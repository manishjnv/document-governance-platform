# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Entry-point scoring heuristics and flow labels."""

from __future__ import annotations

import re
from dataclasses import dataclass

from context_graph_sdk.graph.symbols import is_test_file

ORCHESTRATOR_MAX_CALLERS = 3
ORCHESTRATOR_MIN_CALLEES = 4

_UNIVERSAL_ENTRY = frozenset({"main", "init", "bootstrap", "start", "run", "setup", "configure"})

_ENTRY_PREFIXES = tuple(
    re.compile(pattern, re.IGNORECASE)
    for pattern in (
        r"^handle", r"^on[A-Z]", r"Controller$", r"Handler$", r"^process[A-Z]",
        r"^execute", r"^perform", r"^dispatch", r"^trigger", r"^fire", r"^emit",
    )
)  # fmt: skip

_UTILITY_PATTERNS = (
    *(
        re.compile(pattern, re.IGNORECASE)
        for pattern in (
            r"^get[A-Z]", r"^set[A-Z]", r"^is[A-Z]", r"^has[A-Z]", r"^can[A-Z]",
            r"^format", r"^parse", r"^validate", r"^toString", r"^fromJSON",
            r"^from[A-Z]", r"^encode", r"^decode", r"^serialize", r"^clone", r"^merge",
        )
    ),
    re.compile(r"^_"),  # private-by-convention
)  # fmt: skip

_LANGUAGE_PATTERNS: dict[str, tuple[re.Pattern[str], ...]] = {
    "typescript": (re.compile(r"^use[A-Z]"),),
    "javascript": (re.compile(r"^use[A-Z]"),),
    "python": tuple(
        re.compile(p) for p in (r"^get_", r"^post_", r"^put_", r"^delete_", r"^patch_")
    ),
    "java": (re.compile(r"^do(Get|Post|Put|Delete)"), re.compile(r"^service$")),
    "go": tuple(re.compile(p) for p in (r"^New[A-Z]", r"^Handle", r"^Serve")),
    "rust": tuple(re.compile(p) for p in (r"^handle_", r"^process_", r"^serve")),
    "swift": tuple(
        re.compile(p)
        for p in (
            r"^viewDidLoad$", r"^viewWillAppear$", r"^body$",
            r"^applicationDidFinishLaunching",
        )
    ),
    "php": tuple(
        re.compile(p)
        for p in (r"^handle$", r"^index$", r"^store$", r"^show$", r"^update$", r"^destroy$")
    ),
    "csharp": tuple(
        re.compile(p) for p in (r"^(Get|Post|Put|Delete|Patch)[A-Z]", r"^On[A-Z]", r"^Configure")
    ),
    "c": tuple(
        re.compile(p)
        for p in (
            r"_init$", r"^init_", r"_start$", r"^start_", r"_handler$", r"^handle_",
            r"_callback$", r"^cmd_", r"^server_", r"^client_", r"^session_",
            r"^window_", r"^signal_", r"^event_",
        )
    ),
    "cpp": tuple(
        re.compile(p)
        for p in (
            r"^(Create|create)[A-Z_]",
            r"^(Run|run)$",
            r"^(Start|start)$",
            r"^On[A-Z]",
            r"^on_",
        )
    ),
    "scala": tuple(re.compile(p) for p in (r"^apply$", r"^receive$", r"^props$", r"^routes?$")),
}  # fmt: skip

_FRAMEWORK_PATTERNS = tuple(
    (re.compile(pattern, re.IGNORECASE), reason)
    for pattern, reason in (
        (r"(^|/)pages/", "framework:nextjs-page"),
        (r"(^|/)app/.*route\.(ts|js)x?$", "framework:nextjs-app-router"),
        (r"(^|/)routes/", "framework:route-handler"),
        (r"(^|/)controllers/", "framework:controller"),
        (r"(^|/)handlers/", "framework:handler"),
        (r"(^|/)api/", "framework:api-handler"),
        (r"(^|/)middleware/", "framework:middleware"),
    )
)

_LABEL_RULES: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("Initialization", ("init", "bootstrap", "setup")),
    ("Shutdown", ("shutdown", "cleanup", "teardown", "dispose", "close")),
    ("Test flow", ("test", "bench")),
    ("Server", ("serve", "listen", "accept")),
    ("Request handler", ("handle", "handler", "endpoint", "middleware")),
    ("Router", ("route", "dispatch")),
    ("Create operation", ("create", "insert", "add", "new")),
    ("Update operation", ("update", "modify", "patch", "set")),
    ("Delete operation", ("delete", "remove", "destroy", "drop")),
    ("Read operation", ("get", "fetch", "load", "read", "find", "lookup", "query")),
    ("List operation", ("list", "scan", "iterate", "enum")),
    ("Processing", ("process", "execute", "run", "eval")),
    ("Parser", ("parse", "decode", "unmarshal", "deserialize")),
    ("Serializer", ("format", "encode", "marshal", "serialize", "render")),
    ("Transformer", ("convert", "transform", "map")),
    ("Copy operation", ("copy", "clone", "dup")),
    ("Merge operation", ("merge", "combine", "join")),
    ("Validation", ("valid", "check", "verify")),
    ("Authentication", ("auth", "login", "permit", "acl")),
    ("Synchronization", ("sync", "reconcil", "replicat")),
    ("Scheduler", ("schedule", "plan", "allocat")),
    ("Watcher", ("watch", "monitor", "poll", "subscribe")),
    ("Event emitter", ("emit", "publish", "notify", "broadcast", "event")),
    ("Observability", ("log", "metric", "trace", "audit")),
    ("Registration", ("register", "bind", "wire", "connect")),
    ("Configuration", ("config", "option", "setting")),
    ("Migration", ("migrat", "upgrade", "schema")),
    ("Lifecycle", ("start", "stop", "restart")),
)


def heuristic_label(name: str) -> str:
    lower = name.lower()
    if lower == "main" or lower.endswith(".main"):
        return "Application entry point"
    for label, patterns in _LABEL_RULES:
        if any(pattern in lower for pattern in patterns):
            return label
    return "Execution flow"


@dataclass(frozen=True)
class EntryPointScore:
    score: float
    reasons: tuple[str, ...]


def detect_framework(file_path: str) -> str:
    normalized = file_path.replace("\\", "/")
    for pattern, reason in _FRAMEWORK_PATTERNS:
        if pattern.search(normalized):
            return reason
    return ""


def _name_multiplier(name: str, language: str) -> tuple[float, str]:
    if name.lower() in _UNIVERSAL_ENTRY:
        return 1.5, "entry-pattern"
    for pattern in _ENTRY_PREFIXES:
        if pattern.search(name):
            return 1.5, "entry-pattern"
    for pattern in _LANGUAGE_PATTERNS.get(language, ()):
        if pattern.search(name):
            return 1.5, "entry-pattern"
    for pattern in _UTILITY_PATTERNS:
        if pattern.search(name):
            return 0.3, "utility-pattern"
    return 1.0, ""


def entry_point_score(
    name: str,
    language: str,
    is_exported: bool,
    caller_count: int,
    callee_count: int,
    file_path: str = "",
) -> EntryPointScore:
    if callee_count == 0:
        return EntryPointScore(0.0, ("no-outgoing-calls",))
    reasons: list[str] = []
    base = callee_count / (caller_count + 1)
    multiplier = 1.0
    if is_exported:
        multiplier *= 2.0
        reasons.append("exported")
    name_multiplier, name_reason = _name_multiplier(name, language)
    multiplier *= name_multiplier
    if name_reason:
        reasons.append(name_reason)
    if file_path:
        framework = detect_framework(file_path)
        if framework:
            multiplier *= 1.5
            reasons.append(framework)
    return EntryPointScore(base * multiplier, tuple(reasons))


def is_command_dir(file_path: str) -> bool:
    if not file_path:
        return False
    return any(
        part.lower() in ("cmd", "command", "commands", "cli")
        for part in file_path.replace("\\", "/").split("/")
    )


__all__ = [
    "ORCHESTRATOR_MAX_CALLERS",
    "ORCHESTRATOR_MIN_CALLEES",
    "EntryPointScore",
    "detect_framework",
    "entry_point_score",
    "heuristic_label",
    "is_command_dir",
    "is_test_file",
]
