# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Package.swift parsing."""

from __future__ import annotations

import re

from context_graph_sdk.project.config import (
    DependencyRecord,
    ManifestReader,
    ManifestRecord,
    ProjectConfig,
    workspace_display_name,
)

_PACKAGE_NAME = re.compile(r'name:\s*"([^"]+)"')
_PACKAGE_DEPENDENCY = re.compile(
    r'\.package\s*\(\s*url:\s*"([^"]+)"\s*,\s*'
    r'(?:from:\s*"([^"]+)"|exact:\s*"([^"]+)"'
    r'|\.upToNextMajor\s*\(\s*from:\s*"([^"]+)"\s*\)'
    r'|\.upToNextMinor\s*\(\s*from:\s*"([^"]+)"\s*\)'
    r'|"([^"]+)"\s*\.\.[.<]\s*"[^"]+")'
)


def _package_name_from_url(url: str) -> str:
    name = url.removesuffix(".git").rsplit("/", 1)[-1]
    return name or url


def load_swift_package_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("Package.swift"):
        if relative != "Package.swift":
            continue
        text = reader.read_text(relative)
        if text is None:
            continue
        for match in _PACKAGE_DEPENDENCY.finditer(text):
            version = next((group for group in match.groups()[1:] if group), "")
            config.add_dependency(
                DependencyRecord(_package_name_from_url(match.group(1)), version, relative)
            )


def load_swift_package_manifests(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("Package.swift"):
        text = reader.read_text(relative)
        if text is None:
            continue
        name_match = _PACKAGE_NAME.search(text)
        name = name_match.group(1) if name_match else workspace_display_name(reader.root, relative)
        config.add_manifest(ManifestRecord(name, relative, "swift"))
