# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Assignment ACCESSES edges, type USES edges, and type property updates."""

from __future__ import annotations

from context_graph_sdk.extractors.records import Symbol
from context_graph_sdk.models import LocalRelationshipType
from context_graph_sdk.resolution.context import ResolutionContext, ResolutionResult

_TYPE_TARGET_LABELS = ("Class", "Struct", "Interface", "Trait", "Enum", "Record")


def _assignment_target(
    context: ResolutionContext, candidates: list[Symbol], writer_id: str
) -> Symbol | None:
    if not candidates:
        return None
    writer = context.symbols_by_id.get(writer_id)
    if writer is None or len(candidates) == 1:
        return candidates[0]
    if writer.owner_name:
        for candidate in candidates:
            if candidate.label in ("Property", "Const") and (
                candidate.owner_name == writer.owner_name
                and candidate.file_path == writer.file_path
            ):
                return candidate
    for candidate in candidates:
        if candidate.file_path == writer.file_path:
            return candidate
    return candidates[0]


def resolve_assignments(context: ResolutionContext, result: ResolutionResult) -> None:
    for path, file_result in context.extraction.files:
        for assignment in file_result.assignments:
            candidates = context.symbols_by_name.get(assignment.property_name, [])
            if not candidates:
                continue
            writer_id = context.enclosing_symbol(path, assignment.line)
            target = _assignment_target(context, candidates, writer_id)
            if target is None:
                continue
            result.add_edge(
                writer_id,
                LocalRelationshipType.ACCESSES,
                target.id,
                {"accessKind": "write"},
            )


def _owners_in_file(context: ResolutionContext, owner_name: str, path: str) -> list[Symbol]:
    return [
        candidate
        for candidate in context.symbols_by_name.get(owner_name, [])
        if candidate.file_path == path
    ]


def resolve_type_bindings(context: ResolutionContext, result: ResolutionResult) -> None:
    # Keyed by (file, owner) so same-named functions in other files never
    # receive another file's parameter/return metadata.
    parameter_types: dict[tuple[str, str], list[tuple[str, str]]] = {}
    for path, file_result in context.extraction.files:
        for binding in file_result.type_bindings:
            source_id = context.enclosing_symbol(path, binding.line)
            if binding.type_name and binding.variable_name not in ("@return", "@type"):
                for candidate in context.symbols_by_name.get(binding.type_name, []):
                    if candidate.label in _TYPE_TARGET_LABELS:
                        result.add_edge(
                            source_id,
                            LocalRelationshipType.USES,
                            candidate.id,
                            {"reason": f"type-binding:{binding.kind}"},
                        )
                        break
            if binding.kind == "parameter" and binding.owner_name:
                parameter_types.setdefault((path, binding.owner_name), []).append(
                    (binding.variable_name, binding.type_name)
                )
            if (
                binding.kind == "comment"
                and binding.variable_name == "@return"
                and binding.owner_name
            ):
                for owner in _owners_in_file(context, binding.owner_name, path):
                    if not owner.return_type:
                        result.update_property(owner.id, "returnType", binding.type_name)

    for (path, owner_name), entries in sorted(parameter_types.items()):
        rendered = ", ".join(f"{name}:{type_name}" for name, type_name in entries)
        for owner in _owners_in_file(context, owner_name, path):
            result.update_property(owner.id, "parameterTypes", rendered)
