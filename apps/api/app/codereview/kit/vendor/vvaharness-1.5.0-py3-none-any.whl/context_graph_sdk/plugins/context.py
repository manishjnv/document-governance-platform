# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Bounded local plugin execution context implementations."""

from __future__ import annotations

import threading
from dataclasses import dataclass
from pathlib import Path

from context_graph_sdk.errors import ModelValidationError
from context_graph_sdk.models import FrozenMap
from context_graph_sdk.pipeline import PluginDiagnostic, PluginLogLevel

MAX_PLUGIN_REPORTS = 1_000
MAX_SOURCE_READ_BYTES = 10 * 1024 * 1024


class CancellationToken:
    def __init__(self) -> None:
        self._event = threading.Event()

    @property
    def is_cancelled(self) -> bool:
        return self._event.is_set()

    def cancel(self) -> None:
        self._event.set()


class RepositorySourceReader:
    def __init__(self, root: Path) -> None:
        self._root = root.resolve()

    def read_text(self, relative_path: str, max_bytes: int) -> str:
        if not 0 < max_bytes <= MAX_SOURCE_READ_BYTES:
            raise ModelValidationError("source read byte limit is outside the approved bound")
        candidate = (self._root / relative_path).resolve()
        if candidate == self._root or self._root not in candidate.parents:
            raise ModelValidationError("plugin source path escapes the repository")
        with candidate.open("rb") as source:
            return source.read(max_bytes).decode("utf-8", errors="replace")


@dataclass(frozen=True)
class PluginLogRecord:
    level: PluginLogLevel
    message: str
    details: FrozenMap


class BufferedPluginReporter:
    # One shared instance applies this aggregate budget across an entire run.
    def __init__(self) -> None:
        self._logs: list[PluginLogRecord] = []
        self._diagnostics: list[PluginDiagnostic] = []

    @property
    def logs(self) -> tuple[PluginLogRecord, ...]:
        return tuple(self._logs)

    @property
    def diagnostics(self) -> tuple[PluginDiagnostic, ...]:
        return tuple(self._diagnostics)

    def log(self, level: PluginLogLevel, message: str, details: FrozenMap) -> None:
        if not message:
            raise ModelValidationError("plugin log message is required")
        self._reserve()
        self._logs.append(PluginLogRecord(level, message, details))

    def diagnostic(self, diagnostic: PluginDiagnostic) -> None:
        self._reserve()
        self._diagnostics.append(diagnostic)

    def _reserve(self) -> None:
        if len(self._logs) + len(self._diagnostics) >= MAX_PLUGIN_REPORTS:
            raise ModelValidationError("plugin report count exceeds bound")
