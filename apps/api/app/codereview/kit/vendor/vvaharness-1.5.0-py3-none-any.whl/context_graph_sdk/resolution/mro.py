# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""C3 linearization, language-aware method resolution, and OVERRIDES edges."""

from __future__ import annotations

from dataclasses import dataclass, field

from context_graph_sdk.errors import ModelValidationError
from context_graph_sdk.extractors.records import Symbol
from context_graph_sdk.models import LocalRelationshipType
from context_graph_sdk.resolution.context import ResolutionContext, ResolutionResult
from context_graph_sdk.resolution.heritage import CLASS_LIKE_LABELS

_MAX_LINEARIZE_STEPS = 10_000
_MAX_HIERARCHY_DEPTH = 1_000


def c3_linearize(hierarchy: dict[str, list[str]]) -> dict[str, list[str]]:
    """Iterative C3 MRO; raises on cycles, depth, or unmergeable input."""
    result: dict[str, list[str]] = {}
    all_classes = sorted(
        set(hierarchy).union({parent for parents in hierarchy.values() for parent in parents})
    )
    for root in all_classes:
        if root in result:
            continue
        stack: list[tuple[str, bool]] = [(root, False)]
        in_progress: set[str] = set()
        while stack:
            if len(stack) > _MAX_HIERARCHY_DEPTH:
                raise ModelValidationError("hierarchy linearization exceeded the depth bound")
            cls, expanded = stack.pop()
            if cls in result:
                continue
            parents = hierarchy.get(cls, [])
            if expanded:
                sequences = [list(result[parent]) for parent in parents]
                sequences.append(list(parents))
                result[cls] = [cls, *_c3_merge(sequences)]
                in_progress.discard(cls)
                continue
            if cls in in_progress:
                raise ModelValidationError(f"inconsistent hierarchy: cycle involving {cls!r}")
            in_progress.add(cls)
            stack.append((cls, True))
            for parent in reversed(parents):
                if parent in in_progress:
                    raise ModelValidationError(
                        f"inconsistent hierarchy: cycle involving {parent!r}"
                    )
                if parent not in result:
                    stack.append((parent, False))
    return result


def _c3_merge(sequences: list[list[str]]) -> list[str]:
    merged: list[str] = []
    for _ in range(_MAX_LINEARIZE_STEPS):
        sequences = [sequence for sequence in sequences if sequence]
        if not sequences:
            return merged
        found = ""
        for sequence in sequences:
            candidate = sequence[0]
            if not any(candidate in other[1:] for other in sequences):
                found = candidate
                break
        if not found:
            raise ModelValidationError("inconsistent hierarchy: cannot resolve merge order")
        merged.append(found)
        for sequence in sequences:
            if sequence and sequence[0] == found:
                del sequence[0]
    raise ModelValidationError("hierarchy linearization exceeded the step bound")


@dataclass(frozen=True)
class MROAmbiguity:
    method_name: str
    defined_in: tuple[str, ...]
    resolved_to: str
    reason: str


@dataclass(frozen=True)
class MROEntry:
    class_name: str
    language: str
    ambiguities: tuple[MROAmbiguity, ...] = ()


@dataclass
class MROComputation:
    entries: list[MROEntry] = field(default_factory=list[MROEntry])
    override_edges: int = 0
    ambiguity_count: int = 0


@dataclass(frozen=True)
class _AncestorMethod:
    symbol: Symbol
    parent: Symbol
    is_class: bool


def _linearize_all(
    hierarchy: dict[str, list[str]],
) -> tuple[dict[str, list[str]], dict[str, str]]:
    """Per-class C3 with memoization; a cycle or merge failure isolates to
    the affected classes, which deterministically fall back to themselves
    plus their direct parents."""
    orders: dict[str, list[str]] = {}
    failures: dict[str, str] = {}
    for cls in sorted(hierarchy):
        subset_seen: set[str] = set()
        pending = [cls]
        subset: dict[str, list[str]] = {}
        while pending:
            current = pending.pop()
            if current in subset_seen:
                continue
            subset_seen.add(current)
            parents = hierarchy.get(current, [])
            subset[current] = list(parents)
            pending.extend(parents)
        try:
            orders.update(c3_linearize(subset))
        except ModelValidationError as error:
            failures[cls] = str(error)
            orders[cls] = [cls, *hierarchy.get(cls, [])]
    return orders, failures


def compute_mro(context: ResolutionContext, result: ResolutionResult) -> MROComputation:
    """Apply full-hierarchy C3 linearization with language-aware ambiguity rules.

    Ancestors along the complete linearization contribute shadowing OVERRIDES
    relationships and ambiguity resolution.
    """
    computation = MROComputation()

    parents_by_child: dict[str, list[str]] = {}
    for edge in result.edges:
        if edge.relationship in (
            LocalRelationshipType.INHERITS,
            LocalRelationshipType.IMPLEMENTS,
        ):
            if edge.target_local_id not in context.symbols_by_id:
                continue
            bucket = parents_by_child.setdefault(edge.source_local_id, [])
            if edge.target_local_id not in bucket:
                bucket.append(edge.target_local_id)

    orders, failures = _linearize_all(parents_by_child)

    methods_by_owner: dict[str, list[Symbol]] = {}
    for symbol in context.symbols:
        if symbol.label == "Method" and symbol.owner_name:
            methods_by_owner.setdefault(f"{symbol.file_path}\x00{symbol.owner_name}", []).append(
                symbol
            )

    def own_methods(owner: Symbol) -> list[Symbol]:
        return methods_by_owner.get(f"{owner.file_path}\x00{owner.name}", [])

    for symbol in context.symbols:
        if symbol.label not in CLASS_LIKE_LABELS:
            continue
        if symbol.id not in parents_by_child:
            continue
        ancestors = [
            context.symbols_by_id[ancestor_id]
            for ancestor_id in orders.get(symbol.id, [])[1:]
            if ancestor_id in context.symbols_by_id
        ]
        if not ancestors:
            continue

        own_names = {method.name for method in own_methods(symbol)}

        # Shadowing: a child method overrides same-name methods in every
        # ancestor along the linearization (grandparents included).
        for child_method in own_methods(symbol):
            for ancestor in ancestors:
                for ancestor_method in own_methods(ancestor):
                    if ancestor_method.name == child_method.name and result.add_edge(
                        child_method.id,
                        LocalRelationshipType.OVERRIDES,
                        ancestor_method.id,
                    ):
                        computation.override_edges += 1

        sources_by_name: dict[str, list[_AncestorMethod]] = {}
        for ancestor in ancestors:
            is_class = ancestor.label in ("Class", "Struct")
            for method in own_methods(ancestor):
                sources_by_name.setdefault(method.name, []).append(
                    _AncestorMethod(method, ancestor, is_class)
                )

        ambiguities: list[MROAmbiguity] = []
        if symbol.id in failures:
            ambiguities.append(
                MROAmbiguity("", (), "", f"linearization fallback: {failures[symbol.id]}")
            )
        for method_name in sorted(sources_by_name):
            if method_name in own_names:
                continue
            unique: list[_AncestorMethod] = []
            seen: set[str] = set()
            for source in sources_by_name[method_name]:
                if source.symbol.id not in seen:
                    seen.add(source.symbol.id)
                    unique.append(source)
            if len(unique) < 2:
                continue
            resolved_to, reason = _resolve_ambiguity(symbol.language, unique, ancestors)
            ambiguities.append(
                MROAmbiguity(
                    method_name,
                    tuple(source.symbol.id for source in unique),
                    resolved_to,
                    reason,
                )
            )
            if resolved_to:
                if result.add_edge(symbol.id, LocalRelationshipType.OVERRIDES, resolved_to):
                    computation.override_edges += 1
            else:
                computation.ambiguity_count += 1

        computation.entries.append(MROEntry(symbol.name, symbol.language, tuple(ambiguities)))
    return computation


def _resolve_ambiguity(
    language: str, sources: list[_AncestorMethod], parent_order: list[Symbol]
) -> tuple[str, str]:
    if language == "cpp":
        return _resolve_leftmost(sources, parent_order, "C++ leftmost")
    if language == "python":
        return _resolve_leftmost(sources, parent_order, "Python C3")
    if language in ("csharp", "java"):
        return _resolve_class_beats_interface(sources)
    if language == "rust":
        return "", "ambiguous: Rust requires qualified syntax (<Type as Trait>::method)"
    return _resolve_leftmost(sources, parent_order, "leftmost base")


def _resolve_leftmost(
    sources: list[_AncestorMethod], parent_order: list[Symbol], prefix: str
) -> tuple[str, str]:
    # parent_order is the C3 linearization tail, so "leftmost" means the
    # earliest ancestor in true MRO order.
    order_index = {parent.id: index for index, parent in enumerate(parent_order)}
    best: _AncestorMethod | None = None
    best_index = len(parent_order) + 1
    for source in sources:
        index = order_index.get(source.parent.id)
        if index is not None and index < best_index:
            best_index = index
            best = source
    if best is not None:
        return best.symbol.id, f"{prefix} base {best.parent.name} wins"
    return sources[0].symbol.id, f"{prefix} (fallback)"


def _resolve_class_beats_interface(sources: list[_AncestorMethod]) -> tuple[str, str]:
    class_sources = [source for source in sources if source.is_class]
    interface_sources = [source for source in sources if not source.is_class]
    if len(class_sources) == 1:
        return class_sources[0].symbol.id, "class method wins over interface default"
    if len(class_sources) > 1:
        return "", "ambiguous: multiple class methods"
    if len(interface_sources) == 1:
        return interface_sources[0].symbol.id, "single interface method"
    return "", "ambiguous: multiple interface defaults"
