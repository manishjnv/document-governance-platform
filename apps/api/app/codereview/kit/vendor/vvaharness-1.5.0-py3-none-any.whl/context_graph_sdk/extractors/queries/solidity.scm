; Production extraction query set for solidity, ported from the reviewed reference.
(contract_declaration name: (identifier) @name) @definition.class
(interface_declaration name: (identifier) @name) @definition.interface
(library_declaration name: (identifier) @name) @definition.class
(function_definition name: (identifier) @name) @definition.function
(constructor_definition "constructor" @name) @definition.constructor
(fallback_receive_definition "receive" @name) @definition.method
(fallback_receive_definition "fallback" @name) @definition.method
(modifier_definition name: (identifier) @name) @definition.method
(event_definition name: (identifier) @name) @definition.event
(error_declaration name: (identifier) @name) @definition.error
(struct_declaration name: (identifier) @name) @definition.struct
(enum_declaration name: (identifier) @name) @definition.enum
(state_variable_declaration "constant" name: (identifier) @name) @definition.constant
(state_variable_declaration name: (identifier) @name) @definition.property
(constant_variable_declaration name: (identifier) @name) @definition.constant
(import_directive source: (string) @import.source) @import
(contract_declaration name: (identifier) @heritage.class (inheritance_specifier ancestor: (_) @heritage.extends)) @heritage
(interface_declaration name: (identifier) @heritage.class (inheritance_specifier ancestor: (_) @heritage.implements)) @heritage.impl
(call_expression . (expression (identifier) @call.name)) @call
(call_expression . (_ (member_expression property: (identifier) @call.name))) @call
(modifier_invocation (identifier) @call.name) @call
(assignment_expression (expression (identifier) @assignment.property) (_)) @assignment
(assignment_expression (expression (member_expression property: (identifier) @assignment.property)) (_)) @assignment
