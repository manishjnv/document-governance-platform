# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Per-language extraction behavior descriptors for all 17 configurations.

The shared routing loop consumes these hooks so language-specific export
rules and post-processing stages stay out of shared modules.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from tree_sitter import Node

from context_graph_sdk.extractors.analysis import (
    has_ancestor_type,
    has_scala_bare_visibility,
    has_sibling_modifier,
    has_sibling_modifier_text,
    has_sibling_node_type,
    has_visibility_modifier,
)
from context_graph_sdk.extractors.languages.jvm import (
    extract_infix_calls,
    extract_primary_constructor_params,
    reclassify_interface_declarations,
)
from context_graph_sdk.extractors.languages.ruby import route_ruby_calls
from context_graph_sdk.extractors.languages.solidity import (
    include_solidity_call,
    solidity_annotation_supplement,
)
from context_graph_sdk.extractors.languages.systems import cpp_annotation_supplement
from context_graph_sdk.extractors.records import MutableFileResult

# A post pass runs after query routing with (root, source, path, language, result).
PostPass = Callable[[Node, bytes, str, str, MutableFileResult], None]


@dataclass(frozen=True)
class LanguageDescriptor:
    is_exported: Callable[[Node, str, bytes], bool]
    interface_method_specs: bool = False
    include_call: Callable[[str, Node, bytes], bool] | None = None
    annotation_supplement: Callable[[Node, bytes], tuple[str, ...]] | None = None
    post_passes: tuple[PostPass, ...] = ()


def _exported_go(_node: Node, name: str, _source: bytes) -> bool:
    return bool(name) and name[0].isupper() and name[0].isascii()


def _exported_python(_node: Node, name: str, _source: bytes) -> bool:
    return not name.startswith("_")


def _exported_ecmascript(node: Node, _name: str, _source: bytes) -> bool:
    return has_ancestor_type(node, "export_statement")


def _exported_public_modifier(node: Node, _name: str, source: bytes) -> bool:
    return has_sibling_modifier(node, source, "public")


def _exported_kotlin(node: Node, _name: str, source: bytes) -> bool:
    return not has_visibility_modifier(node, source, "private", "internal", "protected")


def _exported_rust(node: Node, _name: str, _source: bytes) -> bool:
    return has_sibling_node_type(node, "visibility_modifier")


def _exported_c_family(node: Node, _name: str, source: bytes) -> bool:
    return not has_sibling_modifier_text(node, source, "storage_class_specifier", "static")


def _exported_always(_node: Node, _name: str, _source: bytes) -> bool:
    return True


def _exported_php(node: Node, _name: str, source: bytes) -> bool:
    return not has_visibility_modifier(node, source, "private", "protected")


def _exported_swift(node: Node, _name: str, source: bytes) -> bool:
    return has_visibility_modifier(node, source, "public", "open")


def _exported_scala(node: Node, _name: str, source: bytes) -> bool:
    return not has_scala_bare_visibility(node, source)


def _exported_dart(_node: Node, name: str, _source: bytes) -> bool:
    return not name.startswith("_")


def _exported_solidity(node: Node, _name: str, source: bytes) -> bool:
    return not has_visibility_modifier(node, source, "private", "internal")


_JVM_POST_PASSES: tuple[PostPass, ...] = (
    reclassify_interface_declarations,
    extract_infix_calls,
    extract_primary_constructor_params,
)

LANGUAGE_DESCRIPTORS: dict[str, LanguageDescriptor] = {
    "go": LanguageDescriptor(_exported_go, interface_method_specs=True),
    "python": LanguageDescriptor(_exported_python),
    "javascript": LanguageDescriptor(_exported_ecmascript),
    "typescript": LanguageDescriptor(_exported_ecmascript),
    "tsx": LanguageDescriptor(_exported_ecmascript),
    "java": LanguageDescriptor(_exported_public_modifier),
    "kotlin": LanguageDescriptor(_exported_kotlin, post_passes=_JVM_POST_PASSES),
    "csharp": LanguageDescriptor(
        _exported_public_modifier, post_passes=(extract_primary_constructor_params,)
    ),
    "scala": LanguageDescriptor(
        _exported_scala,
        post_passes=(extract_infix_calls, extract_primary_constructor_params),
    ),
    "c": LanguageDescriptor(_exported_c_family),
    "cpp": LanguageDescriptor(_exported_c_family, annotation_supplement=cpp_annotation_supplement),
    "rust": LanguageDescriptor(_exported_rust),
    "ruby": LanguageDescriptor(_exported_always, post_passes=(route_ruby_calls,)),
    "php": LanguageDescriptor(_exported_php),
    "swift": LanguageDescriptor(_exported_swift, interface_method_specs=True),
    "dart": LanguageDescriptor(_exported_dart),
    "solidity": LanguageDescriptor(
        _exported_solidity,
        include_call=include_solidity_call,
        annotation_supplement=solidity_annotation_supplement,
    ),
}
