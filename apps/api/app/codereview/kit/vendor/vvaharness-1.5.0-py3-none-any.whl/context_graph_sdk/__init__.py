# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Public surface of the Context Graph SDK.

Backend factories stay in :mod:`context_graph_sdk.backends`; query-worker manager
contracts stay in :mod:`context_graph_sdk.query`.
"""

from .api import Workspace
from .backends import GraphSchema, SchemaPattern
from .code_graph import CodeGraph
from .errors import (
    ContextGraphError,
    DiscoveryError,
    LifecycleError,
    ModelValidationError,
    PluginError,
    QueryCancelledError,
    QueryError,
    QueryProtocolError,
    QueryResourceLimitError,
    QueryTimeoutError,
    QueryValidationError,
    QueryWorkerError,
    SnapshotLifecycleError,
    StructuredQueryError,
    StructuredQueryLimitError,
    SymbolAmbiguousError,
    SymbolNotFoundError,
    WorkspaceClosedError,
    WorkspaceLockedError,
)
from .identity import ProjectId, SnapshotId, make_edge_id, make_global_id, make_local_id
from .models import (
    AnalysisVersion,
    CorrelationEdge,
    CorrelationEndpointRole,
    CorrelationType,
    FrozenMap,
    GraphEdge,
    GraphMutation,
    GraphNode,
    GraphSnapshot,
    LocalRelationshipType,
    NodeLabel,
    NodeRef,
    ProjectMetadata,
    ProjectSnapshot,
    SnapshotInfo,
    SnapshotLocator,
    freeze_properties,
)
from .normalization import graph_fingerprint, normalize_snapshot
from .pipeline import CorrelationContext, PluginContext, PluginDiagnostic
from .plugins import CorrelationProvider, GraphEnricher, PluginMetadata, PluginPhase
from .progress import AnalysisPhase, AnalysisProgress, AnalysisProgressCallback
from .query import (
    ContextLimits,
    ContextResult,
    CorrelationLimits,
    CorrelationMatch,
    CorrelationResult,
    EntityReference,
    ImpactDirection,
    ImpactLimits,
    ImpactResult,
    QueryLimits,
    QueryWorkerResult,
    RelationshipDirection,
    RelationshipGroup,
    SymbolSelector,
    TraversalPath,
    TruncationReason,
)

__all__ = [
    "AnalysisPhase",
    "AnalysisProgress",
    "AnalysisProgressCallback",
    "AnalysisVersion",
    "CodeGraph",
    "ContextGraphError",
    "ContextLimits",
    "ContextResult",
    "CorrelationContext",
    "CorrelationEdge",
    "CorrelationEndpointRole",
    "CorrelationLimits",
    "CorrelationMatch",
    "CorrelationProvider",
    "CorrelationResult",
    "CorrelationType",
    "DiscoveryError",
    "EntityReference",
    "FrozenMap",
    "GraphEdge",
    "GraphEnricher",
    "GraphMutation",
    "GraphNode",
    "GraphSchema",
    "GraphSnapshot",
    "ImpactDirection",
    "ImpactLimits",
    "ImpactResult",
    "LifecycleError",
    "LocalRelationshipType",
    "ModelValidationError",
    "NodeLabel",
    "NodeRef",
    "PluginContext",
    "PluginDiagnostic",
    "PluginError",
    "PluginMetadata",
    "PluginPhase",
    "ProjectId",
    "ProjectMetadata",
    "ProjectSnapshot",
    "QueryCancelledError",
    "QueryError",
    "QueryLimits",
    "QueryProtocolError",
    "QueryResourceLimitError",
    "QueryTimeoutError",
    "QueryValidationError",
    "QueryWorkerError",
    "QueryWorkerResult",
    "RelationshipDirection",
    "RelationshipGroup",
    "SchemaPattern",
    "SnapshotId",
    "SnapshotInfo",
    "SnapshotLifecycleError",
    "SnapshotLocator",
    "StructuredQueryError",
    "StructuredQueryLimitError",
    "SymbolAmbiguousError",
    "SymbolNotFoundError",
    "SymbolSelector",
    "TraversalPath",
    "TruncationReason",
    "Workspace",
    "WorkspaceClosedError",
    "WorkspaceLockedError",
    "freeze_properties",
    "graph_fingerprint",
    "make_edge_id",
    "make_global_id",
    "make_local_id",
    "normalize_snapshot",
]
