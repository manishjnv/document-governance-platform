# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Core Tree-sitter extraction engine (Go, Python, JavaScript, TypeScript, TSX)."""

from __future__ import annotations

from collections.abc import Callable
from typing import cast

from context_graph_sdk.extractors.records import ExtractionResult, FileDiagnostic, FileExtraction
from context_graph_sdk.extractors.runtime import (
    DEFAULT_FILE_TIMEOUT_SECONDS,
    DEFAULT_MAX_WORKERS,
    SUPPORTED_LANGUAGES,
    WorkItem,
    analysis_components,
    is_supported_language,
    run_bounded,
)


def extract_repository(
    root: str,
    files: list[tuple[str, str]],
    *,
    max_workers: int | None = None,
    file_timeout_seconds: float | None = None,
    on_progress: Callable[[int, int], None] | None = None,
) -> ExtractionResult:
    """Extract all supported (relative_path, language) files under root.

    Output order is the sorted input order regardless of worker scheduling;
    per-file failures become diagnostics instead of aborting other files.
    """
    items = sorted(
        (
            WorkItem(relative_path, language)
            for relative_path, language in files
            if is_supported_language(language)
        ),
        key=lambda item: item.relative_path,
    )
    raw_successes, failures = run_bounded(
        root,
        items,
        max_workers=max_workers if max_workers is not None else DEFAULT_MAX_WORKERS,
        file_timeout_seconds=(
            file_timeout_seconds
            if file_timeout_seconds is not None
            else DEFAULT_FILE_TIMEOUT_SECONDS
        ),
        on_progress=on_progress,
    )
    successes = [(item, cast(FileExtraction, extraction)) for item, extraction in raw_successes]
    return ExtractionResult(
        tuple((item.relative_path, extraction) for item, extraction in successes),
        tuple(FileDiagnostic(item.relative_path, reason) for item, reason in failures),
    )


__all__ = [
    "SUPPORTED_LANGUAGES",
    "ExtractionResult",
    "analysis_components",
    "extract_repository",
    "is_supported_language",
]
