# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Derived analysis stage: communities then processes, one deterministic pass.

Both entry points share one algorithm implementation over
:class:`AnalysisInputs`; ``derive_snapshot`` is the production path used by
the plugin runner's derive callback so PRE_DERIVATION mutations influence
communities/processes and default POST mutations do not.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from context_graph_sdk.analysis.communities import CommunityRecord, detect_communities
from context_graph_sdk.analysis.inputs import (
    AnalysisInputs,
    inputs_from_records,
    inputs_from_snapshot,
)
from context_graph_sdk.analysis.processes import ProcessOptions, ProcessRecord, detect_processes
from context_graph_sdk.extractors.records import ExtractionResult
from context_graph_sdk.models import (
    GraphEdge,
    GraphNode,
    GraphSnapshot,
    LocalRelationshipType,
    freeze_properties,
)
from context_graph_sdk.resolution.context import ResolutionResult


@dataclass(frozen=True)
class DerivedNode:
    local_id: str
    label: str
    properties: tuple[tuple[str, object], ...]


@dataclass(frozen=True)
class DerivedEdge:
    source_local_id: str
    relationship: LocalRelationshipType
    target_local_id: str
    properties: tuple[tuple[str, object], ...] = ()


@dataclass
class DerivedAnalysis:
    nodes: list[DerivedNode] = field(default_factory=list[DerivedNode])
    edges: list[DerivedEdge] = field(default_factory=list[DerivedEdge])
    communities: list[CommunityRecord] = field(default_factory=list[CommunityRecord])
    processes: list[ProcessRecord] = field(default_factory=list[ProcessRecord])


def _derive(inputs: AnalysisInputs, process_options: ProcessOptions | None) -> DerivedAnalysis:
    derived = DerivedAnalysis()
    derived.communities = detect_communities(inputs)
    community_of: dict[str, str] = {}
    for community in derived.communities:
        derived.nodes.append(
            DerivedNode(
                community.local_id,
                "Community",
                (
                    ("modularity", community.modularity),
                    ("name", community.name),
                    ("size", community.size),
                ),
            )
        )
        for member_id in community.member_ids:
            community_of[member_id] = community.name
            derived.edges.append(
                DerivedEdge(member_id, LocalRelationshipType.MEMBER_OF, community.local_id)
            )

    derived.processes = detect_processes(inputs, community_of, process_options)
    for process in derived.processes:
        properties: list[tuple[str, object]] = [
            ("callerCount", process.caller_count),
            ("entryPoint", process.entry_point_id),
            ("entryPointScore", process.entry_point_score),
            ("heuristicLabel", process.heuristic_label),
            ("importance", process.importance),
            ("name", process.name),
            ("stepCount", process.step_count),
        ]
        if process.cross_community:
            properties.append(("crossCommunity", True))
        derived.nodes.append(DerivedNode(process.local_id, "Process", tuple(properties)))
        for step_id, step_number in process.steps:
            derived.edges.append(
                DerivedEdge(
                    step_id,
                    LocalRelationshipType.STEP_IN_PROCESS,
                    process.local_id,
                    (("step", step_number),),
                )
            )
    return derived


def derive_analysis(
    extraction: ExtractionResult,
    resolution: ResolutionResult,
    process_options: ProcessOptions | None = None,
) -> DerivedAnalysis:
    """Record-path derivation used by fixtures and benchmarks."""
    return _derive(inputs_from_records(extraction, resolution), process_options)


def derive_snapshot(
    snapshot: GraphSnapshot, process_options: ProcessOptions | None = None
) -> GraphSnapshot:
    """Snapshot-path derivation: adds Community/Process nodes and their
    MEMBER_OF/STEP_IN_PROCESS edges to the candidate snapshot."""
    derived = _derive(inputs_from_snapshot(snapshot), process_options)
    if not derived.nodes and not derived.edges:
        return snapshot
    project_id = snapshot.project.project_id
    new_nodes = list(snapshot.nodes)
    nodes_by_local: dict[str, GraphNode] = {node.local_id: node for node in snapshot.nodes}
    for derived_node in derived.nodes:
        node = GraphNode(
            project_id,
            derived_node.local_id,
            (derived_node.label,),
            freeze_properties(dict(derived_node.properties)),
        )
        nodes_by_local[node.local_id] = node
        new_nodes.append(node)
    new_edges = list(snapshot.edges)
    for derived_edge in derived.edges:
        source = nodes_by_local.get(derived_edge.source_local_id)
        target = nodes_by_local.get(derived_edge.target_local_id)
        if source is None or target is None:
            continue
        new_edges.append(
            GraphEdge(
                project_id,
                source.id,
                derived_edge.relationship.value,
                target.id,
                properties=freeze_properties(dict(derived_edge.properties)),
            )
        )
    return GraphSnapshot(
        snapshot.project,
        snapshot.snapshot_id,
        snapshot.analysis_version,
        tuple(new_nodes),
        tuple(new_edges),
    )
