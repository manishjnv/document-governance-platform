# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deterministic workspace correlation provider execution."""

from __future__ import annotations

import time
from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass
from typing import cast

from context_graph_sdk.errors import ModelValidationError, PluginError, SnapshotLifecycleError
from context_graph_sdk.identity import ProjectId, SnapshotId
from context_graph_sdk.models import (
    CorrelationEdge,
    FrozenMap,
    GraphNode,
    GraphSnapshot,
    NodeRef,
    ProjectSnapshot,
    ProviderManifest,
    SnapshotLocator,
    freeze_properties,
)
from context_graph_sdk.pipeline import AcceptedGraphReader, CorrelationContext, PluginDiagnostic

from .base import CorrelationProvider, PluginMetadata, PluginPhase
from .context import BufferedPluginReporter, CancellationToken, PluginLogRecord

MAX_CORRELATION_PROVIDERS = 32
MAX_ACCEPTED_TOUCHING_CORRELATIONS = 5_000


@dataclass(frozen=True)
class ProviderRunLimits:
    max_edges_per_provider: int = 1_000
    max_total_edges: int = 5_000
    max_reader_queries: int = 256
    max_rows_per_query: int = 1_000
    max_total_rows: int = 10_000

    def __post_init__(self) -> None:
        if (
            min(
                self.max_edges_per_provider,
                self.max_total_edges,
                self.max_reader_queries,
                self.max_rows_per_query,
                self.max_total_rows,
            )
            <= 0
        ):
            raise ModelValidationError("correlation limits must be positive")


class CorrelationProviderRegistry:
    def __init__(self, providers: Iterable[object] = ()) -> None:
        candidates = tuple(providers)
        if len(candidates) > MAX_CORRELATION_PROVIDERS:
            raise ModelValidationError("correlation provider count exceeds bound")
        names: set[str] = set()
        registered: list[CorrelationProvider] = []
        for provider in candidates:
            if not isinstance(provider, CorrelationProvider):
                raise ModelValidationError("provider must implement CorrelationProvider")
            metadata = provider.metadata
            if metadata.phase != PluginPhase.CORRELATION:
                raise ModelValidationError("correlation provider must use correlation phase")
            if metadata.name in names:
                raise ModelValidationError(f"duplicate correlation provider: {metadata.name}")
            names.add(metadata.name)
            registered.append(provider)
        self._providers = tuple(
            sorted(registered, key=lambda provider: provider.metadata.ordering_key)
        )
        self._versions = {
            provider.metadata.name: provider.metadata.version for provider in self._providers
        }

    def __iter__(self) -> Iterator[CorrelationProvider]:
        return iter(self._providers)

    def __bool__(self) -> bool:
        return bool(self._providers)

    def manifests(
        self, project_id: ProjectId, snapshot_id: SnapshotId
    ) -> tuple[ProviderManifest, ...]:
        return tuple(
            ProviderManifest(
                project_id, snapshot_id, provider.metadata.name, provider.metadata.version
            )
            for provider in self._providers
        )

    def preflight(
        self,
        project_id: ProjectId,
        manifests: tuple[ProviderManifest, ...],
        correlations: tuple[CorrelationEdge, ...],
    ) -> None:
        if len(manifests) > MAX_CORRELATION_PROVIDERS:
            raise PluginError(
                "registry",
                PluginPhase.CORRELATION.value,
                "accepted provider manifest count exceeds bound",
                context=f"project={project_id}",
            )
        if len(correlations) > MAX_ACCEPTED_TOUCHING_CORRELATIONS:
            raise PluginError(
                "registry",
                PluginPhase.CORRELATION.value,
                "accepted touching correlation count exceeds bound",
                context=f"project={project_id}",
            )
        required = {(manifest.provider_name, manifest.provider_version) for manifest in manifests}
        required.update((edge.provider_name, edge.provider_version) for edge in correlations)
        for name, version in sorted(required):
            if self._versions.get(name) != version:
                raise PluginError(
                    name,
                    PluginPhase.CORRELATION.value,
                    f"accepted correlations require provider version {version}",
                    context=f"project={project_id}",
                )


AcceptedExecute = Callable[[SnapshotLocator, str, FrozenMap, int, float], tuple[FrozenMap, ...]]


class CorrelationEndpointValidator:
    """Runner-internal endpoint checks with a budget separate from provider reads."""

    def __init__(
        self,
        accepted: tuple[ProjectSnapshot, ...],
        execute: AcceptedExecute,
        max_checks: int,
        deadline_monotonic: float,
    ) -> None:
        self._accepted = {
            (snapshot.project.project_id, snapshot.snapshot_id): snapshot.locator
            for snapshot in accepted
        }
        self._execute = execute
        self._max_checks = max_checks
        self._deadline_monotonic = deadline_monotonic
        self._checks = 0
        self._cache: dict[tuple[ProjectId, SnapshotId, str, str], bool] = {}

    def exists(self, ref: NodeRef) -> bool:
        key = (ref.project_id, ref.snapshot_id, ref.node_id, ref.local_id)
        cached = self._cache.get(key)
        if cached is not None:
            return cached
        self._checks += 1
        if self._checks > self._max_checks:
            raise ModelValidationError("endpoint validation work exceeds bound")
        remaining = self._deadline_monotonic - time.monotonic()
        if remaining <= 0:
            raise ModelValidationError("endpoint validation deadline exceeded")
        locator = self._accepted.get((ref.project_id, ref.snapshot_id))
        if locator is None:
            return False
        rows = self._execute(
            locator,
            "MATCH (n {id:$id}) RETURN n.localId AS localId LIMIT 2",
            freeze_properties({"id": ref.node_id}),
            2,
            remaining,
        )
        exists = len(rows) == 1 and rows[0]["localId"] == ref.local_id
        self._cache[key] = exists
        return exists


class BoundedAcceptedGraphReader(AcceptedGraphReader):
    def __init__(
        self,
        accepted: tuple[ProjectSnapshot, ...],
        execute: AcceptedExecute,
        limits: ProviderRunLimits,
        deadline_monotonic: float,
    ) -> None:
        self._accepted = {
            (snapshot.project.project_id, snapshot.snapshot_id): snapshot.locator
            for snapshot in accepted
        }
        self._execute = execute
        self._limits = limits
        self._deadline_monotonic = deadline_monotonic
        self._queries = 0
        self._rows = 0

    def query(
        self,
        locator: SnapshotLocator,
        cypher: str,
        parameters: FrozenMap,
        row_limit: int,
    ) -> tuple[FrozenMap, ...]:
        expected = self._accepted.get((locator.project_id, locator.snapshot_id))
        if expected != locator:
            raise SnapshotLifecycleError("provider requested an unaccepted snapshot locator")
        if not 1 <= row_limit <= self._limits.max_rows_per_query:
            raise ModelValidationError("provider read row limit exceeds bound")
        self._queries += 1
        if self._queries > self._limits.max_reader_queries:
            raise ModelValidationError("provider read query count exceeds bound")
        remaining = self._deadline_monotonic - time.monotonic()
        if remaining <= 0:
            raise ModelValidationError("provider read deadline exceeded")
        rows = self._execute(locator, cypher, parameters, row_limit, remaining)
        self._rows += len(rows)
        if self._rows > self._limits.max_total_rows:
            raise ModelValidationError("provider read total row count exceeds bound")
        return rows


@dataclass(frozen=True)
class CorrelationRunResult:
    node_refs: tuple[NodeRef, ...]
    correlations: tuple[CorrelationEdge, ...]
    manifests: tuple[ProviderManifest, ...]
    logs: tuple[PluginLogRecord, ...]
    diagnostics: tuple[PluginDiagnostic, ...]


class CorrelationRunner:
    def __init__(self, limits: ProviderRunLimits | None = None) -> None:
        self._limits = limits or ProviderRunLimits()

    @property
    def limits(self) -> ProviderRunLimits:
        return self._limits

    def run(
        self,
        candidate: GraphSnapshot,
        accepted: tuple[ProjectSnapshot, ...],
        registry: CorrelationProviderRegistry,
        *,
        graph_reader: BoundedAcceptedGraphReader,
        endpoint_validator: CorrelationEndpointValidator,
        reporter: BufferedPluginReporter,
        cancellation: CancellationToken,
        deadline_monotonic: float,
        configuration: FrozenMap,
    ) -> CorrelationRunResult:
        accepted_by_identity = {
            (snapshot.project.project_id, snapshot.snapshot_id): snapshot for snapshot in accepted
        }
        candidate_nodes = {node.id: node for node in candidate.nodes}
        correlations: list[CorrelationEdge] = []
        seen: set[tuple[str, str, str, str, str]] = set()
        context_label = (
            f"project={candidate.project.project_id.value},snapshot={candidate.snapshot_id.value}"
        )
        for provider in registry:
            metadata = provider.metadata
            _check_lifecycle(metadata, cancellation, deadline_monotonic, context_label)
            context = CorrelationContext(
                candidate,
                accepted,
                graph_reader,
                reporter,
                configuration,
                cancellation,
                deadline_monotonic,
            )
            try:
                emitted = _require_correlations(provider.correlate(context))
                if len(emitted) > self._limits.max_edges_per_provider:
                    raise ModelValidationError("provider correlation fan-out exceeds bound")
                for edge in emitted:
                    _validate_correlation(
                        edge,
                        metadata,
                        candidate,
                        candidate_nodes,
                        accepted_by_identity,
                        endpoint_validator,
                    )
                    key = (
                        edge.source.node_id,
                        edge.relationship_type.value,
                        edge.target.node_id,
                        edge.provider_name,
                        edge.provider_version,
                    )
                    if key in seen:
                        raise ModelValidationError("provider emitted duplicate correlation")
                    seen.add(key)
                    correlations.append(edge)
                    if len(correlations) > self._limits.max_total_edges:
                        raise ModelValidationError("aggregate correlation fan-out exceeds bound")
                _check_lifecycle(metadata, cancellation, deadline_monotonic, context_label)
            except PluginError as exc:
                if (
                    exc.plugin_name == metadata.name
                    and exc.phase == metadata.phase.value
                    and exc.context == context_label
                ):
                    raise
                raise PluginError(
                    metadata.name,
                    metadata.phase.value,
                    str(exc),
                    context=context_label,
                ) from exc
            except Exception as exc:
                raise PluginError(
                    metadata.name,
                    metadata.phase.value,
                    str(exc),
                    context=context_label,
                ) from exc
        refs = {
            (ref.project_id, ref.snapshot_id, ref.node_id): ref
            for edge in correlations
            for ref in (edge.source, edge.target)
        }
        return CorrelationRunResult(
            tuple(sorted(refs.values(), key=_ref_key)),
            tuple(sorted(correlations, key=_edge_key)),
            registry.manifests(candidate.project.project_id, candidate.snapshot_id),
            reporter.logs,
            reporter.diagnostics,
        )


def _require_correlations(value: object) -> tuple[CorrelationEdge, ...]:
    if not isinstance(value, tuple):
        raise ModelValidationError("provider must return a tuple of correlations")
    values = cast(tuple[object, ...], value)
    if any(not isinstance(edge, CorrelationEdge) for edge in values):
        raise ModelValidationError("provider must return a tuple of correlations")
    return cast(tuple[CorrelationEdge, ...], values)


def _validate_correlation(
    edge: CorrelationEdge,
    metadata: PluginMetadata,
    candidate: GraphSnapshot,
    candidate_nodes: dict[str, GraphNode],
    accepted: dict[tuple[ProjectId, SnapshotId], ProjectSnapshot],
    endpoint_validator: CorrelationEndpointValidator,
) -> None:
    if edge.provider_name != metadata.name or edge.provider_version != metadata.version:
        raise ModelValidationError("correlation ownership does not match provider metadata")
    candidate_identity = (candidate.project.project_id, candidate.snapshot_id)
    endpoints = (edge.source, edge.target)
    candidate_endpoints = [
        endpoint
        for endpoint in endpoints
        if (endpoint.project_id, endpoint.snapshot_id) == candidate_identity
    ]
    if len(candidate_endpoints) != 1:
        raise ModelValidationError("correlation must have exactly one current candidate endpoint")
    candidate_endpoint = candidate_endpoints[0]
    candidate_node = candidate_nodes.get(candidate_endpoint.node_id)
    if candidate_node is None or candidate_node.local_id != candidate_endpoint.local_id:
        raise ModelValidationError("candidate correlation endpoint does not exist")
    target = edge.target if edge.source == candidate_endpoint else edge.source
    target_snapshot = accepted.get((target.project_id, target.snapshot_id))
    if target_snapshot is None:
        raise ModelValidationError("correlation target is not an accepted snapshot")
    if not endpoint_validator.exists(target):
        raise ModelValidationError("accepted correlation endpoint does not exist")


def _check_lifecycle(
    metadata: PluginMetadata,
    cancellation: CancellationToken,
    deadline: float,
    context: str,
) -> None:
    if cancellation.is_cancelled:
        raise PluginError(
            metadata.name, metadata.phase.value, "provider cancelled", context=context
        )
    if time.monotonic() >= deadline:
        raise PluginError(
            metadata.name,
            metadata.phase.value,
            "provider deadline exceeded",
            context=context,
        )


def _ref_key(ref: NodeRef) -> tuple[str, str, str]:
    return (ref.project_id.value, ref.snapshot_id.value, ref.node_id)


def _edge_key(edge: CorrelationEdge) -> tuple[str, str, str, str, str]:
    return (
        edge.source.node_id,
        edge.relationship_type.value,
        edge.target.node_id,
        edge.provider_name,
        edge.provider_version,
    )
