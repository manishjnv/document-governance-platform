# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""package.json and pnpm workspace parsing."""

from __future__ import annotations

from context_graph_sdk.project.config import (
    DependencyRecord,
    ManifestReader,
    ManifestRecord,
    ProjectConfig,
    workspace_display_name,
)

from ._data import as_mapping, as_str, parse_json_object, string_items, string_list

_SCOPED_SECTIONS = (
    ("dependencies", False, ""),
    ("devDependencies", True, "dev"),
    ("peerDependencies", True, "peer"),
    ("optionalDependencies", True, "optional"),
)


def _is_non_npm_package(package: dict[str, object]) -> bool:
    """VS Code extensions and Unity packages reuse the package.json name."""
    engines = as_mapping(package.get("engines")) or {}
    if "vscode" in engines:
        return True
    if package.get("contributes") is not None:
        return True
    return bool(package.get("unity"))


def load_package_json_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("package.json"):
        text = reader.read_text(relative)
        package = parse_json_object(text) if text is not None else None
        if package is None or _is_non_npm_package(package):
            continue
        for section, dev, scope in _SCOPED_SECTIONS:
            for name, version in string_items(package.get(section)):
                config.add_dependency(DependencyRecord(name, version, relative, dev, scope))


def _workspace_entries(value: object) -> tuple[str, ...]:
    mapping = as_mapping(value)
    if mapping is not None:
        value = mapping.get("packages")
    return string_list(value)


def load_package_json_manifests(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("package.json"):
        text = reader.read_text(relative)
        package = parse_json_object(text) if text is not None else None
        if package is None or _is_non_npm_package(package):
            continue
        workspaces = _workspace_entries(package.get("workspaces"))
        manifest_name = as_str(package.get("name"))
        if not manifest_name and workspaces:
            manifest_name = workspace_display_name(reader.root, relative)
        config.add_manifest(
            ManifestRecord(
                manifest_name,
                relative,
                "javascript",
                as_str(package.get("version")),
                workspaces,
            )
        )


def parse_simple_yaml_string_list(text: str, key: str) -> tuple[str, ...]:
    values: list[str] = []
    in_list = False
    for raw in text.split("\n"):
        line = _strip_inline_comment(raw.rstrip("\r"))
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if not line.startswith(" ") and stripped.endswith(":"):
            in_list = stripped[:-1] == key
            continue
        if not in_list or not stripped.startswith("-"):
            continue
        value = stripped[1:].strip().strip("\"'")
        if value:
            values.append(value)
    return tuple(values)


def _strip_inline_comment(line: str) -> str:
    in_single = False
    in_double = False
    escaped = False
    for index, char in enumerate(line):
        if escaped:
            escaped = False
            continue
        if char == "\\":
            escaped = True
            continue
        if char == "'" and not in_double:
            in_single = not in_single
        elif char == '"' and not in_single:
            in_double = not in_double
        elif char == "#" and not in_single and not in_double:
            return line[:index].rstrip(" \t")
    return line


def load_pnpm_workspace_manifests(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("pnpm-workspace.yaml"):
        text = reader.read_text(relative)
        if text is None:
            continue
        config.add_manifest(
            ManifestRecord(
                workspace_display_name(reader.root, relative),
                relative,
                "javascript",
                "",
                parse_simple_yaml_string_list(text, "packages"),
            )
        )
