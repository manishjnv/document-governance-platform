# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Tree-sitter runtime: pinned grammars, shared immutable objects, workers.

`Language`, compiled `Query`, and parsed `Tree` objects are immutable and
shareable across threads; `Parser` and `QueryCursor` instances are per-worker.
The binding's `progress_callback` is not used because native crashes have been
observed on non-trivial input; per-file bounds come from wall-clock supervision
plus match and size limits.
"""

from __future__ import annotations

import importlib
import importlib.metadata
import importlib.resources
import io
import os
import pickle
import queue
import subprocess
import time
import warnings
from collections.abc import Callable, Sequence
from contextlib import suppress
from dataclasses import dataclass
from functools import cache
from typing import cast

from tree_sitter import Language, Node, Parser, Query, QueryCursor, Tree

from context_graph_sdk._process import StdioChannel, spawn_stdio_worker
from context_graph_sdk.errors import ModelValidationError
from context_graph_sdk.extractors import records

DEFAULT_FILE_TIMEOUT_SECONDS = 30.0
DEFAULT_MAX_WORKERS = 8
MAX_EXTRACTION_PROCESSES = 32
MAX_QUERY_MATCHES_PER_FILE = 200_000
MAX_SOURCE_BYTES = 10 * 1024 * 1024
MAX_EXTRACTION_REQUEST_BYTES = 64 * 1024
MAX_EXTRACTION_RESULT_BYTES = 64 * 1024 * 1024
MAX_AGGREGATE_TIMEOUT_SECONDS = 24 * 60 * 60.0

_ALLOWED_EXTRACTION_TYPES = {
    cls.__name__: cls
    for cls in (
        records.Assignment,
        records.Call,
        records.Delegate,
        records.FileExtraction,
        records.Heritage,
        records.Import,
        records.ImportBinding,
        records.Spawn,
        records.Symbol,
        records.TypeBinding,
    )
}


class _ExtractionUnpickler(pickle.Unpickler):
    """Deserialize only the immutable record graph emitted by our worker."""

    def find_class(self, module: str, name: str) -> object:
        if module == records.__name__ and name in _ALLOWED_EXTRACTION_TYPES:
            return _ALLOWED_EXTRACTION_TYPES[name]
        raise pickle.UnpicklingError(f"unsupported extraction result type: {module}.{name}")


def _load_worker_message(payload: bytes) -> object:
    try:
        return _ExtractionUnpickler(io.BytesIO(payload)).load()
    except pickle.PickleError:
        raise
    except Exception as error:
        raise pickle.UnpicklingError("invalid extraction result payload") from error


@dataclass(frozen=True)
class LanguageRuntimeSpec:
    name: str
    distribution: str
    module: str
    entry: str
    query_asset: str
    entry_arguments: tuple[str, ...] = ()


# TSX is a distinct grammar configuration that shares the TypeScript query asset.
SUPPORTED_LANGUAGES: dict[str, LanguageRuntimeSpec] = {
    spec.name: spec
    for spec in (
        LanguageRuntimeSpec("go", "tree-sitter-go", "tree_sitter_go", "language", "go.scm"),
        LanguageRuntimeSpec(
            "python", "tree-sitter-python", "tree_sitter_python", "language", "python.scm"
        ),
        LanguageRuntimeSpec(
            "javascript",
            "tree-sitter-javascript",
            "tree_sitter_javascript",
            "language",
            "javascript.scm",
        ),
        LanguageRuntimeSpec(
            "typescript",
            "tree-sitter-typescript",
            "tree_sitter_typescript",
            "language_typescript",
            "typescript.scm",
        ),
        LanguageRuntimeSpec(
            "tsx",
            "tree-sitter-typescript",
            "tree_sitter_typescript",
            "language_tsx",
            "typescript.scm",
        ),
        LanguageRuntimeSpec("java", "tree-sitter-java", "tree_sitter_java", "language", "java.scm"),
        # Standalone tree-sitter-kotlin 1.x uses incompatible node kinds; the
        # language pack bundles the grammar expected by these queries.
        LanguageRuntimeSpec(
            "kotlin",
            "tree-sitter-language-pack",
            "tree_sitter_language_pack",
            "get_language",
            "kotlin.scm",
            ("kotlin",),
        ),
        LanguageRuntimeSpec(
            "csharp", "tree-sitter-c-sharp", "tree_sitter_c_sharp", "language", "csharp.scm"
        ),
        LanguageRuntimeSpec(
            "scala", "tree-sitter-scala", "tree_sitter_scala", "language", "scala.scm"
        ),
        LanguageRuntimeSpec("c", "tree-sitter-c", "tree_sitter_c", "language", "c.scm"),
        LanguageRuntimeSpec("cpp", "tree-sitter-cpp", "tree_sitter_cpp", "language", "cpp.scm"),
        LanguageRuntimeSpec("rust", "tree-sitter-rust", "tree_sitter_rust", "language", "rust.scm"),
        LanguageRuntimeSpec("ruby", "tree-sitter-ruby", "tree_sitter_ruby", "language", "ruby.scm"),
        LanguageRuntimeSpec("php", "tree-sitter-php", "tree_sitter_php", "language_php", "php.scm"),
        LanguageRuntimeSpec(
            "swift", "tree-sitter-swift", "tree_sitter_swift", "language", "swift.scm"
        ),
        LanguageRuntimeSpec("dart", "tree-sitter-dart", "tree_sitter_dart", "language", "dart.scm"),
        # tree-sitter-solidity returns a raw pointer instead of a PyCapsule;
        # Language() accepts the pointer behind a deprecation warning at this pin.
        LanguageRuntimeSpec(
            "solidity", "tree-sitter-solidity", "tree_sitter_solidity", "language", "solidity.scm"
        ),
    )
}


def is_supported_language(name: str) -> bool:
    return name in SUPPORTED_LANGUAGES


@cache
def load_language(name: str) -> Language:
    spec = SUPPORTED_LANGUAGES[name]
    module = importlib.import_module(spec.module)
    obtained: object = getattr(module, spec.entry)(*spec.entry_arguments)
    if isinstance(obtained, Language):
        # tree-sitter-language-pack returns an already-wrapped Language.
        return obtained
    if isinstance(obtained, int):
        # tree-sitter-solidity's raw-pointer bridge; deliberate at this pin.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            return Language(obtained)  # pyright: ignore[reportDeprecated]
    return Language(obtained)  # pyright: ignore[reportDeprecated]


@cache
def query_text(name: str) -> str:
    asset = SUPPORTED_LANGUAGES[name].query_asset
    resource = importlib.resources.files("context_graph_sdk.extractors") / "queries" / asset
    return resource.read_text(encoding="utf-8")


@cache
def load_query(name: str) -> Query:
    return Query(load_language(name), query_text(name))


def analysis_components() -> tuple[tuple[str, str], ...]:
    """Pinned parser/grammar versions for the analysis fingerprint."""
    distributions = sorted(
        {spec.distribution for spec in SUPPORTED_LANGUAGES.values()} | {"tree-sitter"}
    )
    return tuple(
        (distribution, importlib.metadata.version(distribution)) for distribution in distributions
    )


QueryMatches = list[tuple[int, dict[str, list[Node]]]]


def parse_and_match(name: str, source: bytes) -> tuple[Tree, QueryMatches]:
    """Parse one file and run its complete query with per-worker state."""
    if len(source) > MAX_SOURCE_BYTES:
        raise ModelValidationError("source exceeds the extraction size bound")
    tree = Parser(load_language(name)).parse(source)
    cursor = QueryCursor(load_query(name))
    matches = cursor.matches(tree.root_node)
    if len(matches) > MAX_QUERY_MATCHES_PER_FILE:
        raise ModelValidationError(
            f"query match count exceeds {MAX_QUERY_MATCHES_PER_FILE} per-file bound"
        )
    return tree, matches


@dataclass(frozen=True)
class WorkItem:
    relative_path: str
    language: str


@dataclass
class _ActiveWorker:
    process: subprocess.Popen[bytes]
    channel: StdioChannel
    index: int | None = None
    started_at: float = 0.0


def run_bounded(
    root: str,
    items: Sequence[WorkItem],
    *,
    max_workers: int = DEFAULT_MAX_WORKERS,
    file_timeout_seconds: float = DEFAULT_FILE_TIMEOUT_SECONDS,
    aggregate_timeout_seconds: float | None = None,
    max_result_bytes: int = MAX_EXTRACTION_RESULT_BYTES,
    worker_module: str = "context_graph_sdk.extractors.worker_entry",
    on_progress: Callable[[int, int], None] | None = None,
) -> tuple[list[tuple[WorkItem, object]], list[tuple[WorkItem, str]]]:
    """Extract files in a bounded pool of reusable, killable subprocesses."""
    if not 1 <= max_workers <= MAX_EXTRACTION_PROCESSES:
        raise ModelValidationError(f"max_workers must be in [1, {MAX_EXTRACTION_PROCESSES}]")
    if not 0 < file_timeout_seconds <= 3_600:
        raise ModelValidationError("file_timeout_seconds must be in (0, 3600]")
    if not 1 <= max_result_bytes <= MAX_EXTRACTION_RESULT_BYTES:
        raise ModelValidationError(
            f"max_result_bytes must be in [1, {MAX_EXTRACTION_RESULT_BYTES}]"
        )
    if not worker_module:
        raise ModelValidationError("worker_module is required")
    if aggregate_timeout_seconds is None:
        aggregate_timeout_seconds = min(
            MAX_AGGREGATE_TIMEOUT_SECONDS,
            file_timeout_seconds * max(1, (len(items) + max_workers - 1) // max_workers) + 5.0,
        )
    if not 0 < aggregate_timeout_seconds <= MAX_AGGREGATE_TIMEOUT_SECONDS:
        raise ModelValidationError(
            f"aggregate_timeout_seconds must be in (0, {MAX_AGGREGATE_TIMEOUT_SECONDS}]"
        )
    if not items:
        _report_progress(on_progress, 0, 0)
        return [], []

    worker_limit = min(max_workers, os.cpu_count() or 1, len(items))
    ready: queue.Queue[StdioChannel] = queue.Queue()
    workers: dict[StdioChannel, _ActiveWorker] = {}
    outcomes: dict[int, tuple[bool, object]] = {}
    next_index = 0
    aggregate_deadline = time.monotonic() + aggregate_timeout_seconds
    progress_interval = max(1, (len(items) + 199) // 200)
    last_progress = 0

    def report_progress(*, force: bool = False) -> None:
        nonlocal last_progress
        completed = len(outcomes)
        if force or completed == len(items) or completed - last_progress >= progress_interval:
            _report_progress(on_progress, completed, len(items))
            last_progress = completed

    report_progress(force=True)

    def stop(worker: _ActiveWorker, *, graceful: bool) -> None:
        workers.pop(worker.channel, None)
        if graceful and worker.process.poll() is None:
            with suppress(OSError):
                worker.channel.send_bytes(b"")
            with suppress(subprocess.TimeoutExpired):
                worker.process.wait(1.0)
        if worker.process.poll() is None:
            worker.process.terminate()
            try:
                worker.process.wait(1.0)
            except subprocess.TimeoutExpired:
                worker.process.kill()
                try:
                    worker.process.wait(1.0)
                except subprocess.TimeoutExpired as error:
                    raise ModelValidationError(
                        "extraction worker could not be terminated"
                    ) from error
        worker.channel.close()

    def spawn() -> _ActiveWorker:
        process, channel = spawn_stdio_worker(
            worker_module,
            root,
            str(MAX_EXTRACTION_REQUEST_BYTES),
            str(max_result_bytes),
            maximum_response_bytes=max_result_bytes,
            on_response=ready.put,
        )
        worker = _ActiveWorker(process, channel)
        workers[channel] = worker
        return worker

    def dispatch(worker: _ActiveWorker, index: int) -> None:
        item = items[index]
        payload = pickle.dumps(
            (index, item.relative_path, item.language), protocol=pickle.HIGHEST_PROTOCOL
        )
        if len(payload) > MAX_EXTRACTION_REQUEST_BYTES:
            raise ModelValidationError("extraction request exceeds IPC bound")
        worker.channel.send_bytes(payload)
        worker.index = index
        worker.started_at = time.monotonic()

    def replace_if_needed() -> None:
        nonlocal next_index
        if next_index >= len(items):
            return
        worker = spawn()
        dispatch(worker, next_index)
        next_index += 1

    for _ in range(worker_limit):
        replace_if_needed()

    completed_normally = False
    primary_failure: BaseException | None = None
    try:
        while len(outcomes) < len(items):
            now = time.monotonic()
            if now >= aggregate_deadline:
                for worker in list(workers.values()):
                    if worker.index is not None:
                        outcomes[worker.index] = (
                            False,
                            "extraction exceeded the aggregate time bound",
                        )
                    stop(worker, graceful=False)
                for index in range(next_index, len(items)):
                    outcomes[index] = (False, "extraction exceeded the aggregate time bound")
                report_progress(force=True)
                break

            busy = [worker for worker in workers.values() if worker.index is not None]
            if not busy:
                raise ModelValidationError("extraction worker pool stopped before completion")
            nearest_deadline = min(
                aggregate_deadline,
                *(worker.started_at + file_timeout_seconds for worker in busy),
            )
            try:
                channel = ready.get(timeout=max(0.0, nearest_deadline - now))
            except queue.Empty:
                channel = None
            worker = workers.get(channel) if channel is not None else None
            if worker is not None and worker.index is not None:
                index = worker.index
                try:
                    payload = worker.channel.recv_bytes(max_result_bytes)
                    decoded = _load_worker_message(payload)
                    if not isinstance(decoded, tuple):
                        raise ValueError("invalid result shape")
                    message = cast(tuple[object, ...], decoded)
                    if len(message) != 3 or message[0] != index or not isinstance(message[1], bool):
                        raise ValueError("invalid result shape")
                except EOFError:
                    with suppress(subprocess.TimeoutExpired):
                        worker.process.wait(0.2)
                    exit_code = worker.process.returncode
                    reason = (
                        f"extraction worker exited with code {exit_code}"
                        if exit_code is not None
                        else "extraction worker closed its response stream without exiting"
                    )
                    outcomes[index] = (False, reason)
                    report_progress()
                    stop(worker, graceful=False)
                    replace_if_needed()
                except (OSError, ValueError, pickle.PickleError) as error:
                    outcomes[index] = (False, f"extraction worker protocol failure: {error}")
                    report_progress()
                    stop(worker, graceful=False)
                    replace_if_needed()
                else:
                    outcomes[index] = (message[1], message[2])
                    report_progress()
                    worker.index = None
                    if next_index < len(items):
                        dispatch(worker, next_index)
                        next_index += 1

            now = time.monotonic()
            for worker in list(workers.values()):
                if worker.index is None or now < worker.started_at + file_timeout_seconds:
                    continue
                outcomes[worker.index] = (False, "extraction exceeded the per-file time bound")
                report_progress()
                stop(worker, graceful=False)
                replace_if_needed()
        completed_normally = True
    except BaseException as error:
        primary_failure = error
        raise
    finally:
        cleanup_failure: Exception | None = None
        for worker in list(workers.values()):
            try:
                stop(worker, graceful=completed_normally)
            except Exception as error:
                cleanup_failure = cleanup_failure or error
        if cleanup_failure is not None and primary_failure is None:
            raise cleanup_failure

    successes: list[tuple[WorkItem, object]] = []
    failures: list[tuple[WorkItem, str]] = []
    for index, item in enumerate(items):
        ok, value = outcomes[index]
        if ok:
            successes.append((item, value))
        else:
            failures.append((item, str(value)))
    return successes, failures


def _report_progress(
    callback: Callable[[int, int], None] | None, completed: int, total: int
) -> None:
    if callback is None:
        return
    # Progress is observational and must never change analysis correctness.
    with suppress(Exception):
        callback(completed, total)
