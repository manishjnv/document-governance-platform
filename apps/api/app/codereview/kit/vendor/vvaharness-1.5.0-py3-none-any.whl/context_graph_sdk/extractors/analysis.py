# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Grammar-agnostic AST analysis helpers."""

from __future__ import annotations

import re
from collections.abc import Callable

from tree_sitter import Node

CLASS_NODE_TYPES = frozenset(
    {
        "class_definition",
        "class_declaration",
        "class",
        "class_specifier",
        "struct_definition",
        "struct_declaration",
        "struct_item",
        "struct_specifier",
        "trait_definition",
        "trait_item",
        "impl_item",
        "interface_declaration",
        "object_declaration",
        "enum_declaration",
        "mixin_declaration",
        "protocol_declaration",
        "extension_declaration",
        "companion_object",
        "record_declaration",
        "type_alias",
        "contract_declaration",
        "library_declaration",
    }
)

COMMENT_NODE_TYPES = frozenset(
    {
        "comment",
        "line_comment",
        "block_comment",
        "multiline_comment",
        "documentation_comment",
        "documentation_block_comment",
    }
)

DECORATOR_NODE_TYPES = frozenset({"decorator", "decorated_definition", "attribute", "annotation"})

ANNOTATION_CONTAINER_TYPES = frozenset(
    {
        "decorator",
        "decorated_definition",
        "attribute",
        "attribute_item",
        "annotation",
        "marker_annotation",
        "modifiers",
    }
)

ANNOTATION_NAME_TYPES = frozenset(
    {
        "type_identifier",
        "identifier",
        "constant",
        "scoped_identifier",
        "field_identifier",
        "property_identifier",
        "name",
    }
)

_KEYWORDS = frozenset(
    {
        "extends",
        "implements",
        "with",
        "class",
        "struct",
        "interface",
        "trait",
        "mixin",
        "super",
        "public",
        "private",
        "protected",
        "open",
        "abstract",
        "final",
        "override",
        "virtual",
    }
)

_XML_TAG = re.compile(r"<[^>]+>")


def node_text(node: Node | None, source: bytes) -> str:
    if node is None:
        return ""
    start, end = node.start_byte, node.end_byte
    if start >= len(source):
        return ""
    return source[start : min(end, len(source))].decode("utf-8", errors="replace")


def walk(root: Node, visit: Callable[[Node, int], str | None]) -> None:
    """Pre-order walk; visit returns "skip" to prune or "stop" to abort."""
    stack: list[tuple[Node, int]] = [(root, 0)]
    while stack:
        node, depth = stack.pop()
        action = visit(node, depth)
        if action == "stop":
            return
        if action == "skip":
            continue
        stack.extend((child, depth + 1) for child in reversed(node.children))


def has_ancestor_type(node: Node, ancestor_type: str, max_depth: int = 20) -> bool:
    current = node.parent
    for _ in range(max_depth):
        if current is None:
            return False
        if current.type == ancestor_type:
            return True
        current = current.parent
    return False


def find_declaration_ancestor(node: Node) -> Node:
    current: Node | None = node
    for _ in range(10):
        if current is None:
            break
        node_type = current.type.lower()
        if (
            "declaration" in node_type
            or "definition" in node_type
            or "_item" in node_type
            or node_type.endswith("_statement")
        ):
            return current
        current = current.parent
    return node


def has_visibility_modifier(node: Node, source: bytes, *keywords: str) -> bool:
    declaration = find_declaration_ancestor(node)
    for child in declaration.children:
        child_type = child.type.lower()
        if "modifier" in child_type or "visibility" in child_type:
            text = node_text(child, source).lower()
            if text and any(keyword in text for keyword in keywords):
                return True
    return False


def has_sibling_modifier(node: Node, source: bytes, keyword: str) -> bool:
    declaration = find_declaration_ancestor(node)
    for child in declaration.children:
        if child.type in ("modifiers", "modifier") and keyword in node_text(child, source):
            return True
    return False


def has_sibling_node_type(node: Node, node_type: str) -> bool:
    declaration = find_declaration_ancestor(node)
    return any(child.type == node_type for child in declaration.children)


def has_sibling_modifier_text(node: Node, source: bytes, node_type: str, text: str) -> bool:
    declaration = find_declaration_ancestor(node)
    return any(
        child.type == node_type and node_text(child, source) == text
        for child in declaration.children
    )


def _access_modifier_is_bare(node: Node) -> bool:
    return all(child.type.lower() != "access_qualifier" for child in node.children)


def has_scala_bare_visibility(node: Node, source: bytes) -> bool:
    """Treat scoped Scala private/protected access as exported."""
    declaration = find_declaration_ancestor(node)
    for child in declaration.children:
        child_type = child.type.lower()
        if child_type == "access_modifier":
            if _access_modifier_is_bare(child):
                return True
            continue
        if "modifier" not in child_type and "visibility" not in child_type:
            continue
        for modifier in child.children:
            modifier_type = modifier.type.lower()
            if modifier_type == "access_modifier":
                if _access_modifier_is_bare(modifier):
                    return True
                continue
            if node_text(modifier, source).lower() in ("private", "protected"):
                return True
        if node_text(child, source).strip().lower() in ("private", "protected"):
            return True
    return False


def first_identifier_text(node: Node, source: bytes) -> str:
    for child in node.children:
        if child.type.lower() in (
            "identifier",
            "simple_identifier",
            "field_identifier",
            "variable_name",
            "name",
        ):
            text = node_text(child, source)
            if text:
                return text
    return ""


def extract_class_name(node: Node, source: bytes) -> str:
    name_node = node.child_by_field_name("name")
    if name_node is not None:
        return node_text(name_node, source)
    if node.type.lower() == "impl_item":
        type_node = node.child_by_field_name("type")
        if type_node is not None:
            return node_text(type_node, source)
    for child in node.children:
        if child.type.lower() in ("type_identifier", "identifier", "constant"):
            return node_text(child, source)
    return ""


def find_enclosing_class_name(node: Node, source: bytes) -> str:
    current = node.parent
    for _ in range(20):
        if current is None:
            return ""
        if current.type.lower() in CLASS_NODE_TYPES:
            return extract_class_name(current, source)
        current = current.parent
    return ""


def extract_receiver_type(def_node: Node, source: bytes) -> str:
    receiver = def_node.child_by_field_name("receiver")
    if receiver is None:
        return ""
    result = ""

    def visit(node: Node, _depth: int) -> str | None:
        nonlocal result
        if result:
            return "stop"
        if node.type.lower() == "type_identifier":
            result = node_text(node, source)
            return "stop"
        return None

    walk(receiver, visit)
    return result


_BODY_FIELDS = ("body", "block", "function_body", "compound_statement")
_BODY_TYPES = frozenset({"block", "body", "statement_block", "compound_statement", "function_body"})


def extract_signature(def_node: Node, source: bytes) -> str:
    start = def_node.start_byte
    body: Node | None = None
    for field in _BODY_FIELDS:
        body = def_node.child_by_field_name(field)
        if body is not None:
            break
    if body is None:
        for child in def_node.children:
            if child.type.lower() in _BODY_TYPES:
                body = child
                break
    if body is not None:
        end = body.start_byte
    else:
        end = def_node.end_byte
        text = source[start : min(end, len(source))].decode("utf-8", errors="replace")
        newline = text.find("\n")
        if newline >= 0:
            end = start + len(text[:newline].encode())
    if start >= end or end > len(source):
        return ""
    signature = source[start:end].decode("utf-8", errors="replace").strip()
    signature = signature.rstrip(" \t{:")
    return signature[:500]


def extract_method_signature(def_node: Node, source: bytes) -> tuple[int, str]:
    parameter_count = 0
    params = def_node.child_by_field_name("parameters") or def_node.child_by_field_name(
        "formal_parameters"
    )
    if params is None:
        for child in def_node.children:
            child_type = child.type.lower()
            if ("parameter" in child_type and "list" in child_type) or child_type in (
                "formal_parameters",
                "parameter_list",
                "function_parameters",
            ):
                params = child
                break
    if params is not None:
        parameter_count = sum(1 for child in params.children if child.is_named)
    return_node = (
        def_node.child_by_field_name("return_type")
        or def_node.child_by_field_name("result")
        or def_node.child_by_field_name("type")
    )
    return_type = node_text(return_node, source).strip()[:80] if return_node else ""
    return parameter_count, return_type


def extract_doc_comment(def_node: Node, source: bytes, language: str) -> str:
    if language == "python":
        docstring = _python_docstring(def_node, source)
        if docstring:
            return docstring
    lines: list[str] = []
    sibling = def_node.prev_sibling
    while sibling is not None:
        node_type = sibling.type.lower()
        if node_type in DECORATOR_NODE_TYPES:
            sibling = sibling.prev_sibling
            continue
        if node_type not in COMMENT_NODE_TYPES:
            break
        text = node_text(sibling, source)
        if text.strip().startswith("//!"):
            break
        lines.append(text)
        sibling = sibling.prev_sibling
    if not lines:
        return ""
    lines.reverse()
    return clean_doc_comment("\n".join(lines))


def _python_docstring(def_node: Node, source: bytes) -> str:
    body = def_node.child_by_field_name("body")
    if body is None or body.named_child_count == 0:
        return ""
    first = body.named_child(0)
    if first is None:
        return ""
    first_type = first.type.lower()
    if first_type == "expression_statement" and first.named_child_count > 0:
        string_node = first.named_child(0)
        if string_node is not None and string_node.type.lower() in (
            "string",
            "concatenated_string",
        ):
            return clean_docstring(node_text(string_node, source))
    if first_type in ("string", "concatenated_string"):
        return clean_docstring(node_text(first, source))
    return ""


def clean_doc_comment(raw: str) -> str:
    cleaned: list[str] = []
    for line in raw.split("\n"):
        line = line.strip()
        line = line.removeprefix("/*").removesuffix("*/")
        line = line.removeprefix("///").removeprefix("//!").removeprefix("//")
        line = line.removeprefix("#").removeprefix("*")
        line = line.strip()
        if line:
            cleaned.append(line)
    result = _XML_TAG.sub("", " ".join(cleaned))
    return result[:1000].strip()


def clean_docstring(raw: str) -> str:
    text = raw.strip()
    for quote in ('"""', "'''"):
        text = text.removeprefix(quote).removesuffix(quote)
    text = text.strip("\"'")
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    return " ".join(lines)[:1000].strip()


def is_keyword(text: str) -> bool:
    return text.lower() in _KEYWORDS


def extract_annotations(def_node: Node, source: bytes) -> str:
    """Return direct annotations plus preceding siblings in source order."""
    names: list[str] = []
    seen: set[str] = set()

    def add(name: str) -> None:
        if name and name not in seen:
            seen.add(name)
            names.append(name)

    for name in _collect_direct_annotation_names(def_node, source):
        add(name)
    sibling = def_node.prev_sibling
    while sibling is not None:
        node_type = sibling.type.lower()
        if node_type in COMMENT_NODE_TYPES:
            sibling = sibling.prev_sibling
            continue
        if node_type not in ANNOTATION_CONTAINER_TYPES:
            break
        for name in _collect_annotation_names(sibling, source):
            add(name)
        sibling = sibling.prev_sibling
    names.reverse()
    return ",".join(names)


def _collect_direct_annotation_names(node: Node, source: bytes) -> list[str]:
    names: list[str] = []
    seen: set[str] = set()

    def collect_from(current: Node) -> None:
        current_type = current.type.lower()
        if current_type in ANNOTATION_CONTAINER_TYPES:
            for name in _collect_annotation_names(current, source):
                if name and name not in seen:
                    seen.add(name)
                    names.append(name)
        for child in current.children:
            if child.is_named and child.type.lower() in ANNOTATION_CONTAINER_TYPES:
                collect_from(child)

    collect_from(node)
    return names


def _collect_annotation_names(node: Node, source: bytes) -> list[str]:
    # Core languages use explicit annotation carriers; C++ modifier keywords
    # are supplemented separately.
    carrier = _annotation_carrier_name(node, source)
    return [carrier] if carrier else []


def _annotation_carrier_name(node: Node, source: bytes) -> str:
    node_type = node.type.lower()
    if node_type == "decorator":
        for child in node.children:
            if child.is_named:
                name = _decorator_target_name(child, source)
                if name:
                    return name
    if node_type in ("annotation", "marker_annotation"):
        name_node = node.child_by_field_name("name")
        if name_node is not None:
            return _annotation_name(name_node, source)
        for child in node.children:
            if child.is_named:
                name = _annotation_name(child, source)
                if name:
                    return name
    if node_type in ("attribute_item", "attribute"):
        for child in node.children:
            if child.is_named:
                name = _annotation_carrier_name(child, source) or _annotation_name(child, source)
                if name:
                    return name
    return ""


def _decorator_target_name(node: Node, source: bytes) -> str:
    node_type = node.type.lower()
    if node_type in ANNOTATION_NAME_TYPES:
        return _annotation_name(node, source)
    if node_type in ("call", "call_expression"):
        function = node.child_by_field_name("function")
        if function is not None:
            return _decorator_target_name(function, source)
    if node_type in ("attribute", "member_expression", "field_expression"):
        for field in ("attribute", "field", "property"):
            field_node = node.child_by_field_name(field)
            if field_node is not None:
                name = _annotation_name(field_node, source)
                if name:
                    return name
    for child in node.children:
        if child.is_named:
            name = _decorator_target_name(child, source)
            if name:
                return name
    return ""


def _annotation_name(node: Node, source: bytes) -> str:
    if node.type.lower() not in ANNOTATION_NAME_TYPES:
        return ""
    text = node_text(node, source).strip()
    if not text:
        return ""
    text = text.lstrip("@#[]")
    separator = max(text.rfind("."), text.rfind(":"), text.rfind("\\"), text.rfind("/"))
    if 0 <= separator < len(text) - 1:
        text = text[separator + 1 :]
    for opener in "([{":
        index = text.find(opener)
        if index >= 0:
            text = text[:index]
    text = text.strip("`'\"]").strip()
    if not text or is_keyword(text):
        return ""
    return text
