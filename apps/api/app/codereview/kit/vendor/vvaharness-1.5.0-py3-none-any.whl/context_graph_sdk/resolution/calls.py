# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Tiered call, spawn, and delegate resolution."""

from __future__ import annotations

import posixpath
from dataclasses import dataclass

from context_graph_sdk.extractors.records import CALLABLE_LABELS, Symbol
from context_graph_sdk.models import LocalRelationshipType
from context_graph_sdk.resolution.context import ResolutionContext, ResolutionResult, file_local_id

CALL_CONFIDENCE = 0.8
SPAWN_CONFIDENCE = 0.9
DELEGATE_CONFIDENCE = 0.7
CALL_REASON = "tree-sitter call extraction"

BUILT_IN_NAMES = frozenset(
    {
        # JS/TS built-ins and common methods
        "log", "warn", "error", "info", "debug",
        "setTimeout", "setInterval", "clearTimeout", "clearInterval",
        "parseInt", "parseFloat", "isNaN", "isFinite", "parse", "stringify",
        "resolve", "reject", "then", "catch", "finally", "require",
        "map", "filter", "reduce", "forEach", "find", "findIndex", "some",
        "every", "includes", "indexOf", "slice", "splice", "concat", "join",
        "split", "push", "pop", "shift", "unshift", "sort", "reverse",
        "keys", "values", "entries", "assign", "freeze", "hasOwnProperty",
        "toString",
        # React hooks
        "useState", "useEffect", "useCallback", "useMemo", "useRef",
        "useContext", "useReducer", "createElement", "createContext",
        "forwardRef", "memo",
        # Python built-ins
        "print", "len", "range", "str", "int", "float", "list", "dict",
        "set", "tuple", "open", "read", "write", "close", "append",
        "extend", "update", "super", "type", "isinstance", "issubclass",
        "getattr", "setattr", "hasattr", "enumerate", "zip", "sorted",
        "reversed", "min", "max", "sum", "abs",
        # C/C++ standard library
        "printf", "fprintf", "sprintf", "snprintf", "scanf", "fscanf",
        "sscanf", "malloc", "calloc", "realloc", "free", "memcpy",
        "memmove", "memset", "memcmp", "strlen", "strcpy", "strncpy",
        "strcat", "strcmp", "sizeof", "assert", "abort", "exit", "fopen",
        "fclose", "fread", "fwrite",
        # Go built-ins
        "make", "new", "panic", "recover", "copy", "delete",
        # Ruby built-ins and visibility/mixin pseudo-calls
        "puts", "p", "pp", "raise", "fail", "lambda", "proc", "each",
        "select", "detect", "collect", "inject", "flat_map", "any?",
        "all?", "none?", "count", "first", "last", "sort_by", "group_by",
        "partition", "compact", "flatten", "uniq", "attr_accessor",
        "attr_reader", "attr_writer", "public", "private", "protected",
        "include", "prepend", "require_relative",
        # Linux kernel common macros/helpers
        "likely", "unlikely", "printk", "kfree", "kmalloc", "kzalloc",
    }
)  # fmt: skip


@dataclass(frozen=True)
class CallSite:
    caller_local_id: str
    callee_name: str
    caller_file_path: str
    original_name: str = ""
    receiver_name: str = ""
    receiver_type: str = ""


def resolve_call_tiered(
    context: ResolutionContext,
    imported_files: dict[str, set[str]],
    site: CallSite,
) -> tuple[Symbol | None, int]:
    """Resolve by same file, import, directory, and receiver-type evidence."""
    candidates = list(context.symbols_by_name.get(site.callee_name, []))
    if site.original_name and site.original_name != site.callee_name:
        candidates.extend(context.symbols_by_name.get(site.original_name, []))
    if not candidates:
        return None, 0

    imports = imported_files.get(file_local_id(site.caller_file_path), set())
    caller_dir = posixpath.dirname(site.caller_file_path)

    best: Symbol | None = None
    best_score = -1
    for candidate in candidates:
        score = 0
        if candidate.label in CALLABLE_LABELS:
            score += 10
        owner = candidate.owner_name
        if site.caller_file_path and candidate.file_path == site.caller_file_path:
            if not site.receiver_name or not owner or len(site.receiver_name) <= 2:
                score += 100
            else:
                receiver = site.receiver_name.lower()
                owner_lower = owner.lower()
                if receiver == owner_lower or owner_lower.startswith(receiver):
                    score += 100
        if site.caller_file_path:
            if candidate.file_path in imports:
                score += 50
            else:
                candidate_dir = posixpath.dirname(candidate.file_path)
                if candidate_dir and any(
                    posixpath.dirname(path) == candidate_dir for path in imports
                ):
                    # Go package import points at one file; package symbols in
                    # sibling files score just below a direct import.
                    score += 45
            if (
                candidate.file_path
                and candidate.file_path != site.caller_file_path
                and caller_dir
                and posixpath.dirname(candidate.file_path) == caller_dir
            ):
                score += 40
        if site.receiver_type and owner and owner == site.receiver_type:
            score += 200
        if score > best_score or (
            score == best_score and best is not None and candidate.id < best.id
        ):
            best = candidate
            best_score = score
    return best, best_score


def _build_imported_files(
    result: ResolutionResult, context: ResolutionContext
) -> dict[str, set[str]]:
    imported: dict[str, set[str]] = {}
    for edge in result.edges:
        if edge.relationship is not LocalRelationshipType.IMPORTS:
            continue
        target = edge.target_local_id
        if target.startswith("file:"):
            imported.setdefault(edge.source_local_id, set()).add(target.removeprefix("file:"))
    return imported


def _external_receivers(
    context: ResolutionContext, result: ResolutionResult
) -> dict[str, set[str]]:
    """Go-only: aliases of unresolved (external) package imports per file."""
    resolved_targets: dict[str, set[str]] = {}
    for edge in result.edges:
        if edge.relationship is not LocalRelationshipType.IMPORTS:
            continue
        if edge.source_local_id.startswith("file:") and edge.target_local_id.startswith("file:"):
            resolved_targets.setdefault(edge.source_local_id.removeprefix("file:"), set()).add(
                edge.target_local_id.removeprefix("file:")
            )
    externals: dict[str, set[str]] = {}
    for path, file_result in context.extraction.files:
        if context.file_language.get(path) != "go":
            continue
        for imported in file_result.imports:
            source = imported.source
            is_resolved = False
            targets = resolved_targets.get(path, set())
            parts = source.split("/")
            for index in range(len(parts)):
                suffix = "/".join(parts[index:])
                if any(t == suffix or t.startswith(suffix + "/") for t in targets):
                    is_resolved = True
                    break
            if is_resolved:
                continue
            alias = posixpath.basename(source)
            if not alias or alias == ".":
                continue
            if len(alias) >= 2 and alias[0] == "v" and alias[1].isdigit():
                parent = posixpath.basename(posixpath.dirname(source))
                if parent and parent != ".":
                    alias = parent
            for binding in imported.bindings:
                if binding.alias:
                    alias = binding.alias
                    break
            externals.setdefault(path, set()).add(alias)
    return externals


def resolve_calls_spawns_delegates(context: ResolutionContext, result: ResolutionResult) -> None:
    imported_files = _build_imported_files(result, context)
    externals = _external_receivers(context, result)

    for path, file_result in context.extraction.files:
        aliases = context.import_aliases.get(path, {})
        for call in file_result.calls:
            if call.callee_name in BUILT_IN_NAMES:
                continue
            if call.receiver_name and call.receiver_name in externals.get(path, set()):
                continue
            receiver_type = (
                context.receiver_type(path, call.receiver_name) if call.receiver_name else ""
            )
            if call.receiver_name and call.receiver_name in aliases:
                receiver_type = aliases[call.receiver_name]
            site = CallSite(
                caller_local_id=context.enclosing_symbol(path, call.line),
                callee_name=call.callee_name,
                caller_file_path=path,
                original_name=aliases.get(call.callee_name, ""),
                receiver_name=call.receiver_name,
                receiver_type=receiver_type,
            )
            target, _ = resolve_call_tiered(context, imported_files, site)
            if target is None:
                continue
            result.add_edge(
                site.caller_local_id,
                LocalRelationshipType.CALLS,
                target.id,
                {"confidence": CALL_CONFIDENCE, "reason": CALL_REASON},
            )

        # Spawn targets come from curated language query predicates, so the
        # general call noise filter does not apply.
        for spawn in file_result.spawns:
            site = CallSite(
                caller_local_id=context.enclosing_symbol(path, spawn.line),
                callee_name=spawn.target_name,
                caller_file_path=path,
                receiver_name=spawn.receiver_name,
                receiver_type=(
                    context.receiver_type(path, spawn.receiver_name) if spawn.receiver_name else ""
                ),
            )
            target, _ = resolve_call_tiered(context, imported_files, site)
            if target is None:
                continue
            result.add_edge(
                site.caller_local_id,
                LocalRelationshipType.SPAWNS,
                target.id,
                {"confidence": SPAWN_CONFIDENCE},
            )

        for delegate in file_result.delegates:
            if delegate.target_name in BUILT_IN_NAMES:
                continue
            site = CallSite(
                caller_local_id=context.enclosing_symbol(path, delegate.line),
                callee_name=delegate.target_name,
                caller_file_path=path,
                receiver_name=delegate.receiver_name,
                receiver_type=(
                    context.receiver_type(path, delegate.receiver_name)
                    if delegate.receiver_name
                    else ""
                ),
            )
            target, score = resolve_call_tiered(context, imported_files, site)
            if target is None:
                continue
            if target.label not in ("Function", "Method"):
                continue
            # Delegate targets must be callable and in the same file; scores
            # alone can also admit cross-file receiver-typed matches.
            if score < 100 or target.file_path != site.caller_file_path:
                continue
            # A bare identifier naming an owned method is a variable, not a
            # method reference.
            if not delegate.receiver_name and target.label == "Method" and target.owner_name:
                continue
            if site.caller_local_id == target.id:
                continue
            result.add_edge(
                site.caller_local_id,
                LocalRelationshipType.DELEGATES_TO,
                target.id,
                {"confidence": DELEGATE_CONFIDENCE},
            )
