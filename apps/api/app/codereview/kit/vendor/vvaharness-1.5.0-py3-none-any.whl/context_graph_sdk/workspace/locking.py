# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Cross-platform exclusive workspace file locking."""

from __future__ import annotations

import errno
import importlib
import os
from pathlib import Path
from typing import BinaryIO, Protocol, cast


class _PosixLocking(Protocol):
    LOCK_EX: int
    LOCK_NB: int
    LOCK_UN: int

    def flock(self, file_descriptor: BinaryIO, operation: int) -> None: ...


class _WindowsLocking(Protocol):
    LK_NBLCK: int
    LK_UNLCK: int

    def locking(self, file_descriptor: int, mode: int, byte_count: int) -> None: ...


class WorkspaceFileLock:
    """Owns an exclusive process lock for one workspace lock file."""

    def __init__(self, path: Path) -> None:
        self._file = path.open("a+b")
        self._locked = False
        try:
            _acquire_file_lock(self._file)
            self._locked = True
        except Exception:
            self._file.close()
            raise

    def release(self) -> None:
        if not self._locked:
            return
        try:
            _release_file_lock(self._file)
        finally:
            self._locked = False
            self._file.close()


def _acquire_file_lock(lock_file: BinaryIO) -> None:
    if os.name == "nt":
        _acquire_windows_lock(lock_file)
        return
    _acquire_posix_lock(lock_file)


def _release_file_lock(lock_file: BinaryIO) -> None:
    if os.name == "nt":
        _release_windows_lock(lock_file)
        return
    _release_posix_lock(lock_file)


def _load_posix_locking() -> _PosixLocking:
    return cast(_PosixLocking, importlib.import_module("fcntl"))


def _acquire_posix_lock(lock_file: BinaryIO) -> None:
    posix_locking = _load_posix_locking()
    try:
        posix_locking.flock(lock_file, posix_locking.LOCK_EX | posix_locking.LOCK_NB)
    except OSError as exc:
        if exc.errno in {errno.EACCES, errno.EAGAIN}:
            raise BlockingIOError(errno.EWOULDBLOCK, "workspace lock is already held") from exc
        raise


def _release_posix_lock(lock_file: BinaryIO) -> None:
    posix_locking = _load_posix_locking()
    posix_locking.flock(lock_file, posix_locking.LOCK_UN)


def _load_windows_locking() -> _WindowsLocking:
    return cast(_WindowsLocking, importlib.import_module("msvcrt"))


def _acquire_windows_lock(lock_file: BinaryIO) -> None:
    windows_locking = _load_windows_locking()
    if os.fstat(lock_file.fileno()).st_size == 0:
        lock_file.write(b"\0")
        lock_file.flush()
    lock_file.seek(0)
    try:
        windows_locking.locking(lock_file.fileno(), windows_locking.LK_NBLCK, 1)
    except OSError as exc:
        if exc.errno in {errno.EACCES, errno.EAGAIN, errno.EDEADLK}:
            raise BlockingIOError(errno.EWOULDBLOCK, "workspace lock is already held") from exc
        raise


def _release_windows_lock(lock_file: BinaryIO) -> None:
    windows_locking = _load_windows_locking()
    lock_file.seek(0)
    windows_locking.locking(lock_file.fileno(), windows_locking.LK_UNLCK, 1)
