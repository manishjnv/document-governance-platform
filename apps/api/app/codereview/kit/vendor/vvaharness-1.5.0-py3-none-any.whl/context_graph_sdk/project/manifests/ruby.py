# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Gemfile parsing."""

from __future__ import annotations

import re

from context_graph_sdk.project.config import DependencyRecord, ManifestReader, ProjectConfig

_GEM_LINE = re.compile(r"^\s*gem\s+['\"]([^'\"]+)['\"](?:\s*,\s*['\"]([^'\"]+)['\"])?")


def load_gemfile_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("Gemfile"):
        if relative != "Gemfile":
            continue
        text = reader.read_text(relative)
        if text is None:
            continue
        for line in text.split("\n"):
            match = _GEM_LINE.match(line)
            if match:
                config.add_dependency(
                    DependencyRecord(match.group(1), match.group(2) or "", relative)
                )
