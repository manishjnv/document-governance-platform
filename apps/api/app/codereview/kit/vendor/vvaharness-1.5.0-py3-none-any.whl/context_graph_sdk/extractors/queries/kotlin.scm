; Production extraction query set for kotlin, ported from the reviewed reference.
(class_declaration (type_identifier) @name) @definition.class
(object_declaration (type_identifier) @name) @definition.class
(companion_object (type_identifier) @name) @definition.class
(enum_entry (simple_identifier) @name) @definition.const
(type_alias (type_identifier) @name) @definition.type
(function_declaration (simple_identifier) @name) @definition.function
(secondary_constructor) @definition.constructor
(import_header (identifier) @import.source) @import
(call_expression (simple_identifier) @call.name) @call
(call_expression (navigation_expression (simple_identifier) @call.name)) @call
(constructor_invocation (user_type (type_identifier) @call.name)) @call
(class_declaration (type_identifier) @heritage.class (delegation_specifier (user_type (type_identifier) @heritage.extends))) @heritage
(class_declaration (type_identifier) @heritage.class (delegation_specifier (constructor_invocation (user_type (type_identifier) @heritage.extends)))) @heritage
(property_declaration (variable_declaration (simple_identifier) @name)) @definition.property
(call_expression (simple_identifier) @_fn (#match? @_fn "^(launch|async)$")) @spawn
(call_expression (navigation_expression (simple_identifier) @_fn (#match? @_fn "^(launch|async)$"))) @spawn
