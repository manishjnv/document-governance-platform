# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deterministic, bounded repository walking with safety policies.

Hidden entries and `.git` are skipped, ignore rules combine built-in defaults
with the root `.gitignore` and `.contextgraphignore`, relative paths use forward
slashes, and files over the source bound are skipped. Symlinks are never traversed or reported so a
repository cannot alias content from outside its root.
"""

from __future__ import annotations

import os
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

from context_graph_sdk.errors import DiscoveryError

from .ignore import DEFAULT_IGNORE_PATTERNS, GitIgnoreMatcher, parse_ignore_lines
from .languages import detect_language, is_documentation_file

DEFAULT_MAX_FILE_BYTES = 10 * 1024 * 1024
DOCUMENTATION_CONTENT_BYTES = 50_000
DEFAULT_MAX_ENTRIES = 500_000


@dataclass(frozen=True)
class WalkedFile:
    relative_path: str
    size: int
    language: str
    is_documentation: bool


@dataclass(frozen=True)
class RepositoryWalk:
    root: str
    directories: tuple[str, ...]
    files: tuple[WalkedFile, ...]
    skipped: tuple[str, ...]


def _load_ignore_matcher(root: Path, extra_patterns: Sequence[str]) -> GitIgnoreMatcher:
    lines = list(DEFAULT_IGNORE_PATTERNS)
    for name in (".gitignore", ".contextgraphignore"):
        try:
            lines.extend(parse_ignore_lines((root / name).read_text(encoding="utf-8")))
        except (OSError, UnicodeDecodeError):
            continue
    lines.extend(extra_patterns)
    return GitIgnoreMatcher(tuple(lines))


def walk_repository(
    root: str | Path,
    *,
    extra_ignore_patterns: Sequence[str] = (),
    max_file_bytes: int = DEFAULT_MAX_FILE_BYTES,
    max_entries: int = DEFAULT_MAX_ENTRIES,
) -> RepositoryWalk:
    if max_file_bytes <= 0 or max_entries <= 0:
        raise DiscoveryError("walker bounds must be positive")
    input_root = Path(root)
    # Symlink detection must use the caller's unresolved path; resolve()
    # would erase the link and silently walk the target.
    if input_root.is_symlink():
        raise DiscoveryError(f"repository root must not be a symlink: {root}")
    resolved_root = input_root.resolve()
    if not resolved_root.is_dir():
        raise DiscoveryError(f"repository root is not a directory: {root}")
    matcher = _load_ignore_matcher(resolved_root, extra_ignore_patterns)

    directories: list[str] = []
    files: list[WalkedFile] = []
    skipped: list[str] = []
    entry_count = 0

    pending: list[tuple[Path, str]] = [(resolved_root, "")]
    while pending:
        directory, relative_prefix = pending.pop()
        try:
            with os.scandir(directory) as scanner:
                entries = sorted(scanner, key=lambda entry: entry.name)
        except OSError:
            if relative_prefix:
                skipped.append(relative_prefix)
            continue
        for entry in entries:
            relative = f"{relative_prefix}/{entry.name}" if relative_prefix else entry.name
            entry_count += 1
            if entry_count > max_entries:
                raise DiscoveryError(f"repository exceeds {max_entries} discovered entries")
            if entry.name.startswith("."):
                continue
            if entry.is_symlink():
                skipped.append(relative)
                continue
            try:
                is_dir = entry.is_dir(follow_symlinks=False)
            except OSError:
                skipped.append(relative)
                continue
            if matcher.matches(relative, is_dir=is_dir):
                continue
            if is_dir:
                directories.append(relative)
                pending.append((Path(entry.path), relative))
                continue
            try:
                size = entry.stat(follow_symlinks=False).st_size
            except OSError:
                skipped.append(relative)
                continue
            if size > max_file_bytes:
                skipped.append(relative)
                continue
            files.append(
                WalkedFile(
                    relative,
                    size,
                    detect_language(entry.name),
                    is_documentation_file(relative),
                )
            )
    return RepositoryWalk(
        str(resolved_root),
        tuple(sorted(directories)),
        tuple(sorted(files, key=lambda item: item.relative_path)),
        tuple(sorted(skipped)),
    )


def read_documentation_text(
    root: str | Path,
    relative_path: str,
    *,
    max_bytes: int = DOCUMENTATION_CONTENT_BYTES,
) -> str:
    """Read documentation content truncated at a UTF-8-safe byte boundary.

    An incomplete trailing multibyte sequence introduced by the byte cut is
    dropped; malformed bytes inside the file are replaced so one bad file
    cannot abort analysis.
    """
    path = _resolve_inside_root(Path(root).resolve(), relative_path)
    try:
        with path.open("rb") as handle:
            data = handle.read(max_bytes + 4)
    except OSError:
        return ""
    truncated = data[:max_bytes]
    if len(data) > max_bytes:
        for trim in range(4):
            candidate = truncated[: max_bytes - trim] if trim else truncated
            try:
                return candidate.decode("utf-8")
            except UnicodeDecodeError as error:
                if error.reason == "unexpected end of data" and error.start >= len(candidate) - 3:
                    continue
                break
    return truncated.decode("utf-8", errors="replace")


def _resolve_inside_root(root: Path, relative_path: str) -> Path:
    candidate = Path(relative_path)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise DiscoveryError(f"path escapes the repository root: {relative_path}")
    resolved = (root / candidate).resolve()
    if not resolved.is_relative_to(root):
        raise DiscoveryError(f"path escapes the repository root: {relative_path}")
    return resolved
