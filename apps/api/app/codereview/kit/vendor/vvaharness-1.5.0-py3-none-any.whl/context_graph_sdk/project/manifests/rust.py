# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Cargo.toml parsing."""

from __future__ import annotations

from context_graph_sdk.project.config import (
    DependencyRecord,
    ManifestReader,
    ManifestRecord,
    ProjectConfig,
    workspace_display_name,
)

from ._data import as_mapping, as_str, mapping_at, parse_toml, string_list

_SECTIONS = (
    ("dependencies", False, ""),
    ("dev-dependencies", True, "dev"),
    ("build-dependencies", True, "build"),
)


def _dependency_version(value: object) -> tuple[str, str]:
    if isinstance(value, str):
        return value, ""
    mapping = as_mapping(value)
    if mapping is not None:
        return as_str(mapping.get("version")), as_str(mapping.get("git"))
    return "", ""


def load_cargo_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("Cargo.toml"):
        text = reader.read_text(relative)
        parsed = parse_toml(text) if text is not None else None
        if parsed is None:
            continue
        for section, dev, scope in _SECTIONS:
            entries = as_mapping(parsed.get(section)) or {}
            for name, value in entries.items():
                version, git = _dependency_version(value)
                if not version and not git:
                    continue
                config.add_dependency(DependencyRecord(name, version, relative, dev, scope))


def load_cargo_manifests(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("Cargo.toml"):
        text = reader.read_text(relative)
        parsed = parse_toml(text) if text is not None else None
        if parsed is None:
            continue
        package = mapping_at(parsed, "package")
        members = string_list(mapping_at(parsed, "workspace").get("members"))
        manifest_name = as_str(package.get("name"))
        if not manifest_name and members:
            manifest_name = workspace_display_name(reader.root, relative)
        config.add_manifest(
            ManifestRecord(
                manifest_name,
                relative,
                "rust",
                as_str(package.get("version")),
                members,
            )
        )
