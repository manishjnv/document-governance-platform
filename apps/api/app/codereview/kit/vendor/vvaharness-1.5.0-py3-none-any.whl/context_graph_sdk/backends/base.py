# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Narrow backend protocols for one physical graph database."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import AbstractContextManager
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, runtime_checkable

from context_graph_sdk.identity import ProjectId
from context_graph_sdk.models import (
    CatalogPublication,
    CorrelationEdge,
    FrozenMap,
    GraphEdge,
    GraphNode,
    ProjectSnapshot,
    ProviderManifest,
    ResolvedCorrelation,
    SnapshotLocator,
)


@dataclass(frozen=True, order=True)
class SchemaPattern:
    source_label: str
    relationship_type: str
    target_label: str
    count: int


@dataclass(frozen=True)
class GraphSchema:
    labels: tuple[str, ...]
    relationship_types: tuple[str, ...]
    node_property_keys: tuple[str, ...]
    relationship_property_keys: tuple[str, ...] = ()
    patterns: tuple[SchemaPattern, ...] = ()
    node_count: int = 0
    relationship_count: int = 0

    def __post_init__(self) -> None:
        object.__setattr__(self, "labels", tuple(sorted(set(self.labels))))
        object.__setattr__(self, "relationship_types", tuple(sorted(set(self.relationship_types))))
        object.__setattr__(self, "node_property_keys", tuple(sorted(set(self.node_property_keys))))
        object.__setattr__(
            self,
            "relationship_property_keys",
            tuple(sorted(set(self.relationship_property_keys))),
        )
        object.__setattr__(self, "patterns", tuple(sorted(set(self.patterns))))

    @property
    def property_keys(self) -> tuple[str, ...]:
        """All node and relationship property keys (compatibility view)."""
        return tuple(sorted(set(self.node_property_keys + self.relationship_property_keys)))


@runtime_checkable
class GraphWriteTransaction(Protocol):
    """One atomic write unit inside one physical database."""

    def write_nodes(self, nodes: tuple[GraphNode, ...]) -> None: ...

    def write_edges(self, edges: tuple[GraphEdge, ...]) -> None: ...

    def commit(self) -> None: ...

    def rollback(self) -> None: ...


@runtime_checkable
class CatalogWriteTransaction(Protocol):
    """One authoritative accepted-snapshot and correlation publication."""

    def publish(self, publication: CatalogPublication) -> None: ...

    def commit(self) -> None: ...

    def rollback(self) -> None: ...


@runtime_checkable
class GraphBackend(Protocol):
    """A single project-snapshot or correlation database handle."""

    def begin_write(self) -> AbstractContextManager[GraphWriteTransaction]: ...

    def query_readonly(
        self, cypher: str, parameters: FrozenMap, row_limit: int
    ) -> Iterator[FrozenMap]: ...

    def close(self) -> None: ...


@runtime_checkable
class CatalogBackend(GraphBackend, Protocol):
    def begin_publication(self) -> AbstractContextManager[CatalogWriteTransaction]: ...

    def accepted_snapshot(self, project_id: ProjectId) -> ProjectSnapshot | None: ...

    def accepted_snapshots(self) -> tuple[ProjectSnapshot, ...]: ...

    def correlations_touching(self, project_id: ProjectId) -> tuple[CorrelationEdge, ...]: ...

    def project_snapshot_count(self, project_id: ProjectId) -> int: ...

    def node_ref_count(self, project_id: ProjectId) -> int: ...

    def provider_manifests(self, project_id: ProjectId) -> tuple[ProviderManifest, ...]: ...

    def resolve_correlations(
        self, node_id: str, result_limit: int
    ) -> tuple[ResolvedCorrelation, ...]: ...


@runtime_checkable
class GraphBackendFactory(Protocol):
    """Creates independent physical databases without process-global pooling."""

    def create_project(self, locator: SnapshotLocator) -> GraphBackend: ...

    def open_project(self, locator: SnapshotLocator) -> GraphBackend: ...

    def create_catalog(self, path: Path) -> CatalogBackend: ...

    def open_catalog(self, path: Path) -> CatalogBackend: ...

    def delete_project(self, locator: SnapshotLocator) -> None: ...
