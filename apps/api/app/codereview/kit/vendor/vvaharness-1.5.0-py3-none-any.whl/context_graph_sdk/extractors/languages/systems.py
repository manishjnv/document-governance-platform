# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""C++ modifier-token annotation extraction."""

from __future__ import annotations

import re

from tree_sitter import Node

from context_graph_sdk.extractors.analysis import node_text

_TOKEN_SPLIT = re.compile(r"[^A-Za-z_]+")
_MODIFIER_KEYWORDS = ("virtual", "override", "final")


def cpp_annotation_supplement(def_node: Node, source: bytes) -> tuple[str, ...]:
    text = node_text(def_node, source)
    if not text:
        return ()
    tokens = set(_TOKEN_SPLIT.split(text))
    return tuple(keyword for keyword in _MODIFIER_KEYWORDS if keyword in tokens)
