; Production extraction query set for csharp, ported from the reviewed reference.
(class_declaration name: (identifier) @name) @definition.class
(interface_declaration name: (identifier) @name) @definition.interface
(struct_declaration name: (identifier) @name) @definition.struct
(enum_declaration name: (identifier) @name) @definition.enum
(record_declaration name: (identifier) @name) @definition.record
(delegate_declaration name: (identifier) @name) @definition.delegate
(namespace_declaration name: (identifier) @name) @definition.namespace
(namespace_declaration name: (qualified_name) @name) @definition.namespace
(file_scoped_namespace_declaration name: (identifier) @name) @definition.namespace
(file_scoped_namespace_declaration name: (qualified_name) @name) @definition.namespace
(method_declaration name: (identifier) @name) @definition.method
(local_function_statement name: (identifier) @name) @definition.function
(constructor_declaration name: (identifier) @name) @definition.constructor
(using_directive (qualified_name) @import.source) @import
(using_directive (identifier) @import.source) @import
(invocation_expression function: (identifier) @call.name) @call
(invocation_expression function: (member_access_expression name: (identifier) @call.name)) @call
(invocation_expression function: (conditional_access_expression (member_binding_expression name: (identifier) @call.name))) @call
(object_creation_expression type: (identifier) @call.name) @call
(implicit_object_creation_expression) @call
(class_declaration name: (identifier) @heritage.class (base_list (identifier) @heritage.extends)) @heritage
(class_declaration name: (identifier) @heritage.class (base_list (generic_name (identifier) @heritage.extends))) @heritage
(interface_declaration name: (identifier) @heritage.class (base_list (identifier) @heritage.extends)) @heritage
(struct_declaration name: (identifier) @heritage.class (base_list (identifier) @heritage.extends)) @heritage
(property_declaration name: (identifier) @name) @definition.property
(assignment_expression left: (member_access_expression expression: (_) @assignment.receiver name: (identifier) @assignment.property) right: (_)) @assignment
(invocation_expression function: (member_access_expression name: (identifier) @_fn (#match? @_fn "^(Run|StartNew|QueueUserWorkItem)$"))) @spawn
(invocation_expression arguments: (argument_list (argument (identifier) @delegate.target))) @delegate
