# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""go.mod and go.work parsing without the Go toolchain."""

from __future__ import annotations

import re

from context_graph_sdk.project.config import (
    DependencyRecord,
    ManifestReader,
    ManifestRecord,
    ProjectConfig,
    workspace_display_name,
)

_COMMENT = re.compile(r"//.*$")


def _directive_lines(text: str, keyword: str) -> list[str]:
    """Yield the arguments of `keyword` directives, expanding block syntax."""
    lines: list[str] = []
    in_block = False
    for raw in text.split("\n"):
        line = _COMMENT.sub("", raw).strip()
        if not line:
            continue
        if in_block:
            if line == ")":
                in_block = False
                continue
            lines.append(line)
            continue
        if line == f"{keyword} (":
            in_block = True
            continue
        if line.startswith(keyword + " "):
            argument = line[len(keyword) + 1 :].strip()
            if argument == "(":
                in_block = True
            elif argument:
                lines.append(argument)
    return lines


def _module_path(text: str) -> str:
    for line in text.split("\n"):
        stripped = _COMMENT.sub("", line).strip()
        if stripped.startswith("module "):
            return stripped[len("module ") :].strip()
    return ""


def load_go_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("go.mod"):
        text = reader.read_text(relative)
        if text is None:
            continue
        replacements: dict[str, tuple[str, str]] = {}
        for line in _directive_lines(text, "replace"):
            if "=>" not in line:
                continue
            old_part, new_part = (part.strip() for part in line.split("=>", 1))
            old_fields = old_part.split()
            new_fields = new_part.split()
            if not old_fields or not new_fields:
                continue
            new_path = new_fields[0]
            new_version = new_fields[1] if len(new_fields) > 1 else ""
            key = f"{old_fields[0]}@{old_fields[1]}" if len(old_fields) > 1 else old_fields[0]
            replacements[key] = (new_path, new_version)
        for line in _directive_lines(text, "require"):
            fields = line.split()
            if len(fields) < 2:
                continue
            name, version = fields[0], fields[1]
            replacement = replacements.get(f"{name}@{version}") or replacements.get(name)
            if replacement is not None:
                name = replacement[0]
                if replacement[1]:
                    version = replacement[1]
            config.add_dependency(DependencyRecord(name, version, relative))


def load_go_manifests(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("go.work"):
        text = reader.read_text(relative)
        if text is None:
            continue
        members = tuple(
            line.split()[0].replace("\\", "/") for line in _directive_lines(text, "use") if line
        )
        config.add_manifest(
            ManifestRecord(
                workspace_display_name(reader.root, relative), relative, "go", "", members
            )
        )
    for relative in reader.by_base_name("go.mod"):
        text = reader.read_text(relative)
        if text is None:
            continue
        module_path = _module_path(text)
        if module_path:
            config.add_manifest(ManifestRecord(module_path, relative, "go"))
