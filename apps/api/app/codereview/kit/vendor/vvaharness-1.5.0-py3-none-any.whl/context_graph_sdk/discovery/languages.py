# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Data-driven language and documentation detection."""

from __future__ import annotations

import posixpath

# All 17 Tree-sitter language configurations by file extension. The `.h`
# extension is routed to C++ so mixed C/C++ headers use the richer grammar.
_NATIVE_EXTENSIONS: dict[str, str] = {
    ".go": "go",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".py": "python",
    ".java": "java",
    ".rs": "rust",
    ".cc": "cpp",
    ".cpp": "cpp",
    ".cxx": "cpp",
    ".hpp": "cpp",
    ".hh": "cpp",
    ".hxx": "cpp",
    ".h": "cpp",
    ".inl": "cpp",
    ".ipp": "cpp",
    ".tpp": "cpp",
    ".c": "c",
    ".rb": "ruby",
    ".php": "php",
    ".kt": "kotlin",
    ".kts": "kotlin",
    ".cs": "csharp",
    ".scala": "scala",
    ".sc": "scala",
    ".swift": "swift",
    ".dart": "dart",
    ".sol": "solidity",
}

_SUPPORTING_BY_FILENAME: dict[str, str] = {
    "dockerfile": "dockerfile",
    "build.sbt": "scala",
    "build.gradle": "groovy",
    "makefile": "make",
    "gnumakefile": "make",
    "bsdmakefile": "make",
}

_SUPPORTING_BY_SUFFIX: tuple[tuple[str, str], ...] = (
    (".json", "json"),
    (".yaml", "yaml"),
    (".yml", "yaml"),
    (".toml", "toml"),
    (".hcl", "hcl"),
    (".tf", "hcl"),
    (".tfvars", "hcl"),
    (".sql", "sql"),
    (".proto", "protobuf"),
    (".sh", "bash"),
    (".bash", "bash"),
    (".zsh", "bash"),
    (".bashrc", "bash"),
    (".bash_profile", "bash"),
    (".bash_login", "bash"),
    (".profile", "bash"),
    (".zshrc", "bash"),
    (".zprofile", "bash"),
)

_MAKEFILE_NAMES = frozenset({"makefile", "gnumakefile", "bsdmakefile"})


def detect_language(filename: str) -> str:
    name = posixpath.basename(filename.replace("\\", "/")).lower()
    if name in _MAKEFILE_NAMES:
        return "make"
    _, extension = posixpath.splitext(name)
    if language := _NATIVE_EXTENSIONS.get(extension):
        return language
    if language := _SUPPORTING_BY_FILENAME.get(name):
        return language
    for suffix, language in _SUPPORTING_BY_SUFFIX:
        if name.endswith(suffix):
            return language
    return ""


_DOC_NAME_PREFIXES: tuple[str, ...] = (
    "readme",
    "architecture",
    "contributing",
    "design",
    "security",
    "code_of_conduct",
    "code-of-conduct",
    "install",
    "usage",
    "faq",
    "history",
    "migration",
    "upgrading",
    "development",
    "hacking",
    "quickstart",
    "tutorial",
    "overview",
    "api",
    "getting-started",
    "getting_started",
    "guide",
)

_DOC_DIRECTORY_NAMES = frozenset(
    {"doc", "docs", "documentation", "wiki", "guides", "handbook", "manual", "book"}
)

_DOC_EXTENSIONS = frozenset({".md", ".rst", ".txt", ".adoc", ".org"})


def is_documentation_file(file_path: str) -> bool:
    lowered = file_path.replace("\\", "/").lower()
    base = posixpath.basename(lowered)
    stem, extension = posixpath.splitext(base)
    if not extension:
        return base in _DOC_NAME_PREFIXES
    if extension not in _DOC_EXTENSIONS:
        return False
    for prefix in _DOC_NAME_PREFIXES:
        if stem == prefix or stem.startswith(prefix + "_") or stem.startswith(prefix + "-"):
            return True
    return any(part in _DOC_DIRECTORY_NAMES for part in lowered.split("/")[:-1])
