# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Structured progress events for synchronous repository analysis."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from enum import StrEnum
from typing import TypeAlias

from context_graph_sdk.errors import ModelValidationError


class AnalysisPhase(StrEnum):
    DISCOVERY = "discovery"
    CONFIGURATION = "configuration"
    EXTRACTION = "extraction"
    RESOLUTION = "resolution"
    GRAPH_BUILD = "graph_build"
    DERIVATION = "derivation"
    CORRELATION = "correlation"
    PUBLICATION = "publication"


@dataclass(frozen=True)
class AnalysisProgress:
    phase: AnalysisPhase
    message: str
    step: int
    step_count: int
    completed: int | None = None
    total: int | None = None
    finished: bool = False

    def __post_init__(self) -> None:
        if not self.message:
            raise ModelValidationError("analysis progress message is required")
        if not 1 <= self.step <= self.step_count:
            raise ModelValidationError("analysis progress step is outside the pipeline")
        if (self.completed is None) != (self.total is None):
            raise ModelValidationError("analysis progress item counts must be paired")
        if (
            self.completed is not None
            and self.total is not None
            and (self.total < 0 or not 0 <= self.completed <= self.total)
        ):
            raise ModelValidationError("analysis progress item counts are invalid")


AnalysisProgressCallback: TypeAlias = Callable[[AnalysisProgress], None]
