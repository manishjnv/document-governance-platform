# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Ruby call routing: require/mixin/attribute reclassification.

One AST walk indexes every `call` node by line up front; routing decisions
then use the index instead of re-walking the tree per routed call.
"""

from __future__ import annotations

from tree_sitter import Node

from context_graph_sdk.extractors.analysis import node_text, walk
from context_graph_sdk.extractors.records import (
    Call,
    Heritage,
    Import,
    MutableFileResult,
    Symbol,
    symbol_id,
)

_REQUIRES = ("require", "require_relative")
_MIXINS = ("include", "extend", "prepend")
_ATTRIBUTES = ("attr_accessor", "attr_reader", "attr_writer")


class _CallIndex:
    """Line-indexed `call` nodes, collected in one pre-order walk."""

    def __init__(self, root: Node) -> None:
        self.by_line: dict[int, list[Node]] = {}

        def visit(node: Node, _depth: int) -> str | None:
            if node.type == "call":
                self.by_line.setdefault(node.start_point.row, []).append(node)
            return None

        walk(root, visit)

    def matching(self, source: bytes, line: int, method_name: str) -> Node | None:
        for node in self.by_line.get(line, []):
            method = node.child_by_field_name("method")
            if method is not None and node_text(method, source) == method_name:
                return node
        return None

    def enclosing_class(self, source: bytes, line: int) -> str:
        # Use the first call node on the line as the lexical anchor.
        nodes = self.by_line.get(line, [])
        if not nodes:
            return ""
        current = nodes[0].parent
        for _ in range(20):
            if current is None:
                return ""
            if current.type in ("class", "module"):
                name_node = current.child_by_field_name("name")
                if name_node is not None:
                    return node_text(name_node, source)
            current = current.parent
        return ""


def route_ruby_calls(
    root: Node, source: bytes, relative_path: str, language: str, result: MutableFileResult
) -> None:
    index = _CallIndex(root)
    remaining: list[Call] = []
    for call in result.calls:
        if call.callee_name in _REQUIRES:
            import_path = _call_argument(index, source, call.line, call.callee_name)
            if import_path:
                if call.callee_name == "require_relative" and not import_path.startswith("."):
                    import_path = "./" + import_path
                result.imports.append(Import(relative_path, import_path))
            continue
        if call.callee_name in _MIXINS:
            mixin = _call_argument(index, source, call.line, call.callee_name)
            owner = index.enclosing_class(source, call.line)
            if mixin and owner:
                result.heritage.append(Heritage(relative_path, owner, mixin, "trait"))
            continue
        if call.callee_name in _ATTRIBUTES:
            owner = index.enclosing_class(source, call.line)
            for property_name in _attribute_arguments(index, source, call.line, call.callee_name):
                result.symbols.append(
                    Symbol(
                        id=symbol_id("Property", relative_path, property_name, owner),
                        name=property_name,
                        label="Property",
                        file_path=relative_path,
                        start_line=call.line,
                        end_line=call.line,
                        is_exported=False,
                        language=language,
                        owner_name=owner,
                    )
                )
            continue
        remaining.append(call)
    result.calls = remaining


def _call_argument(index: _CallIndex, source: bytes, line: int, method_name: str) -> str:
    call = index.matching(source, line, method_name)
    if call is None:
        return ""
    arguments = call.child_by_field_name("arguments")
    if arguments is None:
        return ""
    for child in arguments.children:
        if child.type == "string":
            for grandchild in child.children:
                if grandchild.type == "string_content":
                    return node_text(grandchild, source)
        if child.type in ("constant", "scope_resolution"):
            return node_text(child, source)
    return ""


def _attribute_arguments(
    index: _CallIndex, source: bytes, line: int, method_name: str
) -> list[str]:
    call = index.matching(source, line, method_name)
    if call is None:
        return []
    arguments = call.child_by_field_name("arguments")
    if arguments is None:
        return []
    names: list[str] = []
    for child in arguments.children:
        if child.type == "simple_symbol":
            text = node_text(child, source).removeprefix(":")
            if text:
                names.append(text)
    return names
