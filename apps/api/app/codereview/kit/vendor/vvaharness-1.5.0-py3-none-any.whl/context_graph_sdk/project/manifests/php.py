# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""composer.json parsing."""

from __future__ import annotations

from context_graph_sdk.project.config import (
    DEV_SCOPE,
    DependencyRecord,
    ManifestReader,
    ProjectConfig,
)

from ._data import parse_json_object, string_items


def _is_platform_requirement(name: str) -> bool:
    return name == "php" or name.startswith(("ext-", "lib-"))


def load_composer_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("composer.json"):
        if relative != "composer.json":
            continue
        text = reader.read_text(relative)
        parsed = parse_json_object(text) if text is not None else None
        if parsed is None:
            continue
        for section, dev in (("require", False), ("require-dev", True)):
            for name, version in string_items(parsed.get(section)):
                if _is_platform_requirement(name):
                    continue
                config.add_dependency(
                    DependencyRecord(name, version, relative, dev, DEV_SCOPE if dev else "")
                )
