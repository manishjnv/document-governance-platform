# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Immutable extraction records and deterministic symbol identity."""

from __future__ import annotations

import hashlib
from collections import Counter
from dataclasses import dataclass, field, replace

from context_graph_sdk.errors import ModelValidationError
from context_graph_sdk.symbols import SYMBOL_CATEGORY_LABELS

GENERIC_LABELS = frozenset({"TypeAlias", "CodeElement"})
CALLABLE_LABELS = frozenset({"Function", "Method", "Constructor"})
# Labels that never take an enclosing owner (top-level containers).
OWNERLESS_LABELS = frozenset({"Class", "Interface", "Module", "Namespace", "Trait", "Impl"})


def symbol_id(label: str, file_path: str, name: str, owner: str, *disambiguators: str) -> str:
    """Generate a stable symbol ID from repository-relative identity fields."""
    key = f"{label}:{file_path}:"
    if owner:
        key += owner + "."
    key += name
    for disambiguator in disambiguators:
        if disambiguator:
            key += ":" + disambiguator
    return hashlib.sha256(key.encode()).hexdigest()[:24]


@dataclass(frozen=True)
class Symbol:
    id: str
    name: str
    label: str
    file_path: str
    start_line: int
    end_line: int
    is_exported: bool
    language: str
    kind: str = ""
    content: str = ""
    owner_name: str = ""
    doc_comment: str = ""
    annotations: str = ""
    signature: str = ""
    parameter_count: int = 0
    return_type: str = ""

    def __post_init__(self) -> None:
        if self.label not in SYMBOL_CATEGORY_LABELS:
            raise ModelValidationError(f"unsupported symbol category label: {self.label}")


@dataclass(frozen=True)
class ImportBinding:
    original: str
    alias: str = ""


@dataclass(frozen=True)
class Import:
    file_path: str
    source: str
    bindings: tuple[ImportBinding, ...] = ()


@dataclass(frozen=True)
class Call:
    file_path: str
    callee_name: str
    receiver_name: str = ""
    line: int = 0


@dataclass(frozen=True)
class Assignment:
    file_path: str
    receiver_name: str
    property_name: str
    line: int


@dataclass(frozen=True)
class Spawn:
    file_path: str
    target_name: str
    receiver_name: str = ""
    line: int = 0


@dataclass(frozen=True)
class Delegate:
    file_path: str
    target_name: str
    receiver_name: str = ""
    line: int = 0


@dataclass(frozen=True)
class Heritage:
    """Captured extends/implements/trait fact; resolution is a later stage."""

    file_path: str
    class_name: str
    parent_name: str
    kind: str


@dataclass(frozen=True)
class TypeBinding:
    file_path: str
    variable_name: str
    type_name: str
    line: int
    kind: str
    owner_name: str = ""


@dataclass(frozen=True)
class FileDiagnostic:
    file_path: str
    reason: str


@dataclass(frozen=True)
class FileExtraction:
    symbols: tuple[Symbol, ...] = ()
    imports: tuple[Import, ...] = ()
    calls: tuple[Call, ...] = ()
    assignments: tuple[Assignment, ...] = ()
    spawns: tuple[Spawn, ...] = ()
    delegates: tuple[Delegate, ...] = ()
    heritage: tuple[Heritage, ...] = ()
    type_bindings: tuple[TypeBinding, ...] = ()


@dataclass(frozen=True)
class ExtractionResult:
    files: tuple[tuple[str, FileExtraction], ...] = ()
    diagnostics: tuple[FileDiagnostic, ...] = ()

    @property
    def symbols(self) -> tuple[Symbol, ...]:
        return tuple(sym for _, extraction in self.files for sym in extraction.symbols)


@dataclass
class MutableFileResult:
    """Accumulator used by the shared routing loop for one file."""

    symbols: list[Symbol] = field(default_factory=list[Symbol])
    imports: list[Import] = field(default_factory=list[Import])
    calls: list[Call] = field(default_factory=list[Call])
    assignments: list[Assignment] = field(default_factory=list[Assignment])
    spawns: list[Spawn] = field(default_factory=list[Spawn])
    delegates: list[Delegate] = field(default_factory=list[Delegate])
    heritage: list[Heritage] = field(default_factory=list[Heritage])
    type_bindings: list[TypeBinding] = field(default_factory=list[TypeBinding])

    def freeze(self) -> FileExtraction:
        return FileExtraction(
            tuple(self.symbols),
            tuple(self.imports),
            tuple(self.calls),
            tuple(self.assignments),
            tuple(self.spawns),
            tuple(self.delegates),
            tuple(self.heritage),
            tuple(self.type_bindings),
        )


def deduplicate_symbols(symbols: list[Symbol]) -> list[Symbol]:
    """Prefer the more specific label when one node matched several patterns."""
    best: dict[tuple[str, int], int] = {}
    for index, symbol in enumerate(symbols):
        key = (symbol.name, symbol.start_line)
        existing = best.get(key)
        if existing is None:
            best[key] = index
            continue
        current = symbols[existing]
        if current.label in GENERIC_LABELS and symbol.label not in GENERIC_LABELS:
            best[key] = index
        if current.label == "Function" and symbol.label == "Method":
            best[key] = index
        if current.label == "Property" and symbol.label == "Const":
            best[key] = index
    deduped: list[Symbol] = []
    seen: set[tuple[str, int]] = set()
    for symbol in symbols:
        key = (symbol.name, symbol.start_line)
        if key not in seen:
            seen.add(key)
            deduped.append(symbols[best[key]])
    return deduped


def _group_disambiguator(symbol: Symbol) -> str:
    if symbol.signature:
        return symbol.signature
    if symbol.kind or symbol.content:
        return symbol.kind + "\x00" + symbol.content
    return ""


def disambiguate_duplicate_ids(symbols: list[Symbol]) -> list[Symbol]:
    """Give overloads/duplicate definitions distinct deterministic IDs.

    Signature (then kind/content) stays the primary stable input, but
    byte-identical redefinitions share those too; any IDs still colliding
    within a group additionally hash their start:end location so identical
    redefinitions remain distinct and repeatable.
    """
    groups: dict[tuple[str, str, str, str], list[int]] = {}
    for index, symbol in enumerate(symbols):
        key = (symbol.label, symbol.file_path, symbol.owner_name, symbol.name)
        groups.setdefault(key, []).append(index)
    for indexes in groups.values():
        if len(indexes) < 2:
            continue
        proposed: dict[int, str] = {}
        for index in indexes:
            symbol = symbols[index]
            disambiguator = _group_disambiguator(symbol) or (
                f"{symbol.start_line}:{symbol.end_line}"
            )
            proposed[index] = symbol_id(
                symbol.label, symbol.file_path, symbol.name, symbol.owner_name, disambiguator
            )
        collisions = {
            identifier for identifier, count in Counter(proposed.values()).items() if count > 1
        }
        for index in indexes:
            symbol = symbols[index]
            identifier = proposed[index]
            if identifier in collisions:
                identifier = symbol_id(
                    symbol.label,
                    symbol.file_path,
                    symbol.name,
                    symbol.owner_name,
                    _group_disambiguator(symbol),
                    f"{symbol.start_line}:{symbol.end_line}",
                )
            symbols[index] = replace(symbol, id=identifier)
    return symbols


def is_valid_symbol_name(name: str) -> bool:
    if not name or len(name) > 200:
        return False
    for char in name:
        if char.isalnum() or char in "_$-.:@" or ord(char) > 127:
            continue
        return False
    return True
