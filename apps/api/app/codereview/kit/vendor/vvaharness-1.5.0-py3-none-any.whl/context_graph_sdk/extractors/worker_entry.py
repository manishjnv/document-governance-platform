# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""No-fork stdio entry point for persistent extraction workers."""

from __future__ import annotations

import os
import sys

from context_graph_sdk._process import FrameReader, FrameWriter


def main() -> int:
    if len(sys.argv) != 4:
        return 2
    from .worker import extraction_worker

    requests = FrameReader(sys.stdin.buffer)
    responses = FrameWriter(sys.stdout.buffer)
    extraction_worker(
        sys.argv[1],
        requests,
        responses,
        int(sys.argv[2]),
        int(sys.argv[3]),
    )
    return 0


def _run() -> None:
    try:
        code = main()
    except BaseException as error:
        print(f"extraction worker failed: {type(error).__name__}: {error}", file=sys.stderr)
        code = 1
    # Tree-sitter providers have native teardown paths that are not reliable
    # during CPython finalization. All process-owned resources are closed by
    # the worker loop or the OS, so bypass interpreter teardown deliberately.
    os._exit(code)


if __name__ == "__main__":
    _run()
