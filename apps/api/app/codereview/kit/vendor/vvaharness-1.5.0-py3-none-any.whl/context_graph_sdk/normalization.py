# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""One authoritative deterministic normalization and fingerprint path."""

from __future__ import annotations

import hashlib
import json

from .models import FrozenMap, GraphEdge, GraphNode, GraphSnapshot, PropertyValue

NormalizedValue = (
    str | int | float | bool | None | list["NormalizedValue"] | dict[str, "NormalizedValue"]
)


def normalize_value(value: PropertyValue) -> NormalizedValue:
    if isinstance(value, FrozenMap):
        return {key: normalize_value(child) for key, child in value.entries}
    if isinstance(value, tuple):
        return [normalize_value(child) for child in value]
    return value


def normalize_node(node: GraphNode) -> dict[str, NormalizedValue]:
    return {
        "id": node.id,
        "labels": list(node.labels),
        "localId": node.local_id,
        "properties": normalize_value(node.properties),
        "projectId": node.project_id.value,
    }


def normalize_edge(edge: GraphEdge) -> dict[str, NormalizedValue]:
    return {
        "discriminator": edge.discriminator,
        "id": edge.id,
        "properties": normalize_value(edge.properties),
        "projectId": edge.project_id.value,
        "source": edge.source_id,
        "target": edge.target_id,
        "type": edge.relationship_type,
    }


def normalize_snapshot(snapshot: GraphSnapshot) -> dict[str, NormalizedValue]:
    """Normalize graph content while excluding per-run snapshot IDs."""
    return {
        "projectId": snapshot.project.project_id.value,
        "nodes": [normalize_node(node) for node in snapshot.nodes],
        "edges": [normalize_edge(edge) for edge in snapshot.edges],
    }


def canonical_json(value: NormalizedValue) -> str:
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"), sort_keys=True)


def graph_fingerprint(snapshot: GraphSnapshot) -> str:
    return hashlib.sha256(canonical_json(normalize_snapshot(snapshot)).encode()).hexdigest()
