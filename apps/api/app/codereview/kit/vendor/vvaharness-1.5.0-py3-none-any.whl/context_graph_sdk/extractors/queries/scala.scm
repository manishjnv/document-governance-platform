; Production extraction query set for scala, ported from the reviewed reference.
(class_definition name: (identifier) @name) @definition.class
(object_definition name: (identifier) @name) @definition.class
(trait_definition name: (identifier) @name) @definition.interface
(enum_definition name: (identifier) @name) @definition.enum
(function_definition name: (identifier) @name) @definition.function
(type_definition name: (type_identifier) @name) @definition.type
(val_declaration name: (identifier) @name) @definition.property
(var_declaration name: (identifier) @name) @definition.property
(full_enum_case name: (identifier) @name) @definition.const
(simple_enum_case name: (identifier) @name) @definition.const
(import_declaration path: (_) @import.source) @import
(call_expression function: (identifier) @call.name) @call
(call_expression function: (field_expression field: (identifier) @call.name)) @call
(class_definition name: (identifier) @heritage.class (extends_clause (type_identifier) @heritage.extends)) @heritage
(trait_definition name: (identifier) @heritage.class (extends_clause (type_identifier) @heritage.extends)) @heritage
(object_definition name: (identifier) @heritage.class (extends_clause (type_identifier) @heritage.extends)) @heritage
