# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deterministic Leiden community detection (Traag et al., 2019).

The implementation uses an isolated ``random.Random`` instance. Determinism,
quality objectives, and partition guarantees define its behavior.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from enum import Enum

Adjacency = dict[str, dict[str, float]]

_MAX_LEVELS = 20
_CONVERGENCE_CAP = 100


class Objective(Enum):
    MODULARITY = "modularity"
    CPM = "cpm"
    ERDOS_RENYI = "erdos-renyi"


@dataclass(frozen=True)
class LeidenOptions:
    """Options with explicit None-vs-value semantics.

    ``resolution=None`` selects the objective default: 1/(2m) for
    modularity (so quality reduces to standard Newman modularity under the
    unnormalized igraph formulation used by :func:`quality`), 1.0 for CPM,
    and 1.0 scaled by weighted density for Erdos-Renyi. An explicit float,
    including 0.0, is honored as written. ``beta=None`` selects 0.01.
    """

    objective: Objective = Objective.MODULARITY
    resolution: float | None = None
    beta: float | None = None
    seed: int = 42
    # 2 outer iterations by default; 0 means no local-move iterations (the
    # initial partition is kept); -1 runs until convergence (bounded).
    max_iterations: int = 2
    start_partition: dict[str, int] | None = None


@dataclass
class LeidenResult:
    membership: dict[str, int] = field(default_factory=dict[str, int])
    cluster_count: int = 0
    quality: float = math.nan


def validate_adjacency(adjacency: Adjacency, objective: Objective) -> str | None:
    for source, neighbors in adjacency.items():
        for target, weight in neighbors.items():
            if math.isnan(weight):
                return f"edge {source}->{target} has NaN weight"
            if math.isinf(weight):
                return f"edge {source}->{target} has infinite weight"
            if weight < 0 and objective is not Objective.CPM:
                return f"edge {source}->{target} has negative weight"
    return None


def _effective_resolution(options: LeidenOptions, total_weight: float, node_count: int) -> float:
    resolution = options.resolution
    if options.objective is Objective.CPM:
        return 1.0 if resolution is None else resolution
    if options.objective is Objective.ERDOS_RENYI:
        resolution = 1.0 if resolution is None else resolution
        if node_count > 1:
            pairs = node_count * (node_count + 1) / 2.0
            resolution *= total_weight / pairs
        return resolution
    return (1.0 / (2 * total_weight)) if resolution is None else resolution


def _node_weights(
    adjacency: Adjacency, nodes: list[str], options: LeidenOptions
) -> dict[str, float]:
    if options.objective in (Objective.CPM, Objective.ERDOS_RENYI):
        return dict.fromkeys(nodes, 1.0)
    return {node: sum(adjacency[node].values()) for node in nodes}


def leiden(adjacency: Adjacency, options: LeidenOptions | None = None) -> LeidenResult:
    options = options or LeidenOptions()
    if not adjacency:
        return LeidenResult()

    if validate_adjacency(adjacency, options.objective) is not None:
        nodes = sorted(adjacency)
        return LeidenResult({node: i for i, node in enumerate(nodes)}, len(nodes), math.nan)

    nodes = sorted(adjacency)
    total_weight = sum(sum(neighbors.values()) for neighbors in adjacency.values()) / 2
    if total_weight == 0:
        return LeidenResult({node: i for i, node in enumerate(nodes)}, len(nodes), math.nan)

    resolution = _effective_resolution(options, total_weight, len(nodes))
    beta = 0.01 if options.beta is None else options.beta
    node_weight = _node_weights(adjacency, nodes, options)

    membership: dict[str, int]
    if options.start_partition is not None:
        next_id = max(options.start_partition.values(), default=-1) + 1
        membership = {}
        for node in nodes:
            if node in options.start_partition:
                membership[node] = options.start_partition[node]
            else:
                membership[node] = next_id
                next_id += 1
    else:
        membership = {node: i for i, node in enumerate(nodes)}

    rng = random.Random(options.seed)

    # Explicit semantics: 0 means "no local-move iterations" (the initial
    # partition is returned as-is), -1 runs until convergence (bounded).
    iterations = options.max_iterations
    run_until_convergence = iterations < 0
    if run_until_convergence:
        iterations = _CONVERGENCE_CAP

    current_membership = membership
    for _ in range(iterations):
        level_adj = adjacency
        level_nodes = nodes
        level_weight = node_weight
        level_membership = current_membership
        node_to_original: dict[str, list[str]] = {node: [node] for node in nodes}
        any_changed = False

        for _ in range(_MAX_LEVELS):
            changed = _fast_move(
                level_adj, level_nodes, level_weight, level_membership, resolution, rng
            )
            if not changed:
                break
            any_changed = True
            _reindex(level_nodes, level_membership)
            refined = _refine(
                level_adj, level_nodes, level_weight, level_membership, resolution, beta, rng
            )
            if len({refined[node] for node in level_nodes}) >= len(level_nodes):
                refined = {node: level_membership[node] for node in level_nodes}
            aggregated = _aggregate(
                level_adj, level_nodes, level_weight, level_membership, refined, node_to_original
            )
            if len(aggregated[1]) >= len(level_nodes):
                break
            level_adj, level_nodes, level_weight, level_membership, node_to_original = aggregated

        if run_until_convergence and not any_changed:
            break

        current_membership = {}
        for super_node, community in level_membership.items():
            for original in node_to_original[super_node]:
                current_membership[original] = community

    remap: dict[int, int] = {}
    for node in nodes:
        community = current_membership[node]
        if community not in remap:
            remap[community] = len(remap)
        current_membership[node] = remap[community]

    return LeidenResult(
        current_membership, len(remap), quality(adjacency, current_membership, options)
    )


def _fast_move(
    adjacency: Adjacency,
    nodes: list[str],
    node_weight: dict[str, float],
    membership: dict[str, int],
    resolution: float,
    rng: random.Random,
) -> bool:
    sigma_tot: dict[int, float] = {}
    community_size: dict[int, int] = {}
    for node in nodes:
        community = membership[node]
        sigma_tot[community] = sigma_tot.get(community, 0.0) + node_weight[node]
        community_size[community] = community_size.get(community, 0) + 1

    next_cluster = max((membership[node] for node in nodes), default=-1) + 1
    empty_stack = [c for c in range(next_cluster) if community_size.get(c, 0) == 0]

    shuffled = list(nodes)
    rng.shuffle(shuffled)
    queue = list(shuffled)
    in_queue = dict.fromkeys(shuffled, True)
    head = 0
    any_moved = False

    while head < len(queue):
        node = queue[head]
        head += 1
        in_queue[node] = False

        old_community = membership[node]
        degree = node_weight[node]

        neighbor_weight: dict[int, float] = {}
        for neighbor, weight in adjacency[node].items():
            if neighbor == node:
                continue
            community = membership[neighbor]
            neighbor_weight[community] = neighbor_weight.get(community, 0.0) + weight

        sigma_tot[old_community] -= degree
        community_size[old_community] -= 1
        if community_size[old_community] == 0:
            empty_stack.append(old_community)

        empty_community = empty_stack[-1] if empty_stack else -1

        best_community = old_community
        best_diff = (
            neighbor_weight.get(old_community, 0.0) - degree * sigma_tot[old_community] * resolution
        )
        if empty_community >= 0 and empty_community != old_community and best_diff < 0.0:
            best_diff = 0.0
            best_community = empty_community

        for community in sorted(c for c in neighbor_weight if c != old_community):
            diff = neighbor_weight[community] - degree * sigma_tot.get(community, 0.0) * resolution
            if diff > best_diff:
                best_diff = diff
                best_community = community

        membership[node] = best_community
        sigma_tot[best_community] = sigma_tot.get(best_community, 0.0) + degree
        community_size[best_community] = community_size.get(best_community, 0) + 1

        if (
            best_community == old_community
            and community_size[old_community] == 1
            and empty_stack
            and empty_stack[-1] == old_community
        ) or (
            best_community == empty_community
            and best_community != old_community
            and empty_stack
            and empty_stack[-1] == empty_community
        ):
            empty_stack.pop()

        if best_community != old_community:
            any_moved = True
            to_enqueue = sorted(
                neighbor
                for neighbor in adjacency[node]
                if membership.get(neighbor) != best_community and not in_queue.get(neighbor, False)
            )
            for neighbor in to_enqueue:
                queue.append(neighbor)
                in_queue[neighbor] = True

    return any_moved


def _refine(
    adjacency: Adjacency,
    nodes: list[str],
    node_weight: dict[str, float],
    membership: dict[str, int],
    resolution: float,
    beta: float,
    rng: random.Random,
) -> dict[str, int]:
    refined = {node: index for index, node in enumerate(nodes)}
    clusters: dict[int, list[str]] = {}
    for node in nodes:
        clusters.setdefault(membership[node], []).append(node)

    refined_sigma = {refined[node]: node_weight[node] for node in nodes}
    cluster_total = {c: sum(node_weight[n] for n in members) for c, members in clusters.items()}
    non_singleton: set[int] = set()

    for cluster_id in sorted(clusters):
        members = clusters[cluster_id]
        if len(members) <= 1:
            continue
        total_cluster_weight = cluster_total[cluster_id]

        ext_edge_weight: dict[int, float] = {}
        for vertex in members:
            refined_community = refined[vertex]
            for neighbor, weight in adjacency[vertex].items():
                if (
                    membership.get(neighbor) == cluster_id
                    and refined[neighbor] != refined_community
                ):
                    ext_edge_weight[refined_community] = (
                        ext_edge_weight.get(refined_community, 0.0) + weight
                    )

        shuffled = list(members)
        rng.shuffle(shuffled)

        for vertex in shuffled:
            current = refined[vertex]
            degree = node_weight[vertex]
            if current in non_singleton:
                continue
            if ext_edge_weight.get(current, 0.0) < resolution * degree * (
                total_cluster_weight - degree
            ):
                continue

            refined_sigma[current] -= degree

            neighbor_refined: dict[int, float] = {}
            for neighbor, weight in adjacency[vertex].items():
                if membership.get(neighbor) == cluster_id:
                    community = refined[neighbor]
                    neighbor_refined[community] = neighbor_refined.get(community, 0.0) + weight

            candidates: list[tuple[int, float]] = [(current, 0.0)]
            for community in sorted(neighbor_refined):
                if community == current:
                    continue
                target_weight = refined_sigma.get(community, 0.0)
                well_connected = target_weight * (total_cluster_weight - target_weight)
                if ext_edge_weight.get(community, 0.0) < well_connected * resolution:
                    continue
                diff = neighbor_refined[community] - degree * target_weight * resolution
                if diff >= 0:
                    candidates.append((community, diff))

            max_diff = max(diff for _, diff in candidates)
            cumulative: list[float] = []
            running = 0.0
            for _, diff in candidates:
                running += math.exp((diff - max_diff) / beta)
                cumulative.append(running)
            draw = rng.random() * running
            chosen_index = 0
            for index, bound in enumerate(cumulative):
                if draw <= bound:
                    chosen_index = index
                    break
            chosen = candidates[chosen_index][0]

            if chosen != current:
                refined[vertex] = chosen
                non_singleton.add(chosen)
                for neighbor, weight in adjacency[vertex].items():
                    if membership.get(neighbor) != cluster_id:
                        continue
                    if refined[neighbor] == chosen:
                        ext_edge_weight[chosen] = ext_edge_weight.get(chosen, 0.0) - weight
                    else:
                        ext_edge_weight[chosen] = ext_edge_weight.get(chosen, 0.0) + weight
            refined_sigma[chosen] = refined_sigma.get(chosen, 0.0) + degree

    return refined


def _aggregate(
    adjacency: Adjacency,
    nodes: list[str],
    node_weight: dict[str, float],
    membership: dict[str, int],
    refined: dict[str, int],
    node_to_original: dict[str, list[str]],
) -> tuple[Adjacency, list[str], dict[str, float], dict[str, int], dict[str, list[str]]]:
    members_by_refined: dict[int, list[str]] = {}
    for node in nodes:
        members_by_refined.setdefault(refined[node], []).append(node)
    refined_ids = sorted(members_by_refined)
    super_name = {c: f"super:{c}" for c in refined_ids}

    new_adjacency: Adjacency = {super_name[c]: {} for c in refined_ids}
    for node in nodes:
        source = super_name[refined[node]]
        for neighbor, weight in adjacency[node].items():
            target = super_name[refined[neighbor]]
            if source <= target:
                new_adjacency[source][target] = new_adjacency[source].get(target, 0.0) + weight
    for source, neighbors in list(new_adjacency.items()):
        for target, weight in list(neighbors.items()):
            if source != target:
                new_adjacency[target][source] = weight

    new_weight = {
        super_name[c]: sum(node_weight[m] for m in members_by_refined[c]) for c in refined_ids
    }
    new_membership = {super_name[c]: membership[members_by_refined[c][0]] for c in refined_ids}
    new_node_to_original = {
        super_name[c]: [
            original for member in members_by_refined[c] for original in node_to_original[member]
        ]
        for c in refined_ids
    }
    return (
        new_adjacency,
        [super_name[c] for c in refined_ids],
        new_weight,
        new_membership,
        new_node_to_original,
    )


def _reindex(nodes: list[str], membership: dict[str, int]) -> None:
    remap: dict[int, int] = {}
    for node in nodes:
        community = membership[node]
        if community not in remap:
            remap[community] = len(remap)
        membership[node] = remap[community]


def quality(
    adjacency: Adjacency, communities: dict[str, int], options: LeidenOptions | None = None
) -> float:
    options = options or LeidenOptions()
    if not adjacency:
        return 0.0
    total_weight = sum(sum(neighbors.values()) for neighbors in adjacency.values()) / 2
    if total_weight == 0:
        return math.nan
    resolution = _effective_resolution(options, total_weight, len(adjacency))
    node_weight = _node_weights(adjacency, sorted(adjacency), options)

    internal = 0.0
    for source, neighbors in adjacency.items():
        source_community = communities[source]
        for target, weight in neighbors.items():
            if communities[target] == source_community:
                internal += weight

    cluster_weight: dict[int, float] = {}
    for node in adjacency:
        community = communities[node]
        cluster_weight[community] = cluster_weight.get(community, 0.0) + node_weight[node]
    squared = sum(weight * weight for weight in cluster_weight.values())
    return (internal - resolution * squared) / (2.0 * total_weight)


def modularity(adjacency: Adjacency, communities: dict[str, int]) -> float:
    value = quality(adjacency, communities, LeidenOptions(objective=Objective.MODULARITY))
    return 0.0 if math.isnan(value) else value
