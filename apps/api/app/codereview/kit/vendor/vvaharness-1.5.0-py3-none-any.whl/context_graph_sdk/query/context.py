# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Bounded project-local symbol context queries."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from typing import cast

from context_graph_sdk.errors import (
    StructuredQueryLimitError,
    SymbolAmbiguousError,
    SymbolNotFoundError,
)
from context_graph_sdk.models import FrozenMap, PropertyValue
from context_graph_sdk.symbols import SYMBOL_LABELS

from .results import (
    ContextLimits,
    ContextResult,
    EntityReference,
    RelationshipDirection,
    RelationshipGroup,
    SymbolSelector,
    TraversalPath,
    entity_sort_key,
)

ExecuteQuery = Callable[[str, Mapping[str, object], int], tuple[FrozenMap, ...]]

CALL_RELATIONSHIPS = ("CALLS", "DELEGATES_TO", "SPAWNS")
CONTEXT_RELATIONSHIPS = (
    "ACCESSES",
    "CALLS",
    "DEFINES",
    "DELEGATES_TO",
    "DEPENDS_ON",
    "HAS_METHOD",
    "HAS_PROPERTY",
    "IMPLEMENTS",
    "IMPORTS",
    "INHERITS",
    "OVERRIDES",
    "SPAWNS",
    "STEP_IN_PROCESS",
    "USES",
)


@dataclass(frozen=True)
class _Neighbor:
    current_id: str
    edge_id: str
    relationship_type: str
    entity: EntityReference


@dataclass(frozen=True)
class _FrontierPath:
    nodes: tuple[EntityReference, ...]
    relationships: tuple[str, ...]


def project_context(
    execute: ExecuteQuery,
    selector: SymbolSelector,
    limits: ContextLimits,
) -> ContextResult:
    symbol = select_symbol(execute, selector, limits.candidate_limit)
    incoming = _neighbors(
        execute,
        (symbol.id,),
        RelationshipDirection.INCOMING,
        CONTEXT_RELATIONSHIPS,
        limits.max_edges,
    )
    outgoing = _neighbors(
        execute,
        (symbol.id,),
        RelationshipDirection.OUTGOING,
        CONTEXT_RELATIONSHIPS,
        limits.max_edges,
    )
    immediate = (*incoming, *outgoing)
    if len(immediate) > limits.max_edges:
        raise StructuredQueryLimitError("context relationship edge limit exceeded")
    imports = _file_imports(execute, symbol, limits.group_limit)
    entities = {neighbor.entity.id for neighbor in immediate}
    entities.update(entity.id for entity in imports)
    if len(entities) + 1 > limits.max_nodes:
        raise StructuredQueryLimitError("context node limit exceeded")

    groups: dict[tuple[str, RelationshipDirection], dict[str, EntityReference]] = defaultdict(dict)
    for direction, neighbors in (
        (RelationshipDirection.INCOMING, incoming),
        (RelationshipDirection.OUTGOING, outgoing),
    ):
        for neighbor in neighbors:
            groups[(neighbor.relationship_type, direction)][neighbor.entity.id] = neighbor.entity
    oversized_group = next(
        (key for key, group in groups.items() if len(group) > limits.group_limit), None
    )
    if oversized_group is not None:
        raise StructuredQueryLimitError(
            f"context relationship group limit exceeded: {oversized_group[0]}"
        )
    relationship_groups = tuple(
        RelationshipGroup(
            relationship,
            direction,
            tuple(sorted(group.values(), key=entity_sort_key)),
        )
        for (relationship, direction), group in sorted(
            groups.items(), key=lambda item: (item[0][0], item[0][1].value)
        )
    )
    call_paths = traverse_paths(
        execute,
        symbol,
        RelationshipDirection.OUTGOING,
        CALL_RELATIONSHIPS,
        limits.call_depth,
        limits.max_nodes,
        limits.max_edges,
        limits.max_paths,
    )
    return ContextResult(
        symbol,
        _unique_entities(
            neighbor.entity
            for neighbor in incoming
            if neighbor.relationship_type in CALL_RELATIONSHIPS
        ),
        _unique_entities(
            neighbor.entity
            for neighbor in outgoing
            if neighbor.relationship_type in CALL_RELATIONSHIPS
        ),
        imports,
        _unique_entities(
            neighbor.entity
            for neighbor in incoming
            if neighbor.relationship_type in {"IMPLEMENTS", "INHERITS"}
        ),
        _unique_entities(
            neighbor.entity
            for neighbor in immediate
            if neighbor.relationship_type == "STEP_IN_PROCESS"
            or "Process" in neighbor.entity.labels
        ),
        relationship_groups,
        call_paths,
    )


def _file_imports(
    execute: ExecuteQuery,
    symbol: EntityReference,
    limit: int,
) -> tuple[EntityReference, ...]:
    if symbol.file_path is None:
        return ()
    query = (
        "MATCH (file:File {filePath:$filePath})-[:IMPORTS]->(neighbor) "
        "RETURN neighbor.id AS id,neighbor.localId AS localId,neighbor.name AS name,"
        "labels(neighbor) AS labels,neighbor.filePath AS filePath,"
        "neighbor.startLine AS startLine,neighbor.endLine AS endLine "
        "ORDER BY filePath,startLine,id LIMIT $limit"
    )
    rows = execute(query, {"filePath": symbol.file_path, "limit": limit + 1}, limit + 1)
    if len(rows) > limit:
        raise StructuredQueryLimitError("context import limit exceeded")
    return _unique_entities(_entity(row) for row in rows)


def is_symbol_entity(entity: EntityReference) -> bool:
    return bool(SYMBOL_LABELS.difference({"Module"}).intersection(entity.labels)) or (
        "Symbol" in entity.labels and "Module" in entity.labels
    )


def select_symbol(
    execute: ExecuteQuery,
    selector: SymbolSelector,
    candidate_limit: int,
) -> EntityReference:
    return _select_entity(execute, selector, candidate_limit, symbol_only=True)


def select_entity(
    execute: ExecuteQuery,
    selector: SymbolSelector,
    candidate_limit: int,
) -> EntityReference:
    return _select_entity(execute, selector, candidate_limit, symbol_only=False)


def _select_entity(
    execute: ExecuteQuery,
    selector: SymbolSelector,
    candidate_limit: int,
    *,
    symbol_only: bool,
) -> EntityReference:
    clauses = ["(n.id=$value OR n.localId=$value OR n.name=$value)"]
    parameters: dict[str, object] = {"value": selector.value}
    if selector.file_path is not None:
        clauses.append("n.filePath=$filePath")
        parameters["filePath"] = selector.file_path
    if selector.line is not None:
        clauses.append("n.startLine <= $line AND n.endLine >= $line")
        parameters["line"] = selector.line
    if symbol_only:
        clauses.append(
            "('Symbol' IN labels(n) OR any(label IN labels(n) WHERE label IN $symbolLabels))"
        )
        clauses.append("(NOT 'Module' IN labels(n) OR 'Symbol' IN labels(n))")
        parameters["symbolLabels"] = sorted(SYMBOL_LABELS)
    query = (
        "MATCH (n) WHERE "
        + " AND ".join(clauses)
        + " RETURN n.id AS id,n.localId AS localId,n.name AS name,labels(n) AS labels,"
        "n.filePath AS filePath,n.startLine AS startLine,n.endLine AS endLine "
        "ORDER BY filePath,startLine,id LIMIT $limit"
    )
    parameters["limit"] = candidate_limit + 1
    rows = execute(query, parameters, candidate_limit + 1)
    candidates_by_id = {
        entity.id: entity
        for row in rows
        for entity in (_entity(row),)
        if not symbol_only or is_symbol_entity(entity)
    }
    exact = {
        entity_id: entity
        for entity_id, entity in candidates_by_id.items()
        if entity.id == selector.value or entity.local_id == selector.value
    }
    candidates = tuple(sorted((exact or candidates_by_id).values(), key=entity_sort_key))
    if not candidates:
        raise SymbolNotFoundError(selector.value)
    if len(candidates) > 1:
        raise SymbolAmbiguousError(selector.value, tuple(entity.id for entity in candidates))
    return next(iter(candidates))


def traverse_paths(
    execute: ExecuteQuery,
    start: EntityReference,
    direction: RelationshipDirection,
    relationship_types: tuple[str, ...],
    max_depth: int,
    max_nodes: int,
    max_edges: int,
    max_paths: int,
) -> tuple[TraversalPath, ...]:
    if max_depth == 0:
        return ()
    paths: list[TraversalPath] = []
    frontier = [_FrontierPath((start,), ())]
    current_entities = (start,)
    seen_nodes = {start.id}
    seen_edges: set[str] = set()
    seen_paths: set[tuple[tuple[str, ...], tuple[str, ...]]] = set()
    for _ in range(max_depth):
        neighbors = _neighbors(
            execute,
            tuple(entity.id for entity in current_entities),
            direction,
            relationship_types,
            max_edges,
        )
        adjacency: dict[str, list[_Neighbor]] = defaultdict(list)
        for neighbor in neighbors:
            adjacency[neighbor.current_id].append(neighbor)
            seen_edges.add(neighbor.edge_id)
        if len(seen_edges) > max_edges:
            raise StructuredQueryLimitError("traversal edge limit exceeded")
        next_frontier: list[_FrontierPath] = []
        for path in frontier:
            current_id = path.nodes[-1].id
            base_nodes = path.nodes
            base_relationships = path.relationships
            for neighbor in sorted(
                adjacency.get(current_id, ()),
                key=lambda item: (item.entity.id, item.relationship_type, item.edge_id),
            ):
                if neighbor.entity.id in {entity.id for entity in base_nodes}:
                    continue
                candidate = TraversalPath(
                    (*base_nodes, neighbor.entity),
                    (*base_relationships, neighbor.relationship_type),
                )
                candidate_key = _path_key(candidate)
                if candidate_key in seen_paths:
                    continue
                seen_paths.add(candidate_key)
                next_frontier.append(_FrontierPath(candidate.nodes, candidate.relationships))
                paths.append(candidate)
                seen_nodes.add(neighbor.entity.id)
                if len(seen_nodes) > max_nodes:
                    raise StructuredQueryLimitError("traversal node limit exceeded")
                if len(paths) > max_paths:
                    raise StructuredQueryLimitError("traversal path limit exceeded")
        if not next_frontier:
            break
        next_frontier.sort(key=_frontier_key)
        frontier = next_frontier
        current_entities = tuple(path.nodes[-1] for path in next_frontier)
    return tuple(sorted(paths, key=_path_key))


def _neighbors(
    execute: ExecuteQuery,
    current_ids: tuple[str, ...],
    direction: RelationshipDirection,
    relationship_types: tuple[str, ...],
    max_edges: int,
) -> tuple[_Neighbor, ...]:
    if not current_ids:
        return ()
    if direction == RelationshipDirection.OUTGOING:
        pattern = "(current)-[r]->(neighbor)"
    else:
        pattern = "(neighbor)-[r]->(current)"
    query = (
        f"MATCH {pattern} WHERE current.id IN $ids AND type(r) IN $relationships "
        "RETURN current.id AS currentId,r.id AS edgeId,type(r) AS relationship,"
        "neighbor.id AS id,neighbor.localId AS localId,neighbor.name AS name,"
        "labels(neighbor) AS labels,neighbor.filePath AS filePath,"
        "neighbor.startLine AS startLine,neighbor.endLine AS endLine "
        "ORDER BY currentId,relationship,filePath,startLine,id LIMIT $limit"
    )
    rows = execute(
        query,
        {
            "ids": list(current_ids),
            "relationships": list(relationship_types),
            "limit": max_edges + 1,
        },
        max_edges + 1,
    )
    if len(rows) > max_edges:
        raise StructuredQueryLimitError("traversal edge limit exceeded")
    return tuple(
        _Neighbor(
            str(row["currentId"]),
            str(row["edgeId"]),
            str(row["relationship"]),
            _entity(row),
        )
        for row in rows
    )


def _entity(row: FrozenMap) -> EntityReference:
    labels_value = row["labels"]
    labels = tuple(str(label) for label in cast(tuple[PropertyValue, ...], labels_value))
    return EntityReference(
        str(row["id"]),
        str(row["localId"]),
        str(row["name"] or ""),
        labels,
        str(row["filePath"]) if row["filePath"] is not None else None,
        cast(int | None, row["startLine"]),
        cast(int | None, row["endLine"]),
    )


def _unique_entities(entities: Iterable[EntityReference]) -> tuple[EntityReference, ...]:
    unique: dict[str, EntityReference] = {}
    for entity in entities:
        unique[entity.id] = entity
    return tuple(sorted(unique.values(), key=entity_sort_key))


def _path_key(path: TraversalPath) -> tuple[tuple[str, ...], tuple[str, ...]]:
    return (tuple(entity.id for entity in path.nodes), path.relationships)


def _frontier_key(path: _FrontierPath) -> tuple[tuple[str, ...], tuple[str, ...]]:
    return (tuple(entity.id for entity in path.nodes), path.relationships)
