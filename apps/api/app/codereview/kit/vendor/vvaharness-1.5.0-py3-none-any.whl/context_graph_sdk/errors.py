# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Typed errors shared by backend-neutral SDK contracts."""

from __future__ import annotations


class ContextGraphError(Exception):
    """Base class for SDK failures."""


class ModelValidationError(ContextGraphError, ValueError):
    """A graph or identity value violates a persisted-data invariant."""


class ResolutionLimitError(ContextGraphError):
    """Resolution exceeded an explicit graph-growth bound."""


class LifecycleError(ContextGraphError):
    """A workspace or snapshot resource is not in the required state."""


class WorkspaceClosedError(LifecycleError):
    """An operation was attempted after workspace closure."""


class WorkspaceLockedError(LifecycleError):
    """Another manager process owns the workspace directory."""


class SnapshotLifecycleError(LifecycleError):
    """An accepted or leased snapshot cannot be resolved safely."""


class DiscoveryError(ContextGraphError):
    """Repository discovery input is unsafe, unreadable, or over a bound."""


class QueryError(ContextGraphError):
    """Base class for project-query failures."""


class QueryValidationError(QueryError):
    """Cypher is outside the accepted read-only subset."""


class QueryTimeoutError(QueryError):
    """The manager terminated a query worker at its deadline."""


class QueryCancelledError(QueryError):
    """The caller cancelled an in-flight worker request."""


class QueryResourceLimitError(QueryError):
    """A worker, row, or serialized-byte limit was exceeded."""


class QueryWorkerError(QueryError):
    """The worker crashed or violated its lifecycle contract."""


class QueryProtocolError(QueryError):
    """A bounded worker IPC frame was malformed."""


class StructuredQueryError(QueryError):
    """A bounded model-facing graph operation failed."""


class SymbolNotFoundError(StructuredQueryError):
    def __init__(self, selector: str) -> None:
        self.selector = selector
        super().__init__(f"symbol not found: {selector}")


class SymbolAmbiguousError(StructuredQueryError):
    def __init__(self, selector: str, candidate_ids: tuple[str, ...]) -> None:
        self.selector = selector
        self.candidate_ids = candidate_ids
        super().__init__(f"symbol is ambiguous: {selector} ({len(candidate_ids)} candidates)")


class StructuredQueryLimitError(StructuredQueryError):
    """A structured traversal exceeded an explicit graph bound."""


class PluginError(ContextGraphError):
    """A trusted plugin failed in a named execution phase."""

    def __init__(
        self,
        plugin_name: str,
        phase: str,
        message: str,
        *,
        context: str | None = None,
    ) -> None:
        self.plugin_name = plugin_name
        self.phase = phase
        self.context = context
        suffix = f" ({context})" if context else ""
        super().__init__(f"{plugin_name} [{phase}]{suffix}: {message}")
