# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Reusable worker loop for bounded extraction subprocesses."""

from __future__ import annotations

import pickle
from pathlib import Path
from typing import cast

from context_graph_sdk._process import ByteReader, ByteWriter
from context_graph_sdk.errors import ModelValidationError
from context_graph_sdk.extractors.records import FileExtraction
from context_graph_sdk.extractors.runtime import MAX_SOURCE_BYTES


def extract_work_item(root: str, relative_path: str, language: str) -> FileExtraction:
    """Read and extract one repository file inside a supervised child."""
    from context_graph_sdk.extractors.extract import extract_file

    path = Path(root) / relative_path
    if path.stat().st_size > MAX_SOURCE_BYTES:
        raise ModelValidationError("source exceeds the extraction size bound")
    return extract_file(relative_path, path.read_bytes(), language)


def extraction_worker(
    root: str,
    requests: ByteReader,
    responses: ByteWriter,
    max_request_bytes: int,
    max_result_bytes: int,
) -> None:
    """Serve bounded extraction requests until the parent closes the pool."""
    try:
        while True:
            try:
                payload = requests.recv_bytes(max_request_bytes)
            except EOFError:
                return
            if not payload:
                return
            try:
                decoded: object = pickle.loads(payload)
                if not isinstance(decoded, tuple):
                    raise ValueError("invalid request shape")
                request = cast(tuple[object, ...], decoded)
                if (
                    len(request) != 3
                    or not isinstance(request[0], int)
                    or not isinstance(request[1], str)
                    or not isinstance(request[2], str)
                ):
                    raise ValueError("invalid request shape")
                index = request[0]
                relative_path = request[1]
                language = request[2]
                try:
                    result: tuple[int, bool, object] = (
                        index,
                        True,
                        extract_work_item(root, relative_path, language),
                    )
                except BaseException as error:
                    result = (index, False, f"{type(error).__name__}: {error}")
            except Exception as error:
                result = (-1, False, f"extraction worker protocol failure: {error}")
            response = pickle.dumps(result, protocol=pickle.HIGHEST_PROTOCOL)
            if len(response) > max_result_bytes:
                response = pickle.dumps(
                    (
                        result[0],
                        False,
                        f"extraction result exceeds {max_result_bytes} byte IPC bound",
                    ),
                    protocol=pickle.HIGHEST_PROTOCOL,
                )
            responses.send_bytes(response)
    finally:
        requests.close()
        responses.close()
