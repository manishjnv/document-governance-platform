# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""vcpkg.json parsing."""

from __future__ import annotations

from context_graph_sdk.project.config import DependencyRecord, ManifestReader, ProjectConfig

from ._data import as_list, as_mapping, as_str, parse_json_object


def load_vcpkg_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("vcpkg.json"):
        if relative != "vcpkg.json":
            continue
        text = reader.read_text(relative)
        parsed = parse_json_object(text) if text is not None else None
        if parsed is None:
            continue
        for entry in as_list(parsed.get("dependencies")):
            if isinstance(entry, str):
                config.add_dependency(DependencyRecord(entry, "", relative))
                continue
            mapping = as_mapping(entry)
            if mapping is None:
                continue
            name = as_str(mapping.get("name"))
            if not name:
                continue
            version = as_str(mapping.get("version>=")) or as_str(mapping.get("version"))
            config.add_dependency(DependencyRecord(name, version, relative))
