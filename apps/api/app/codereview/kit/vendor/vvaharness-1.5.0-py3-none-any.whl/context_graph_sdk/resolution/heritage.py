# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Explicit heritage edges and structural interface inference."""

from __future__ import annotations

from context_graph_sdk.extractors.records import Symbol
from context_graph_sdk.models import LocalRelationshipType
from context_graph_sdk.resolution.context import ResolutionContext, ResolutionResult

# One label set shared by parent preference, MRO, and structural matching.
CLASS_LIKE_LABELS = ("Class", "Interface", "Struct", "Trait")


def _resolve_parent(context: ResolutionContext, name: str, child_file: str) -> Symbol | None:
    """Prefer class-like labels, then a same-file parent within each label."""
    candidates = context.symbols_by_name.get(name, [])
    if not candidates:
        return None
    for label in CLASS_LIKE_LABELS:
        labelled = [candidate for candidate in candidates if candidate.label == label]
        if not labelled:
            continue
        for candidate in labelled:
            if candidate.file_path == child_file:
                return candidate
        return labelled[0]
    return candidates[0]


def resolve_heritage(context: ResolutionContext, result: ResolutionResult) -> None:
    for path, file_result in context.extraction.files:
        for heritage in file_result.heritage:
            # The child declaration lexically lives in the record's file.
            children = [
                candidate
                for candidate in context.symbols_by_name.get(heritage.class_name, [])
                if candidate.file_path == path
            ]
            if not children:
                continue
            child = children[0]
            parent = _resolve_parent(context, heritage.parent_name, path)
            if parent is None:
                continue
            if heritage.kind == "extends":
                # Kotlin/C#/Swift use one syntax for both; an interface or
                # trait parent means this is an IMPLEMENTS relationship.
                relationship = (
                    LocalRelationshipType.IMPLEMENTS
                    if parent.label in ("Interface", "Trait")
                    else LocalRelationshipType.INHERITS
                )
            elif heritage.kind in ("implements", "trait"):
                relationship = LocalRelationshipType.IMPLEMENTS
            else:
                continue
            result.add_edge(child.id, relationship, parent.id)


def _methods_by_owner(context: ResolutionContext) -> dict[str, dict[str, list[Symbol]]]:
    """Group methods by owner name and file to avoid cross-file ambiguity."""
    by_owner: dict[str, dict[str, list[Symbol]]] = {}
    for symbol in context.symbols:
        if symbol.label != "Method" or not symbol.owner_name:
            continue
        owner_key = f"{symbol.file_path}\x00{symbol.owner_name}"
        by_owner.setdefault(owner_key, {}).setdefault(symbol.name, []).append(symbol)
    return by_owner


def resolve_structural_interfaces(context: ResolutionContext, result: ResolutionResult) -> None:
    methods = _methods_by_owner(context)

    def method_names(owner: Symbol) -> set[str]:
        return set(methods.get(f"{owner.file_path}\x00{owner.name}", {}))

    interfaces = [
        (symbol, method_names(symbol))
        for symbol in context.symbols
        if symbol.label == "Interface" and method_names(symbol)
    ]
    if not interfaces:
        return
    existing_implements: set[tuple[str, str]] = {
        (edge.source_local_id, edge.target_local_id)
        for edge in result.edges
        if edge.relationship is LocalRelationshipType.IMPLEMENTS
    }
    # Partition candidates by method name so each interface only tests the
    # classes that own its rarest required method instead of every class.
    classes = [
        (symbol, method_names(symbol))
        for symbol in context.symbols
        if symbol.label in ("Struct", "Class") and method_names(symbol)
    ]
    owners_by_method: dict[str, list[int]] = {}
    for index, (_, names) in enumerate(classes):
        for name in names:
            owners_by_method.setdefault(name, []).append(index)
    for interface, required in interfaces:
        rarest = min(required, key=lambda name: (len(owners_by_method.get(name, [])), name))
        for index in owners_by_method.get(rarest, []):
            symbol, own = classes[index]
            if (symbol.id, interface.id) in existing_implements:
                continue
            if required <= own:
                result.add_edge(symbol.id, LocalRelationshipType.IMPLEMENTS, interface.id)
