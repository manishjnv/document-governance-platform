# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""JVM/.NET family enhancement passes (Kotlin, Scala, C#)."""

from __future__ import annotations

from dataclasses import replace

from tree_sitter import Node

from context_graph_sdk.extractors.analysis import node_text, walk
from context_graph_sdk.extractors.records import (
    Call,
    MutableFileResult,
    Symbol,
    is_valid_symbol_name,
    symbol_id,
)

_NAME_FALLBACK_TYPES = ("type_identifier", "identifier", "simple_identifier")


def _class_like_name(node: Node, source: bytes) -> str:
    name_node = node.child_by_field_name("name")
    if name_node is not None:
        return node_text(name_node, source)
    for child in node.children:
        if child.type.lower() in _NAME_FALLBACK_TYPES:
            return node_text(child, source)
    return ""


def reclassify_interface_declarations(
    root: Node, source: bytes, relative_path: str, _language: str, result: MutableFileResult
) -> None:
    """Kotlin grammars parse interfaces as class_declaration with an
    `interface` keyword token; reclassify matching Class symbols."""
    interface_names: set[str] = set()

    def visit(node: Node, _depth: int) -> str | None:
        if "class_declaration" not in node.type.lower():
            return None
        keyword = any(
            not child.is_named and node_text(child, source) == "interface"
            for child in node.children
        )
        if keyword:
            name = _class_like_name(node, source)
            if name:
                interface_names.add(name)
        return None

    walk(root, visit)
    for index, symbol in enumerate(result.symbols):
        if symbol.label == "Class" and symbol.name in interface_names:
            result.symbols[index] = replace(
                symbol,
                label="Interface",
                id=symbol_id("Interface", relative_path, symbol.name, ""),
            )


def extract_infix_calls(
    root: Node, source: bytes, relative_path: str, _language: str, result: MutableFileResult
) -> None:
    """Kotlin/Scala infix expressions call the middle identifier."""

    def visit(node: Node, _depth: int) -> str | None:
        if node.type.lower() not in ("infix_expression", "infix_call"):
            return None
        if node.child_count < 3:
            return None
        for index in range(1, node.child_count - 1):
            child = node.child(index)
            if child is not None and "identifier" in child.type.lower():
                callee = node_text(child, source)
                # Operator identifiers (`+`, `::`, arithmetic noise) also
                # surface as identifier nodes; only well-formed names count.
                if callee and is_valid_symbol_name(callee) and not _is_operator_noise(callee):
                    result.calls.append(Call(relative_path, callee, "", node.start_point.row))
                break
        return None

    walk(root, visit)


def _is_operator_noise(callee: str) -> bool:
    # is_valid_symbol_name allows `-` `.` `:` for other languages' names;
    # a callee made only of those characters is operator punctuation.
    return all(char in "-.:@$" for char in callee)


def extract_primary_constructor_params(
    root: Node, source: bytes, relative_path: str, language: str, result: MutableFileResult
) -> None:
    """Primary constructor parameter lists become Constructor symbols when
    no explicit constructor exists (C# 12, Kotlin, Scala)."""
    class_names = {
        symbol.name for symbol in result.symbols if symbol.label in ("Class", "Struct", "Record")
    }
    owners_with_constructor = {
        symbol.owner_name for symbol in result.symbols if symbol.label == "Constructor"
    }
    additions: list[Symbol] = []

    def visit(node: Node, _depth: int) -> str | None:
        node_type = node.type.lower()
        if "class" not in node_type and "record" not in node_type:
            return None
        class_name = _class_like_name(node, source)
        if not class_name or class_name not in class_names:
            return None
        parameter_list: Node | None = None
        for child in node.children:
            if child.is_named and child.type.lower() in ("parameter_list", "primary_constructor"):
                parameter_list = child
                break
        if parameter_list is None:
            return None
        parameter_count = sum(
            1
            for child in parameter_list.children
            if child.is_named and "parameter" in child.type.lower()
        )
        if parameter_count == 0 or class_name in owners_with_constructor:
            return None
        owners_with_constructor.add(class_name)
        additions.append(
            Symbol(
                id=symbol_id("Constructor", relative_path, class_name, class_name),
                name=class_name,
                label="Constructor",
                file_path=relative_path,
                start_line=parameter_list.start_point.row,
                end_line=parameter_list.end_point.row,
                is_exported=True,
                language=language,
                content=node_text(parameter_list, source),
                owner_name=class_name,
                parameter_count=parameter_count,
            )
        )
        return None

    walk(root, visit)
    result.symbols.extend(additions)
