# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Private no-fork subprocess transport for native-runtime workers."""

from __future__ import annotations

import os
import struct
import subprocess
import sys
import threading
from collections import deque
from collections.abc import Callable
from contextlib import suppress
from typing import BinaryIO, Protocol, cast

_FRAME_HEADER = struct.Struct("!I")
_MAX_FRAME_BYTES = (1 << (_FRAME_HEADER.size * 8)) - 1


class ByteReader(Protocol):
    def recv_bytes(self, maximum: int) -> bytes: ...

    def close(self) -> None: ...


class ByteWriter(Protocol):
    def send_bytes(self, payload: bytes) -> None: ...

    def close(self) -> None: ...


class FrameReader:
    """Read bounded length-prefixed frames from one binary stream."""

    def __init__(self, stream: BinaryIO) -> None:
        self._stream = stream

    def recv_bytes(self, maximum: int) -> bytes:
        header = _read_exact(self._stream, _FRAME_HEADER.size)
        size = _FRAME_HEADER.unpack(header)[0]
        if size > maximum:
            raise OSError(f"message length {size} exceeds {maximum} byte bound")
        return _read_exact(self._stream, size)

    def close(self) -> None:
        self._stream.close()


class FrameWriter:
    """Write length-prefixed frames to one binary stream."""

    def __init__(self, stream: BinaryIO) -> None:
        self._stream = stream
        self._lock = threading.Lock()

    def send_bytes(self, payload: bytes) -> None:
        if len(payload) > _MAX_FRAME_BYTES:
            raise ValueError("payload exceeds framing limit")
        with self._lock:
            _write_all(self._stream, _FRAME_HEADER.pack(len(payload)))
            _write_all(self._stream, payload)
            self._stream.flush()

    def close(self) -> None:
        self._stream.close()


class StdioChannel:
    """Asynchronous framed requests and responses over a child's standard streams."""

    def __init__(
        self,
        request_stream: BinaryIO,
        response_stream: BinaryIO,
        maximum_response_bytes: int,
        on_response: Callable[[StdioChannel], None] | None = None,
    ) -> None:
        self._request = FrameWriter(request_stream)
        self._response = FrameReader(response_stream)
        self._maximum_response_bytes = maximum_response_bytes
        self._on_response = on_response
        self._condition = threading.Condition()
        self._messages: deque[bytes | BaseException] = deque()
        self._closed = False
        self._reader = threading.Thread(
            target=self._read_responses,
            name="context-graph-worker-reader",
            daemon=True,
        )
        self._reader.start()

    def send_bytes(self, payload: bytes) -> None:
        self._request.send_bytes(payload)

    def poll(self, timeout: float) -> bool:
        with self._condition:
            return self._condition.wait_for(lambda: bool(self._messages), timeout)

    def recv_bytes(self, maximum: int) -> bytes:
        with self._condition:
            if not self._messages:
                raise BlockingIOError("worker response is not ready")
            message = self._messages.popleft()
        if isinstance(message, BaseException):
            raise message
        if len(message) > maximum:
            raise OSError(f"message length {len(message)} exceeds {maximum} byte bound")
        return message

    def close_request(self) -> None:
        with suppress(OSError):
            self._request.close()

    def close(self) -> None:
        with self._condition:
            if self._closed:
                return
            self._closed = True
        self.close_request()
        with suppress(OSError):
            self._response.close()
        if threading.current_thread() is not self._reader:
            self._reader.join(2.0)

    def _read_responses(self) -> None:
        while True:
            try:
                message: bytes | BaseException = self._response.recv_bytes(
                    self._maximum_response_bytes
                )
            except BaseException as error:
                message = error
            with self._condition:
                if self._closed:
                    return
                if self._messages:
                    message = OSError("worker produced more than one pending response")
                    self._messages.clear()
                self._messages.append(message)
                self._condition.notify_all()
            if self._on_response is not None:
                with suppress(Exception):
                    self._on_response(self)
            if isinstance(message, BaseException):
                return


def spawn_stdio_worker(
    module: str,
    *arguments: str,
    maximum_response_bytes: int = 64 * 1024 * 1024,
    on_response: Callable[[StdioChannel], None] | None = None,
) -> tuple[subprocess.Popen[bytes], StdioChannel]:
    """Launch through the safest native subprocess path on each platform.

    POSIX keeps ``close_fds=False`` and passes no descriptors explicitly so
    CPython can use ``posix_spawn`` instead of ``fork_exec``. Forking after the
    host has initialized Tree-sitter or the embedded JVM is unsafe on macOS.
    Python-created descriptors are non-inheritable by default, and all worker
    traffic remains on standard input/output.

    Windows has no fork hazard, so ``close_fds=True`` prevents unrelated
    inheritable handles from an embedding host such as VVAH reaching workers.
    The framed stream transport deliberately uses the ``Popen`` file objects
    rather than treating their CRT descriptors as multiprocessing sockets.
    """
    process = subprocess.Popen(
        [sys.executable, "-m", module, *arguments],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        close_fds=os.name == "nt",
        bufsize=0,
    )
    if process.stdin is None or process.stdout is None:
        _terminate_failed_spawn(process)
        raise RuntimeError("worker standard streams were not created")
    try:
        channel = StdioChannel(
            cast(BinaryIO, process.stdin),
            cast(BinaryIO, process.stdout),
            maximum_response_bytes,
            on_response,
        )
    except Exception:
        process.stdin.close()
        process.stdout.close()
        _terminate_failed_spawn(process)
        raise
    return process, channel


def _read_exact(stream: BinaryIO, size: int) -> bytes:
    chunks: list[bytes] = []
    remaining = size
    while remaining:
        chunk = stream.read(remaining)
        if not chunk:
            raise EOFError
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def _write_all(stream: BinaryIO, payload: bytes) -> None:
    view = memoryview(payload)
    while view:
        written = stream.write(view)
        if written is None or written <= 0:
            raise BrokenPipeError("worker stream closed during write")
        view = view[written:]


def _terminate_failed_spawn(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    process.terminate()
    with suppress(subprocess.TimeoutExpired):
        process.wait(5.0)
    if process.poll() is None:
        process.kill()
        with suppress(subprocess.TimeoutExpired):
            process.wait(2.0)
