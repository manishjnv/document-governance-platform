# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Immutable results and limits for project-local structured graph operations."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from context_graph_sdk.errors import ModelValidationError
from context_graph_sdk.models import (
    CorrelationEndpointRole,
    CorrelationType,
    FrozenMap,
    NodeRef,
    ProjectSnapshot,
)

DEFAULT_SYMBOL_CANDIDATE_LIMIT = 20


class RelationshipDirection(StrEnum):
    INCOMING = "incoming"
    OUTGOING = "outgoing"


class ImpactDirection(StrEnum):
    UPSTREAM = "upstream"
    DOWNSTREAM = "downstream"


@dataclass(frozen=True)
class SymbolSelector:
    value: str
    file_path: str | None = None
    line: int | None = None

    def __post_init__(self) -> None:
        if not self.value:
            raise ModelValidationError("symbol selector value is required")
        if self.line is not None and self.line < 0:
            raise ModelValidationError("symbol selector line cannot be negative")


@dataclass(frozen=True)
class EntityReference:
    id: str
    local_id: str
    name: str
    labels: tuple[str, ...]
    file_path: str | None = None
    start_line: int | None = None
    end_line: int | None = None

    def __post_init__(self) -> None:
        if not self.id or not self.local_id or not self.labels:
            raise ModelValidationError("entity reference requires id, local_id, and labels")
        object.__setattr__(self, "labels", tuple(sorted(set(self.labels))))


@dataclass(frozen=True)
class RelationshipGroup:
    relationship_type: str
    direction: RelationshipDirection
    entities: tuple[EntityReference, ...]

    def __post_init__(self) -> None:
        if not self.relationship_type:
            raise ModelValidationError("relationship group type is required")


@dataclass(frozen=True)
class TraversalPath:
    nodes: tuple[EntityReference, ...]
    relationships: tuple[str, ...]

    def __post_init__(self) -> None:
        if len(self.nodes) < 2 or len(self.relationships) != len(self.nodes) - 1:
            raise ModelValidationError("traversal path nodes and relationships do not align")

    @property
    def depth(self) -> int:
        return len(self.relationships)


@dataclass(frozen=True)
class ContextLimits:
    candidate_limit: int = DEFAULT_SYMBOL_CANDIDATE_LIMIT
    group_limit: int = 100
    call_depth: int = 3
    max_nodes: int = 500
    max_edges: int = 1_000
    max_paths: int = 500

    def __post_init__(self) -> None:
        _bounded("candidate_limit", self.candidate_limit, 1, 100)
        _bounded("group_limit", self.group_limit, 1, 500)
        _bounded("call_depth", self.call_depth, 0, 10)
        _bounded("max_nodes", self.max_nodes, 1, 5_000)
        _bounded("max_edges", self.max_edges, 1, 10_000)
        _bounded("max_paths", self.max_paths, 1, 2_000)


@dataclass(frozen=True)
class ImpactLimits:
    candidate_limit: int = DEFAULT_SYMBOL_CANDIDATE_LIMIT
    max_depth: int = 3
    max_nodes: int = 500
    max_edges: int = 1_000
    max_paths: int = 500

    def __post_init__(self) -> None:
        _bounded("candidate_limit", self.candidate_limit, 1, 100)
        _bounded("max_depth", self.max_depth, 1, 10)
        _bounded("max_nodes", self.max_nodes, 1, 5_000)
        _bounded("max_edges", self.max_edges, 1, 10_000)
        _bounded("max_paths", self.max_paths, 1, 2_000)


@dataclass(frozen=True)
class ContextResult:
    symbol: EntityReference
    callers: tuple[EntityReference, ...]
    callees: tuple[EntityReference, ...]
    imports: tuple[EntityReference, ...]
    implementors: tuple[EntityReference, ...]
    processes: tuple[EntityReference, ...]
    relationships: tuple[RelationshipGroup, ...]
    call_paths: tuple[TraversalPath, ...]


@dataclass(frozen=True)
class CorrelationLimits:
    candidate_limit: int = DEFAULT_SYMBOL_CANDIDATE_LIMIT
    max_results: int = 100

    def __post_init__(self) -> None:
        _bounded("candidate_limit", self.candidate_limit, 1, 100)
        _bounded("max_results", self.max_results, 1, 1_000)


@dataclass(frozen=True)
class CorrelationMatch:
    relationship_type: CorrelationType
    source: NodeRef
    target: NodeRef
    queried_endpoint: CorrelationEndpointRole
    related_snapshot: ProjectSnapshot
    provider_name: str
    provider_version: str
    confidence: float
    reason: str
    evidence: FrozenMap
    context: ContextResult | None = None


@dataclass(frozen=True)
class CorrelationResult:
    source: EntityReference
    matches: tuple[CorrelationMatch, ...]


@dataclass(frozen=True)
class ImpactResult:
    symbol: EntityReference
    direction: ImpactDirection
    affected: tuple[EntityReference, ...]
    paths: tuple[TraversalPath, ...]


def entity_sort_key(entity: EntityReference) -> tuple[str, int, str]:
    return (
        entity.file_path or "",
        entity.start_line if entity.start_line is not None else -1,
        entity.id,
    )


def _bounded(name: str, value: int, minimum: int, maximum: int) -> None:
    if not minimum <= value <= maximum:
        raise ModelValidationError(f"{name} must be in [{minimum}, {maximum}]")
