# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Immutable backend-neutral graph and catalog models."""

from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from enum import StrEnum
from typing import TypeAlias, cast

from .errors import ModelValidationError
from .identity import ProjectId, SnapshotId, make_edge_id, make_global_id, validate_local_id

PropertyScalar: TypeAlias = str | int | float | bool | None
PropertyValue: TypeAlias = "PropertyScalar | tuple[PropertyValue, ...] | FrozenMap"


@dataclass(frozen=True)
class FrozenMap:
    """Recursively immutable, key-sorted property map."""

    entries: tuple[tuple[str, PropertyValue], ...] = ()

    def __post_init__(self) -> None:
        keys = [key for key, _ in self.entries]
        if any(not key for key in keys) or len(keys) != len(set(keys)):
            raise ModelValidationError("property keys must be non-empty and unique")
        if keys != sorted(keys):
            raise ModelValidationError("property keys must be sorted")
        _validate_frozen_map(self, budget=_PropertyBudget(), depth=0)

    def __getitem__(self, key: str) -> PropertyValue:
        for candidate, value in self.entries:
            if candidate == key:
                return value
        raise KeyError(key)

    def to_dict(self) -> dict[str, object]:
        return {key: thaw_value(value) for key, value in self.entries}


MAX_PROPERTY_DEPTH = 8
MAX_PROPERTY_ITEMS = 10_000


@dataclass
class _PropertyBudget:
    items: int = 0

    def consume(self, count: int) -> None:
        self.items += count
        if self.items > MAX_PROPERTY_ITEMS:
            raise ModelValidationError("property value tree exceeds aggregate item limit")


def _validate_frozen_map(value: FrozenMap, *, budget: _PropertyBudget, depth: int) -> None:
    if depth > MAX_PROPERTY_DEPTH:
        raise ModelValidationError("property nesting exceeds maximum depth")
    budget.consume(len(value.entries))
    for _, child in value.entries:
        _validate_frozen_value(child, budget=budget, depth=depth + 1)


def _validate_frozen_value(value: object, *, budget: _PropertyBudget, depth: int) -> None:
    if depth > MAX_PROPERTY_DEPTH:
        raise ModelValidationError("property nesting exceeds maximum depth")
    if value is None or isinstance(value, str | bool | int):
        return
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ModelValidationError("float properties must be finite")
        return
    if isinstance(value, FrozenMap):
        _validate_frozen_map(value, budget=budget, depth=depth)
        return
    if isinstance(value, tuple):
        sequence = cast(tuple[object, ...], value)
        budget.consume(len(sequence))
        for child in sequence:
            _validate_frozen_value(child, budget=budget, depth=depth + 1)
        return
    raise ModelValidationError(f"unsupported frozen property value: {type(value).__name__}")


def freeze_value(
    value: object,
    *,
    _depth: int = 0,
    _budget: _PropertyBudget | None = None,
) -> PropertyValue:
    budget = _budget or _PropertyBudget()
    if _depth > MAX_PROPERTY_DEPTH:
        raise ModelValidationError("property nesting exceeds maximum depth")
    if value is None or isinstance(value, str | bool | int):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ModelValidationError("float properties must be finite")
        return value
    if isinstance(value, FrozenMap):
        _validate_frozen_map(value, budget=budget, depth=_depth)
        return value
    if isinstance(value, Mapping):
        mapping = cast(Mapping[object, object], value)
        budget.consume(len(mapping))
        items: list[tuple[str, PropertyValue]] = []
        for key, child in mapping.items():
            if not isinstance(key, str) or not key:
                raise ModelValidationError("property map keys must be non-empty strings")
            items.append((key, freeze_value(child, _depth=_depth + 1, _budget=budget)))
        return FrozenMap(tuple(sorted(items)))
    if isinstance(value, Sequence) and not isinstance(value, str | bytes | bytearray):
        sequence = cast(Sequence[object], value)
        budget.consume(len(sequence))
        return tuple(freeze_value(child, _depth=_depth + 1, _budget=budget) for child in sequence)
    raise ModelValidationError(f"unsupported property value: {type(value).__name__}")


def freeze_properties(values: Mapping[str, object] | None = None) -> FrozenMap:
    frozen = freeze_value(values or {})
    return cast(FrozenMap, frozen)


def thaw_value(value: PropertyValue) -> object:
    if isinstance(value, FrozenMap):
        return value.to_dict()
    if isinstance(value, tuple):
        return [thaw_value(item) for item in value]
    return value


class NodeLabel(StrEnum):
    PROJECT = "Project"
    FILE = "File"
    FOLDER = "Folder"
    MODULE = "Module"
    DEPENDENCY = "Dependency"
    SYMBOL = "Symbol"
    COMMUNITY = "Community"
    PROCESS = "Process"
    PROJECT_SNAPSHOT = "ProjectSnapshot"
    NODE_REF = "NodeRef"


class LocalRelationshipType(StrEnum):
    CONTAINS = "CONTAINS"
    DEFINES = "DEFINES"
    IMPORTS = "IMPORTS"
    CALLS = "CALLS"
    SPAWNS = "SPAWNS"
    DELEGATES_TO = "DELEGATES_TO"
    ACCESSES = "ACCESSES"
    USES = "USES"
    INHERITS = "INHERITS"
    IMPLEMENTS = "IMPLEMENTS"
    DEPENDS_ON = "DEPENDS_ON"
    MEMBER_OF = "MEMBER_OF"
    HAS_METHOD = "HAS_METHOD"
    HAS_PROPERTY = "HAS_PROPERTY"
    OVERRIDES = "OVERRIDES"
    STEP_IN_PROCESS = "STEP_IN_PROCESS"


class CorrelationEndpointRole(StrEnum):
    SOURCE = "source"
    TARGET = "target"


class CorrelationType(StrEnum):
    CROSS_REPO_IMPORTS = "CROSS_REPO_IMPORTS"
    CROSS_REPO_CALLS = "CROSS_REPO_CALLS"
    CROSS_REPO_DEPENDENCY = "CROSS_REPO_DEPENDENCY"
    SHARED_TYPE = "SHARED_TYPE"


CORRELATION_RELATIONSHIP_TYPES = frozenset(member.value for member in CorrelationType)


@dataclass(frozen=True)
class AnalysisVersion:
    sdk_version: str
    components: tuple[tuple[str, str], ...] = ()

    def __post_init__(self) -> None:
        if not self.sdk_version:
            raise ModelValidationError("sdk_version is required")
        names = [name for name, version in self.components if name and version]
        if len(names) != len(self.components) or len(names) != len(set(names)):
            raise ModelValidationError("analysis components require unique names and versions")
        object.__setattr__(self, "components", tuple(sorted(self.components)))


@dataclass(frozen=True)
class ProjectMetadata:
    project_id: ProjectId
    display_name: str
    source_path: str | None = None
    source_url: str | None = None
    revision: str | None = None

    def __post_init__(self) -> None:
        if not self.display_name:
            raise ModelValidationError("display_name is required")


@dataclass(frozen=True)
class SnapshotLocator:
    project_id: ProjectId
    snapshot_id: SnapshotId
    database_path: str

    def __post_init__(self) -> None:
        if not self.database_path:
            raise ModelValidationError("database_path is required")


@dataclass(frozen=True)
class SnapshotInfo:
    """What the publisher recorded about an accepted snapshot."""

    fingerprint: str
    node_count: int
    edge_count: int


@dataclass(frozen=True)
class GraphNode:
    project_id: ProjectId
    local_id: str
    labels: tuple[str, ...]
    properties: FrozenMap = field(default_factory=FrozenMap)
    id: str = ""

    def __post_init__(self) -> None:
        validate_local_id(self.local_id)
        if not self.labels or any(not label for label in self.labels):
            raise ModelValidationError("a node requires non-empty labels")
        labels = tuple(sorted(set(self.labels)))
        object.__setattr__(self, "labels", labels)
        expected = make_global_id(self.project_id, self.local_id)
        if self.id and self.id != expected:
            raise ModelValidationError("node global id does not match project/local identity")
        object.__setattr__(self, "id", expected)


@dataclass(frozen=True)
class GraphEdge:
    project_id: ProjectId
    source_id: str
    relationship_type: str
    target_id: str
    discriminator: str = ""
    properties: FrozenMap = field(default_factory=FrozenMap)
    id: str = ""

    def __post_init__(self) -> None:
        if not self.relationship_type:
            raise ModelValidationError("relationship_type is required")
        if self.relationship_type in CORRELATION_RELATIONSHIP_TYPES:
            raise ModelValidationError(
                "cross-project relationship types belong in the correlation store"
            )
        expected = make_edge_id(
            self.project_id,
            self.source_id,
            self.relationship_type,
            self.target_id,
            self.discriminator,
        )
        if self.id and self.id != expected:
            raise ModelValidationError("edge id does not match its identity fields")
        object.__setattr__(self, "id", expected)


@dataclass(frozen=True)
class GraphSnapshot:
    project: ProjectMetadata
    snapshot_id: SnapshotId
    analysis_version: AnalysisVersion
    nodes: tuple[GraphNode, ...] = ()
    edges: tuple[GraphEdge, ...] = ()

    def __post_init__(self) -> None:
        node_ids = {node.id for node in self.nodes}
        if len(node_ids) != len(self.nodes):
            raise ModelValidationError("snapshot contains duplicate node ids")
        if any(node.project_id != self.project.project_id for node in self.nodes):
            raise ModelValidationError("snapshot nodes must belong to its project")
        correlation_labels = {NodeLabel.PROJECT_SNAPSHOT.value, NodeLabel.NODE_REF.value}
        if any(correlation_labels.intersection(node.labels) for node in self.nodes):
            raise ModelValidationError(
                "correlation-store labels cannot appear in a project snapshot"
            )
        if len({edge.id for edge in self.edges}) != len(self.edges):
            raise ModelValidationError("snapshot contains duplicate edge ids")
        for edge in self.edges:
            if edge.project_id != self.project.project_id:
                raise ModelValidationError("local edges must belong to the snapshot project")
            if edge.source_id not in node_ids or edge.target_id not in node_ids:
                raise ModelValidationError("local edge endpoints must exist in the same snapshot")
        object.__setattr__(self, "nodes", tuple(sorted(self.nodes, key=lambda node: node.id)))
        object.__setattr__(self, "edges", tuple(sorted(self.edges, key=lambda edge: edge.id)))


@dataclass(frozen=True)
class GraphMutation:
    project_id: ProjectId
    nodes: tuple[GraphNode, ...] = ()
    edges: tuple[GraphEdge, ...] = ()
    removed_node_ids: tuple[str, ...] = ()
    removed_edge_ids: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if any(node.project_id != self.project_id for node in self.nodes):
            raise ModelValidationError("mutation nodes must belong to its project")
        if any(edge.project_id != self.project_id for edge in self.edges):
            raise ModelValidationError("mutation edges must remain project-local")
        for values, name in (
            ([node.id for node in self.nodes], "node"),
            ([edge.id for edge in self.edges], "edge"),
            (list(self.removed_node_ids), "removed node"),
            (list(self.removed_edge_ids), "removed edge"),
        ):
            if len(values) != len(set(values)):
                raise ModelValidationError(f"mutation contains duplicate {name} ids")
        if {node.id for node in self.nodes}.intersection(self.removed_node_ids):
            raise ModelValidationError("mutation cannot add and remove the same node")
        if {edge.id for edge in self.edges}.intersection(self.removed_edge_ids):
            raise ModelValidationError("mutation cannot add and remove the same edge")


@dataclass(frozen=True)
class ProjectSnapshot:
    project: ProjectMetadata
    snapshot_id: SnapshotId
    locator: SnapshotLocator
    analysis_version: AnalysisVersion
    accepted: bool

    def __post_init__(self) -> None:
        if (
            self.locator.project_id != self.project.project_id
            or self.locator.snapshot_id != self.snapshot_id
        ):
            raise ModelValidationError("snapshot locator identity does not match its record")


@dataclass(frozen=True)
class NodeRef:
    project_id: ProjectId
    snapshot_id: SnapshotId
    local_id: str
    node_id: str

    def __post_init__(self) -> None:
        expected = make_global_id(self.project_id, validate_local_id(self.local_id))
        if self.node_id != expected:
            raise ModelValidationError("NodeRef global id does not match project/local identity")


@dataclass(frozen=True)
class CorrelationEdge:
    source: NodeRef
    relationship_type: CorrelationType
    target: NodeRef
    provider_name: str
    provider_version: str
    confidence: float
    reason: str
    evidence: FrozenMap = field(default_factory=FrozenMap)

    def __post_init__(self) -> None:
        if self.source.project_id == self.target.project_id:
            raise ModelValidationError("correlations must connect different projects")
        if not self.provider_name or not self.provider_version or not self.reason:
            raise ModelValidationError("correlation provenance and reason are required")
        if not math.isfinite(self.confidence) or not 0.0 <= self.confidence <= 1.0:
            raise ModelValidationError("correlation confidence must be between zero and one")


@dataclass(frozen=True)
class ProviderManifest:
    project_id: ProjectId
    snapshot_id: SnapshotId
    provider_name: str
    provider_version: str

    def __post_init__(self) -> None:
        if not self.provider_name or not self.provider_version:
            raise ModelValidationError("provider manifest name and version are required")


@dataclass(frozen=True)
class ResolvedCorrelation:
    correlation: CorrelationEdge
    queried_endpoint: CorrelationEndpointRole
    related_snapshot: ProjectSnapshot

    def __post_init__(self) -> None:
        related = (
            self.correlation.target
            if self.queried_endpoint == CorrelationEndpointRole.SOURCE
            else self.correlation.source
        )
        if (
            related.project_id != self.related_snapshot.project.project_id
            or related.snapshot_id != self.related_snapshot.snapshot_id
        ):
            raise ModelValidationError("resolved snapshot does not match the related endpoint")


@dataclass(frozen=True)
class CatalogPublication:
    snapshot: ProjectSnapshot
    node_refs: tuple[NodeRef, ...]
    correlations: tuple[CorrelationEdge, ...]
    provider_manifests: tuple[ProviderManifest, ...] = ()

    def __post_init__(self) -> None:
        if not self.snapshot.accepted:
            raise ModelValidationError("published snapshot must be accepted")
        candidate = self.snapshot.project.project_id
        if any(
            ref.project_id == candidate and ref.snapshot_id != self.snapshot.snapshot_id
            for ref in self.node_refs
        ):
            raise ModelValidationError("candidate NodeRefs must use the published snapshot")
        if any(
            edge.source.project_id != candidate and edge.target.project_id != candidate
            for edge in self.correlations
        ):
            raise ModelValidationError(
                "every refreshed correlation must touch the candidate project"
            )
        manifest_names = [manifest.provider_name for manifest in self.provider_manifests]
        if len(manifest_names) != len(set(manifest_names)):
            raise ModelValidationError("provider manifests must have unique names")
        if any(
            manifest.project_id != candidate or manifest.snapshot_id != self.snapshot.snapshot_id
            for manifest in self.provider_manifests
        ):
            raise ModelValidationError("provider manifests must belong to the published snapshot")
        refs = {(ref.project_id, ref.snapshot_id, ref.node_id) for ref in self.node_refs}
        for edge in self.correlations:
            for endpoint in (edge.source, edge.target):
                key = (endpoint.project_id, endpoint.snapshot_id, endpoint.node_id)
                if key not in refs:
                    raise ModelValidationError("correlation endpoints require persisted NodeRefs")
