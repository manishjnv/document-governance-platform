# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

""".csproj PackageReference and .sln solution parsing."""

from __future__ import annotations

import posixpath
import re
import xml.etree.ElementTree as ElementTree

from context_graph_sdk.project.config import (
    DependencyRecord,
    ManifestReader,
    ManifestRecord,
    ProjectConfig,
)

_SOLUTION_PROJECT = re.compile(r'Project\("[^"]+"\)\s*=\s*"[^"]+"\s*,\s*"([^"]+\.csproj)"')


def _is_msbuild_variable(value: str) -> bool:
    return value.startswith("$(") and value.endswith(")")


def load_csproj_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_extension(".csproj"):
        text = reader.read_text(relative)
        if text is None:
            continue
        try:
            root = ElementTree.fromstring(text)
        except ElementTree.ParseError:
            continue
        for reference in root.iter("PackageReference"):
            name = (reference.get("Include") or reference.get("Update") or "").strip()
            version = (reference.get("Version") or "").strip()
            if not version:
                version_element = reference.find("Version")
                if version_element is not None:
                    version = (version_element.text or "").strip()
            if not name or _is_msbuild_variable(name) or _is_msbuild_variable(version):
                continue
            config.add_dependency(DependencyRecord(name, version, relative))


def load_solution_manifests(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_extension(".sln"):
        text = reader.read_text(relative)
        if text is None:
            continue
        members = tuple(
            match.group(1).replace("\\", "/") for match in _SOLUTION_PROJECT.finditer(text)
        )
        config.add_manifest(
            ManifestRecord(
                posixpath.splitext(posixpath.basename(relative))[0],
                relative,
                "csharp",
                "",
                members,
            )
        )
