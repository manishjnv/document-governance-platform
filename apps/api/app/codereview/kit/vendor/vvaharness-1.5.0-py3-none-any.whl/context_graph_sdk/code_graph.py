# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Non-owning project view over the latest accepted physical snapshot."""

# pyright: reportPrivateUsage=false

from __future__ import annotations

import time
from collections.abc import Mapping
from typing import TYPE_CHECKING

from context_graph_sdk.backends import GraphSchema, SchemaPattern
from context_graph_sdk.errors import (
    QueryTimeoutError,
    StructuredQueryError,
    StructuredQueryLimitError,
)
from context_graph_sdk.identity import ProjectId
from context_graph_sdk.models import (
    CorrelationEndpointRole,
    FrozenMap,
    ProjectSnapshot,
    SnapshotInfo,
    freeze_properties,
)
from context_graph_sdk.query import QueryLimits, QueryWorkerRequest, QueryWorkerResult
from context_graph_sdk.query.context import (
    ExecuteQuery,
    is_symbol_entity,
    project_context,
    select_entity,
)
from context_graph_sdk.query.impact import project_impact
from context_graph_sdk.query.results import (
    ContextLimits,
    ContextResult,
    CorrelationLimits,
    CorrelationMatch,
    CorrelationResult,
    ImpactDirection,
    ImpactLimits,
    ImpactResult,
    SymbolSelector,
)

if TYPE_CHECKING:
    from context_graph_sdk.api import Workspace


def _integer_value(value: object, context: str) -> int:
    if not isinstance(value, int):
        raise StructuredQueryError(f"{context} is not an integer")
    return value


class CodeGraph:
    def __init__(self, workspace: Workspace, project_id: ProjectId) -> None:
        self._workspace = workspace
        self.project_id = project_id

    def cypher(
        self,
        query: str,
        parameters: Mapping[str, object] | None = None,
        limits: QueryLimits | None = None,
    ) -> QueryWorkerResult:
        snapshot, lease = self._workspace._resolve_with_lease(self.project_id)
        try:
            request = QueryWorkerRequest(
                self._workspace._next_request_id(),
                snapshot.locator,
                query,
                freeze_properties(parameters),
                limits or self._workspace.default_query_limits,
            )
            return self._workspace._workers.execute(request)
        finally:
            lease.release()
            self._workspace._collect_retired()

    def context(
        self,
        selector: str | SymbolSelector,
        limits: ContextLimits | None = None,
    ) -> ContextResult:
        selected = selector if isinstance(selector, SymbolSelector) else SymbolSelector(selector)
        snapshot, lease = self._workspace._resolve_with_lease(self.project_id)
        try:
            return project_context(
                self._structured_executor(snapshot), selected, limits or ContextLimits()
            )
        finally:
            lease.release()
            self._workspace._collect_retired()

    def impact(
        self,
        selector: str | SymbolSelector,
        direction: ImpactDirection | str,
        limits: ImpactLimits | None = None,
        relationship_types: tuple[str, ...] | None = None,
    ) -> ImpactResult:
        selected = selector if isinstance(selector, SymbolSelector) else SymbolSelector(selector)
        try:
            selected_direction = (
                direction if isinstance(direction, ImpactDirection) else ImpactDirection(direction)
            )
        except ValueError as exc:
            raise StructuredQueryError(f"unsupported impact direction: {direction}") from exc
        snapshot, lease = self._workspace._resolve_with_lease(self.project_id)
        try:
            return project_impact(
                self._structured_executor(snapshot),
                selected,
                selected_direction,
                limits or ImpactLimits(),
                relationship_types,
            )
        finally:
            lease.release()
            self._workspace._collect_retired()

    def correlations(
        self,
        selector: str | SymbolSelector,
        limits: CorrelationLimits | None = None,
        *,
        target_context_limits: ContextLimits | None = None,
    ) -> CorrelationResult:
        selected = selector if isinstance(selector, SymbolSelector) else SymbolSelector(selector)
        selected_limits = limits or CorrelationLimits()
        source_snapshot, source_lease = self._workspace._resolve_with_lease(self.project_id)
        target_leases = ()
        try:
            source = select_entity(
                self._structured_executor(source_snapshot),
                selected,
                selected_limits.candidate_limit,
            )
            resolved, target_leases = self._workspace._resolve_correlations_with_leases(
                source.id, selected_limits.max_results
            )
            matches: list[CorrelationMatch] = []
            for item in resolved:
                correlation = item.correlation
                related = (
                    correlation.target
                    if item.queried_endpoint == CorrelationEndpointRole.SOURCE
                    else correlation.source
                )
                target_context = None
                if target_context_limits is not None:
                    target_executor = self._structured_executor(item.related_snapshot)
                    target_entity = select_entity(
                        target_executor,
                        SymbolSelector(related.node_id),
                        target_context_limits.candidate_limit,
                    )
                    if is_symbol_entity(target_entity):
                        target_context = project_context(
                            target_executor,
                            SymbolSelector(related.node_id),
                            target_context_limits,
                        )
                matches.append(
                    CorrelationMatch(
                        correlation.relationship_type,
                        correlation.source,
                        correlation.target,
                        item.queried_endpoint,
                        item.related_snapshot,
                        correlation.provider_name,
                        correlation.provider_version,
                        correlation.confidence,
                        correlation.reason,
                        correlation.evidence,
                        target_context,
                    )
                )
            return CorrelationResult(
                source,
                tuple(
                    sorted(
                        matches,
                        key=lambda match: (
                            match.relationship_type.value,
                            match.source.project_id.value,
                            match.source.node_id,
                            match.target.project_id.value,
                            match.target.node_id,
                            match.queried_endpoint.value,
                            match.provider_name,
                        ),
                    )
                ),
            )
        finally:
            for lease in target_leases:
                lease.release()
            source_lease.release()
            self._workspace._collect_retired()

    def info(self) -> SnapshotInfo:
        """The snapshot's published fingerprint and node/edge counts."""
        return self._workspace.snapshot_info(self.project_id)

    def schema(self) -> GraphSchema:
        snapshot, lease = self._workspace._resolve_with_lease(self.project_id)
        try:
            limits = self._workspace.default_query_limits

            def execute(query: str) -> tuple[FrozenMap, ...]:
                result = self._workspace._workers.execute(
                    QueryWorkerRequest(
                        self._workspace._next_request_id(),
                        snapshot.locator,
                        query,
                        freeze_properties(),
                        limits,
                    )
                )
                if result.truncated:
                    raise StructuredQueryLimitError("schema result exceeded query bounds")
                return result.rows

            labels = tuple(
                str(row["value"])
                for row in execute(
                    "MATCH (n) UNWIND labels(n) AS value RETURN DISTINCT value ORDER BY value"
                )
            )
            relationship_types = tuple(
                str(row["value"])
                for row in execute(
                    "MATCH ()-[r]->() RETURN DISTINCT type(r) AS value ORDER BY value"
                )
            )
            node_keys = tuple(
                str(row["value"])
                for row in execute(
                    "MATCH (n) UNWIND keys(n) AS value RETURN DISTINCT value ORDER BY value"
                )
            )
            relationship_keys = tuple(
                str(row["value"])
                for row in execute(
                    "MATCH ()-[r]->() UNWIND keys(r) AS value RETURN DISTINCT value ORDER BY value"
                )
            )
            patterns = tuple(
                SchemaPattern(
                    str(row["source"]),
                    str(row["relationship"]),
                    str(row["target"]),
                    _integer_value(row["count"], "schema pattern count"),
                )
                for row in execute(
                    "MATCH (a)-[r]->(b) RETURN labels(a)[0] AS source,type(r) AS relationship,"
                    "labels(b)[0] AS target,count(r) AS count "
                    "ORDER BY source,relationship,target"
                )
            )
            node_rows = execute("MATCH (n) RETURN count(n) AS count")
            relationship_rows = execute("MATCH ()-[r]->() RETURN count(r) AS count")
            if len(node_rows) != 1 or len(relationship_rows) != 1:
                raise StructuredQueryError("schema count query returned no row")
            node_count = _integer_value(node_rows[0]["count"], "schema node count")
            relationship_count = _integer_value(
                relationship_rows[0]["count"], "schema relationship count"
            )
            return GraphSchema(
                labels,
                relationship_types,
                node_keys,
                relationship_keys,
                patterns,
                node_count,
                relationship_count,
            )
        finally:
            lease.release()
            self._workspace._collect_retired()

    def _structured_executor(self, snapshot: ProjectSnapshot) -> ExecuteQuery:
        base_limits = self._workspace.default_query_limits
        operation_deadline = time.monotonic() + base_limits.timeout_seconds

        def execute(
            query: str,
            parameters: Mapping[str, object],
            row_limit: int,
        ) -> tuple[FrozenMap, ...]:
            remaining = operation_deadline - time.monotonic()
            if remaining <= 0:
                raise QueryTimeoutError("structured query operation exceeded deadline")
            result = self._workspace._workers.execute(
                QueryWorkerRequest(
                    self._workspace._next_request_id(),
                    snapshot.locator,
                    query,
                    freeze_properties(parameters),
                    QueryLimits(
                        remaining,
                        base_limits.memory_bytes,
                        row_limit,
                        base_limits.byte_limit,
                    ),
                )
            )
            if result.truncated:
                reason = result.truncation_reason.value if result.truncation_reason else "unknown"
                raise StructuredQueryLimitError(
                    f"structured query result exceeded the {reason} limit"
                )
            return result.rows

        return execute
