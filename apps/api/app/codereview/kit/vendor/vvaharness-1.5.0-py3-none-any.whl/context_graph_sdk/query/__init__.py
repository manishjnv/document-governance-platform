# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Query contracts."""

from .contracts import (
    QueryLimits,
    QueryWorkerRequest,
    QueryWorkerResult,
    TruncationReason,
    WorkerHealth,
    WorkerPoolLimits,
)
from .results import (
    DEFAULT_SYMBOL_CANDIDATE_LIMIT,
    ContextLimits,
    ContextResult,
    CorrelationLimits,
    CorrelationMatch,
    CorrelationResult,
    EntityReference,
    ImpactDirection,
    ImpactLimits,
    ImpactResult,
    RelationshipDirection,
    RelationshipGroup,
    SymbolSelector,
    TraversalPath,
)

__all__ = [
    "DEFAULT_SYMBOL_CANDIDATE_LIMIT",
    "ContextLimits",
    "ContextResult",
    "CorrelationLimits",
    "CorrelationMatch",
    "CorrelationResult",
    "EntityReference",
    "ImpactDirection",
    "ImpactLimits",
    "ImpactResult",
    "QueryLimits",
    "QueryWorkerRequest",
    "QueryWorkerResult",
    "RelationshipDirection",
    "RelationshipGroup",
    "SymbolSelector",
    "TraversalPath",
    "TruncationReason",
    "WorkerHealth",
    "WorkerPoolLimits",
]
