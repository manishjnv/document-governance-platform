# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Bounded BFS process-flow discovery, importance scoring, and PageRank."""

from __future__ import annotations

import hashlib
import math
import posixpath
from dataclasses import dataclass, field

from context_graph_sdk.analysis.entry_points import (
    ORCHESTRATOR_MAX_CALLERS,
    ORCHESTRATOR_MIN_CALLEES,
    entry_point_score,
    heuristic_label,
    is_command_dir,
    is_test_file,
)
from context_graph_sdk.analysis.inputs import AnalysisInputs, AnalysisNode
from context_graph_sdk.errors import ModelValidationError

_PAGERANK_ITERATIONS = 10
_PAGERANK_DAMPING = 0.85
DEFAULT_MAX_PROCESSES = 10_000
MAX_PROCESS_LIMIT = 100_000


@dataclass(frozen=True)
class ProcessOptions:
    max_depth: int = 10
    max_branching: int = 4
    min_steps: int = 3
    max_processes: int = DEFAULT_MAX_PROCESSES
    min_confidence: float = 0.5
    exclude_tests: bool = True


@dataclass(frozen=True)
class ProcessRecord:
    local_id: str
    name: str
    entry_point_id: str
    heuristic_label: str
    step_count: int
    caller_count: int
    entry_point_score: float
    importance: float
    cross_community: bool
    communities: tuple[str, ...]
    steps: tuple[tuple[str, int], ...]  # (symbol local id, step number)


class FlowGraph:
    """Directed call-flow view over resolution edges, indexed both ways."""

    def __init__(
        self,
        inputs: AnalysisInputs,
        community_of: dict[str, str],
    ) -> None:
        self.symbols: dict[str, AnalysisNode] = inputs.nodes
        self.community_of = community_of
        self.outgoing: dict[str, list[tuple[str, str, float]]] = {}
        self.incoming: dict[str, list[tuple[str, str, float]]] = {}
        for source_id, target_id, relationship, confidence in inputs.edges:
            if source_id not in inputs.nodes or target_id not in inputs.nodes:
                continue
            self.outgoing.setdefault(source_id, []).append((target_id, relationship, confidence))
            self.incoming.setdefault(target_id, []).append((source_id, relationship, confidence))
        for bucket in self.outgoing.values():
            bucket.sort(key=lambda item: (-item[2], item[0]))
        for bucket in self.incoming.values():
            bucket.sort()

    def callable_ids(self) -> list[str]:
        return sorted(
            symbol_id
            for symbol_id, symbol in self.symbols.items()
            if symbol.label in ("Function", "Method")
        )

    def incoming_of(self, node: str, relationship: str) -> list[str]:
        return [source for source, rel, _ in self.incoming.get(node, []) if rel == relationship]

    def outgoing_count(self, node: str, *relationships: str) -> int:
        return sum(1 for _, rel, _ in self.outgoing.get(node, []) if rel in relationships)

    def production_callers(self, node: str, relationships: tuple[str, ...]) -> int:
        count = 0
        for source, rel, _ in self.incoming.get(node, []):
            if rel not in relationships:
                continue
            symbol = self.symbols.get(source)
            if symbol is not None and is_test_file(symbol.file_path):
                continue
            count += 1
        return count


def _find_entry_points(graph: FlowGraph, exclude_tests: bool) -> list[str]:
    entry_points: list[str] = []
    for node in graph.callable_ids():
        symbol = graph.symbols[node]
        if exclude_tests and is_test_file(symbol.file_path):
            continue
        if not graph.incoming_of(node, "CALLS"):
            entry_points.append(node)
    return entry_points


def _find_orchestrators(graph: FlowGraph, existing: set[str], exclude_tests: bool) -> list[str]:
    orchestrators: list[str] = []
    all_relationships = ("CALLS", "SPAWNS", "DELEGATES_TO")
    for node in graph.callable_ids():
        if node in existing:
            continue
        symbol = graph.symbols[node]
        if exclude_tests and is_test_file(symbol.file_path):
            continue
        production = graph.production_callers(node, all_relationships)
        if production == 0 or production > ORCHESTRATOR_MAX_CALLERS:
            continue
        if graph.outgoing_count(node, *all_relationships) >= ORCHESTRATOR_MIN_CALLEES:
            orchestrators.append(node)
    return orchestrators


def _find_spawn_targets(graph: FlowGraph, existing: set[str], exclude_tests: bool) -> list[str]:
    targets: list[str] = []
    seen: set[str] = set()
    for node in graph.callable_ids():
        if node in existing or node in seen:
            continue
        if not graph.incoming_of(node, "SPAWNS"):
            continue
        seen.add(node)
        symbol = graph.symbols[node]
        if exclude_tests and is_test_file(symbol.file_path):
            continue
        targets.append(node)
    return targets


def _find_delegate_targets(graph: FlowGraph, existing: set[str], exclude_tests: bool) -> list[str]:
    targets: list[str] = []
    for node in graph.callable_ids():
        if node in existing:
            continue
        if not graph.incoming_of(node, "DELEGATES_TO"):
            continue
        symbol = graph.symbols[node]
        if exclude_tests and is_test_file(symbol.file_path):
            continue
        if graph.incoming_of(node, "CALLS"):
            continue
        callees = graph.outgoing_count(node, "CALLS") + graph.outgoing_count(node, "SPAWNS")
        if callees < 3:
            continue
        targets.append(node)
    return targets


@dataclass
class _RawProcess:
    entry_point: str
    steps: list[tuple[str, int, int]]  # (node, step number, depth)
    visited: set[str]
    communities: tuple[str, ...]
    cross_community: bool
    caller_count: int
    importance: float = 0.0
    steps_set: set[str] = field(default_factory=set[str])


def _spawn_sibling_counts(graph: FlowGraph) -> dict[str, int]:
    fanout: dict[str, int] = {}
    for source, edges in graph.outgoing.items():
        fanout[source] = sum(1 for _, rel, _ in edges if rel == "SPAWNS")
    siblings: dict[str, int] = {}
    for target, edges in graph.incoming.items():
        for source, rel, _ in edges:
            if rel == "SPAWNS":
                siblings[target] = max(siblings.get(target, 0), fanout.get(source, 0))
    return siblings


def _external_callers(graph: FlowGraph, node: str, visited: set[str], seen: set[str]) -> list[str]:
    callers: list[str] = []
    for source, _, _ in graph.incoming.get(node, []):
        if source not in visited and source not in seen:
            seen.add(source)
            callers.append(source)
    return callers


def detect_processes(
    inputs: AnalysisInputs,
    community_of: dict[str, str],
    options: ProcessOptions | None = None,
) -> list[ProcessRecord]:
    options = options or ProcessOptions()
    if not 1 <= options.max_processes <= MAX_PROCESS_LIMIT:
        raise ModelValidationError(f"max_processes must be in [1, {MAX_PROCESS_LIMIT}]")
    graph = FlowGraph(inputs, community_of)

    entry_points = _find_entry_points(graph, options.exclude_tests)
    existing = set(entry_points)
    orchestrators = _find_orchestrators(graph, existing, options.exclude_tests)
    entry_points.extend(orchestrators)
    existing.update(orchestrators)
    spawn_targets = _find_spawn_targets(graph, existing, options.exclude_tests)
    entry_points.extend(spawn_targets)
    existing.update(spawn_targets)
    delegate_targets = _find_delegate_targets(graph, existing, options.exclude_tests)
    entry_points.extend(delegate_targets)
    entry_points.sort()

    orchestrator_set = set(orchestrators)
    spawn_siblings = _spawn_sibling_counts(graph)

    seen_fingerprints: set[str] = set()
    raw_processes: list[_RawProcess] = []
    for entry_point in entry_points:
        if len(raw_processes) >= options.max_processes:
            break
        visited = {entry_point}
        steps: list[tuple[str, int, int]] = []
        queue: list[tuple[str, int]] = [(entry_point, 0)]
        head = 0
        step_number = 0
        while head < len(queue):
            node, depth = queue[head]
            head += 1
            step_number += 1
            steps.append((node, step_number, depth))
            if depth >= options.max_depth:
                continue
            branch_limit = options.max_branching * 2 if depth == 0 else options.max_branching
            branch_count = 0
            for target, _, confidence in graph.outgoing.get(node, []):
                if branch_count >= branch_limit:
                    break
                # Zero or absent confidence means unspecified; only explicit
                # low-confidence edges are pruned.
                if 0 < confidence < options.min_confidence:
                    continue
                if target in visited:
                    continue
                visited.add(target)
                queue.append((target, depth + 1))
                branch_count += 1

        if len(steps) < options.min_steps:
            continue
        fingerprint = hashlib.sha256(
            "\x00".join(sorted(node for node, _, _ in steps)).encode()
        ).hexdigest()[:32]
        if fingerprint in seen_fingerprints:
            continue
        seen_fingerprints.add(fingerprint)

        community_set = {community_of[node] for node, _, _ in steps if node in community_of}
        caller_seen: set[str] = set()
        for node, _, _ in steps:
            _external_callers(graph, node, visited, caller_seen)

        raw_processes.append(
            _RawProcess(
                entry_point,
                steps,
                visited,
                tuple(sorted(community_set)),
                len(community_set) > 1,
                len(caller_seen),
                steps_set={node for node, _, _ in steps},
            )
        )

    step_flow_count: dict[str, int] = {}
    for raw in raw_processes:
        for node, _, _ in raw.steps:
            step_flow_count[node] = step_flow_count.get(node, 0) + 1

    for raw in raw_processes:
        effective_callers = 0.0
        effective_steps = 0.0
        caller_seen = set()
        for node, _, depth in raw.steps:
            share = max(step_flow_count.get(node, 1), 1)
            step_weight = 1.0 / (share ** (1.0 / 3.0))
            caller_weight = (1.0 / (depth + 1)) / math.sqrt(share)
            effective_steps += step_weight
            for caller in _external_callers(graph, node, raw.visited, caller_seen):
                symbol = graph.symbols.get(caller)
                if symbol is not None and is_test_file(symbol.file_path):
                    continue
                effective_callers += caller_weight

        packages = {
            posixpath.dirname(graph.symbols[node].file_path)
            for node, _, _ in raw.steps
            if graph.symbols[node].file_path
        }
        packages.discard("")
        entry_fanout = graph.outgoing_count(raw.entry_point, "CALLS")
        entry_production_callers = graph.production_callers(raw.entry_point, ("CALLS", "SPAWNS"))
        entry_symbol = graph.symbols[raw.entry_point]
        entry_path = entry_symbol.file_path

        raw_reach = float(len(raw.steps))
        importance = (math.log1p(effective_callers) + 0.3 * math.log1p(raw_reach)) * math.log1p(
            effective_steps
        )
        if raw.steps:
            exclusivity = effective_steps / len(raw.steps)
            importance *= 1.0 + 0.3 * math.sqrt(exclusivity)
        if raw.cross_community:
            importance *= 1.5
        if len(packages) > 2:
            importance *= 1.0 + 0.3 * math.log1p(len(packages) - 2)
        if entry_fanout > 1:
            importance *= 1.0 + 0.15 * math.log1p(entry_fanout)
        if entry_production_callers > 1:
            importance *= 1.0 + 0.2 * math.log1p(entry_production_callers)
        siblings = spawn_siblings.get(raw.entry_point, 0)
        if siblings > 0:
            importance *= 1.0 + 0.5 / math.sqrt(max(siblings, 1))

        entry_label = heuristic_label(entry_symbol.name)
        if (
            raw.entry_point in orchestrator_set
            and entry_label not in ("Create operation", "Initialization")
            and not is_command_dir(entry_path)
        ):
            importance *= 1.5
        if entry_label in ("Create operation", "Initialization"):
            importance *= 0.2
        if is_command_dir(entry_path):
            importance *= 0.5
        if entry_path and is_test_file(entry_path):
            importance *= 0.1
        raw.importance = importance

    # Flow-level PageRank: flows invoked by important flows gain rank.
    entry_to_index = {raw.entry_point: index for index, raw in enumerate(raw_processes)}
    invokers, out_degree = flow_rank_topology(
        [[node for node, _, _ in raw.steps] for raw in raw_processes], entry_to_index
    )
    rank = [raw.importance for raw in raw_processes]
    for _ in range(_PAGERANK_ITERATIONS):
        new_rank = [0.0] * len(raw_processes)
        for index, raw in enumerate(raw_processes):
            new_rank[index] = (1 - _PAGERANK_DAMPING) * raw.importance
            for invoker in invokers[index]:
                if out_degree[invoker] > 0:
                    new_rank[index] += _PAGERANK_DAMPING * rank[invoker] / out_degree[invoker]
        rank = new_rank
    for index, raw in enumerate(raw_processes):
        if raw.importance > 0:
            ratio = rank[index] / raw.importance
            if ratio > 1.0:
                raw.importance *= 1.0 + math.log1p(ratio - 1.0)

    records: list[ProcessRecord] = []
    for raw in raw_processes:
        entry_symbol = graph.symbols[raw.entry_point]
        # Expose the entry-point heuristic as metadata without letting it
        # perturb the independently calculated importance ordering.
        score = entry_point_score(
            entry_symbol.name,
            entry_symbol.language,
            entry_symbol.is_exported,
            len(graph.incoming_of(raw.entry_point, "CALLS")),
            graph.outgoing_count(raw.entry_point, "CALLS"),
            entry_symbol.file_path,
        ).score
        records.append(
            ProcessRecord(
                local_id=f"process:{raw.entry_point}-flow",
                name=_qualified_flow_name(entry_symbol),
                entry_point_id=raw.entry_point,
                heuristic_label=heuristic_label(entry_symbol.name),
                step_count=len(raw.steps),
                # Expose the raw unique external caller count; importance
                # applies production-only weighting separately.
                caller_count=raw.caller_count,
                entry_point_score=score,
                importance=raw.importance,
                cross_community=raw.cross_community,
                communities=raw.communities,
                steps=tuple((node, number) for node, number, _ in raw.steps),
            )
        )
    return records


def flow_rank_topology(
    flow_steps: list[list[str]], entry_to_index: dict[str, int]
) -> tuple[list[list[int]], list[int]]:
    """Invoker lists and out-degrees for the flow PageRank.

    A flow's own entry point is always among its steps; it is excluded from
    both the invoker lists and the out-degree so a flow's rank share is
    split only across the *other* flows it invokes (consistent semantics on
    both sides of the propagation).
    """
    invokers: list[list[int]] = [[] for _ in flow_steps]
    out_degree: list[int] = [0] * len(flow_steps)
    for index, steps in enumerate(flow_steps):
        for node in steps:
            target = entry_to_index.get(node)
            if target is not None and target != index:
                invokers[target].append(index)
                out_degree[index] += 1
    return invokers, out_degree


def _qualified_flow_name(entry: AnalysisNode) -> str:
    package = ""
    if entry.file_path:
        directory = posixpath.dirname(entry.file_path)
        if directory not in (".", "/", ""):
            package = posixpath.basename(directory)
    parts = [
        part
        for part in (package, entry.owner_name if entry.label == "Method" else "", entry.name)
        if part
    ]
    return ".".join(parts) + "-flow"
