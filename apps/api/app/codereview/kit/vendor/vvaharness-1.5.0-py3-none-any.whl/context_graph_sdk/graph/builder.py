# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deterministic structural snapshot construction from discovery output.

Local IDs use stable, domain-prefixed repository-local identities such as
``file:<path>``, ``folder:<path>``, and ``module:<source>:<name>``.
"""

from __future__ import annotations

import posixpath
from collections.abc import Callable, Mapping

from context_graph_sdk.discovery.walker import RepositoryWalk
from context_graph_sdk.errors import ModelValidationError
from context_graph_sdk.extractors.records import ExtractionResult
from context_graph_sdk.graph.symbols import (
    owner_relationship,
    same_file_owner,
    sorted_symbols,
    symbol_properties,
)
from context_graph_sdk.identity import SnapshotId
from context_graph_sdk.models import (
    AnalysisVersion,
    GraphEdge,
    GraphNode,
    GraphSnapshot,
    LocalRelationshipType,
    NodeLabel,
    ProjectMetadata,
    freeze_properties,
)
from context_graph_sdk.project.config import (
    ManifestRecord,
    ProjectConfig,
    workspace_member_manifest_path,
)
from context_graph_sdk.resolution.context import ResolutionResult

_PROJECT_LOCAL_ID = "project"


class _SnapshotAccumulator:
    def __init__(self, project: ProjectMetadata) -> None:
        self.project = project
        self.nodes: dict[str, GraphNode] = {}
        self.edges: dict[str, GraphEdge] = {}

    def add_node(
        self, local_id: str, label: NodeLabel, properties: Mapping[str, object]
    ) -> GraphNode:
        return self.add_typed_node(local_id, (label.value,), properties)

    def add_typed_node(
        self, local_id: str, labels: tuple[str, ...], properties: Mapping[str, object]
    ) -> GraphNode:
        node = GraphNode(self.project.project_id, local_id, labels, freeze_properties(properties))
        existing = self.nodes.get(node.id)
        if existing is None:
            self.nodes[node.id] = node
            return node
        if existing != node:
            raise ModelValidationError(
                f"conflicting structural nodes share one local id: {local_id!r}"
            )
        return existing

    def add_edge(
        self,
        source: GraphNode,
        relationship: LocalRelationshipType,
        target: GraphNode,
        properties: Mapping[str, object] | None = None,
    ) -> None:
        edge = GraphEdge(
            self.project.project_id,
            source.id,
            relationship.value,
            target.id,
            properties=freeze_properties(properties),
        )
        self.edges.setdefault(edge.id, edge)


def build_structural_snapshot(
    project: ProjectMetadata,
    snapshot_id: SnapshotId,
    analysis_version: AnalysisVersion,
    walk: RepositoryWalk,
    config: ProjectConfig,
    documentation: Mapping[str, str] | None = None,
    extraction: ExtractionResult | None = None,
    resolution: ResolutionResult | None = None,
) -> GraphSnapshot:
    documentation = documentation or {}
    accumulator = _SnapshotAccumulator(project)

    project_properties: dict[str, object] = {"name": project.display_name}
    if project.source_path:
        project_properties["sourcePath"] = project.source_path
    if project.source_url:
        project_properties["sourceUrl"] = project.source_url
    if project.revision:
        project_properties["revision"] = project.revision
    project_node = accumulator.add_node(_PROJECT_LOCAL_ID, NodeLabel.PROJECT, project_properties)

    folders: dict[str, GraphNode] = {}

    def ensure_folder(relative: str) -> None:
        if not relative or relative == "." or relative in folders:
            return
        folders[relative] = accumulator.add_node(
            f"folder:{relative}",
            NodeLabel.FOLDER,
            {"name": posixpath.basename(relative), "filePath": relative},
        )

    for directory in walk.directories:
        ensure_folder(directory)
        _ensure_ancestors(directory, ensure_folder)

    files: dict[str, GraphNode] = {}
    for walked in walk.files:
        _ensure_ancestors(walked.relative_path, ensure_folder)
        properties: dict[str, object] = {
            "name": posixpath.basename(walked.relative_path),
            "filePath": walked.relative_path,
            "language": walked.language,
            "size": walked.size,
        }
        content = documentation.get(walked.relative_path)
        if content:
            properties["content"] = content
        files[walked.relative_path] = accumulator.add_node(
            f"file:{walked.relative_path}", NodeLabel.FILE, properties
        )

    for mapping in (files, folders):
        for relative, node in mapping.items():
            parent = posixpath.dirname(relative)
            if parent and parent in folders:
                accumulator.add_edge(folders[parent], LocalRelationshipType.CONTAINS, node)
            elif not parent:
                accumulator.add_edge(project_node, LocalRelationshipType.CONTAINS, node)

    for dependency in config.dependencies:
        manifest_file = files.get(dependency.source)
        properties = {"name": dependency.name, "source": dependency.source}
        if dependency.version:
            properties["version"] = dependency.version
        if dependency.dev:
            properties["devDep"] = True
        if dependency.scope:
            properties["scope"] = dependency.scope
        node = accumulator.add_node(
            f"dep:{dependency.source}:{dependency.name}", NodeLabel.DEPENDENCY, properties
        )
        if manifest_file is not None:
            accumulator.add_edge(manifest_file, LocalRelationshipType.DEPENDS_ON, node)

    modules_by_manifest: dict[str, GraphNode] = {}
    for manifest in config.manifests:
        manifest_file = files.get(manifest.source)
        if manifest_file is None:
            continue
        module = accumulator.add_node(
            f"module:{manifest.source}:{manifest.name}",
            NodeLabel.MODULE,
            {
                "name": manifest.name,
                "version": manifest.version,
                "filePath": manifest.source,
                "language": manifest.language,
                "source": manifest.source,
            },
        )
        accumulator.add_edge(manifest_file, LocalRelationshipType.DEFINES, module)
        modules_by_manifest[manifest.source] = module

    for manifest in config.manifests:
        module = modules_by_manifest.get(manifest.source)
        manifest_file = files.get(manifest.source)
        if module is None or manifest_file is None:
            continue
        for workspace in manifest.workspaces:
            member = _resolve_workspace_member(
                accumulator, manifest, workspace, modules_by_manifest
            )
            if member is None:
                member = _synthetic_workspace_module(accumulator, manifest, workspace)
                accumulator.add_edge(manifest_file, LocalRelationshipType.DEFINES, member)
            # Compatibility-sensitive direction: the root module points to
            # each workspace member, so MEMBER_OF reads as "has member".
            accumulator.add_edge(module, LocalRelationshipType.MEMBER_OF, member)

    for process in config.build_processes:
        source_file = files.get(process.source)
        if source_file is None:
            continue
        # Build and runtime flows share the Process query surface.
        node = accumulator.add_node(
            f"proc:{process.source}:{process.name}",
            NodeLabel.PROCESS,
            {
                "name": process.name,
                "entryPoint": process.entry_point,
                "filePath": process.source,
                "language": process.language,
                "source": process.source,
            },
        )
        accumulator.add_edge(source_file, LocalRelationshipType.DEFINES, node)

    if extraction is not None:
        _add_symbols(accumulator, files, extraction, resolution)

    if resolution is not None:
        nodes_by_local_id = {node.local_id: node for node in accumulator.nodes.values()}
        for edge in resolution.edges:
            source = nodes_by_local_id.get(edge.source_local_id)
            target = nodes_by_local_id.get(edge.target_local_id)
            # Endpoints can be missing when a caller fell back to a file that
            # was discovered but produced no node (never in practice) or a
            # symbol was deduplicated; skipping keeps the graph consistent.
            if source is None or target is None:
                continue
            accumulator.add_edge(source, edge.relationship, target, dict(edge.properties))

    return GraphSnapshot(
        project,
        snapshot_id,
        analysis_version,
        tuple(accumulator.nodes.values()),
        tuple(accumulator.edges.values()),
    )


def _add_symbols(
    accumulator: _SnapshotAccumulator,
    files: Mapping[str, GraphNode],
    extraction: ExtractionResult,
    resolution: ResolutionResult | None = None,
) -> None:
    symbols = sorted_symbols(extraction)
    updates = resolution.property_updates if resolution is not None else {}
    nodes_by_name: dict[str, list[GraphNode]] = {}
    node_by_symbol_id: dict[str, GraphNode] = {}
    for symbol in symbols:
        properties = symbol_properties(symbol)
        properties.update(updates.get(symbol.id, {}))
        # The symbol hash is its stable repository-local identity.
        properties["symbolLabels"] = ["Symbol", symbol.label]
        node = accumulator.add_typed_node(symbol.id, (symbol.label,), properties)
        node_by_symbol_id[symbol.id] = node
        nodes_by_name.setdefault(symbol.name, []).append(node)
        file_node = files.get(symbol.file_path)
        if file_node is not None:
            accumulator.add_edge(file_node, LocalRelationshipType.CONTAINS, node)
            accumulator.add_edge(file_node, LocalRelationshipType.DEFINES, node)
    for symbol in symbols:
        if not symbol.owner_name:
            continue
        owner_node = same_file_owner(symbol, nodes_by_name)
        if owner_node is None:
            continue
        member = node_by_symbol_id[symbol.id]
        if owner_node.id == member.id:
            continue
        accumulator.add_edge(owner_node, owner_relationship(symbol), member)


def _ensure_ancestors(relative: str, ensure_folder: Callable[[str], None]) -> None:
    parts = relative.split("/")
    for index in range(1, len(parts)):
        ensure_folder("/".join(parts[:index]))


def _resolve_workspace_member(
    accumulator: _SnapshotAccumulator,
    manifest: ManifestRecord,
    workspace: str,
    modules_by_manifest: Mapping[str, GraphNode],
) -> GraphNode | None:
    member_manifest = workspace_member_manifest_path(manifest, workspace)
    if member_manifest is None:
        return None
    return modules_by_manifest.get(member_manifest)


def _synthetic_workspace_module(
    accumulator: _SnapshotAccumulator, manifest: ManifestRecord, workspace: str
) -> GraphNode:
    return accumulator.add_node(
        f"module-workspace:{manifest.source}:{workspace}",
        NodeLabel.MODULE,
        {
            "name": workspace,
            "filePath": manifest.source,
            "language": manifest.language,
            "source": manifest.source,
        },
    )
