# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Conservative lexical validation for public read-only Cypher."""

from __future__ import annotations

import re

from context_graph_sdk.errors import QueryValidationError

_FORBIDDEN = frozenset(
    {
        "ALTER",
        "CALL",
        "COMMIT",
        "CREATE",
        "DELETE",
        "DETACH",
        "DROP",
        "EXPORT",
        "GRANT",
        "IMPORT",
        "INSERT",
        "LOAD",
        "MERGE",
        "REMOVE",
        "REVOKE",
        "ROLLBACK",
        "SET",
        "SHOW",
        "START",
        "STOP",
        "TRANSACTION",
        "TRUNCATE",
        "UPDATE",
        "UPSERT",
    }
)
_TOKEN = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


def validate_readonly_cypher(cypher: str) -> None:
    if not cypher.strip():
        raise QueryValidationError("Cypher query is empty")
    code = _code_only(cypher)
    semicolons = [index for index, char in enumerate(code) if char == ";"]
    if len(semicolons) > 1 or (semicolons and code[semicolons[0] + 1 :].strip()):
        raise QueryValidationError("multiple Cypher statements are not allowed")
    tokens = {token.upper() for token in _TOKEN.findall(code)}
    forbidden = sorted(tokens.intersection(_FORBIDDEN))
    if forbidden:
        raise QueryValidationError(f"Cypher clause is not read-only: {forbidden[0]}")


def _code_only(cypher: str) -> str:
    output: list[str] = []
    index = 0
    state = "code"
    while index < len(cypher):
        char = cypher[index]
        following = cypher[index + 1] if index + 1 < len(cypher) else ""
        if state == "code":
            if char == "/" and following == "/":
                output.extend("  ")
                index += 2
                state = "line_comment"
                continue
            if char == "/" and following == "*":
                output.extend("  ")
                index += 2
                state = "block_comment"
                continue
            if char in {"'", '"', "`"}:
                output.append(" ")
                state = {"'": "single", '"': "double", "`": "identifier"}[char]
            else:
                output.append(char)
        elif state == "line_comment":
            output.append("\n" if char == "\n" else " ")
            if char == "\n":
                state = "code"
        elif state == "block_comment":
            output.append(" ")
            if char == "*" and following == "/":
                output.append(" ")
                index += 1
                state = "code"
        else:
            output.append(" ")
            quote = {"single": "'", "double": '"', "identifier": "`"}[state]
            if char == "\\" and state != "identifier" and following:
                output.append(" ")
                index += 1
            elif char == quote:
                if following == quote:
                    output.append(" ")
                    index += 1
                else:
                    state = "code"
        index += 1
    if state not in {"code", "line_comment"}:
        raise QueryValidationError("unterminated Cypher string, identifier, or comment")
    return "".join(output)
