# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Ecosystem import resolution producing file-level and folder-level IMPORTS."""

from __future__ import annotations

import posixpath

from context_graph_sdk.models import LocalRelationshipType
from context_graph_sdk.resolution.context import (
    ResolutionContext,
    ResolutionResult,
    file_local_id,
    folder_local_id,
)

_TS_EXTENSIONS = (".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs")
_TS_INDEX_FILES = ("index.ts", "index.tsx", "index.js", "index.jsx")
_PY_EXTENSIONS = (".py", ".pyi")
_JVM_EXTENSIONS = (".java", ".kt", ".scala", ".groovy")
_GENERIC_EXTENSIONS = (
    ".go", ".ts", ".tsx", ".js", ".jsx", ".py", ".java", ".rs",
    ".rb", ".php", ".cs", ".kt", ".swift", ".sol",
)  # fmt: skip


def is_relative_import(import_path: str) -> bool:
    return import_path.startswith(("./", "../"))


_DEDICATED_RESOLVER_LANGUAGES = frozenset(
    {
        "go",
        "typescript",
        "tsx",
        "javascript",
        "python",
        "java",
        "kotlin",
        "rust",
        "csharp",
        "php",
        "ruby",
        "swift",
    }
)


def resolve_imports(context: ResolutionContext, result: ResolutionResult) -> None:
    resolved_pairs: list[tuple[str, str]] = []
    for from_path, file_result in context.extraction.files:
        language = context.file_language.get(from_path, "")
        for imported in file_result.imports:
            target = _resolve_one(context, from_path, imported.source, language)
            if target is None and language in _DEDICATED_RESOLVER_LANGUAGES:
                # Dedicated resolvers already encode every deterministic
                # fallback for their ecosystem; anything unresolved is a
                # stdlib/external import that cannot exist in the project.
                continue
            if target is None:
                if is_relative_import(imported.source) or imported.source.startswith("."):
                    target = _resolve_generic_relative(context, from_path, imported.source)
                else:
                    target = _resolve_generic_absolute(context, imported.source)
            if target is None or target == from_path:
                continue
            if result.add_edge(
                file_local_id(from_path), LocalRelationshipType.IMPORTS, file_local_id(target)
            ):
                resolved_pairs.append((from_path, target))
    _add_folder_edges(context, result, resolved_pairs)


def _resolve_one(
    context: ResolutionContext, from_path: str, import_path: str, language: str
) -> str | None:
    if language == "go":
        return _resolve_go(context, import_path)
    if language in ("typescript", "tsx", "javascript"):
        return _resolve_ts_js(context, from_path, import_path)
    if language == "python":
        return _resolve_python(context, from_path, import_path)
    if language in ("java", "kotlin"):
        return _resolve_jvm(context, import_path)
    if language == "rust":
        return _resolve_rust(context, from_path, import_path)
    if language == "csharp":
        return _resolve_csharp(context, import_path)
    if language == "php":
        return _resolve_php(context, import_path)
    if language == "ruby":
        return _resolve_ruby(context, from_path, import_path)
    if language == "swift":
        return _resolve_swift(context, import_path)
    return None


def _go_package_file(context: ResolutionContext, directory: str) -> str | None:
    """A representative non-test .go file in the directory (sorted order)."""
    directory = directory.rstrip("/")
    fallback: str | None = None
    for name in context.files_in_dir(directory):
        if not name.endswith(".go"):
            continue
        candidate = posixpath.join(directory, name) if directory else name
        if not name.endswith("_test.go"):
            return candidate
        if fallback is None:
            fallback = candidate
    return fallback


def _resolve_go(context: ResolutionContext, import_path: str) -> str | None:
    module = context.settings.go_module_path
    if module and import_path.startswith(module):
        relative = import_path.removeprefix(module).removeprefix("/")
        if relative:
            return _go_package_file(context, relative)
    parts = import_path.split("/")
    if len(parts) >= 2:
        for index in range(len(parts)):
            found = _go_package_file(context, "/".join(parts[index:]))
            if found is not None:
                return found
    return None


def _lookup_ts_file(context: ResolutionContext, base_path: str) -> str | None:
    found = context.lookup_with_extensions(base_path, _TS_EXTENSIONS)
    if found is not None:
        return found
    for index_file in _TS_INDEX_FILES:
        candidate = posixpath.join(base_path, index_file)
        if context.has_file(candidate):
            return candidate
    return None


def _resolve_ts_js(context: ResolutionContext, from_path: str, import_path: str) -> str | None:
    if import_path.startswith("."):
        resolved = posixpath.normpath(posixpath.join(posixpath.dirname(from_path), import_path))
        return _lookup_ts_file(context, resolved)
    for pattern, targets in context.settings.ts_config_paths:
        if pattern.endswith("*"):
            prefix = pattern[:-1]
            if import_path.startswith(prefix):
                rest = import_path.removeprefix(prefix)
                for target in targets:
                    candidate = posixpath.join(target.removesuffix("*"), rest)
                    found = _lookup_ts_file(context, posixpath.normpath(candidate))
                    if found is not None:
                        return found
        elif import_path == pattern:
            for target in targets:
                found = _lookup_ts_file(context, target)
                if found is not None:
                    return found
    if context.settings.ts_config_base_url:
        found = _lookup_ts_file(
            context, posixpath.join(context.settings.ts_config_base_url, import_path)
        )
        if found is not None:
            return found
    return _lookup_ts_file(context, import_path)


def _resolve_python(context: ResolutionContext, from_path: str, import_path: str) -> str | None:
    if import_path.startswith("."):
        return _resolve_python_relative(context, from_path, import_path)
    module_path = import_path.replace(".", "/")
    found = context.lookup_with_extensions(module_path, _PY_EXTENSIONS)
    if found is not None:
        return found
    package_init = posixpath.join(module_path, "__init__.py")
    if context.has_file(package_init):
        return package_init
    directory = posixpath.dirname(from_path)
    while directory not in ("", "."):
        candidate = posixpath.join(directory, module_path)
        found = context.lookup_with_extensions(candidate, _PY_EXTENSIONS)
        if found is not None:
            return found
        init = posixpath.join(candidate, "__init__.py")
        if context.has_file(init):
            return init
        parent = posixpath.dirname(directory)
        if parent == directory:
            break
        directory = parent
    return context.lookup_suffix("/" + module_path + ".py")


def _resolve_python_relative(
    context: ResolutionContext, from_path: str, import_path: str
) -> str | None:
    dots = len(import_path) - len(import_path.lstrip("."))
    rest = import_path[dots:]
    directory = posixpath.dirname(from_path)
    for _ in range(dots - 1):
        directory = posixpath.dirname(directory)
    if rest:
        candidate = posixpath.join(directory, rest.replace(".", "/"))
        found = context.lookup_with_extensions(candidate, _PY_EXTENSIONS)
        if found is not None:
            return found
        init = posixpath.join(candidate, "__init__.py")
        if context.has_file(init):
            return init
    package_init = posixpath.join(directory, "__init__.py")
    return package_init if context.has_file(package_init) else None


_JVM_SOURCE_DIRS = ("src/main/java/", "src/main/kotlin/", "src/")


def _jvm_file_in_dir(context: ResolutionContext, directory: str) -> str | None:
    for prefix in ("", "src/main/java/", "src/main/kotlin/"):
        full = prefix + directory
        for name in context.files_in_dir(full):
            if posixpath.splitext(name)[1] in (".java", ".kt", ".scala"):
                return posixpath.join(full, name)
    return None


def _resolve_jvm(context: ResolutionContext, import_path: str) -> str | None:
    module_path = import_path.replace(".", "/")
    if module_path.endswith("/*"):
        return _jvm_file_in_dir(context, module_path[:-2])
    found = context.lookup_with_extensions(module_path, _JVM_EXTENSIONS)
    if found is not None:
        return found
    for source_dir in _JVM_SOURCE_DIRS:
        found = context.lookup_with_extensions(source_dir + module_path, _JVM_EXTENSIONS)
        if found is not None:
            return found
    parts = import_path.split(".")
    if len(parts) >= 2:
        class_name = parts[-1]
        package_dir = "/".join(parts[:-1])
        for source_dir in ("", *_JVM_SOURCE_DIRS):
            directory = source_dir + package_dir
            for name in context.files_in_dir(directory):
                if posixpath.splitext(name)[0] == class_name:
                    return posixpath.join(directory, name)
    return None


def _lookup_rust_module(context: ResolutionContext, base_path: str) -> str | None:
    for candidate in (
        base_path + ".rs",
        posixpath.join(base_path, "mod.rs"),
        posixpath.join(base_path, "lib.rs"),
        base_path,
    ):
        if context.has_file(candidate):
            return candidate
    return None


def _resolve_rust(context: ResolutionContext, from_path: str, import_path: str) -> str | None:
    brace = import_path.find("{")
    if brace >= 0:
        import_path = import_path[:brace].rstrip(":")
    import_path = import_path.removesuffix("::*")
    module_path = import_path.replace("::", "/")
    if module_path.startswith("crate/"):
        return _lookup_rust_module(context, "src/" + module_path.removeprefix("crate/"))
    if module_path.startswith("super/"):
        parent = posixpath.dirname(posixpath.dirname(from_path))
        return _lookup_rust_module(
            context, posixpath.join(parent, module_path.removeprefix("super/"))
        )
    if module_path.startswith("self/"):
        directory = posixpath.dirname(from_path)
        return _lookup_rust_module(
            context, posixpath.join(directory, module_path.removeprefix("self/"))
        )
    found = _lookup_rust_module(context, "src/" + module_path)
    if found is not None:
        return found
    return _lookup_rust_module(context, module_path)


def _resolve_csharp(context: ResolutionContext, import_path: str) -> str | None:
    namespace_path = import_path.replace(".", "/")
    if context.has_file(namespace_path + ".cs"):
        return namespace_path + ".cs"
    root = context.settings.csharp_root_namespace
    if root and import_path.startswith(root):
        relative = import_path.removeprefix(root).removeprefix(".").replace(".", "/")
        if relative and context.has_file(relative + ".cs"):
            return relative + ".cs"
    for name in context.files_in_dir(namespace_path):
        if name.endswith(".cs"):
            return posixpath.join(namespace_path, name)
    return context.lookup_suffix("/" + namespace_path + ".cs")


def _resolve_php(context: ResolutionContext, import_path: str) -> str | None:
    namespace_path = import_path.replace("\\", "/")
    for prefix, directories in context.settings.composer_psr4:
        normalized = prefix.replace("\\", "/")
        if namespace_path.startswith(normalized):
            relative = namespace_path.removeprefix(normalized)
            for directory in directories:
                candidate = posixpath.join(directory.rstrip("/"), relative) + ".php"
                if context.has_file(candidate):
                    return candidate
    if context.has_file(namespace_path + ".php"):
        return namespace_path + ".php"
    found = context.lookup_suffix("/" + namespace_path + ".php")
    if found is not None:
        return found
    class_name = namespace_path.rsplit("/", 1)[-1]
    return context.lookup_suffix("/" + class_name + ".php")


def _resolve_ruby(context: ResolutionContext, from_path: str, import_path: str) -> str | None:
    if import_path.startswith("."):
        resolved = posixpath.normpath(posixpath.join(posixpath.dirname(from_path), import_path))
        if context.has_file(resolved + ".rb"):
            return resolved + ".rb"
        return resolved if context.has_file(resolved) else None
    if context.has_file(import_path + ".rb"):
        return import_path + ".rb"
    for prefix in ("lib/", "app/", "src/"):
        candidate = prefix + import_path + ".rb"
        if context.has_file(candidate):
            return candidate
    return context.lookup_suffix("/" + import_path + ".rb")


def _resolve_swift(context: ResolutionContext, import_path: str) -> str | None:
    directories = [
        directory for name, directory in context.settings.swift_targets if name == import_path
    ]
    directories.append("Sources/" + import_path)
    for directory in directories:
        for name in context.files_in_dir(directory):
            if name.endswith(".swift"):
                return posixpath.join(directory, name)
    candidate = import_path + ".swift"
    return candidate if context.has_file(candidate) else None


def _resolve_generic_relative(
    context: ResolutionContext, from_path: str, import_path: str
) -> str | None:
    resolved = posixpath.normpath(posixpath.join(posixpath.dirname(from_path), import_path))
    if context.has_file(resolved):
        return resolved
    found = context.lookup_with_extensions(resolved, _GENERIC_EXTENSIONS)
    if found is not None:
        return found
    for index_file in _TS_INDEX_FILES:
        candidate = posixpath.join(resolved, index_file)
        if context.has_file(candidate):
            return candidate
    return None


def _resolve_generic_absolute(context: ResolutionContext, import_path: str) -> str | None:
    """Use deterministic suffix matching where no ecosystem resolver exists.

    Substring scans are deliberately excluded because their winners depend on
    unrelated path names and iteration order.
    """
    for extension in _GENERIC_EXTENSIONS:
        found = context.lookup_suffix(import_path + extension)
        if found is not None:
            return found
    return context.lookup_suffix(import_path)


def _add_folder_edges(
    context: ResolutionContext, result: ResolutionResult, resolved_pairs: list[tuple[str, str]]
) -> None:
    for from_path, to_path in resolved_pairs:
        from_dir = posixpath.dirname(from_path)
        to_dir = posixpath.dirname(to_path)
        if from_dir == to_dir:
            continue
        if from_dir in context.folders and to_dir in context.folders:
            result.add_edge(
                folder_local_id(from_dir), LocalRelationshipType.IMPORTS, folder_local_id(to_dir)
            )
