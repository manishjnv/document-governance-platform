# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Gitignore-style matching with negation, ** globs, and dir-only rules.

Small local implementation so ignore behavior stays testable and dependency
free. Matching follows gitignore semantics: patterns are evaluated in order
and the last matching pattern decides, `!` re-includes, a trailing `/`
restricts the pattern to directories, and a pattern containing a slash is
anchored to the repository root while others match any path segment.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

DEFAULT_IGNORE_PATTERNS: tuple[str, ...] = (
    ".git/",
    ".svn/",
    ".hg/",
    ".bzr/",
    ".idea/",
    ".vscode/",
    ".vs/",
    "node_modules/",
    "vendor/",
    "venv/",
    ".venv/",
    "__pycache__/",
    "site-packages/",
    ".mypy_cache/",
    ".pytest_cache/",
    "dist/",
    "out/",
    "output/",
    "bin/",
    "obj/",
    "target/",
    ".next/",
    ".nuxt/",
    ".vercel/",
    ".parcel-cache/",
    ".turbo/",
    "coverage/",
    "__tests__/",
    "__mocks__/",
    ".nyc_output/",
    "*.exe",
    "*.bin",
    "*.o",
    "*.so",
    "*.dll",
    "*.dylib",
    "*.class",
    "*.jar",
    "*.zip",
    "*.tar",
    "*.gz",
    "*.rar",
    "*.png",
    "*.jpg",
    "*.jpeg",
    "*.gif",
    "*.svg",
    "*.ico",
    "*.webp",
    "*.pdf",
    "*.wasm",
    "*.pyc",
    "*.doc",
    "*.docx",
    "*.mp4",
    "*.mp3",
    "*.wav",
    "*.woff",
    "*.woff2",
    "*.ttf",
    "*.db",
    "*.sqlite",
    "*.pem",
    "*.key",
    "*.crt",
    "*.csv",
    "*.parquet",
    "*.pkl",
    "*.map",
    "*.lock",
    "*.min.js",
    "*.bundle.js",
    "*.chunk.js",
    "*.min.css",
    "*.generated.ts",
    "*.generated.js",
    "*.generated.go",
    "*.d.ts",
    "*.pb.go",
    "*.pb.gw.go",
    "*_generated.go",
    "*_gen.go",
    "*_string.go",
    "*.zz_generated.go",
    "*.deepcopy.go",
    "*_enumer.go",
    "*.twirp.go",
    "*_easyjson.go",
    "*_ffjson.go",
    "*.mock.go",
    "*_mock.go",
    "*.pb.scala",
    "package-lock.json",
    "yarn.lock",
    "pnpm-lock.yaml",
    "composer.lock",
    "Cargo.lock",
    "go.sum",
    ".gitignore",
    ".gitattributes",
    ".npmrc",
    ".editorconfig",
    ".prettierrc",
    ".eslintignore",
    ".dockerignore",
    "LICENSE",
    "LICENSE.md",
    "CHANGELOG.md",
    ".env",
    ".env.local",
    ".env.production",
)


def parse_ignore_lines(text: str) -> tuple[str, ...]:
    lines: list[str] = []
    for raw in text.split("\n"):
        line = raw.rstrip("\r")
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        lines.append(line)
    return tuple(lines)


@dataclass(frozen=True)
class _CompiledPattern:
    regex: re.Pattern[str]
    # For dir-only patterns a non-directory path may only match strictly
    # beneath the named directory, never the path itself.
    beneath_regex: re.Pattern[str]
    negated: bool
    directory_only: bool


def _translate_glob(pattern: str) -> str:
    parts: list[str] = []
    index = 0
    while index < len(pattern):
        char = pattern[index]
        if char == "*":
            if pattern[index : index + 2] == "**":
                run_end = index
                while run_end < len(pattern) and pattern[run_end] == "*":
                    run_end += 1
                if (
                    index > 0
                    and pattern[index - 1] == "/"
                    and pattern[run_end : run_end + 1] == "/"
                ):
                    parts.append("(?:[^/]+/)*")
                    index = run_end + 1
                    continue
                parts.append(".*")
                index = run_end
                continue
            parts.append("[^/]*")
            index += 1
            continue
        if char == "?":
            parts.append("[^/]")
            index += 1
            continue
        if char == "[":
            end = pattern.find("]", index + 1)
            if end > index:
                inner = pattern[index + 1 : end]
                if inner.startswith("!"):
                    inner = "^" + inner[1:]
                parts.append("[" + inner.replace("\\", "\\\\") + "]")
                index = end + 1
                continue
        parts.append(re.escape(char))
        index += 1
    return "".join(parts)


def _compile_pattern(line: str) -> _CompiledPattern | None:
    pattern = line
    negated = pattern.startswith("!")
    if negated:
        pattern = pattern[1:]
    pattern = pattern.rstrip()
    if not pattern:
        return None
    directory_only = pattern.endswith("/")
    pattern = pattern.rstrip("/")
    if not pattern:
        return None
    anchored = pattern.startswith("/")
    pattern = pattern.lstrip("/")
    if pattern.startswith("**/"):
        anchored = False
        pattern = pattern[3:]
    if "/" in pattern:
        anchored = True
    body = _translate_glob(pattern)
    prefix = "^" if anchored else "^(?:.*/)?"
    # A matched directory also ignores everything beneath it.
    regex = re.compile(prefix + body + r"(?:/.*)?$")
    beneath_regex = re.compile(prefix + body + r"/.*$")
    return _CompiledPattern(regex, beneath_regex, negated, directory_only)


class GitIgnoreMatcher:
    """Ordered gitignore-style matcher; the last matching pattern wins."""

    def __init__(self, lines: tuple[str, ...]) -> None:
        compiled = (_compile_pattern(line) for line in lines)
        self._patterns = tuple(pattern for pattern in compiled if pattern is not None)

    def matches(self, relative_path: str, *, is_dir: bool) -> bool:
        ignored = False
        for pattern in self._patterns:
            regex = (
                pattern.beneath_regex if pattern.directory_only and not is_dir else pattern.regex
            )
            if regex.match(relative_path):
                ignored = not pattern.negated
        return ignored
