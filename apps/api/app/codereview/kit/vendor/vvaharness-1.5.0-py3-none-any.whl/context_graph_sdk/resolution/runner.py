# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Authoritative resolution stage order for one project analysis."""

from __future__ import annotations

from collections.abc import Sequence

from context_graph_sdk.extractors.records import ExtractionResult
from context_graph_sdk.project.config import ProjectConfig
from context_graph_sdk.resolution.bindings import resolve_assignments, resolve_type_bindings
from context_graph_sdk.resolution.calls import resolve_calls_spawns_delegates
from context_graph_sdk.resolution.context import ResolutionContext, ResolutionResult
from context_graph_sdk.resolution.heritage import resolve_heritage, resolve_structural_interfaces
from context_graph_sdk.resolution.imports import resolve_imports
from context_graph_sdk.resolution.mro import compute_mro


def resolve_project(
    files: Sequence[tuple[str, str]],
    folder_paths: Sequence[str],
    extraction: ExtractionResult,
    config: ProjectConfig,
) -> ResolutionResult:
    """Resolve imports, calls, heritage, bindings, and MRO in dependency order.

    `files` are the walker's (path, language) pairs, the authoritative
    language source even for files that produced no symbols.
    """
    context = ResolutionContext(files, folder_paths, extraction, config)
    result = ResolutionResult()
    resolve_imports(context, result)
    resolve_calls_spawns_delegates(context, result)
    resolve_heritage(context, result)
    resolve_structural_interfaces(context, result)
    resolve_assignments(context, result)
    resolve_type_bindings(context, result)
    compute_mro(context, result)
    return result
