# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Explicit registry for trusted project-local graph enrichers."""

from __future__ import annotations

from collections.abc import Iterable, Iterator

from context_graph_sdk.errors import ModelValidationError

from .base import GraphEnricher, PluginMetadata, PluginPhase

MAX_LOCAL_PLUGINS = 64
_MAX_NAME_LENGTH = 128
_MAX_VERSION_LENGTH = 64
_MAX_PRIORITY = 10_000
_LOCAL_PHASES = frozenset({PluginPhase.PRE_DERIVATION, PluginPhase.POST_DERIVATION})


class PluginRegistry:
    def __init__(self, plugins: Iterable[object] = ()) -> None:
        candidates = tuple(plugins)
        if len(candidates) > MAX_LOCAL_PLUGINS:
            raise ModelValidationError(f"local plugin count exceeds {MAX_LOCAL_PLUGINS}")
        registered: list[GraphEnricher] = []
        names: set[str] = set()
        for plugin in candidates:
            if not isinstance(plugin, GraphEnricher):
                raise ModelValidationError("local plugin must implement GraphEnricher")
            metadata = plugin.metadata
            _validate_metadata(metadata)
            if metadata.name in names:
                raise ModelValidationError(f"duplicate local plugin name: {metadata.name}")
            names.add(metadata.name)
            registered.append(plugin)
        self._plugins = tuple(sorted(registered, key=lambda plugin: plugin.metadata.ordering_key))

    def __bool__(self) -> bool:
        return bool(self._plugins)

    def __len__(self) -> int:
        return len(self._plugins)

    def __iter__(self) -> Iterator[GraphEnricher]:
        return iter(self._plugins)

    def for_phase(self, phase: PluginPhase) -> tuple[GraphEnricher, ...]:
        if phase not in _LOCAL_PHASES:
            raise ModelValidationError(f"unsupported local plugin phase: {phase.value}")
        return tuple(plugin for plugin in self._plugins if plugin.metadata.phase == phase)


def _validate_metadata(metadata: PluginMetadata) -> None:
    if metadata.phase not in _LOCAL_PHASES:
        raise ModelValidationError(
            f"local plugin {metadata.name!r} uses unsupported phase {metadata.phase.value}"
        )
    if len(metadata.name) > _MAX_NAME_LENGTH:
        raise ModelValidationError("plugin name exceeds bound")
    if len(metadata.version) > _MAX_VERSION_LENGTH:
        raise ModelValidationError("plugin version exceeds bound")
    if not -_MAX_PRIORITY <= metadata.priority <= _MAX_PRIORITY:
        raise ModelValidationError("plugin priority exceeds bound")
