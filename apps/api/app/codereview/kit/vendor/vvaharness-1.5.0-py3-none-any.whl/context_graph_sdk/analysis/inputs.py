# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared derived-analysis input model.

Communities and processes consume one neutral input shape so the record
path (extraction + resolution, used by unit fixtures) and the snapshot
path (graph nodes/edges after pre-derivation plugins) share a single
algorithm implementation.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from context_graph_sdk.extractors.records import ExtractionResult
from context_graph_sdk.models import GraphSnapshot, LocalRelationshipType
from context_graph_sdk.resolution.context import ResolutionResult

ANALYSIS_RELATIONSHIPS = (
    LocalRelationshipType.CALLS.value,
    LocalRelationshipType.SPAWNS.value,
    LocalRelationshipType.DELEGATES_TO.value,
)


# Labels the analysis algorithms branch on; multi-label graph nodes pick the
# first present entry so incidental extra labels cannot mask a callable.
_ANALYSIS_LABEL_PRIORITY = ("Method", "Function", "Class")


@dataclass(frozen=True)
class AnalysisNode:
    id: str  # repository-local identity
    name: str
    label: str
    file_path: str
    is_exported: bool
    language: str
    owner_name: str = ""


@dataclass
class AnalysisInputs:
    nodes: dict[str, AnalysisNode] = field(default_factory=dict[str, AnalysisNode])
    # (source local id, target local id, relationship value, confidence)
    edges: list[tuple[str, str, str, float]] = field(
        default_factory=list[tuple[str, str, str, float]]
    )


def inputs_from_records(
    extraction: ExtractionResult, resolution: ResolutionResult
) -> AnalysisInputs:
    inputs = AnalysisInputs()
    for _, file_result in extraction.files:
        for symbol in file_result.symbols:
            inputs.nodes[symbol.id] = AnalysisNode(
                symbol.id,
                symbol.name,
                symbol.label,
                symbol.file_path,
                symbol.is_exported,
                symbol.language,
                symbol.owner_name,
            )
    for edge in resolution.edges:
        if edge.relationship.value not in ANALYSIS_RELATIONSHIPS:
            continue
        confidence = 1.0
        for key, value in edge.properties:
            if key == "confidence" and isinstance(value, (int, float)):
                confidence = float(value)
        inputs.edges.append(
            (edge.source_local_id, edge.target_local_id, edge.relationship.value, confidence)
        )
    return inputs


def inputs_from_snapshot(snapshot: GraphSnapshot) -> AnalysisInputs:
    """Adapter over graph nodes/edges so pre-derivation plugin mutations
    influence derived analysis exactly like built-in extraction output."""
    inputs = AnalysisInputs()
    local_by_global: dict[str, str] = {}
    owners: dict[str, str] = {}
    for edge in snapshot.edges:
        if edge.relationship_type == LocalRelationshipType.HAS_METHOD.value:
            owners[edge.target_id] = edge.source_id
    names_by_global: dict[str, str] = {}
    for node in snapshot.nodes:
        properties = node.properties.to_dict()
        name = properties.get("name")
        if isinstance(name, str):
            names_by_global[node.id] = name
    for node in snapshot.nodes:
        properties = node.properties.to_dict()
        name = properties.get("name")
        if not isinstance(name, str) or not name:
            continue
        file_path = properties.get("filePath")
        language = properties.get("language")
        exported = properties.get("isExported")
        owner_global = owners.get(node.id)
        local_by_global[node.id] = node.local_id
        label = next(
            (candidate for candidate in _ANALYSIS_LABEL_PRIORITY if candidate in node.labels),
            node.labels[0] if node.labels else "",
        )
        inputs.nodes[node.local_id] = AnalysisNode(
            node.local_id,
            name,
            label,
            file_path if isinstance(file_path, str) else "",
            bool(exported) if isinstance(exported, bool) else False,
            language if isinstance(language, str) else "",
            names_by_global.get(owner_global, "") if owner_global else "",
        )
    for edge in snapshot.edges:
        if edge.relationship_type not in ANALYSIS_RELATIONSHIPS:
            continue
        source = local_by_global.get(edge.source_id)
        target = local_by_global.get(edge.target_id)
        if source is None or target is None:
            continue
        confidence = 1.0
        raw = edge.properties.to_dict().get("confidence")
        if isinstance(raw, (int, float)):
            confidence = float(raw)
        inputs.edges.append((source, target, edge.relationship_type, confidence))
    return inputs
