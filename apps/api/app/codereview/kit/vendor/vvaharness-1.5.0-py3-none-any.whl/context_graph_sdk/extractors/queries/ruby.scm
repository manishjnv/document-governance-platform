; Production extraction query set for ruby, ported from the reviewed reference.
(class name: (constant) @name) @definition.class
(module name: (constant) @name) @definition.module
(method name: (identifier) @name) @definition.method
(singleton_method name: (identifier) @name) @definition.function
(call method: (identifier) @call.name) @call
(class name: (constant) @heritage.class superclass: (superclass (constant) @heritage.extends)) @heritage
(call method: (identifier) @_fn (#match? @_fn "^(include|extend|prepend)$") arguments: (argument_list (constant) @heritage.extends)) @heritage
(call method: (identifier) @_fn (#match? @_fn "^(attr_accessor|attr_reader|attr_writer)$") arguments: (argument_list (simple_symbol) @name)) @definition.property
(call receiver: (constant) @_recv (#eq? @_recv "Thread") method: (identifier) @_fn (#eq? @_fn "new")) @spawn
(call arguments: (argument_list (identifier) @delegate.target)) @delegate
