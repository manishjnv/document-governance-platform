# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Workspace lifecycle and synthetic snapshot publication vertical."""

from __future__ import annotations

import json
import logging
import os
import shutil
import threading
import time
import uuid
from collections.abc import Iterable
from contextlib import suppress
from pathlib import Path
from types import TracebackType
from typing import cast

from context_graph_sdk.analysis import derive_snapshot
from context_graph_sdk.backends import GraphBackendFactory
from context_graph_sdk.code_graph import CodeGraph
from context_graph_sdk.discovery import read_documentation_text, walk_repository
from context_graph_sdk.errors import (
    DiscoveryError,
    LifecycleError,
    ModelValidationError,
    SnapshotLifecycleError,
    StructuredQueryLimitError,
    WorkspaceClosedError,
    WorkspaceLockedError,
)
from context_graph_sdk.extractors import analysis_components
from context_graph_sdk.graph import build_structural_snapshot
from context_graph_sdk.identity import ProjectId, SnapshotId
from context_graph_sdk.ingestion import run_builtin_ingestion
from context_graph_sdk.models import (
    AnalysisVersion,
    CatalogPublication,
    CorrelationEdge,
    FrozenMap,
    GraphNode,
    GraphSnapshot,
    NodeRef,
    ProjectMetadata,
    ProjectSnapshot,
    ProviderManifest,
    ResolvedCorrelation,
    SnapshotInfo,
    SnapshotLocator,
    freeze_properties,
)
from context_graph_sdk.normalization import graph_fingerprint
from context_graph_sdk.plugins import CorrelationProvider, GraphEnricher
from context_graph_sdk.plugins.context import (
    BufferedPluginReporter,
    CancellationToken,
    RepositorySourceReader,
)
from context_graph_sdk.plugins.correlation import (
    BoundedAcceptedGraphReader,
    CorrelationEndpointValidator,
    CorrelationProviderRegistry,
    CorrelationRunner,
)
from context_graph_sdk.plugins.registry import PluginRegistry
from context_graph_sdk.plugins.runner import DEFAULT_LOCAL_PLUGIN_TIMEOUT_SECONDS, LocalPluginRunner
from context_graph_sdk.progress import AnalysisPhase, AnalysisProgress, AnalysisProgressCallback
from context_graph_sdk.query import QueryLimits, QueryWorkerRequest, WorkerPoolLimits
from context_graph_sdk.query.worker import QueryWorkerManager, SpawnQueryWorkerManager
from context_graph_sdk.resolution import resolve_project
from context_graph_sdk.workspace.catalog import WorkspaceCatalog
from context_graph_sdk.workspace.contracts import SnapshotLease
from context_graph_sdk.workspace.handles import SnapshotLeaseRegistry
from context_graph_sdk.workspace.locking import WorkspaceFileLock

_CONCURRENT_CLOSE_WAIT_SECONDS = 75.0
_ANALYSIS_STEP_COUNT = 8
_LOGGER = logging.getLogger(__name__)


def _emit_progress(
    callback: AnalysisProgressCallback | None,
    phase: AnalysisPhase,
    message: str,
    step: int,
    *,
    completed: int | None = None,
    total: int | None = None,
    finished: bool = False,
) -> None:
    if callback is None:
        return
    event = AnalysisProgress(
        phase,
        message,
        step,
        _ANALYSIS_STEP_COUNT,
        completed,
        total,
        finished,
    )
    # Progress is observational and must never change publication semantics.
    try:
        callback(event)
    except Exception:
        _LOGGER.debug("analysis progress callback failed", exc_info=True)


# Windows-only: antivirus or file-indexing can briefly hold a handle on a file
# inside the publication folder at the exact moment it is renamed into place,
# raising WinError 5 ("Access is denied") or WinError 32 ("The process cannot
# access the file because it is being used by another process"). Both are
# transient. Retrying is scoped to exactly those two codes and bounded to
# _PUBLISH_RETRY_TIMEOUT_SECONDS; any other error, or the same error past the
# deadline, is raised immediately. macOS/Linux never hit this class of error,
# so this never retries there.
_WINDOWS_TRANSIENT_LOCK_WINERRORS = frozenset({5, 32})
_PUBLISH_RETRY_TIMEOUT_SECONDS = 10.0
_PUBLISH_RETRY_POLL_SECONDS = 0.50


def _replace_with_windows_lock_retry(source: Path, destination: Path) -> None:
    if os.name != "nt":
        os.replace(source, destination)
        return
    deadline = time.monotonic() + _PUBLISH_RETRY_TIMEOUT_SECONDS
    while True:
        try:
            os.replace(source, destination)
            return
        except OSError as exc:
            if getattr(exc, "winerror", None) not in _WINDOWS_TRANSIENT_LOCK_WINERRORS:
                raise
            if time.monotonic() >= deadline:
                raise
            time.sleep(_PUBLISH_RETRY_POLL_SECONDS)


class Workspace:
    """Owns one physical-snapshot workspace and its manager-only catalog."""

    def __init__(
        self,
        path: str | Path,
        backend_factory: GraphBackendFactory,
        *,
        worker_manager: QueryWorkerManager | None = None,
        correlation_providers: Iterable[CorrelationProvider] = (),
        default_query_limits: QueryLimits | None = None,
    ) -> None:
        if worker_manager is None:
            from context_graph_sdk.backends.arcadedb import ArcadeDBBackendFactory

            if not isinstance(backend_factory, ArcadeDBBackendFactory):
                raise TypeError(
                    "non-Arcade backend factories require an explicit query worker manager"
                )
        self.path = Path(path).expanduser().resolve()
        self.path.mkdir(parents=True, exist_ok=True)
        self._factory = backend_factory
        try:
            self._workspace_lock = WorkspaceFileLock(self.path / ".workspace.lock")
        except BlockingIOError as exc:
            raise WorkspaceLockedError(f"workspace is already owned: {self.path}") from exc
        workers = worker_manager
        catalog: WorkspaceCatalog | None = None
        try:
            if workers is None:
                workers = SpawnQueryWorkerManager(WorkerPoolLimits(1))
            self._closed = False
            self._closing = False
            self._close_complete = threading.Event()
            self._close_failure: LifecycleError | None = None
            self._state_lock = threading.RLock()
            self._request_counter = 0
            self._leases = SnapshotLeaseRegistry()
            self._retired: dict[str, SnapshotLocator] = {}
            self._correlation_registry = CorrelationProviderRegistry(correlation_providers)
            self._correlation_runner = CorrelationRunner()
            self._local_plugin_runner = LocalPluginRunner()
            # Interim: the deadline also pays worker startup (JVM, snapshot open), so it matches
            # the recovery window until startup gets its own budget.
            self.default_query_limits = default_query_limits or QueryLimits(
                30.0, 1024 * 1024 * 1024, 1_000, 1024 * 1024
            )
            self._workers = workers
            catalog_path = self.path / "catalog"
            catalog_backend = (
                self._factory.open_catalog(catalog_path)
                if catalog_path.exists()
                else self._factory.create_catalog(catalog_path)
            )
            catalog = WorkspaceCatalog(catalog_backend)
            self._catalog = catalog
            self._validate_catalog_snapshots()
            self._reconcile()
            self._preflight_all_providers()
            for snapshot in self._catalog.accepted_snapshots():
                fingerprint, node_count, edge_count = _read_snapshot_integrity(
                    snapshot.locator.database_path
                )
                self._workers.authorize(
                    snapshot.locator.database_path, fingerprint, node_count, edge_count
                )
        except Exception:
            if workers is not None:
                with suppress(Exception):
                    workers.close()
            if catalog is not None:
                with suppress(Exception):
                    catalog.close()
            self._workspace_lock.release()
            raise

    def __enter__(self) -> Workspace:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        self.close()

    def analyze(
        self,
        repository: str | Path,
        project_id: ProjectId | str,
        plugins: Iterable[GraphEnricher] = (),
        *,
        progress: AnalysisProgressCallback | None = None,
    ) -> CodeGraph:
        """Analyze one repository and atomically publish its project snapshot."""
        self._ensure_open()
        registry = PluginRegistry(plugins)
        resolved = project_id if isinstance(project_id, ProjectId) else ProjectId(project_id)
        self._preflight_all_providers()
        repository_path = Path(repository)
        if not repository_path.is_dir():
            raise DiscoveryError(f"repository is not a directory: {repository}")
        _emit_progress(progress, AnalysisPhase.DISCOVERY, "Discovering files", 1)
        walk = walk_repository(repository_path)
        _emit_progress(
            progress,
            AnalysisPhase.CONFIGURATION,
            "Reading project configuration",
            2,
        )
        ingestion = run_builtin_ingestion(
            walk,
            on_language_start=lambda: _emit_progress(
                progress, AnalysisPhase.EXTRACTION, "Extracting symbols", 3
            ),
            on_file_progress=lambda completed, total: _emit_progress(
                progress,
                AnalysisPhase.EXTRACTION,
                "Extracting symbols",
                3,
                completed=completed,
                total=total,
            ),
        )
        config = ingestion.config
        documentation = {
            file.relative_path: content
            for file in walk.files
            if file.is_documentation
            and (content := read_documentation_text(walk.root, file.relative_path))
        }
        extraction = ingestion.extraction
        _emit_progress(progress, AnalysisPhase.RESOLUTION, "Resolving relationships", 4)
        resolution = resolve_project(
            [(file.relative_path, file.language) for file in walk.files],
            list(walk.directories),
            extraction,
            config,
        )
        _emit_progress(progress, AnalysisPhase.GRAPH_BUILD, "Building candidate graph", 5)
        metadata = ProjectMetadata(
            resolved,
            Path(walk.root).name or resolved.value,
            source_path=walk.root,
        )
        components = (
            ("analysis", "1"),
            ("discovery", "1"),
            ("extractors", "1"),
            *analysis_components(),
        )
        # Base resolved snapshot (no derived analysis yet): PRE_DERIVATION
        # plugin mutations must influence communities/processes, so the
        # runner's derive callback performs derivation exactly once between
        # the plugin phases — also on the no-plugin path.
        snapshot = build_structural_snapshot(
            metadata,
            SnapshotId(uuid.uuid4().hex),
            AnalysisVersion(_sdk_version(), components),
            walk,
            config,
            documentation,
            extraction,
            resolution,
        )
        _emit_progress(
            progress,
            AnalysisPhase.DERIVATION,
            "Running plugins and derived analysis",
            6,
        )
        cancellation = CancellationToken()
        deadline = time.monotonic() + DEFAULT_LOCAL_PLUGIN_TIMEOUT_SECONDS
        result = self._local_plugin_runner.run(
            snapshot,
            registry,
            source_reader=RepositorySourceReader(Path(walk.root)),
            cancellation=cancellation,
            deadline_monotonic=deadline,
            configuration=FrozenMap(),
            derive=derive_snapshot,
        )
        _emit_progress(progress, AnalysisPhase.CORRELATION, "Correlating projects", 7)
        accepted = tuple(
            accepted_snapshot
            for accepted_snapshot in self._catalog.accepted_snapshots()
            if accepted_snapshot.project.project_id != resolved
        )
        graph_reader = BoundedAcceptedGraphReader(
            accepted,
            self._execute_accepted_query,
            self._correlation_runner.limits,
            deadline,
        )
        endpoint_validator = CorrelationEndpointValidator(
            accepted,
            self._execute_accepted_query,
            self._correlation_runner.limits.max_total_edges,
            deadline,
        )
        correlation_result = self._correlation_runner.run(
            result.snapshot,
            accepted,
            self._correlation_registry,
            graph_reader=graph_reader,
            endpoint_validator=endpoint_validator,
            reporter=BufferedPluginReporter(),
            cancellation=cancellation,
            deadline_monotonic=deadline,
            configuration=FrozenMap(),
        )
        _emit_progress(progress, AnalysisPhase.PUBLICATION, "Publishing snapshot", 8)
        graph = self._publish_snapshot(
            result.snapshot,
            node_refs=correlation_result.node_refs,
            correlations=correlation_result.correlations,
            provider_manifests=correlation_result.manifests,
        )
        _emit_progress(
            progress,
            AnalysisPhase.PUBLICATION,
            "Analysis complete",
            8,
            finished=True,
        )
        return graph

    def project(self, project_id: ProjectId | str) -> CodeGraph:
        self._ensure_open()
        resolved = project_id if isinstance(project_id, ProjectId) else ProjectId(project_id)
        if self._catalog.accepted_snapshot(resolved) is None:
            raise SnapshotLifecycleError(f"project has no accepted snapshot: {resolved}")
        return CodeGraph(self, resolved)

    def snapshot_info(self, project_id: ProjectId | str) -> SnapshotInfo:
        """The accepted snapshot's published fingerprint and node/edge counts, from its sidecar."""
        resolved = project_id if isinstance(project_id, ProjectId) else ProjectId(project_id)
        snapshot, lease = self._resolve_with_lease(resolved)
        try:
            return SnapshotInfo(*_read_snapshot_integrity(snapshot.locator.database_path))
        finally:
            lease.release()

    def close(self) -> None:
        with self._state_lock:
            if self._closed:
                return
            if self._closing:
                close_complete = self._close_complete
            else:
                self._closing = True
                close_complete = None
        if close_complete is not None:
            if not close_complete.wait(_CONCURRENT_CLOSE_WAIT_SECONDS):
                raise LifecycleError("concurrent workspace close did not finish")
            with self._state_lock:
                failure = self._close_failure
            if failure is not None:
                raise failure
            return
        failures: list[Exception] = []
        try:
            try:
                self._workers.close()
            except Exception as exc:
                failures.append(exc)
            leases_drained = self._leases.wait_for_zero(10.0)
            if not leases_drained:
                failures.append(LifecycleError("workspace leases did not drain before close"))
            if leases_drained:
                for close_resource in (self._catalog.close, self._leases.close):
                    try:
                        close_resource()
                    except Exception as exc:
                        failures.append(exc)
                if not failures:
                    try:
                        self._workspace_lock.release()
                    except Exception as exc:
                        failures.append(exc)
            failure = _cleanup_failure(failures) if failures else None
            with self._state_lock:
                self._close_failure = failure
                self._closed = failure is None
            if failure is not None:
                raise failure
        finally:
            self._close_complete.set()

    def _publish_snapshot(
        self,
        snapshot: GraphSnapshot,
        *,
        node_refs: tuple[NodeRef, ...] = (),
        correlations: tuple[CorrelationEdge, ...] = (),
        provider_manifests: tuple[ProviderManifest, ...] = (),
        fail_before_commit: bool = False,
    ) -> CodeGraph:
        """Single internal publication seam; `analyze()` is the public caller."""
        self._ensure_open()
        project = snapshot.project.project_id
        final_path = self.path / "projects" / project.value / snapshot.snapshot_id.value
        candidate_path = self.path / "candidates" / f"{project.value}-{snapshot.snapshot_id.value}"
        if final_path.exists() or candidate_path.exists():
            raise SnapshotLifecycleError("snapshot database path already exists")
        candidate_locator = SnapshotLocator(project, snapshot.snapshot_id, str(candidate_path))
        backend = None
        fingerprint = graph_fingerprint(snapshot)
        moved = False
        authorized = False
        try:
            backend = self._factory.create_project(candidate_locator)
            persisted_nodes = tuple(
                GraphNode(
                    node.project_id,
                    node.local_id,
                    node.labels,
                    freeze_properties(
                        {
                            **node.properties.to_dict(),
                            "snapshotId": snapshot.snapshot_id.value,
                            "analysisVersion": snapshot.analysis_version.sdk_version,
                        }
                    ),
                )
                for node in snapshot.nodes
            )
            with backend.begin_write() as transaction:
                for start in range(0, len(persisted_nodes), 10_000):
                    transaction.write_nodes(persisted_nodes[start : start + 10_000])
                for start in range(0, len(snapshot.edges), 10_000):
                    transaction.write_edges(snapshot.edges[start : start + 10_000])
                transaction.commit()
            backend.close()
            backend = None
            (candidate_path / ".context-graph-sdk-fingerprint").write_text(
                json.dumps(
                    {
                        "fingerprint": fingerprint,
                        "nodeCount": len(snapshot.nodes),
                        "edgeCount": len(snapshot.edges),
                    },
                    separators=(",", ":"),
                    sort_keys=True,
                )
                + "\n"
            )
            final_path.parent.mkdir(parents=True, exist_ok=True)
            _replace_with_windows_lock_retry(candidate_path, final_path)
            moved = True
            locator = SnapshotLocator(project, snapshot.snapshot_id, str(final_path))
            record = ProjectSnapshot(
                snapshot.project,
                snapshot.snapshot_id,
                locator,
                snapshot.analysis_version,
                True,
            )
            publication = CatalogPublication(record, node_refs, correlations, provider_manifests)
            with self._state_lock:
                previous = self._catalog.accepted_snapshot(project)
                self._workers.authorize(
                    locator.database_path, fingerprint, len(snapshot.nodes), len(snapshot.edges)
                )
                authorized = True
                self._catalog.publish(publication, fail_before_commit=fail_before_commit)
                if previous is not None:
                    self._retired[previous.locator.database_path] = previous.locator
        except Exception:
            if backend is not None:
                backend.close()
            if authorized:
                self._workers.revoke(str(final_path))
            shutil.rmtree(final_path if moved else candidate_path, ignore_errors=True)
            raise
        self._collect_retired()
        return CodeGraph(self, project)

    def _execute_accepted_query(
        self,
        locator: SnapshotLocator,
        cypher: str,
        parameters: FrozenMap,
        row_limit: int,
        timeout_seconds: float,
    ) -> tuple[FrozenMap, ...]:
        with self._state_lock:
            accepted = self._catalog.accepted_snapshot(locator.project_id)
            if accepted is None or accepted.locator != locator:
                raise SnapshotLifecycleError("provider snapshot is no longer accepted")
            lease = self._leases.acquire(locator).__enter__()
        try:
            limits = self.default_query_limits
            result = self._workers.execute(
                QueryWorkerRequest(
                    self._next_request_id(),
                    locator,
                    cypher,
                    parameters,
                    QueryLimits(
                        min(limits.timeout_seconds, timeout_seconds),
                        limits.memory_bytes,
                        row_limit,
                        limits.byte_limit,
                    ),
                )
            )
            if result.truncated:
                raise ModelValidationError("provider read result exceeded its declared bound")
            return result.rows
        finally:
            lease.release()
            self._collect_retired()

    def _resolve_correlations_with_leases(
        self, node_id: str, result_limit: int
    ) -> tuple[tuple[ResolvedCorrelation, ...], tuple[SnapshotLease, ...]]:
        self._ensure_open()
        for attempt in range(2):
            with self._state_lock:
                try:
                    resolved = self._catalog.resolve_correlations(node_id, result_limit)
                except ModelValidationError as exc:
                    if "limit" in str(exc):
                        raise StructuredQueryLimitError(str(exc)) from exc
                    raise
                leases_by_path: dict[str, SnapshotLease] = {}
                try:
                    for item in resolved:
                        locator = item.related_snapshot.locator
                        if locator.database_path not in leases_by_path:
                            leases_by_path[locator.database_path] = self._leases.acquire(
                                locator
                            ).__enter__()
                except Exception:
                    for lease in leases_by_path.values():
                        lease.release()
                    raise
                leases = tuple(leases_by_path.values())
                missing = any(
                    not Path(item.related_snapshot.locator.database_path).exists()
                    for item in resolved
                )
            if not missing:
                return resolved, leases
            for lease in leases:
                lease.release()
            if attempt == 1:
                raise SnapshotLifecycleError(
                    "correlation target snapshot is unavailable after re-resolution"
                )
        raise AssertionError("bounded correlation resolution exhausted")

    def _resolve_with_lease(self, project_id: ProjectId):
        self._ensure_open()
        with self._state_lock:
            snapshot = self._catalog.accepted_snapshot(project_id)
            if snapshot is None:
                raise SnapshotLifecycleError(f"project has no accepted snapshot: {project_id}")
            lease = self._leases.acquire(snapshot.locator).__enter__()
            return snapshot, lease

    def _collect_retired(self) -> None:
        with self._state_lock:
            for path, locator in tuple(self._retired.items()):
                if self._leases.active_count(locator) == 0:
                    try:
                        self._factory.delete_project(locator)
                    except OSError:
                        continue
                    self._workers.revoke(path)
                    del self._retired[path]

    def _next_request_id(self) -> str:
        with self._state_lock:
            self._request_counter += 1
            return f"query-{self._request_counter}-{uuid.uuid4().hex}"

    def _validate_catalog_snapshots(self) -> None:
        projects = (self.path / "projects").resolve()
        for snapshot in self._catalog.accepted_snapshots():
            locator = snapshot.locator
            expected = projects / locator.project_id.value / locator.snapshot_id.value
            try:
                canonical = Path(locator.database_path).resolve(strict=True)
                expected_canonical = expected.resolve(strict=True)
            except OSError as exc:
                raise SnapshotLifecycleError(
                    f"catalog snapshot locator is stale: {locator.database_path}"
                ) from exc
            if (
                canonical != expected_canonical
                or canonical == projects
                or projects not in canonical.parents
            ):
                raise SnapshotLifecycleError(
                    f"catalog snapshot locator is outside this workspace: {locator.database_path}"
                )

    def _reconcile(self) -> None:
        accepted = {
            Path(snapshot.locator.database_path).resolve()
            for snapshot in self._catalog.accepted_snapshots()
        }
        candidates = self.path / "candidates"
        if candidates.exists():
            for path in candidates.iterdir():
                if path.is_dir():
                    shutil.rmtree(path)
        projects = self.path / "projects"
        if projects.exists():
            for project_dir in projects.iterdir():
                if not project_dir.is_dir():
                    continue
                for snapshot_dir in project_dir.iterdir():
                    if snapshot_dir.is_dir() and snapshot_dir.resolve() not in accepted:
                        shutil.rmtree(snapshot_dir)

    def _preflight_all_providers(self) -> None:
        for snapshot in self._catalog.accepted_snapshots():
            project_id = snapshot.project.project_id
            self._correlation_registry.preflight(
                project_id,
                self._catalog.provider_manifests(project_id),
                self._catalog.correlations_touching(project_id),
            )

    def _ensure_open(self) -> None:
        if self._closed or self._closing:
            raise WorkspaceClosedError("workspace is closed")


def _cleanup_failure(failures: list[Exception]) -> LifecycleError:
    details = "; ".join(f"{type(failure).__name__}: {failure}" for failure in failures)
    error = LifecycleError(f"workspace cleanup failed: {details}")
    error.__cause__ = failures[0]
    return error


def _sdk_version() -> str:
    import importlib.metadata

    try:
        return importlib.metadata.version("context-graph-sdk")
    except importlib.metadata.PackageNotFoundError:
        return "0"


def _read_snapshot_integrity(database_path: str) -> tuple[str, int, int]:
    try:
        content = (Path(database_path) / ".context-graph-sdk-fingerprint").read_text()
        parsed: object = json.loads(content)
        if not isinstance(parsed, dict):
            raise ValueError("integrity sidecar is not an object")
        payload = cast(dict[str, object], parsed)
        fingerprint = payload.get("fingerprint")
        node_count = payload.get("nodeCount")
        edge_count = payload.get("edgeCount")
        if (
            not isinstance(fingerprint, str)
            or not isinstance(node_count, int)
            or not isinstance(edge_count, int)
        ):
            raise ValueError("integrity sidecar fields are invalid")
        return fingerprint, node_count, edge_count
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise SnapshotLifecycleError(
            f"invalid snapshot integrity sidecar: {database_path}"
        ) from exc
