# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Root-file resolution configuration for supported package ecosystems."""

from __future__ import annotations

import posixpath
import re

from context_graph_sdk.project.config import ManifestReader, ProjectConfig, ResolutionSettings

from ._data import as_mapping, as_str, mapping_at, parse_json_object, string_list

_ROOT_NAMESPACE = re.compile(r"<RootNamespace>([^<]+)</RootNamespace>")
_SWIFT_TARGET = re.compile(r'\.(?:target|executableTarget|testTarget)\s*\(\s*name:\s*"([^"]+)"')
_SWIFT_PATH = re.compile(r'path:\s*"([^"]+)"')


def _go_module_path(reader: ManifestReader) -> str:
    text = reader.read_text("go.mod") if "go.mod" in reader.files else None
    if text is None:
        return ""
    for line in text.split("\n"):
        stripped = line.split("//", 1)[0].strip()
        if stripped.startswith("module "):
            return stripped[len("module ") :].strip()
    return ""


def _string_list_map(value: object) -> tuple[tuple[str, tuple[str, ...]], ...]:
    mapping = as_mapping(value) or {}
    entries: list[tuple[str, tuple[str, ...]]] = []
    for key, item in sorted(mapping.items()):
        if isinstance(item, str):
            entries.append((key, (item,)))
        else:
            values = string_list(item)
            if values:
                entries.append((key, values))
    return tuple(entries)


def _ts_config(reader: ManifestReader) -> tuple[str, tuple[tuple[str, tuple[str, ...]], ...]]:
    for name in ("tsconfig.json", "jsconfig.json"):
        if name not in reader.files:
            continue
        loaded = _load_ts_config(reader, name, set(), 0)
        if loaded is not None:
            return loaded
    return "", ()


def _load_ts_config(
    reader: ManifestReader, relative_path: str, seen: set[str], depth: int
) -> tuple[str, tuple[tuple[str, tuple[str, ...]], ...]] | None:
    if depth >= 32 or relative_path in seen:
        return None
    seen.add(relative_path)
    text = reader.read_text(relative_path)
    parsed = parse_json_object(text) if text is not None else None
    if parsed is None:
        return None
    options = mapping_at(parsed, "compilerOptions")
    base_url = as_str(options.get("baseUrl"))
    paths = _string_list_map(options.get("paths"))
    extends = as_str(parsed.get("extends"))
    if extends and (not base_url or not paths):
        if not extends.endswith(".json"):
            extends += ".json"
        parent = posixpath.normpath(posixpath.join(posixpath.dirname(relative_path), extends))
        inherited = _load_ts_config(reader, parent, seen, depth + 1)
        if inherited is not None:
            base_url = base_url or inherited[0]
            paths = paths or inherited[1]
    return base_url, paths


def _composer_psr4(reader: ManifestReader) -> tuple[tuple[str, tuple[str, ...]], ...]:
    if "composer.json" not in reader.files:
        return ()
    text = reader.read_text("composer.json")
    parsed = parse_json_object(text) if text is not None else None
    if parsed is None:
        return ()
    return _string_list_map(mapping_at(parsed, "autoload").get("psr-4"))


def _csharp_root_namespace(reader: ManifestReader) -> str:
    for relative in reader.by_extension(".csproj"):
        if "/" in relative:
            continue
        text = reader.read_text(relative)
        if text is None:
            continue
        match = _ROOT_NAMESPACE.search(text)
        if match:
            return match.group(1)
    return ""


def _swift_targets(reader: ManifestReader) -> tuple[tuple[str, str], ...]:
    if "Package.swift" not in reader.files:
        return ()
    text = reader.read_text("Package.swift")
    if text is None:
        return ()
    targets: list[tuple[str, str]] = []
    for match in _SWIFT_TARGET.finditer(text):
        name = match.group(1)
        window = text[match.end() : match.end() + 200]
        path_match = _SWIFT_PATH.search(window)
        targets.append((name, path_match.group(1) if path_match else f"Sources/{name}"))
    return tuple(targets)


def load_resolution_settings(reader: ManifestReader, config: ProjectConfig) -> None:
    base_url, paths = _ts_config(reader)
    config.resolution = ResolutionSettings(
        go_module_path=_go_module_path(reader),
        ts_config_base_url=base_url,
        ts_config_paths=paths,
        composer_psr4=_composer_psr4(reader),
        csharp_root_namespace=_csharp_root_namespace(reader),
        swift_targets=_swift_targets(reader),
    )
