# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Manager-owned snapshot lease contracts."""

from __future__ import annotations

from contextlib import AbstractContextManager
from typing import Protocol, runtime_checkable

from context_graph_sdk.models import SnapshotLocator


@runtime_checkable
class SnapshotLease(Protocol):
    @property
    def locator(self) -> SnapshotLocator: ...

    @property
    def released(self) -> bool: ...

    def release(self) -> None: ...


@runtime_checkable
class SnapshotLeaseManager(Protocol):
    """Prevents retirement while a physical snapshot is in use."""

    def acquire(self, locator: SnapshotLocator) -> AbstractContextManager[SnapshotLease]: ...

    def active_count(self, locator: SnapshotLocator) -> int: ...

    def close(self) -> None: ...
