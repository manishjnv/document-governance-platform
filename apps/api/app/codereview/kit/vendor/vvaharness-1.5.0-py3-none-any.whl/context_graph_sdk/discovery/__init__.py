# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deterministic bounded repository discovery."""

from .ignore import DEFAULT_IGNORE_PATTERNS, GitIgnoreMatcher, parse_ignore_lines
from .languages import detect_language, is_documentation_file
from .walker import (
    DEFAULT_MAX_FILE_BYTES,
    DOCUMENTATION_CONTENT_BYTES,
    RepositoryWalk,
    WalkedFile,
    read_documentation_text,
    walk_repository,
)

__all__ = [
    "DEFAULT_IGNORE_PATTERNS",
    "DEFAULT_MAX_FILE_BYTES",
    "DOCUMENTATION_CONTENT_BYTES",
    "GitIgnoreMatcher",
    "RepositoryWalk",
    "WalkedFile",
    "detect_language",
    "is_documentation_file",
    "parse_ignore_lines",
    "read_documentation_text",
    "walk_repository",
]
