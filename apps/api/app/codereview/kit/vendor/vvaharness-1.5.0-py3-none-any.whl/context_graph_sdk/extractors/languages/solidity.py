# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Solidity call filtering and modifier annotations."""

from __future__ import annotations

import re

from tree_sitter import Node

from context_graph_sdk.extractors.analysis import (
    extract_signature,
    first_identifier_text,
    node_text,
    walk,
)
from context_graph_sdk.extractors.records import is_valid_symbol_name

_RETURNS = re.compile(r"returns\s*\([^)]*\)")
_MODIFIER_NAME = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*(\(|$|\s)")
_NON_MODIFIER_TOKENS = frozenset(
    {
        "public",
        "external",
        "internal",
        "private",
        "view",
        "pure",
        "payable",
        "virtual",
        "override",
        "returns",
    }
)


def _ancestor_exact(node: Node, node_type: str, max_depth: int) -> Node | None:
    current = node.parent
    for _ in range(max_depth):
        if current is None:
            return None
        if current.type == node_type:
            return current
        current = current.parent
    return None


def include_solidity_call(callee: str, name_node: Node, source: bytes) -> bool:
    """Constructor modifier invocations count as calls only when they are
    parent-constructor calls (the contract inherits the callee)."""
    modifier_invocation = _ancestor_exact(name_node, "modifier_invocation", 6)
    if modifier_invocation is None:
        return True
    constructor = _ancestor_exact(modifier_invocation, "constructor_definition", 8)
    if constructor is None:
        return False
    contract = _ancestor_exact(constructor, "contract_declaration", 12)
    if contract is None:
        return False
    for child in contract.children:
        if child.type != "inheritance_specifier":
            continue
        ancestor = child.child_by_field_name("ancestor") or child
        if _last_identifier(ancestor, source) == callee:
            return True
    return False


def _last_identifier(node: Node, source: bytes) -> str:
    result = ""

    def visit(current: Node, _depth: int) -> str | None:
        nonlocal result
        if "identifier" in current.type.lower() and current.child_count == 0:
            result = node_text(current, source)
        return None

    walk(node, visit)
    return result


def solidity_annotation_supplement(def_node: Node, source: bytes) -> tuple[str, ...]:
    """Report function modifier invocations as annotations."""
    names: list[str] = []

    def visit(node: Node, depth: int) -> str | None:
        node_type = node.type.lower()
        if depth > 0 and node_type in ("function_body", "block"):
            return "skip"
        if node_type != "modifier_invocation":
            return None
        name = first_identifier_text(node, source)
        if name and is_valid_symbol_name(name):
            names.append(name)
        return "skip"

    walk(def_node, visit)
    if not names:
        names = _modifier_names_from_signature(extract_signature(def_node, source))
    return tuple(dict.fromkeys(names))


def _modifier_names_from_signature(signature: str) -> list[str]:
    if not signature:
        return []
    closing = signature.find(")")
    if closing < 0 or closing + 1 >= len(signature):
        return []
    tail = _RETURNS.sub(" ", signature[closing + 1 :])
    names: list[str] = []
    seen: set[str] = set()
    for match in _MODIFIER_NAME.finditer(tail):
        name = match.group(1)
        if name in seen or name in _NON_MODIFIER_TOKENS:
            continue
        seen.add(name)
        names.append(name)
    return names
