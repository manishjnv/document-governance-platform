# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Parse build.sbt dependencies with a bounded text scan.

Each top-level element of a ``Seq`` argument list that uses ``%`` operators
contributes group, artifact, and version; a fourth string equal to ``test``
marks a test dependency.
"""

from __future__ import annotations

import re

from context_graph_sdk.project.config import (
    TEST_SCOPE,
    DependencyRecord,
    ManifestReader,
    ProjectConfig,
)

_QUOTED = re.compile(r'"([^"]*)"')


def _seq_arguments(content: str) -> list[str]:
    arguments: list[str] = []
    for match in re.finditer(r"\bSeq\s*\(", content):
        depth = 0
        for index in range(match.end() - 1, len(content)):
            if content[index] == "(":
                depth += 1
            elif content[index] == ")":
                depth -= 1
                if depth == 0:
                    arguments.append(content[match.end() : index])
                    break
    return arguments


def _split_top_level(argument_list: str) -> list[str]:
    elements: list[str] = []
    depth = 0
    current: list[str] = []
    in_string = False
    for char in argument_list:
        if char == '"':
            in_string = not in_string
        if not in_string:
            if char in "([{":
                depth += 1
            elif char in ")]}":
                depth -= 1
            elif char == "," and depth == 0:
                elements.append("".join(current))
                current = []
                continue
        current.append(char)
    if current:
        elements.append("".join(current))
    return elements


def load_sbt_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("build.sbt"):
        text = reader.read_text(relative)
        if text is None:
            continue
        for argument_list in _seq_arguments(text):
            for element in _split_top_level(argument_list):
                if "%" not in element:
                    continue
                values = _QUOTED.findall(element)
                if len(values) < 3:
                    continue
                dev = len(values) >= 4 and values[3].lower() == TEST_SCOPE
                config.add_dependency(
                    DependencyRecord(
                        f"{values[0]}:{values[1]}",
                        values[2],
                        relative,
                        dev,
                        TEST_SCOPE if dev else "",
                    )
                )
