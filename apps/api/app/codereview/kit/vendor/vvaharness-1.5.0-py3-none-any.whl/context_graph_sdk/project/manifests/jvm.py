# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Maven pom.xml and Gradle settings/build/lockfile parsing."""

from __future__ import annotations

import re
import xml.etree.ElementTree as ElementTree

from context_graph_sdk.project.config import (
    TEST_SCOPE,
    DependencyRecord,
    ManifestReader,
    ManifestRecord,
    ProjectConfig,
    workspace_display_name,
)

_MAVEN_PROPERTY = re.compile(r"\$\{([^}]+)\}")


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _child_text(element: ElementTree.Element, name: str) -> str:
    for child in element:
        if _local_name(child.tag) == name:
            return (child.text or "").strip()
    return ""


def _children(element: ElementTree.Element, name: str) -> list[ElementTree.Element]:
    return [child for child in element if _local_name(child.tag) == name]


def _parse_pom(text: str) -> ElementTree.Element | None:
    try:
        root = ElementTree.fromstring(text)
    except ElementTree.ParseError:
        return None
    return root if _local_name(root.tag) == "project" else None


def _expand(value: str, properties: dict[str, str]) -> str:
    return _MAVEN_PROPERTY.sub(lambda match: properties.get(match.group(1), match.group(0)), value)


def _pom_properties(root: ElementTree.Element) -> tuple[dict[str, str], str, str]:
    parent = next(iter(_children(root, "parent")), None)
    parent_group = _child_text(parent, "groupId") if parent is not None else ""
    parent_version = _child_text(parent, "version") if parent is not None else ""
    group_id = _child_text(root, "groupId") or parent_group
    version = _child_text(root, "version") or parent_version
    properties: dict[str, str] = {}
    for props in _children(root, "properties"):
        for prop in props:
            properties[_local_name(prop.tag)] = (prop.text or "").strip()
    artifact_id = _child_text(root, "artifactId")
    for key, value in (("groupId", group_id), ("artifactId", artifact_id), ("version", version)):
        if value:
            properties[f"project.{key}"] = value
            properties[f"pom.{key}"] = value
    return properties, group_id, version


def _add_pom_dependency(
    element: ElementTree.Element,
    properties: dict[str, str],
    relative: str,
    config: ProjectConfig,
    *,
    management: bool,
) -> None:
    group_id = _expand(_child_text(element, "groupId"), properties)
    artifact_id = _expand(_child_text(element, "artifactId"), properties)
    version = _expand(_child_text(element, "version"), properties)
    scope = _child_text(element, "scope")
    if "${" in group_id or "${" in artifact_id:
        return
    if management and scope == "import":
        return
    if not management and scope in ("provided", "system"):
        return
    dev = scope == TEST_SCOPE
    config.add_dependency(
        DependencyRecord(
            f"{group_id}:{artifact_id}", version, relative, dev, TEST_SCOPE if dev else ""
        )
    )


def load_pom_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("pom.xml"):
        text = reader.read_text(relative)
        root = _parse_pom(text) if text is not None else None
        if root is None:
            continue
        properties, _, _ = _pom_properties(root)
        for dependencies in _children(root, "dependencies"):
            for dependency in _children(dependencies, "dependency"):
                _add_pom_dependency(dependency, properties, relative, config, management=False)
        for management in _children(root, "dependencyManagement"):
            for dependencies in _children(management, "dependencies"):
                for dependency in _children(dependencies, "dependency"):
                    _add_pom_dependency(dependency, properties, relative, config, management=True)


def load_pom_manifests(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("pom.xml"):
        text = reader.read_text(relative)
        root = _parse_pom(text) if text is not None else None
        if root is None:
            continue
        _, _, version = _pom_properties(root)
        modules = [
            module_text
            for modules in _children(root, "modules")
            for module in _children(modules, "module")
            if (module_text := (module.text or "").strip())
        ]
        config.add_manifest(
            ManifestRecord(
                _child_text(root, "artifactId"), relative, "java", version, tuple(modules)
            )
        )


_GRADLE_INCLUDE = re.compile(r"include(?:Flat)?\s*\(([^)]*)\)|include\s+([^\n]+)")


def strip_gradle_comments(content: str) -> str:
    output: list[str] = []
    in_single = False
    in_double = False
    in_block = False
    escaped = False
    index = 0
    while index < len(content):
        char = content[index]
        if in_block:
            if char == "*" and content[index + 1 : index + 2] == "/":
                in_block = False
                index += 1
            index += 1
            continue
        if escaped:
            output.append(char)
            escaped = False
            index += 1
            continue
        if char == "\\":
            output.append(char)
            escaped = True
            index += 1
            continue
        if not in_single and not in_double and char == "/":
            following = content[index + 1 : index + 2]
            if following == "/":
                while index < len(content) and content[index] != "\n":
                    index += 1
                continue
            if following == "*":
                in_block = True
                index += 2
                continue
        if char == "'" and not in_double:
            in_single = not in_single
        elif char == '"' and not in_single:
            in_double = not in_double
        output.append(char)
        index += 1
    return "".join(output)


def load_gradle_settings_manifests(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("settings.gradle", "settings.gradle.kts"):
        text = reader.read_text(relative)
        if text is None:
            continue
        content = strip_gradle_comments(text)
        members: list[str] = []
        seen: set[str] = set()
        for match in _GRADLE_INCLUDE.finditer(content):
            arguments = match.group(1) or match.group(2) or ""
            for raw in arguments.split(","):
                item = raw.strip().strip("\"'").removeprefix(":").replace(":", "/")
                if item and item not in seen:
                    seen.add(item)
                    members.append(item)
        config.add_manifest(
            ManifestRecord(
                workspace_display_name(reader.root, relative),
                relative,
                "java",
                "",
                tuple(members),
            )
        )


_GRADLE_DEPENDENCY_STATEMENT = re.compile(r"^\s*(\w+)\s*\(?\s*(['\"])([^'\"]+)\2", re.MULTILINE)


def _gradle_scope(configuration: str) -> tuple[bool, str]:
    name = configuration.lower()
    if "test" in name:
        return True, TEST_SCOPE
    if "build" in name or name == "classpath" or "processor" in name or name == "kapt":
        return True, "build"
    return False, ""


def _dependencies_blocks(content: str) -> list[str]:
    blocks: list[str] = []
    for match in re.finditer(r"\bdependencies\s*\{", content):
        depth = 0
        for index in range(match.end() - 1, len(content)):
            if content[index] == "{":
                depth += 1
            elif content[index] == "}":
                depth -= 1
                if depth == 0:
                    blocks.append(content[match.end() : index])
                    break
    return blocks


def load_gradle_build_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("build.gradle", "build.gradle.kts"):
        text = reader.read_text(relative)
        if text is None:
            continue
        content = strip_gradle_comments(text)
        for block in _dependencies_blocks(content):
            for match in _GRADLE_DEPENDENCY_STATEMENT.finditer(block):
                coordinates = match.group(3)
                if "$" in coordinates:
                    continue
                parts = coordinates.split(":")
                if len(parts) != 3:
                    continue
                dev, scope = _gradle_scope(match.group(1))
                config.add_dependency(
                    DependencyRecord(f"{parts[0]}:{parts[1]}", parts[2], relative, dev, scope)
                )


def load_gradle_lockfile_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("gradle.lockfile", "buildscript-gradle.lockfile"):
        text = reader.read_text(relative)
        if text is None:
            continue
        for raw in text.split("\n"):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(":", 2)
            if len(parts) != 3:
                continue
            version, _, class_paths = parts[2].partition("=")
            dev = bool(class_paths) and all(
                path.startswith("test") for path in class_paths.split(",")
            )
            config.add_dependency(
                DependencyRecord(
                    f"{parts[0]}:{parts[1]}",
                    version,
                    relative,
                    dev,
                    TEST_SCOPE if dev else "",
                )
            )
