# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Built-in extraction capabilities and their single bounded execution path."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from context_graph_sdk.discovery.walker import RepositoryWalk
from context_graph_sdk.extractors import ExtractionResult, extract_repository
from context_graph_sdk.plugins import (
    LanguageExtractor,
    PluginMetadata,
    PluginPhase,
    ProjectExtractor,
)
from context_graph_sdk.project import ProjectConfig, load_project_config


@dataclass(frozen=True)
class IngestionResult:
    config: ProjectConfig
    extraction: ExtractionResult


class BuiltinLanguageExtractor:
    metadata = PluginMetadata(PluginPhase.EXTRACTION, 10, "builtin-languages", "1")

    def __init__(self, on_progress: Callable[[int, int], None] | None = None) -> None:
        self._on_progress = on_progress

    @property
    def languages(self) -> tuple[str, ...]:
        from context_graph_sdk.extractors.runtime import SUPPORTED_LANGUAGES

        return tuple(sorted(SUPPORTED_LANGUAGES))

    def extract(self, repository: RepositoryWalk) -> ExtractionResult:
        return extract_repository(
            repository.root,
            [(file.relative_path, file.language) for file in repository.files if file.language],
            on_progress=self._on_progress,
        )


class BuiltinProjectExtractor:
    metadata = PluginMetadata(PluginPhase.EXTRACTION, 20, "builtin-project", "1")

    def extract(self, repository: RepositoryWalk) -> ProjectConfig:
        return load_project_config(
            repository.root, [file.relative_path for file in repository.files]
        )


class BuiltinExtractionRegistry:
    """The one bounded registry for built-in language/project capabilities."""

    def __init__(
        self,
        language_extractor: LanguageExtractor | None = None,
        project_extractor: ProjectExtractor | None = None,
    ) -> None:
        language = language_extractor or BuiltinLanguageExtractor()
        project = project_extractor or BuiltinProjectExtractor()
        self.language: LanguageExtractor = language
        self.project: ProjectExtractor = project

    def run(self, walk: RepositoryWalk) -> IngestionResult:
        return IngestionResult(self.project.extract(walk), self.language.extract(walk))


def run_builtin_ingestion(
    walk: RepositoryWalk,
    *,
    on_language_start: Callable[[], None] | None = None,
    on_file_progress: Callable[[int, int], None] | None = None,
) -> IngestionResult:
    registry = BuiltinExtractionRegistry(BuiltinLanguageExtractor(on_file_progress))
    config = registry.project.extract(walk)
    if on_language_start is not None:
        on_language_start()
    return IngestionResult(config, registry.language.extract(walk))
