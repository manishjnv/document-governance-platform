# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Bounded upstream/downstream project impact traversal."""

from __future__ import annotations

from context_graph_sdk.errors import StructuredQueryError

from .context import ExecuteQuery, select_symbol, traverse_paths
from .results import (
    EntityReference,
    ImpactDirection,
    ImpactLimits,
    ImpactResult,
    RelationshipDirection,
    SymbolSelector,
    entity_sort_key,
)

IMPACT_RELATIONSHIPS = (
    "ACCESSES",
    "CALLS",
    "DELEGATES_TO",
    "DEPENDS_ON",
    "IMPLEMENTS",
    "IMPORTS",
    "INHERITS",
    "OVERRIDES",
    "SPAWNS",
    "USES",
)
_IMPACT_RELATIONSHIP_SET = frozenset(IMPACT_RELATIONSHIPS)


def project_impact(
    execute: ExecuteQuery,
    selector: SymbolSelector,
    direction: ImpactDirection,
    limits: ImpactLimits,
    relationship_types: tuple[str, ...] | None = None,
) -> ImpactResult:
    selected_types = relationship_types or IMPACT_RELATIONSHIPS
    unsupported = sorted(set(selected_types).difference(_IMPACT_RELATIONSHIP_SET))
    if unsupported:
        raise StructuredQueryError(f"unsupported impact relationship: {unsupported[0]}")
    selected_types = tuple(sorted(set(selected_types)))
    symbol = select_symbol(execute, selector, limits.candidate_limit)
    traversal_direction = (
        RelationshipDirection.INCOMING
        if direction == ImpactDirection.UPSTREAM
        else RelationshipDirection.OUTGOING
    )
    paths = traverse_paths(
        execute,
        symbol,
        traversal_direction,
        selected_types,
        limits.max_depth,
        limits.max_nodes,
        limits.max_edges,
        limits.max_paths,
    )
    affected: dict[str, EntityReference] = {}
    for path in paths:
        for entity in path.nodes[1:]:
            affected[entity.id] = entity
    return ImpactResult(
        symbol,
        direction,
        tuple(sorted(affected.values(), key=entity_sort_key)),
        paths,
    )
