# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""requirements.txt and pyproject.toml parsing (PEP 621 and Poetry)."""

from __future__ import annotations

import posixpath
import re

from context_graph_sdk.project.config import (
    DEV_SCOPE,
    DependencyRecord,
    ManifestReader,
    ManifestRecord,
    ProjectConfig,
    workspace_display_name,
)

from ._data import as_mapping, as_str, mapping_at, parse_toml, string_list

_INLINE_COMMENT = re.compile(r"(^|\s+)#.*$")
_VALID_PACKAGE = re.compile(r"^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?$")
_VERSION_SEPARATORS = ("===", "==", ">=", "<=", "~=", "!=", ">", "<")
# Production variants parse first so first-record-wins deduplication keeps
# the production specifier when a package repeats in dev/test variants.
_REQUIREMENTS_VARIANTS = (
    "requirements.txt",
    "requirements-prod.txt",
    "requirements-dev.txt",
    "requirements-test.txt",
    "requirements_dev.txt",
    "requirements_test.txt",
)
_MAX_REQUIREMENT_INCLUDES = 64


def _split_name_version(specifier: str) -> tuple[str, str]:
    if ";" in specifier:
        specifier = specifier[: specifier.index(";")]
    specifier = specifier.strip()
    open_bracket = specifier.find("[")
    if open_bracket >= 0:
        close_bracket = specifier.find("]")
        if close_bracket > open_bracket:
            specifier = specifier[:open_bracket] + specifier[close_bracket + 1 :]
    for separator in _VERSION_SEPARATORS:
        index = specifier.find(separator)
        if index >= 0:
            return specifier[:index].strip(), specifier[index:].strip()
    return specifier.strip(), ""


def load_requirements_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    seen: set[str] = set()
    for relative in reader.by_base_name(*_REQUIREMENTS_VARIANTS):
        _parse_requirements_file(reader, relative, config, seen)


def _parse_requirements_file(
    reader: ManifestReader, relative: str, config: ProjectConfig, seen: set[str]
) -> None:
    normalized = posixpath.normpath(relative)
    if normalized in seen or len(seen) >= _MAX_REQUIREMENT_INCLUDES:
        return
    seen.add(normalized)
    text = reader.read_text(normalized)
    if text is None:
        return
    lines = text.split("\n")
    index = 0
    while index < len(lines):
        line = lines[index]
        index += 1
        while line.rstrip(" \t").endswith("\\") and index < len(lines):
            line = line.rstrip(" \t")[:-1] + lines[index]
            index += 1
        line = _INLINE_COMMENT.sub("", line).strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith(("-r ", "-c ")):
            include = posixpath.join(posixpath.dirname(normalized), line[3:].strip())
            _parse_requirements_file(reader, include, config, seen)
            continue
        if line.startswith("-"):
            continue
        if " --" in line:
            line = line[: line.index(" --")]
        name, version = _split_name_version(line)
        if name and _VALID_PACKAGE.match(name):
            # Group included requirements variants under the canonical root source.
            config.add_dependency(DependencyRecord(name, version, "requirements.txt"))


def _poetry_version(value: object) -> str:
    if isinstance(value, str):
        return value
    mapping = as_mapping(value)
    if mapping is not None:
        version = as_str(mapping.get("version"))
        if version:
            return version
        git = as_str(mapping.get("git"))
        if git:
            return "git:" + git
    return ""


def _add_specifiers(config: ProjectConfig, entries: object, relative: str, *, dev: bool) -> None:
    for entry in string_list(entries):
        name, version = _split_name_version(entry)
        if name:
            config.add_dependency(
                DependencyRecord(name, version, relative, dev, DEV_SCOPE if dev else "")
            )


def load_pyproject_dependencies(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("pyproject.toml"):
        text = reader.read_text(relative)
        parsed = parse_toml(text) if text is not None else None
        if parsed is None:
            continue
        project = mapping_at(parsed, "project")
        dependencies = project.get("dependencies")
        optional = as_mapping(project.get("optional-dependencies")) or {}
        if string_list(dependencies) or optional:
            _add_specifiers(config, dependencies, relative, dev=False)
            for group, entries in optional.items():
                dev = "dev" in group or "test" in group
                _add_specifiers(config, entries, relative, dev=dev)
            continue
        poetry = mapping_at(parsed, "tool", "poetry")
        main_dependencies = as_mapping(poetry.get("dependencies")) or {}
        for name, value in main_dependencies.items():
            if name.lower() == "python":
                continue
            config.add_dependency(DependencyRecord(name, _poetry_version(value), relative))
        groups = as_mapping(poetry.get("group")) or {}
        for group_name, group in groups.items():
            entries = mapping_at(group, "dependencies")
            dev = "dev" in group_name or "test" in group_name
            for name, value in entries.items():
                if name.lower() == "python":
                    continue
                config.add_dependency(
                    DependencyRecord(
                        name, _poetry_version(value), relative, dev, DEV_SCOPE if dev else ""
                    )
                )


def load_pyproject_manifests(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("pyproject.toml"):
        text = reader.read_text(relative)
        parsed = parse_toml(text) if text is not None else None
        if parsed is None:
            continue
        project = mapping_at(parsed, "project")
        poetry = mapping_at(parsed, "tool", "poetry")
        name = as_str(project.get("name"))
        version = as_str(project.get("version"))
        if not name:
            name = as_str(poetry.get("name"))
            version = as_str(poetry.get("version"))
        members: list[str] = []
        for tool_name in ("uv", "pdm"):
            members.extend(
                string_list(mapping_at(parsed, "tool", tool_name, "workspace").get("members"))
            )
        if not name and members:
            name = workspace_display_name(reader.root, relative)
        config.add_manifest(ManifestRecord(name, relative, "python", version, tuple(members)))
