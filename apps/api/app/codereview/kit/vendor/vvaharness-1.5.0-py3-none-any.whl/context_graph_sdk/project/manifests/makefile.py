# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""High-signal Makefile build-process extraction."""

from __future__ import annotations

import re

from context_graph_sdk.project.config import BuildProcessRecord, ManifestReader, ProjectConfig

HIGH_SIGNAL_TARGETS = frozenset(
    {
        "build",
        "test",
        "lint",
        "format",
        "fmt",
        "check",
        "clean",
        "install",
        "dev",
        "run",
        "release",
    }
)

# A rule line starts at column zero and separates targets from prerequisites
# with a colon that is not part of an assignment (`:=`).
_RULE_LINE = re.compile(r"^([^\t:=#][^:=]*):(?:[^=]|$)")


def load_makefile_processes(reader: ManifestReader, config: ProjectConfig) -> None:
    for relative in reader.by_base_name("Makefile", "GNUmakefile", "BSDmakefile"):
        text = reader.read_text(relative)
        if text is None:
            continue
        for line in text.split("\n"):
            match = _RULE_LINE.match(line.rstrip("\r"))
            if match is None:
                continue
            for target in match.group(1).split():
                if target in HIGH_SIGNAL_TARGETS:
                    config.add_build_process(
                        BuildProcessRecord(target, relative, "make", f"make {target}")
                    )
