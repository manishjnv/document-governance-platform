# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Manager-only catalog facade."""

from __future__ import annotations

from context_graph_sdk.backends import CatalogBackend
from context_graph_sdk.identity import ProjectId
from context_graph_sdk.models import (
    CatalogPublication,
    CorrelationEdge,
    ProjectSnapshot,
    ProviderManifest,
    ResolvedCorrelation,
)


class WorkspaceCatalog:
    def __init__(self, backend: CatalogBackend) -> None:
        self._backend = backend

    def publish(self, publication: CatalogPublication, *, fail_before_commit: bool = False) -> None:
        with self._backend.begin_publication() as transaction:
            transaction.publish(publication)
            if fail_before_commit:
                raise RuntimeError("injected failure before catalog commit")
            transaction.commit()

    def accepted_snapshot(self, project_id: ProjectId) -> ProjectSnapshot | None:
        return self._backend.accepted_snapshot(project_id)

    def accepted_snapshots(self) -> tuple[ProjectSnapshot, ...]:
        return self._backend.accepted_snapshots()

    def correlations_touching(self, project_id: ProjectId) -> tuple[CorrelationEdge, ...]:
        return self._backend.correlations_touching(project_id)

    def project_snapshot_count(self, project_id: ProjectId) -> int:
        return self._backend.project_snapshot_count(project_id)

    def node_ref_count(self, project_id: ProjectId) -> int:
        return self._backend.node_ref_count(project_id)

    def provider_manifests(self, project_id: ProjectId) -> tuple[ProviderManifest, ...]:
        return self._backend.provider_manifests(project_id)

    def resolve_correlations(
        self, node_id: str, result_limit: int
    ) -> tuple[ResolvedCorrelation, ...]:
        return self._backend.resolve_correlations(node_id, result_limit)

    def close(self) -> None:
        self._backend.close()
