# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Canonical labels emitted for extracted source symbols."""

from __future__ import annotations

SYMBOL_LABEL = "Symbol"

# Keep this set authoritative for extraction validation, graph labelling, and
# structured symbol selection. Every label produced by the built-in extractor
# must be represented here.
SYMBOL_CATEGORY_LABELS = frozenset(
    {
        "Annotation",
        "Class",
        "CodeElement",
        "Const",
        "Constructor",
        "Delegate",
        "Enum",
        "Function",
        "Impl",
        "Interface",
        "Macro",
        "Method",
        "Module",
        "Namespace",
        "Property",
        "Record",
        "Static",
        "Struct",
        "Template",
        "Trait",
        "TypeAlias",
        "Typedef",
        "Union",
        "Variable",
    }
)
SYMBOL_LABELS = frozenset({SYMBOL_LABEL, *SYMBOL_CATEGORY_LABELS})
