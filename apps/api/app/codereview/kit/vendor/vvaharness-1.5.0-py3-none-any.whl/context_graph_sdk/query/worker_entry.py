# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""No-fork stdio entry point for the bounded query worker."""

from __future__ import annotations

import os
import sys

from context_graph_sdk._process import FrameReader, FrameWriter


def main() -> int:
    if len(sys.argv) != 2:
        return 2
    from .worker import run_worker_loop

    requests = FrameReader(sys.stdin.buffer)
    responses = FrameWriter(sys.stdout.buffer)
    try:
        run_worker_loop(requests, responses, int(sys.argv[1]))
    finally:
        requests.close()
        responses.close()
    return 0


def _run() -> None:
    try:
        code = main()
    except BaseException as error:
        print(f"query worker failed: {type(error).__name__}: {error}", file=sys.stderr)
        code = 1
    # The worker closes each database before returning. Avoid JPype/JVM native
    # teardown during CPython finalization; the process owns no shared state.
    os._exit(code)


if __name__ == "__main__":
    _run()
