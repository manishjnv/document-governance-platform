; Production extraction query set for python, ported from the reviewed reference.
(class_definition name: (identifier) @name) @definition.class
(function_definition name: (identifier) @name) @definition.function
(class_definition body: (block (function_definition name: (identifier) @name) @definition.method))
(class_definition body: (block (decorated_definition definition: (function_definition name: (identifier) @name)) @definition.method))
(class_definition body: (block (expression_statement (assignment left: (identifier) @name)) @definition.property))
(class_definition body: (block (expression_statement (assignment left: (identifier) @name type: (_) right: (_)?)) @definition.property))
(import_statement name: (dotted_name) @import.source) @import
(import_from_statement module_name: (dotted_name) @import.source) @import
(import_from_statement module_name: (relative_import) @import.source) @import
(call function: (identifier) @call.name) @call
(call function: (attribute attribute: (identifier) @call.name)) @call
(class_definition name: (identifier) @heritage.class superclasses: (argument_list (identifier) @heritage.extends)) @heritage
(assignment left: (attribute object: (_) @assignment.receiver attribute: (identifier) @assignment.property) right: (_)) @assignment
(augmented_assignment left: (attribute object: (_) @assignment.receiver attribute: (identifier) @assignment.property) right: (_)) @assignment
(call function: (attribute attribute: (identifier) @_fn (#match? @_fn "^(Thread|Process)$")) arguments: (argument_list (keyword_argument name: (identifier) @_kw (#eq? @_kw "target") value: (identifier) @spawn.target))) @spawn
(call function: (attribute attribute: (identifier) @_fn (#match? @_fn "^(create_task|ensure_future)$")) arguments: (argument_list (call function: (identifier) @spawn.target))) @spawn
(call function: (attribute attribute: (identifier) @_fn (#match? @_fn "^(create_task|ensure_future)$")) arguments: (argument_list (call function: (attribute attribute: (identifier) @spawn.target)))) @spawn
(call function: (attribute attribute: (identifier) @_fn (#match? @_fn "^(run|run_until_complete)$")) arguments: (argument_list (call function: (identifier) @spawn.target))) @spawn
(call function: (identifier) @_fn (#eq? @_fn "run_in_threadpool") arguments: (argument_list (identifier) @spawn.target)) @spawn
(call function: (attribute attribute: (identifier) @_fn (#eq? @_fn "submit")) arguments: (argument_list (identifier) @spawn.target)) @spawn
(call arguments: (argument_list (identifier) @delegate.target)) @delegate
