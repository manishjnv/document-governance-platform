# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Backend-neutral query and killable-worker contracts."""

from __future__ import annotations

import json
from dataclasses import dataclass
from enum import StrEnum

from context_graph_sdk.errors import ModelValidationError
from context_graph_sdk.models import FrozenMap, SnapshotLocator

MAX_QUERY_ROWS = 100_000
MAX_QUERY_BYTES = 16 * 1024 * 1024
MAX_REQUEST_BYTES = 256 * 1024


@dataclass(frozen=True)
class QueryLimits:
    timeout_seconds: float
    memory_bytes: int
    row_limit: int
    byte_limit: int

    def __post_init__(self) -> None:
        if not 0 < self.timeout_seconds <= 3_600:
            raise ModelValidationError("timeout_seconds must be in (0, 3600]")
        if self.memory_bytes <= 0:
            raise ModelValidationError("memory_bytes must be positive")
        if not 1 <= self.row_limit <= MAX_QUERY_ROWS:
            raise ModelValidationError(f"row_limit must be in [1, {MAX_QUERY_ROWS}]")
        if not 1 <= self.byte_limit <= MAX_QUERY_BYTES:
            raise ModelValidationError(f"byte_limit must be in [1, {MAX_QUERY_BYTES}]")


@dataclass(frozen=True)
class QueryWorkerRequest:
    request_id: str
    snapshot: SnapshotLocator
    cypher: str
    parameters: FrozenMap
    limits: QueryLimits

    def __post_init__(self) -> None:
        if not self.request_id or len(self.request_id) > 128:
            raise ModelValidationError("request_id must contain 1..128 characters")
        if not self.cypher:
            raise ModelValidationError("cypher is required")
        if self.encoded_size > MAX_REQUEST_BYTES:
            raise ModelValidationError("serialized query-worker request exceeds request bound")

    @property
    def encoded_size(self) -> int:
        payload = {
            "requestId": self.request_id,
            "snapshot": {
                "projectId": self.snapshot.project_id.value,
                "snapshotId": self.snapshot.snapshot_id.value,
                "databasePath": self.snapshot.database_path,
            },
            "cypher": self.cypher,
            "parameters": self.parameters.to_dict(),
            "limits": {
                "timeoutSeconds": self.limits.timeout_seconds,
                "memoryBytes": self.limits.memory_bytes,
                "rowLimit": self.limits.row_limit,
                "byteLimit": self.limits.byte_limit,
            },
        }
        return len(
            json.dumps(payload, ensure_ascii=True, separators=(",", ":"), sort_keys=True).encode()
        )


@dataclass(frozen=True)
class WorkerPoolLimits:
    max_workers: int
    max_request_bytes: int = MAX_REQUEST_BYTES
    max_response_bytes: int = MAX_QUERY_BYTES

    def __post_init__(self) -> None:
        if self.max_workers <= 0:
            raise ModelValidationError("max_workers must be positive")
        if self.max_request_bytes <= 0 or self.max_response_bytes <= 0:
            raise ModelValidationError("worker IPC byte bounds must be positive")


class TruncationReason(StrEnum):
    ROWS = "rows"
    BYTES = "bytes"


@dataclass(frozen=True)
class QueryWorkerResult:
    request_id: str
    rows: tuple[FrozenMap, ...]
    serialized_bytes: int
    truncated: bool = False
    truncation_reason: TruncationReason | None = None

    def __post_init__(self) -> None:
        if not self.request_id:
            raise ModelValidationError("request_id is required")
        if self.serialized_bytes < 0:
            raise ModelValidationError("serialized_bytes cannot be negative")
        if self.truncated != (self.truncation_reason is not None):
            raise ModelValidationError("truncation reason must match truncated state")


@dataclass(frozen=True)
class WorkerHealth:
    process_id: int
    rss_bytes: int
    thread_count: int
    file_descriptor_count: int

    def __post_init__(self) -> None:
        if self.process_id <= 0:
            raise ModelValidationError("worker process_id must be positive")
        if min(self.rss_bytes, self.thread_count, self.file_descriptor_count) < 0:
            raise ModelValidationError("worker health values cannot be negative")
