# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Bounded JSON IPC encoding for query workers."""

from __future__ import annotations

import json
from typing import Any, cast

from context_graph_sdk.errors import QueryProtocolError
from context_graph_sdk.identity import ProjectId, SnapshotId
from context_graph_sdk.models import SnapshotLocator, freeze_properties

from .contracts import QueryLimits, QueryWorkerRequest, QueryWorkerResult, TruncationReason


def encode_request(request: QueryWorkerRequest) -> bytes:
    payload = {
        "requestId": request.request_id,
        "snapshot": {
            "projectId": request.snapshot.project_id.value,
            "snapshotId": request.snapshot.snapshot_id.value,
            "databasePath": request.snapshot.database_path,
        },
        "cypher": request.cypher,
        "parameters": request.parameters.to_dict(),
        "limits": {
            "timeoutSeconds": request.limits.timeout_seconds,
            "memoryBytes": request.limits.memory_bytes,
            "rowLimit": request.limits.row_limit,
            "byteLimit": request.limits.byte_limit,
        },
    }
    return json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()


def decode_request(frame: bytes) -> QueryWorkerRequest:
    try:
        decoded = json.loads(frame)
        if not isinstance(decoded, dict):
            raise TypeError("request frame must be an object")
        payload = cast(dict[str, Any], decoded)
        if set(payload) != {"requestId", "snapshot", "cypher", "parameters", "limits"}:
            raise ValueError("request frame contains missing or unknown fields")
        snapshot = cast(dict[str, Any], payload["snapshot"])
        limits = cast(dict[str, Any], payload["limits"])
        if set(snapshot) != {"projectId", "snapshotId", "databasePath"}:
            raise ValueError("snapshot locator contains missing or unknown fields")
        if set(limits) != {"timeoutSeconds", "memoryBytes", "rowLimit", "byteLimit"}:
            raise ValueError("query limits contain missing or unknown fields")
        return QueryWorkerRequest(
            str(payload["requestId"]),
            SnapshotLocator(
                ProjectId(str(snapshot["projectId"])),
                SnapshotId(str(snapshot["snapshotId"])),
                str(snapshot["databasePath"]),
            ),
            str(payload["cypher"]),
            freeze_properties(cast(dict[str, object], payload["parameters"])),
            QueryLimits(
                float(limits["timeoutSeconds"]),
                int(limits["memoryBytes"]),
                int(limits["rowLimit"]),
                int(limits["byteLimit"]),
            ),
        )
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise QueryProtocolError(f"malformed query request: {exc}") from exc


def encode_result(result: QueryWorkerResult) -> bytes:
    payload = {
        "requestId": result.request_id,
        "rows": [row.to_dict() for row in result.rows],
        "serializedBytes": result.serialized_bytes,
        "truncated": result.truncated,
        "truncationReason": result.truncation_reason.value if result.truncation_reason else None,
    }
    return json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()


def decode_result(frame: bytes) -> QueryWorkerResult:
    try:
        decoded = json.loads(frame)
        if not isinstance(decoded, dict):
            raise TypeError("result frame must be an object")
        payload = cast(dict[str, Any], decoded)
        if set(payload) != {
            "requestId",
            "rows",
            "serializedBytes",
            "truncated",
            "truncationReason",
        }:
            raise ValueError("result frame contains missing or unknown fields")
        reason = payload.get("truncationReason")
        return QueryWorkerResult(
            str(payload["requestId"]),
            tuple(freeze_properties(cast(dict[str, object], row)) for row in payload["rows"]),
            int(payload["serializedBytes"]),
            bool(payload["truncated"]),
            TruncationReason(str(reason)) if reason else None,
        )
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise QueryProtocolError(f"malformed query result: {exc}") from exc


def encode_error(request_id: str | None, code: str, message: str) -> bytes:
    return json.dumps(
        {"requestId": request_id, "error": code, "message": message},
        separators=(",", ":"),
        sort_keys=True,
    ).encode()


def decode_error(frame: bytes) -> tuple[str | None, str, str] | None:
    try:
        payload = cast(dict[str, Any], json.loads(frame))
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise QueryProtocolError(f"malformed worker response: {exc}") from exc
    if "error" not in payload:
        return None
    request_id = payload.get("requestId")
    return (
        str(request_id) if request_id is not None else None,
        str(payload["error"]),
        str(payload.get("message", "")),
    )
