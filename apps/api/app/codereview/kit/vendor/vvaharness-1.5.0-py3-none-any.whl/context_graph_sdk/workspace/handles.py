# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Manager-owned snapshot lease registry.

Project databases are not cached by the manager: query workers open the
leased immutable snapshot per request and close it afterwards, so open
handles are bounded by the worker pool. The registry only tracks active
reader leases so retired snapshots are garbage-collected safely.
"""

# pyright: reportPrivateUsage=false

from __future__ import annotations

import threading
import time
from contextlib import AbstractContextManager
from types import TracebackType

from context_graph_sdk.models import SnapshotLocator


class _SnapshotLease(AbstractContextManager["_SnapshotLease"]):
    def __init__(self, registry: SnapshotLeaseRegistry, locator: SnapshotLocator) -> None:
        self._registry = registry
        self.locator = locator
        self.released = False

    def __enter__(self) -> _SnapshotLease:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        self.release()

    def release(self) -> None:
        if not self.released:
            self._registry._release(self.locator)
            self.released = True


class SnapshotLeaseRegistry:
    def __init__(self) -> None:
        self._counts: dict[str, int] = {}
        self._condition = threading.Condition()
        self._closed = False

    def acquire(self, locator: SnapshotLocator) -> AbstractContextManager[_SnapshotLease]:
        with self._condition:
            if self._closed:
                raise RuntimeError("snapshot lease registry is closed")
            key = locator.database_path
            self._counts[key] = self._counts.get(key, 0) + 1
        return _SnapshotLease(self, locator)

    def active_count(self, locator: SnapshotLocator) -> int:
        with self._condition:
            return self._counts.get(locator.database_path, 0)

    def wait_for_zero(self, timeout_seconds: float) -> bool:
        deadline = time.monotonic() + timeout_seconds
        with self._condition:
            while self._counts:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return False
                self._condition.wait(remaining)
            return True

    def close(self) -> None:
        with self._condition:
            if self._counts:
                raise RuntimeError("cannot close lease registry with active leases")
            self._closed = True

    def _release(self, locator: SnapshotLocator) -> None:
        with self._condition:
            key = locator.database_path
            count = self._counts.get(key, 0)
            if count <= 1:
                self._counts.pop(key, None)
            else:
                self._counts[key] = count - 1
            self._condition.notify_all()
