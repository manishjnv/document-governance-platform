# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared capture routing and the per-file extraction entry point.

Language-specific behavior lives in the descriptor table
(:mod:`context_graph_sdk.extractors.descriptors`); the routing loop itself is
language-neutral.
"""

from __future__ import annotations

from tree_sitter import Node

from context_graph_sdk.extractors import runtime
from context_graph_sdk.extractors.analysis import (
    extract_annotations,
    extract_class_name,
    extract_doc_comment,
    extract_method_signature,
    extract_receiver_type,
    extract_signature,
    find_enclosing_class_name,
    first_identifier_text,
    node_text,
    walk,
)
from context_graph_sdk.extractors.bindings import extract_type_bindings
from context_graph_sdk.extractors.descriptors import LANGUAGE_DESCRIPTORS, LanguageDescriptor
from context_graph_sdk.extractors.records import (
    CALLABLE_LABELS,
    OWNERLESS_LABELS,
    Assignment,
    Call,
    Delegate,
    FileExtraction,
    Heritage,
    Import,
    ImportBinding,
    MutableFileResult,
    Spawn,
    Symbol,
    deduplicate_symbols,
    disambiguate_duplicate_ids,
    is_valid_symbol_name,
    symbol_id,
)

_DEFINITION_LABELS: tuple[tuple[str, str], ...] = (
    ("definition.function", "Function"),
    ("definition.class", "Class"),
    ("definition.interface", "Interface"),
    ("definition.method", "Method"),
    ("definition.struct", "Struct"),
    ("definition.enum", "Enum"),
    ("definition.namespace", "Namespace"),
    ("definition.module", "Module"),
    ("definition.trait", "Trait"),
    ("definition.impl", "Impl"),
    ("definition.const", "Const"),
    ("definition.static", "Static"),
    ("definition.typedef", "Typedef"),
    ("definition.macro", "Macro"),
    ("definition.union", "Union"),
    ("definition.property", "Property"),
    ("definition.record", "Record"),
    ("definition.delegate", "Delegate"),
    ("definition.annotation", "Annotation"),
    ("definition.constructor", "Constructor"),
    ("definition.template", "Template"),
    ("definition.constant", "Const"),
    ("definition.variable", "Variable"),
)

_KIND_CAPTURES = {"definition.event": "event", "definition.error": "error"}


def _classify(captures: dict[str, list[Node]]) -> str:
    fallback = ""
    for capture, label in _DEFINITION_LABELS:
        if capture in captures:
            return label
    for capture in _KIND_CAPTURES:
        if capture in captures:
            return "CodeElement"
    if "definition.type" in captures:
        fallback = "TypeAlias"
    return fallback


def _classify_kind(captures: dict[str, list[Node]]) -> str:
    for capture, kind in _KIND_CAPTURES.items():
        if capture in captures:
            return kind
    return ""


def _definition_node(captures: dict[str, list[Node]]) -> Node | None:
    for name, nodes in captures.items():
        if name.startswith("definition.") and nodes:
            return nodes[-1]
    for name in ("heritage", "name"):
        nodes = captures.get(name)
        if nodes:
            return nodes[-1]
    for nodes in captures.values():
        if nodes:
            return nodes[-1]
    return None


def _trim_quotes(text: str) -> str:
    text = text.strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'`":
        return text[1:-1]
    return text


def extract_file(relative_path: str, source: bytes, language: str) -> FileExtraction:
    """Extract every record family from one file; caller handles failures."""
    descriptor = LANGUAGE_DESCRIPTORS[language]
    tree, matches = runtime.parse_and_match(language, source)
    result = MutableFileResult()

    for _, captures in matches:
        texts = {
            name: [node_text(node, source) for node in nodes] for name, nodes in captures.items()
        }
        last = {name: values[-1] if values else "" for name, values in texts.items()}

        if "import" in captures:
            aliases = texts.get("import.alias", [])
            for index, import_source in enumerate(texts.get("import.source", [])):
                bindings: tuple[ImportBinding, ...] = ()
                cleaned = _trim_quotes(import_source)
                if index < len(aliases) and aliases[index]:
                    bindings = (ImportBinding(cleaned, aliases[index]),)
                result.imports.append(Import(relative_path, cleaned, bindings))
            continue

        if "spawn" in captures:
            target = last.get("spawn.name", "") or last.get("spawn.target", "")
            if target and is_valid_symbol_name(target):
                result.spawns.append(
                    Spawn(
                        relative_path,
                        target,
                        last.get("spawn.receiver", ""),
                        captures["spawn"][-1].start_point.row,
                    )
                )
            continue

        if "delegate" in captures:
            target = last.get("delegate.target", "")
            if target and is_valid_symbol_name(target):
                result.delegates.append(
                    Delegate(
                        relative_path,
                        target,
                        last.get("delegate.receiver", ""),
                        captures["delegate"][-1].start_point.row,
                    )
                )
            continue

        if "call" in captures:
            names = texts.get("call.name", [])
            nodes = captures.get("call.name", [])
            receiver = last.get("call.receiver", "")
            for index, callee in enumerate(names):
                if not is_valid_symbol_name(callee):
                    if index >= len(nodes):
                        continue
                    callee = first_identifier_text(nodes[index], source)
                    if not is_valid_symbol_name(callee):
                        continue
                if (
                    descriptor.include_call is not None
                    and index < len(nodes)
                    and not descriptor.include_call(callee, nodes[index], source)
                ):
                    continue
                line = nodes[index].start_point.row if index < len(nodes) else 0
                result.calls.append(Call(relative_path, callee, receiver, line))
            continue

        if "assignment" in captures:
            property_name = last.get("assignment.property", "")
            if property_name:
                property_nodes = captures.get("assignment.property", [])
                line = property_nodes[-1].start_point.row if property_nodes else 0
                result.assignments.append(
                    Assignment(
                        relative_path,
                        last.get("assignment.receiver", ""),
                        property_name,
                        line,
                    )
                )
            continue

        if "heritage" in captures or "heritage.impl" in captures:
            class_name = last.get("heritage.class", "")
            if class_name:
                for capture, kind in (
                    ("heritage.extends", "extends"),
                    ("heritage.implements", "implements"),
                    ("heritage.trait", "trait"),
                ):
                    for parent in texts.get(capture, []):
                        if parent:
                            result.heritage.append(
                                Heritage(relative_path, class_name, parent, kind)
                            )
            # A heritage match may also define a symbol when @name is present.
            if "name" not in captures:
                continue

        # Symbol routing requires @name, so nameless captures such as Kotlin
        # `secondary_constructor` and Swift `init_declaration` produce no symbols.
        name = last.get("name", "")
        if not name or not is_valid_symbol_name(name):
            continue
        label = _classify(captures)
        if not label:
            continue
        def_node = _definition_node(captures)
        if def_node is None:
            continue

        owner = ""
        if label not in OWNERLESS_LABELS:
            owner = find_enclosing_class_name(def_node, source)
            if not owner:
                owner = extract_receiver_type(def_node, source)
        if label == "Function":
            enclosing = find_enclosing_class_name(def_node, source)
            if enclosing:
                label = "Method"
                owner = enclosing

        parameter_count = 0
        return_type = ""
        signature = ""
        if label in CALLABLE_LABELS:
            parameter_count, return_type = extract_method_signature(def_node, source)
            signature = extract_signature(def_node, source)

        result.symbols.append(
            Symbol(
                id=symbol_id(label, relative_path, name, owner),
                name=name,
                label=label,
                kind=_classify_kind(captures),
                file_path=relative_path,
                start_line=def_node.start_point.row,
                end_line=def_node.end_point.row,
                is_exported=descriptor.is_exported(def_node, name, source),
                language=language,
                content=node_text(def_node, source),
                owner_name=owner,
                doc_comment=extract_doc_comment(def_node, source, language),
                annotations=_annotations_with_supplement(descriptor, def_node, source),
                signature=signature,
                parameter_count=parameter_count,
                return_type=return_type,
            )
        )

    result.symbols = deduplicate_symbols(result.symbols)

    root = tree.root_node
    result.imports = enrich_import_bindings(result.imports, root, source)
    result.calls = enrich_call_receivers(result.calls, root, source)
    if descriptor.interface_method_specs:
        result.symbols.extend(extract_interface_method_specs(root, source, relative_path, language))
    for post_pass in descriptor.post_passes:
        post_pass(root, source, relative_path, language, result)
    result.symbols = disambiguate_duplicate_ids(result.symbols)
    result.type_bindings = list(extract_type_bindings(root, source, relative_path))
    return result.freeze()


def _annotations_with_supplement(
    descriptor: LanguageDescriptor, def_node: Node, source: bytes
) -> str:
    annotations = extract_annotations(def_node, source)
    if descriptor.annotation_supplement is None:
        return annotations
    existing = annotations.split(",") if annotations else []
    for name in descriptor.annotation_supplement(def_node, source):
        if name not in existing:
            existing.append(name)
    return ",".join(existing)


def enrich_import_bindings(imports: list[Import], root: Node, source: bytes) -> list[Import]:
    source_index: dict[str, int] = {}
    for index, imported in enumerate(imports):
        source_index.setdefault(imported.source, index)

    def visit(node: Node, _depth: int) -> str | None:
        if "import" not in node.type.lower():
            return None
        import_source = ""
        for field in ("source", "path", "module_name"):
            child = node.child_by_field_name(field)
            if child is not None:
                import_source = _trim_quotes(node_text(child, source))
                break
        if not import_source:
            for child in node.children:
                child_type = child.type.lower()
                if child_type == "string" or "string_literal" in child_type:
                    import_source = _trim_quotes(node_text(child, source))
                    break
        if not import_source or import_source not in source_index:
            return None
        index = source_index[import_source]
        if imports[index].bindings:
            return "skip"
        bindings: list[ImportBinding] = []

        def collect(current: Node, _d: int) -> str | None:
            current_type = current.type.lower()
            if current_type == "import_specifier":
                identifiers = _collect_identifiers(current, source)
                if len(identifiers) == 1:
                    bindings.append(ImportBinding(identifiers[0]))
                elif len(identifiers) >= 2:
                    bindings.append(ImportBinding(identifiers[0], identifiers[1]))
                return "skip"
            if current_type == "namespace_import":
                identifiers = _collect_identifiers(current, source)
                if identifiers:
                    bindings.append(ImportBinding("*", identifiers[-1]))
                return "skip"
            if current_type == "import_clause":
                for child in current.children:
                    if child.type.lower() == "identifier":
                        bindings.append(ImportBinding("default", node_text(child, source)))
            return None

        walk(node, collect)
        if bindings:
            imports[index] = Import(
                imports[index].file_path, imports[index].source, tuple(bindings)
            )
        return "skip"

    walk(root, visit)
    return imports


def _collect_identifiers(node: Node, source: bytes) -> list[str]:
    identifiers: list[str] = []
    for child in node.children:
        child_type = child.type.lower()
        if "identifier" in child_type or child_type == "name":
            text = node_text(child, source)
            if text:
                identifiers.append(text)
    return identifiers


def enrich_call_receivers(calls: list[Call], root: Node, source: bytes) -> list[Call]:
    call_index = {(call.callee_name, call.line): index for index, call in enumerate(calls)}

    def visit(node: Node, _depth: int) -> str | None:
        node_type = node.type.lower()
        if "call" not in node_type and "invocation" not in node_type:
            return None
        function_node: Node | None = None
        for field in ("function", "method", "callee", "name"):
            function_node = node.child_by_field_name(field)
            if function_node is not None:
                break
        if function_node is None:
            return None
        function_type = function_node.type.lower()
        if not any(
            token in function_type
            for token in ("member", "field", "selector", "navigation", "attribute", "access")
        ):
            return None
        receiver = ""
        method_name = ""
        for field in ("object", "operand", "value", "expression"):
            child = function_node.child_by_field_name(field)
            if child is not None:
                receiver = node_text(child, source)
                # Keep the immediate qualifier from a chained receiver
                # (a.b.method() -> receiver "b") for local type resolution.
                dot = receiver.rfind(".")
                if dot >= 0:
                    receiver = receiver[dot + 1 :]
                break
        for field in ("property", "field", "name", "attribute"):
            child = function_node.child_by_field_name(field)
            if child is not None:
                method_name = node_text(child, source)
                break
        if not receiver or not method_name:
            identifiers = _collect_identifiers(function_node, source)
            if len(identifiers) >= 2:
                receiver = receiver or identifiers[0]
                method_name = method_name or identifiers[-1]
        if receiver and method_name:
            index = call_index.get((method_name, node.start_point.row))
            if index is not None and not calls[index].receiver_name:
                calls[index] = Call(
                    calls[index].file_path, method_name, receiver, calls[index].line
                )
        return None

    walk(root, visit)
    return calls


# Go interface and Swift protocol bodies share these node categories; only
# Go currently needs the supplemental member walk.
_INTERFACE_BODY_TYPES = frozenset({"interface_type", "protocol_body"})
_METHOD_SPEC_TYPES = frozenset({"method_spec", "method_elem"})


def extract_interface_method_specs(
    root: Node, source: bytes, relative_path: str, language: str
) -> list[Symbol]:
    """Go interface method specs become Method symbols owned by the interface."""
    extra: list[Symbol] = []

    def visit(node: Node, _depth: int) -> str | None:
        if node.type.lower() not in _INTERFACE_BODY_TYPES:
            return None
        interface_name = _interface_owner_name(node, source)
        if not interface_name:
            return None
        for child in node.children:
            if not child.is_named or child.type.lower() not in _METHOD_SPEC_TYPES:
                continue
            name_node = child.child_by_field_name("name")
            if name_node is None:
                for candidate in child.children:
                    if candidate.type.lower() in ("field_identifier", "identifier"):
                        name_node = candidate
                        break
            if name_node is None:
                continue
            method_name = node_text(name_node, source)
            if not method_name:
                continue
            parameter_count, return_type = extract_method_signature(child, source)
            extra.append(
                Symbol(
                    id=symbol_id("Method", relative_path, method_name, interface_name),
                    name=method_name,
                    label="Method",
                    file_path=relative_path,
                    start_line=child.start_point.row,
                    end_line=child.end_point.row,
                    is_exported=True,
                    language=language,
                    content=node_text(child, source),
                    owner_name=interface_name,
                    parameter_count=parameter_count,
                    return_type=return_type,
                )
            )
        return "skip"

    walk(root, visit)
    return extra


def _interface_owner_name(node: Node, source: bytes) -> str:
    current = node.parent
    for _ in range(5):
        if current is None:
            return ""
        name_node = current.child_by_field_name("name")
        if name_node is not None:
            name = node_text(name_node, source)
            if name:
                return name
        if current.type.lower() in ("type_spec", "protocol_declaration"):
            name = extract_class_name(current, source)
            if name:
                return name
        current = current.parent
    return ""
