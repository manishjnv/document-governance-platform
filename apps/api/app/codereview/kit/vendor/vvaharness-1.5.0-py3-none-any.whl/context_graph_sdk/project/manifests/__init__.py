# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Manifest family loaders in deterministic execution order."""

from .cpp import load_vcpkg_dependencies
from .dotnet import load_csproj_dependencies, load_solution_manifests
from .golang import load_go_dependencies, load_go_manifests
from .jvm import (
    load_gradle_build_dependencies,
    load_gradle_lockfile_dependencies,
    load_gradle_settings_manifests,
    load_pom_dependencies,
    load_pom_manifests,
)
from .makefile import load_makefile_processes
from .node import (
    load_package_json_dependencies,
    load_package_json_manifests,
    load_pnpm_workspace_manifests,
)
from .php import load_composer_dependencies
from .python_pkg import (
    load_pyproject_dependencies,
    load_pyproject_manifests,
    load_requirements_dependencies,
)
from .resolution_config import load_resolution_settings
from .ruby import load_gemfile_dependencies
from .rust import load_cargo_dependencies, load_cargo_manifests
from .sbt import load_sbt_dependencies
from .swift import load_swift_package_dependencies, load_swift_package_manifests

ALL_LOADERS = (
    load_go_dependencies,
    load_package_json_dependencies,
    load_cargo_dependencies,
    load_requirements_dependencies,
    load_composer_dependencies,
    load_gemfile_dependencies,
    load_csproj_dependencies,
    load_swift_package_dependencies,
    load_pom_dependencies,
    load_gradle_lockfile_dependencies,
    load_gradle_build_dependencies,
    load_vcpkg_dependencies,
    load_pyproject_dependencies,
    load_sbt_dependencies,
    load_makefile_processes,
    load_go_manifests,
    load_package_json_manifests,
    load_pnpm_workspace_manifests,
    load_pom_manifests,
    load_cargo_manifests,
    load_pyproject_manifests,
    load_gradle_settings_manifests,
    load_solution_manifests,
    load_swift_package_manifests,
    load_resolution_settings,
)

__all__ = ["ALL_LOADERS"]
