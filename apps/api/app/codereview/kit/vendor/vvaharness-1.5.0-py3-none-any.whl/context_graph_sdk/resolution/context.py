# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Immutable indexed resolution context and result contracts.

Built once per analysis from discovery/extraction records; resolvers never
re-scan the graph or query a backend. All lookup structures are sorted so
resolution output is independent of record arrival order.
"""

from __future__ import annotations

import posixpath
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field

from context_graph_sdk.errors import ResolutionLimitError
from context_graph_sdk.extractors.records import ExtractionResult, Symbol
from context_graph_sdk.models import LocalRelationshipType
from context_graph_sdk.project.config import ProjectConfig, ResolutionSettings

MAX_RESOLUTION_EDGES = 500_000
MAX_CANDIDATES_PER_NAME = 200


@dataclass(frozen=True)
class ResolvedEdge:
    source_local_id: str
    relationship: LocalRelationshipType
    target_local_id: str
    properties: tuple[tuple[str, object], ...] = ()


@dataclass
class ResolutionResult:
    """Edges and symbol property updates emitted by the resolution stages."""

    edges: list[ResolvedEdge] = field(default_factory=list[ResolvedEdge])
    property_updates: dict[str, dict[str, object]] = field(
        default_factory=dict[str, dict[str, object]]
    )
    _seen: set[tuple[str, str, str]] = field(default_factory=set[tuple[str, str, str]], repr=False)

    def add_edge(
        self,
        source_local_id: str,
        relationship: LocalRelationshipType,
        target_local_id: str,
        properties: Mapping[str, object] | None = None,
    ) -> bool:
        """Deduplicated add; the first edge for one (source, type, target)
        wins so properties stay deterministic under the fixed stage order."""
        if not source_local_id or not target_local_id or source_local_id == target_local_id:
            return False
        key = (source_local_id, relationship.value, target_local_id)
        if key in self._seen:
            return False
        if len(self.edges) >= MAX_RESOLUTION_EDGES:
            raise ResolutionLimitError(
                f"resolution edge count exceeds {MAX_RESOLUTION_EDGES} bound"
            )
            return False
        self._seen.add(key)
        self.edges.append(
            ResolvedEdge(
                source_local_id,
                relationship,
                target_local_id,
                tuple(sorted((properties or {}).items())),
            )
        )
        return True

    def update_property(self, symbol_id: str, key: str, value: object) -> None:
        self.property_updates.setdefault(symbol_id, {}).setdefault(key, value)


def file_local_id(relative_path: str) -> str:
    return f"file:{relative_path}"


def folder_local_id(relative_path: str) -> str:
    return f"folder:{relative_path}"


@dataclass(frozen=True)
class _SymbolRange:
    local_id: str
    start: int
    end: int


class ResolutionContext:
    """Sorted indexes over files and symbols for one project analysis."""

    def __init__(
        self,
        files: Sequence[tuple[str, str]],
        folder_paths: Sequence[str],
        extraction: ExtractionResult,
        config: ProjectConfig,
    ) -> None:
        """`files` carries the walker's authoritative (path, language) pairs so
        symbol-less files (barrel re-exports, header-only imports) still
        resolve with their real language."""
        self.settings: ResolutionSettings = config.resolution
        self.file_language: dict[str, str] = {path: language for path, language in sorted(files)}
        self.file_paths: tuple[str, ...] = tuple(sorted(self.file_language))
        self.folders: frozenset[str] = frozenset(folder_paths)
        self.files: frozenset[str] = frozenset(self.file_paths)
        self.files_by_dir: dict[str, list[str]] = {}
        for path in self.file_paths:
            self.files_by_dir.setdefault(posixpath.dirname(path), []).append(
                posixpath.basename(path)
            )
        self.files_by_base: dict[str, list[str]] = {}
        for path in self.file_paths:
            self.files_by_base.setdefault(posixpath.basename(path), []).append(path)

        self.extraction = extraction
        self.symbols: tuple[Symbol, ...] = tuple(
            sorted(
                (s for _, fr in extraction.files for s in fr.symbols),
                key=lambda s: (s.file_path, s.start_line, s.id),
            )
        )
        self.symbols_by_id: dict[str, Symbol] = {s.id: s for s in self.symbols}
        self.symbols_by_name: dict[str, list[Symbol]] = {}
        for symbol in self.symbols:
            bucket = self.symbols_by_name.setdefault(symbol.name, [])
            if len(bucket) < MAX_CANDIDATES_PER_NAME:
                bucket.append(symbol)
        for bucket in self.symbols_by_name.values():
            bucket.sort(key=lambda s: s.id)
        self._ranges: dict[str, list[_SymbolRange]] = {}
        for symbol in self.symbols:
            self._ranges.setdefault(symbol.file_path, []).append(
                _SymbolRange(symbol.id, symbol.start_line, symbol.end_line)
            )

        self.import_aliases = _build_import_alias_map(extraction)
        self.receiver_types = _build_receiver_type_map(extraction)

    def has_file(self, path: str) -> bool:
        return path in self.files

    def lookup_with_extensions(self, base_path: str, extensions: tuple[str, ...]) -> str | None:
        if base_path in self.files:
            return base_path
        for extension in extensions:
            candidate = base_path + extension
            if candidate in self.files:
                return candidate
        return None

    def lookup_suffix(self, suffix: str) -> str | None:
        base = posixpath.basename(suffix)
        for path in self.files_by_base.get(base, []):
            if path.endswith(suffix):
                return path
        return None

    def files_in_dir(self, directory: str) -> list[str]:
        return self.files_by_dir.get(directory.rstrip("/"), [])

    def enclosing_symbol(self, relative_path: str, line: int) -> str:
        """Tightest symbol containing the line, else the file node id."""
        best_id = ""
        best_span = 1 << 31
        for candidate in self._ranges.get(relative_path, []):
            if candidate.start <= line <= candidate.end:
                span = candidate.end - candidate.start
                if span < best_span or (span == best_span and candidate.local_id < best_id):
                    best_span = span
                    best_id = candidate.local_id
        return best_id or file_local_id(relative_path)

    def receiver_type(self, relative_path: str, receiver_name: str) -> str:
        # self/this/cls require enclosing-class inference, which is not available here.
        if receiver_name in ("self", "this", "cls"):
            return ""
        return self.receiver_types.get(relative_path, {}).get(receiver_name, "")


def _build_import_alias_map(extraction: ExtractionResult) -> dict[str, dict[str, str]]:
    result: dict[str, dict[str, str]] = {}
    for path, file_result in extraction.files:
        for imported in file_result.imports:
            for binding in imported.bindings:
                if (
                    binding.alias
                    and binding.original
                    and binding.alias != binding.original
                    and binding.original != "*"
                ):
                    result.setdefault(path, {}).setdefault(binding.alias, binding.original)
    return result


def _build_receiver_type_map(extraction: ExtractionResult) -> dict[str, dict[str, str]]:
    result: dict[str, dict[str, str]] = {}
    for path, file_result in extraction.files:
        for binding in file_result.type_bindings:
            if not binding.variable_name or not binding.type_name:
                continue
            if binding.variable_name.startswith("@"):
                continue
            result.setdefault(path, {}).setdefault(binding.variable_name, binding.type_name)
    return result
