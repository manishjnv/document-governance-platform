# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Typed access helpers for parsed JSON/TOML manifest data."""

from __future__ import annotations

import json
import tomllib
from typing import cast


def parse_json_object(text: str) -> dict[str, object] | None:
    try:
        parsed = cast(object, json.loads(text))
    except ValueError:
        return None
    return as_mapping(parsed)


def parse_toml(text: str) -> dict[str, object] | None:
    try:
        return cast(dict[str, object], tomllib.loads(text))
    except (tomllib.TOMLDecodeError, ValueError):
        return None


def as_mapping(value: object) -> dict[str, object] | None:
    if isinstance(value, dict):
        return cast(dict[str, object], value)
    return None


def as_list(value: object) -> list[object]:
    if isinstance(value, list):
        return cast(list[object], value)
    return []


def as_str(value: object, default: str = "") -> str:
    return value if isinstance(value, str) else default


def mapping_at(value: object, *keys: str) -> dict[str, object]:
    current = as_mapping(value) or {}
    for key in keys:
        current = as_mapping(current.get(key)) or {}
    return current


def string_list(value: object) -> tuple[str, ...]:
    return tuple(item for item in as_list(value) if isinstance(item, str) and item)


def string_items(value: object) -> tuple[tuple[str, str], ...]:
    mapping = as_mapping(value) or {}
    return tuple((key, item) for key, item in mapping.items() if isinstance(item, str))
