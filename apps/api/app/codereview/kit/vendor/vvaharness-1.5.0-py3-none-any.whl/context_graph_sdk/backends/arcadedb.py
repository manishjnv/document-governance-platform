# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""ArcadeDB adapter for independent physical graph databases.

ArcadeDB and JPype are imported lazily so importing :mod:`context_graph_sdk` in the
manager process cannot start a JVM.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import os
import re
import shutil
import tempfile
import threading
from collections.abc import Iterator
from contextlib import AbstractContextManager, suppress
from pathlib import Path
from types import TracebackType
from typing import Any, cast

from context_graph_sdk.backends.base import (
    CatalogBackend,
    CatalogWriteTransaction,
    GraphBackend,
    GraphWriteTransaction,
)
from context_graph_sdk.errors import ModelValidationError
from context_graph_sdk.identity import ProjectId, SnapshotId
from context_graph_sdk.models import (
    AnalysisVersion,
    CatalogPublication,
    CorrelationEdge,
    CorrelationEndpointRole,
    CorrelationType,
    FrozenMap,
    GraphEdge,
    GraphNode,
    NodeRef,
    ProjectMetadata,
    ProjectSnapshot,
    ProviderManifest,
    ResolvedCorrelation,
    SnapshotLocator,
    freeze_properties,
)

_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_MAX_WRITE_BATCH = 10_000
_MAX_CATALOG_CORRELATIONS = 5_000
# Hidden deterministic native type for one multi-label combination.
_COMBINATION_TYPE_PREFIX = "_cgml_"
_ARCADE_START_LOCK = threading.Lock()
_arcade_logging_configured = False
_arcade_log_filters: list[Any] = []


def _arcade() -> Any:
    return importlib.import_module("arcadedb_embedded")


def _configure_java_logging() -> None:
    global _arcade_logging_configured
    if _arcade_logging_configured:
        return
    jpype = importlib.import_module("jpype")
    if not jpype.isJVMStarted():
        return
    level = jpype.JClass("java.util.logging.Level").WARNING
    logger_class = jpype.JClass("java.util.logging.Logger")
    root = logger_class.getLogger("")
    root.setLevel(level)
    for handler in root.getHandlers():
        handler.setLevel(level)
        existing_filter = handler.getFilter()

        def is_loggable(record: Any, existing: Any = existing_filter) -> bool:
            if "GraalVM Polyglot Engine: no languages found" in str(record.getMessage()):
                return False
            return existing is None or bool(existing.isLoggable(record))

        filter_proxy = jpype.JProxy("java.util.logging.Filter", dict(isLoggable=is_loggable))
        handler.setFilter(filter_proxy)
        _arcade_log_filters.append(filter_proxy)
    # ArcadeDB initializes this optional scripting bridge during ordinary
    # Cypher use even though the SDK does not enable a polyglot language.
    logger_class.getLogger("com.arcadedb.query.polyglot.GraalPolyglotEngine").setLevel(
        jpype.JClass("java.util.logging.Level").SEVERE
    )
    _arcade_logging_configured = True


def _database_call(operation: str, path: str) -> Any:
    """Start ArcadeDB quietly, while preserving captured startup errors."""
    arcade = _arcade()
    jpype = importlib.import_module("jpype")
    with _ARCADE_START_LOCK:
        if jpype.isJVMStarted():
            _configure_java_logging()
            return getattr(arcade, operation)(path)

        failure: BaseException | None = None
        result: Any = None
        with tempfile.TemporaryFile() as captured:
            saved_stderr = os.dup(2)
            try:
                os.dup2(captured.fileno(), 2)
                try:
                    result = getattr(arcade, operation)(path)
                    # Initialize ArcadeDB's optional polyglot query bridge while
                    # startup stderr is captured, then retain warnings but drop
                    # routine engine INFO output for subsequent SDK operations.
                    warmup = result.query("opencypher", "RETURN 1 AS value", {})
                    try:
                        tuple(warmup)
                    finally:
                        warmup.close()
                    _configure_java_logging()
                    with suppress(Exception):
                        jpype.JClass("java.lang.System").err.flush()
                except BaseException as error:
                    failure = error
            finally:
                os.dup2(saved_stderr, 2)
                os.close(saved_stderr)
            captured.seek(0)
            diagnostics = captured.read().decode("utf-8", errors="replace").strip()
        if failure is not None:
            if diagnostics:
                failure.add_note(f"ArcadeDB JVM stderr:\n{diagnostics}")
            raise failure
        actionable = "\n".join(
            line
            for line in diagnostics.splitlines()
            if "Using incubator modules: jdk.incubator.vector" not in line
            and "GraalVM Polyglot Engine: no languages found" not in line
        )
        if actionable:
            os.write(2, f"{actionable}\n".encode())
        return result


def _identifier(value: str) -> str:
    if not _IDENTIFIER.fullmatch(value):
        raise ModelValidationError(f"unsupported ArcadeDB identifier: {value!r}")
    return value


def _rows(result: Any) -> Iterator[FrozenMap]:
    try:
        for row in result:
            yield freeze_properties(cast(dict[str, object], row.to_dict()))
    finally:
        result.close()


class ArcadeGraphWriteTransaction(AbstractContextManager["ArcadeGraphWriteTransaction"]):
    def __init__(self, database: Any, locator: SnapshotLocator) -> None:
        self._database = database
        self._locator = locator
        self._finished = False
        self._vertex_types: set[str] = set()
        self._combination_types: dict[tuple[str, ...], str] = {}
        self._nodes: list[GraphNode] = []
        self._edges: list[GraphEdge] = []

    def __enter__(self) -> ArcadeGraphWriteTransaction:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        if not self._finished:
            self.rollback()

    def write_nodes(self, nodes: tuple[GraphNode, ...]) -> None:
        if len(nodes) > _MAX_WRITE_BATCH:
            raise ModelValidationError("node write batch exceeds adapter bound")
        self._nodes.extend(nodes)

    def write_edges(self, edges: tuple[GraphEdge, ...]) -> None:
        if len(edges) > _MAX_WRITE_BATCH:
            raise ModelValidationError("edge write batch exceeds adapter bound")
        self._edges.extend(edges)

    def _vertex_type(self, labels: tuple[str, ...]) -> str:
        validated = tuple(_identifier(label) for label in labels)
        for label in validated:
            if label not in self._vertex_types:
                self._database.schema.get_or_create_vertex_type(label)
                self._vertex_types.add(label)
        if len(validated) == 1:
            return validated[0]
        combination = self._combination_types.get(validated)
        if combination is not None:
            return combination
        digest = hashlib.sha256("\x00".join(validated).encode()).hexdigest()
        combination = f"{_COMBINATION_TYPE_PREFIX}{digest}"
        schema = self._database.schema
        existed = schema.exists_type(combination)
        concrete = schema.get_or_create_vertex_type(combination)
        if not existed:
            for label in validated:
                concrete.addSuperType(label)
        self._combination_types[validated] = combination
        return combination

    def commit(self) -> None:
        vertices: dict[str, Any] = {}
        for relationship in sorted({edge.relationship_type for edge in self._edges}):
            self._database.schema.get_or_create_edge_type(_identifier(relationship))
        with self._database.graph_batch(
            expected_edge_count=len(self._edges),
            use_wal=True,
            wal_flush="yes_full",
        ) as batch:
            for node in self._nodes:
                properties = node.properties.to_dict()
                properties.update(
                    {
                        "id": node.id,
                        "localId": node.local_id,
                        "projectId": node.project_id.value,
                        "snapshotId": self._locator.snapshot_id.value,
                        "labels": list(node.labels),
                    }
                )
                vertices[node.id] = batch.create_vertex(
                    self._vertex_type(node.labels), **properties
                )
            for edge in self._edges:
                relationship = _identifier(edge.relationship_type)
                properties = edge.properties.to_dict()
                properties.update({"id": edge.id, "projectId": edge.project_id.value})
                batch.new_edge(
                    vertices[edge.source_id],
                    relationship,
                    vertices[edge.target_id],
                    **properties,
                )
        self._finished = True

    def rollback(self) -> None:
        self._nodes.clear()
        self._edges.clear()
        self._finished = True


class ArcadeGraphBackend:
    def __init__(self, database: Any, locator: SnapshotLocator | None = None) -> None:
        self._database = database
        self._locator = locator
        self._closed = False

    def begin_write(self) -> AbstractContextManager[GraphWriteTransaction]:
        self._ensure_open()
        if self._locator is None:
            raise RuntimeError("catalog backend does not support graph writes")
        return ArcadeGraphWriteTransaction(self._database, self._locator)

    def query_readonly(
        self, cypher: str, parameters: FrozenMap, row_limit: int
    ) -> Iterator[FrozenMap]:
        self._ensure_open()
        if row_limit <= 0:
            raise ModelValidationError("row_limit must be positive")
        result = self._database.query("opencypher", cypher, parameters.to_dict())
        for index, row in enumerate(_rows(result)):
            if index >= row_limit:
                break
            yield row

    def close(self) -> None:
        if not self._closed:
            self._database.close()
            self._closed = True

    def _ensure_open(self) -> None:
        if self._closed:
            raise RuntimeError("backend is closed")


class ArcadeCatalogWriteTransaction(AbstractContextManager["ArcadeCatalogWriteTransaction"]):
    def __init__(self, database: Any) -> None:
        self._database = database
        self._finished = False
        database.begin()

    def __enter__(self) -> ArcadeCatalogWriteTransaction:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        if not self._finished:
            self.rollback()

    def publish(self, publication: CatalogPublication) -> None:
        project_id = publication.snapshot.project.project_id.value
        self._database.command(
            "opencypher",
            "MATCH (a:NodeRef)-[r]->(b:NodeRef) "
            "WHERE a.projectId=$project OR b.projectId=$project DELETE r",
            {"project": project_id},
        )
        self._database.command(
            "opencypher",
            "MATCH (n:NodeRef {projectId:$project}) DETACH DELETE n",
            {"project": project_id},
        )
        self._database.command(
            "opencypher",
            "MATCH (s:ProjectSnapshot {projectId:$project}) SET s.accepted=false",
            {"project": project_id},
        )
        snapshot = publication.snapshot
        self._database.command(
            "opencypher",
            "CREATE (:ProjectSnapshot {key:$key,projectId:$project,snapshotId:$snapshot,"
            "databasePath:$path,displayName:$display,sourcePath:$sourcePath,sourceUrl:$sourceUrl,"
            "revision:$revision,accepted:true,sdkVersion:$sdk,components:$components})",
            {
                "key": f"{project_id}:{snapshot.snapshot_id.value}",
                "project": project_id,
                "snapshot": snapshot.snapshot_id.value,
                "path": snapshot.locator.database_path,
                "display": snapshot.project.display_name,
                "sourcePath": snapshot.project.source_path,
                "sourceUrl": snapshot.project.source_url,
                "revision": snapshot.project.revision,
                "sdk": snapshot.analysis_version.sdk_version,
                "components": json.dumps(snapshot.analysis_version.components),
            },
        )
        for ref in publication.node_refs:
            key = _node_ref_key(ref)
            existing = self._database.query(
                "opencypher", "MATCH (n:NodeRef {key:$key}) RETURN count(n) AS n", {"key": key}
            )
            count = next(iter(existing)).get("n")
            existing.close()
            if int(count) == 0:
                self._database.command(
                    "opencypher",
                    "CREATE (:NodeRef {key:$key,nodeId:$node,projectId:$project,"
                    "snapshotId:$snapshot,localId:$local})",
                    {
                        "key": key,
                        "node": ref.node_id,
                        "project": ref.project_id.value,
                        "snapshot": ref.snapshot_id.value,
                        "local": ref.local_id,
                    },
                )
        for ref in publication.node_refs:
            key = _node_ref_key(ref)
            if self._count("MATCH (n:NodeRef {key:$key}) RETURN count(n) AS n", {"key": key}) != 1:
                raise RuntimeError(f"catalog did not persist NodeRef exactly once: {key}")
        for correlation in publication.correlations:
            peer = (
                correlation.target
                if correlation.source.project_id.value == project_id
                else correlation.source
            )
            if (
                self._count(
                    "MATCH (s:ProjectSnapshot "
                    "{projectId:$project,snapshotId:$snapshot,accepted:true}) "
                    "RETURN count(s) AS n",
                    {"project": peer.project_id.value, "snapshot": peer.snapshot_id.value},
                )
                != 1
            ):
                raise RuntimeError("correlation peer snapshot is no longer accepted")
            relationship = correlation.relationship_type.value
            correlation_key = _correlation_key(correlation)
            self._database.command(
                "opencypher",
                f"MATCH (a:NodeRef {{key:$source}}),(b:NodeRef {{key:$target}}) "
                f"CREATE (a)-[r:{relationship}]->(b) SET r += $properties",
                {
                    "source": _node_ref_key(correlation.source),
                    "target": _node_ref_key(correlation.target),
                    "properties": {
                        "key": correlation_key,
                        "sourceKey": _node_ref_key(correlation.source),
                        "targetKey": _node_ref_key(correlation.target),
                        "providerName": correlation.provider_name,
                        "providerVersion": correlation.provider_version,
                        "confidence": correlation.confidence,
                        "reason": correlation.reason,
                        "evidence": correlation.evidence.to_dict(),
                    },
                },
            )
            if (
                self._count(
                    "MATCH ()-[r {key:$key}]->() RETURN count(r) AS n", {"key": correlation_key}
                )
                != 1
            ):
                raise RuntimeError(
                    f"catalog did not persist correlation exactly once: {correlation_key}"
                )
        self._database.command(
            "opencypher",
            "MATCH (n:NodeRef) WHERE NOT EXISTS { MATCH (n)--() } DETACH DELETE n",
        )
        self._database.command(
            "opencypher",
            "MATCH (m:ProviderManifest {projectId:$project}) DETACH DELETE m",
            {"project": project_id},
        )
        for manifest in publication.provider_manifests:
            self._database.command(
                "opencypher",
                "CREATE (:ProviderManifest {projectId:$project,snapshotId:$snapshot,"
                "providerName:$name,providerVersion:$version})",
                {
                    "project": manifest.project_id.value,
                    "snapshot": manifest.snapshot_id.value,
                    "name": manifest.provider_name,
                    "version": manifest.provider_version,
                },
            )
        self._database.command(
            "opencypher", "MATCH (s:ProjectSnapshot {accepted:false}) DETACH DELETE s"
        )

    def _count(self, query: str, parameters: dict[str, object]) -> int:
        result = self._database.query("opencypher", query, parameters)
        try:
            return int(next(iter(result)).get("n"))
        finally:
            result.close()

    def commit(self) -> None:
        self._database.commit()
        self._finished = True

    def rollback(self) -> None:
        self._database.rollback()
        self._finished = True


class ArcadeCatalogBackend(ArcadeGraphBackend):
    @classmethod
    def create(cls, database: Any) -> ArcadeCatalogBackend:
        backend = cls(database)
        for type_name in ("ProjectSnapshot", "NodeRef", "ProviderManifest"):
            database.schema.get_or_create_vertex_type(type_name)
        for relationship in CorrelationType:
            database.schema.get_or_create_edge_type(relationship.value)
        return backend

    def begin_publication(self) -> AbstractContextManager[CatalogWriteTransaction]:
        self._ensure_open()
        return ArcadeCatalogWriteTransaction(self._database)

    def accepted_snapshot(self, project_id: ProjectId) -> ProjectSnapshot | None:
        result = self._database.query(
            "opencypher",
            "MATCH (s:ProjectSnapshot {projectId:$project,accepted:true}) RETURN "
            "s.snapshotId AS snapshot,s.databasePath AS path,s.displayName AS display,"
            "s.sourcePath AS sourcePath,s.sourceUrl AS sourceUrl,s.revision AS revision,"
            "s.sdkVersion AS sdk,s.components AS components",
            {"project": project_id.value},
        )
        rows = list(result)
        result.close()
        if not rows:
            return None
        return _project_snapshot_from_row(project_id, rows[0])

    def accepted_snapshots(self) -> tuple[ProjectSnapshot, ...]:
        result = self._database.query(
            "opencypher",
            "MATCH (s:ProjectSnapshot {accepted:true}) RETURN s.projectId AS project,"
            "s.snapshotId AS snapshot,s.databasePath AS path,s.displayName AS display,"
            "s.sourcePath AS sourcePath,s.sourceUrl AS sourceUrl,s.revision AS revision,"
            "s.sdkVersion AS sdk,s.components AS components ORDER BY project",
        )
        try:
            return tuple(
                _project_snapshot_from_row(ProjectId(str(row.get("project"))), row)
                for row in result
            )
        finally:
            result.close()

    def project_snapshot_count(self, project_id: ProjectId) -> int:
        result = self._database.query(
            "opencypher",
            "MATCH (s:ProjectSnapshot {projectId:$project}) RETURN count(s) AS n",
            {"project": project_id.value},
        )
        try:
            return int(next(iter(result)).get("n"))
        finally:
            result.close()

    def node_ref_count(self, project_id: ProjectId) -> int:
        result = self._database.query(
            "opencypher",
            "MATCH (n:NodeRef {projectId:$project}) RETURN count(n) AS n",
            {"project": project_id.value},
        )
        try:
            return int(next(iter(result)).get("n"))
        finally:
            result.close()

    def provider_manifests(self, project_id: ProjectId) -> tuple[ProviderManifest, ...]:
        result = self._database.query(
            "opencypher",
            "MATCH (m:ProviderManifest {projectId:$project}) RETURN "
            "m.snapshotId AS snapshot,m.providerName AS name,m.providerVersion AS version "
            "ORDER BY name",
            {"project": project_id.value},
        )
        try:
            return tuple(
                ProviderManifest(
                    project_id,
                    SnapshotId(str(row.get("snapshot"))),
                    str(row.get("name")),
                    str(row.get("version")),
                )
                for row in result
            )
        finally:
            result.close()

    def resolve_correlations(
        self, node_id: str, result_limit: int
    ) -> tuple[ResolvedCorrelation, ...]:
        if result_limit <= 0:
            raise ModelValidationError("correlation result limit must be positive")
        self._database.begin()
        try:
            result = self._database.query(
                "opencypher",
                "MATCH (source:NodeRef {nodeId:$node})-[r]-(target:NodeRef),"
                "(s:ProjectSnapshot {accepted:true}) "
                "WHERE s.projectId=target.projectId AND s.snapshotId=target.snapshotId RETURN "
                "source.nodeId AS sourceNode,source.projectId AS sourceProject,"
                "source.snapshotId AS sourceSnapshot,source.localId AS sourceLocal,"
                "source.key AS queriedKey,type(r) AS relationship,target.nodeId AS targetNode,"
                "target.projectId AS targetProject,target.snapshotId AS snapshot,"
                "target.localId AS targetLocal,r.sourceKey AS sourceKey,r.targetKey AS targetKey,"
                "r.providerName AS providerName,"
                "r.providerVersion AS providerVersion,r.confidence AS confidence,"
                "r.reason AS reason,r.evidence AS evidence,s.databasePath AS path,"
                "s.displayName AS display,s.sourcePath AS sourcePath,s.sourceUrl AS sourceUrl,"
                "s.revision AS revision,s.sdkVersion AS sdk,s.components AS components "
                "ORDER BY relationship,targetProject,targetNode LIMIT $limit",
                {"node": node_id, "limit": result_limit + 1},
            )
            rows = list(result)
            result.close()
            if len(rows) > result_limit:
                raise ModelValidationError("correlation result limit exceeded")
            resolved: list[ResolvedCorrelation] = []
            for row in rows:
                queried = NodeRef(
                    ProjectId(str(row.get("sourceProject"))),
                    SnapshotId(str(row.get("sourceSnapshot"))),
                    str(row.get("sourceLocal")),
                    str(row.get("sourceNode")),
                )
                related_project = ProjectId(str(row.get("targetProject")))
                related = NodeRef(
                    related_project,
                    SnapshotId(str(row.get("snapshot"))),
                    str(row.get("targetLocal")),
                    str(row.get("targetNode")),
                )
                queried_key = str(row.get("queriedKey"))
                if queried_key == str(row.get("sourceKey")):
                    role = CorrelationEndpointRole.SOURCE
                    original_source, original_target = queried, related
                elif queried_key == str(row.get("targetKey")):
                    role = CorrelationEndpointRole.TARGET
                    original_source, original_target = related, queried
                else:
                    raise RuntimeError("correlation direction metadata is missing")
                correlation = CorrelationEdge(
                    original_source,
                    CorrelationType(str(row.get("relationship"))),
                    original_target,
                    str(row.get("providerName")),
                    str(row.get("providerVersion")),
                    float(row.get("confidence")),
                    str(row.get("reason")),
                    freeze_properties(cast(dict[str, object], row.get("evidence") or {})),
                )
                resolved.append(
                    ResolvedCorrelation(
                        correlation,
                        role,
                        _project_snapshot_from_row(related_project, row),
                    )
                )
            return tuple(resolved)
        finally:
            self._database.rollback()

    def correlations_touching(self, project_id: ProjectId) -> tuple[CorrelationEdge, ...]:
        result = self._database.query(
            "opencypher",
            "MATCH (a:NodeRef)-[r]->(b:NodeRef) "
            "WHERE a.projectId=$project OR b.projectId=$project RETURN "
            "a.nodeId AS sourceNode,a.projectId AS sourceProject,a.snapshotId AS sourceSnapshot,"
            "a.localId AS sourceLocal,type(r) AS relationship,b.nodeId AS targetNode,"
            "b.projectId AS targetProject,b.snapshotId AS targetSnapshot,b.localId AS targetLocal,"
            "r.providerName AS providerName,r.providerVersion AS providerVersion,"
            "r.confidence AS confidence,r.reason AS reason,r.evidence AS evidence "
            "LIMIT $limit",
            {"project": project_id.value, "limit": _MAX_CATALOG_CORRELATIONS + 1},
        )
        correlations: list[CorrelationEdge] = []
        try:
            for row in result:
                source = NodeRef(
                    ProjectId(str(row.get("sourceProject"))),
                    SnapshotId(str(row.get("sourceSnapshot"))),
                    str(row.get("sourceLocal")),
                    str(row.get("sourceNode")),
                )
                target = NodeRef(
                    ProjectId(str(row.get("targetProject"))),
                    SnapshotId(str(row.get("targetSnapshot"))),
                    str(row.get("targetLocal")),
                    str(row.get("targetNode")),
                )
                correlations.append(
                    CorrelationEdge(
                        source,
                        CorrelationType(str(row.get("relationship"))),
                        target,
                        str(row.get("providerName")),
                        str(row.get("providerVersion")),
                        float(row.get("confidence")),
                        str(row.get("reason")),
                        freeze_properties(cast(dict[str, object], row.get("evidence") or {})),
                    )
                )
        finally:
            result.close()
        if len(correlations) > _MAX_CATALOG_CORRELATIONS:
            raise ModelValidationError("accepted touching correlation count exceeds bound")
        return tuple(correlations)


class ArcadeDBBackendFactory:
    """Creates independent ArcadeDB handles; importing this class is JVM-safe."""

    def create_project(self, locator: SnapshotLocator) -> GraphBackend:
        path = Path(locator.database_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        return ArcadeGraphBackend(_database_call("create_database", str(path)), locator)

    def open_project(self, locator: SnapshotLocator) -> GraphBackend:
        return ArcadeGraphBackend(_database_call("open_database", locator.database_path), locator)

    def create_catalog(self, path: Path) -> CatalogBackend:
        path.parent.mkdir(parents=True, exist_ok=True)
        return ArcadeCatalogBackend.create(_database_call("create_database", str(path)))

    def open_catalog(self, path: Path) -> CatalogBackend:
        return ArcadeCatalogBackend.create(_database_call("open_database", str(path)))

    def delete_project(self, locator: SnapshotLocator) -> None:
        shutil.rmtree(locator.database_path, ignore_errors=False)


def _project_snapshot_from_row(project_id: ProjectId, row: Any) -> ProjectSnapshot:
    snapshot_id = SnapshotId(str(row.get("snapshot")))
    locator = SnapshotLocator(project_id, snapshot_id, str(row.get("path")))
    components = tuple(tuple(item) for item in json.loads(str(row.get("components"))))
    return ProjectSnapshot(
        ProjectMetadata(
            project_id,
            str(row.get("display")),
            source_path=_optional_string(row.get("sourcePath")),
            source_url=_optional_string(row.get("sourceUrl")),
            revision=_optional_string(row.get("revision")),
        ),
        snapshot_id,
        locator,
        AnalysisVersion(str(row.get("sdk")), cast(tuple[tuple[str, str], ...], components)),
        True,
    )


def _optional_string(value: object) -> str | None:
    return None if value is None else str(value)


def _node_ref_key(ref: NodeRef) -> str:
    return f"{ref.project_id.value}:{ref.snapshot_id.value}:{ref.node_id}"


def _correlation_key(correlation: CorrelationEdge) -> str:
    identity = "\x00".join(
        (
            _node_ref_key(correlation.source),
            correlation.relationship_type.value,
            _node_ref_key(correlation.target),
            correlation.provider_name,
            correlation.provider_version,
        )
    )
    return hashlib.sha256(identity.encode()).hexdigest()
