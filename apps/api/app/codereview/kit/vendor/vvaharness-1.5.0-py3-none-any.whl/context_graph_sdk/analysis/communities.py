# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Weighted call adjacency, community application, and semantic naming."""

from __future__ import annotations

import math
import posixpath
from dataclasses import dataclass

from context_graph_sdk.analysis.inputs import AnalysisInputs, AnalysisNode
from context_graph_sdk.analysis.leiden import Adjacency, LeidenOptions, leiden, modularity

CALLABLE_COMMUNITY_LABELS = ("Function", "Method", "Class")

_GENERIC_PACKAGE_NAMES = frozenset(
    {
        "structs", "internal", "util", "utils", "common", "helper", "helpers",
        "lib", "src", "pkg", "cmd", "app", "types", "models", "shared",
        "core", "base", "misc", "data", "root",
    }
)  # fmt: skip


@dataclass(frozen=True)
class CommunityRecord:
    local_id: str
    name: str
    modularity: float
    size: int
    member_ids: tuple[str, ...]


def build_call_adjacency(inputs: AnalysisInputs) -> Adjacency:
    """Undirected confidence-weighted adjacency over callable symbols."""
    adjacency: Adjacency = {}
    for source_id, target_id, _, confidence in inputs.edges:
        source = inputs.nodes.get(source_id)
        target = inputs.nodes.get(target_id)
        if source is None or target is None:
            continue
        if (
            source.label not in CALLABLE_COMMUNITY_LABELS
            or target.label not in CALLABLE_COMMUNITY_LABELS
        ):
            continue
        weight = confidence if confidence > 0 else 1.0
        adjacency.setdefault(source.id, {})
        adjacency.setdefault(target.id, {})
        adjacency[source.id][target.id] = adjacency[source.id].get(target.id, 0.0) + weight
        adjacency[target.id][source.id] = adjacency[target.id].get(source.id, 0.0) + weight
    return adjacency


def detect_communities(
    inputs: AnalysisInputs,
    options: LeidenOptions | None = None,
) -> list[CommunityRecord]:
    adjacency = build_call_adjacency(inputs)
    if not adjacency:
        return []
    result = leiden(adjacency, options)
    if not result.membership:
        return []
    # Split disconnected assignments so every community is internally connected.
    membership = split_disconnected_communities(adjacency, result.membership)
    overall_modularity = modularity(adjacency, membership)

    groups: dict[int, list[str]] = {}
    for node_id, community in membership.items():
        groups.setdefault(community, []).append(node_id)

    used_labels: dict[str, int] = {}
    records: list[CommunityRecord] = []
    for community_id in sorted(groups):
        members = sorted(groups[community_id])
        name = _derive_name(inputs.nodes, members, community_id)
        if used_labels.get(name, 0) > 0:
            alternative = _derive_name(inputs.nodes, members, community_id, exclude=name)
            if alternative != name and used_labels.get(alternative, 0) == 0:
                name = alternative
            else:
                dominant = _dominant_symbol_name(inputs.nodes, members, community_id)
                if (
                    dominant != name
                    and used_labels.get(dominant, 0) == 0
                    and dominant != f"community-{community_id}"
                ):
                    name = dominant
                else:
                    for suffix in range(2, 100):
                        candidate = f"{name}-{suffix}"
                        if used_labels.get(candidate, 0) == 0:
                            name = candidate
                            break
                    else:
                        # Guaranteed-unique fallback: community ids are
                        # unique per run, so this label cannot collide.
                        name = f"community-{community_id}"
        used_labels[name] = used_labels.get(name, 0) + 1
        records.append(
            CommunityRecord(
                f"community:{community_id}",
                name,
                round(overall_modularity * 1000) / 1000,
                len(members),
                tuple(members),
            )
        )
    return records


def _is_generic(name: str) -> bool:
    return name.lower() in _GENERIC_PACKAGE_NAMES


def _directory_counts(nodes: dict[str, AnalysisNode], member_ids: list[str]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for member_id in member_ids:
        symbol = nodes.get(member_id)
        if symbol is None or not symbol.file_path:
            continue
        directory = posixpath.dirname(symbol.file_path).lstrip("./") or "root"
        counts[directory] = counts.get(directory, 0) + 1
    return counts


def _derive_name(
    nodes: dict[str, AnalysisNode],
    member_ids: list[str],
    community_id: int,
    exclude: str = "",
) -> str:
    directory_counts = _directory_counts(nodes, member_ids)
    if not directory_counts:
        return f"community-{community_id}"

    directories = sorted(directory_counts)
    best_dir = ""
    best_count = 0
    for directory in directories:
        if _is_generic(posixpath.basename(directory)):
            continue
        if directory_counts[directory] > best_count:
            best_count = directory_counts[directory]
            best_dir = directory
    if not best_dir:
        for directory in directories:
            if directory_counts[directory] > best_count:
                best_count = directory_counts[directory]
                best_dir = directory

    base = posixpath.basename(best_dir)
    is_shallow_root = "/" not in best_dir and best_dir != "root"

    if is_shallow_root:
        sub_counts: dict[str, int] = {}
        for directory, count in directory_counts.items():
            if directory.startswith(best_dir + "/"):
                sub = directory.removeprefix(best_dir + "/").split("/", 1)[0]
                if not _is_generic(sub):
                    sub_counts[sub] = sub_counts.get(sub, 0) + count
        if not sub_counts:
            for directory, count in directory_counts.items():
                if directory.startswith(best_dir + "/"):
                    sub = directory.removeprefix(best_dir + "/").split("/", 1)[0]
                    sub_counts[sub] = sub_counts.get(sub, 0) + count
        if sub_counts:
            subs = sorted(sub_counts)
            best_sub, best_sub_count = "", 0
            for sub in subs:
                if sub == exclude:
                    continue
                if sub_counts[sub] > best_sub_count:
                    best_sub_count = sub_counts[sub]
                    best_sub = sub
            if not best_sub:
                for sub in subs:
                    if sub_counts[sub] > best_sub_count:
                        best_sub_count = sub_counts[sub]
                        best_sub = sub
            second_sub, second_count = "", 0
            for sub in subs:
                if sub == best_sub:
                    continue
                if sub_counts[sub] > second_count:
                    second_count = sub_counts[sub]
                    second_sub = sub
            candidate = best_sub
            if second_sub and second_count * 2 >= best_sub_count:
                candidate = best_sub + "+" + second_sub
            if candidate != exclude:
                return candidate
        name = _dominant_symbol_name(nodes, member_ids, community_id)
        if name != exclude:
            return name
        return f"community-{community_id}"

    if _is_generic(base):
        parent = posixpath.dirname(best_dir)
        if parent not in (".", "/", ""):
            base = posixpath.basename(parent) + "/" + base

    if best_count * 2 >= len(member_ids) and base != exclude:
        return base

    second_dir, second_count = "", 0
    for directory in directories:
        if directory == best_dir:
            continue
        if directory_counts[directory] > second_count:
            second_count = directory_counts[directory]
            second_dir = directory
    if second_dir:
        second_base = posixpath.basename(second_dir)
        if _is_generic(second_base):
            parent = posixpath.dirname(second_dir)
            if parent not in (".", "/", ""):
                second_base = posixpath.basename(parent) + "/" + second_base
        candidate = base + "+" + second_base
        if candidate != exclude:
            return candidate
    if base != exclude:
        return base
    return _dominant_symbol_name(nodes, member_ids, community_id)


def _dominant_symbol_name(
    nodes: dict[str, AnalysisNode], member_ids: list[str], community_id: int
) -> str:
    name_counts: dict[str, int] = {}
    for member_id in member_ids:
        symbol = nodes.get(member_id)
        if symbol is None or not symbol.name or not symbol.is_exported:
            continue
        name_counts[symbol.name] = name_counts.get(symbol.name, 0) + 1
    if not name_counts:
        return f"community-{community_id}"
    names = sorted(name_counts)
    best_name, best_count = "", 0
    for name in names:
        if name_counts[name] > best_count:
            best_count = name_counts[name]
            best_name = name
    second_name, second_count = "", 0
    for name in names:
        if name == best_name:
            continue
        if name_counts[name] > second_count:
            second_count = name_counts[name]
            second_name = name
    if second_name and second_count * 2 >= best_count:
        return best_name + "+" + second_name
    return best_name or f"community-{community_id}"


def is_connected(adjacency: Adjacency, members: list[str]) -> bool:
    """Return whether the induced community subgraph is connected."""
    if not members:
        return True
    member_set = set(members)
    stack = [members[0]]
    seen = {members[0]}
    while stack:
        node = stack.pop()
        for neighbor in adjacency.get(node, {}):
            if neighbor in member_set and neighbor not in seen:
                seen.add(neighbor)
                stack.append(neighbor)
    return len(seen) == len(member_set)


def split_disconnected_communities(
    adjacency: Adjacency, membership: dict[str, int]
) -> dict[str, int]:
    """Deterministically split any internally disconnected community so the
    connectedness guarantee holds regardless of refinement outcomes."""
    groups: dict[int, list[str]] = {}
    for node, community in membership.items():
        groups.setdefault(community, []).append(node)
    next_id = max(groups, default=-1) + 1
    result = dict(membership)
    for community in sorted(groups):
        members = sorted(groups[community])
        remaining = set(members)
        first_component = True
        while remaining:
            start = min(remaining)
            component = {start}
            stack = [start]
            while stack:
                node = stack.pop()
                for neighbor in adjacency.get(node, {}):
                    if neighbor in remaining and neighbor not in component:
                        component.add(neighbor)
                        stack.append(neighbor)
            remaining -= component
            if first_component:
                first_component = False
                continue
            for node in sorted(component):
                result[node] = next_id
            next_id += 1
    return result


def community_quality_is_finite(value: float) -> bool:
    return not math.isnan(value) and not math.isinf(value)
