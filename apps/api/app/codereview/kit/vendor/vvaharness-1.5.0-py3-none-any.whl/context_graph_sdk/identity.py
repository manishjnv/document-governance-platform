# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Stable project, snapshot, node, and edge identity helpers."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

from .errors import ModelValidationError

_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")


def _validate_named_id(value: str, kind: str, maximum: int = 128) -> str:
    if not value or len(value) > maximum:
        raise ModelValidationError(f"{kind} must contain 1..{maximum} characters")
    if not _ID_PATTERN.fullmatch(value):
        raise ModelValidationError(f"{kind} contains unsupported characters: {value!r}")
    return value


@dataclass(frozen=True, order=True)
class ProjectId:
    value: str

    def __post_init__(self) -> None:
        _validate_named_id(self.value, "project_id")

    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True, order=True)
class SnapshotId:
    value: str

    def __post_init__(self) -> None:
        _validate_named_id(self.value, "snapshot_id")

    def __str__(self) -> str:
        return self.value


def validate_local_id(local_id: str) -> str:
    if not local_id or len(local_id) > 512:
        raise ModelValidationError("local_id must contain 1..512 characters")
    return local_id


def _sha256(namespace: str, *components: str) -> str:
    digest = hashlib.sha256()
    digest.update(namespace.encode())
    for component in components:
        encoded = component.encode()
        digest.update(len(encoded).to_bytes(8, "big"))
        digest.update(encoded)
    return digest.hexdigest()


def make_local_id(kind: str, *components: str) -> str:
    _validate_named_id(kind, "identity kind", 64)
    if not components:
        raise ModelValidationError("local identity requires string components")
    return _sha256(f"local:{kind}", *components)


def make_global_id(project_id: ProjectId, local_id: str) -> str:
    return _sha256("global-node", project_id.value, validate_local_id(local_id))


def make_edge_id(
    project_id: ProjectId,
    source_id: str,
    relationship_type: str,
    target_id: str,
    discriminator: str = "",
) -> str:
    if not all(value for value in (source_id, relationship_type, target_id)):
        raise ModelValidationError("edge identity requires non-empty endpoint and type values")
    return _sha256(
        "local-edge", project_id.value, source_id, relationship_type, target_id, discriminator
    )
