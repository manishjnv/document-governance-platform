# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Trusted, backend-neutral plugin capability protocols."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING, Protocol, runtime_checkable

from context_graph_sdk.errors import ModelValidationError
from context_graph_sdk.models import CorrelationEdge, GraphMutation
from context_graph_sdk.pipeline.context import CorrelationContext, IndexContext, PluginContext

if TYPE_CHECKING:
    from context_graph_sdk.discovery.walker import RepositoryWalk
    from context_graph_sdk.extractors.records import ExtractionResult
    from context_graph_sdk.project.config import ProjectConfig


class PluginPhase(StrEnum):
    EXTRACTION = "extraction"
    PRE_DERIVATION = "pre_derivation"
    POST_DERIVATION = "post_derivation"
    CORRELATION = "correlation"
    INDEX = "index"


_PHASE_ORDER = {phase: index for index, phase in enumerate(PluginPhase)}


@dataclass(frozen=True)
class PluginMetadata:
    phase: PluginPhase
    priority: int
    name: str
    version: str

    def __post_init__(self) -> None:
        if not self.name or not self.version:
            raise ModelValidationError("plugin name and version are required")

    @property
    def ordering_key(self) -> tuple[int, int, str]:
        return (_PHASE_ORDER[self.phase], self.priority, self.name)


@runtime_checkable
class LanguageExtractor(Protocol):
    """Trusted repository language-extraction capability."""

    @property
    def metadata(self) -> PluginMetadata: ...

    @property
    def languages(self) -> tuple[str, ...]: ...

    def extract(self, repository: RepositoryWalk) -> ExtractionResult: ...


@runtime_checkable
class ProjectExtractor(Protocol):
    """Trusted repository manifest/configuration extraction capability."""

    @property
    def metadata(self) -> PluginMetadata: ...

    def extract(self, repository: RepositoryWalk) -> ProjectConfig: ...


@runtime_checkable
class GraphEnricher(Protocol):
    """Trusted enrichment capability; deadlines are cooperative."""

    @property
    def metadata(self) -> PluginMetadata: ...

    def enrich(self, context: PluginContext) -> GraphMutation: ...


@runtime_checkable
class CorrelationProvider(Protocol):
    """Trusted correlation capability; deadlines are cooperative."""

    @property
    def metadata(self) -> PluginMetadata: ...

    def correlate(self, context: CorrelationContext) -> tuple[CorrelationEdge, ...]: ...


@runtime_checkable
class IndexProvider(Protocol):
    @property
    def metadata(self) -> PluginMetadata: ...

    def build(self, context: IndexContext) -> None: ...
