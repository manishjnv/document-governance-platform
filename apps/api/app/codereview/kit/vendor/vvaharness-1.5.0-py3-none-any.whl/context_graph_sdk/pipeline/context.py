# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Backend-neutral contexts supplied to trusted plugin capabilities."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Protocol, runtime_checkable

from context_graph_sdk.errors import ModelValidationError
from context_graph_sdk.models import (
    FrozenMap,
    GraphSnapshot,
    ProjectMetadata,
    ProjectSnapshot,
    SnapshotLocator,
)


@runtime_checkable
class SourceReader(Protocol):
    def read_text(self, relative_path: str, max_bytes: int) -> str: ...


@runtime_checkable
class CancellationState(Protocol):
    @property
    def is_cancelled(self) -> bool: ...


@runtime_checkable
class AcceptedGraphReader(Protocol):
    """Bounded read access to accepted immutable project snapshots."""

    def query(
        self,
        locator: SnapshotLocator,
        cypher: str,
        parameters: FrozenMap,
        row_limit: int,
    ) -> tuple[FrozenMap, ...]: ...


class PluginLogLevel(StrEnum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


@dataclass(frozen=True)
class PluginDiagnostic:
    code: str
    message: str
    path: str | None = None
    line: int | None = None

    def __post_init__(self) -> None:
        if not self.code or not self.message:
            raise ModelValidationError("diagnostic code and message are required")
        if self.line is not None and self.line <= 0:
            raise ModelValidationError("diagnostic line must be positive")


@runtime_checkable
class PluginReporter(Protocol):
    def log(self, level: PluginLogLevel, message: str, details: FrozenMap) -> None: ...

    def diagnostic(self, diagnostic: PluginDiagnostic) -> None: ...


@dataclass(frozen=True)
class PluginContext:
    project: ProjectMetadata
    graph: GraphSnapshot
    source_reader: SourceReader
    reporter: PluginReporter
    cancellation: CancellationState
    configuration: FrozenMap
    deadline_monotonic: float


@dataclass(frozen=True)
class CorrelationContext:
    candidate: GraphSnapshot
    accepted: tuple[ProjectSnapshot, ...]
    graph_reader: AcceptedGraphReader
    reporter: PluginReporter
    configuration: FrozenMap
    cancellation: CancellationState
    deadline_monotonic: float


@dataclass(frozen=True)
class IndexContext:
    snapshot: ProjectSnapshot
    locator: SnapshotLocator
    artifact_path: Path
    graph_fingerprint: str
    graph_reader: AcceptedGraphReader
    source_reader: SourceReader
    reporter: PluginReporter
    configuration: FrozenMap
    cancellation: CancellationState
    deadline_monotonic: float
