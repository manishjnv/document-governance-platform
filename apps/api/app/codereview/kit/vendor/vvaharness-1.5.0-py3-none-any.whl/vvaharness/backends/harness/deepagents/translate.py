# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Translate DeepAgents / LangGraph state and messages into HarnessMessage types."""

from __future__ import annotations

from collections.abc import AsyncIterator, Mapping, Sequence

from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    ToolMessage,
)
from langchain_core.messages.tool import ToolCall
from pydantic import BaseModel

from vvaharness.backends.harness.deepagents.models import DeepAgentsGraphState, StreamEvent
from vvaharness.backends.harness.deepagents.usage import (
    SessionUsage,
    aggregate_usage_metadata,
)
from vvaharness.backends.harness.models import (
    HarnessAssistantText,
    HarnessMessage,
    HarnessResult,
    HarnessToolResult,
    HarnessToolUse,
    OneShotResult,
)

# Cross-route stop-reason literals live with the other backends so all four routes agree
from vvaharness.backends.llm.models import ai_message_refused, finish_truncated, reply_finish
from vvaharness.util.tokens import TOKENS


def _extract_text(message: AIMessage) -> str:
    if isinstance(message.content, str):
        return message.content
    parts = [
        str(block.get("text", ""))
        for block in message.content
        if isinstance(block, dict) and block.get("type") == "text"
    ]
    return "".join(parts)


def _tool_calls(message: AIMessage) -> list[ToolCall]:
    return list(message.tool_calls)


def _last_ai_text(messages: Sequence[BaseMessage]) -> str | None:
    """Return the last non-empty assistant text found scanning messages in reverse."""
    for message in reversed(messages):
        if isinstance(message, AIMessage):
            text = _extract_text(message).strip()
            if text:
                return text
    return None


def _last_ai_message(messages: Sequence[BaseMessage]) -> AIMessage | None:
    """The final assistant turn, or None when the state carries none."""
    for message in reversed(messages):
        if isinstance(message, AIMessage):
            return message
    return None


def reply_truncated(messages: Sequence[BaseMessage]) -> bool:
    """Whether the final assistant turn was clipped by its output-token budget."""
    message = _last_ai_message(messages)
    return message is not None and finish_truncated(reply_finish(message.response_metadata or {}))


def reply_refusal(messages: Sequence[BaseMessage]) -> tuple[bool, str | None]:
    """``(refused, category)`` over every assistant turn, the first refused one winning."""
    # A refusal can cut a tool_use whose tool still runs, so the refused turn need not be last.
    # Subagent refusals are invisible here; the parent's own next turn decides.
    for message in messages:
        if isinstance(message, AIMessage):
            refused, category = ai_message_refused(message)
            if refused:
                return True, category
    return False, None


def translate_final_state(state: DeepAgentsGraphState, *, oneshot: bool = False) -> OneShotResult:
    """Convert a terminal LangGraph state into a OneShotResult."""
    messages = state.get("messages", [])
    # state["usage"] is never populated here, so recover from messages or one-shots lose telemetry
    usage = aggregate_usage_metadata(messages)
    if usage is not None:
        TOKENS.add(usage, turns=usage.get("turns"))
    truncated = reply_truncated(messages)
    structured = state.get("structured_response")
    if isinstance(structured, BaseModel):
        # A valid structured answer wins over an earlier refused turn
        return OneShotResult(
            result_text=structured.model_dump_json(),
            structured=structured,
            usage=usage,
            truncated=truncated,
        )
    refused, category = reply_refusal(messages)
    return OneShotResult(
        result_text=_last_ai_text(messages), usage=usage, truncated=truncated,
        refused=refused, refusal_category=category,
    )


def _messages_from_event(payload: Mapping[str, DeepAgentsGraphState]) -> list[BaseMessage]:
    """Collect new messages from a LangGraph ``stream_mode='updates'`` payload."""
    messages: list[BaseMessage] = []
    for update in payload.values():
        if not isinstance(update, dict):
            continue
        node_messages = update.get("messages")
        if isinstance(node_messages, Sequence):
            messages.extend(node_messages)
    return messages


async def translate_stream_events(
    event: StreamEvent | Mapping[str, DeepAgentsGraphState],
    seen_tool_call_ids: set[str],
    ns_to_agent: dict[tuple[str, ...], str] | None = None,
) -> AsyncIterator[HarnessMessage]:
    """Yield HarnessMessage variants for one LangGraph stream event."""
    if ns_to_agent is None:
        ns_to_agent = {}
    namespace, payload = event if isinstance(event, tuple) else ((), event)
    namespace_tag = tuple(namespace) if namespace else None
    for message in _messages_from_event(payload):
        if isinstance(message, AIMessage):
            name = getattr(message, "name", None)
            if name:
                ns_to_agent[namespace] = name
            agent = name or ns_to_agent.get(namespace)
            text = _extract_text(message)
            if text.strip():
                yield HarnessAssistantText(text=text, agent=agent, namespace=namespace_tag)
            for call in _tool_calls(message):
                tool_call_id = call.get("id", "")
                if not tool_call_id:
                    continue
                if tool_call_id in seen_tool_call_ids:
                    continue
                seen_tool_call_ids.add(tool_call_id)
                yield HarnessToolUse(
                    tool_id=tool_call_id,
                    name=call.get("name", ""),
                    input=call.get("args", {}),
                    agent=agent,
                    namespace=namespace_tag,
                )
        elif isinstance(message, ToolMessage):
            yield HarnessToolResult(
                content=message.content,
                is_error=getattr(message, "status", "success") == "error",
                agent=ns_to_agent.get(namespace),
                namespace=namespace_tag,
            )


def make_terminal_result(
    state: DeepAgentsGraphState,
    session_id: str | None = None,
    stream_usage: SessionUsage | None = None,
) -> HarnessResult:
    """Synthesize a terminal HarnessResult from the final LangGraph state."""
    # stream_usage wins over final-state aggregation: it alone includes persona subagent turns
    messages = state.get("messages", [])
    final_text = _last_ai_text(messages)
    structured = state.get("structured_response")
    refused, category = False, None
    if isinstance(structured, BaseModel):
        final_text = structured.model_dump_json()
    else:
        structured = None
        refused, category = reply_refusal(messages)
    # state["usage"] is never populated on this route, hence the fallback ladder.
    raw_usage = state.get("usage")
    usage = raw_usage if isinstance(raw_usage, dict) else None
    if usage is None:
        usage = stream_usage if stream_usage is not None else aggregate_usage_metadata(messages)
    if usage is not None:
        TOKENS.add(usage, turns=usage.get("turns"))

    return HarnessResult(
        subtype="success",
        session_id=session_id,
        result_text=final_text,
        structured=structured,
        usage=usage,
        total_cost_usd=None,
        state=state,
        truncated=reply_truncated(messages),
        refused=refused,
        refusal_category=category,
    )


__all__ = [
    "make_terminal_result",
    "reply_refusal",
    "reply_truncated",
    "translate_final_state",
    "translate_stream_events",
]
