# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Path and weakness-class tables s5 matches against."""
from __future__ import annotations

import re

from vvaharness.models import Finding, VulnClass

EXCLUDE_PATH_RE = re.compile(
    r"(^|/)(tests?|__tests__|mocks?|examples?|fixtures?|samples?|testdata)(/|$)"
    r"|_test\.|\.test\.|\.spec\.|Test\.java$|Tests\.cs$",
    re.IGNORECASE,
)

# Point-of-occurrence classes override the test-path exclusion.
HARDCODED_CWES: frozenset[str] = frozenset({
    "CWE-798", "CWE-259", "CWE-321", "CWE-256",
})

CONTROL_ABSENCE_CWES: frozenset[str] = frozenset({
    "CWE-352", "CWE-1004", "CWE-614", "CWE-307",
    "CWE-778", "CWE-311", "CWE-312", "CWE-532", "CWE-209",
})

SECRET_TEXT_RX = re.compile(
    r"(?i)\b(?:"
    r"hard[\s-]?coded|"
    r"password|passwd|"
    r"api[_-]?key|access[_-]?key|secret[_-]?key|"
    r"auth[_-]?token|bearer\s+token|jwt|"
    r"private[_-]?key|client[_-]?secret|credential"
    r")\b"
    r"|-----BEGIN\s+[A-Z ]*PRIVATE\s+KEY-----"
    r"|\bAKIA[0-9A-Z]{16}\b"
    r"|\bgh[pousr]_[0-9A-Za-z]{36,}\b"
    r"|\bxox[baprs]-[0-9A-Za-z-]{10,}\b"
)


def is_secret_class(f: Finding) -> bool:
    """True when *f* is point-of-occurrence, so a test-path match must not exclude it."""
    if f.vuln_class == VulnClass.INFO_LEAK:
        return True
    if f.cwe and (f.cwe in HARDCODED_CWES or f.cwe in CONTROL_ABSENCE_CWES):
        return True
    haystack = " ".join(s for s in (f.title, f.description, f.code_snippet) if s)
    return bool(SECRET_TEXT_RX.search(haystack))
