# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The seed s0 emits: deterministic entry points, sinks, and taint paths."""
from __future__ import annotations

from dataclasses import dataclass, field

from vvaharness.models.scan.surface import EntryPoint, Sink


@dataclass
class SeedPackage:
    """s0's output, merged into ``ContextPackage`` by s1 when present."""
    entry_points: list[EntryPoint] = field(default_factory=list)
    unsafe_sinks: list[Sink] = field(default_factory=list)
    # Each hop is "rel/path:line"; NO producer fills this, so it is always empty (s3's only input)
    taint_paths: list[list[str]] = field(default_factory=list)
    languages: list[str] = field(default_factory=list)
    # s0's full walk, so the tree is stat'd once; empty when s0 is off and s1 walks itself
    all_files: list[str] = field(default_factory=list)
    excluded: dict = field(default_factory=dict)

    def __bool__(self) -> bool:
        """True if s0 found anything worth merging into s1's output."""
        return bool(self.entry_points or self.unsafe_sinks or self.taint_paths)
