# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 8's prompts: the chaining brief, and the per-finding block it ranks."""
from __future__ import annotations

from vvaharness.models import ContextPackage, Finding
from vvaharness.models.scan._render import _confidence_label, _one_line
from vvaharness.pipeline.stages.s6.prompts import _entry_point_lines
from vvaharness.pipeline.stages.s8 import facts as _facts
from vvaharness.pipeline.stages.s8.outcomes import finding_ids
from vvaharness.util.config import knob

SYSTEM = """You are an exploit development strategist reviewing verified findings
that have ALREADY PASSED adversarial verification by a security expert. Each finding
carries a TRUE_POSITIVE verdict, confidence level, and CVSS vector — use this as
authoritative ground truth. Your job is NOT to re-verify bugs or judge exploitability
directly — it's to assess what an attacker can actually DO with these bugs TOGETHER,
and to rank them by chaining opportunity.

For each finding, reassess only the CHAIN potential given:
- Is it pre-auth or post-auth? (check design controls)
- Can a prior finding (or external source) supply input to this sink?
- Does a prior finding's output become this finding's input?
- What primitive does it give? (read, write, control flow, leak, DoS only)
- Which other findings does it SUPPLY that primitive to? Record every such id in
  `feeds` — evidenced or not, but never a finding at the same file:line.

Then look for CHAINS — combinations more dangerous than any single bug. The shape
that matters is "one bug supplies what another needs", for example:
- Auth bypass or missing authorization + a post-auth sink = pre-auth exploit
- Information disclosure (traceback, debug page, leaked key) + a sink that needs
  that secret or path = working attack instead of a guess
- SSRF + an internal service or metadata endpoint = credential theft
- Unrestricted upload or path traversal + a code-loading path = RCE
- Weak session/token generation + missing authorization = account takeover
- New finding + known unpatched CVE = combined attack
- Memory-safety pairs (info leak + corruption, UAF + type confusion) where the
  language actually admits them — do not force this shape onto a managed runtime.
- Reachability: finding A flows to finding B if they share function neighborhoods
  or data flow (check each finding's "Reachability" line). A line reading
  "(inferred from AST, unverified)" is a weaker signal than a derived one; a line
  reading "(no graph context)" is no signal at all — do not invent a flow from it.

If a design control genuinely blocks a chain, say so and downrank it.

The CVSS severity shown against each finding is ALREADY the shipped severity -- the host
derived it and it needs no confirmation from you. Return a `ranked_findings` entry ONLY
for a finding that feeds another, or whose severity you are actively changing, and say
why in at most two sentences. Every finding you omit ships with that CVSS severity. Do
not restate a finding you have nothing to add to: an entry per finding is the single
largest cost in this stage and buys nothing.

Use these bands when you DO change one (verifier already validated the vector):
- CRITICAL (9.0-10.0): likely a standalone problem needing immediate patching
- HIGH (7.0-8.9): serious but may be blocked by pre-auth, sandboxing, or require a chain
- MEDIUM (4.0-6.9): chaining or multi-stage is common; look for it
- LOW (0.1-3.9): useful only in chain or as a stepping stone
- INFO: no standalone or chained exploit path visible

Every finding carries an id like `f3`. Refer to findings ONLY by that id — in
`finding_id`, in `feeds` and in a chain's `steps` — never by position or by title.

Two rules bind every chain you propose:
- Each step must CHANGE what the attacker can do: it supplies a value, a
  privilege, a reachable state or an input that the next step needs and the
  attacker did not already have. A missing control the attacker does not have
  to defeat in order to take the next step is not a step — record it in
  `preconditions` or leave it out.
- The vulnerability named in the chain's `title` must itself be one of the
  `steps`. If the payoff you named is not one of the findings listed below,
  retitle the chain to what its steps actually achieve.

Close the loop before you write `summary`, which comes last. Every id in a
finding's `feeds` that you can evidence becomes a chain with `link_evidence`;
one you cannot evidence stays in `feeds` and is not a chain. A precondition or
an amplifier — a root container, a missing header — is not a `feeds` entry: it
stays in `exploitability_notes` or a chain's `preconditions`. The `summary`
describes only chains that appear in `chains` — a family you did not list is
not summarised."""


# Gates the fact blocks: entry-point inventory, Dockerfile USER, decorator prologue in each snippet
_FACT_BLOCKS = "step8.prompt_fact_blocks"


def facts_enabled(cfg) -> bool:
    """Returns whether the deterministic fact blocks render, defaulting to on for ``cfg=None``."""
    return bool(knob(cfg, _FACT_BLOCKS, True))


# Off by default and in every profile: attack-narrative text may raise the cyber-refusal rate
_HOP_TEXT = "step8.hop_text"


def hop_text_enabled(cfg) -> bool:
    """Returns whether each finding block carries its scenario/preconditions lines."""
    return bool(knob(cfg, _HOP_TEXT, False))


def _hop_lines(f: Finding) -> str:
    """Returns the Scenario/Preconditions lines, omitting each one that is empty."""
    fields = (("Scenario", _one_line(f.exploit_scenario)),
              ("Preconditions", "; ".join(filter(None, map(_one_line, f.preconditions)))))
    return "".join(f"    {label}: {text}\n" for label, text in fields if text)


# A check against asserted-but-unregistered routes: an ALLOWLIST; as a denylist it refutes live
_ENTRY_POINT_CAVEAT = (
    "  This inventory is INCOMPLETE: it is derived from the pattern scan and\n"
    "  the code graph, which do not see framework dispatch, dynamic or\n"
    "  generated registration. A line here is evidence that the entry point\n"
    "  exists; ABSENCE FROM THIS LIST IS NOT evidence that a route is\n"
    "  unregistered or unreachable, and must not be argued either way."
)


def _entry_point_block(ctx: ContextPackage) -> str:
    """Returns s6's entry-point rendering plus S8's caveat, or "" when the census is empty."""
    lines = _entry_point_lines(ctx)
    return f"{lines}\n{_ENTRY_POINT_CAVEAT}\n\n" if lines else ""


def reachability_for_finding(f: Finding, ctx: ContextPackage) -> str:
    """Compact reachability signature for chaining, showing source/sink refs."""
    parts = []
    if f.source_ref:
        marker = " (inferred from AST, unverified)" if "source_ref" in f.backfilled_refs else ""
        parts.append(f"source={f.source_ref}{marker}")
    if f.sink_ref:
        marker = " (inferred from AST, unverified)" if "sink_ref" in f.backfilled_refs else ""
        parts.append(f"sink={f.sink_ref}{marker}")
    return " ".join(parts) if parts else "(no graph context)"


def finding_block(fid: str, f: Finding, ctx: ContextPackage,
                  facts_on: bool = True, hop_text: bool = False) -> str:
    """Returns one finding's prompt block, including its redacted code snippet."""
    cvss = f.cvss_vector or "n/a"
    verified = (f"{f.verdict} {_confidence_label(f.verdict_confidence)}"
                if f.verdict else "unverified")
    reachability = reachability_for_finding(f, ctx)
    snippet = _facts.snippet_for(f, ctx.repo_root,
                                 include_decorators=facts_on)
    # _one_line on model prose: a multi-line title could forge a field or a new [fN] header
    out = (
        f"[{fid}] {f.vuln_class.value} @ {f.file}:{f.line_start}-{f.line_end}\n"
        f"    Title: {_one_line(f.title)}\n"
        f"    CVSS: {cvss}  |  Verified: {verified}\n"
        f"    {_one_line(f.description)}\n"
        + (_hop_lines(f) if hop_text else "")
        + f"    Reachability: {reachability}\n"
    )
    if snippet:
        out += "    CODE:\n" + _indent_block(snippet) + "\n"
    return out


def _indent_block(text: str, pad: str = "      ") -> str:
    """Indent a code block under its field so the prompt stays scannable."""
    return "\n".join(f"{pad}{ln}" for ln in text.splitlines())


def repo_fact_blocks(findings: list[Finding], ctx: ContextPackage,
                     labels: list[str], facts_on: bool = True) -> str:
    """Returns the ENTRY POINTS, DEPLOYMENT EXPOSURE and FINDINGS AT THE SAME LOCATION sections."""
    # The windowing estimator calls this same function, so its estimate cannot drift from the prompt
    exposure = _facts.exposure_facts(ctx, findings, user_facts=facts_on)
    exposure_block = ("\n".join(f"  - {e}" for e in exposure)
                      if exposure else "  (not determined)")
    colocated = _facts.same_location_groups(findings, labels)
    colocated_block = ("\n".join(f"  - {c}" for c in colocated)
                       if colocated else "  (none)")
    entry_block = _entry_point_block(ctx) if facts_on else ""
    return f"""{entry_block}DEPLOYMENT EXPOSURE (how this app is actually reachable — these facts were
read from the repo and OVERRIDE any assumption about a remote attacker):
{exposure_block}

FINDINGS AT THE SAME LOCATION (one code fact, so they can NEVER be two steps
of the same chain — pick at most one of each group per chain):
{colocated_block}"""


def build_prompt(findings: list[Finding], ctx: ContextPackage, *,
                 labels: list[str] | None = None, cfg=None) -> str:
    """Returns the chaining prompt; ``labels`` must be the ORIGINAL finding ids, not a window's."""
    if labels is None:
        labels = list(finding_ids(findings))
    facts_on = facts_enabled(cfg)
    hop_text = hop_text_enabled(cfg)
    blocks = [finding_block(fid, f, ctx, facts_on, hop_text)
              for fid, f in zip(labels, findings)]
    findings_block = "\n".join(blocks)

    controls_block = "\n".join(
        f"  - [{c.kind}] {c.name} -> protects: {', '.join(c.protects) or 'global'}"
        for c in ctx.design_controls
    ) or "  (none)"

    cve_block = "\n".join(
        f"  - {c.id} (CVSS {c.cvss}, {'patched' if c.patched else 'UNPATCHED'}): {c.summary}"
        for c in ctx.known_cves
    ) or "  (none)"

    tm_block = ""
    if ctx.app_profile:
        tm_block += ctx.app_profile.to_prompt_block() + "\n"
    if ctx.threat_model:
        tm_block += ctx.threat_model.to_prompt_block() + "\n"

    return f"""REPO: {ctx.repo_root}

{tm_block}DESIGN CONTROLS:
{controls_block}

KNOWN CVEs (check for combinations with new findings):
{cve_block}

{repo_fact_blocks(findings, ctx, labels, facts_on)}

FINDINGS (refer to each by its bracketed id):
{findings_block}

EVIDENCE RULES:
  - The CODE block under each finding was read from the repository and is
    authoritative: where it contradicts a finding's prose, the code wins. Read
    it before asserting a sink is reachable — a guard, an early return or an
    `else` branch in that code decides whether "unauthenticated" is true.
  - If a sink runs only under a condition the shipped default does not satisfy
    (a config flag, an env var, a non-default launch argument), the chain is
    not unauthenticated. Record that condition in `preconditions` — it is
    printed to the reader as "Requires:" — or drop the chain.
  - For every adjacent pair of steps, give one `link_evidence` entry naming the
    mechanism and the file:line that shows it. Citations are checked against
    the repository; one that does not resolve is flagged to the reader as
    unconfirmed, so cite the line you actually relied on. If you cannot
    evidence a link, the chain is not real — omit it. An invented chain is
    worse than none.
  - Put the attacker's route to the FIRST step in `entry_reachability`.
  - A route, an accepted HTTP method, a published port, the user the
    deployment runs as, and any application feature or flow a step relies on
    or leads to (a password reset, an admin panel, mail sending, a file
    store) are FACTS, not inferences: assert one only where it
    appears in a fact block above or in a CODE block you were given. Where
    neither shows it, write the step as depending on it ("if this handler
    accepts POST", "if the application offers a password reset") instead of
    asserting it, in every prose field (`title`, `narrative`,
    `entry_reachability`, `summary`, `exploitability_notes`) alike. A chain
    resting on an assumed route, method or feature is an invented chain;
    an impact resting on one is an invented impact.

Analyze and respond with ONLY the JSON object."""


def repair_prompt(raw: str, err: Exception) -> str:
    """The one bounded re-ask when a chain reply did not parse as a ChainReport."""
    return (
        "REPAIR TASK: the previous reply was supposed to be ONE JSON object with keys "
        "`ranked_findings`, `chains`, `summary` but failed to parse. Return ONLY the corrected "
        "JSON object. Restate what is already there: do not add, remove or reconsider any "
        "chain or entry; an unfinished chain is worth less than no chain.\n\n"
        f"PARSE ERROR: {type(err).__name__}: {err}\n\n--- ORIGINAL REPLY ---\n{raw}"
    )
