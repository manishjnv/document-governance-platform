# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Per-stage status reporting for the scan pipeline; stderr only, stdout stays clean for reports."""
# Plain timestamped lines, no cursor tricks off-TTY, so this is safe under CI and log capture
from __future__ import annotations

import itertools
import json
import os
import shutil
import sys
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime

from vvaharness.report.redact import redact
from vvaharness.util import errlog as _errlog
from vvaharness.util.stage_telemetry import STAGES

_SPIN = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
_CYAN, _GREEN, _RED, _YELLOW, _DIM, _RST = (
    "\033[36m", "\033[32m", "\033[31m", "\033[33m", "\033[2m", "\033[0m")

# Public on purpose; WARN_MARK is "finished, coverage lost", which the exit code cannot say
OK_MARK, WARN_MARK, FAIL_MARK = "✓", "⚠", "✗"


@dataclass
class StageResult:
    """Optional non-error result annotation for a completed stage."""

    incomplete_detail: str = ""

    def mark_incomplete(self, detail: str) -> None:
        """Render this clean completion as incomplete, with *detail*."""
        self.incomplete_detail = detail


def _is_tty(stream) -> bool:
    try:
        return bool(stream.isatty())
    except Exception:
        return False


class _Spinner:
    """Animate one stderr line in place until stopped, then clear it for the caller's own line."""

    def __init__(self, label, out, n=None, total=None):
        self._label, self._out, self._n, self._total = label, out, n, total
        self._stop = threading.Event()
        self._t0 = time.time()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def start(self):
        self._thread.start()
        return self

    def _run(self):
        tag = f"[{self._n}/{self._total}] " if self._n and self._total else ""
        for frame in itertools.cycle(_SPIN):
            if self._stop.is_set():
                break
            el = int(time.time() - self._t0)
            # Truncate to terminal width: a wrapped line defeats the single-row \r\033[K rewrite
            cols = shutil.get_terminal_size((80, 24)).columns
            prefix = f"  {frame} {tag}"      # visible leading text
            suffix = f" … {el}s"             # visible trailing text
            budget = cols - len(prefix) - len(suffix) - 1
            label = self._label
            if budget > 1 and len(label) > budget:
                label = label[: budget - 1] + "…"
            self._out.write(f"\r\033[K  {_CYAN}{frame}{_RST} "
                            f"{tag}{label}{_DIM}{suffix}{_RST}")
            self._out.flush()
            self._stop.wait(0.12)

    def stop(self):
        self._stop.set()
        self._thread.join(timeout=1)
        self._out.write("\r\033[K")   # clear the spinner line
        self._out.flush()


def json_logs_enabled() -> bool:
    """Structured JSON event logging is on when VVAHARNESS_JSON_LOGS is set to a truthy value (1/true/yes)."""
    return os.environ.get("VVAHARNESS_JSON_LOGS", "").lower() in ("1", "true", "yes")


def emit_event(event: str, *, stream=None, **fields) -> None:
    """Emit one structured JSON log line (no-op unless JSON logs are enabled)."""
    if not json_logs_enabled():
        return
    out = stream if stream is not None else sys.stderr
    rec = {"ts": datetime.now(UTC).isoformat(), "event": event}
    rec.update({k: v for k, v in fields.items() if v is not None})
    print(json.dumps(rec, separators=(",", ":")), file=out, flush=True)


@contextmanager
def stage(label: str, *, n: int | None = None, total: int | None = None,
          stream=None, animate: bool | None = None,
          stage_id: str | None = None):
    """Wrap a pipeline stage: start line, timed body, then a ✓ completion or ✗ failure line."""
    # NEVER swallows; pass animate=False when the body shares the stream, or the spinner spams
    out = stream if stream is not None else sys.stderr
    tag = f"[{n}/{total}] " if n is not None and total is not None else ""
    as_json = json_logs_enabled()
    auto_animate = _is_tty(out)
    animate = (auto_animate if animate is None else animate) and not as_json
    t0 = time.time()
    spin = None
    err0 = (_errlog.count_for_stage(stage_id, include_recovered=False)
            if stage_id else 0)
    if stage_id:
        STAGES.start(stage_id, label)
    if as_json:
        emit_event("stage_start", stage=label, n=n, total=total,
                   stage_id=stage_id, stream=out)
    elif animate:
        spin = _Spinner(label, out, n, total).start()
    else:
        print(f"  ▶ {tag}{label} …", file=out, flush=True)
    result = StageResult()
    try:
        yield result
    except BaseException as e:
        dt = round(time.time() - t0, 2)
        if spin:
            spin.stop()
        if stage_id:
            STAGES.done(stage_id, outcome="error", duration_sec=dt)
        if as_json:
            emit_event("stage_fail", stage=label, n=n, total=total,
                       duration_sec=dt, stage_id=stage_id,
                       error=redact(f"{type(e).__name__}: {e}"), stream=out)
        else:
            x = f"{_RED}{FAIL_MARK}{_RST}" if animate else FAIL_MARK
            print(f"  {x} {tag}{label} — failed after {dt:.1f}s: "
                  f"{redact(f'{type(e).__name__}: {e}')}", file=out, flush=True)
        # Blank separator between stage blocks; skipped in JSON mode (one object per line).
        if not as_json:
            print(file=out, flush=True)
        raise
    else:
        dt = round(time.time() - t0, 2)
        if spin:
            spin.stop()
        # Only records NOT recovered=True count: a marker firing on healthy runs gets ignored
        n_err = ((_errlog.count_for_stage(stage_id, include_recovered=False)
                  - err0) if stage_id else 0)
        if stage_id:
            outcome = "completed_with_errors" if n_err > 0 else "completed"
            STAGES.done(stage_id, outcome=outcome, duration_sec=dt)
        # "unrecovered", not "recoverable": include_recovered=False means exactly those
        note = (f", {n_err} unrecovered error(s) — see errors.jsonl"
                if n_err > 0 else "")
        # Derived from the SAME n_err, never recomputed; colour alone fails in uncoloured CI logs
        mark, colour = (WARN_MARK, _YELLOW) if n_err > 0 else (OK_MARK, _GREEN)
        if result.incomplete_detail and as_json:
            emit_event("stage_incomplete", stage=label, n=n, total=total,
                       duration_sec=dt, stage_id=stage_id,
                       detail=result.incomplete_detail, stream=out)
        elif as_json:
            emit_event("stage_ok", stage=label, n=n, total=total,
                       duration_sec=dt, stage_id=stage_id,
                       errors=n_err if n_err > 0 else None, stream=out)
        elif result.incomplete_detail:
            print(f"  ○ {tag}{label} — {result.incomplete_detail} ({dt:.1f}s{note})",
                  file=out, flush=True)
        elif animate:
            print(f"  {colour}{mark}{_RST} {tag}{label} {_DIM}({dt:.1f}s{note}){_RST}",
                  file=out, flush=True)
        else:
            print(f"  {mark} {tag}{label} ({dt:.1f}s{note})", file=out, flush=True)
        # Blank separator between stage blocks; skipped in JSON mode (one object per line).
        if not as_json:
            print(file=out, flush=True)
