# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Per-run entry-point and sink snapshots: the graph rows written and read back."""
from __future__ import annotations

import hashlib
import json

from vvaharness.orchestrator.store._db import connect


def _qnode(file_path: str, function_name: str) -> str:
    file_part = (file_path or "").replace("\\", "/")
    fn_part = function_name or ""
    return f"{file_part}::{fn_part}" if file_part or fn_part else ""


def _split_qnode(qnode: str) -> tuple[str, str]:
    # Split on the LAST "::" to match the canonical q_split in s1_preprocess, or a hydrated graph points at the wrong file for a name that itself contains "::" (C++, C#).
    if "::" not in qnode:
        return "", qnode
    f, _, n = qnode.rpartition("::")
    return f, n


def _graph_rows(obj) -> list[dict] | None:
    """Build one node row per qnode named by ``obj.entry_points``/``obj.unsafe_sinks`` — an entry/sink index, no..."""
    entry_points = list(getattr(obj, "entry_points", ()) or ())
    unsafe_sinks = list(getattr(obj, "unsafe_sinks", ()) or ())
    if not (entry_points or unsafe_sinks):
        return None

    entry_meta: dict[str, tuple[str, int]] = {}
    for ep in entry_points:
        qn = _qnode(getattr(ep, "file", ""), getattr(ep, "function", ""))
        if qn:
            entry_meta[qn] = (
                (getattr(ep, "kind", "") or ""),
                1 if bool(getattr(ep, "reachable_from_unauth", False)) else 0,
            )

    sink_meta: dict[str, int] = {}
    for sink in unsafe_sinks:
        qn = _qnode(getattr(sink, "file", ""), getattr(sink, "function", ""))
        if qn:
            line = int(getattr(sink, "line", 0) or 0)
            prev = sink_meta.get(qn)
            sink_meta[qn] = line if prev is None or (line and line < prev) else prev

    node_rows: list[dict] = []
    for qn in sorted(set(entry_meta) | set(sink_meta)):
        file_path, function_name = _split_qnode(qn)
        entry_kind, unauth = entry_meta.get(qn, ("", 0))
        sink_line = sink_meta.get(qn, 0)
        node_rows.append({
            "qnode": qn,
            "file_path": file_path,
            "function_name": function_name,
            "is_entry_point": 1 if qn in entry_meta else 0,
            "entry_kind": entry_kind,
            "reachable_from_unauth": unauth,
            "is_sink": 1 if qn in sink_meta else 0,
            "sink_line": sink_line,
        })

    return node_rows


def save_callgraph(run_id: str, step: str, obj) -> str | None:
    """Persist ``obj``'s entry-point/sink qnode index and bind the current step to it, storing rows rather than a single BLOB so large graphs remain queryable."""
    node_rows = _graph_rows(obj)
    if node_rows is None:
        return None
    payload = json.dumps({
        "nodes": node_rows,
    }, sort_keys=True, separators=(",", ":")).encode()
    graph_id = hashlib.sha256(payload).hexdigest()[:32]

    con = connect()
    try:
        with con:
            con.execute("INSERT OR IGNORE INTO runs(run_id, repo_root) VALUES (?, '')",
                        (run_id,))
            con.execute("UPDATE runs SET updated_at = datetime('now') WHERE run_id = ?",
                        (run_id,))
            exists = con.execute(
                "SELECT 1 FROM callgraph_snapshots WHERE run_id=? AND graph_id=?",
                (run_id, graph_id),
            ).fetchone()
            if exists is None:
                con.execute(
                    "INSERT INTO callgraph_snapshots"
                    "(run_id, graph_id, node_count, edge_count, entry_point_count, sink_count) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        run_id,
                        graph_id,
                        len(node_rows),
                        0,
                        sum(r["is_entry_point"] for r in node_rows),
                        sum(r["is_sink"] for r in node_rows),
                    ),
                )
                con.executemany(
                    "INSERT INTO callgraph_nodes"
                    "(run_id, graph_id, qnode, file_path, function_name, start_line, end_line, "
                    " is_entry_point, entry_kind, reachable_from_unauth, is_sink, sink_line) "
                    "VALUES (?, ?, ?, ?, ?, 0, 0, ?, ?, ?, ?, ?)",
                    [(
                        run_id,
                        graph_id,
                        row["qnode"],
                        row["file_path"],
                        row["function_name"],
                        row["is_entry_point"],
                        row["entry_kind"],
                        row["reachable_from_unauth"],
                        row["is_sink"],
                        row["sink_line"],
                    ) for row in node_rows],
                )
            con.execute(
                "INSERT OR REPLACE INTO callgraph_stage_refs(run_id, step, graph_id) VALUES (?, ?, ?)",
                (run_id, step, graph_id),
            )
        return graph_id
    finally:
        con.close()


def load_callgraph(run_id: str, step: str) -> dict | None:
    """Load the entry-point/sink qnode index bound to ``(run_id, step)`` as isolated ``call_graph`` nodes (no edges — this store never had any), or ``None`` when the step has no bound graph."""
    con = connect()
    try:
        ref = con.execute(
            "SELECT graph_id FROM callgraph_stage_refs WHERE run_id=? AND step=?",
            (run_id, step),
        ).fetchone()
        if ref is None:
            return None
        graph_id = ref[0]
        node_rows = con.execute(
            "SELECT qnode FROM callgraph_nodes WHERE run_id=? AND graph_id=?",
            (run_id, graph_id),
        ).fetchall()
    finally:
        con.close()

    return {
        "graph_id": graph_id,
        "call_graph": {qn: [] for (qn,) in node_rows},
        "node_count": len(node_rows),
    }
