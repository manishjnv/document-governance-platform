# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 2's reply parsing and the deterministic finalisation of its threats."""
from __future__ import annotations

from vvaharness.models import ContextPackage, ThreatModel
from vvaharness.report.redact import redact
from vvaharness.scope import resolve_inventory_path
from vvaharness.util import console, logs
from vvaharness.util import errlog as _errlog
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event
from vvaharness.util.json_extract import extract_json

log = logs.get_logger(__name__)


def _parse_threat_model(raw: str) -> ThreatModel:
    """Extracts and schema-validates a ThreatModel from a raw model reply, in one step."""
    data = extract_json(raw)
    # All fields default so model_validate takes ANY dict; bare {} stays accepted (pinned by a test)
    if isinstance(data, dict) and data \
            and not (data.keys() & ThreatModel.model_fields.keys()):
        raise ValueError(
            "extracted JSON object has none of the threat-model fields "
            f"(got keys: {sorted(data.keys())[:8]}) — likely a sub-object "
            "of a truncated or malformed response")
    return ThreatModel.model_validate(data)
def _finalize_threats(tm: ThreatModel, ctx: ContextPackage | None) -> None:
    """Assigns ids by list position and resolves surface_files to inventory form, dropping what ctx cannot validate."""
    for i, t in enumerate(tm.threats, start=1):
        t.id = f"T{i}"
    if ctx is None or not tm.threats:
        return
    valid = set(ctx.all_files)
    emitted = 0
    dropped: list[str] = []
    for t in tm.threats:
        pairs = [(raw, resolve_inventory_path(ctx.repo_root, raw, valid)) for raw in t.surface_files]
        t.surface_files = list(dict.fromkeys(rel for _, rel in pairs if rel in valid))
        dropped += [raw for raw, rel in pairs if rel not in valid]
        emitted += len(pairs)
    console.write(f"  [s2] surface_files: {emitted - len(dropped)} of {emitted} path(s) across "
                  f"{len(tm.threats)} threat(s) resolved to an in-scope file")
    if not dropped:
        return
    COUNTERS.bump("s2_surface_files_dropped", len(dropped))
    # Model text: redact the whole sample BEFORE the cap
    sample = redact(", ".join(dropped))[:300]
    log.warning(Event.S2_SURFACE_FILES_DROPPED, dropped=len(dropped), sample=sample)
    if len(dropped) == emitted:
        # DELIBERATELY UNMARKED (no recovered=True), like the zero-threats record in run():
        # every threat lost its whole surface, so s3 mints nothing
        _errlog.log("s2", "threatmodel",
                    "every surface_files path was rejected — no threat keeps a "
                    "validated surface; s3 will mint no investigation unit",
                    dropped=sample)


# (kind, step2 key, counter); threats carry no counter here, _cap_threats already bumps its own
_OUTPUT_CAPS = (
    ("threats", "max_threats", None),
    ("assets", "max_assets", "s2_assets_truncated"),
    ("trust_boundaries", "max_trust_boundaries", "s2_trust_boundaries_truncated"),
)


def _warn_output_caps(raw: tuple[int, int, int], tm: ThreatModel,
                      limits: tuple[int, int, int]) -> None:
    """Warn for each step2 output cap that dropped part of the threat model, naming its key."""
    kept = (len(tm.threats), len(tm.assets), len(tm.trust_boundaries))
    for (kind, key, counter), total, n, limit in zip(_OUTPUT_CAPS, raw, kept, limits):
        if n >= total:
            continue
        if counter:
            COUNTERS.bump(counter, total - n)
        log.warning(Event.S2_CAP_TRUNCATED, kind=kind, kept=n, total=total,
                    excluded=total - n, cap=f"step2.{key}", limit=limit)
