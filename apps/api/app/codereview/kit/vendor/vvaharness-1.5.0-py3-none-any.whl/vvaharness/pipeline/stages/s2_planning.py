# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""S2's todo-list planning prompts: the parent owns breadth, with no sub-agents."""

from __future__ import annotations

PLAN_SYSTEM_PROMPT = (
    '## Planning is mandatory here\n\n'
    'Your FIRST action is `write_todos`. Do not emit the threat model before you have written a '
    'plan and worked it. Every threat you name has to rest on code you actually opened, and every '
    'threat you fail to name is invisible to every later stage — this stage sets the ceiling on '
    'what the whole scan can find.\n\n'
    'You have no sub-agents. The todo list IS your coverage guarantee, and it is the only thing '
    'standing between a directory and being silently unread.\n\n'
    'Every plan covers at least:\n'
    '  1. Partition the FILE INVENTORY into directory groups and write one todo per group, so the '
    'plan itself accounts for every file in scope. A group with no todo is a set of files no later '
    'stage will open. The inventory is already in this prompt — partition it, do not go and '
    're-enumerate it with `ls` or Glob.\n'
    '  2. Work the groups in order of how likely they are to hide a threat nothing else will find: '
    'templates and views first, then container/CI/IaC, then models and persistence, then utils. '
    'Request handlers last — they are the best-covered code in any repo and the rest of the '
    'pipeline still sees them.\n'
    '  3. Open the entry points and confirm which are reachable unauthenticated.\n'
    '  4. Establish module structure and blast radius from the graph rather than from directory '
    'names: `GraphContext` for a symbol\'s callers, callees and imports in one call, '
    '`GraphImpact` for whether anything reaches it, `GraphCommunityOf` for a file\'s module, '
    '`GraphSinksInCommunity` for the sinks already known in it. One `GraphContext` call answers '
    'what several Reads would.\n'
    '  5. Read the container, CI and infrastructure files — `Dockerfile`, `docker-compose*.yml`, '
    'IaC, `.github/**`. Secrets and deployment posture live there and nowhere else.\n'
    '  6. Read the templates and client-side files. An unescaped interpolation of stored data is a '
    'finding, and nothing else in the pipeline will look for it.\n'
    '  7. Give every threat a `surface_files` list of real paths taken from what you actually '
    'read.\n'
    '  8. Reconcile: subtract every path you named from the inventory and account for what is '
    'left, either with a new threat or a one-line reason in `open_questions`. Emit '
    '"unreviewed: <n> file(s) — <reason>" when any remain.\n\n'
    'Mark each todo in_progress as you start it and completed only when genuinely done. Add todos '
    'when what you read opens something new. Only once every todo is completed do you emit the '
    'threat model.'
)

PLAN_TOOL_DESCRIPTION = (
    'Record and update your threat-modelling plan. Call this FIRST, before any other tool, then '
    'keep it current: mark a todo in_progress when you start it and completed when you have '
    'genuinely finished it, and add todos as the code opens new questions. This is not optional '
    'and not only for long tasks. Statuses are "pending", "in_progress" and "completed". Never '
    'call this tool twice in one turn.'
)

__all__ = [
    "PLAN_SYSTEM_PROMPT",
    "PLAN_TOOL_DESCRIPTION",
]
