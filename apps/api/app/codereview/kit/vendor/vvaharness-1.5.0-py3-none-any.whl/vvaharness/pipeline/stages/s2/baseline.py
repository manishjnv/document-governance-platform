# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 2's minimum-baseline audit: which required items a threat model left undisposed."""
from __future__ import annotations

import re
from collections.abc import Collection

from vvaharness.models import Threat, ThreatModel
from vvaharness.rules.repo_kinds import BASELINES


_BASELINE_EVIDENCE_RX = re.compile(r"baseline:\s*(BL-[A-Z]+-\w+)")


def _required_baselines(kinds: set[str]) -> set[str]:
    """Baseline ids every repo kind in `kinds` requires a disposal for."""
    return {bid for k in kinds for bid, _ in BASELINES.get(k, ())}


def _baseline_audit(tm: ThreatModel, kinds: set[str]) -> set[str]:
    """Returns required baseline ids given neither a "baseline: <ID>" threat nor an open_questions entry."""
    required = _required_baselines(kinds)
    as_threat = {m.group(1) for t in tm.threats
                 if (m := _BASELINE_EVIDENCE_RX.match(t.evidence or ""))}
    as_question = {q.split(":", 1)[0].strip() for q in tm.open_questions
                   if q.startswith("BL-")}
    return required - as_threat - as_question


# Each id's BASELINES description doubles as its OWASP category label: no second taxonomy.
# _COVERED_BY_ALIAS is NOT a second taxonomy either — it only lets a disposed id's OWN terms
# join another id's candidate set; the stem rule below still applies only to a term's own baseline.
_BASELINE_TEXT_BY_ID: dict[str, str] = {
    bid: text for _entries in BASELINES.values() for bid, text in _entries
}

#: An application-layer disposal of BL-WEB-A02 (crypto failures) also speaks to the IaC
#: TLS/encryption half, but never the other half of BL-IAC-TLS ("unencrypted storage classes").
_COVERED_BY_ALIAS: dict[str, tuple[str, ...]] = {"BL-IAC-TLS": ("BL-WEB-A02",)}

_CATEGORY_STOPWORDS = {
    "the", "and", "for", "via", "not", "any", "use", "non", "its", "that",
    "this", "from", "into", "with", "owasp", "cwe",
}


def _stem(word: str) -> str:
    """Strips a trailing "ed", "es" or "s" from a word of 6+ letters; shorter words pass through."""
    if len(word) < 6:
        return word
    for suffix in ("ed", "es", "s"):
        if word.endswith(suffix):
            return word[:-len(suffix)]
    return word


def _category_terms(bid: str) -> frozenset[str]:
    """Returns lowercase word-stems (len >= 3) from `bid`'s own `BASELINES` description."""
    text = _BASELINE_TEXT_BY_ID.get(bid, "")
    words = re.findall(r"[A-Za-z]+", text.lower())
    return frozenset(_stem(w) for w in words
                     if len(w) >= 3 and w not in _CATEGORY_STOPWORDS)


#: One shared word is noise: "missing" matched A02+A07, "default" A05; two terms cannot be faked
_MIN_CATEGORY_TERM_MATCHES = 2


def _category_covered_elsewhere(bid: str, threats: list[Threat],
                                disposed: Collection[str] = ()) -> bool:
    """True if some threat's text names `bid`'s own category, or a disposed alias's."""
    own_terms = _category_terms(bid)
    alias_terms: frozenset[str] = frozenset()
    for alias_bid in _COVERED_BY_ALIAS.get(bid, ()):
        if alias_bid in disposed:
            alias_terms |= _category_terms(alias_bid)
    terms = own_terms | alias_terms
    if len(terms) < _MIN_CATEGORY_TERM_MATCHES:
        return False
    for t in threats:
        text = t.threat.lower()
        matched = {term for term in terms if term in text}
        # At least one matched term must come from bid's OWN text, or an alias could cover alone
        if len(matched) >= _MIN_CATEGORY_TERM_MATCHES and (matched & own_terms):
            return True
    return False
