# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Reading the `claude` JSON envelope: guardrails, usage, telemetry, assistant text."""
from __future__ import annotations

import json
from typing import cast

from vvaharness.backends.llm import cache as _cache
from vvaharness.backends.llm.models import (
    ANTHROPIC_STOP_REFUSAL,
    CLI_CONTINUED_REPLIES_COUNTER,
    EnvelopeResult,
    GuardrailBlocked,
    model_refusal,
    refusal_category,
)
from vvaharness.util import logs
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event
from vvaharness.util.json_extract import extract_json

# Token accounting is shared with the SDK backend (util/tokens.py); re-exported for legacy imports
from vvaharness.util.tokens import TOKENS, TokenUsage

log = logs.get_logger(__name__)




# Known canned-refusal strings from the classifier; exact match only, avoiding false positives.
_GUARDRAIL_REFUSALS = frozenset({
    "Your request was not allowed",
})


def _check_guardrail(env: dict) -> None:
    text = env.get("result")
    if (isinstance(text, str)
            and text.strip() in _GUARDRAIL_REFUSALS
            and (env.get("num_turns") or 1) <= 1
            and not env.get("is_error")):
        out_tok = ((env.get("usage") or {}).get("output_tokens"))
        raise GuardrailBlocked(
            "org content-guardrail blocked this prompt "
            f"(result={text!r}, num_turns={env.get('num_turns')}, "
            f"out_tok={out_tok}). The classifier on api.anthropic.com is "
            "rejecting the prompt content — this is NOT a pipeline bug. ")


def _spend_of(event: dict | None) -> tuple[int | None, float | None]:
    """(turns, usd) off a CLI result event, or (None, None) when it did not report them."""
    turns = (event or {}).get("num_turns")
    usd = (event or {}).get("total_cost_usd")
    return (turns if isinstance(turns, int) else None,
            float(usd) if isinstance(usd, (int, float)) else None)


def _structured_text(event: dict | None) -> str | None:
    """Serialized ``structured_output`` off a CLI result event, when it carries one."""
    payload = (event or {}).get("structured_output")
    if not isinstance(payload, (dict, list)):
        return None
    try:
        return json.dumps(payload)
    except (TypeError, ValueError):      # non-serializable payload — fall back to `result`
        return None


def _telemetry_of(event: dict | None) -> tuple[str | None, dict | None]:
    """(stop_reason, modelUsage) off a CLI result event, both None when absent."""
    # CLI summary, not the wire response; TERMINAL event only: streamed ones say stop_reason null
    stop = (event or {}).get("stop_reason")
    usage = (event or {}).get("modelUsage")
    return (stop if isinstance(stop, str) else None,
            usage if isinstance(usage, dict) else None)


def _decode_stream(stdout: str) -> object:
    """*stdout* as one JSON document, else the list of its parsed NDJSON lines; None if none."""
    try:
        return json.loads(stdout)
    except (json.JSONDecodeError, TypeError):
        pass
    objs: list = []
    for ln in stdout.splitlines():
        ln = ln.strip()
        if not ln:
            continue
        try:
            objs.append(json.loads(ln))
        except (json.JSONDecodeError, TypeError):
            continue
    return objs or None


def _stream_events(stdout: str) -> list[dict]:
    """Every JSON object in *stdout*, whether NDJSON lines or one list/dict document."""
    doc = _decode_stream(stdout)
    items = doc if isinstance(doc, list) else [doc]
    return [e for item in items for e in (item if isinstance(item, list) else [item])
            if isinstance(e, dict)]


def _refusal_category_of(stdout: str) -> str | None:
    """The refusal category the stream's structured keys report; None when it carries none."""
    # Keys only, never the wording. `model_refusal_fallback` (a refusal the CLI recovered from)
    # is never read: this runs only when the TERMINAL stop_reason is a refusal.
    events = _stream_events(stdout)
    refused = [e["message"] for e in events
               if e.get("type") == "assistant" and isinstance(e.get("message"), dict)
               and e["message"].get("stop_reason") == ANTHROPIC_STOP_REFUSAL]
    category = refusal_category(refused[-1]) if refused else None
    if category is not None:
        return category
    api = next((e.get("apiRefusalCategory") for e in reversed(events)
                if e.get("type") == "system" and e.get("subtype") == "model_refusal_no_fallback"),
               None)
    return api if isinstance(api, str) else None


def _raise_if_refused(stop_reason: str | None, *, tag: str | None, stdout: str) -> None:
    """Raise the typed refusal for a refused reply; callers bank its usage first."""
    # Not in _check_guardrail: it runs before the usage is banked. Category from *stdout*'s
    # stream keys; a single-dict `--output-format json` envelope carries none.
    if stop_reason == ANTHROPIC_STOP_REFUSAL:
        raise model_refusal(route="cli", stage=tag or "",
                            category=_refusal_category_of(stdout))


def _raise_if_refused_exit(stdout: str, *, tag: str | None) -> None:
    """Bank and raise the typed refusal when a non-zero exit's envelope reports one."""
    # Limitation: assumes a refused non-zero exit still emits a "refusal" envelope; otherwise
    # this returns and the caller reports the exit as before.
    try:
        env_res = _parse_envelope(stdout)
    except Exception:  # best-effort: the caller reports the exit
        return
    if env_res.stop_reason != ANTHROPIC_STOP_REFUSAL:
        return
    _note_unparsed_cache_keys(env_res.usage)
    TOKENS.add(env_res.usage, usd=env_res.usd, turns=env_res.turns)
    _raise_if_refused(env_res.stop_reason, tag=tag, stdout=stdout)


def _assistant_text(events: list) -> str:
    """Every assistant text block in a list envelope, in order, concatenated."""
    parts: list[str] = []
    for evt in events:
        if not isinstance(evt, dict) or evt.get("type") != "assistant":
            continue
        for blk in (evt.get("message", {}) or {}).get("content", []) or []:
            if isinstance(blk, dict) and blk.get("type") == "text":
                parts.append(blk.get("text", ""))
    return "".join(parts)


def _stitch_continuation(events: list, result_text: str, *,
                         turns: int | None, tag: str | None) -> str:
    """Rebuild a prompt-mode reply the CLI split across turns, or return it unchanged."""
    # TRAP (2.1.270): `result` holds only the LAST turn of a split reply; PROMPT-MODE ONLY
    if not turns or turns <= 1:
        return result_text
    stitched = _assistant_text(events).strip()
    body = result_text.strip()
    if not stitched or not body or stitched == body or not stitched.endswith(body):
        # Not a recognisable continuation tail — leave the CLI's own answer alone.
        return result_text
    COUNTERS.bump(CLI_CONTINUED_REPLIES_COUNTER)
    log.warning(Event.CLI_REPLY_SPLIT_ACROSS_TURNS, turns=turns, tag=tag or None,
                result_chars=len(body), stream_chars=len(stitched))
    return stitched


def _parse_envelope(stdout: str, *, stitch_continuations: bool = False,
                    tag: str | None = None) -> EnvelopeResult:
    """Parse `claude -p --output-format json` envelope (dict or list) into (result_text, usage)."""
    env = _decode_stream(stdout)
    if env is None:
        return EnvelopeResult(stdout.strip(), None)

    if isinstance(env, list):
        result_evt = next((e for e in reversed(env)
                           if isinstance(e, dict) and e.get("type") == "result"),
                          None)
        if result_evt:
            _check_guardrail(result_evt)
        usage = (result_evt or {}).get("usage")
        text = _structured_text(result_evt) or (result_evt or {}).get("result")
        if not isinstance(text, str) or not text.strip():
            last_asst = next(
                (e for e in reversed(env)
                 if isinstance(e, dict) and e.get("type") == "assistant"),
                None,
            )
            parts = [
                blk.get("text", "")
                for blk in ((last_asst or {}).get("message", {}) or {}).get("content", []) or []
                if isinstance(blk, dict) and blk.get("type") == "text"
            ]
            # No assistant text either: return "" (not the raw envelope) for a clean degrade.
            text = "".join(parts)
        turns, usd = _spend_of(result_evt)
        stop_reason, model_usage = _telemetry_of(result_evt)
        text = text.strip()
        if stitch_continuations:
            text = _stitch_continuation(env, text, turns=turns, tag=tag)
        return EnvelopeResult(
            text, cast("TokenUsage", usage) if isinstance(usage, dict) else None,
            turns, usd, stop_reason, model_usage,
        )

    if not isinstance(env, dict):
        return EnvelopeResult(stdout.strip(), None)
    _check_guardrail(env)
    result = _structured_text(env) or env.get("result")
    if not isinstance(result, str):
        # Valid JSON envelope but no string result → empty, not the raw envelope.
        result = ""
    raw_usage = env.get("usage")
    turns, usd = _spend_of(env)
    stop_reason, model_usage = _telemetry_of(env)
    # No stitching on the single-dict shape: no per-turn events to stitch from, so never faked
    return EnvelopeResult(
        result.strip(), cast("TokenUsage", raw_usage) if isinstance(raw_usage, dict) else None,
        turns, usd, stop_reason, model_usage,
    )


_PARSED_USAGE_CACHE_KEYS = _cache.ANTHROPIC_PARSED_CACHE_KEYS


def _note_unparsed_cache_keys(usage: dict | None) -> None:
    """Flag cache accounting the envelope reports under key names this module does not parse."""
    _cache.note_unparsed_cache_keys(usage, via="cli")




def parse_json_response(text: str) -> dict | list:
    """Extract the actual JSON content from a `--output-format json` wrapped response."""
    try:
        envelope = json.loads(text)
        if isinstance(envelope, dict) and "result" in envelope:
            content = envelope["result"]
            if isinstance(content, str):
                return json.loads(content)
            return content
        return envelope
    except (json.JSONDecodeError, TypeError):
        pass

    return extract_json(text)
