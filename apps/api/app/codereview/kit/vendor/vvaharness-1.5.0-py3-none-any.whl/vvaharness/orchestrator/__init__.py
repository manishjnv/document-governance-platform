# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


from __future__ import annotations

"""Agentic SAST — profile-controlled S0 static seeding plus an S1-S11 workflow (detection, remediation, then validation), run via ``vvaharness scan --repo <path>``."""
import shutil as shutil  # re-exported: patched by tests via orchestrator.shutil

from vvaharness.orchestrator.batch import run_batch as run_batch
from vvaharness.orchestrator.checkpoints import (
    load_ckpt as load_ckpt,
)
from vvaharness.orchestrator.checkpoints import (
    run_id_for as run_id_for,
)
from vvaharness.orchestrator.checkpoints import (
    save_ckpt as save_ckpt,
)
from vvaharness.orchestrator.config_paths import (
    _default_config as _default_config,
)
from vvaharness.orchestrator.config_paths import (
    trusted_config as trusted_config,
)
from vvaharness.orchestrator.entry import main as main
from vvaharness.orchestrator.preflight import (
    _mask as _mask,
)
from vvaharness.orchestrator.preflight import (
    _reachable_despite_token_cap as _reachable_despite_token_cap,
)
from vvaharness.orchestrator.preflight import (
    _reachable_despite_truncated_reply as _reachable_despite_truncated_reply,
)
from vvaharness.orchestrator.preflight import (
    check_backends as check_backends,
)
from vvaharness.orchestrator.preflight import (
    configure_backends as configure_backends,
)
from vvaharness.orchestrator.preflight import (
    probe_backends as probe_backends,
)
from vvaharness.orchestrator.scan import scan_repo as scan_repo
