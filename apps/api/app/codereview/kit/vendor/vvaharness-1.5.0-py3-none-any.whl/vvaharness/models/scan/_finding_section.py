# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""One finding's Markdown section, and the two entry points that call it."""
from __future__ import annotations

import logging

from vvaharness.models.scan._render import (
    _code_span,
    _confidence_label,
    _demote_md_headings,
    _md_cell,
    _one_line,
    _render_repro_block,
    _snippet_fence,
    _vector_span,
)
from vvaharness.models.scan.findings import RankedFinding
from vvaharness.models.vocab import OFFENSIVE_LABELS

log = logging.getLogger(__name__)


log = logging.getLogger(__name__)

# Reader labels only, wire ev_status unchanged; EV is positive-only, so CONFIRMED is its one verdict
_EV_VERDICT_LABEL = {
    "CONFIRMED": "CONFIRMED (beta)",
    "NOT_CONFIRMED": "NOT CONFIRMED (beta)",
    "INCONCLUSIVE": "REQUIRES REVIEW (beta)",
    "NOT_TESTED": "SAST-ONLY (beta; not live-testable)",
}
# Names the `Why:` source: a routing fact and a model's reading read alike but are not equal
_EV_REASON_TAG = {
    "rule": "[rule] ",
    "triage": "[triage] ",
    "judge": "[judge] ",
}
# Restated on every non-confirmed block: the block is where the misreading happens.
_EV_NOT_A_FP_NOTE = ("_Not a false positive: exploit verification only ever adds a live "
                     "confirmation. This finding's verdict comes from static "
                     "verification._")
# The same point beside the run-level tally.
_EV_POSITIVE_ONLY_NOTE = ("Exploit verification is additive and positive-only: a finding "
                          "it did not confirm live is not a false positive — the static "
                          "verifier owns that verdict.")


def finding_section_lines(i: int, rf: RankedFinding) -> list[str]:
    """The Markdown lines of one finding's report section (1-based index *i*)."""
    return [line for line, _ in _finding_section(i, rf)]


def finding_description_lines(i: int, rf: RankedFinding) -> list[str]:
    """The section lines tagged for the SARIF ``description`` property."""
    return [line for line, keep in _finding_section(i, rf) if keep]


def _finding_section(i: int, rf: RankedFinding) -> list[tuple[str, bool]]:
    """One finding's rendered section as ``(line, in_sarif_description)`` pairs."""
    f = rf.finding
    if f.cvss_score is not None:
        # A FALSE_POSITIVE means the score was computed against a rejected claim, so it misleads
        _score = ("(scored against the claim, verdict FALSE_POSITIVE)"
                  if f.verdict == "FALSE_POSITIVE"
                  else f"**{f.cvss_score:.1f}**")
        cvss = f"{_score} ({f.cvss_rating}) — {_vector_span(f.cvss_vector)}"
    elif f.cvss_vector:
        cvss = _vector_span(f.cvss_vector)
    else:
        cvss = "_not computed_"
    from vvaharness.report.cwe import cwe_for, cwe_name
    _cwe = cwe_for(f.cwe, f.vuln_class)
    _nm = cwe_name(_cwe) if _cwe else ""
    _cwe_label = (f"{_cwe}: {_nm}" if _nm else _cwe) if _cwe else ""
    out = [
        (f"### {i}. [{rf.severity.value.upper()}] {_md_cell(f.title)}", False),
        (f"**Class:** {_cwe_label or f.vuln_class.value}", False),
    ]
    if _cwe:
        _n = _cwe.split('-')[-1]
        out.append(
            (f"**CWE:** {_cwe_label} - "
             f"https://cwe.mitre.org/data/definitions/{_n}.html", False))
    # Repo-controlled path: folding backticks to U+02CB is the only way it cannot close the span
    _file_span = _md_cell(f.file).replace(chr(96), chr(0x2CB))
    # A line_end of 0 renders as a bare start line, never a bogus `path:42-0` range.
    _lines = (f"{f.line_start}-{f.line_end}" if f.line_end
              else f"{f.line_start}")
    out.extend([
        (f"**File:** `{_file_span}:{_lines}`", False),
        # Pinned by tests: only a "_not computed_" CVSS line enters the description.
        (f"**CVSS 3.1:** {cvss}", cvss == "_not computed_"),
    ])
    if f.vsvs_score is not None:
        out.append((f"**VulContextSeverity:** `{f.vsvs_vector}` - "
                    f"**{f.vsvs_score:.1f} ({f.vsvs_rating})**", False))
    if f.offensive_priority:
        out.append((f"**OffensivePriority:** **{f.offensive_priority}** - "
                    f"{OFFENSIVE_LABELS.get(f.offensive_priority, '')} | "
                    f"*{_md_cell(f.offensive_reason)}*", False))
    if f.duplicates:
        # Model-authored paths: fold backticks or one could close the code span.
        refs = ", ".join(
            f"`{_md_cell(d.file).replace(chr(96), chr(0x2CB))}:{d.line_start}"
            + (f"-{d.line_end}`" if d.line_end and d.line_end != d.line_start
               else "`")
            for d in f.duplicates
        )
        out.append((f"**Also at:** {refs}", False))
    out.append(("", True))
    if f.duplicates:
        out.extend([
            ((f"*{len(f.duplicates)} additional call site(s) collapsed "
              f"during dedup — same root cause; each location needs the "
              f"same fix applied.*"), True),
            ("", True),
        ])
    # Model prose: escape angles or GFM acts on an <img>/<script>; findings.json keeps raw bytes
    out.extend([("#### Description", True),
                (_demote_md_headings(f.description, escape_angles=True), True),
                ("", True)])
    if f.impact:
        out.extend([("#### Impact", True),
                    (_demote_md_headings(f.impact, escape_angles=True), True),
                    ("", True)])
    if f.exploit_scenario:
        out.extend([("#### Exploit scenario", True),
                    (_demote_md_headings(f.exploit_scenario,
                                         escape_angles=True), True),
                    ("", True)])
    if f.preconditions:
        out.append(("#### Preconditions", True))
        out.extend((f"- {_md_cell(p)}", True) for p in f.preconditions)
        out.append(("", True))
    # Snippet stays raw, so the fence must outrun any backtick run inside or it forges structure
    _snip_fence = _snippet_fence(f.code_snippet)
    out.extend([
        (_snip_fence, True),
        (f.code_snippet, True),
        (_snip_fence, True),
        ("", True),
    ])
    if f.recommendation:
        out.extend([("#### How to fix", True),
                    (_demote_md_headings(f.recommendation,
                                         escape_angles=True), True),
                    ("", True)])
    # Fold, not demote: a multi-line value spills raw lines below the label
    out.extend([((f"**Exploitability:** "
                  f"{_one_line(rf.exploitability_notes)}"), True), ("", True)])
    if f.verdict:
        out.extend([
            ("#### Adversarial verification", True),
            ((f"**Verdict:** {f.verdict} (confidence: "
              f"{_confidence_label(f.verdict_confidence)}) — "
              f"{_one_line(f.verdict_reason)}"), True),
            ("", True),
        ])
    # Only ev_status None is skipped; "**Exploit Verification:**" is the line MD consumers key on
    if f.ev_status in _EV_VERDICT_LABEL:
        verdict = _EV_VERDICT_LABEL[f.ev_status]
        # Folded to one line: the parsers read a labelled line as a unit.
        reason = _one_line(f.ev_evidence) if f.ev_evidence else ""
        # Pinned by tests: the heading enters the description though its lines are MD-only.
        out.append(("#### Exploit Verification", True))
        # "EV Confidence", not bare "Confidence": a static "**Confidence:**" line already exists
        conf_line = (f"**EV Confidence:** {f.ev_confidence_score}/10"
                     if f.ev_confidence_score is not None else None)
        if f.ev_status == "CONFIRMED":
            # A confirmation's evidence is the proof, so it rides the verdict line.
            out.extend([
                (f"**Exploit Verification:** {verdict}"
                 + (f" — {reason}" if reason else ""), False),
                ("", True),
            ])
            if conf_line:
                out.extend([(conf_line, False), ("", True)])
        else:
            # Non-confirming: the reason is the whole message, so it gets its own labelled line
            out.extend([(f"**Exploit Verification:** {verdict}", False),
                        ("", True)])
            if conf_line:
                out.extend([(conf_line, False), ("", True)])
            if reason:
                out.extend([
                    (f"**Why:** "
                     f"{_EV_REASON_TAG.get(f.ev_reason_source, '')}{reason}",
                     False),
                    ("", True),
                ])
            out.extend([(_EV_NOT_A_FP_NOTE, False), ("", True)])
        # Method/CVSS/repro describe HOW it confirmed, so only CONFIRMED carries them
        if f.ev_status == "CONFIRMED":
            if f.ev_method or f.ev_confidence:
                out.extend([
                    ((f"**EV Method:** {f.ev_method or 'deterministic-backed'} "
                      f"({f.ev_confidence or 'medium'})"), False),
                    ("", True),
                ])
            if f.ev_cvss_score is not None:
                  # Advisory only: static cvss_score owns ranking, hence the "EV CVSS" label
                out.extend([
                    (f"**EV CVSS:** {f.ev_cvss_score}"
                     + (f" ({f.ev_cvss_rating})" if f.ev_cvss_rating else "")
                     + (f" {_vector_span(f.ev_cvss_vector)}"
                        if f.ev_cvss_vector else ""),
                     False),
                    ("", True),
                ])
            if f.ev_repro:
                  # _code_span, not a bare pair: a backtick closes the span, a fold corrupts it
                out.extend([(f"**Repro:** {_code_span(f.ev_repro)}", False),
                            ("", True)])
            if f.ev_repro_detail:
                  # Verbatim output: only blank lines OUTSIDE <details> enter the SARIF description
                in_details = False
                for ln in _render_repro_block(f.ev_repro_detail):
                    if ln.startswith("<details>"):
                        in_details = True
                    out.append((ln, ln == "" and not in_details))
                    if ln == "</details>":
                        in_details = False
    return out
