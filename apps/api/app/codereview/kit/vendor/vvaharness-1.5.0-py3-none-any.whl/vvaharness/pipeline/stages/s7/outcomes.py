# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 7's output contract: one duplicate ruling per finding, and the parse that fails open."""
from __future__ import annotations

from pydantic import BaseModel, Field, field_validator

from vvaharness.models.scan._coerce import flag as _coerce_bool
from vvaharness.report.redact import redact
from vvaharness.util import errlog as _errlog
from vvaharness.util import logs
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event
from vvaharness.util.json_extract import extract_json

log = logs.get_logger(__name__)


class DedupDecision(BaseModel):
    index: int = Field(description="Echo the FINDING index you were given, verbatim.")
    duplicate_of: int = Field(description=
        "The index of the finding this one duplicates — always LOWER than `index`, because the "
        "lowest index of a group is always the canonical one. Use -1 when this finding is not a "
        "duplicate of anything, which is the common answer.")
    reasoning: str = Field(description=
        "One sentence. For a duplicate, name the single fix that closes both; for a non-duplicate, "
        "name the fix this one needs that no other finding's fix covers.")
    # An absent flag defaults False, the fail-safe (discard the member's site).
    independent_sites: bool = Field(default=False, description=
        "For a duplicate: true when each finding in the group is an independently fixable defect "
        "at its own dangerous operation — fixing one site would not fix the others, so the "
        "member's location must survive on the survivor as an extra call site. False when one "
        "root-cause or control fix covers every member. Always false on a non-duplicate.")

    @field_validator("independent_sites", mode="before")
    @classmethod
    def _coerce_flag(cls, v: object) -> bool:
        """Coerces any non-bool flag to a bool so one bad value costs this field, not the whole model."""
        return _coerce_bool(v)


class DedupDecisions(BaseModel):
    decisions: list[DedupDecision] = Field(description=
        "ONE entry per FINDING index you were given, in ascending order. An index you omit is kept "
        "as its own separate finding — safe, but it means nobody ruled on it, so judge every one.")


def _decisions(raw: str) -> DedupDecisions | None:
    """The reply as decisions, tolerating JSON wrapped in prose."""
    try:
        return DedupDecisions.model_validate_json(raw)
    except ValueError:
        pass
    try:
        return DedupDecisions.model_validate(extract_json(raw))
    except ValueError:
        return None


def parse_decisions(raw: str, n: int,
                        label: str = "s7-dedup") -> list[tuple[int, int, str, bool]]:
    """The (idx, canonical, reasoning, independent_sites) rows with 0 <= canonical < idx < n."""
    parsed = _decisions(raw)
    if parsed is None:
        if raw.strip():
            # [] keeps every finding; the counter stops that miss reading as "no duplicates".
            COUNTERS.bump("s7_dedup_parse_miss")
            # redact() BEFORE the [:500] cut, or slicing bisects a credential past every pattern
            head = redact(raw)[:500].replace("\n", "\\n")
            log.warning(Event.S7_DEDUP_UNPARSEABLE, stage=label, findings=n, raw_head=head)
            _errlog.log(label, "semantic-parse",
                        f"reply did not parse as dedup decisions (n={n})", raw_head=head)
        return []
    out: list[tuple[int, int, str, bool]] = []
    for d in parsed.decisions:
        if 0 <= d.duplicate_of < d.index < n:
            out.append((d.index, d.duplicate_of, d.reasoning.strip(),
                        d.independent_sites))
    absent = n - len(parsed.decisions)
    if absent > 0:
        COUNTERS.bump("s7_dedup_index_omitted", absent)
    return out
