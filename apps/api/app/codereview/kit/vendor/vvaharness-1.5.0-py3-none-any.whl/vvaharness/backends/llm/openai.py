# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""OpenAI backend; third `via:` option alongside cli/sdk, same surface, set via config.yaml."""

# Newer models (o-series, gpt-5+) need max_completion_tokens and REJECT temperature.
# Prompt caching rides the provider's IMPLICIT cache, never an explicit breakpoint:
# `prompt_cache_breakpoint` would require switching the user turn to a content-block list, a
# request-shape change a strict gateway can 400 on with no signature to self-heal from.
# TRANSPORT: tool-less calls (prompt()) always speak Chat Completions. agentic() starts there
# too, and stays there, UNTIL a model's own gateway says tools and reasoning_effort conflict on
# Chat Completions — the measured cost of silencing reasoning_effort to 'none' instead (today's
# only Chat-side remedy) is real: it measurably lowers finding recall on affected models. From
# that point on, THAT MODEL's tool turns move natively to the Responses API: same loop, same tools,
# reasoning replayed via encrypted_content under store=False. The one canonical transcript stays
# Chat-shaped throughout; `openai_responses.py`'s pure functions translate it at send time, and
# strip the Responses-only replay keys (`_reasoning_items`, `_item_id`) before any Chat send.
# The move is LEARNED (by gateway wording) or PINNED (`use_responses_api:` on the models entry),
# never guessed from a model name. A model whose gateway supports neither leg at all (the
# measured broken set, or one learned Chat-only after a failed Responses call) stays on Chat
# with reasoning_effort='none' on tool turns, same as before this transport existed.
from __future__ import annotations

import hashlib
import json
import os
import re
import threading
import time
from typing import TYPE_CHECKING, Any, Final, NamedTuple

import openai

from vvaharness.util import logs

if TYPE_CHECKING:
    from collections.abc import Callable

    # Annotation-only: `agentic` never constructs one, it just validates through
    # the class the caller passes.
    from pydantic import BaseModel

from vvaharness.backends.harness.models import (
    AuthenticationError,
    TruncatedResponseError,
    truncated_below_budget,
)
from vvaharness.backends.llm import cache as _cache
from vvaharness.backends.llm import tools as _localtools
from vvaharness.backends.llm.models import (
    AGENTIC_MAX_TOKENS,
    DEFAULT_READ_TOOLS,
    DEFAULT_REQUEST_TIMEOUT_SECONDS,
    EFFORT_REJECTIONS,
    LLM_TRUNCATED_BELOW_BUDGET_COUNTER,
    OPENAI_FINISH_LENGTH,
    RATE_LIMIT_TRANSIENT_RX,
    REASONING_OFF,
    RESPONSE_MODEL_TOOL_NAME,
    RETRYABLE_STATUS,
    SERVER_ERROR_STATUS,
    SERVER_ERROR_TRANSIENT_RX,
    STRUCTURED_PROSE_REASK,
    STRUCTURED_REASK_MAX,
    TRANSPORT_CHAT,
    TRANSPORT_MEMORY,
    TRANSPORT_RESPONSES,
    TRUNCATED_REPLIES_COUNTER,
    TRUNCATED_RETRY_ATTEMPTED_COUNTER,
    TRUNCATED_RETRY_RECOVERED_COUNTER,
    ClockKind,
    OpenAiConfig,
    _tiers_key,
    call_timeout_error,
    classify_effort_rejection,
    effort_after_rejections,
    effort_scaled_seconds,
    is_param_rejection,
    is_responses_shape_rejection,
    jittered_delay,
    model_refusal,
    model_refusal_from,
    next_effort_tier,
    note_budget_use,
    proxy_error,
    rejection_text,
    response_model_tool,
    step_down,
    truncation_retry_max,
    turn_options,
    wait_overrun,
)
from vvaharness.backends.llm.openai_responses import (
    REASONING_ITEMS_KEY,
    from_response,
    to_chat_messages,
    to_responses_request,
)
from vvaharness.backends.llm.tls import (
    coerce_verify,
    scoped_no_proxy_env,
    warn_verify_disabled,
)
from vvaharness.report.redact import redact
from vvaharness.util import console
from vvaharness.util import errlog as _errlog
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event
from vvaharness.util.response_quality import (
    check_response_quality,
    is_timeout_failure,
    output_tokens_for_gate,
    structured_failure_detail,
)
from vvaharness.util.scan_progress import get_active_tracker, is_stage_only
from vvaharness.util.tokens import TOKENS, TokenUsage, estimate_tokens
from vvaharness.util.warn_once import warn_once

log = logs.get_logger(__name__)

# No separate mid-stream transport clause, deliberately: on openai 3.19.2
# `Stream._iter_events` wraps the WHOLE body iteration, re-raising transport errors as
# `openai.APIConnectionError`, so a mid-stream drop already arrives at that arm.
# What that makes load-bearing: the APIConnectionError arm must NOT read an already-streaming
# failure as a terminal VVAH-E002, so `streamed_any` gates the ProxyError classification.

_AUTH_STATUS_RX_OAI = re.compile(
    r"unauthorized|invalid[_ ]api[_ ]key"
    # Bounded, not `.*`: an unanchored wildcard let a 400 reading
    # "invalid_request_error ... prompt is too long: 300000 tokens" match, so an
    # oversized chunk was logged three times as an authentication error and the
    # operator had no way to see the real cause.
    # \btoken\b: `max_tokens`/`completion tokens` cap rejections must not read as auth.
    r"|invalid[^\n]{0,24}\btoken\b|\btoken\b[^\n]{0,24}(?:expired|invalid|revoked)"
    r"|authentication[_ ]failed|incorrect[_ ]api[_ ]key",
    re.IGNORECASE,
)
_AUTH_MAX_RETRIES_OAI = 3
_AUTH_BACKOFF_OAI = (2, 4, 8)

_REDACT_RX = re.compile(r"(sk-[A-Za-z0-9_-]{6})[A-Za-z0-9_-]+")
# Match a human-readable block reason in a corp-proxy/DLP page: `reason=` param, or rsn span.
_PROXY_REASON_RX = re.compile(
    r'(?:class="[^"]*\brsn\b[^"]*">\s*|class="[^"]*\breason\b[^"]*">\s*|reason=)'
    r'([^<&\n]{1,200})', re.I)


def _summarise_status_error(e) -> str:
    """Collapse a proxy/DLP HTML block page into one actionable line."""
    body = ""
    resp = getattr(e, "response", None)
    if resp is not None:
        try:
            body = resp.text
        except Exception:
            body = ""
    body = body or str(getattr(e, "message", "") or e)
    low = body.lower()
    if "dlp" in low or "<html" in low:
        m = _PROXY_REASON_RX.search(body)
        reason = _scrub_secrets(m.group(1).strip() if m else "policy block")
        return (f"blocked by corporate proxy/DLP — {reason}. "
                f"Request an exception or point openai.base_url at an "
                f"internal gateway; ")
    return redact(_scrub_secrets(body))[:300]


# Bearer tokens/api keys/cookies a proxy may reflect back in an error body; redact before logging.
_SECRET_LINE_RX = re.compile(
    r"(?im)^(.*?\b(authorization|api[-_ ]?key|x-api-key|cookie|set-cookie|"
    r"token|secret|bearer)\b\s*[:=]\s*).+$")
_BEARER_RX = re.compile(r"(?i)\b(bearer\s+)[A-Za-z0-9._\-]+")


def _scrub_secrets(text: str) -> str:
    if not text:
        return text
    text = _REDACT_RX.sub(r"\1***", text)          # sk-XXXXXX… → sk-XXXXXX***
    text = _BEARER_RX.sub(r"\1***", text)          # Bearer <tok> → Bearer ***
    text = _SECRET_LINE_RX.sub(r"\1***", text)     # Header: <val> → Header: ***
    return text


def _cause_chain(e: Exception) -> str:
    parts, c = [], e.__cause__
    while c is not None:
        parts.append(f"{type(c).__name__}: {c}")
        c = c.__cause__
    detail = " <- ".join(parts) or "no underlying cause reported"
    return _REDACT_RX.sub(r"\1***", detail)


def _payload_shape(messages: list[dict], error_body: str) -> str:
    """One bounded line describing the request actually sent, appended to a terminal 400 so a vendor message tha..."""
    chars = 0
    block_types: set[str] = set()
    markers = 0
    for m in messages:
        c = m.get("content")
        if isinstance(c, str):
            block_types.add("text")
            chars += len(c)
            markers += c.count("data:image/")
        elif isinstance(c, list):
            for b in c:
                if isinstance(b, dict):
                    block_types.add(str(b.get("type") or "?"))
                    t = b.get("text")
                    if isinstance(t, str):
                        chars += len(t)
                        markers += t.count("data:image/")
    line = (f"payload sent: {len(messages)} message(s), content block "
            f"types={sorted(block_types) or ['none']}, {chars:,} chars, "
            f"data-URI markers in text={markers}")
    if "image" in error_body.lower() and block_types <= {"text"}:
        line += (" — request was text-only; a data:image;base64 marker inside "
                 "packed source can trip a vision-capability gate on some "
                 "gateways (exclude the carrying file from scope or "
                 "neutralise the marker)")
    return line


# Lazy, thread-safe singleton client (s4 runs in a ThreadPoolExecutor).

_client = None
_client_lock = threading.Lock()
# cache_markers "off" suppresses the `prompt_cache_key` field; this route emits no explicit
# breakpoint (see the module docstring), so there is nothing else for the switch to suppress.
_cfg: OpenAiConfig = {"api_key": None, "base_url": None, "verify_ssl": True,
              "ca_cert": None, "organization": None, "no_proxy": None,
              "cache_markers": "on"}


def configure(*, api_key: str | None = None, base_url: str | None = None,
              verify_ssl: bool | str | None = None,
              ca_cert: str | None = None,
              client_cert: str | tuple | list | None = None,
              organization: str | None = None,
              no_proxy: str | None = None,
              cache_markers: str | None = None) -> None:
    """Called once from the orchestrator before any OpenAI step runs."""
    global _client
    with _client_lock:
        if api_key:
            _cfg["api_key"] = api_key
        if base_url:
            _cfg["base_url"] = base_url
        if verify_ssl is not None:
            _cfg["verify_ssl"] = coerce_verify(verify_ssl)
        if ca_cert:
            _cfg["ca_cert"] = ca_cert
        if client_cert:
            # Accepted only to DIAGNOSE it: this route has no mTLS plumbing, and
            # silently ignoring an operator's client_cert leaves them believing
            # mTLS is active. Mirrors the `via: cli` warning (cli.py:388).
            log.warning("client_cert/mTLS is configured but the "
                  "`via: openai` backend cannot present a client certificate. "
                  "Use a `via: sdk` or `via: deepagents` role for mTLS "
                  "gateways.")
        if organization:
            _cfg["organization"] = organization
        if no_proxy:
            _cfg["no_proxy"] = no_proxy
        if cache_markers is not None:
            _cfg["cache_markers"] = cache_markers
        _client = None


def _get_client():
    global _client
    if _client is not None:
        return _client
    with _client_lock:
        if _client is None:
            # Two retry layers, deliberately (same call as sdk.py's). `max_retries` stays at the
            # library default (2) so the worst case is 3x3=9 sends per call.
            # The wrapper ladder is NOT redundant: it is the only layer that can see a transient a
            # gateway reports INSIDE an HTTP 200 body, which the SDK reads as success. Its flat 60s
            # stays flat because those bodies carry no retry-after to read.
            kw: dict = {"max_retries": 2}
            key = _cfg["api_key"] or os.environ.get("OPENAI_API_KEY")
            if key:
                # Env vars from files often carry a trailing newline; httpx rejects Authorization.
                kw["api_key"] = key.strip()
            # `or`-chain: an empty OPENAI_BASE_URL is falsy, falls back to the default endpoint.
            kw["base_url"] = (_cfg["base_url"]
                              or os.environ.get("OPENAI_BASE_URL")
                              or "https://api.openai.com/v1")
            if _cfg["organization"]:
                kw["organization"] = _cfg["organization"]
            ca = _cfg["ca_cert"]
            if ca and not os.path.exists(ca):
                log.warning(Event.TLS_CA_FALLBACK, path=ca, verify_ssl=_cfg['verify_ssl'])
                ca = None
            verify = ca or _cfg["verify_ssl"]
            if verify is False:
                warn_verify_disabled(kw.get("base_url"), label="openai",
                                     ca_hint="openai.ca_cert")
            # BOTH constructions must stay inside the no_proxy scope: DefaultHttpxClient reads
            # the proxy environment in its OWN __init__ and builds its mounts there, so
            # constructing it outside meant `no_proxy` + `ca_cert`/`verify_ssl: false` got no
            # bypass at all — the case that needs it most.
            with scoped_no_proxy_env(_cfg.get("no_proxy")):
                if verify is not True:
                    kw["http_client"] = openai.DefaultHttpxClient(verify=verify)
                _client = openai.OpenAI(**kw)
    return _client


def _cache_markers_enabled() -> bool:
    """Whether `cache_markers` permits the `prompt_cache_key` field this module sends."""
    return _cache.markers_enabled(_cfg)


# OpenAI's server-side cache engages from 1,024 prompt tokens counted CUMULATIVELY from the start
# of the rendered request, and only byte-identical prefixes hit. Deliberately ONE flat floor, not
# a per-model table like sdk.py's: pre-5.6 the minimum varies by REQUEST settings (tools, schemas,
# effort), which no model table expresses; erring only picks a key bucket, changing no other field.
_CACHE_MIN_PROMPT_TOKENS = 1024

# Ring size for the sub-minimum-prefix branch, now its only user. The provider publishes a per-key
# request-rate ceiling above which entries start missing; 8 buckets keeps a stage pool under it
# even with parallelism raised past the shipped profiles.
_CACHE_KEY_SHARDS = 8

# Same value and rationale as the sdk path, defined once in llm/cache.py.
_CACHE_EST_MARGIN = _cache.CACHE_EST_MARGIN


def _prefix_meets_cache_minimum(text: str | None, *,
                                preceding: str = "") -> bool:
    """Whether a cache prefix ending at `text` is estimated to clear the provider's minimum."""
    # The provider measures its floor against the CUMULATIVE rendered prefix, so callers pass
    # whatever renders ahead of `text` (here, the system message) in `preceding`; each part is
    # rated on its own character mix. An empty `text` is never a cacheable prefix.
    if not text:
        return False
    est = estimate_tokens(preceding or "") + estimate_tokens(text)
    return est * _CACHE_EST_MARGIN >= _CACHE_MIN_PROMPT_TOKENS


def _prompt_cache_key(tag: str | None, model: str,
                      cache_prefix: str | None = None, *,
                      preceding: str = "") -> str:
    """Deterministic routing key for `prompt_cache_key`, so a provider can bias load-balancing toward a server a..."""
    # No credential and no prompt content enters the key: anything content-derived is SHA-256'd
    # first, and `preceding` feeds only the size gate, never the key bytes. Never use `repo_root`
    # (an absolute host path).
    # The key NAMES THE SHARING GROUP and must never be anything coarser — do NOT cross it with
    # the ring to bound volume, which would split the group the digest exists to hold together.
    # `tag.split()[0]` raises IndexError on a whitespace-only tag, in the hottest function here.
    fields = (tag or "").split(None, 1)
    stage = fields[0] if fields else ""
    tracker = get_active_tracker()
    repo_name = (getattr(tracker, "repo_name", "") or "") if tracker else ""
    bucket = ""
    if cache_prefix:
        if _prefix_meets_cache_minimum(cache_prefix, preceding=preceding):
            bucket = hashlib.sha256(
                cache_prefix.encode("utf-8")).hexdigest()[:12]
        else:
            rest = fields[1] if len(fields) > 1 else ""
            shard = int(hashlib.sha256(rest.encode("utf-8")).hexdigest(),
                        16) % _CACHE_KEY_SHARDS
            bucket = f"r{shard}"
    raw = f"{stage}:{repo_name}:{model}:{bucket}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]


# prompt() — single-shot, no tools. Same return contract as cli/sdk.prompt().

#: Chat Completions output-budget parameter names; newer models accept only the second.
_MAX_TOKENS_KEY: Final = "max_tokens"
_MAX_COMPLETION_TOKENS_KEY: Final = "max_completion_tokens"
#: The Responses-leg budget key; a cap rejection there names this, never the two Chat keys above.
_MAX_OUTPUT_TOKENS_KEY: Final = "max_output_tokens"
#: Ceiling on total attempts after bounded extra-send grants (param-drop / truncation retry).
_ATTEMPTS_CEILING: Final = 6
#: Per-turn (and forced-final) transient/connection retries in agentic(); 10/20/30/40s waits.
_AGENTIC_TRANSIENT_RETRIES: Final = 4

_NO_TEMP_MODELS: set[str] = set()
_USE_LEGACY_MAXTOK: set[str] = set()
#: A per-model output cap learned from a gateway's own 400/422 body, once — the
#: self-healing counterpart of `registry.output_cap_of` for a model with no
#: DECLARED `models.<role>.max_tokens`. Consulted the same way
#: `_USE_LEGACY_MAXTOK` is: memoised on first sight, then applied to every
#: later call for that model_id within the process.
_LEARNED_OUTPUT_CAP: dict[str, int] = {}
#: Matches a gateway's cap-rejection body ("reduce max_completion_tokens to 32768").
#: Digits only, 4-7 long: the SDK wraps EVERY BadRequestError as "Error code: {status} - {body}",
#: so the standalone HTTP status is always in the text and a 3-digit match would be read as the
#: cap itself. The caller also requires the match be STRICTLY LESS than the rejected value.
#: Ambiguous (0 or >1 qualifying numbers) means "do not learn".
_CAP_VALUE_RX: Final = re.compile(r"\b(\d{4,7})\b")
#: Strip the SDK's own status-code preamble before scanning, belt-and-braces
#: alongside the 4-digit floor above (a 4-digit HTTP-adjacent number, e.g. a
#: request id right after "Error code: 400 - ", would otherwise still count).
_SDK_ERROR_PREFIX_RX: Final = re.compile(r"^error code:\s*\d+\s*-\s*")


def _learned_cap_from_body(body: str, *, requested: int) -> int | None:
    body = _SDK_ERROR_PREFIX_RX.sub("", body.strip())
    candidates = {int(n) for n in _CAP_VALUE_RX.findall(body)}
    candidates = {n for n in candidates if 0 < n < requested}
    return candidates.pop() if len(candidates) == 1 else None
# Endpoints that rejected the prompt-cache hint, remembered from a 400/422 so the rest of the
# run stops sending it.
_NO_CACHE_KEY_MODELS: set[str] = set()
#: Endpoints that rejected `tool_choice` on the forced-final agentic call. Same
#: remember-and-degrade shape as _NO_JSON_SCHEMA_MODELS below: a gateway that
#: cannot pin a tool still gets the tool advertised.
_NO_TOOL_CHOICE_MODELS: set[str] = set()
#: Endpoints that rejected `reasoning_effort` as a field, same object as EFFORT_REJECTIONS.field
#: so openai and deepagents share one memory.
_NO_REASONING_EFFORT_MODELS: set[str] = EFFORT_REJECTIONS.field


def _reasoning_effort_kw(model: str, effort: str | None, transport: str = TRANSPORT_CHAT, *,
                         with_tools: bool = False) -> dict:
    """``{"reasoning_effort": <tier>}`` for *effort* on *model*, walked past any rejection.

    The tools-off forced-'none' remedy applies on Chat only: a model whose tool turns run on
    Responses never needs it (Responses never conflicts tools with effort), and 'none' must
    never be sent there -- the measured reasoning loss is the whole reason this leg exists.
    """
    # Tools-off wins even over "no effort configured": the preflight probe sends no effort, and
    # a prompt() tier rejection may already have put the model in .field before an agentic call
    # ever sees it. ``None`` yields ``{}`` without importing the mapping, so an effort-less call
    # never pulls in langchain.
    if with_tools and transport == TRANSPORT_CHAT and model in EFFORT_REJECTIONS.tools_off:
        return {"reasoning_effort": REASONING_OFF}
    if effort is None or model in _NO_REASONING_EFFORT_MODELS:
        return {}
    from vvaharness.backends.harness.deepagents.options.model_building import (  # noqa: PLC0415 — lazy: keeps langchain out of a plain openai leg
        _to_openai_reasoning_effort,
    )
    tier = effort_after_rejections(model, _to_openai_reasoning_effort(effort), transport)
    return {} if tier is None else {"reasoning_effort": tier}


def _next_effort_label(nxt: str | None) -> str:
    """``repr(nxt)`` for a warn_once line, or "no field" once the ladder bottoms out."""
    return repr(nxt) if nxt is not None else "no field"

#: Endpoints that rejected Structured Outputs (`response_format` type json_schema),
#: remembered from a 400/422 so the rest of the run goes straight to json_object mode.
_NO_JSON_SCHEMA_MODELS: set[str] = set()
#: Endpoints that rejected `stream_options`, remembered so usage is simply not requested.
_NO_STREAM_OPTIONS_MODELS: set[str] = set()

#: OpenAI ``finish_reason`` for a provider guardrail refusal — distinct from an empty
#: reply, and unhealable, so it raises `ModelRefusal` rather than entering any ladder.
_OPENAI_FINISH_CONTENT_FILTER: Final = "content_filter"


def _raise_if_refusal_rejection(e: openai.APIError, *, tag: str | None) -> None:
    """Raise the typed refusal when *e* is a provider policy block (the gateway's cyber 400)."""
    # Call FIRST in every error arm: any other arm would re-send the flagged content.
    refusal = model_refusal_from(e, route="openai", stage=tag or "")
    if refusal is not None:
        raise refusal from e

#: Param drops already announced, so a strict gateway warns once, not once per call.
_WARNED_DROPS: set[str] = set()


def _warn_max_budget_unenforced(fn: str, max_budget_usd: float | None) -> None:
    """One-time WARN that `max_budget_usd` is accepted but never enforced here."""
    # Same "name the drop" idiom as this module's other param-drop WARNs (reusing their
    # `_WARNED_DROPS` registry): OpenAI's Chat Completions API has no spend-cap parameter, so this
    # route silently ignores it -- only the Claude-side transports (`via: cli`, the Agent SDK,
    # `cli_mcp`) actually enforce it.
    if max_budget_usd is None:
        return
    warn_once(
        _WARNED_DROPS, f"max_budget_usd:{fn}",
        f"WARN [openai]: max_budget_usd={max_budget_usd} is accepted by "
        f"{fn}() but not enforced on this route -- no spend cap is applied "
        f"here; max_turns is the bound that applies instead. Route this "
        f"role via: cli for an enforced budget.")


#: `json_schema.name` must be `[a-zA-Z0-9_-]{1,64}` (openai 3.19.2's JSONSchema TypedDict).
_SCHEMA_NAME_RX = re.compile(r"[^A-Za-z0-9_-]+")


def _strict_ready(node: object) -> bool:
    """Whether a lowered schema meets OpenAI's MECHANICAL strict-mode requirements."""
    # Strict Structured Outputs requires every object to carry ``additionalProperties: false``
    # and list EVERY property in ``required``; a schema missing either is 400'd, not relaxed.
    # pydantic's ``model_json_schema()`` satisfies NEITHER by default, so sending
    # ``strict: true`` unconditionally would 400 on exactly the stages this exists for.
    # Deliberately a PREDICATE, never a transform: making a defaulted field required changes what
    # the model is asked to emit, which is a per-stage DTO decision, not a transport's to take.
    if isinstance(node, list):
        return all(_strict_ready(item) for item in node)
    if not isinstance(node, dict):
        return True
    props = node.get("properties")
    if isinstance(props, dict):
        if node.get("additionalProperties") is not False:
            return False
        if set(props) != set(node.get("required") or ()):
            return False
    return all(_strict_ready(v) for k, v in node.items() if k != "required")


def _response_format_for(json_schema: dict | None, *, model: str,
                         tag: str | None) -> dict:
    """The `response_format` to send, preferring Structured Outputs over json_object mode."""
    if not json_schema or model in _NO_JSON_SCHEMA_MODELS:
        return {"type": "json_object"}
    name = _SCHEMA_NAME_RX.sub("_", (tag or "vvaharness").strip()) or "vvaharness"
    strict = _strict_ready(json_schema)
    if not strict:
        warn_once(
            _WARNED_DROPS, f"non_strict_schema:{name}",
            f"WARN [openai]: {tag or 'this stage'}'s response schema does not meet "
            f"OpenAI strict Structured Outputs requirements (every object needs "
            f"`additionalProperties: false` and every property in `required`), so it "
            f"is sent with strict: false — the model receives the schema but the "
            f"provider does not ENFORCE it, and the stage's own pydantic validation "
            f"remains the guarantee. To get enforcement, give that DTO "
            f"`extra=\"forbid\"` and no defaulted fields, or route the role via: sdk / "
            f"cli / deepagents, which force a schema-typed tool call instead.")
    return {
        "type": "json_schema",
        "json_schema": {"name": name[:64], "schema": json_schema, "strict": strict},
    }


def _is_transient_oai(error: openai.APIStatusError) -> bool:
    """True for a retryable status, or a transient a gateway reported in the message instead."""
    if error.status_code in RETRYABLE_STATUS:
        return True
    # Prose may not PROMOTE an explicit auth status — see sdk._is_transient_sdk for the rule.
    # It bites harder here: _AUTH_STATUS_RX_OAI matches neither "not authorized" nor "forbidden",
    # so a proxy/DLP 403 block page (the shape _summarise_status_error exists to collapse) would
    # otherwise be read as transient off its own "Service Unavailable" text.
    if error.status_code in (401, 403):
        return False
    # `.message` already IS the body ("Error code: {status} - {body}"), so this reads it without
    # the second, guarded `response.text` access that can raise. RATE_LIMIT_TRANSIENT_RX therefore
    # carries no bare `\b429\b`: it would promote any terminal error mentioning `req-429-...`.
    # rejection_text() drops a pydantic echo of the request: a PROMPT naming "rate limit" or
    # "Internal Server Error" (routine in security prompts) must not make a permanent 422 transient.
    body = rejection_text(error)
    return bool(RATE_LIMIT_TRANSIENT_RX.search(body)
                or SERVER_ERROR_TRANSIENT_RX.search(body))


def _auth_failure_oai(error: openai.APIStatusError) -> bool:
    """Whether *error* is an unhealable credential failure (VVAH-E001); echoed request stripped."""
    return bool(error.status_code == 401
                or (_AUTH_STATUS_RX_OAI.search(rejection_text(error))
                    and error.status_code not in RETRYABLE_STATUS))


def _stream_within_deadline(stream: Any, *, deadline: float, stage: str | None,
                            effort: str | None, budget_s: float | None) -> Any:
    """Yield *stream*'s chunks, closing it and raising once the wall-clock *deadline* passes.

    A per-request SDK timeout bounds each individual read, so a trickle of small chunks (each
    arriving well inside that window) can otherwise run past the stage's own wall-clock budget
    forever. This checks the clock between chunks instead of trusting the transport layer to.
    """
    for ev in stream:
        if time.monotonic() >= deadline:
            stream.close()
            raise call_timeout_error(
                stage=stage or "", route="openai", budget_s=budget_s, effort=effort,
                cause_text=f"openai stream exceeded its {budget_s:g}s wall-clock budget")
        yield ev


def prompt(
    user_prompt: str | list[dict],
    *,
    model: str,
    cache_prefix: str | None = None,
    system_prompt: str | None = None,
    max_tokens: int | None = None,
    temperature: float | None = None,
    thinking_budget: int | None = None,   # ignored — OpenAI has no equivalent knob here
    betas: list[str] | None = None,        # ignored
    json_schema: dict | None = None,
    output_format: str = "text",
    cwd: str | None = None,
    max_budget_usd: float | None = None,
    timeout: int | None = None,
    tag: str | None = None,
    # This model's own declared output-token ceiling (models.<role>.max_tokens),
    # when one exists — bounds the one doubled-budget truncation retry below so
    # it cannot exceed a cap the model's provider actually enforces. None (no
    # declared cap) keeps this route's existing behaviour: the retry is
    # unbounded and an oversized request is the provider's own 400 to raise.
    output_cap: int | None = None,
    # Reasoning-effort tier, same A5 mapping as agentic(); None keeps the request as before.
    effort: str | None = None,
) -> str:
    _warn_max_budget_unenforced("prompt", max_budget_usd)
    client = _get_client()
    max_tok = max_tokens or 16000
    if output_cap is not None:
        max_tok = min(max_tok, output_cap)
    learned_cap = _LEARNED_OUTPUT_CAP.get(model)
    if learned_cap is not None:
        max_tok = min(max_tok, learned_cap)

    messages: list[dict] = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    # OpenAI accepts content arrays but not Anthropic's cache_control, so strip it. A
    # caller-marked `cache_prefix` folds back in prefix-first rather than becoming a second block:
    # this route places no explicit breakpoint, so keeping one string leaves a call that omits the
    # parameter byte-identical to today's, with no request-shape change to be 400'd over.
    if isinstance(user_prompt, list):
        user_content: str | list = [
            {k: v for k, v in b.items() if k != "cache_control"}
            for b in user_prompt
            if isinstance(b, dict)
        ]
        if cache_prefix:
            user_content = [{"type": "text", "text": cache_prefix}, *user_content]
    else:
        user_content = (cache_prefix + user_prompt) if cache_prefix else user_prompt
    messages.append({"role": "user", "content": user_content})

    kw: dict = {
        "model": model,
        "messages": messages,
        "stream": True,
    }
    if model not in _NO_STREAM_OPTIONS_MODELS:
        kw["stream_options"] = {"include_usage": True}
    if _cache_markers_enabled() and model not in _NO_CACHE_KEY_MODELS:
        # The system message renders ahead of the user turn, so it counts toward the provider's
        # cumulative minimum — system + shard prefix can clear the floor when neither would alone.
        kw["prompt_cache_key"] = _prompt_cache_key(
            tag, model, cache_prefix=cache_prefix,
            preceding=system_prompt or "")
    # Newer models (gpt-5+, o-series) only accept max_completion_tokens.
    if model in _USE_LEGACY_MAXTOK:
        kw["max_tokens"] = max_tok
    else:
        kw["max_completion_tokens"] = max_tok
    if temperature is not None and model not in _NO_TEMP_MODELS:
        kw["temperature"] = temperature
    if json_schema or output_format == "json":
        # Schema-validated Structured Outputs when the caller supplied a schema, else
        # JSON-object mode so the model can't return prose/arrays (s4's output_format="json").
        kw["response_format"] = _response_format_for(json_schema, model=model, tag=tag)
    kw.update(_reasoning_effort_kw(model, effort))

    # A disabled SESSION ceiling (timeout 0/None, S6-off) must not disable this REQUEST hang-stop,
    # hence `timeout or DEFAULT...` rather than passing a falsy timeout straight through.
    request_timeout = effort_scaled_seconds(
        timeout or DEFAULT_REQUEST_TIMEOUT_SECONDS, effort, kind=ClockKind.REQUEST)

    _up_chars = (
        sum(len(b.get("text", "")) for b in user_prompt if isinstance(b, dict))
        if isinstance(user_prompt, list) else len(user_prompt)
    )
    console.write(f"    [openai] prompt -> {model}{f' [{tag}]' if tag else ''} "
                  f"({_up_chars} chars, max_tokens={max_tok}"
                  f"{f', T={temperature}' if 'temperature' in kw else ''}"
                  f"{', json' if 'response_format' in kw else ''}"
                  f"{f', effort={effort}' if 'reasoning_effort' in kw else ''}"
                  f", timeout={request_timeout:g}s)")

    session_t0 = time.monotonic()
    session_budget = request_timeout

    attempts, retry_wait = 3, 60
    text = None  # guard: three param-drops across attempts left text/usage unbound (NameError).
    usage = None
    auth_attempt = 0
    # VVAH-E005 state: one doubled-budget retry per call, then fail loud.
    trunc_retried = False
    trunc_retry_at = 0
    # `attempts` is read live, so a param-drop on the final try can grant one bounded extra send.
    attempt = 0
    # Set once the first stream event arrives, so the APIConnectionError arm can tell a
    # pre-flight proxy/TLS failure (terminal VVAH-E002) from a drop mid-body (transient).
    streamed_any = False
    # (model, tier) and the original exception while one server-error probe is in flight;
    # None once it is answered (by success or by the raise below).
    server_error_probe = None
    server_error_exc = None
    while attempt < attempts:
        attempt += 1
        try:
            # Reset BEFORE the send, not after: a create() that raises on a later attempt
            # must not inherit the previous attempt's "we were streaming" state.
            streamed_any = False
            _t0 = time.monotonic()
            # Honor the effort-scaled per-request hang-stop, via with_options().
            send = turn_options(session_t0, session_budget, request_timeout)
            req_client = client.with_options(**send)
            stream = req_client.chat.completions.create(**kw)
            parts: list[str] = []
            usage = None
            finish: str | None = None
            refusal: str | None = None
            for ev in _stream_within_deadline(
                    stream, deadline=_t0 + send["timeout"], stage=tag, effort=effort,
                    budget_s=request_timeout):
                streamed_any = True
                if ev.choices:
                    choice = ev.choices[0]
                    delta = choice.delta
                    if delta and delta.content:
                        parts.append(delta.content)
                    # A Structured Outputs / safety refusal streams here, NOT in `content`;
                    # unread it became a bare empty reply and the provider's stated reason
                    # was lost before the VVAH-E003 gate ever saw it.
                    if delta is not None and getattr(delta, "refusal", None):
                        refusal = (refusal or "") + str(delta.refusal)
                    # Terminal chunk carries it; keep the last non-None value.
                    finish = getattr(choice, "finish_reason", None) or finish
                if getattr(ev, "usage", None):
                    usage = ev.usage
            note_budget_use(time.monotonic() - _t0, request_timeout, effort)
            if finish == _OPENAI_FINISH_CONTENT_FILTER:
                # A guardrail declined: the same prompt cannot heal, and s4/s6 already
                # fail this unit fast on the typed refusal instead of burning the ladder.
                _bank_attempt_usage(usage)
                raise model_refusal(route="openai", stage=tag or "",
                                    category=_OPENAI_FINISH_CONTENT_FILTER, detail=refusal or "")
            if refusal and not "".join(parts).strip():
                _bank_attempt_usage(usage)
                raise model_refusal(route="openai", stage=tag or "", category=None,
                                    detail=refusal)
            if finish == OPENAI_FINISH_LENGTH:
                # Budget exhausted (reasoning can consume all of it): one doubled retry, then E005.
                budget_key = (_MAX_TOKENS_KEY if _MAX_TOKENS_KEY in kw
                              else _MAX_COMPLETION_TOKENS_KEY)
                requested_now = kw[budget_key]
                retry_at = (None if trunc_retried
                            else truncation_retry_max(requested_now, cap=output_cap))
                if retry_at is not None:
                    # A final-attempt truncation still gets its retry, capped like param-drops.
                    if attempt == attempts and attempts < _ATTEMPTS_CEILING:
                        attempts += 1
                    if attempt < attempts:
                        trunc_retried, trunc_retry_at = True, retry_at
                        COUNTERS.bump(TRUNCATED_RETRY_ATTEMPTED_COUNTER)
                        log.warning(Event.TRUNCATED_RETRY, route="openai",
                                    finish_reason=OPENAI_FINISH_LENGTH, budget_key=budget_key,
                                    budget=requested_now, retry_at=retry_at)
                        # This attempt's usage is real spend, and the doubled
                        # retry below overwrites `usage` before it is ever
                        # read again -- bank it now or it is lost for good.
                        discarded = _bank_attempt_usage(usage)
                        _errlog.log(
                            tag or "openai", tag or "truncation",
                            f"VVAH-E005 warning: reply truncated at "
                            f"{budget_key}={requested_now}; retrying once at "
                            f"{retry_at}",
                            error_code=TruncatedResponseError.error_code,
                            recovered=True,
                            produced=(discarded.get("output_tokens")
                                      if discarded else None),
                        )
                        kw[budget_key] = retry_at
                        continue
                # Fresh this attempt (never banked above -- either the first
                # attempt with no useful doubling left, or the retried
                # attempt itself still coming back truncated).
                norm = _bank_attempt_usage(usage)
                produced = norm.get("output_tokens") if norm else None
                reasoning_tokens = norm.get("reasoning_tokens") if norm else None
                COUNTERS.bump(TRUNCATED_REPLIES_COUNTER)
                if truncated_below_budget(produced, max_tok):
                    COUNTERS.bump(LLM_TRUNCATED_BELOW_BUDGET_COUNTER)
                raise TruncatedResponseError(
                    "reply still hit the output-token budget after the "
                    "doubled retry" if trunc_retried else
                    "reply hit the output-token budget with no retry budget "
                    "left",
                    stage=tag or "",
                    requested=max_tok,
                    retried=trunc_retry_at,
                    produced=produced,
                    reasoning_tokens=reasoning_tokens,
                )
            if trunc_retried:
                COUNTERS.bump(TRUNCATED_RETRY_RECOVERED_COUNTER)
            if server_error_probe is not None:
                probed_model, probed_sent = server_error_probe
                if learned := EFFORT_REJECTIONS.recovered_twice(server_error_probe):
                    EFFORT_REJECTIONS.tiers.add(server_error_probe)
                COUNTERS.bump("llm_effort_tier_stepped_down_on_server_error")
                warn_once(
                    _WARNED_DROPS, f"server_error_tier:{probed_model}:{probed_sent}:{learned}",
                    f"WARN [openai]: {probed_model} returned a server error at "
                    f"reasoning_effort={probed_sent!r} and succeeded at "
                    f"{kw.get('reasoning_effort')!r}; using {kw.get('reasoning_effort')!r} "
                    f"{'for the rest of this run' if learned else 'for this call'}.")
            text = "".join(parts)
            break
        # 422 is the SDK sibling of 400 for the same param-rejection body; all drops below apply
        except (openai.BadRequestError, openai.UnprocessableEntityError) as e:
            _raise_if_refusal_rejection(e, tag=tag)
            body = rejection_text(e).lower()
            budget_key_now = (_MAX_TOKENS_KEY if _MAX_TOKENS_KEY in kw
                             else _MAX_COMPLETION_TOKENS_KEY)
            if (model not in _LEARNED_OUTPUT_CAP
                    and (_MAX_TOKENS_KEY in body or _MAX_COMPLETION_TOKENS_KEY in body)):
                learned = _learned_cap_from_body(body, requested=kw[budget_key_now])
                if learned is not None:
                    _LEARNED_OUTPUT_CAP[model] = learned
                    warn_once(
                        _WARNED_DROPS, f"learned_cap:{model}",
                        f"WARN [openai]: {model} rejected {budget_key_now}="
                        f"{kw[budget_key_now]} — learned its real output cap "
                        f"({learned}) from the gateway's own error and will "
                        f"use it for the rest of this process. Set "
                        f"models.<role>.max_tokens: {learned} to skip this "
                        f"extra round-trip next time.")
                    kw[budget_key_now] = learned
                    if attempt == attempts and attempts < _ATTEMPTS_CEILING:
                        attempts += 1
                    continue
            if trunc_retried and (_MAX_TOKENS_KEY in body
                                  or _MAX_COMPLETION_TOKENS_KEY in body):
                # This rejection IS the provider's cap: the first send accepted the param name.
                # `usage` here is the FIRST (truncated) attempt's -- this retry
                # never streamed, so it was already banked at that attempt's
                # own truncation-retry branch above; read it for `produced`
                # without banking it a second time.
                stale = _normalised_attempt_usage(usage)
                produced = stale.get("output_tokens") if stale else None
                COUNTERS.bump(TRUNCATED_REPLIES_COUNTER)
                if truncated_below_budget(produced, max_tok):
                    COUNTERS.bump(LLM_TRUNCATED_BELOW_BUDGET_COUNTER)
                raise TruncatedResponseError(
                    f"provider rejected the doubled output budget as over "
                    f"its cap: {redact(_scrub_secrets(str(e)))[:200]}",
                    stage=tag or "",
                    requested=max_tok,
                    retried=trunc_retry_at,
                    produced=produced,
                    reasoning_tokens=(stale.get("reasoning_tokens")
                                      if stale else None),
                ) from e
            # Each param-drop branch must guarantee a subsequent send, or text/usage ends unbound.
            dropped = False
            if "temperature" in body and "temperature" in kw:
                _NO_TEMP_MODELS.add(model)
                console.write(f"    [openai] {model} rejected `temperature` — "
                              f"retrying without it")
                kw.pop("temperature", None)
                dropped = True
            elif "max_completion_tokens" in kw and "max_completion_tokens" in body:
                _USE_LEGACY_MAXTOK.add(model)
                kw["max_tokens"] = kw.pop("max_completion_tokens")
                console.write(f"    [openai] {model} rejected `max_completion_tokens` — "
                              f"retrying with legacy `max_tokens`")
                dropped = True
            elif "max_tokens" in kw and "max_completion_tokens" in body:
                kw["max_completion_tokens"] = kw.pop("max_tokens")
                console.write(f"    [openai] {model} requires `max_completion_tokens` — "
                              f"retrying")
                dropped = True
            elif "prompt_cache_key" in body and "prompt_cache_key" in kw:
                # Sent to every OpenAI-compatible endpoint, and a strict gateway may reject an
                # unrecognised parameter outright — fatal on every call of every scan, for a
                # field that is only ever an optimisation. Remembered per model.
                _NO_CACHE_KEY_MODELS.add(model)
                kw.pop("prompt_cache_key", None)
                console.write(f"    [openai] {model} rejected `prompt_cache_key` — "
                              f"retrying without it")
                dropped = True
            elif ("json_schema" in body
                  and kw.get("response_format", {}).get("type") == "json_schema"):
                # A gateway without Structured Outputs support: fall back to today's
                # json_object mode for the rest of the run rather than failing the call.
                # The schema is then unenforced, which is a DEGRADATION, so say so once.
                _NO_JSON_SCHEMA_MODELS.add(model)
                kw["response_format"] = {"type": "json_object"}
                warn_once(
                    _WARNED_DROPS, f"json_schema:{model}",
                    f"WARN [openai]: {model} rejected `response_format` type "
                    f"json_schema (Structured Outputs) — falling back to "
                    f"json_object mode for the rest of this run. Replies are "
                    f"syntactically valid JSON but NOT schema-validated, so a "
                    f"stage that needs a validated payload depends on its own "
                    f"parser; route that role via: sdk, cli or deepagents for "
                    f"enforced structured output.")
                dropped = True
            elif ("reasoning_effort" in kw
                  and (effort_cls := classify_effort_rejection(e)) is not None):
                # field drops the parameter at once; tier steps down the shared ladder.
                # tools_conflict cannot occur here (prompt() carries no tools).
                sent = kw["reasoning_effort"]
                if effort_cls == "field":
                    EFFORT_REJECTIONS.field.add(model)
                    kw.pop("reasoning_effort", None)
                    COUNTERS.bump("llm_effort_field_dropped")
                    warn_once(
                        _WARNED_DROPS, f"reasoning_effort_field:{model}",
                        f"WARN [openai]: {model} rejected `reasoning_effort` as an "
                        f"unsupported parameter — retrying without it for the rest "
                        f"of this run.")
                else:
                    # Chat transport (prompt() never leaves it): the shared step_down reads the
                    # body's own listed values first, and only falls back to the blunt ladder
                    # when the body names none.
                    nxt = step_down(model, sent, e)
                    if nxt is None:
                        kw.pop("reasoning_effort", None)
                    else:
                        kw["reasoning_effort"] = nxt
                    COUNTERS.bump("llm_effort_tier_stepped_down")
                    warn_once(
                        _WARNED_DROPS, f"reasoning_effort:{model}:{sent}",
                        f"WARN [openai]: {model} rejected reasoning_effort={sent!r} "
                        f"— retrying at {_next_effort_label(nxt)}.")
                dropped = True
            elif "stream_options" in body and "stream_options" in kw:
                # Optimisation-only, exactly like prompt_cache_key: without it no usage
                # arrives on this route, so cost reporting degrades and nothing else does.
                _NO_STREAM_OPTIONS_MODELS.add(model)
                kw.pop("stream_options", None)
                warn_once(
                    _WARNED_DROPS, f"stream_options:{model}",
                    f"WARN [openai]: {model} rejected `stream_options` — retrying "
                    f"without it. Token usage is not reported on streamed calls to "
                    f"this endpoint, so cost figures for this role will read zero.")
                dropped = True
            if dropped:
                # Grant one more send, capped so a server that keeps rejecting can't loop unbounded.
                if attempt == attempts and attempts < _ATTEMPTS_CEILING:
                    attempts += 1
                continue
            if _auth_failure_oai(e):  # credential prose under 400/422: same rule as the status arm
                raise AuthenticationError(redact(str(e))[:400],
                                          status_code=e.status_code, backend="openai") from e
            # Request-shape arms above had first refusal; a transient body earns a bounded resend.
            # Docs define 400/422 as non-retryable (the SDK never retries them); the ChatCompletion
            # validation match in SERVER_ERROR_TRANSIENT_RX is a gateway heuristic bounded by attempts
            if _is_transient_oai(e) and attempt < attempts:
                wait = jittered_delay(retry_wait)
                if overrun := wait_overrun(wait, session_t0, session_budget,
                                           stage=tag or "", route="openai", effort=effort):
                    raise overrun from e
                console.write(f"    [openai] transient {e.status_code} (attempt "
                              f"{attempt}/{attempts}, model={model}); retrying in "
                              f"{wait:.1f}s")
                time.sleep(wait)
                continue
            raise RuntimeError(
                f"OpenAI call failed (status={e.status_code}, model={model}): "
                f"{_summarise_status_error(e)}\n"
                f"  {_payload_shape(messages, str(e))}"
            ) from e
        except openai.APIStatusError as e:
            _raise_if_refusal_rejection(e, tag=tag)
            # VVAH-E001: auth is synchronous, so a few fast retries then halt (not the 60s loop).
            # A RETRYABLE status beats prose, as in sdk.prompt: a 503/429 payload that
            # happens to mention authentication is an outage, and the transient ladder
            # is what rides one out.
            if _auth_failure_oai(e):
                # `attempt < attempts` as well as the auth budget — see sdk.prompt for
                # the full note. Both were 3, so every send went to a `continue` and the
                # raise below could not be reached: a wrong key exhausted the loop and
                # surfaced as the post-loop parameter-drop RuntimeError, with no
                # AuthenticationError and no VVAH-E001 error_code.
                if auth_attempt < _AUTH_MAX_RETRIES_OAI and attempt < attempts:
                    wait = _AUTH_BACKOFF_OAI[min(auth_attempt,
                                                 len(_AUTH_BACKOFF_OAI) - 1)]
                    if overrun := wait_overrun(wait, session_t0, session_budget,
                                               stage=tag or "", route="openai", effort=effort):
                        raise overrun from e
                    console.write(f"    [openai] authentication error "
                                  f"(status={e.status_code}, attempt "
                                  f"{auth_attempt + 1}/{_AUTH_MAX_RETRIES_OAI}); "
                                  f"retrying in {wait}s")
                    time.sleep(wait)
                    auth_attempt += 1
                    continue
                # redact() BEFORE [:400]: truncating first can cut a JWT segment / PEM end
                # marker so the pattern no longer matches and raw credential text survives.
                raise AuthenticationError(redact(str(e))[:400],
                                          status_code=e.status_code,
                                          backend="openai") from e
            if _is_transient_oai(e) and attempt < attempts:
                wait = jittered_delay(retry_wait)
                if overrun := wait_overrun(wait, session_t0, session_budget,
                                           stage=tag or "", route="openai", effort=effort):
                    raise overrun from e
                console.write(f"    [openai] transient {e.status_code} (attempt "
                              f"{attempt}/{attempts}, model={model}); retrying in "
                              f"{wait:.1f}s")
                time.sleep(wait)
                continue
            if server_error_probe is not None:
                # The probe resend also failed: an outage, not a tier problem.
                # Raise the first error, not this one, and record nothing.
                raise RuntimeError(
                    f"OpenAI call failed (status={server_error_exc.status_code}, "
                    f"model={model}): {_summarise_status_error(server_error_exc)}"
                ) from server_error_exc
            sent = kw.get("reasoning_effort")
            # 5xx only (429 is a rate limit, not a server fault); REASONING_OFF has no lower
            # rung; and a resend must actually be possible, or the continue below falls
            # through the loop and the post-loop drop-retry RuntimeError masks this error.
            can_probe = (sent is not None and sent != REASONING_OFF
                        and e.status_code in SERVER_ERROR_STATUS
                        and (attempt < attempts or attempts < _ATTEMPTS_CEILING))
            nxt = next_effort_tier(sent) if can_probe else None
            if nxt is not None and EFFORT_REJECTIONS.probe_once((model, sent)):
                server_error_probe, server_error_exc = (model, sent), e
                kw["reasoning_effort"] = nxt
                if attempt == attempts and attempts < _ATTEMPTS_CEILING:
                    attempts += 1
                continue
            raise RuntimeError(
                f"OpenAI call failed (status={e.status_code}, model={model}): "
                f"{_summarise_status_error(e)}"
            ) from e
        except openai.APIConnectionError as e:
            # The SDK already retried a timeout twice (max_retries=2); the wrapper's 60s-jitter
            # ladder below is for dropped sockets, not deadlines, so a timeout raises immediately.
            if is_timeout_failure(e):
                raise call_timeout_error(
                    stage=tag or "", route="openai", budget_s=request_timeout, effort=effort,
                    cause_text=f"OpenAI request exceeded {request_timeout:g}s") from e
            detail = _cause_chain(e)
            # VVAH-E002: proxy/TLS misconfiguration cannot heal, so don't burn the retry budget —
            # but ONLY when nothing was streamed yet. A drop mid-body arrives here too, and there
            # the handshake and proxy CONNECT both already succeeded, so a TLS/proxy signature in
            # the cause is stale context, not the cause.
            if not streamed_any and (proxy := proxy_error(e, backend="openai")):
                raise proxy from e
            where = "mid-stream" if streamed_any else "connection"
            if attempt < attempts:
                wait = jittered_delay(retry_wait)
                if overrun := wait_overrun(wait, session_t0, session_budget,
                                           stage=tag or "", route="openai", effort=effort):
                    raise overrun from e
                console.write(f"    [openai] {where} error (attempt {attempt}/{attempts}): "
                              f"{detail} — retrying in {wait:.1f}s")
                time.sleep(wait)
                continue
            raise RuntimeError(
                f"OpenAI {where} error after {attempts} attempts "
                f"(model={model}): {e}\n"
                f"  cause: {detail}\n"
                f"  hint: CERTIFICATE_VERIFY_FAILED → set openai.ca_cert in "
                f"config.yaml; 'Illegal header value' → OPENAI_API_KEY has "
                f"trailing whitespace; otherwise check HTTPS_PROXY / "
                f"OPENAI_BASE_URL."
            ) from e
        except openai.APIError as e:
            # After its subclasses: a mid-stream error event raises the base type
            _raise_if_refusal_rejection(e, tag=tag)
            raise

    if text is None:
        # All attempts ended in a param-drop `continue`; fail loudly instead of an opaque NameError.
        raise RuntimeError(
            f"OpenAI call to {model} exhausted all retries without a "
            f"successful response (every attempt hit a parameter-drop retry). "
            f"Final request kwargs keys: {sorted(kw)}."
        )

    if usage is not None:
        u = usage.model_dump() if hasattr(usage, "model_dump") else dict(usage)
        # Raw dict, pre-normalisation: the normalised dict fabricates the parsed names, so key
        # presence there proves nothing.
        _note_unparsed_cache_keys(u)
        norm = _normalise_usage(u)
        TOKENS.add(norm)
        written = norm.get("cache_creation_input_tokens")
        console.write(f"    [openai] usage: in={u.get('prompt_tokens', 0)} "
                      f"(cached={norm['cache_read_input_tokens']}"
                      f"{f', cache_write={written}' if written is not None else ''}) "
                      f"out={u.get('completion_tokens', 0)}")
    else:
        TOKENS.add(None)

    # OpenAI spells it completion_tokens; normalise to the shared gate helper
    # so absent-vs-zero behaves identically to the other three routes.
    out_tokens = output_tokens_for_gate(
        None if usage is None else {"output_tokens": u.get("completion_tokens")})
    check_response_quality(text.strip(), stage=tag or "",
                           output_tokens=out_tokens)
    return text.strip()


# agentic(): function-calling loop over local Read/Glob/Grep (cwd-jailed); Bash is unsupported.

_MAX_TURNS = 25  # default tool-loop cap; override per-role via the step's `max_turns` config.
_AGENTIC_MAX_TOK = AGENTIC_MAX_TOKENS


# The cache-ish usage keys this module parses, in the RAW Chat Completions shape. Sub-dict keys
# are namespaced by _note_unparsed_cache_keys, so the set spells them the same way.
_PARSED_USAGE_CACHE_KEYS = frozenset({
    "prompt_tokens_details.cached_tokens",
    "prompt_tokens_details.cache_write_tokens",
})


def _note_unparsed_cache_keys(u: dict | None) -> None:
    """Flag cache accounting reported under key names this module does not parse."""
    if not isinstance(u, dict):
        return
    flat = dict(u)
    ptd = flat.pop("prompt_tokens_details", None)
    if isinstance(ptd, dict):
        for k, v in ptd.items():
            if isinstance(k, str):
                flat[f"prompt_tokens_details.{k}"] = v
    _cache.report_unparsed_cache_keys(flat, _PARSED_USAGE_CACHE_KEYS,
                                      via="openai", label="openai")


def _normalise_usage(u: dict) -> TokenUsage:
    """Normalise a Chat Completions usage payload to the Anthropic names util/tokens.py aggregates."""
    ptd = u.get("prompt_tokens_details") or {}
    if not isinstance(ptd, dict):
        ptd = {}
    ctd = u.get("completion_tokens_details") or {}
    if not isinstance(ctd, dict):
        ctd = {}
    cached = ptd.get("cached_tokens", 0) or 0
    norm: TokenUsage = {
        "input_tokens": max(0, (u.get("prompt_tokens", 0) or 0) - cached),
        # Deliberately NOT `or 0`: an absent completion count must reach TOKENS.add as None so it
        # lands in the `completion_absent` counter (util/tokens.py coerces to 0 itself, after
        # counting). Coercing here left that counter permanently defeated on this route.
        "output_tokens": u.get("completion_tokens"),
        "cache_read_input_tokens": cached,
    }
    if "cache_write_tokens" in ptd:
        written = ptd.get("cache_write_tokens") or 0
        norm["cache_creation_input_tokens"] = written
        norm["input_tokens"] = max(0, norm["input_tokens"] - written)
    if "reasoning_tokens" in ctd:
        norm["reasoning_tokens"] = ctd.get("reasoning_tokens") or 0
    return norm


def _normalised_attempt_usage(usage) -> TokenUsage | None:
    """The raw stream *usage* object (an SDK type or None) normalised, or None."""
    # Shared by every raise arm in ``prompt()``'s retry loop that needs this attempt's usage —
    # either to bank it (`_bank_attempt_usage`) or to read ``output_tokens``/``reasoning_tokens``
    # for a VVAH-E005 ``produced=`` figure — so the two never read the payload two different ways.
    if usage is None:
        return None
    u = usage.model_dump() if hasattr(usage, "model_dump") else dict(usage)
    _note_unparsed_cache_keys(u)
    return _normalise_usage(u)


def _bank_attempt_usage(usage) -> TokenUsage | None:
    """Record one attempt's usage before a retry or a raise discards it."""
    # Every discarded attempt (param-drop, truncation retry, raise) still spent real provider
    # tokens, so each must be banked here rather than only once after the loop exits. Counts the
    # call even when *usage* is None, matching the success path's contract.
    norm = _normalised_attempt_usage(usage)
    TOKENS.add(norm)
    return norm


def _record_usage(usage) -> None:
    if usage is None:
        TOKENS.add(None)
        return
    u = usage.model_dump() if hasattr(usage, "model_dump") else dict(usage)
    _note_unparsed_cache_keys(u)   # raw dict, before normalisation
    TOKENS.add(_normalise_usage(u))


# Per-tool-result cap in agentic history, so one large Read can't blow the limit. Defined
# once in tools.py now that sdk.agentic and the in-process tool_adapter share it; the
# module-level aliases keep this backend's own references (and its tests) at one name.
_TOOL_RESULT_CAP = _localtools.TOOL_RESULT_CAP
_cap_tool_result = _localtools.cap_tool_result
_CTX_OVERFLOW_RX = re.compile(
    r"context.?length|context length|exceed.*(?:token|limit)|too long", re.I)


def _anthropic_tool_to_openai(t: dict) -> dict:
    """Convert one Anthropic Messages tool schema ({name, description, input_schema}) to the OpenAI function-too..."""
    return {"type": "function",
            "function": {"name": t["name"],
                         "description": t.get("description", ""),
                         "parameters": t.get("input_schema") or {"type": "object"}}}


_EVICTED_MARK = "[evicted to fit context]"


def _shrink_history(messages: list[dict]) -> bool:
    """Evict the oldest not-yet-evicted oversized tool result (short stub) to claw back context."""
    for m in messages:
        c = m.get("content")
        if (m.get("role") == "tool" and isinstance(c, str) and len(c) > 1200
                and not c.endswith(_EVICTED_MARK)):
            m["content"] = c[:800] + "\n…" + _EVICTED_MARK
            return True
    return False


def _first_choice(resp, *, model: str, tag: str | None, turn: int):
    """The reply's first choice, raising a diagnosable error when the gateway sent none."""
    choices = getattr(resp, "choices", None) or []
    if not choices:
        raise RuntimeError(
            f"OpenAI returned a reply with no choices (model={model}, turn={turn}"
            + (f", stage={tag}" if tag else "") + ") — the gateway answered 200 with an "
            "empty completion; nothing can be parsed from it.")
    return choices[0]


def _check_terminal_finish(choice, msg, *, send: Callable[[dict], Any], messages: list[dict],
                           call_kw: dict, appended: bool, model: str,
                           tag: str | None, requested: int,
                           response_model: type[BaseModel] | None = None,
                           dispatchable: bool = False,
                           output_cap: int | None = None,
                           effort: str | None = None,
                           request_timeout: float | None = None):
    """Classify a terminal agentic reply's ``finish_reason``, returning ``(choice, msg, override_text)``."""
    finish = getattr(choice, "finish_reason", None)
    refusal = getattr(msg, "refusal", None)
    if finish == _OPENAI_FINISH_CONTENT_FILTER:
        raise model_refusal(route="openai", stage=tag or "",
                            category=_OPENAI_FINISH_CONTENT_FILTER,
                            detail=str(refusal) if refusal else "")
    if finish == OPENAI_FINISH_LENGTH:
        budget_key = (_MAX_TOKENS_KEY if _MAX_TOKENS_KEY in call_kw
                     else _MAX_COMPLETION_TOKENS_KEY)
        retry_at = truncation_retry_max(call_kw[budget_key], cap=output_cap)
        if retry_at is None:
            # Already at (or past) the model's own declared cap — a doubled
            # retry would only repeat the same 400/truncation, so raise
            # loudly now instead of resending with an unusable budget. No
            # errlog record here: the owning caller records the final failure.
            COUNTERS.bump(TRUNCATED_REPLIES_COUNTER)
            raise TruncatedResponseError(
                f"output truncated at {budget_key}={requested} with no "
                f"useful doubling left (model cap {output_cap})",
                stage=tag or "", requested=requested, retried=0)
        COUNTERS.bump(TRUNCATED_RETRY_ATTEMPTED_COUNTER)
        log.warning(Event.TRUNCATED_RETRY, route="openai", finish_reason=OPENAI_FINISH_LENGTH,
                    budget_key=budget_key, budget=requested, retry_at=retry_at)
        _errlog.log(
            tag or "openai", tag or "truncation",
            f"VVAH-E005 warning: agentic reply truncated at "
            f"{budget_key}={requested}; retrying once at {retry_at}",
            error_code=TruncatedResponseError.error_code, recovered=True)
        if appended:
            messages.pop()
        retry_kw = {**call_kw, "model": model, budget_key: retry_at}
        try:
            _t0 = time.monotonic()
            resp = send(retry_kw)
            note_budget_use(time.monotonic() - _t0, request_timeout, effort)
        except (openai.BadRequestError, openai.UnprocessableEntityError) as e:
            _raise_if_refusal_rejection(e, tag=tag)
            body = rejection_text(e).lower()
            if _MAX_TOKENS_KEY in body or _MAX_COMPLETION_TOKENS_KEY in body:
                # Mirrors prompt()'s identical conversion: this rejection IS the
                # provider's own cap, reached by the doubled retry itself
                # (this route is deliberately uncapped — see the docstring).
                COUNTERS.bump(TRUNCATED_REPLIES_COUNTER)
                raise TruncatedResponseError(
                    f"provider rejected the doubled output budget as over "
                    f"its cap: {redact(_scrub_secrets(str(e)))[:200]}",
                    stage=tag or "", requested=requested, retried=retry_at) from e
            if _auth_failure_oai(e):  # credential prose under 400/422: same rule as the status arm
                raise AuthenticationError(redact(str(e))[:400],
                                          status_code=e.status_code, backend="openai") from e
            raise RuntimeError(
                f"OpenAI agentic truncation-retry failed (status={e.status_code}, "
                f"model={model}): {_summarise_status_error(e)}"
            ) from e
        except openai.APIStatusError as e:
            _raise_if_refusal_rejection(e, tag=tag)
            # Same auth-first rule as the primary send: an unhealable
            # credential must surface as VVAH-E001, not a raw SDK exception
            # `orchestrator/batch.py` has no halt rule for.
            if _auth_failure_oai(e):
                raise AuthenticationError(redact(str(e))[:400],
                                          status_code=e.status_code,
                                          backend="openai") from e
            raise RuntimeError(
                f"OpenAI agentic truncation-retry failed (status="
                f"{e.status_code}, model={model}): {_summarise_status_error(e)}"
            ) from e
        except openai.APIConnectionError as e:
            if is_timeout_failure(e):
                raise call_timeout_error(
                    stage=tag or "", route="openai", budget_s=request_timeout, effort=effort,
                    cause_text=f"OpenAI agentic truncation-retry exceeded "
                               f"{request_timeout:g}s") from e
            if proxy := proxy_error(e, backend="openai"):
                raise proxy from e
            raise RuntimeError(
                f"OpenAI agentic truncation-retry connection error "
                f"(model={model}): {e}\n  cause: {_cause_chain(e)}"
            ) from e
        _record_usage(getattr(resp, "usage", None))
        retried_choice = _first_choice(resp, model=model, tag=tag, turn=-1)
        retried_msg = retried_choice.message
        retried_calls = getattr(retried_msg, "tool_calls", None) or []
        if appended:
            messages.append({
                "role": "assistant", "content": retried_msg.content,
                "tool_calls": ([tc.model_dump() for tc in retried_calls]
                              if retried_calls else None),
                REASONING_ITEMS_KEY: getattr(retried_msg, "reasoning_items", None) or [],
            })
        if getattr(retried_choice, "finish_reason", None) == OPENAI_FINISH_LENGTH:
            COUNTERS.bump(TRUNCATED_REPLIES_COUNTER)
            raise TruncatedResponseError(
                "agentic reply still hit the output-token budget after "
                "the doubled retry",
                stage=tag or "", requested=requested, retried=retry_at)
        # `dispatchable` calls (submit included) go to the turn loop; no check belongs here.
        undispatched = retried_calls if not dispatchable else []
        submit = next((tc for tc in undispatched if response_model is not None
                       and tc.function.name == RESPONSE_MODEL_TOOL_NAME), None)
        if undispatched and submit is None:
            # No tool_choice was forcing anything here, so a tool call at the doubled budget IS
            # an anomaly, and this is the forced-final call site with no turn loop left to dispatch
            # it from — fail loudly rather than misread its content as final text.
            raise TruncatedResponseError(
                "agentic reply's doubled-budget retry unexpectedly "
                "requested a tool call; refusing to guess at dispatching "
                "it from the truncation-retry seam",
                stage=tag or "", requested=requested, retried=retry_at)
        COUNTERS.bump(TRUNCATED_RETRY_RECOVERED_COUNTER)
        if submit is None or response_model is None:
            return retried_choice, retried_msg, None
        # The forced call the original (clipped) attempt was making completed on retry — extract
        # it exactly as the main loop's own tool-dispatch already would on a first-try success.
        try:
            args = json.loads(submit.function.arguments or "{}")
            return (retried_choice, retried_msg,
                    response_model.model_validate(args).model_dump_json())
        except Exception:
            # Malformed submit on the retry, with no turn loop left here to re-ask from — defer
            # to the forced-final call site's own fallback, which re-checks
            # retried_msg.tool_calls and falls back to prose on a second validation failure.
            log.warning(Event.RESPONSE_MODEL_RETRY_INVALID, tool=RESPONSE_MODEL_TOOL_NAME)
            return retried_choice, retried_msg, None
    if refusal and not (msg.content or "").strip():
        raise model_refusal(route="openai", stage=tag or "", category=None, detail=str(refusal))
    return choice, msg, None


def _responses_allowed(model: str, override: bool | None) -> bool:
    """Whether *model*'s tool turns may use the Responses API this process.

    A learned Chat-only failure (this call, or an earlier one) vetoes it outright, even under
    an explicit ``use_responses_api: true`` pin: the pin states intent, this is proof it does
    not work, and honouring the pin anyway would let the transport flip back and forth forever.
    """
    if model in TRANSPORT_MEMORY.chat_only:
        return False
    from vvaharness.backends.harness.deepagents.options.model_building import (  # noqa: PLC0415 — lazy: keeps langchain out of a plain Chat-only leg
        resolve_use_responses_api,
    )
    return bool(resolve_use_responses_api(model, None, override))


def _initial_transport(model: str, override: bool | None) -> str:
    """Which transport this call's tool turns start on."""
    if override is True and _responses_allowed(model, override):
        return TRANSPORT_RESPONSES
    if model in EFFORT_REJECTIONS.tools_off and _responses_allowed(model, override):
        return TRANSPORT_RESPONSES
    return TRANSPORT_CHAT


def _turn_client(client: openai.OpenAI, session_t0: float, session_budget: float | None,
                 request_timeout: float) -> openai.OpenAI:
    """*client* re-timed to the smaller of *request_timeout* and the session time left."""
    return client.with_options(**turn_options(session_t0, session_budget, request_timeout))


def _send_turn(client: openai.OpenAI, transport: str, messages: list[dict], kw: dict) -> Any:
    """One send on *transport*; both legs return a reply shaped like a Chat Completions message.

    A completed Responses send marks its model proven and counts the call here, the one place
    every call site sends through, instead of each of them repeating the same two statements.
    """
    if transport == TRANSPORT_CHAT:
        return client.chat.completions.create(messages=to_chat_messages(messages), **kw)
    request = to_responses_request(
        messages, kw, include_encrypted=kw["model"] not in TRANSPORT_MEMORY.no_include)
    resp = from_response(client.responses.create(**request))
    TRANSPORT_MEMORY.responses_proven.add(kw["model"])
    COUNTERS.bump("openai_responses_api_calls")
    return resp


def _learn_chat_only(model: str) -> None:
    """Record *model* as needing Chat Completions for its tool turns, and warn once."""
    TRANSPORT_MEMORY.chat_only.add(model)
    COUNTERS.bump("openai_responses_fallback")
    warn_once(
        _WARNED_DROPS, f"responses_fallback:{model}",
        f"WARN [openai]: {model}'s Responses API call failed with no effort-field "
        f"explanation — falling back to Chat Completions for the rest of this run.")


def _fall_back_to_chat(model: str, base_kw: dict) -> None:
    """Learn *model* Chat-only, forcing 'none' only when Chat is already known to conflict."""
    _learn_chat_only(model)
    if model in EFFORT_REJECTIONS.tools_off:
        base_kw["reasoning_effort"] = REASONING_OFF


def _responses_failure_falls_back(model: str, e: BaseException) -> bool:
    """Whether a non-effort Responses-leg 400/422 should learn Chat-only and fall back now.

    An unproven model falls back on any 400/422 reaching here, having already been filtered
    past the effort and `include` arms: an endpoint that has never completed a Responses turn
    gets no benefit of the doubt. A proven one only on an outright shape rejection, so a one-off
    opaque 400 on an already-working transport does not retire it.
    """
    return is_responses_shape_rejection(e) or model not in TRANSPORT_MEMORY.responses_proven


def _handle_include_rejection(model: str, e: BaseException, *, transport: str) -> bool:
    """True when *e* is the Responses-only ``include`` rejection; records it for the resend."""
    if transport != TRANSPORT_RESPONSES or not is_param_rejection(e, "include"):
        return False
    if model not in TRANSPORT_MEMORY.no_include:
        TRANSPORT_MEMORY.no_include.add(model)
        warn_once(
            _WARNED_DROPS, f"no_include:{model}",
            f"WARN [openai]: {model}'s gateway rejected `include` on the Responses API — "
            f"resending without it (reasoning restarts fresh each tool turn) and staying on "
            f"the Responses API.")
    return True


class _EffortOutcome(NamedTuple):
    """What agentic()'s turn loop does next after an effort-rejection classification."""

    transport: str
    fail: bool = False


def _handle_tools_conflict(model: str, base_kw: dict, override: bool | None) -> _EffortOutcome:
    """The Chat-only tools-conflict remedy: move to Responses when allowed, else force 'none'."""
    EFFORT_REJECTIONS.tools_off.add(model)
    COUNTERS.bump("llm_effort_tools_off")
    if _responses_allowed(model, override):
        warn_once(
            _WARNED_DROPS, f"responses_switch:{model}",
            f"WARN [openai]: {model} rejects reasoning_effort alongside function tools on "
            f"Chat Completions; its tool-carrying calls now move to the Responses API "
            f"(native reasoning kept) for the rest of this run.")
        return _EffortOutcome(TRANSPORT_RESPONSES)
    base_kw["reasoning_effort"] = REASONING_OFF
    warn_once(
        _WARNED_DROPS, f"reasoning_off_tools:{model}",
        f"WARN [openai]: {model} rejects reasoning_effort alongside function tools on Chat "
        f"Completions; tool-carrying calls now send reasoning_effort='none' (no native "
        f"reasoning on agentic turns). Set `use_responses_api: true` on this models entry, "
        f"or route the role via: deepagents, to keep native reasoning.")
    return _EffortOutcome(TRANSPORT_CHAT)


def _handle_tier_rejection(
    model: str, base_kw: dict, e: BaseException, transport: str,
) -> _EffortOutcome:
    """The shared step-down ladder (highest listed value, else the blunt ladder), per transport."""
    sent = base_kw.get("reasoning_effort")
    nxt = step_down(model, sent, e, transport)
    if nxt is None:
        base_kw.pop("reasoning_effort", None)
    else:
        base_kw["reasoning_effort"] = nxt
    COUNTERS.bump("llm_effort_tier_stepped_down")
    warn_once(
        _WARNED_DROPS, f"reasoning_effort:{model}:{transport}:{sent}",
        f"WARN [openai]: {model} rejected reasoning_effort={sent!r} on {transport} — "
        f"retrying at {_next_effort_label(nxt)}.")
    return _EffortOutcome(transport)


def _tools_off_exhausted(model: str, effort_cls: str, sent: str | None, transport: str) -> bool:
    """True once a Chat-side model already forced to 'none' is rejected again.

    Gated on Chat: Responses never conflicts tools with effort, so a model forced to 'none'
    there in the past does not exhaust a later, unrelated Responses-leg rejection.
    """
    return (transport == TRANSPORT_CHAT and model in EFFORT_REJECTIONS.tools_off
            and (effort_cls == "tools_conflict" or sent == REASONING_OFF))


def _handle_field_rejection(model: str, base_kw: dict, transport: str) -> _EffortOutcome:
    """Drop `reasoning_effort` outright for *model* on *transport*; the field itself is rejected."""
    EFFORT_REJECTIONS.field.add(model)
    base_kw.pop("reasoning_effort", None)
    COUNTERS.bump("llm_effort_field_dropped")
    warn_once(
        _WARNED_DROPS, f"reasoning_effort_field:{model}:{transport}",
        f"WARN [openai]: {model} rejected `reasoning_effort` as an unsupported parameter "
        f"on {transport} — retrying without it for the rest of this run.")
    return _EffortOutcome(transport)


def _handle_tier_or_noop(
    model: str, base_kw: dict, e: BaseException, sent: str | None, transport: str,
) -> _EffortOutcome | None:
    """The tier ladder, or None when the call never sent an effort to step down.

    None here means "not actionable": the caller falls through to its other checks (context
    overflow, auth, transient retry) and its own generic fail-fast, exactly as it did before
    this classifier existed -- a tier rejection with nothing sent is not this route's to fix.
    """
    if sent is None:
        return None
    return _handle_tier_rejection(model, base_kw, e, transport)


def _dispatch_effort_class(
    model: str, base_kw: dict, e: BaseException, transport: str, override: bool | None,
) -> _EffortOutcome | None:
    """Route an already-classified, not-yet-exhausted effort rejection to its own handler."""
    effort_cls = classify_effort_rejection(e)
    sent = base_kw.get("reasoning_effort")
    # sent != REASONING_OFF: a tools_conflict with 'none' already sent is not a NEW conflict to
    # move off Chat for -- it falls through to the tier ladder, which steps 'none' back up once.
    if effort_cls == "tools_conflict" and transport == TRANSPORT_CHAT and sent != REASONING_OFF:
        return _handle_tools_conflict(model, base_kw, override)
    if effort_cls == "field":
        return _handle_field_rejection(model, base_kw, transport)
    return _handle_tier_or_noop(model, base_kw, e, sent, transport)


def _handle_effort_rejection(
    model: str, base_kw: dict, e: BaseException, *, transport: str, override: bool | None,
) -> _EffortOutcome | None:
    """Decide the next transport/``base_kw["reasoning_effort"]`` for an effort rejection.

    Mutates *base_kw* for the caller's resend; returns None when *e* is not an effort rejection
    at all, or when it is one this route cannot act on (the caller then falls through to its
    other checks and its own fail-fast). ``fail=True`` means the caller raises its existing
    fail-fast directly: the forced 'none' remedy, or every tier, is already exhausted and no
    further resend can help.
    """
    effort_cls = classify_effort_rejection(e)
    if effort_cls is None:
        return None
    sent = base_kw.get("reasoning_effort")
    if _tools_off_exhausted(model, effort_cls, sent, transport):
        EFFORT_REJECTIONS.tiers.add(_tiers_key(model, REASONING_OFF, transport))
        return _EffortOutcome(transport, fail=True)
    return _dispatch_effort_class(model, base_kw, e, transport, override)


def _run_localtool(name: str, args: dict, *, ok_tools: list[str], cwd: str,
                   tag: str | None) -> str:
    """Execute, cap and log one localtool call, or refuse a name the session never granted."""
    if name not in ok_tools:
        # Same ungranted-tool gate as sdk.agentic
        return _localtools.UNGRANTED_TOOL_ERROR.format(name=name)
    result = _cap_tool_result(_localtools.execute(name, args, cwd=cwd))
    if not is_stage_only():
        console.write(f"      [openai] tool {name}({_localtools.summarize_args(args)}) -> "
                      f"{len(result)} chars{f' [{tag}]' if tag else ''}")
    return result


def agentic(
    user_prompt: str,
    *,
    model: str,
    system_prompt: str | None = None,
    allowed_tools: list[str] | None = None,
    cwd: str,
    max_budget_usd: float | None = None,
    permission_mode: str = "auto",  # accepted for parity; unused
    max_turns: int | None = None,
    # Session clock: the loop raises CallTimeoutError before starting a turn once this many
    # seconds (effort-scaled) have elapsed; a turn already in flight is bound by request_timeout.
    timeout: int | None = None,
    tag: str | None = None,
    # `extra_tools` are Anthropic-shape schemas; `extra_dispatch(name, input)` runs one and
    # returns its string result, or None to DEFER to localtools. A caller tool is the caller's to
    # log and size-cap in its own dispatch; this loop only caps and logs the localtools IT runs.
    extra_tools: list[dict] | None = None,
    extra_dispatch=None,
    # Per-turn output ceiling, defaulting to AGENTIC_MAX_TOKENS (16k). `via: cli`'s agentic leg
    # accepts no such parameter in either shape, so it stays on its own default and the dispatcher
    # warns once instead of silently dropping a configured ceiling.
    max_output_tokens: int | None = None,
    # Structured output for the AGENTIC loop. Without it, 25 of 27 S4 units on gpt-5.5 failed to
    # parse as an InvestigationOutcome, against 0 for the same model on via:deepagents.
    # Published as a TOOL, not a `response_format`, because the loop must keep its read tools
    # usable.
    response_model: type[BaseModel] | None = None,
    # This model's own declared output-token ceiling, when one exists —
    # bounds the doubled truncation retry (see `_check_terminal_finish`).
    # None keeps the pre-existing unbounded-retry behaviour.
    output_cap: int | None = None,
    # Out-of-loop EvidenceGate enforcement: called right after a structured submit VALIDATES,
    # before it is accepted as the final answer. Bounded by the gate's own `max_rejections`, NOT
    # by `STRUCTURED_REASK_MAX`, which bounds schema malformation — a different failure.
    submit_guard: Callable[[], str | None] | None = None,
    # Out-of-loop tool WITHDRAWAL (B4): called at the top of every turn; a returned name
    # is dropped from `base_kw["tools"]` for the remaining turns instead of staying bound
    # so the model can keep spending turns on calls the adapter's budget only refuses.
    # Mirrors `ToolCallBudget.wrap_model_call`'s in-loop withdrawal on `via: deepagents`.
    # `None` keeps every existing caller (none of which passes this) byte-identical.
    exhausted_tools: Callable[[], frozenset[str]] | None = None,
    # Reasoning-effort tier, translated through the same `EffortLevel` vocabulary
    # `via: deepagents` uses, sent as `reasoning_effort`, and dropped + remembered on a 400/422
    # exactly like `prompt_cache_key`.
    effort: str | None = None,
    # The models-entry `use_responses_api` override: True/False pin the transport outright,
    # None (the default for every pre-existing caller) leaves it to the learned tools-conflict
    # trigger — see `_initial_transport`. Tool-less calls never read this; `prompt()` has no
    # such parameter and always stays on Chat Completions.
    use_responses_api: bool | None = None,
) -> str:
    _warn_max_budget_unenforced("agentic", max_budget_usd)
    client = _get_client()
    # Two clocks compose: request_timeout bounds a call already in flight; the session clock
    # below (derived from `timeout`) stops the loop from STARTING a turn past its budget.
    request_timeout = effort_scaled_seconds(
        DEFAULT_REQUEST_TIMEOUT_SECONDS, effort, kind=ClockKind.REQUEST)
    session_budget = (effort_scaled_seconds(timeout, effort, kind=ClockKind.SESSION)
                      if timeout else None)
    session_t0 = time.monotonic()
    transport = _initial_transport(model, use_responses_api)
    turns_cap = int(max_turns) if max_turns else _MAX_TURNS
    out_cap = int(max_output_tokens) if max_output_tokens else _AGENTIC_MAX_TOK
    if output_cap is not None:
        out_cap = min(out_cap, output_cap)
    learned_cap = _LEARNED_OUTPUT_CAP.get(model)
    if learned_cap is not None:
        out_cap = min(out_cap, learned_cap)
    # `None` = unspecified (read-only default); `[]` = the caller wants no localtools. See
    # the same note in backends.llm.sdk.agentic — folding them together makes "none"
    # inexpressible and duplicates the tools of a caller that supplies its own.
    allowed = list(DEFAULT_READ_TOOLS) if allowed_tools is None else list(allowed_tools)
    ok_tools, missing = _localtools.supported(allowed)
    if missing:
        raise NotImplementedError(
            f"via:openai agentic() does not implement tools {missing}. "
            f"Supported: {sorted(ok_tools)}. Keep this role on `via: cli` "
            f"or drop the unsupported tool from allowed_tools."
        )
    tools = [*_localtools.schemas_for(ok_tools),
             *(_anthropic_tool_to_openai(t) for t in (extra_tools or []))]
    advertised = ok_tools + [t.get("name") for t in (extra_tools or [])]
    if response_model is not None:
        tools.append(_anthropic_tool_to_openai(response_model_tool(response_model)))
        advertised = [*advertised, RESPONSE_MODEL_TOOL_NAME]

    messages: list[dict] = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": user_prompt})

    console.write(f"    [openai] agentic -> {model}{f' [{tag}]' if tag else ''} "
                  f"(tools={advertised}, cwd={cwd})")

    base_kw: dict = {"model": model, "tools": tools}
    if model in _USE_LEGACY_MAXTOK:
        base_kw["max_tokens"] = out_cap
    else:
        base_kw["max_completion_tokens"] = out_cap
    # Built ONCE from THIS SESSION's rendered lead and reused unchanged every turn: sibling
    # sessions share only tools+system, so digesting the system prompt alone collapses a whole
    # stage onto the ring. Keying on the growing tail instead would churn the key each turn.
    if _cache_markers_enabled() and model not in _NO_CACHE_KEY_MODELS:
        base_kw["prompt_cache_key"] = _prompt_cache_key(
            tag, model, cache_prefix=(system_prompt or "") + user_prompt,
            preceding=json.dumps(tools, default=str))
    base_kw.update(_reasoning_effort_kw(model, effort, transport, with_tools=True))

    final_text = ""
    tool_calls_total = 0
    # One reminder only, spent when the model answers in prose while a schema is
    # being forced. A second would just burn turns on a model that cannot comply.
    schema_nudged = False
    # Bounds the submit-validation re-ask ladder below independently of the
    # overall turn budget: a model that keeps mis-shaping the same submit
    # must not spend the WHOLE turn budget on retries that keep failing the
    # same way (shared with sdk.py's identical ladder).
    submit_rejects = 0
    # B4: names already dropped from `base_kw["tools"]`, so the withdrawal below only
    # rebuilds the list (and prints) the turn a name is newly exhausted, not every turn.
    withdrawn: frozenset[str] = frozenset()
    for turn in range(1, turns_cap + 1):
        if session_budget and time.monotonic() - session_t0 >= session_budget:
            # The orphaned turn is discarded today anyway: stopping here just stops its billing.
            raise call_timeout_error(
                stage=tag or "", route="openai", budget_s=session_budget, effort=effort,
                cause_text=f"session clock exceeded {session_budget:g}s before turn {turn}")
        if exhausted_tools is not None:
            newly_exhausted = exhausted_tools() - withdrawn
            if newly_exhausted:
                withdrawn |= newly_exhausted
                base_kw["tools"] = [
                    t for t in base_kw["tools"]
                    if t.get("function", {}).get("name") not in withdrawn]
                console.write(f"    [openai] withdrawing exhausted tool(s) "
                              f"{sorted(newly_exhausted)} for the remaining turns"
                              f"{f' [{tag}]' if tag else ''}")
        resp = None
        shrinks = 0
        transients = 0
        # (model, tier) and the original exception while one server-error probe is in
        # flight; None once it is answered (by success or by the raise below).
        server_error_probe = None
        server_error_exc = None
        while resp is None:
            try:
                _t0 = time.monotonic()
                turn_client = _turn_client(client, session_t0, session_budget, request_timeout)
                resp = _send_turn(turn_client, transport, messages, base_kw)
                note_budget_use(time.monotonic() - _t0, request_timeout, effort)
            except (openai.BadRequestError, openai.UnprocessableEntityError) as e:
                _raise_if_refusal_rejection(e, tag=tag)
                low = rejection_text(e).lower()
                agentic_budget_key = (_MAX_TOKENS_KEY if _MAX_TOKENS_KEY in base_kw
                                      else _MAX_COMPLETION_TOKENS_KEY)
                if (model not in _LEARNED_OUTPUT_CAP
                        and (_MAX_TOKENS_KEY in low or _MAX_COMPLETION_TOKENS_KEY in low
                             or _MAX_OUTPUT_TOKENS_KEY in low)):
                    learned = _learned_cap_from_body(
                        low, requested=base_kw[agentic_budget_key])
                    if learned is not None:
                        _LEARNED_OUTPUT_CAP[model] = learned
                        warn_once(
                            _WARNED_DROPS, f"learned_cap:{model}",
                            f"WARN [openai]: {model} rejected "
                            f"{agentic_budget_key}={base_kw[agentic_budget_key]} "
                            f"— learned its real output cap ({learned}) from "
                            f"the gateway's own error and will use it for the "
                            f"rest of this process. Set models.<role>."
                            f"max_tokens: {learned} to skip this extra "
                            f"round-trip next time.")
                        base_kw[agentic_budget_key] = learned
                        continue
                if "max_completion_tokens" in base_kw and "max_completion_tokens" in low:
                    _USE_LEGACY_MAXTOK.add(model)
                    base_kw["max_tokens"] = base_kw.pop("max_completion_tokens")
                    continue
                # Mirrors prompt()'s branch: never fail the loop over an optimisation-only field.
                if "prompt_cache_key" in base_kw and "prompt_cache_key" in low:
                    _NO_CACHE_KEY_MODELS.add(model)
                    base_kw.pop("prompt_cache_key", None)
                    console.write(f"    [openai] {model} rejected `prompt_cache_key` — "
                                  f"retrying without it")
                    continue
                # The shared classifier sorts the rejection into tools-conflict, field or tier;
                # the memory and the ladder are shared with the deepagents client. tools_conflict
                # is tested first: its body also says "not supported", which the field arm below
                # would otherwise swallow as a drop -- and the dropped request is the one that
                # keeps failing.
                effort_outcome = _handle_effort_rejection(
                    model, base_kw, e, transport=transport, override=use_responses_api)
                if effort_outcome is not None:
                    if effort_outcome.fail:
                        # The forced 'none' remedy already failed once (or every tier bottomed
                        # out): re-forcing it would cycle forever. No further resend can help.
                        raise RuntimeError(
                            f"OpenAI agentic call failed (status={e.status_code}, "
                            f"model={model}, turn={turn}): {_summarise_status_error(e)}\n"
                            f"  This model rejects reasoning_effort alongside function "
                            f"tools at every value, including 'none'. Set "
                            f"`use_responses_api: true` on this models entry, or route "
                            f"the role via: deepagents, to keep native reasoning with tools."
                        ) from e
                    transport = effort_outcome.transport
                    continue
                if _handle_include_rejection(model, e, transport=transport):
                    continue
                if (transport == TRANSPORT_RESPONSES
                        and _responses_failure_falls_back(model, e)):
                    _fall_back_to_chat(model, base_kw)
                    transport = TRANSPORT_CHAT
                    continue
                # Context-window overflow: evict the oldest oversized tool result and retry.
                if (_CTX_OVERFLOW_RX.search(low) and shrinks < 16
                        and _shrink_history(messages)):
                    shrinks += 1
                    console.write(f"      [openai] context overflow (turn {turn}); "
                                  f"evicted oldest tool output [{shrinks}], retrying")
                    continue
                if _auth_failure_oai(e):  # credential prose under 400/422, as the status arm
                    raise AuthenticationError(redact(str(e))[:400],
                                              status_code=e.status_code, backend="openai") from e
                # 400/422 are non-retryable per the docs; this is the bounded gateway heuristic (F2)
                if _is_transient_oai(e) and transients < _AGENTIC_TRANSIENT_RETRIES:
                    transients += 1
                    wait = jittered_delay(min(60, 10 * transients))
                    if overrun := wait_overrun(wait, session_t0, session_budget,
                                               stage=tag or "", route="openai", effort=effort):
                        raise overrun from e
                    console.write(f"      [openai] transient {e.status_code} (turn "
                                  f"{turn}, retry {transients}/{_AGENTIC_TRANSIENT_RETRIES}); "
                                  f"waiting {wait:.1f}s")
                    time.sleep(wait)
                    continue
                raise RuntimeError(
                    f"OpenAI agentic call failed (status={e.status_code}, "
                    f"model={model}, turn={turn}): {_summarise_status_error(e)}"
                ) from e
            except openai.APIStatusError as e:
                _raise_if_refusal_rejection(e, tag=tag)
                # Auth FIRST, exactly as prompt() decides it: a mid-scan expired token is
                # unhealable, and this loop's only other option is to burn four transient
                # retries and then raise a generic RuntimeError — losing VVAH-E001, the
                # credential remediation block and the batch halt.
                if _auth_failure_oai(e):
                    raise AuthenticationError(redact(str(e))[:400],
                                              status_code=e.status_code,
                                              backend="openai") from e
                if _is_transient_oai(e) and transients < _AGENTIC_TRANSIENT_RETRIES:
                    transients += 1
                    wait = jittered_delay(min(60, 10 * transients))
                    if overrun := wait_overrun(wait, session_t0, session_budget,
                                               stage=tag or "", route="openai", effort=effort):
                        raise overrun from e
                    console.write(f"      [openai] transient {e.status_code} (turn "
                                  f"{turn}, retry {transients}/{_AGENTIC_TRANSIENT_RETRIES}); "
                                  f"waiting {wait:.1f}s")
                    time.sleep(wait)
                    continue
                if (transport == TRANSPORT_RESPONSES
                        and model not in TRANSPORT_MEMORY.responses_proven):
                    # A persistent 5xx on a transport this model never completed a turn on:
                    # treat it like any other unproven-Responses failure, not a tier problem.
                    _fall_back_to_chat(model, base_kw)
                    transport = TRANSPORT_CHAT
                    continue
                if server_error_probe is not None:
                    # The probe resend also failed: an outage, not a tier problem.
                    # Raise the first error, not this one, and record nothing.
                    raise RuntimeError(
                        f"OpenAI agentic call failed (status="
                        f"{server_error_exc.status_code}, model={model}, turn="
                        f"{turn}): {_summarise_status_error(server_error_exc)}"
                    ) from server_error_exc
                sent = base_kw.get("reasoning_effort")
                # 5xx only (429 is a rate limit, not a server fault); REASONING_OFF has no
                # lower rung to probe.
                can_probe = (sent is not None and sent != REASONING_OFF
                            and e.status_code in SERVER_ERROR_STATUS)
                nxt = next_effort_tier(sent) if can_probe else None
                if nxt is not None and EFFORT_REJECTIONS.probe_once(
                        claimed := _tiers_key(model, sent, transport)):
                    server_error_probe, server_error_exc = (model, sent, claimed), e
                    base_kw["reasoning_effort"] = nxt
                    continue
                raise RuntimeError(
                    f"OpenAI agentic call failed (status={e.status_code}, "
                    f"model={model}, turn={turn}): {_summarise_status_error(e)}"
                ) from e
            except openai.APIConnectionError as e:
                if is_timeout_failure(e):
                    raise call_timeout_error(
                        stage=tag or "", route="openai", budget_s=request_timeout, effort=effort,
                        cause_text=f"OpenAI agentic call exceeded "
                                   f"{request_timeout:g}s (turn={turn})") from e
                if proxy := proxy_error(e, backend="openai"):
                    raise proxy from e
                if transients < _AGENTIC_TRANSIENT_RETRIES:
                    transients += 1
                    wait = jittered_delay(min(60, 10 * transients))
                    if overrun := wait_overrun(wait, session_t0, session_budget,
                                               stage=tag or "", route="openai", effort=effort):
                        raise overrun from e
                    console.write(f"      [openai] agentic connection error (turn {turn}, "
                                  f"retry {transients}/{_AGENTIC_TRANSIENT_RETRIES}); "
                                  f"waiting {wait:.1f}s")
                    time.sleep(wait)
                    continue
                raise RuntimeError(
                    f"OpenAI agentic connection error (model={model}, turn={turn}): "
                    f"{e}\n  cause: {_cause_chain(e)}"
                ) from e

        if server_error_probe is not None:
            probed_model, probed_sent, probed_key = server_error_probe
            if learned := EFFORT_REJECTIONS.recovered_twice(probed_key):
                EFFORT_REJECTIONS.tiers.add(probed_key)
            COUNTERS.bump("llm_effort_tier_stepped_down_on_server_error")
            warn_once(
                _WARNED_DROPS, f"server_error_tier:{probed_model}:{probed_sent}:{learned}",
                f"WARN [openai]: {probed_model} returned a server error at "
                f"reasoning_effort={probed_sent!r} and succeeded at "
                f"{base_kw.get('reasoning_effort')!r}; using {base_kw.get('reasoning_effort')!r} "
                f"{'for the rest of this run' if learned else 'for this session'}.")
        _record_usage(getattr(resp, "usage", None))
        choice = _first_choice(resp, model=model, tag=tag, turn=turn)
        msg = choice.message
        calls = getattr(msg, "tool_calls", None) or []
        finish = getattr(choice, "finish_reason", None)

        assistant = {
            "role": "assistant",
            "content": msg.content,
            "tool_calls": [tc.model_dump() for tc in calls] if calls else None,
            # Stripped before the Chat wire (to_chat_messages); carries Responses replay state
            # only. A native Chat reply has no `.reasoning_items` attribute, so this is `[]`.
            REASONING_ITEMS_KEY: getattr(msg, "reasoning_items", None) or [],
        }
        messages.append(assistant)

        # Must be checked even when `calls` is non-empty: OpenAI reports finish_reason=="length"
        # when generation is cut off MID-tool-call too, leaving `tool_calls` populated with
        # unparseable `arguments` JSON the dispatch loop would silently coerce to `{}` instead of
        # raising VVAH-E005.
        if not calls or finish == OPENAI_FINISH_LENGTH:
            retry_client = _turn_client(client, session_t0, session_budget, request_timeout)

            def _retry_send(kw: dict, *, _tc: openai.OpenAI = retry_client,
                            _tp: str = transport) -> Any:
                return _send_turn(_tc, _tp, messages, kw)

            choice, msg, override = _check_terminal_finish(
                choice, msg, send=_retry_send, messages=messages, call_kw=base_kw,
                appended=True, model=model, tag=tag, requested=out_cap,
                response_model=response_model, dispatchable=True,
                output_cap=output_cap, effort=effort, request_timeout=request_timeout)
            if override is not None:
                console.write(f"    [openai] agentic done in {turn} turn(s), "
                              f"{tool_calls_total} tool call(s), structured reply")
                return override
            # A doubled-budget retry may have landed on a tool call (the
            # clipped attempt was mid-way through one) — recompute `calls`
            # and, if so, fall through to the dispatch loop below exactly as
            # a first-try tool_calls reply would.
            calls = getattr(msg, "tool_calls", None) or []
            if not calls:
                final_text = (msg.content or "").strip()
                # A schema was forced but the model replied in prose. Ask once, by
                # name, before giving up: returning the prose is what used to lose the
                # unit downstream. If it still will not call the tool we return the
                # text anyway, so this is never worse than the old behaviour.
                if response_model is not None and not schema_nudged:
                    schema_nudged = True
                    COUNTERS.bump("llm_structured_prose_reask")
                    log.warning(Event.STRUCTURED_PROSE_REASK, route="openai", model=model,
                                tool=RESPONSE_MODEL_TOOL_NAME)
                    messages.append({"role": "user", "content": STRUCTURED_PROSE_REASK})
                    continue
                console.write(f"    [openai] agentic done in {turn} turn(s), "
                              f"{tool_calls_total} tool call(s)")
                return final_text

        for i, tc in enumerate(calls):
            tool_calls_total += 1
            name = tc.function.name
            try:
                args = json.loads(tc.function.arguments or "{}")
                args_valid = True
            except json.JSONDecodeError:
                # The submit tool keeps `{}`: its validation ladder below re-asks by name.
                args, args_valid = {}, False
                # The gateway rejects a replayed invalid string (function.arguments must be
                # valid JSON): rewrite the bound assistant turn so the retry never resends it.
                assistant["tool_calls"][i]["function"]["arguments"] = "{}"
            if response_model is not None and name == RESPONSE_MODEL_TOOL_NAME:
                # The structured reply IS the final answer, so the loop ends here
                # rather than feeding a tool result back. Validated before
                # returning and re-dumped, so the caller gets canonical JSON for
                # the model it asked for instead of whatever key order or extra
                # keys the model emitted.
                try:
                    validated = response_model.model_validate(args)
                except Exception as exc:
                    # Bounded by STRUCTURED_REASK_MAX independently of the overall turn budget, so
                    # one malformed submit that keeps failing the same way cannot spend the whole
                    # ladder — losing the unit to it is the failure this seam exists to stop.
                    submit_rejects += 1
                    COUNTERS.bump("llm_structured_submit_rejected")
                    if submit_rejects >= STRUCTURED_REASK_MAX:
                        log.warning(Event.STRUCTURED_SUBMIT_REJECTED, route="openai",
                                    tool=RESPONSE_MODEL_TOOL_NAME, error=type(exc).__name__,
                                    rejects=submit_rejects)
                        detail, _ = structured_failure_detail(exc)
                        # recovered=True: raw submit returned; the stage's own parser decides
                        _errlog.log(
                            tag or "openai", tag or "structured",
                            f"{RESPONSE_MODEL_TOOL_NAME} rejected {submit_rejects} time(s); "
                            f"raw submit returned",
                            detail=detail, reason="llm_structured_reask_gave_up", recovered=True)
                        return json.dumps(args)
                    console.write(f"    [openai] {RESPONSE_MODEL_TOOL_NAME} rejected "
                                  f"({type(exc).__name__}) — re-asking")
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": (f"Rejected: {str(exc)[:600]}. Fix the named "
                                    f"fields and call the tool again."),
                    })
                    continue
                if submit_guard is not None:
                    hold_text = submit_guard()
                    if hold_text is not None:
                        console.write(f"    [openai] {RESPONSE_MODEL_TOOL_NAME} accepted but "
                                      f"evidence-gated — re-asking")
                        messages.append({
                            "role": "tool",
                            "tool_call_id": tc.id,
                            "content": hold_text,
                        })
                        continue
                console.write(f"    [openai] agentic done in {turn} turn(s), "
                              f"{tool_calls_total} tool call(s), structured reply")
                return validated.model_dump_json()
            # A caller-supplied tool goes to extra_dispatch (the caller logs + caps it); a
            # localtools name returns None and is executed, capped, and logged by
            # _run_localtool — logging/capping follow whichever layer actually ran the tool.
            # Unparseable arguments run nothing; the error turn lets the model re-issue the call.
            if args_valid:
                result = extra_dispatch(name, args) if extra_dispatch is not None else None
                if result is None:
                    result = _run_localtool(name, args, ok_tools=ok_tools, cwd=cwd, tag=tag)
            else:
                COUNTERS.bump("openai_tool_args_invalid_json")
                # Model-emitted and ungated (any string): redact() BEFORE the cut
                log.warning(Event.TOOL_ARGS_INVALID_JSON, route="openai", tool=redact(name)[:200],
                            tag=tag or None)
                result = "ERROR: tool arguments were not valid JSON"
            messages.append({
                "role": "tool",
                "tool_call_id": tc.id,
                "content": result,
            })

    log.warning(Event.LLM_TURN_CAP_EXHAUSTED, turns_cap=turns_cap, model=model, tag=tag)
    COUNTERS.bump("llm_turn_cap_exhausted")
    # The forced-final call drops `tools` so a tool-happy model cannot spend
    # another turn -- but when a schema is being forced, the submit tool is the
    # ONLY way to answer, so it is kept (alone) and required. Dropping it here
    # would reintroduce the unparseable-prose reply for exactly the runs that
    # exhausted their budget.
    forced_kw: dict = {k: v for k, v in base_kw.items() if k != "tools"}
    forced_kw["model"] = model
    if response_model is not None:
        forced_kw["tools"] = [
            _anthropic_tool_to_openai(response_model_tool(response_model))]
        if model not in _NO_TOOL_CHOICE_MODELS:
            forced_kw["tool_choice"] = {
                "type": "function",
                "function": {"name": RESPONSE_MODEL_TOOL_NAME}}
        instruction = (f"Tool budget exhausted. Call "
                       f"`{RESPONSE_MODEL_TOOL_NAME}` now with what you have "
                       f"established so far; it is the only way to reply.")
    else:
        instruction = ("Tool budget exhausted. Reply now with your final answer "
                       "based on what you have read so far; do not call tools.")
    messages.append({"role": "user", "content": instruction})
    final_transients = 0
    while True:
        try:
            _t0 = time.monotonic()
            final_client = _turn_client(client, session_t0, session_budget, request_timeout)
            resp = _send_turn(final_client, transport, messages, forced_kw)
            note_budget_use(time.monotonic() - _t0, request_timeout, effort)
            break
        except (openai.BadRequestError, openai.UnprocessableEntityError) as e:
            _raise_if_refusal_rejection(e, tag=tag)
            # An endpoint that refuses `tool_choice` must not cost the unit:
            # remember it and retry with the tool merely advertised, mirroring
            # how `prompt()` degrades its structured-output tiers.
            if ("tool_choice" in forced_kw and "tool_choice" in rejection_text(e).lower()):
                _NO_TOOL_CHOICE_MODELS.add(model)
                forced_kw.pop("tool_choice", None)
                console.write(f"    [openai] {model} rejected `tool_choice` on the "
                              f"forced-final call — retrying without it")
                continue
            if _auth_failure_oai(e):  # credential prose under 400/422: same rule as the status arm
                raise AuthenticationError(redact(str(e))[:400],
                                          status_code=e.status_code, backend="openai") from e
            # 400/422 are non-retryable per the docs; this is the bounded gateway heuristic (F2)
            if _is_transient_oai(e) and final_transients < _AGENTIC_TRANSIENT_RETRIES:
                final_transients += 1
                wait = jittered_delay(min(60, 10 * final_transients))
                if overrun := wait_overrun(wait, session_t0, session_budget,
                                           stage=tag or "", route="openai", effort=effort):
                    raise overrun from e
                console.write(f"      [openai] forced-final transient {e.status_code} "
                              f"(retry {final_transients}/{_AGENTIC_TRANSIENT_RETRIES}); "
                              f"waiting {wait:.1f}s")
                time.sleep(wait)
                continue
            raise RuntimeError(
                f"OpenAI agentic forced-final failed (status={e.status_code}, "
                f"model={model}): {_summarise_status_error(e)}"
            ) from e
        except openai.APIStatusError as e:
            _raise_if_refusal_rejection(e, tag=tag)
            if _auth_failure_oai(e):   # auth-first, same rule as the turn loop above
                raise AuthenticationError(redact(str(e))[:400],
                                          status_code=e.status_code,
                                          backend="openai") from e
            if _is_transient_oai(e) and final_transients < _AGENTIC_TRANSIENT_RETRIES:
                final_transients += 1
                wait = jittered_delay(min(60, 10 * final_transients))
                if overrun := wait_overrun(wait, session_t0, session_budget,
                                           stage=tag or "", route="openai", effort=effort):
                    raise overrun from e
                console.write(f"      [openai] forced-final transient {e.status_code} "
                              f"(retry {final_transients}/{_AGENTIC_TRANSIENT_RETRIES}); "
                              f"waiting {wait:.1f}s")
                time.sleep(wait)
                continue
            raise RuntimeError(
                f"OpenAI agentic forced-final failed (status={e.status_code}, "
                f"model={model}): {_summarise_status_error(e)}"
            ) from e
        except openai.APIConnectionError as e:
            if is_timeout_failure(e):
                raise call_timeout_error(
                    stage=tag or "", route="openai", budget_s=request_timeout, effort=effort,
                    cause_text=f"OpenAI agentic forced-final exceeded "
                               f"{request_timeout:g}s") from e
            if proxy := proxy_error(e, backend="openai"):
                raise proxy from e
            if final_transients < _AGENTIC_TRANSIENT_RETRIES:
                final_transients += 1
                wait = jittered_delay(min(60, 10 * final_transients))
                if overrun := wait_overrun(wait, session_t0, session_budget,
                                           stage=tag or "", route="openai", effort=effort):
                    raise overrun from e
                console.write(f"      [openai] forced-final connection error "
                              f"(retry {final_transients}/{_AGENTIC_TRANSIENT_RETRIES}); "
                              f"waiting {wait:.1f}s")
                time.sleep(wait)
                continue
            raise RuntimeError(
                f"OpenAI agentic forced-final connection error (model={model}): "
                f"{e}\n  cause: {_cause_chain(e)}"
            ) from e
    _record_usage(getattr(resp, "usage", None))
    final_choice = _first_choice(resp, model=model, tag=tag, turn=turns_cap)

    def _final_retry_send(kw: dict, *, _tc: openai.OpenAI = final_client,
                          _tp: str = transport) -> Any:
        return _send_turn(_tc, _tp, messages, kw)

    final_choice, final_msg, override = _check_terminal_finish(
        final_choice, final_choice.message, send=_final_retry_send, messages=messages,
        call_kw=forced_kw, appended=False, model=model, tag=tag,
        requested=out_cap, response_model=response_model,
        output_cap=output_cap, effort=effort, request_timeout=request_timeout)
    if override is not None:
        return override
    if response_model is not None:
        for tc in (getattr(final_msg, "tool_calls", None) or []):
            if tc.function.name != RESPONSE_MODEL_TOOL_NAME:
                continue
            try:
                args = json.loads(tc.function.arguments or "{}")
                return response_model.model_validate(args).model_dump_json()
            except Exception as exc:
                # Out of turns and the submit is malformed: fall through to the
                # prose below so the stage's own parser still gets a chance,
                # rather than raising and losing the unit outright.
                log.warning(Event.RESPONSE_MODEL_FORCED_FINAL_INVALID,
                            tool=RESPONSE_MODEL_TOOL_NAME, error=type(exc).__name__)
    return (final_msg.content or "").strip()

