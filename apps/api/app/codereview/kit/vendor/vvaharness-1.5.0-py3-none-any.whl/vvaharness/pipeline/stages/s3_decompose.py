# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Step 3 — builds the risk-ranked TaskManifest deterministically from S2's ThreatModel, one InvestigationUnit per threat."""
from __future__ import annotations

from pathlib import Path

from vvaharness.util import logs

log = logs.get_logger(__name__)

from vvaharness.lang.detect import detect_languages
from vvaharness.models import ContextPackage, InvestigationUnit, TaskManifest, UnitSize
from vvaharness.models.scan.work import threat_unit_id
from vvaharness.util import console

_LOC_KILO = 1_000       # for the "12.3k"-style LOC report formatting
_P90_FRACTION = 0.9

_SMALL_UNIT_LOC_MAX = 2_000
_MEDIUM_UNIT_LOC_MAX = 8_000

_IMPACT_ORDINAL = {"low": 1, "medium": 2, "high": 3, "critical": 4, "existential": 5}
_LIKELIHOOD_ORDINAL = {
    "very_rare": 1, "rare": 2, "possible": 3, "likely": 4, "almost_certain": 5,
}
_DEFAULT_IMPACT_ORDINAL = _IMPACT_ORDINAL["medium"]
_DEFAULT_LIKELIHOOD_ORDINAL = _LIKELIHOOD_ORDINAL["possible"]
_MAX_RISK_SCORE = max(_IMPACT_ORDINAL.values()) * max(_LIKELIHOOD_ORDINAL.values())


def run(ctx: ContextPackage, cfg) -> TaskManifest:
    log.info("s3/decompose: starting task decomposition - threats=%d modules=%d",
             len(ctx.threat_model.threats) if ctx.threat_model else 0, len(ctx.modules))
    manifest = TaskManifest(units=[])

    n_threat = _investigation_units(manifest, ctx)

    repo_root = Path(ctx.repo_root)
    for u in manifest.units:
        u.languages = detect_languages(u.files, repo_root=repo_root)

    manifest.unreachable_files = _coverage_report(manifest, ctx)
    _report_unit_loc(manifest, repo_root)

    tracker = getattr(cfg, "_scan_progress", None)
    if tracker is not None:
        for unit in manifest.units:
            tracker.queued(unit)

    console.write(
        f"  [s3] done: {len(manifest.units)} unit(s) ({n_threat} threat(s)), "
        f"top risk = {manifest.sorted_units()[0].id if manifest.units else 'none'}"
    )
    log.info(
        "s3/decompose: decomposition complete - units=%d (threat=%d)",
        len(manifest.units), n_threat,
    )
    return manifest


def _threat_risk_rank(t) -> int:
    """Returns 1 (most urgent) .. `_MAX_RISK_SCORE` (least) from Threat.impact x Threat.likelihood."""
    score = (_IMPACT_ORDINAL.get(t.impact, _DEFAULT_IMPACT_ORDINAL)
            * _LIKELIHOOD_ORDINAL.get(t.likelihood, _DEFAULT_LIKELIHOOD_ORDINAL))
    return _MAX_RISK_SCORE + 1 - score


def _file_module_index(ctx: ContextPackage) -> dict[str, str]:
    """Returns ``file -> community name`` from `ctx.modules`, a reported annotation that nothing groups or splits files by."""
    file_community: dict[str, str] = {}
    for m in ctx.modules:
        for f in m.files:
            file_community.setdefault(f, m.name)
    return file_community


def _investigation_units(manifest: TaskManifest, ctx: ContextPackage) -> int:
    """Appends one InvestigationUnit per threat, carrying that threat's whole validated surface uncut, and returns how many it added."""
    tm = ctx.threat_model
    if not tm or not tm.threats:
        return 0

    all_files = set(ctx.all_files)
    file_community = _file_module_index(ctx)
    repo_root = Path(ctx.repo_root)
    base_rank = max((u.risk_rank for u in manifest.units), default=0)

    added = 0
    with_surface = 0
    used_ids = {u.id for u in manifest.units}
    for threat_id, t in zip(tm.threat_ids(), tm.threats, strict=True):
        files = [f for f in dict.fromkeys(t.surface_files) if f in all_files]
        if not files:
            manifest.threats_without_unit.append(threat_id)
            console.write(f"    [s3] {threat_id}: no validated surface file — "
                          "never reviewed")
            continue
        with_surface += 1

        cid = threat_unit_id(threat_id)
        if cid in used_ids:
            n = 2
            while f"{cid}-{n}" in used_ids:
                n += 1
            cid = f"{cid}-{n}"
        used_ids.add(cid)

        fset = set(files)
        sinks = [s for s in ctx.unsafe_sinks if s.file in fset]
        loc = sum(_count_loc(repo_root / f) for f in files)

        manifest.units.append(InvestigationUnit(
            id=cid,
            threat=t.threat,
            surface=t.surface,
            actor=t.actor,
            asset=t.asset,
            impact=t.impact,
            likelihood=t.likelihood,
            controls=t.controls,
            evidence=t.evidence,
            file_ids=files,
            sinks=sinks,
            entry_points=[e for e in ctx.entry_points if e.file in fset],
            related_cves=[c.id for c in ctx.known_cves
                         if set(c.affected_files) & fset],
            communities=sorted({file_community.get(f, f"file:{f}") for f in files}),
            cwes=sorted({c for s in sinks for c in s.cwe}),
            risk_rank=base_rank + _threat_risk_rank(t),
            size=_size_for(loc),
        ))
        added += 1

    console.write(f"    [s3] threats: {added} unit(s) from "
                  f"{with_surface}/{len(tm.threats)} threat(s) with a validated "
                  "surface")
    return added


def _size_for(loc: int) -> UnitSize:
    if loc < _SMALL_UNIT_LOC_MAX:
        return UnitSize.SMALL
    if loc < _MEDIUM_UNIT_LOC_MAX:
        return UnitSize.MEDIUM
    return UnitSize.LARGE


def _coverage_report(manifest: TaskManifest, ctx: ContextPackage) -> list[str]:
    """Returns the files named by no unit, also printing that coverage gap to stderr."""
    covered: set[str] = set()
    for u in manifest.units:
        covered.update(u.files)
    unreachable = sorted(set(ctx.all_files) - covered)
    if unreachable:
        console.write(f"    [s3] coverage: {len(unreachable)}/{len(ctx.all_files)} "
                      "file(s) named by no threat's surface — never reviewed")
    # No COUNTERS bump: metrics.build() reads manifest.unreachable_files, which survives --resume
    return unreachable


def _report_unit_loc(manifest: TaskManifest, repo_root: Path) -> None:
    locs = sorted(sum(_count_loc(repo_root / f) for f in u.files)
                  for u in manifest.units)
    if not locs:
        return
    n = len(locs)
    fmt = lambda x: f"{x / _LOC_KILO:.1f}k" if x >= _LOC_KILO else str(x)
    p90 = locs[min(n - 1, int(n * _P90_FRACTION))]
    console.write(f"    [s3] unit LOC: n={n} min={fmt(locs[0])} "
                  f"p50={fmt(locs[n // 2])} p90={fmt(p90)} max={fmt(locs[-1])}")


_LOC_CACHE: dict[str, int] = {}


def _count_loc(p: Path) -> int:
    """Returns the file's line count, memoised on its (always absolute) path string."""
    k = str(p)
    v = _LOC_CACHE.get(k)
    if v is not None:
        return v
    try:
        with p.open("r", encoding="utf-8", errors="replace") as fh:
            v = sum(1 for _ in fh)
    except OSError:
        v = 0
    _LOC_CACHE[k] = v
    return v
