# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 7's prompt: the collapse test, and the finding rows it rules on."""
from __future__ import annotations

import json

from vvaharness.models import Finding

SYSTEM = """You are collapsing overlapping SAST findings that several
independent reviewers raised against the same repository.

DECISION TEST: two findings are the SAME finding when one engineering fix
closes both. If each needs its own code change, they are separate — even if
the bug class and file are identical.

Collapse it — set `duplicate_of` to the LOWER index — when any of these hold:
- Same defect, different label or line — e.g. "OS command exec" at L40 vs
  "shell injection" at L42.
- Both trace back to one shared helper / utility; the call sites differ but
  the fix lives in the helper.
- One global control is absent (auth filter, CSRF token, output encoder) and
  each affected route was filed as its own ticket.
- A cause/effect pair on one flow — "no input validation" filed alongside the
  resulting "SQLi" on the same sink.
- One insecure setting or default surfaces at several read points.
- Same file, lines within ~30 of each other, and the descriptions clearly
  describe one issue from two angles.

Keep it separate — `duplicate_of: -1` — when:
- The fixes land in different functions/files and neither fix covers the
  other.
- Same CWE class repeated independently (e.g. two unrelated string-built SQL
  queries) — each one needs its own patch.
- **The two findings carry different `cwe` values.** Different CWEs mean
  different defects and different fixes, even at the same file and line, and
  even when one control would plausibly touch both (one exception follows). A
  missing CSRF token is not a debug-mode leak; cleartext password storage is
  not an auth bypass. Never collapse across CWE ids. The one exception is
  sibling ids that name ONE weakness — CWE-89/943/564, CWE-78/77,
  CWE-22/23/36, CWE-79/80 and CWE-862/285/284 — which count as the same id;
  every other cross-CWE collapse you propose is refused.

For EVERY decision, also set `independent_sites` per its schema description.
The test: "would fixing one site fix the others?" Yes → false. No — each
site would still be broken after another site's fix → true. It never changes
whether you collapse; it only decides whether the collapsed members'
locations survive on the survivor as extra call sites in the report. On a
`duplicate_of: -1` row set false.

Collapse only what ONE edit fixes. When you are unsure, keep both: a kept
duplicate costs a line in the report, a wrongly collapsed finding is a
deleted vulnerability."""


def build_payload(verified: list[Finding], unresolved: list[int]) -> str:
    """The findings the deterministic pass could not resolve, indexed as the reply must be."""
    payload = [{
        "index": local,
        "file": verified[g].file,
        "line": verified[g].line_start,
        "category": verified[g].vuln_class.value,
        "title": verified[g].title,
        "description": verified[g].description[:500],
        "exploit_scenario": verified[g].exploit_scenario[:300],
        "cwe": verified[g].cwe,
        "source_ref": verified[g].source_ref,
        "sink_ref": verified[g].sink_ref,
    } for local, g in enumerate(unresolved)]
    return "FINDINGS TO DEDUPLICATE:\n" + json.dumps(payload, indent=2)
