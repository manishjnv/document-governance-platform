# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Packaged AI-agent operating instructions.

`vvaharness setup --install-agents` writes these into the files each agent
reads, so an agent driving the tool RUNS it rather than editing it. AGENTS.md
and .github/copilot-instructions.md are always written; CLAUDE.md and the
Claude skill only when a `claude` CLI is on PATH, and GEMINI.md only when
`gemini` is. Existing files are never overwritten. Kept in the package (not
just the repo AGENTS.md) so pip-installed users have it too."""
from __future__ import annotations

# Canonical cross-tool operating manual; leads with the Apache header like the rest of the tree
AGENT_DOC = """\
<!--
Copyright 2026 Visa, Inc.
Licensed under the Apache License, Version 2.0; see http://www.apache.org/licenses/LICENSE-2.0
-->
# Operating vvaharness (for AI coding agents)

`vvaharness` is a **released** CLI security-scanning product. **Operate it,
do not develop or repair it.** It writes a Markdown report and SARIF 2.1.0;
findings are triage candidates, not confirmed vulnerabilities.

## The four rules
1. **Never edit the `vvaharness` package source** to make a scan run. A
   hand-edited tool gives unsupported, non-reproducible results.
2. **Never hand-write config files.** Use a shipped profile via `--config`. The
   one sanctioned exception is a git-ignored `config.local.yaml` overlay.
3. **On any failure, run `vvaharness setup` (or `doctor`), fix the environment
   it points to, and re-run.** Report bugs with `VVAHARNESS_DEBUG=1`; don't
   patch around them.
4. **Scan only code the user is authorized to scan. Never arm exploit
   verification or fix mode unless the user asks.** Exploit verification sends
   live attack traffic; fix mode edits the user's source.

Before you scan: prompts send target source to the configured model provider,
and scans spend real tokens. Run `vvaharness estimate --repo <path>` first (no
spend).

## Run it
```
pipx install .                     # from the vvaharness folder; or: pip install .
vvaharness setup                   # checks Python, keys, gateway, config
vvaharness scan --repo <path> --stop-after s9   # detection only; --application-id <id> is optional
```
- Pick a profile with `--config vvaharness/config/profiles/<name>.yaml`
  (`default`, `sdk`, `full`, `taint`, `semgrep`), then re-run `setup` with it.
  `sdk` uses `ANTHROPIC_SDK_API_KEY` for detection; its S11 needs
  `ANTHROPIC_API_KEY` / `ANTHROPIC_AUTH_TOKEN`, `CLAUDE_CODE_OAUTH_TOKEN` or a
  `claude` login. `full` needs `OPENAI_API_KEY` only when exploit verification
  is armed.
- The packaged default sets `step_remediate.enabled: false` and
  `step_validate.enabled: false`, so a plain scan using it skips S10/S11.
  Other profiles or a local overlay can enable them (`sdk` and `full` do).
  `--remediate` enables S10 only and S10 can **edit target source**. In-scan
  S11 requires `step_validate.enabled: true`; there is no scan `--validate`
  flag. Standalone `remediate` and `validate` remain available when these
  flags are false. Keep `--stop-after s9` to explicitly skip both stages with
  any profile, even with `--remediate`.
- **Exploit verification is Beta — API only.** It sends live HTTP attack
  traffic, including state-changing requests, to a localhost target, and only
  verifies findings that map to an HTTP endpoint. It turns on when
  `EV_API_COLLECTION` names a Postman/OpenAPI/Swagger collection (a stale
  value in `.env` counts), and `--resume` turns it back on for a run that had
  it, even with the variable unset. To send no traffic, unset
  `EV_API_COLLECTION` and start a fresh run without `--resume`.
  `--stop-after ev` parses the collection and probes the target, then stops
  before S0 with no model spend. `vvaharness ev-replay --repo <path>` re-checks
  exploit-verified findings against a redeployed target.
- Behind an Anthropic-compatible gateway (a JWT-shaped `eyJ…` key), set
  `ANTHROPIC_BASE_URL=https://<your-gateway>/`, plus `SSL_CERT_FILE` if the
  gateway uses a private CA. Run `setup` for exact guidance.

## On failure
Read the one-line `✗ scan failed: …`, run `vvaharness doctor`, fix what it
flags (usually a credential or `ANTHROPIC_BASE_URL`), re-run. Full trace:
`VVAHARNESS_DEBUG=1`.
"""

# Claude Code skill: same content plus the frontmatter ~/.claude/skills discovery needs
CLAUDE_SKILL = (
    "---\n"
    "name: vvaharness\n"
    "description: Operate the vvaharness SAST CLI (install, setup, doctor, "
    "scan). Use when asked to scan a repo for vulnerabilities with vvaharness. "
    "Operate the tool; never edit its source or hand-write its config. "
    "Exploit verification is Beta and API-only; do not arm it unless asked.\n"
    "---\n\n"
) + AGENT_DOC


def gemini_doc() -> str:
    return AGENT_DOC.replace("(for AI coding agents)", "(for the Gemini CLI)")
