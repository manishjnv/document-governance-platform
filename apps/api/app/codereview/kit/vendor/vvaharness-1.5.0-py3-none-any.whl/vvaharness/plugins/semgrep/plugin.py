# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""VVAH Semgrep-enhanced: the assembled variant, wired through the plugin seams."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from context_graph_sdk.plugins import GraphEnricher

from vvaharness.plugins.semgrep.enricher import SemgrepEnricher
from vvaharness.plugins.semgrep.tools import SEMGREP_TOOLS
from vvaharness.plugins.semgrep.triage import semgrep_triage_subagent
from vvaharness.sdk.plugins import Contribution, PluginInfo
from vvaharness.util import logs

log = logs.get_logger(__name__)

VERSION = "1"
_MAX_CONFIG_FILES = 32


class SemgrepConfigError(ValueError):
    """Raised when the Semgrep rule files this variant was given cannot be used."""


def _validated_configs(configs: tuple[Path | str, ...]) -> tuple[Path, ...]:
    """Local rule files, resolved; a registry name or URL is rejected rather than fetched."""
    if len(configs) > _MAX_CONFIG_FILES:
        raise SemgrepConfigError(f"at most {_MAX_CONFIG_FILES} rule files")
    resolved = []
    for raw in configs:
        path = Path(raw).expanduser()
        if not path.is_file():
            raise SemgrepConfigError(f"rule file is not a local file: {raw}")
        resolved.append(path.resolve())
    return tuple(resolved)


@dataclass(frozen=True)
class SemgrepPlugin:
    """Contributes the Semgrep enricher, four read-only tools over its subgraph, and triage."""

    configs: tuple[Path, ...] = ()
    rulesets: tuple[str, ...] = ()
    executable: str = "semgrep"
    timeout_seconds: float = 120.0
    enricher: GraphEnricher | None = None
    priority: int = 100

    @property
    def info(self) -> PluginInfo:
        """Identity and ordering for this variant."""
        return PluginInfo(name="semgrep", version=VERSION, priority=self.priority)

    def contribute(self) -> Contribution:
        """Every seam this variant fills; the enricher is built from the rules it was given."""
        return Contribution(
            enrichers=self._enrichers(),
            graph_tools=dict(SEMGREP_TOOLS),
            subagents=(semgrep_triage_subagent(),),
        )

    def _enrichers(self) -> tuple[GraphEnricher, ...]:
        """The shipped enricher over the validated rule files, an override, or nothing at all."""
        if self.enricher is not None:
            return (self.enricher,)
        if not self.configs and not self.rulesets:
            log.warning(
                "vvah-semgrep: no rule files and no rulesets, so the graph carries no Semgrep "
                "evidence and the tools will report an absent subgraph. Pass configs=(<path>,) "
                "for local rules, rulesets=('p/...',) to fetch from the registry over the "
                "network, or enricher= to substitute your own GraphEnricher.")
            return ()
        return (SemgrepEnricher(configs=_validated_configs(self.configs) if self.configs else (),
                                rulesets=tuple(self.rulesets), executable=self.executable,
                                timeout_seconds=self.timeout_seconds, priority=self.priority),)


__all__ = ["VERSION", "SemgrepConfigError", "SemgrepPlugin"]
