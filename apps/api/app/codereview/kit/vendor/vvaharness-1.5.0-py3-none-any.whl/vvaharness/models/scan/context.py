# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The ContextPackage s1 emits, and the prompt views built from it."""
from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel, Field

from vvaharness.models.scan.inputs import CVE, AppProfile, Control
from vvaharness.models.scan.surface import EntryPoint, ModuleInfo, Sink
from vvaharness.models.scan.threat import ThreatModel

log = logging.getLogger(__name__)

class ContextPackage(BaseModel):
    repo_root: str
    language: str                    # primary language detected
    # s0 semgrep codeFlows, source->...->sink; s3._reachable_files never drops these files
    seed_taint_paths: list[list[str]] = []
    entry_points: list[EntryPoint] = []
    unsafe_sinks: list[Sink] = []
    modules: list[ModuleInfo] = []
    all_files: list[str] = []                 # injected: deterministic repo walk (rel paths)
    excluded: dict = {}                       # injected: {dirs:{path:n}, exts:{ext:n}, globs:{pat:n}, oversize:n}
    known_cves: list[CVE] = []                # injected
    design_controls: list[Control] = []       # injected
    app_profile: AppProfile | None = None     # injected (CMDB)
    threat_model: ThreatModel | None = None   # s2 output, attached to ctx after s2
    notes: str = ""                           # free-form Opus observations
    # A dumped NormalizedCollection as a plain dict (no EV import); None = exploit verification off
    ev_collection: dict | None = None
    # Live GraphHandle, attached post-S1; excluded from the checkpoint as --resume rebuilds it
    graph_handle: Any = Field(default=None, exclude=True)

    def ast_context_view(self, *, max_files: int = 250, max_entry_points: int = 120,
                         max_sinks: int = 160, max_modules: int = 40,
                         max_edges: int = 120) -> ContextPackage:
        seed_files: list[str] = []
        _seen: set[str] = set()

        def _add_file(path: str) -> None:
            norm = path.replace("\\", "/")
            while norm.startswith("./"):
                norm = norm[2:]
            if norm and norm not in _seen:
                _seen.add(norm)
                seed_files.append(norm)

        for entry in self.entry_points[:max_entry_points]:
            _add_file(entry.file)
        for sink in self.unsafe_sinks[:max_sinks]:
            _add_file(sink.file)
        for path in self.seed_taint_paths:
            for node in path:
                _add_file(node.split(":", 1)[0])
        for module in self.modules[:max_modules]:
            for path in module.files[:5]:
                _add_file(path)

        all_files: list[str] = []
        all_files_set = set(self.all_files)
        seen_all: set[str] = set()
        for path in seed_files:
            if path in all_files_set and path not in seen_all:
                seen_all.add(path)
                all_files.append(path)
                if len(all_files) >= max_files:
                    break
        if len(all_files) < max_files:
            for path in self.all_files:
                if path not in seen_all:
                    seen_all.add(path)
                    all_files.append(path)
                    if len(all_files) >= max_files:
                        break

        allowed_files = set(all_files)
        entry_points = [e for e in self.entry_points if e.file in allowed_files][:max_entry_points]
        unsafe_sinks = [s for s in self.unsafe_sinks if s.file in allowed_files][:max_sinks]

        modules = []
        for module in self.modules:
            kept = [path for path in module.files if path in allowed_files][:10]
            if kept:
                modules.append(module.model_copy(update={"files": kept}))
            if len(modules) >= max_modules:
                break

        trimmed_paths = []
        for path in self.seed_taint_paths:
            kept = [node for node in path if node.split(":", 1)[0] in allowed_files]
            if kept:
                trimmed_paths.append(kept[:8])

        return self.model_copy(update={
            "all_files": all_files,
            "entry_points": entry_points,
            "unsafe_sinks": unsafe_sinks,
            "modules": modules,
            "seed_taint_paths": trimmed_paths,
        })


