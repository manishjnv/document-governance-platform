# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The deterministic repo walk, its exclusion rules, and post-agent scope checks."""
from __future__ import annotations

import fnmatch
import re
from collections.abc import Collection
from pathlib import Path
from types import SimpleNamespace

from vvaharness.util import console, logs
from vvaharness.util import errlog as _errlog

log = logs.get_logger(__name__)

class EmptyScopeError(RuntimeError):
    """No file survived the exclusions, so nothing could be analysed (exit 2)."""


# Deterministic repo walk: s3/s4 see every source file regardless of what the agent explored
_DEFAULT_EXCLUDE_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv", "venv",
    "dist", "build", ".idea", ".vscode", "target", "vendor", ".terraform",
    ".next", ".nuxt", "coverage", ".pytest_cache", ".mypy_cache",
    # `target` excluded only with a build marker; "spec"/"specs" NOT here (UI component folders)
    "test", "tests", "__tests__", "__test__", "e2e", "testdata",
    "fixtures", "__fixtures__", "mocks", "__mocks__", "stubs",
    # IaC/CI dirs are KEPT in scope (only .terraform excluded); below: our own output dirs
    "checkpoints", "security-scan", "security-remediation", ".vvaharness",
}
_DEFAULT_EXCLUDE_EXTS = {
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg", ".pdf", ".zip", ".gz",
    ".tar", ".7z", ".jar", ".war", ".class", ".exe", ".dll", ".so", ".dylib",
    ".bin", ".o", ".a", ".obj", ".pyc", ".pyo", ".pkl", ".lock", ".min.js", ".map",
    ".woff", ".woff2", ".ttf", ".eot", ".mp4", ".mp3", ".wav",
}
# Globs matched against the repo-relative posix path: co-located test files and root infra files
_DEFAULT_EXCLUDE_GLOBS = (
    "**/test_*.py", "**/*_test.py", "**/conftest.py",
    "**/*_test.go", "**/*.test.js", "**/*.test.ts", "**/*.test.jsx", "**/*.test.tsx",
    "**/*.spec.js", "**/*.spec.ts", "**/*.spec.jsx", "**/*.spec.tsx",
    "**/*Test.java", "**/*Tests.java", "**/*IT.java",
    "**/*Test.cs", "**/*Tests.cs", "**/*Test.kt",
    # Dockerfile/Jenkinsfile/Makefile/*.tf and Helm YAML are KEPT; below is repo metadata only
    "**/.gitignore", "**/.gitattributes", "**/.gitmodules", "**/.gitkeep",
    "**/.editorconfig", "**/.dockerignore", "**/.npmignore", "**/.eslintignore",
    "**/.prettierignore", "**/.mailmap", "**/CODEOWNERS", "**/.DS_Store",
    "**/LICENSE", "**/LICENSE.*", "**/NOTICE",
)

# Proof a `target/` is real build output, in target/'s own PARENT; absent, it is ordinary app code
_TARGET_BUILD_MARKERS = (
    "pom.xml", "build.gradle", "build.gradle.kts", "Cargo.toml",
    "build.sbt", "project.clj",
)


def _has_target_build_marker(root: Path, parent_parts: list[str]) -> bool:
    """True when a Maven/Gradle/Cargo/sbt/Leiningen build marker file sits in
    the directory that directly contains a `target/` dir — i.e. `target/` is
    genuine build output and should stay excluded. Without a marker, a
    directory merely named target/ is ordinary app code and must be walked."""
    parent = root.joinpath(*parent_parts) if parent_parts else root
    return any((parent / marker).is_file() for marker in _TARGET_BUILD_MARKERS)


def _exclusion_sets(cfg) -> tuple[set[str], set[str], list[str]]:
    """Resolve (dirs, exts, globs) once — built-in defaults + config.yaml step1.* appends."""
    excl_dirs = {d.lower() for d in
                 _DEFAULT_EXCLUDE_DIRS | set(getattr(cfg.step1, "exclude_dirs", None) or [])}
    excl_exts = _DEFAULT_EXCLUDE_EXTS | set(getattr(cfg.step1, "exclude_exts", None) or [])
    excl_globs = list(_DEFAULT_EXCLUDE_GLOBS) + list(
        getattr(cfg.step1, "exclude_globs", None) or [])
    return excl_dirs, excl_exts, excl_globs
def glob_hit(rel: str, globs) -> str | None:
    """Return the first glob that excludes the repo-relative posix path `rel`, else None."""
    name = rel.rsplit("/", 1)[-1]
    for g in globs:
        if fnmatch.fnmatchcase(rel, g):
            return g
        if g.startswith("**/") and fnmatch.fnmatchcase(name, g[3:]):
            return g
    return None


def _fold_slashes(p: str) -> str:
    """Posix separators with any leading './' removed."""
    p = p.replace("\\", "/")
    while p.startswith("./"):
        p = p[2:]
    return p


def _norm_rel(repo_root: str, p: str) -> str:
    """Normalize an agent-emitted path to the same repo-relative posix form that _walk_repo produces, so set-mem..."""
    if not p:
        return p
    p = _fold_slashes(p)
    rel_root = str(Path(repo_root)).replace("\\", "/").rstrip("/") + "/"
    abs_root = str(Path(repo_root).resolve()).replace("\\", "/").rstrip("/") + "/"
    pl = p.lower()
    for r in (abs_root, rel_root):
        if pl.startswith(r.lower()):
            return p[len(r):]
    # DeepAgents' vfs is repo-rooted, so "/src/app.py" arrives absolute; strip the virtual root
    return p.lstrip("/")


def resolve_inventory_path(repo_root: str, p: str, inventory: Collection[str]) -> str:
    """*p* in its inventory spelling if any deterministic reading of it is in *inventory*, else its _norm_rel form."""
    if not p:
        return p
    folded = _fold_slashes(p)
    if not inventory:
        # Nothing to resolve against: strip only the virtual root (no inventory path carries one);
        # a root-prefix strip could rewrite a correct path into a wrong one
        return folded.lstrip("/")
    # Raw first: a correct spelling must never lose to a prefix strip (repo dir named like a
    # package dir); the first hit wins, since the string alone cannot tell two readings apart.
    for cand in (folded, folded.lstrip("/"), folded.removeprefix(Path(repo_root).name + "/")):
        if cand in inventory:
            return cand
    return _norm_rel(repo_root, folded)


def _resolve_scope_path(path: str, repo_root: str, keep: set[str],
                        top_dirs: list[str]) -> tuple[str | None, bool]:
    """Resolve an agent-emitted path to its in-scope inventory form."""
    rel = resolve_inventory_path(repo_root, path, keep)
    if rel in keep:
        return rel, False
    matches = [f"{td}/{rel}" for td in top_dirs if f"{td}/{rel}" in keep]
    if len(matches) == 1:
        return matches[0], False
    return None, len(matches) > 1


def scope_after(repo_root: str, cfg, *, dirs=(), exts=(), globs=(),
                max_file_kb: int | None = None) -> list[str]:
    """In-scope inventory _walk_repo yields with these extra step1 exclusions."""
    # A guard on a proposed overlay must measure the walk that actually runs. _survey() is not it — it has no max_file_kb filter.
    base_dirs, base_exts, base_globs = _exclusion_sets(cfg)
    shadow = SimpleNamespace(step1=SimpleNamespace(
        exclude_dirs=sorted(base_dirs | {d.lower() for d in dirs}),
        exclude_exts=sorted(base_exts | set(exts)),
        exclude_globs=list(base_globs) + list(globs),
        max_file_kb=(max_file_kb if max_file_kb is not None
                     else getattr(cfg.step1, "max_file_kb", 1024)),
        follow_symlinks=False,
    ))
    return _walk_repo(repo_root, shadow)[0]


def _walk_repo(repo_root: str, cfg) -> tuple[list[str], dict]:
    root = Path(repo_root)
    root_resolved = root.resolve()
    excl_dirs, excl_exts, excl_globs = _exclusion_sets(cfg)
    max_kb = getattr(cfg.step1, "max_file_kb", 1024)
    # Off-root symlinks are dropped UNCONDITIONALLY (host-file exfil); follow_symlinks only warns
    follow_symlinks = bool(getattr(cfg.step1, "follow_symlinks", False))
    if follow_symlinks:
        console.write("  [s1] NOTE: step1.follow_symlinks is set, but symlinks whose "
                      "target resolves outside the repo are still dropped (host-file "
                      "disclosure guard); only in-tree symlinks are followed.")

    out: list[str] = []
    skipped_dirs: dict[str, int] = {}
    skipped_exts: dict[str, int] = {}
    skipped_globs: dict[str, int] = {}
    skipped_size: list[tuple[str, int]] = []
    skipped_symlinks: dict[str, int] = {}
    skipped_symlink_targets: dict[str, int] = {}

    def _rule_hit(r: str) -> tuple[dict[str, int], str] | None:
        """(bucket, key) of the first dir/ext/glob rule excluding path *r*."""
        parts = r.split("/")
        hit_idx = next(
            (i for i, part in enumerate(parts[:-1])
             if part.lower() in excl_dirs
             # "target" is excluded only when a build marker sits in its parent dir
             and (part.lower() != "target"
                  or _has_target_build_marker(root, parts[:i]))),
            None)
        if hit_idx is not None:
            return skipped_dirs, "/".join(parts[:hit_idx + 1])
        name = parts[-1].lower()
        hit_ext = next((e for e in excl_exts
                        if Path(name).suffix == e or name.endswith(e)), None)
        if hit_ext:
            return skipped_exts, hit_ext
        hit_glob = glob_hit(r, excl_globs)
        if hit_glob:
            return skipped_globs, hit_glob
        return None

    for p in root.rglob("*"):
        if not p.is_file():
            continue
        rel = str(p.relative_to(root)).replace("\\", "/")
        # rglob follows symlinks, so this containment check is UNCONDITIONAL: no config re-opens it
        tgt_rel = None
        if p.is_symlink():
            try:
                tgt = p.resolve(strict=False)
                escapes = not tgt.is_relative_to(root_resolved)
                if not escapes:
                    tgt_rel = tgt.relative_to(root_resolved).as_posix()
            except OSError as _sym_err:
                escapes = True
                _errlog.log("s1", rel, _sym_err, reason="symlink_resolve_failed",
                            note="treated as escaping — file excluded from scope")
            if escapes:
                skipped_symlinks[rel] = skipped_symlinks.get(rel, 0) + 1
                continue
        hit = _rule_hit(rel)
        if hit:
            bucket, key = hit
            bucket[key] = bucket.get(key, 0) + 1
            continue
        # An in-root link is judged by its target too, or a.txt -> key.pem smuggles it into scope
        if tgt_rel is not None and _rule_hit(tgt_rel):
            skipped_symlink_targets[rel] = skipped_symlink_targets.get(rel, 0) + 1
            continue
        try:
            sz = p.stat().st_size
            if sz > max_kb * 1024:
                skipped_size.append((rel, sz))
                continue
        except OSError as _stat_err:
            _errlog.log("s1", rel, _stat_err, reason="stat_failed",
                        note="file excluded from scan scope")
            continue
        out.append(rel)

    excluded = {
        "dirs": skipped_dirs,
        "exts": skipped_exts,
        "globs": skipped_globs,
        "oversize": len(skipped_size),
        "oversize_files": sorted(skipped_size, key=lambda kv: -kv[1]),
        "symlinks": skipped_symlinks,
        "symlink_targets": skipped_symlink_targets,
    }
    return sorted(out), excluded


# Collapses ~5,000 per-env config copies to one per shape-cluster; only if the secret regex clears

_DEDUP_DEFAULTS = {
    "enabled": True,
    "exts": (".yml", ".yaml", ".json", ".toml", ".ini",
             ".properties", ".conf", ".cfg", ".env"),
    "min_cluster_size": 3,
    "keep_per_top_dir": True,
    "promote_on_secret_hit": True,
    "promote_on_insecure_value": True,
    "max_file_kb": 512,
}

# Layer-2 net: real credential material must never be dropped; lookahead skips templated refs
_SECRET_RX = re.compile(
    r"(?i)(?:password|passwd|pwd|secret|api[_-]?key|apikey|access[_-]?key|"
    r"auth[_-]?token|private[_-]?key|client[_-]?secret|credential)s?"
    r"[ \t]*[:=][ \t]*['\"]?"
    r"(?!CRYPT:|ENC\(|\{\{|\$\{|<%=|<%|vault:|secret:|file:|/)"
    r"(?![\w.-]+[ \t]*:)"
    r"[^\s'\",}{]{8,}"
    r"|-----BEGIN [A-Z ]*PRIVATE KEY-----"
    r"|\bAKIA[0-9A-Z]{16}\b"
    r"|\bxox[baprs]-[0-9A-Za-z-]{10,}\b"
    r"|\bgh[pousr]_[0-9A-Za-z]{36,}\b"
    r"|\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"
)

# Insecure *values*, not secrets: they make a variant worth scanning despite a safe-sibling shape
_INSECURE_RX = re.compile(
    r"(?i)\b(?:verify|verif(?:y|ication)[_-]?ssl|ssl[_-]?verify|"
    r"validate[_-]?cert\w*|tls[_-]?verify|check[_-]?hostname|"
    r"reject[_-]?unauthori[sz]ed)\b\s*[:=]\s*['\"]?(?:false|0|no|none|off)\b"
    r"|\binsecure\w*\s*[:=]\s*['\"]?(?:true|1|yes)\b"
    r"|\bInsecureSkipVerify\s*[:=]\s*true\b"
    r"|\b(?:auth|authentication|authn|security)\s*[:=]\s*['\"]?(?:none|disabled|off|false)\b"
    r"|\bdebug\s*[:=]\s*['\"]?(?:true|1|yes)\b"
    r"|\ballow[_-]?anonymous\s*[:=]\s*['\"]?(?:true|1|yes)\b"
)
