# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Per-file scan observability, gated on ``scan_progress.enabled``; all output goes to stderr."""
# Every emit must stay inside self._lock: s4's ThreadPoolExecutor interleaves mid-line otherwise
from __future__ import annotations

import atexit
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Literal

from vvaharness.util import console

Style = Literal["compact", "verbose", "summary_only", "stage_only", "llm_debug", "live"]

_STYLES: tuple[str, ...] = ("compact", "verbose", "summary_only", "stage_only",
                            "llm_debug", "live")

_STAGE_LABELS: dict[str, str] = {
    "s0": "static seed", "s1": "pre-process", "s2": "threat model",
    "s3": "decompose", "s4": "deep dive", "s5": "detectors",
    "s6": "verify", "s7": "dedup", "s8": "chain", "s9": "report",
    "s10": "remediate",
}

_LIVE_REFRESH_HZ = 8

_OUTCOME_GLYPH: dict[str, str] = {
    "completed": "✓", "completed_with_errors": "⚠", "error": "✗",
    "cached": "⤼", "skipped": "–",
}

_OUTCOME_STYLE: dict[str, str] = {
    "completed": "ok", "completed_with_errors": "warn", "error": "fail",
    "cached": "muted", "skipped": "muted",
}


def _clock(seconds: float) -> str:
    """A duration an operator can read at a glance: seconds under a minute, else m:ss."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    return f"{int(seconds) // 60}m{int(seconds) % 60:02d}s"

_STAGE_ORDER = ("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7",
                "s8", "s9", "s10")


_ACTIVE_TRACKER: ScanProgress | None = None


def _stderr_is_a_terminal() -> bool:
    """A live display on a pipe writes cursor escapes into the captured log, so it must not start."""
    import sys

    isatty = getattr(sys.stderr, "isatty", None)
    return bool(callable(isatty) and isatty())


def set_active_tracker(tracker: ScanProgress | None) -> None:
    """Register the process-wide active tracker for backend-level hooks."""
    global _ACTIVE_TRACKER
    _ACTIVE_TRACKER = tracker


def get_active_tracker() -> ScanProgress | None:
    """Return the active per-scan tracker, if one is registered."""
    return _ACTIVE_TRACKER


def is_stage_only() -> bool:
    """Return whether the active scan requests minimum stage-only output."""
    tracker = get_active_tracker()
    return bool(tracker and tracker.enabled and tracker.style == "stage_only")


@dataclass
class UnitProgress:
    unit_id: str
    files: list[str]
    rank: int
    lens: str
    threat: str
    state: Literal["queued", "scanning", "scanned"] = "queued"
    outcome: str | None = None       # "completed" | "error" | "guardrail"
    findings: int = 0
    started_at: float = field(default_factory=time.monotonic)
    elapsed: float = 0.0


class ScanProgress:
    """Thread-safe scan progress tracker.  One instance per repo scan."""

    def __init__(self, *, enabled: bool = False,
                 style: Style = "compact",
                 repo_name: str = ""):
        self.enabled = enabled
        self.style = style
        self.repo_name = repo_name
        try:
            self._llm_max_chars = int(
                os.environ.get("VVAHARNESS_SCAN_PROGRESS_LLM_MAX_CHARS", "12000")
            )
        except ValueError:
            self._llm_max_chars = 12000
        self._lock = threading.Lock()
        self._total_files: int = 0
        self._units: dict[str, UnitProgress] = {}  # unit_id -> UnitProgress
        self._stages: dict[str, dict[str, float | str]] = {}
        self._n_scanning: int = 0
        self._n_scanned: int = 0
        self._start: float = time.monotonic()
        self._live: object | None = None
        self._findings: int = 0


    @classmethod
    def from_cfg(cls, cfg, repo_name: str = "") -> ScanProgress:
        """Build a tracker from the active config."""
        sp = getattr(cfg, "scan_progress", None)
        enabled = bool(getattr(sp, "enabled", False)) if sp else False
        env_enabled = os.environ.get("VVAHARNESS_SCAN_PROGRESS_ENABLED", "").lower()
        if env_enabled in ("1", "true", "yes"):
            enabled = True
        style: Style = str(getattr(sp, "style", "compact")) if sp else "compact"
        if style not in _STYLES:
            style = "compact"
        if style == "live" and not _stderr_is_a_terminal():
            style = "compact"
        return cls(enabled=enabled, style=style, repo_name=repo_name)


    def stage_started(self, stage_id: str, label: str = "") -> None:
        """Emit stage-level start progress (S0-S11)."""
        if not self.enabled:
            return
        self.start_live()
        with self._lock:
            self._stages[stage_id] = {
                "state": "started", "start": time.monotonic(), "label": label,
            }
            if self.style == "summary_only":
                return
            extra = f"  {label}" if label else ""
            if self.style == "stage_only":
                self._emit(f"[progress] ▶ [{self._stage_number(stage_id)}] "
                           f"{stage_id.upper()} {label or stage_id}")
            else:
                self._emit(f"[progress] stage-start {stage_id:<4}{extra}")

    def stage_done(self, stage_id: str, *, outcome: str = "completed",
                   detail: str = "") -> None:
        """Emit stage-level completion progress (S0-S11)."""
        if not self.enabled:
            return
        with self._lock:
            rec = self._stages.get(stage_id, {"start": time.monotonic()})
            elapsed = max(0.0, time.monotonic() - float(rec.get("start", time.monotonic())))
            rec["state"] = outcome
            rec["elapsed"] = elapsed
            self._stages[stage_id] = rec
            if self.style == "summary_only":
                return
            if self.style == "stage_only":
                self._emit(f"[progress] ✓ [{self._stage_number(stage_id)}] "
                           f"{stage_id.upper()} {rec.get('label') or stage_id} "
                           f"({elapsed:.1f}s)")
                self._emit("")
                return
            msg = f"[progress] stage-done  {stage_id:<4} outcome={outcome}  {elapsed:.1f}s"
            if detail:
                msg += f"  {detail}"
            self._emit(msg)

    def stage_note(self, stage_id: str, detail: str) -> None:
        """Emit an in-stage progress note (non-terminal milestone)."""
        if not self.enabled or not detail:
            return
        with self._lock:
            if self.style in ("summary_only", "stage_only"):
                return
            self._emit(f"[progress] stage-note  {stage_id:<4} {detail}")

    def discovered(self, all_files: list[str]) -> None:
        """Call after s1 completes the file inventory walk."""
        if not self.enabled:
            return
        with self._lock:
            self._total_files = len(all_files)
            if self.style in ("summary_only", "stage_only"):
                return
            label = f"  (repo: {self.repo_name})" if self.repo_name else ""
            self._emit(
                f"[progress] discovered  {len(all_files):>5} files{label}"
            )

    def queued(self, unit) -> None:
        """Call for each unit after s3 annotates a threat into an investigation unit."""
        if not self.enabled:
            return
        lens = "+".join((getattr(unit, "languages", None) or [])[:3]) or "generic"
        cp = UnitProgress(
            unit_id=unit.id,
            files=list(getattr(unit, "files", []) or []),
            rank=getattr(unit, "risk_rank", 0),
            lens=lens,
            threat=(getattr(unit, "threat", "") or "")[:80],
        )
        with self._lock:
            self._units[unit.id] = cp
            if self.style in ("summary_only", "stage_only"):
                return
            file_count = len(cp.files)
            self._emit(
                f"[progress] queued      {unit.id:<16} "
                f"(rank={cp.rank}, lens={lens}, {file_count} file{'s' if file_count != 1 else ''})"
            )
            if self.style in ("verbose", "llm_debug"):
                for f in cp.files:
                    self._emit(f"           →  {f}")

    def scanning(self, unit) -> None:
        """Call immediately before s4 starts processing a unit."""
        if not self.enabled:
            return
        with self._lock:
            cp = self._units.get(unit.id)
            if cp:
                cp.state = "scanning"
                cp.started_at = time.monotonic()
            self._n_scanning += 1
            n_total = len(self._units)
            n_done = self._n_scanned
            if self.style == "summary_only":
                return
            file_count = len(getattr(unit, "files", []) or [])
            self._emit(
                f"[progress] scanning    {unit.id:<16}  "
                f"[{file_count} file{'s' if file_count != 1 else ''}]  "
                f"({n_done + self._n_scanning} / {n_total} units)"
            )
            if self.style in ("verbose", "llm_debug"):
                for f in (getattr(unit, "files", []) or []):
                    self._emit(f"           ▶  {f}")

    def scanned(self, unit, *, outcome: str, n_findings: int = 0) -> None:
        """Call after s4 finishes a unit (completed, error, guardrail, uninvestigated, or failed).
        Counted once even when called twice for one unit."""
        if not self.enabled:
            return
        with self._lock:
            cp = self._units.get(unit.id)
            first = cp is None or cp.outcome is None
            if cp:
                cp.state = "scanned"
                cp.outcome = outcome
                cp.findings = n_findings
                cp.elapsed = time.monotonic() - cp.started_at
            self._n_scanning = max(0, self._n_scanning - 1)
            if first:
                self._n_scanned += 1
                self._findings += max(0, n_findings)
            if self.style == "summary_only":
                return
            elapsed_s = f"{cp.elapsed:.1f}s" if cp else "?"
            icon = {"completed": "✓", "error": "✗", "guardrail": "⊘",
                    "uninvestigated": "∅", "failed": "⚠"}.get(outcome, "?")
            finding_note = (f"  findings={n_findings}" if n_findings else "")
            self._emit(
                f"[progress] scanned     {unit.id:<16}  "
                f"outcome={outcome}  {elapsed_s}{finding_note}  {icon}"
            )
            files = getattr(unit, "files", []) or []
            show_files = self.style in ("verbose", "llm_debug") or (
                self.style == "compact" and (n_findings > 0 or outcome != "completed")
            )
            if show_files:
                for f in files:
                    self._emit(f"           {icon}  {f}")

    def print_summary(self) -> None:
        """Call once after all s4 units complete."""
        if not self.enabled or self.style == "stage_only":
            return
        with self._lock:
            total = len(self._units)
            outcomes: dict[str, int] = {}
            scanned_files: set[str] = set()
            for cp in self._units.values():
                o = cp.outcome or "pending"
                outcomes[o] = outcomes.get(o, 0) + 1
                if cp.state == "scanned":
                    scanned_files.update(cp.files)
            remaining = total - self._n_scanned
            # s4's own elapsed, off the same stage-start stage_done() reads, never another stage's
            stage_start = self._stages.get("s4", {}).get("start")
            elapsed = (max(0.0, time.monotonic() - float(stage_start))
                      if stage_start is not None else 0.0)
            outcome_str = "  ".join(
                f"{k}={v}" for k, v in sorted(outcomes.items())
            )
            self._emit(
                f"[progress] summary     {self._n_scanned} / {total} units done  |"
                f"  scanned={len(scanned_files)} files  elapsed={elapsed:.1f}s"
            )
            if outcome_str:
                self._emit(f"           outcomes:  {outcome_str}")
            if remaining > 0:
                self._emit(
                    f"           WARNING: {remaining} unit(s) not scanned "
                    f"(see error log)"
                )
            # Tag each unit's line when more than one ran: concurrent s4 stderr is unattributable
            if total > 1:
                for cp in sorted(self._units.values(), key=lambda c: c.unit_id):
                    if cp.state != "scanned":
                        continue
                    finding_note = f"  findings={cp.findings}" if cp.findings else ""
                    self._emit(
                        f"           unit={cp.unit_id:<16}  outcome={cp.outcome}  "
                        f"{cp.elapsed:.1f}s{finding_note}"
                    )

    def llm_payload(self, *, phase: str, backend: str, model_id: str,
                    tag: str = "", user_prompt: str = "",
                    system_prompt: str = "") -> None:
        """Emit the exact prompt payload stream for LLM dispatch debugging."""
        if not self.enabled or self.style != "llm_debug":
            return
        with self._lock:
            tag_note = f" tag={tag}" if tag else ""
            self._emit(
                f"[progress] llm-call    phase={phase} backend={backend}"
                f" model={model_id}{tag_note}"
            )
            if system_prompt:
                self._emit_prompt_block("system", system_prompt)
            self._emit_prompt_block("user", user_prompt)

    def _emit_prompt_block(self, label: str, text: str) -> None:
        payload = text or ""
        try:
            from vvaharness.report.redact import redact

            payload = redact(payload)
        except Exception:
            # Progress logging must never fail a scan.
            pass
        total = len(payload)
        shown = payload[:self._llm_max_chars]
        self._emit(
            f"[progress] llm-{label}-prompt chars={total}"
            f" shown={len(shown)}"
        )
        for ln in shown.splitlines() or [""]:
            self._emit(f"           | {ln}")
        if total > len(shown):
            self._emit(
                f"           | ... truncated {total - len(shown)} chars"
            )
        self._emit(f"[progress] llm-{label}-end")

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _stage_number(stage_id: str) -> str:
        try:
            index = _STAGE_ORDER.index(stage_id) + 1
        except ValueError:
            return f"?/{len(_STAGE_ORDER)}"
        return f"{index}/{len(_STAGE_ORDER)}"

    def _emit(self, line: str) -> None:
        """One progress line to stderr, suppressed while the live display owns the terminal."""
        if self._live is not None:
            return
        console.write(line)

    def start_live(self) -> None:
        """Take over stderr with the stage table; a no-op unless style is live on a terminal."""
        if self._live is not None or self.style != "live" or not self.enabled:
            return
        if not _stderr_is_a_terminal():
            self.style = "compact"
            return
        try:
            from rich.live import Live

            live = Live(get_renderable=self._render, console=console.console(),
                        refresh_per_second=_LIVE_REFRESH_HZ, transient=False)
            live.start()
        except (ImportError, OSError, ValueError):
            self.style = "compact"
            return
        self._live = live
        atexit.register(self.stop_live)

    def stop_live(self) -> None:
        """Release the terminal, so the summary and any later output print normally."""
        live, self._live = self._live, None
        if live is None:
            return
        try:
            live.stop()
        except OSError:
            self.style = "compact"

    def _render(self):
        """The stage table, rebuilt on every live refresh; never raises into the refresh thread."""
        try:
            return self._stage_table()
        except Exception:  # noqa: BLE001 - a raise here kills rich's refresh thread mid-scan
            from rich.text import Text

            return Text("")

    def _stage_table(self):
        from rich.spinner import Spinner
        from rich.table import Table
        from rich.text import Text

        table = Table(box=None, pad_edge=False, show_edge=False, header_style="muted")
        for column in ("", "stage", "what", "status", "time"):
            table.add_column(column, overflow="fold")
        with self._lock:
            stages = dict(self._stages)
            scanning, scanned, units = self._n_scanning, self._n_scanned, len(self._units)
            findings, started = self._findings, self._start
        for index, stage_id in enumerate(_STAGE_ORDER):
            record = stages.get(stage_id)
            state = str(record.get("state", "")) if record else ""
            label = str(record.get("label", "")) if record else ""
            if state == "started":
                status, clock = Spinner("dots", style="model"), time.monotonic() - float(
                    record.get("start", started))
            elif record:
                status, clock = Text(_OUTCOME_GLYPH.get(state, state), style=_OUTCOME_STYLE.get(
                    state, "muted")), float(record.get("elapsed", 0.0))
            else:
                status, clock = Text("·", style="muted"), None
            table.add_row(Text(f"{index}", style="muted"), Text(stage_id.upper()),
                          Text(label or _STAGE_LABELS.get(stage_id, ""), style="muted"),
                          status, Text("" if clock is None else _clock(clock), style="muted"))
        header = Text("  ")
        header.append(self.repo_name or "scan", style="heading")
        header.append(f"   {_clock(time.monotonic() - started)} elapsed", style="muted")
        if units:
            header.append(f"   units {scanned}/{units}", style="muted")
            if scanning:
                header.append(f" (+{scanning} running)", style="muted")
        if findings:
            header.append(f"   findings {findings}", style="model")
        from rich.console import Group

        return Group(Text(""), header, Text(""), table, Text(""))
