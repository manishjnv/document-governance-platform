# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Detection skill packages, and the injection that makes them reachable from a session."""

from __future__ import annotations

import shutil
import threading
from functools import wraps
from pathlib import Path

PACKAGED_SKILLS = Path(__file__).parent

#: Repo-relative location for temporary skill copies.
INJECTED_SUBDIR = Path(".vvaharness") / "skills"

_INJECTED: dict[str, Path | None] = {}
_TEMP_COPIES: dict[str, tuple[Path, bool]] = {}
_INJECT_LOCK = threading.Lock()


def skill_names() -> tuple[str, ...]:
    """Every packaged skill name, sorted."""
    return tuple(sorted(
        d.name for d in PACKAGED_SKILLS.iterdir()
        if d.is_dir() and (d / "SKILL.md").is_file()
    ))


def _inject(repo_root: Path) -> Path | None:
    """Copy the packaged skills under *repo_root*, or None when the copy fails."""
    parent = Path(repo_root) / INJECTED_SUBDIR.parent
    if parent.is_symlink():
        return None
    parent_existed = parent.exists()
    try:
        parent.mkdir(exist_ok=True)
        dst = Path(repo_root) / INJECTED_SUBDIR
        dst.mkdir()
    except OSError:
        return None
    _TEMP_COPIES[str(repo_root.resolve())] = (dst, parent_existed)
    try:
        shutil.copytree(PACKAGED_SKILLS, dst, dirs_exist_ok=True)
    except OSError:
        return None
    for leftover in (dst / "__init__.py", dst / "__pycache__"):
        if leftover.is_dir():
            shutil.rmtree(leftover, ignore_errors=True)
        elif leftover.exists():
            leftover.unlink(missing_ok=True)
    return dst


def inject_skills(repo_root: Path) -> Path | None:
    """The skill_root for *repo_root*, copying the packaged tree there on first call only."""
    key = str(Path(repo_root).resolve())
    with _INJECT_LOCK:
        if key not in _INJECTED:
            _INJECTED[key] = _inject(Path(repo_root))
        return _INJECTED[key]


def with_injected_skills(function):
    """Remove this scan's temporary skills on return, failure or interruption."""
    @wraps(function)
    def scoped(repo: Path, *args, **kwargs):
        try:
            return function(repo, *args, **kwargs)
        finally:
            key = str(Path(repo).resolve())
            with _INJECT_LOCK:
                _INJECTED.pop(key, None)
                copy = _TEMP_COPIES.pop(key, None)
                if copy is not None:
                    destination, parent_existed = copy
                    shutil.rmtree(destination)
                    if not parent_existed:
                        try:
                            (Path(repo) / INJECTED_SUBDIR.parent).rmdir()
                        except OSError:
                            pass
    return scoped


__all__ = ["INJECTED_SUBDIR", "PACKAGED_SKILLS", "inject_skills", "skill_names",
           "with_injected_skills"]
