# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The Claude backend's own data contract: the SDK-to-harness error mapping."""

# Lives here, not harness.models: it names SDK exception classes and that contract imports no SDK

from __future__ import annotations

from claude_agent_sdk import (
    CLIConnectionError,
    CLIJSONDecodeError,
    CLINotFoundError,
)
from claude_agent_sdk._errors import MessageParseError

from vvaharness.backends.harness.models import (
    HarnessCLINotFoundError,
    HarnessConnectionError,
    HarnessJSONDecodeError,
    HarnessMessageParseError,
)

#: SDK->harness exception pairs; ProcessError is absent by design (exit code/stderr tail to copy)
SDK_ERROR_MAP: tuple[tuple[type[Exception], type[Exception]], ...] = (
    (CLINotFoundError, HarnessCLINotFoundError),
    (CLIConnectionError, HarnessConnectionError),
    (CLIJSONDecodeError, HarnessJSONDecodeError),
    (MessageParseError, HarnessMessageParseError),
)

__all__ = ["SDK_ERROR_MAP"]
