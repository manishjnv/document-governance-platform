# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Graph-compilation helper shared by the streaming and one-shot graphs."""

from __future__ import annotations

import threading
import typing
import warnings
from contextlib import contextmanager
from dataclasses import replace
from enum import Enum
from typing import TYPE_CHECKING, Any

from deepagents import create_deep_agent
from deepagents.backends import FilesystemBackend
from deepagents.middleware.filesystem import FilesystemPermission
from deepagents.profiles.harness.harness_profiles import (
    _HARNESS_PROFILES,
    _ensure_harness_profiles_loaded,
)
from langchain.agents.middleware import ModelRetryMiddleware
from langchain.agents.middleware.types import AgentMiddleware, ExtendedModelResponse, ModelResponse
from langchain.agents.structured_output import StructuredOutputValidationError, ToolStrategy
from langchain_core.exceptions import ModelInvalidRequestError
from langchain_core.messages import ToolMessage
from langchain_core.tools import BaseTool
from langgraph.checkpoint.memory import MemorySaver
from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer
from langgraph.graph.state import CompiledStateGraph
from pydantic import BaseModel

from vvaharness.backends.harness.deepagents.exclude_tools import ExcludeTools
from vvaharness.backends.harness.deepagents.invalid_tool_args import RepairInvalidToolArgs
from vvaharness.backends.harness.deepagents.limits import MODEL_MAX_OUTPUT_TOKENS
from vvaharness.backends.harness.deepagents.models import DELETE_TOOL_NAME, SubagentSpec
from vvaharness.backends.harness.deepagents.options.model_building import (
    REASON_IN_PROMPT,
    build_model_cached,
    reasons_in_prompt,
)
from vvaharness.backends.harness.deepagents.options.response_format import submit_instructed_prompt
from vvaharness.backends.harness.deepagents.permit_tools import PermitTools
from vvaharness.backends.harness.deepagents.profiles import (
    register_vvah_harness_profiles,
    stage_profile_suffix,
)
from vvaharness.backends.harness.deepagents.prompt_caching import BlockMarkerPromptCaching
from vvaharness.backends.harness.deepagents.redaction import read_only_middleware
from vvaharness.backends.harness.deepagents.translate import reply_truncated
from vvaharness.backends.harness.deepagents.usage import SessionUsage, aggregate_usage_metadata
from vvaharness.backends.harness.models import TruncatedResponseError
from vvaharness.backends.llm.models import (
    TRUNCATED_RETRY_ATTEMPTED_COUNTER,
    TRUNCATED_RETRY_RECOVERED_COUNTER,
    proxy_detail,
    truncation_retry_max,
)
from vvaharness.backends.llm.openai import _payload_shape
from vvaharness.util import console, logs
from vvaharness.util import errlog as _errlog
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event
from vvaharness.util.response_quality import is_connection_failure
from vvaharness.util.scan_progress import is_stage_only
from vvaharness.util.tokens import TOKENS

log = logs.get_logger(__name__)

# Message-anchored, NOT module-anchored: stacklevel=2 makes a module= filter never match.
# The drop itself is now compensated below (submit_instructed_prompt), not just silenced here.
warnings.filterwarnings(
    "once",
    message=r"tool_choice is forced but thinking is enabled",
    category=UserWarning,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable, Generator

    from langchain.agents.middleware.types import (
        ModelCallResult,
        ModelRequest,
        ToolCallRequest,
    )
    from langgraph.types import Command

# Serializes create_deep_agent so a suffix-stripped window cannot leak into a concurrent build
_BUILD_LOCK = threading.Lock()


# backends.llm.models is the single home of the proxy/TLS failure signature; import, never copy.
def _connection_retryable(exc: Exception) -> bool:
    """Whether *exc* is a dropped connection safe to retry per call, not a TLS/proxy failure."""
    return is_connection_failure(exc) and proxy_detail(exc) is None


#: Shared verbatim with every subagent spec (options/subagents.py); never copied.
_CONNECTION_RETRY_MIDDLEWARE = ModelRetryMiddleware(
    max_retries=3, initial_delay=5, backoff_factor=2, max_delay=60,
    retry_on=_connection_retryable, on_failure="error",
)


class LogToolCalls(AgentMiddleware):
    """One stderr line per tool call — the deepagents route's own version of the `tool {name} -> {N} chars [tag]..."""
    # NAME and SIZE only: ordering vs RedactToolResults varies, so raw content must never be logged

    def __init__(self, tag: str | None = None) -> None:
        super().__init__()
        self._tag = tag

    def _log(self, request: ToolCallRequest,
             result: ToolMessage | Command[Any]) -> ToolMessage | Command[Any]:
        if not is_stage_only():
            name = request.tool_call.get("name") or ""
            content = getattr(result, "content", "")
            n = len(content) if isinstance(content, str) else 0
            suffix = f" [{self._tag}]" if self._tag else ""
            console.write(f"      [deepagents] tool {name} -> {n} chars{suffix}")
        return result

    def wrap_tool_call(
        self, request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage | Command[Any]],
    ) -> ToolMessage | Command[Any]:
        return self._log(request, handler(request))

    async def awrap_tool_call(
        self, request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command[Any]]],
    ) -> ToolMessage | Command[Any]:
        return self._log(request, await handler(request))


@contextmanager
def _restaged_harness_profiles(stage: str | None, *, blank: bool) -> Generator[None]:
    """Blank or stage-swap every harness-profile suffix for the build; caller holds _BUILD_LOCK."""
    # No public opt-out for the model-keyed suffix (0.7.x); only the suffix is rewritten
    _ensure_harness_profiles_loaded()
    saved = dict(_HARNESS_PROFILES)
    for key, profile in saved.items():
        suffix = "" if blank else stage_profile_suffix(stage, key)
        if suffix is not None:
            _HARNESS_PROFILES[key] = replace(profile, system_prompt_suffix=suffix)
    try:
        yield
    finally:
        _HARNESS_PROFILES.clear()
        _HARNESS_PROFILES.update(saved)


def _result_messages(result: ModelCallResult) -> list:
    """The ``BaseMessage`` list a ``wrap_model_call`` handler's result carries, across all three ``ModelCallResu..."""
    if isinstance(result, ExtendedModelResponse):
        result = result.model_response
    if isinstance(result, ModelResponse):
        return result.result
    return [result]


class CapOutputTokens(AgentMiddleware):
    """Per-request output-token cap, applied as a ``model_settings`` override."""
    # Overrides model_settings (no cache churn); retry resends THIS request; agentic() raises E005

    def __init__(self, max_tokens: int, *, tag: str | None = None,
                cap: int | None = None) -> None:
        """Cap every model request in this graph at *max_tokens* output tokens."""
        super().__init__()
        self._max_tokens = max_tokens
        self._tag = tag
        self._cap_ceiling = cap if cap is not None else MODEL_MAX_OUTPUT_TOKENS

    def _cap(self, request: ModelRequest, max_tokens: int) -> ModelRequest:
        return request.override(
            model_settings={**request.model_settings, "max_tokens": max_tokens}
        )

    def _retry_at(self) -> int | None:
        return truncation_retry_max(self._max_tokens, cap=self._cap_ceiling)

    def _bank(self, discarded: ModelCallResult) -> SessionUsage | None:
        """Count *discarded*'s spend: billed, but it never reaches graph state."""
        usage = aggregate_usage_metadata(_result_messages(discarded))
        if usage:
            TOKENS.add(usage, turns=usage.get("turns"))
        return usage

    def _log_retry(self, retry_at: int, usage: SessionUsage | None) -> None:
        produced = usage.get("output_tokens") if usage else None
        COUNTERS.bump(TRUNCATED_RETRY_ATTEMPTED_COUNTER)
        log.warning(Event.TRUNCATED_RETRY, route="deepagents", max_tokens=self._max_tokens,
                    retry_at=retry_at)
        _errlog.log(
            self._tag or "deepagents", self._tag or "truncation",
            f"VVAH-E005 warning: model call truncated at "
            f"max_tokens={self._max_tokens}; retrying once at {retry_at}",
            error_code=TruncatedResponseError.error_code, recovered=True,
            produced=produced)

    def _truncation_retry_at(self, discarded: ModelCallResult) -> int | None:
        """Doubled cap to resend clipped *discarded* at; None if not clipped or no headroom."""
        if not reply_truncated(_result_messages(discarded)):
            return None
        retry_at = self._retry_at()
        if retry_at is not None:
            self._log_retry(retry_at, self._bank(discarded))
        return retry_at

    def _rejected(self, exc: StructuredOutputValidationError) -> int | None:
        """Bank the rejected final, then the doubled cap if it was cut off; None otherwise."""
        # Native structured output is parsed INSIDE the handler, so a final the cap cut off
        # surfaces as a parse failure, never as a clipped result; either way it was billed
        usage = self._bank(exc.ai_message)
        if not reply_truncated([exc.ai_message]):
            return None
        retry_at = self._retry_at()
        if retry_at is not None:
            self._log_retry(retry_at, usage)
        return retry_at

    @staticmethod
    def _accepted(retried: ModelCallResult) -> ModelCallResult:
        """Count *retried* as recovered unless it was clipped again (agentic() raises E005)."""
        if not reply_truncated(_result_messages(retried)):
            COUNTERS.bump(TRUNCATED_RETRY_RECOVERED_COUNTER)
        return retried

    @contextmanager
    def _banking_rejected_final(self) -> Generator[None]:
        """Bank a doubled retry's final that the parser rejects before re-raising."""
        try:
            yield
        except StructuredOutputValidationError as exc:
            self._bank(exc.ai_message)
            raise

    def wrap_model_call(
        self, request: ModelRequest, handler: Callable[[ModelRequest], ModelCallResult]
    ) -> ModelCallResult:
        """Call the model at the output-token cap; retry once, doubled, if cut off."""
        try:
            result = handler(self._cap(request, self._max_tokens))
        except StructuredOutputValidationError as exc:
            retry_at = self._rejected(exc)
            if retry_at is None:
                raise
        else:
            retry_at = self._truncation_retry_at(result)
            if retry_at is None:
                return result
        with self._banking_rejected_final():
            return self._accepted(handler(self._cap(request, retry_at)))

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelCallResult]],
    ) -> ModelCallResult:
        """Async counterpart of :meth:`wrap_model_call`."""
        try:
            result = await handler(self._cap(request, self._max_tokens))
        except StructuredOutputValidationError as exc:
            retry_at = self._rejected(exc)
            if retry_at is None:
                raise
        else:
            retry_at = self._truncation_retry_at(result)
            if retry_at is None:
                return result
        with self._banking_rejected_final():
            return self._accepted(await handler(self._cap(request, retry_at)))


class LogInvalidRequestShape(AgentMiddleware):
    """Diagnose a gateway's invalid-request 400 with the request shape, then re-raise it."""

    def __init__(self, *, tag: str | None = None) -> None:
        """Tag the diagnostic and errlog rows with *tag* (the graph's own name)."""
        super().__init__()
        self._tag = tag

    def _log_shape(self, request: ModelRequest, exc: ModelInvalidRequestError) -> None:
        # recovered=True: diagnostic only; the call's own failure row records any loss
        _errlog.log(
            self._tag or "deepagents", self._tag or "invalid-request",
            _payload_shape([{"content": m.content} for m in request.messages], str(exc)),
            reason="deepagents_invalid_request_shape", recovered=True)

    def wrap_model_call(
        self, request: ModelRequest, handler: Callable[[ModelRequest], ModelCallResult]
    ) -> ModelCallResult:
        """Call the model; log the request shape and re-raise on an invalid-request 400."""
        try:
            return handler(request)
        except ModelInvalidRequestError as exc:
            self._log_shape(request, exc)
            raise

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelCallResult]],
    ) -> ModelCallResult:
        """Async counterpart of :meth:`wrap_model_call`."""
        try:
            return await handler(request)
        except ModelInvalidRequestError as exc:
            self._log_shape(request, exc)
            raise


def _leaf_serde_classes(annotation: Any) -> list[type]:
    """Every ``BaseModel``/``Enum`` class reachable inside one field annotation."""
    if annotation is None:
        return []
    args = typing.get_args(annotation)
    if args:
        out: list[type] = []
        for arg in args:
            out.extend(_leaf_serde_classes(arg))
        return out
    if isinstance(annotation, type) and issubclass(annotation, (BaseModel, Enum)):
        return [annotation]
    return []


def _reachable_serde_classes(root: type) -> list[tuple[str, str]]:
    """Walk *root*'s pydantic schema for every nested ``BaseModel``/``Enum`` class its fields can produce, as ``..."""
    # Only Enums are keyed (model_dump flattens models); a missing key leaks the raw enum VALUE
    seen: set[type] = set()
    stack: list[type] = [root]
    while stack:
        cls = stack.pop()
        if cls in seen:
            continue
        seen.add(cls)
        if issubclass(cls, BaseModel):
            for field in cls.model_fields.values():
                for nested in _leaf_serde_classes(field.annotation):
                    if nested not in seen:
                        stack.append(nested)
    return [(cls.__module__, cls.__name__) for cls in seen]


def _create_agent(
    model_id: str,
    env: dict[str, str],
    system_prompt: str | None,
    tools: list[BaseTool],
    *,
    name: str,
    skills: list[str] | None,
    permissions: list[FilesystemPermission],
    model_provider: str | None = None,
    redact_reads: bool = False,
    backend: FilesystemBackend | None = None,
    response_model: type | None = None,
    response_format: ToolStrategy | type | None = None,
    subagents: list[SubagentSpec] | None = None,
    extra_excluded_tools: frozenset[str] | None = None,
    max_output_tokens: int | None = None,
    output_cap: int | None = None,
    permitted_tool_calls: frozenset[str] | None = None,
    strip_harness_suffix: bool = False,
    cache_markers: bool = True,
    cache_tail: bool = True,
    parent_middleware: tuple[AgentMiddleware, ...] = (),
    effort: str | None = None,
    use_responses_api: bool | None = None,
    think_in_prompt: bool = False,
) -> CompiledStateGraph:
    """Graph builder shared by the streaming and one-shot graphs."""
    checkpointer: MemorySaver
    if response_model is None:
        checkpointer = MemorySaver()
    else:
        # Every nested BaseModel/Enum the schema can reach, not just response_model itself
        allowed_models = _reachable_serde_classes(response_model)
        checkpointer = MemorySaver(
            serde=JsonPlusSerializer(allowed_msgpack_modules=allowed_models)
        )
    model = build_model_cached(model_id, env, model_provider, effort, use_responses_api)
    # Deliberate, scoped exception to staying frozen/byte-identical on S10/S11 (see LogToolCalls
    # below): langchain-anthropic drops a forced tool_choice under thinking on EVERY Anthropic
    # route regardless of caller, so S11's structured calls are exposed to the same bug and get
    # the same preventive fix as S2/S4/S6/S7/S8 — a no-op everywhere this condition doesn't hold.
    system_prompt = submit_instructed_prompt(system_prompt, model, response_model, response_format)
    register_vvah_harness_profiles()
    kwargs: dict[str, Any] = {
        "model": build_model_cached(
            model_id, env, model_provider, effort, use_responses_api,
            think_in_prompt=think_in_prompt,
        ),
        # Same predicate as build_model's native-reasoning drop, so no route loses both
        "system_prompt": ((system_prompt or "") + REASON_IN_PROMPT)
                         if (think_in_prompt and reasons_in_prompt(model_id, model_provider))
                         else system_prompt,
        "tools": tools,
        "name": name,
        "permissions": permissions,
        "checkpointer": checkpointer,
    }
    # OMITTED, not None/[]: SkillsMiddleware injects ~1.9k chars even with zero skills; do not tidy
    if skills is not None:
        kwargs["skills"] = skills
    # A flat fix agent cannot redact: edit_file needs byte-exact old_string; ONE ExcludeTools only
    extra: frozenset[str] = extra_excluded_tools or frozenset()
    middleware: list[AgentMiddleware]
    if redact_reads:
        middleware = [*read_only_middleware(extra), *parent_middleware]
    else:
        middleware = [
            ExcludeTools(frozenset({DELETE_TOOL_NAME}) | extra),
            *parent_middleware,
        ]
    # Both arms, both flavors: a no-op without an invalid call or a gateway 400
    middleware.append(RepairInvalidToolArgs())
    middleware.append(LogInvalidRequestShape(tag=name))
    # Per-call output cap; None keeps the model ceiling: 64k on Anthropic, uncapped on OpenAI
    if max_output_tokens is not None:
        middleware.append(CapOutputTokens(max_output_tokens, tag=name, cap=output_cap))
    # ExcludeTools only un-advertises, so this is "unreachable" not "absent"; None = NO gate
    if permitted_tool_calls is not None:
        middleware.append(PermitTools(permitted_tool_calls))
    # Shares the auto-attached caching middleware's name, so deepagents replaces it in place
    middleware.append(
        BlockMarkerPromptCaching(enabled=cache_markers, mark_tail=cache_tail)
    )
    # stderr-only; adds no kwarg/prompt/tool-list surface, so it is safe on frozen S10/S11 too.
    middleware.append(LogToolCalls(tag=name))
    # Last of ours (deepagents splices its request-filter tail inside it): the outer budget
    # claims once per call.
    # Preflight probes must report an unreachable endpoint at once, not after the retry window.
    if not name.startswith("preflight"):
        middleware.append(_CONNECTION_RETRY_MIDDLEWARE)
    kwargs["middleware"] = middleware
    if response_format is not None:
        kwargs["response_format"] = response_format
    if subagents is not None:
        kwargs["subagents"] = subagents
    if backend is not None:
        kwargs["backend"] = backend
    # Every build takes the lock so the strip window cannot bleed into a concurrent build
    with _BUILD_LOCK, _restaged_harness_profiles(name, blank=strip_harness_suffix):
        return create_deep_agent(**kwargs)
