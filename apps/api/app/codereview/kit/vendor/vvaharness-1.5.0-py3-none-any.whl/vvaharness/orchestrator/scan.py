# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from __future__ import annotations
from vvaharness.util import logs

"""orchestrator.scan — see package docstring."""
import copy
import hashlib
import os
import shlex
import shutil
import subprocess
import time
from collections.abc import MutableMapping
from dataclasses import dataclass
from pathlib import Path
from uuid import uuid4

import httpx
import yaml

from vvaharness import config as config_mod
from vvaharness.backends.harness.models import is_halt_error
from vvaharness.backends.llm.registry import resolve as resolve_model
from vvaharness.backends.llm.tls import coerce_verify
from vvaharness.codegraph import build_graph
from vvaharness.injectors.cve_feed import load_cves
from vvaharness.injectors.design_controls import load_controls
from vvaharness.models import (
    ContextPackage,
    FinalReport,
    Finding,
    TaskManifest,
    ThreatModel,
)
from vvaharness.orchestrator import store as _store
from vvaharness.orchestrator.artifacts import SCAN_DIR_NAME, artifact_dir
from vvaharness.orchestrator.case_ids import mint_case_ids
from vvaharness.orchestrator.checkpoints import (
    EV_COLLECTION_STEP,
    REPO_IDENTITY_STEP,
    load_ckpt,
    load_stage_provenance,
    run_id_for,
    save_ckpt,
    save_stage_provenance,
)
from vvaharness.orchestrator.cmdb import _load_app_profile
from vvaharness.orchestrator.config_paths import _iter_model_roles, _resolve_against
from vvaharness.orchestrator.enrich_findings import _enrich_findings
from vvaharness.orchestrator.findings_json import write_findings_json
from vvaharness.pipeline.stages import (
    s0_seed,
    s1_autoexclude,
    s1_preprocess,
    s2,
    s3_decompose,
    s4_deepdive,
    s5,
    s6_verify,
    s7_dedup,
    s8_chain,
    s9_sarif,
)
from vvaharness.report.redact import redact
from vvaharness.sdk.loading import load_plugin_set
from vvaharness.skills import with_injected_skills
from vvaharness.util import console
from vvaharness.util import errlog as _errlog
from vvaharness.util.exceptions import S2HollowAfterRetry
from vvaharness.util import metrics as _metrics
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.pricing import load_pricing_cached
from vvaharness.util.scan_progress import ScanProgress, set_active_tracker
from vvaharness.util.stage_telemetry import (
    CACHED_PROVENANCE,
    STAGE_ROLES,
    STAGES,
    stage_token_bucket,
)
from vvaharness.util.stage_telemetry import _resolve_model as _resolve_stage_role
from vvaharness.util.status import stage
from vvaharness.util.tokens import TOKENS
from vvaharness.util.events import Event

log = logs.get_logger(__name__)


@dataclass(frozen=True)
class ScanOutcome:
    """What one repo's scan produced, and whether every stage of it succeeded — ``exit_code`` reflects an in-pipeline remediation or validation failure, or a degraded report (empty scope, a stage error, or s4 halting early on expired credentials/a broken proxy), instead of swallowing any of them."""
    report_path: Path | None
    finding_count: int
    exit_code: int = 0


def _head_sha(repo: Path) -> str | None:
    """Return the scanned repo's current git HEAD SHA, or None for a non-git target / git failure."""
    try:
        r = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"],
                           capture_output=True, text=True, timeout=20)
        return r.stdout.strip() if r.returncode == 0 else None
    except Exception:                                  # noqa: BLE001
        return None


def _config_file_sha256(config_path: str | Path) -> str | None:
    """Hash the raw config file bytes for a stage's provenance envelope (E4)."""
    # Its own helper, not manifest.py's private ``_config_sha256``: scan.py imports nothing from it
    try:
        return hashlib.sha256(Path(config_path).read_bytes()).hexdigest()
    except OSError:
        return None


def _ledger_imbalance(s5_out_count: int, verified: list, dropped: list) -> str | None:
    """The finding-ledger balance check, from typed fields only (never COUNTERS, which are process-wide and read..."""
    # A real EQUALITY, not a floor: clones subtract out, so growth cannot mask a same-size loss
    s6_discovered_verified = sum(1 for f in verified if f.origin == "s6_discovered")
    clones = sum(1 for f in verified if f.is_repeat_clone)
    s6_dropped_from_s5 = sum(1 for d in dropped if not d.chunk_id.endswith("+s6"))
    accounted = (len(verified) - s6_discovered_verified - clones) + s6_dropped_from_s5
    if accounted == s5_out_count:
        return None
    diff = s5_out_count - accounted
    if diff > 0:
        return (f"finding ledger does not balance: {s5_out_count} entered "
               f"verification, {accounted} accounted for in verified/dropped "
               f"({diff} missing)")
    return (f"finding ledger does not balance: {s5_out_count} entered "
           f"verification, {accounted} accounted for in verified/dropped "
           f"({-diff} more than entered — a double-count, not a loss)")


def _verified_counts(verified: list[Finding]) -> tuple[int, int, int, int]:
    """(TRUE_POSITIVE, discovered TP, repeat-clone TP, EV-rescued) counts over *verified*."""
    # The ledger check's typed markers, never COUNTERS. Discovered and clone are disjoint (the
    # re-verify wave, a discovery's only path through apply_outcome, has clone_repeats off); a
    # row without a TRUE_POSITIVE verdict can only be an EV rescue of a static drop (_rescue).
    tps = [f for f in verified if f.verdict == "TRUE_POSITIVE"]
    return (len(tps),
            sum(1 for f in tps if f.origin == "s6_discovered"),
            sum(1 for f in tps if f.is_repeat_clone),
            len(verified) - len(tps))


def _verified_order(verified: list) -> list:
    """Sort S6 output into a stable order before it is checkpointed and handed to S7."""
    return sorted(verified, key=lambda f: (
        f.file, f.line_start, f.line_end, f.cwe or "", f.vuln_class or "",
        f.title or "", f.chunk_id or ""))


def _prune_ev_replays(run_id: str, canonical, ctx) -> None:
    """Drop replay bundles for findings that S7 dedup collapsed."""
    # EV stores bundles at end of S6, BEFORE dedup, so the set can outlive the report; best-effort
    if not getattr(ctx, "ev_collection", None):
        return
    try:
        from vvaharness.exploit_verification.verify.router import replay_key
        removed = _store.prune_replays(run_id, {replay_key(f) for f in canonical})
        if removed:
            console.write(f"  [s6-ev] pruned {removed} replay bundle(s) for finding(s) "
                          f"collapsed by dedup")
    except Exception as exc:  # noqa: BLE001 — pruning is housekeeping, never fatal
        log.warning(Event.REPLAY_PRUNE_FAILED, error=type(exc).__name__)


def _ev_collection_in(repo: Path, args, ckpt_dir: Path, run_id: str, collection_in=None):
    """Resolve the collection EV should work from: ``(collection, resumed)``."""
    # Precedence: EV_API_COLLECTION then the ev_collection checkpoint, --resume ONLY (EV sends live)
    from vvaharness.exploit_verification import options as ev_options

    if ev_options.collection_path(os.environ):
        if collection_in is None:
            # No gate object means a direct caller (e.g. a test): nothing to verify against, EV off
            console.write("  [ev-probe] no parsed collection handed to the scan; skipping "
                          "exploit verification")
            return None, False
        return collection_in, False

    if not getattr(args, "resume", False):
        return None, False
    col = load_ckpt(ckpt_dir, run_id, EV_COLLECTION_STEP)
    if col is None:
        # Silent for an ordinary SAST-only resume; a --stop-after ev resume asked for a check.
        if getattr(args, "stop_after", None) == "ev":
            console.write("  [ev] no checkpointed collection for this run — set "
                          "EV_API_COLLECTION")
        return None, False
    console.write(f"  [ev] reusing the checkpointed collection "
                  f"({len(col.endpoints)} endpoint(s), {col.source_format}) — exploit "
                  f"verification is ON for this resumed run")
    return col, True


def _ev_prep(repo: Path, args, cfg, *, ckpt_dir: Path, run_id: str,
             collection_in=None) -> dict | None:
    """Exploit-verification prep: probe the collection's reachability against the live target and return the (re..."""
    # Pre-S1: --stop-after ev needs no graph/spend; EVUnreachableError -> exit 2; never edits repo
    from vvaharness.exploit_verification import options as ev_options
    from vvaharness.exploit_verification import probe as ev_probe
    from vvaharness.exploit_verification.errors import EVInputError

    # Master switch first: resolving a collection reads disk and logs, which an EV-off run must not
    if ev_options.profile_disabled(cfg):
        return None
    col_in, resumed = _ev_collection_in(repo, args, ckpt_dir, run_id, collection_in)
    if col_in is None:
        # `enabled: true` = REQUIRED, and this is the first point that knows if a collection exists
        if ev_options.required(cfg):
            raise EVInputError(
                "step6_exploit_verification.enabled: true requires a collection, and "
                "this run resolved none (EV_API_COLLECTION unset, and no checkpointed "
                "collection to resume). Set EV_API_COLLECTION, or set "
                "enabled: auto to make verification optional.")
        return None
    opts = ev_options.load_options(cfg, os.environ, resumed_collection=resumed)
    if not opts.enabled:
        return None

    # Checked here too: a resumed run's collection came from a checkpoint preflight cannot read
    _model_err = ev_options.model_preflight(cfg)
    if _model_err:
        raise EVInputError(_model_err)

    if resumed:
        # The offline gate had no path to run on, so its env-dependent checks run here, pre-S1
        from vvaharness.exploit_verification import gate as ev_gate
        result = ev_gate.run_gate(opts, os.environ, collection=col_in)
        if result.checks:
            console.write("  [exploit-verification] collection gate (from checkpoint):")
            console.write(ev_gate.format_checks(result.checks))
    else:
        # Persist the parsed input, not the probe's annotations: reachability is per-deployment
        save_ckpt(ckpt_dir, run_id, EV_COLLECTION_STEP, col_in)

    col = ev_probe.run_probe(
        col_in, opts,
        allow_state_changing=bool(ev_options.ev_section(cfg).allow_state_changing_methods))
    # None → the on_unreachable=abort policy disabled EV for this run.
    if col is None:
        return None
    _ev_oob_selftest(opts)
    return col.model_dump()


def _ev_oob_selftest(opts) -> None:
    """Validate the OOB listener early (before model spend) and log the outcome."""
    from vvaharness.exploit_verification.executor.oob import resolve_oob

    mgr = resolve_oob(opts)
    if not mgr.enabled:
        if (opts.oob_mode or "auto") != "off":
            console.write("  [ev-oob] out-of-band listener off (no EV_OOB_URL and the "
                          "target is not loopback) — blind-only findings will fall to "
                          "static")
        return
    try:
        mgr.start()
        ok = mgr.self_test()
        console.mark("ok" if ok else "fail",
                     f"[ev-oob] listener {'reachable' if ok else 'NOT reachable'} "
                     f"(self-test {mgr.advertised_url}); the target must be able to "
                     f"reach this URL")
    finally:
        mgr.stop()


def _hydrate_ctx_callgraph_from_store(run_id: str, ctx: ContextPackage,
                                      *steps: str) -> ContextPackage:
    """Attach the stored entry-point/sink qnode index as ctx.call_graph for runtime prompt context, searching the step list in order — first hit wins."""
    for step in steps:
        graph = _store.load_callgraph(run_id, step)
        if not graph:
            continue
        console.write(
            "  [graphdb] hydrated ctx.call_graph from sqlite: "
            f"step={step} nodes={graph['node_count']}"
        )
        return ctx.model_copy(update={"call_graph": graph["call_graph"]})
    return ctx


def _upload_to_ingest(md_path: Path, sarif_path: Path, *,
                      repository_name: str, application_id: str | None,
                      cfg, cfg_dir: Path) -> bool:
    """Upload the Step 9 markdown+SARIF artifacts to the ingest hub."""
    # Non-fatal; dest UNRESTRICTED; plain httpx.Client not safety.hardened_client; bad CA skips
    output_cfg = getattr(cfg, "output", None)
    url = getattr(output_cfg, "ingest_url", None)
    token = getattr(output_cfg, "ingest_token", None)
    if not url:
        console.write("  [ingest] no output.ingest_url configured - skipping")
        return False
    if not token:
        console.write("  [ingest] no output.ingest_token configured - skipping")
        return False
    if not md_path.exists() or not sarif_path.exists():
        console.write(f"  [ingest] report files missing ({md_path}, {sarif_path}) - skipping")
        return False

    verify = getattr(output_cfg, "ingest_verify", None)
    if verify is None:
        verify = getattr(getattr(cfg, "sdk", None), "verify_ssl", True)
    verify = coerce_verify(verify)
    if isinstance(verify, str):
        verify = _resolve_against(cfg_dir, verify)
        if not Path(verify).exists():
            # SECURITY: fail CLOSED — a configured CA path asks for STRICTER TLS, not for none
            log.error(Event.INGEST_CA_MISSING, path=verify,
                      remedy="set output.ingest_verify to a readable bundle, or to false to accept an unverified upload")
            return False

    headers = {
        "Authorization": f"Bearer {token}",
        "accept": "application/json",
    }
    data = {"repositoryName": repository_name}
    if application_id:
        data["applicationId"] = application_id

    console.write(f"  [ingest] POST {url}  verify={verify!r}")
    try:
        with open(md_path, "rb") as md_f, open(sarif_path, "rb") as sarif_f:
            files = {
                "file": (md_path.name, md_f, "text/markdown"),
                "sarifFile": (sarif_path.name, sarif_f, "application/json"),
            }
            with httpx.Client(timeout=60, verify=verify) as client:
                resp = client.post(url, headers=headers, data=data, files=files)
        if resp.status_code >= 400:
            body = (resp.text or "")[:500]
            console.write(f"  [ingest] upload failed (non-fatal): HTTP {resp.status_code} "
                          f"for {url}\n"
                          f"  [ingest] server response: {body}")
            return False
        console.write(f"  [ingest] uploaded {md_path.name} + {sarif_path.name} - "
                      f"{resp.status_code}")
        return True
    except Exception as e:
        console.write(f"  [ingest] upload failed (non-fatal): {e}")
        return False


def _recorded_stage_outcome(step_id: str, fallback: str) -> str:
    """The outcome STAGES actually recorded for *step_id*, else *fallback*."""
    # status.stage() may close a stage as ``completed_with_errors``, so echo the record, not the arg
    rec = STAGES.snapshot().get(step_id) or {}
    recorded = rec.get("outcome")
    if recorded in (None, "running", "not_run"):
        return fallback
    return recorded


def _artifact_module_name(repo_name: str) -> str:
    """Return a non-empty, filesystem-safe module name for scan artifacts."""
    safe = "".join(c if c.isalnum() or c in "._-" else "_" for c in repo_name)
    return safe if safe and safe.strip(".") else "repo"


@with_injected_skills
def scan_repo(repo: Path, repo_name: str, application_id: str | None,
              args, cfg,
              path_prefix: str | None = None,
              ev_collection_in=None) -> ScanOutcome:
    """Run the profile-selected S0-S11 workflow against one local checkout, returning a :class:`ScanOutcome` (ra..."""
    run_id = run_id_for(repo)

    # SECURITY: checkpoint state MUST NOT live in the scanned repo; state_root() never creates it
    _state = _store.state_root()
    ckpt_dir = _state / "checkpoints" / run_id
    # Checkpoints live in the SQLite state store; ckpt_dir is kept for save_ckpt/load_ckpt call-site compatibility and used on disk only for the --auto-step1 overlay.
    _store.register_run(run_id, repo_root=str(repo.resolve()),
                        repo_name=repo_name, app_id=application_id)

    # Fresh scan = start over: purge stale rows; --stop-after ev exempt, it returns before S1
    if not args.resume and args.stop_after != "ev":
        _cleared = _store.reset_run(run_id)
        if _cleared:
            console.write(f"  [ckpt] reset {run_id[:12]}… — cleared {_cleared} stale "
                          f"checkpoint row(s) from a prior scan")

    # run_id keys on PATH: a re-clone publishes stale findings; resume stays on; no HEAD = not bound
    repo_head = _head_sha(repo)
    if args.resume and repo_head:
        prior_head = load_ckpt(ckpt_dir, run_id, REPO_IDENTITY_STEP)
        if isinstance(prior_head, str) and prior_head and prior_head != repo_head:
            log.warning(Event.CKPT_TARGET_CHANGED, run_id=run_id[:12], prior_head=prior_head[:12],
                        repo_head=repo_head[:12])
            _store.reset_run(run_id)
    if repo_head:
        save_ckpt(ckpt_dir, run_id, REPO_IDENTITY_STEP, repo_head)

    # SECURITY: a committed `security-scan` symlink would redirect every artifact AND the error log
    out_dir = artifact_dir(repo, SCAN_DIR_NAME)

    # Step 10's exit code, carried to every return so an early --stop-after and a full run report the same way.
    rem_rc = 0

    # Belt-and-braces: refuse --resume if ckpt_dir somehow resolves inside the target tree.
    if args.resume:
        try:
            ckpt_dir.resolve().relative_to(repo.resolve())
        except ValueError:
            pass  # good — ckpt_dir is OUTSIDE the repo
        else:
            console.mark("fail", "refusing --resume: checkpoint dir resolves inside the "
                  "scanned repository", indent=0)
            return ScanOutcome(None, 0)

    t0 = time.time()
    start_ts = _metrics.now_iso()
    # Filesystem-safe timestamp (':' is illegal on Windows).
    ts_safe = start_ts.replace(":", "").replace("-", "")
    module_safe = _artifact_module_name(repo_name)
    out_path = out_dir / f"{module_safe}_{ts_safe}_report.md"
    sarif_path = out_dir / f"{module_safe}_{ts_safe}_report.sarif"
    # Configure the per-scan error log BEFORE any stage can call _errlog.log(), so failures land in <repo>/security-scan/ rather than the module-global default.
    _errlog.configure(out_dir / f"{module_safe}_{ts_safe}_errors.jsonl")

    # Before auto-step1/S1 so --stop-after ev is spend-free; AFTER reset_run, which would delete it
    ev_collection = _ev_prep(repo, args, cfg, ckpt_dir=ckpt_dir, run_id=run_id,
                             collection_in=ev_collection_in)
    if args.stop_after == "ev":
        return ScanOutcome(None, 0)

    # Runs once per cloned target, BEFORE s1, layering its exclusions on top of config.yaml's step1; cfg is deep-copied so batch entries don't accumulate each other's overlays.
    if getattr(args, "auto_step1", False):
        # Through store so this dir gets the DB's owner-only mode: a later stage reads the overlay
        _store.ensure_state_dir("checkpoints", run_id)
        auto_path = ckpt_dir / "step1.yaml"
        if not (args.resume and auto_path.is_file()):
            try:
                with TOKENS.phase("s1-autoexclude"):
                    s1_autoexclude.run(repo, cfg, out_path=auto_path)
            except Exception as e:
                if is_halt_error(e):
                    raise
                log.warning(Event.S1_AUTOEXCLUDE_FAILED, detail=str(e))
                _errlog.log("s1.autoexclude", repo_name, e)
                auto_path = None
        else:
            console.write(f"  [auto-step1] reusing {auto_path}")
            # A cached overlay can predate this build's vetoes, so re-vet; --step1-config never is
            stored = yaml.safe_load(auto_path.read_text(encoding="utf-8")) or {}
            if isinstance(stored, dict):
                dirs0 = list(stored.get("exclude_dirs") or [])
                exts0 = list(stored.get("exclude_exts") or [])
                globs0 = list(stored.get("exclude_globs") or [])
                dirs1, exts1, globs1 = s1_autoexclude.vet_overlay(
                    repo, cfg, dirs=dirs0, exts=exts0, globs=globs0)
                dedup0 = stored.get("config_dedup") or {}
                dedup1 = s1_autoexclude.vet_config_dedup(dedup0)
                vetoed_dirs = sorted(set(dirs0) - set(dirs1))
                vetoed_exts = sorted(set(exts0) - set(exts1))
                vetoed_globs = sorted(set(globs0) - set(globs1))
                changed_dedup = dedup1 != dedup0
                if vetoed_dirs or vetoed_exts or vetoed_globs or changed_dedup:
                    log.warning(f"re-vetted stored overlay on "
                          f"--resume; dropped dirs={vetoed_dirs} "
                          f"exts={vetoed_exts} globs={vetoed_globs}"
                          + (f"; config_dedup {dedup0} -> {dedup1}"
                             if changed_dedup else ""))
                    stored["exclude_dirs"] = dirs1
                    stored["exclude_exts"] = exts1
                    stored["exclude_globs"] = globs1
                    if dedup1:
                        stored["config_dedup"] = dedup1
                    elif "config_dedup" in stored:
                        del stored["config_dedup"]
                    auto_path.write_text(
                        "# Auto-generated by vvaharness auto-step1 — "
                        "appended to global step1.\n"
                        + yaml.safe_dump(stored, sort_keys=False,
                                        default_flow_style=False),
                        encoding="utf-8")
        if auto_path and auto_path.is_file():
            cfg = config_mod.Config(copy.deepcopy(cfg._data))
            # expand=False: the overlay is LLM-authored; ${...} must stay literal.
            cfg, _ = config_mod.apply_step1_overlay(cfg, auto_path, expand=False)
            s1 = cfg._data.get("step1", {})
            console.write(f"  [auto-step1] applied overlay  "
                          f"(exclude_dirs={len(s1.get('exclude_dirs') or [])} "
                          f"exts={len(s1.get('exclude_exts') or [])} "
                          f"globs={len(s1.get('exclude_globs') or [])})")

    # Optional file/unit progress tracker (stages consume cfg._scan_progress).
    tracker = ScanProgress.from_cfg(cfg, repo_name=repo_name)
    set_active_tracker(tracker)
    cfg._data["_scan_progress"] = tracker

    def _sp_start(step_id: str, label: str) -> None:
        if tracker.enabled:
            tracker.stage_started(step_id, label=label)

    def _sp_done(step_id: str, *, outcome: str = "completed",
                 detail: str = "") -> None:
        # completed/error already carry a measured duration; other outcomes ran no timed body
        if outcome not in ("completed", "error"):
            STAGES.mark(step_id, outcome)
        if outcome == "cached":
            # E4: every "cached" call site funnels here; a pre-E4 row has no envelope and falls back
            prov = load_stage_provenance(ckpt_dir, run_id, step_id)
            if prov is not None:
                CACHED_PROVENANCE.record(step_id, prov)
        if tracker.enabled:
            # Echo what status.stage() recorded (maybe completed_with_errors), else the passed value
            tracker.stage_done(step_id,
                               outcome=_recorded_stage_outcome(step_id, outcome),
                               detail=detail)

    console.banner()
    console.write(f"Agentic SAST  repo={repo}  module={repo_name}  "
                  f"app_id={application_id or '-'}  run_id={run_id}")
    console.write("  models:")
    for role, m in _iter_model_roles(cfg):
        mid, via, extras = resolve_model(m)
        ex = f" {extras}" if extras else ""
        console.write(f"    {role:<11} -> {mid:<28} [{via}]{ex}")

    cfg_dir = Path(args.config).resolve().parent
    cves = load_cves(_resolve_against(cfg_dir, cfg.inject.cve_file))
    controls = load_controls(_resolve_against(cfg_dir, cfg.inject.controls_file))
    app_profile, app_info = _load_app_profile(application_id)
    console.write(f"  injected: {len(cves)} CVEs, {len(controls)} controls, "
                  f"app_profile={'yes' if app_profile else 'no'}")

    def _m(role: str) -> str:
        mid, via, _ = resolve_model(getattr(cfg.models, role))
        return f"{mid} [{via}]"

    # Role -> model id plus the price table: the two ingredients of per-stage cost_usd
    _scan_role_models = {role: resolve_model(m)[0] for role, m in _iter_model_roles(cfg)}
    _scan_pricing = load_pricing_cached(getattr(getattr(cfg, "pricing", None), "file", None))
    # E4: role -> via + this run's config hash, so a --resume under another --config keeps origin
    _scan_role_vias = {role: resolve_model(m)[1] for role, m in _iter_model_roles(cfg)}
    _scan_config_sha256 = _config_file_sha256(args.config)

    def _save_stage_provenance(step_id: str) -> None:
        role = STAGE_ROLES.get(step_id)
        # E4: every phase PHASE_MAP maps to step_id — s1 spans s1-autoexclude AND s1-preprocess
        bucket = stage_token_bucket(step_id, TOKENS.snapshot())
        save_stage_provenance(
            ckpt_dir, run_id, step_id,
            model=_resolve_stage_role(role, _scan_role_models),
            via=_resolve_stage_role(role, _scan_role_vias),
            config_sha256=_scan_config_sha256,
            tokens=bucket,
        )

    # Pure static, zero tokens: runs the configured seed engine and returns EntryPoint/Sink/taint-path lists that s1 merges into the ContextPackage.
    seed = load_ckpt(ckpt_dir, run_id, "s0") if args.resume else None
    if seed is None:
        # The label names what S0 does: match rule packs against source text, no phantom knob
        _sp_start("s0", "rules")
        with stage("Step 0 — Static seed (rules)", n=0, total=11,
                   stage_id="s0"), TOKENS.phase("s0-seed"):
            seed = s0_seed.run(str(repo), cfg, ckpt_dir=ckpt_dir)
        save_ckpt(ckpt_dir, run_id, "s0", seed)
        _save_stage_provenance("s0")
        _sp_done("s0", detail=(f"entry_points={len(getattr(seed, 'entry_points', []) or [])} "
                               f"sinks={len(getattr(seed, 'unsafe_sinks', []) or [])}"))
    else:
        _sp_done("s0", outcome="cached")
    _store.save_callgraph(run_id, "s0", seed)
    # Not checkpointed: a --resume rebuilds rather than deserializing a workspace handle from JSON
    _plugins = load_plugin_set(cfg)
    _plugins.install_graph_tools()
    # One directory per invocation: a prior run's workspace is never reopened, so it is never stale
    graph_dir = _store.ensure_state_dir("graphs", run_id, uuid4().hex)
    graph_handle = build_graph(str(repo), run_id, graph_dir,
                               enrichers=_plugins.contribution.enrichers)
    # Every exit from here (each --stop-after, the return, any exception) must release the workspace
    try:
        if args.stop_after == "s0":
            return ScanOutcome(None, 0)

        ctx: ContextPackage | None = load_ckpt(ckpt_dir, run_id, "s1") if args.resume else None
        if ctx is None:
            _sp_start("s1", f"{_m('preprocess')}")
            with stage(f"Step 1 — Pre-process ({_m('preprocess')})", n=1, total=11,
                       stage_id="s1"), TOKENS.phase("s1-preprocess"):
                ctx = s1_preprocess.run(str(repo), cfg, cves, controls, seed=seed,
                                        graph_handle=graph_handle)
            save_ckpt(ckpt_dir, run_id, "s1", ctx)
            _save_stage_provenance("s1")
            _sp_done("s1", detail=f"files={len(getattr(ctx, 'all_files', []) or [])}")
        else:
            _sp_done("s1", outcome="cached")
        _store.save_callgraph(run_id, "s1", ctx)
        ctx = _hydrate_ctx_callgraph_from_store(run_id, ctx, "s1", "s0")
        ctx.app_profile = app_profile
        ctx.ev_collection = ev_collection      # from the pre-S1 EV probe (None when EV off)
        ctx.graph_handle = graph_handle
        if args.stop_after == "s1":
            return ScanOutcome(None, 0)

        # ── Step 2 — Threat model (always runs; S3/S4 mint nothing without it) ─
        tm: ThreatModel | None = (load_ckpt(ckpt_dir, run_id, "s2")
                                  if args.resume else None)
        # Only a fresh s2 invalidates s3+: treating a restored checkpoint as "re-ran" would
        # re-run s3..s8 on every resume. Set as soon as a re-run is ATTEMPTED, not only on a
        # clean return -- an s2 that throws also leaves s3+ built from a stale threat model,
        # and must cascade exactly like an empty or successful rerun does.
        s2_reran = False
        if tm is None:
            s2_reran = True
            try:
                _sp_start("s2", f"{_m('threatmodel')}")
                with stage(f"Step 2 — Threat model ({_m('threatmodel')})",
                           n=2, total=11, stage_id="s2"), \
                        TOKENS.phase("s2-threatmodel"):
                    tm = s2.run(str(repo), repo_name, cfg, cves,
                                            controls, ctx=ctx,
                                            app_profile=app_profile)
                # model_validate({}) succeeds, so an empty checkpoint would pin --resume forever
                if tm.threats or tm.assets or tm.trust_boundaries:
                    save_ckpt(ckpt_dir, run_id, "s2", tm)
                    _save_stage_provenance("s2")
                else:
                    COUNTERS.bump("s2_degraded")
                _sp_done("s2", detail=(f"assets={len(tm.assets)} boundaries={len(tm.trust_boundaries)} "
                                       f"threats={len(tm.threats)}"))
            except S2HollowAfterRetry as e:
                COUNTERS.bump("s2_degraded")
                _errlog.log("s2", repo_name, str(e), reason=e.reason)
                _sp_done("s2", outcome="error", detail=f"hollow after retry ({e.reason})")
                tracker.stop_live()
                console.mark("fail", f"{e}", lead="\n")
                return ScanOutcome(None, 0, exit_code=1)
            except Exception as e:
                if is_halt_error(e):
                    raise
                log.warning(Event.S2_STEP_FAILED, detail=str(e))
                # s2 already logs its own failures; logging again double-counts
                if not _errlog.already_logged(e):
                    _errlog.log("s2", repo_name, e)
                _sp_done("s2", outcome="error",
                         detail=redact(f"{type(e).__name__}: {e}"))
                # Worse than an empty model: attribution and the AC lens both go
                COUNTERS.bump("s2_degraded")
                tm = None
        else:
            _sp_done("s2", outcome="cached")
        # Always re-attach (s2/CMDB may differ across resumed runs).
        ctx.threat_model = tm
        _store.save_callgraph(run_id, "s2", ctx)
        ctx = _hydrate_ctx_callgraph_from_store(run_id, ctx, "s2", "s1", "s0")
        if args.stop_after == "s2":
            return ScanOutcome(None, 0)

        # Reuse s3 only if s2 was restored too: a rerun s2 makes the cached manifest stale
        manifest: TaskManifest | None = (load_ckpt(ckpt_dir, run_id, "s3")
                                         if args.resume and not s2_reran else None)
        s3_resumed = manifest is not None
        if manifest is None:
            _sp_start("s3", f"{_m('decompose')}")
            with stage(f"Step 3 — Decompose ({_m('decompose')})", n=3, total=11,
                       stage_id="s3"), TOKENS.phase("s3-decompose"):
                manifest = s3_decompose.run(ctx, cfg)
            save_ckpt(ckpt_dir, run_id, "s3", manifest)
            _save_stage_provenance("s3")
            _sp_done("s3", detail=f"units={len(getattr(manifest, 'units', []) or [])}")
        else:
            _sp_done("s3", outcome="cached")
        _store.save_callgraph(run_id, "s3", ctx)
        if args.stop_after == "s3":
            return ScanOutcome(None, 0)

        # Reuse s4 only if s3 was restored too: a rerun s3 mints units a cached s4 never saw
        s4_ckpt = load_ckpt(ckpt_dir, run_id, "s4") if args.resume and s3_resumed else None
        s4_resumed = s4_ckpt is not None
        unit_outcomes: dict[str, str] = {}
        external_input = False
        if s4_ckpt is None:
            _sp_start("s4", f"{_m('deepdive')}")
            with stage(f"Step 4 — Deep-dive ({_m('deepdive')}; "
                       f"parallel={getattr(cfg.step4, 'parallel', 12)})",
                       n=4, total=11, stage_id="s4"), TOKENS.phase("s4-deepdive"):
                findings, unit_outcomes = s4_deepdive.run(manifest.sorted_units(), ctx, cfg)
            # Bundle the per-unit outcomes with the findings so a --resume that rebuilds metrics still sees the coverage tally.
            save_ckpt(ckpt_dir, run_id, "s4",
                      {"findings": findings, "outcomes": unit_outcomes})
            _save_stage_provenance("s4")
            _sp_done("s4", detail=f"findings={len(findings)}")
        elif isinstance(s4_ckpt, dict):
            from vvaharness.orchestrator.checkpoints import s4_input_kind

            findings = s4_ckpt.get("findings", [])
            unit_outcomes = s4_ckpt.get("outcomes", {})
            external_input = s4_input_kind(s4_ckpt) == "external"
            _sp_done("s4", outcome="cached")
        else:  # legacy bare-list checkpoint (pre outcome-tracking)
            findings = s4_ckpt
            _sp_done("s4", outcome="cached")
        _store.save_callgraph(run_id, "s4", ctx)
        if args.stop_after == "s4":
            return ScanOutcome(None, 0)

        # s4-only snapshot: the fallback denominator for a legacy (pre-6-tuple) s7 checkpoint
        s4_count = len(findings)

        # ── Steps 5+6+7 — independent progress + legacy-compatible S7 bundle ──
        # Reuse s7 only if s4 was restored too: a rerun s4 makes the cached s5/s6/s7 bundle stale.
        # s5/s6 below already refuse to reuse on top of a rerun s4; this closes the same gap for
        # s7's own checkpoint, which otherwise short-circuits s5+s6+s7 unconditionally.
        s7_ckpt = load_ckpt(ckpt_dir, run_id, "s7") if args.resume and s4_resumed else None
        legacy_s7_note = ""
        if s7_ckpt is None:
            # Reuse S5 only if S4 was restored too: a rerun S4 makes every downstream row stale
            s5_ckpt = (load_ckpt(ckpt_dir, run_id, "s5")
                       if args.resume and s4_resumed else None)
            s5_resumed = s5_ckpt is not None
            if s5_ckpt is None:
                _sp_start("s5", "enrich")
                with stage("Step 5 — Enrich (snippet + evidence refs, deterministic)",
                           n=5, total=11, stage_id="s5"), \
                        TOKENS.phase("s5-prefilter"):
                    findings, pre_dropped = s5.run(findings, ctx, cfg)
                save_ckpt(ckpt_dir, run_id, "s5", {
                    "findings": findings,
                    "pre_dropped": pre_dropped,
                })
                _save_stage_provenance("s5")
                _sp_done("s5", detail=f"kept={len(findings)} dropped={len(pre_dropped)}")
            else:
                findings = s5_ckpt["findings"]
                pre_dropped = s5_ckpt["pre_dropped"]
                _sp_done("s5", outcome="cached")
            if args.stop_after == "s5":
                return ScanOutcome(None, 0)

            # Reuse S6 only if S5 was restored: a fresh S5 may have produced a different input set
            s6_ckpt = (load_ckpt(ckpt_dir, run_id, "s6")
                       if args.resume and s5_resumed else None)
            if s6_ckpt is None:
                # Re-hydrate callgraph context from SQLite right before verification so s6 reasons over the latest persisted graph snapshot.
                ctx = _hydrate_ctx_callgraph_from_store(
                    run_id, ctx, "s4", "s3", "s2", "s1", "s0")
                _sp_start("s6", f"{_m('verify')}")
                with stage(f"Step 6 — Verify ({_m('verify')})", n=6, total=11,
                           stage_id="s6"), TOKENS.phase("s6-verify"):
                    if getattr(ctx, "ev_collection", None):
                        # EV armed: live-verifiable findings to the confirm-agent, rest stay static
                        from vvaharness.exploit_verification.verify import (
                            router as ev_router,
                        )
                        verified, dropped = ev_router.run(findings, ctx, cfg,
                                                          run_id=run_id)
                    else:
                        verified, dropped = s6_verify.run(findings, ctx, cfg, run_id=run_id)
                verified = _verified_order(verified)
                save_ckpt(ckpt_dir, run_id, "s6", {
                    "verified": verified,
                    "dropped": dropped,
                })
                _save_stage_provenance("s6")
                _sp_done("s6", detail=f"verified={len(verified)} dropped={len(dropped)}")
            else:
                # Sorted here too, so a pre-sort checkpoint resumes in a fresh run's order
                verified = _verified_order(s6_ckpt["verified"])
                dropped = s6_ckpt["dropped"]
                _sp_done("s6", outcome="cached")
            if args.stop_after == "s6":
                return ScanOutcome(None, 0)
            # Ensure s7 semantic dedup sees the latest sqlite-backed callgraph context before making root-cause grouping decisions.
            ctx = _hydrate_ctx_callgraph_from_store(run_id, ctx,
                                                    "s4", "s3", "s2", "s1", "s0")
            _sp_start("s7", f"{_m('dedup')}")
            with stage(f"Step 7 — Dedup ({_m('dedup')})", n=7, total=11,
                       stage_id="s7"), TOKENS.phase("s7-dedup"):
                canonical, dup_dropped = s7_dedup.run(verified, cfg, ctx=ctx)
            _sp_done("s7", detail=f"canonical={len(canonical)} dup_dropped={len(dup_dropped)}")
            _prune_ev_replays(run_id, canonical, ctx)
            # 6th member: the post-s5 count, so a --resume runs the ledger check without s5
            s5_out_count = len(findings)
            save_ckpt(ckpt_dir, run_id, "s7",
                      (pre_dropped, verified, dropped, canonical, dup_dropped, s5_out_count))
            _save_stage_provenance("s7")
            _resume_cmd = (f"vvaharness scan --repo {shlex.quote(str(repo))} "
                          f"--config {shlex.quote(str(args.config))} --resume")
            if application_id:
                _resume_cmd += f" --application-id {shlex.quote(application_id)}"
            console.write(f"  [ckpt] s7 saved (run_id {run_id}); resume with: {_resume_cmd}")
        elif len(s7_ckpt) == 6:
            pre_dropped, verified, dropped, canonical, dup_dropped, s5_out_count = s7_ckpt
            _sp_done("s5", outcome="cached")
            _sp_done("s6", outcome="cached")
            _sp_done("s7", outcome="cached")
        elif len(s7_ckpt) == 5:
            pre_dropped, verified, dropped, canonical, dup_dropped = s7_ckpt
            # Predates the 6th member: ledger check suppressed, but the s5 drop audit IS present
            s5_out_count = None
            legacy_s7_note = ("s5 post-enrich count unavailable for the finding "
                              "ledger balance check (legacy checkpoint)")
            _sp_done("s5", outcome="cached")
            _sp_done("s6", outcome="cached")
            _sp_done("s7", outcome="cached")
        else:  # legacy 4-tuple checkpoint (pre_dropped not stored)
            verified, dropped, canonical, dup_dropped = s7_ckpt
            pre_dropped = []
            s5_out_count = None
            # FIX-3: no S5 drop audit in this row and no post-enrich count; the report must say so
            legacy_s7_note = "s5 drop audit unavailable (legacy checkpoint)"
            _sp_done("s5", outcome="cached")
            _sp_done("s6", outcome="cached")
            _sp_done("s7", outcome="cached")
        # Honour --stop-after s5/s6 even on a --resume: the in-branch early-returns above are skipped when a combined s5+6+7 checkpoint is loaded.
        if args.stop_after in ("s5", "s6"):
            return ScanOutcome(None, 0)
        _enrich_findings(canonical, app_info, path_prefix=path_prefix)
        all_dropped = pre_dropped + dropped + dup_dropped
        # raw_findings_count redefined: the s4-only snapshot undercounts (s5 mints rows after it)
        raw_count = s5_out_count if s5_out_count is not None else s4_count
        if s5_out_count is not None:
            ledger_msg = _ledger_imbalance(s5_out_count, verified, dropped)
            if ledger_msg:
                log.warning(Event.LEDGER_IMBALANCE, detail=ledger_msg)
                # recovered=True: an accounting invariant, not transport; no VVAH-E0xx code for it
                _errlog.log("s6-verify", repo_name, ledger_msg, recovered=True)
        _store.save_callgraph(run_id, "s7", ctx)
        if args.stop_after == "s7":
            return ScanOutcome(None, 0)

        # Ensure chain analysis sees the latest sqlite-backed callgraph context for reachability reasoning and exploit-chain assembly.
        ctx = _hydrate_ctx_callgraph_from_store(run_id, ctx,
                                                "s4", "s3", "s2", "s1", "s0")
        # Reuse s8 only if s7 was restored too: a rerun s7 (new canonical findings, or a re-run
        # s2 re-deriving threats_without_unit) makes the cached FinalReport stale
        s7_resumed = s7_ckpt is not None
        report: FinalReport | None = (load_ckpt(ckpt_dir, run_id, "s8")
                                      if args.resume and s7_resumed else None)
        if report is None:
            end_ts = _metrics.now_iso()
            fp = sum(1 for d in dropped if d.reason == "FALSE_POSITIVE")
            # TRUE_POSITIVE verdicts, not len(verified): EV keeps some the static verifier rejected
            true_pos, discovered_tp, clone_tp, ev_rescued = _verified_counts(verified)
            metrics = _metrics.build(
                ctx, manifest,
                repo_name=repo_name, start_ts=start_ts, end_ts=end_ts,
                raw_findings=raw_count, true_pos=true_pos,
                false_pos=fp, duplicates=len(dup_dropped),
                discovered_tp=discovered_tp, clone_tp=clone_tp, ev_rescued=ev_rescued,
                unit_outcomes=unit_outcomes,
                external_input=external_input,
                role_models=_scan_role_models, pricing=_scan_pricing,
            )
            _sp_start("s8", f"{_m('chain')}")
            with stage(f"Step 8 — Chain ({_m('chain')})", n=8, total=11,
                       stage_id="s8"), TOKENS.phase("s8-chain"):
                report = s8_chain.run(canonical, ctx, cfg,
                                  dropped=all_dropped,
                                  raw_findings_count=raw_count,
                                  metrics=metrics)
            # build() ran before s8, so its metrics miss s8's spend; re-snapshot before persisting
            _metrics.refresh_tokens(report.metrics, end_ts=_metrics.now_iso(),
                                    role_models=_scan_role_models, pricing=_scan_pricing)
            report.repo_name = repo_name
            report.threat_model = tm
            report.app_profile = app_profile
            report.threats_without_unit = manifest.threats_without_unit_for(tm)
            if getattr(cfg.output, "emit_unreachable_appendix", False):
                report.unreachable_files = manifest.unreachable_files
            # B9: pin HEAD so step 10 (now or later via remediate --from-report) can refuse on mismatch.
            report.git_sha = _head_sha(repo)
            save_ckpt(ckpt_dir, run_id, "s8", report)
            _save_stage_provenance("s8")
            _sp_done("s8", detail=f"findings={len(report.findings)} chains={len(report.chains)}")
        else:
            _sp_done("s8", outcome="cached")
        _store.save_callgraph(run_id, "s8", ctx)
        if legacy_s7_note and legacy_s7_note not in report.degraded_reason:
            # APPEND, never assign: S8 may own one. Flips `degraded` too, or renderers hide the note
            report.degraded_reason = (f"{report.degraded_reason}; {legacy_s7_note}"
                                      if report.degraded_reason else legacy_s7_note)
            report.degraded = True

        # E5: an earlier stage's error starves downstream too; append-once keeps --resume idempotent
        _starved: list[str] = []
        for _stage_id in ("s2", "s4", "s6"):
            _rec = STAGES.snapshot().get(_stage_id)
            if not _rec or _rec.get("outcome") != "error":
                continue
            _starved.append(_stage_id)
            _msg = _errlog.last_message_for_stage(_stage_id)
            _clause = (f"{_stage_id} failed: {redact(_msg)}" if _msg
                      else f"{_stage_id} failed")
            if _clause not in report.degraded_reason:
                report.degraded_reason = (f"{report.degraded_reason}; {_clause}"
                                          if report.degraded_reason else _clause)
                report.degraded = True
        if _starved:
            log.warning(Event.INVESTIGATION_STAGE_FAILED, stages=_starved,
                        findings=len(report.findings))
            console.mark("fail", f"investigation incomplete: {', '.join(_starved)} failed. "
                                 f"The {len(report.findings)} finding(s) below are NOT a "
                                 f"trustworthy result for this repo -- a stage that should have "
                                 f"found work never ran to completion. See degraded_reason.",
                         lead="\n")

        # s4 can halt early and still return normally, so the E5 check above never fires; catch it off the per-unit outcomes instead.
        _n_halted = sum(1 for v in unit_outcomes.values() if v == "halted")
        if _n_halted:
            _clause = (f"s4 halted early: {_n_halted} unit(s) not analyzed "
                      "(expired/invalid credentials or a broken proxy/TLS path)")
            if _clause not in report.degraded_reason:
                report.degraded_reason = (f"{report.degraded_reason}; {_clause}"
                                          if report.degraded_reason else _clause)
                report.degraded = True

        # A degraded report used to still exit 0; ORed into every ScanOutcome below at rem_rc/val_rc's precedence.
        degraded_rc = 1 if report.degraded else 0

        # Identity before persistence, deliberately: mint_case_ids asserts uniqueness across the report, and the id names a case directory, so a clash must stop the run before anything is written.
        _ids = mint_case_ids(report)
        console.write(f"  [case] {_ids['minted']} case id(s) minted, "
                      f"{_ids['preassigned']} already assigned"
                      + (f", {_ids['collisions']} bucket collision(s) disambiguated"
                         if _ids["collisions"] else ""))

        out_path.parent.mkdir(parents=True, exist_ok=True)
        # The typed result beside the rendering: the old MD round-trip lost refs and path fidelity
        findings_path = write_findings_json(report, repo)
        console.write(f"  [out] wrote {findings_path}")
        # emit_unreachable_appendix at BOTH ends: this gates RENDERING, the gate above populating
        md_text = redact(report.to_markdown(
            posture_channel=bool(knob(cfg, "output.posture_channel", True)),
            unreachable_appendix=bool(
                knob(cfg, "output.emit_unreachable_appendix", False))))
        out_path.write_text(md_text, encoding="utf-8")
        n_redacted = sum(getattr(redact, "last_counts", {}).values())
        console.write(f"  [out] wrote {out_path}"
                      + (f"  ({n_redacted} sensitive values masked)"
                         if n_redacted else ""))
        if args.stop_after == "s8":
            return ScanOutcome(out_path, len(report.findings), rem_rc or degraded_rc)

        s9_done = load_ckpt(ckpt_dir, run_id, "s9") if args.resume else None
        if s9_done is None or not sarif_path.exists():
            _sp_start("s9", "sarif")
            with stage(f"Step 9 — SARIF (app_id={application_id or '-'})",
                       n=9, total=11, stage_id="s9"):
                s9_sarif.run(report, sarif_path,
                             application_id=application_id, app_info=app_info,
                             cfg=cfg)
            console.write(f"  [out] wrote {sarif_path}")
            save_ckpt(ckpt_dir, run_id, "s9", str(sarif_path))
            _sp_done("s9", detail=f"sarif={sarif_path.name}")
        else:
            _sp_done("s9", outcome="cached")
        _store.save_callgraph(run_id, "s9", ctx)

        # Once per run: a successful upload is checkpointed so --resume does not re-send the pair
        ingest_done = load_ckpt(ckpt_dir, run_id, "ingest") if args.resume else None
        if ingest_done:
            console.write("  [ingest] already uploaded (checkpoint) - skipping")
        else:
            ok = _upload_to_ingest(
                out_path,
                sarif_path,
                repository_name=repo_name,
                application_id=application_id,
                cfg=cfg,
                cfg_dir=cfg_dir,
            )
            if ok:
                save_ckpt(ckpt_dir, run_id, "ingest", True)

        if args.stop_after == "s9":
            return ScanOutcome(out_path, len(report.findings), rem_rc or degraded_rc)

        # B3: runs INSIDE scan_repo() so the clone still exists; writes per-finding artefacts under <repo>/security-remediation/<slug>/, same layout as the standalone `vvaharness remediate` command.
        rem_cfg = getattr(cfg, "step_remediate", None)
        rem_on = bool(getattr(args, "remediate", False)
                      or getattr(rem_cfg, "enabled", False))

        if not (rem_on and report.findings):
            _sp_done("s10", outcome="disabled")
        else:
            rem_err = _remediate_preflight(cfg, args, repo, report)
            if rem_err:
                console.write(f"  [s10] DISABLED — {rem_err}")
                _errlog.log("s10.preflight", repo_name, RuntimeError(rem_err))
                _sp_done("s10", outcome="disabled")
            else:
                rem_progress: dict[str, int] = {}
                _sp_start("s10", f"{_m('remediate')}")
                with stage(f"Step 10 — Remediate ({_m('remediate')})",
                           n=10, total=11, stage_id="s10"), \
                        TOKENS.phase("s10-remediate"):
                    rem_rc = _run_remediation(report, repo, cfg, ckpt_dir, run_id,
                                              resume=args.resume,
                                              top=getattr(args, "top", None),
                                              report_md=out_path,
                                              progress=rem_progress)
                _sp_done("s10", detail=_progress_detail(
                    rem_progress, "attempted", "fixed", "not_fixed"))
                if rem_rc:
                    log.warning(Event.REMEDIATION_INCOMPLETE, exit_code=rem_rc)

        if args.stop_after == "s10":
            return ScanOutcome(out_path, len(report.findings), rem_rc or degraded_rc)

        # Initialised HERE, on the straight-line path: the disabled branches skip the call below
        val_rc = 0
        val_cfg = getattr(cfg, "step_validate", None)
        val_on = bool(getattr(val_cfg, "enabled", False))
        # `and report.findings`, like s10: else s11 finds no case on a clean repo and returns 1
        if not (val_on and report.findings):
            _sp_done("s11", outcome="disabled")
        else:
            val_err = _validate_preflight(cfg)
            if val_err:
                console.write(f"  [s11] DISABLED — {val_err}")
                _errlog.log("s11.preflight", repo_name, RuntimeError(val_err))
                _sp_done("s11", outcome="disabled")
            else:
                val_progress: dict[str, int] = {}
                _sp_start("s11", "validation")
                with stage("Step 11 — Validate (s11)", n=11, total=11,
                           stage_id="s11"), TOKENS.phase("s11-validate"):
                    val_rc = _run_validation(repo, cfg, config_path=args.config,
                                             resume=args.resume, report_md=out_path,
                                             progress=val_progress)
                _sp_done("s11", detail=_progress_detail(
                    val_progress, "validated", "passed", "failed"))
        if args.stop_after == "s11":
            # s10 first: a broken pipeline outranks a broken validation, so `or`, not max()/sum()
            return ScanOutcome(out_path, len(report.findings), rem_rc or val_rc or degraded_rc)

        elapsed = time.time() - t0
        console.write(f"\nDone in {elapsed:.0f}s. {len(report.findings)} verified "
                      f"findings ({len(report.dropped)} dropped), "
                      f"{len(report.chains)} chains.")
        m = report.metrics
        tok_p = m.prompt_tokens if m and m.prompt_tokens is not None else "unavailable"
        tok_c = m.completion_tokens if m and m.completion_tokens is not None else "unavailable"
        tok_t = m.total_tokens if m and m.total_tokens is not None else "unavailable"
        console.write(f"Tokens: prompt={tok_p}, completion={tok_c}, total={tok_t}")
        console.write(f"Report: {out_path}")

        print(md_text)
        return ScanOutcome(out_path, len(report.findings), rem_rc or val_rc or degraded_rc)
    finally:
        tracker.stop_live()
        if graph_handle:
            graph_handle.close()
        # Best effort: Windows can still hold the mapping briefly after close; gc sweeps the rest
        shutil.rmtree(graph_dir, ignore_errors=True)


def _run_remediation(report: FinalReport, repo: Path, cfg, ckpt_dir, run_id,
                     *, resume: bool = False, top: int | None = None,
                     report_md: Path | None = None,
                     progress: MutableMapping[str, int] | None = None) -> int:
    """Walk the verified findings one-by-one with the Remediation Agent, delegating to the same ``runner.process_targets`` the standalone ``vvaharness remediate`` command uses."""
    from vvaharness.remediation_agent.discovery import Layout
    from vvaharness.remediation_agent.options import RemediateOptions
    from vvaharness.remediation_agent.report_parser import REMEDIATION_DIR_NAME
    from vvaharness.remediation_agent.runner import process_targets
    from vvaharness.remediation_agent.select import (
        drop_non_main_channel,
        resolve_top,
        select_top_logged,
    )
    from vvaharness.remediation_agent.target import RemediationTarget

    rem_dir = repo / REMEDIATION_DIR_NAME
    rem_dir.mkdir(parents=True, exist_ok=True)

    # Top-N cap: profile's step_remediate.top_n_findings is the source of truth; --top N overrides it ad-hoc.
    eff_top = resolve_top(top, cfg)
    # Posture findings are filtered BEFORE the top-N cap, so they cannot take an app defect's slot
    selected = select_top_logged(
        drop_non_main_channel(report.findings, log_prefix="[s10]"),
        eff_top,
        score_of=lambda rf: rf.finding.cvss_score,
        log_prefix="[s10]")
    findings = [rf.finding for rf in selected]

    # The Anthropic and DeepAgents harnesses expose confined Edit/Write tools; via:openai remains read-only on the legacy dispatcher.
    _, _remediate_via, _ = resolve_model(cfg.models.remediate)
    if _remediate_via in ("cli", "sdk", "deepagents"):
        console.mark("warn", f"[s10] FIX MODE — about to EDIT source files in {repo}; "
                     f"rerun with --stop-after s9 to scan without modifying the target")
    else:
        console.mark("warn",
                     f"[s10] {_remediate_via} backend cannot edit files (no Edit/Write "
                     f"tool); fix mode errors per finding — use report-only or "
                     f"via:cli/sdk/deepagents")
    console.write(f"  [s10] remediating {len(findings)} finding(s) via Remediation Agent; "
                  f"artefacts → {rem_dir}")

    # Thread the scan's existing ckpt_dir/run_id through Layout so resume state is shared with the standalone command, and bind *report_md* so the combined report can't be redirected by a newest-wins glob.
    layout = Layout(rem_dir=rem_dir, ckpt_dir=ckpt_dir, run_id=run_id)
    opts = RemediateOptions(resume=resume, mode="fix")
    # This list is freshly built and ranked, so 1..N IS its display order (the standalone path keeps the report's own ordinals instead).
    targets = [RemediationTarget(finding=f, index=i)
               for i, f in enumerate(findings, start=1)]
    kwargs = {"progress": progress} if progress is not None else {}
    return process_targets(targets, layout=layout, cfg=cfg, repo_path=repo,
                           opts=opts, report=report_md, **kwargs)


def _run_validation(repo: Path, cfg, *, config_path: str, resume: bool = False,
                    report_md: Path | None = None,
                    progress: MutableMapping[str, int] | None = None) -> int:
    """Invoke the s11 validation package against the case records s10 left under security-remediation/, returning its exit code rather than discarding it."""
    from vvaharness.pipeline.stages.s11_validate import run as s11_run
    kwargs = {"progress": progress} if progress is not None else {}
    rc = s11_run(repo, cfg=cfg, config_path=config_path, resume=resume,
                 report_md=report_md, **kwargs)
    if rc != 0:
        log.warning(Event.VALIDATION_NONZERO_EXIT, exit_code=rc)
    return rc


def _progress_detail(progress: MutableMapping[str, int], *fields: str) -> str:
    """Format stable key/value counters for a stage-done progress record."""
    return " ".join(f"{field}={progress.get(field, 0)}" for field in fields)


def _remediate_preflight(cfg, args, repo: Path, report) -> str | None:
    """Hard checks before remediation may run; returns an error string (which DISABLES remediation, scan continues) or None to proceed."""
    rem = getattr(cfg.models, "remediate", None)
    if rem is None:
        return "models.remediate must be set"

    # Imported locally: vvaharness.util.environment reaches back into the validation CLI, which imports this package.
    from vvaharness.util.environment import _backend_credential_ok
    model_id, via, _ = resolve_model(rem)
    ready, detail = _backend_credential_ok(via, model_id, getattr(rem, "provider", None))
    if not ready:
        return f"models.remediate via:{via} — {detail}"

    # B9: refuse if the working tree has moved since the report was built (line numbers would be stale, patch lands on wrong code).
    cur = _head_sha(repo)
    if (report.git_sha and cur and report.git_sha != cur
            and not getattr(args, "force", False)):
        return (f"HEAD moved since scan ({report.git_sha[:8]} → "
                f"{cur[:8]}); pass --force to override")
    return None


def _validate_preflight(cfg: object) -> str | None:
    """Hard checks before in-scan s11 validation may run; returns an error string (which DISABLES validation, scan continues) or None to proceed. Symmetrical with ``_remediate_preflight``."""
    # Local import: see the note in _remediate_preflight.
    from vvaharness.util.environment import _backend_credential_ok
    from vvaharness.validation.config.validate_role import (
        normalize_validate_backend,
        validate_model_spec,
    )

    val = validate_model_spec(cfg)
    if val is None:
        return "models.validate.orchestrator must be set"

    model_id, via, _ = resolve_model(val)
    # Same routing the validate CLI applies, so this gate checks the credential for the backend s11 will actually use.
    via, provider = normalize_validate_backend(via, getattr(val, "provider", None))

    ready, detail = _backend_credential_ok(via, model_id, provider)
    return None if ready else f"models.validate.orchestrator via:{via} — {detail}"
