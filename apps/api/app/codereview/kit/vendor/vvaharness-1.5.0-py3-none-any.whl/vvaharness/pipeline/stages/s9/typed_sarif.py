# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 9's SARIF 2.1.0 emitter, built entirely from the typed ``FinalReport``."""
from __future__ import annotations

import json
from pathlib import Path

from vvaharness import __version__ as _PKG_VERSION
from vvaharness.models import FinalReport
from vvaharness.models.scan._render import _md_cell
from vvaharness.models.scan.findings import Finding, RankedFinding
from vvaharness.models.scan.report import finding_description_lines
from vvaharness.models.vocab import OFFENSIVE_LABELS, SEV_RANK
from vvaharness.pipeline.stages.s9.health import scan_health as _scan_health
from vvaharness.report.appcontext import AppInfo
from vvaharness.report.cvss import rating as _cvss_rating
from vvaharness.report.cvss import score_or_sentinel as _cvss_score
from vvaharness.report.cwe import cwe_for, cwe_label, cwe_name
from vvaharness.report.redact import redact_counts, redact_tree
from vvaharness.rules.cwe import norm_cwe
from vvaharness.util import console
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS

# Cross-artifact join: SARIF partialFingerprints <-> findings.json case_id <-> finding_case.json
FINGERPRINT_KEY = "vvaFindingId/v1"

# Ids the dup guard folded in: each twin is its own case, so the survivor publishes them to join
ALIAS_KEY = "aliasFindingIds"


def result_identifies(result, case_id: str) -> bool:
    """Whether *result* is the SARIF row for *case_id*, own fingerprint or folded alias."""
    if not case_id:
        return False
    prints = result.get("partialFingerprints") or {}
    if str(prints.get(FINGERPRINT_KEY, "")) == case_id:
        return True
    aliases = (result.get("properties") or {}).get(ALIAS_KEY) or []
    return case_id in aliases


def result_fingerprint(result) -> str:
    """The result's OWN join key (``partialFingerprints["vvaFindingId/v1"]``), or ""."""
    return str((result.get("partialFingerprints") or {}).get(FINGERPRINT_KEY, ""))


def record_result_block(result, case_id: str, block, *, key: str,
                        alias_key: str) -> bool:
    """Attach *block* under ``properties[key]``; True when it took the primary key."""
    # SARIF result is additionalProperties:false, so a block outside properties fails validation
    props = result.setdefault("properties", {})
    own = result_fingerprint(result)
    # A fingerprint-less row keeps the primary key, so loc/title fallback matching still resolves
    if not (own and case_id and own != case_id):
        props[key] = block
        return True
    aliases = props.get(alias_key)
    if not isinstance(aliases, dict):
        aliases = {}
        props[alias_key] = aliases
    aliases[case_id] = block
    return False


# uuid5(NAMESPACE_URL, "https://cwe.mitre.org/"); literal for cross-run joins, must stay RFC-4122
CWE_TAXONOMY_GUID = "ec480a2c-8267-5d90-affc-401687cd64b0"

_DEDUP_RELATED_MSG = ("Additional call site — collapsed during dedup; same "
                      "root cause as the primary location and needs the same "
                      "fix.")
_REF_RELATED_MSG = {
    "source": "Source — where untrusted input enters.",
    "sink": "Sink — where the tainted value is used unsafely.",
}


def _sarif_level(sev: str) -> str:
    return {"CRITICAL": "error", "HIGH": "error",
            "MEDIUM": "warning"}.get(sev, "note")


def _security_severity(sev: str, cvss_score: float) -> str:
    if cvss_score >= 0:
        return f"{cvss_score:.1f}"
    return {"CRITICAL": "9.0", "HIGH": "7.0",
            "MEDIUM": "4.0", "LOW": "0.1"}.get(sev, "0.0")


def _class_label(f: Finding) -> tuple[str | None, str]:
    """(effective CWE, class label) exactly as the MD renderer derives them."""
    # TRAP: widening CWE_NAMES reshapes ruleIds and reopens alerts; norm_cwe saves the taxonomy sort
    eff = norm_cwe(f.cwe) or cwe_for(None, f.vuln_class)
    nm = cwe_name(eff) if eff else ""
    label = ((f"{eff}: {nm}" if nm else eff) if eff else "") or f.vuln_class.value
    return eff, label


def _result_message(f: Finding, score: float) -> str:
    """The rendered ``message.text`` from *f* and its precomputed CVSS *score*."""
    score_txt = f" {score:.1f}" if score >= 0 else ""
    return _md_cell(f.title) + (f"  [CVSS{score_txt}: {f.cvss_vector}]"
                                if f.cvss_vector else "")


def _dup_result_key(f: Finding, eff: str | None,
                    msg: str) -> tuple[str, int, str, str, str, str]:
    """The duplicate-emit guard's key: what makes two results identical to a reader."""
    # channel and origin are legs: without them a CRITICAL folds into its posture or detector twin
    return (f.file or "unknown", f.line_start, eff or f.vuln_class.value,
            msg, f.channel or "main", f.origin or "")


def _survivor_rank(rf: RankedFinding) -> tuple[int]:
    """Sort key picking the twin a reader sees: strongest severity wins."""
    # Severity ranks, not first-wins: a LOW twin would ship level:note/0.1 and pass an error gate
    return (SEV_RANK.get(rf.severity, 9),)


def _section_description(i: int, rf: RankedFinding) -> str:
    """The SARIF ``description``: the finding's narrative lines, redacted and capped."""
    # Redact before the 4000-char cut, or cutting bisects a secret and ships its raw prefix
    desc, _ = redact_counts(
        "\n".join(finding_description_lines(i, rf)).strip())
    return desc[:4000] + "…" if len(desc) > 4000 else desc


def _ref_related_location(role: str, ref: str) -> dict:
    """A role-annotated relatedLocation from a ``file:line`` ref string."""
    uri, _, line = ref.rpartition(":")
    region: dict = {}
    if uri and line.isdigit():
        region = {"startLine": int(line)}
    else:
        uri = ref
    physical: dict = {"artifactLocation": {"uri": uri}}
    if region:
        physical["region"] = region
    return {
        "physicalLocation": physical,
        "message": {"text": _REF_RELATED_MSG[role]},
        "properties": {"role": role},
    }


def _taint_code_flow(source_ref: str, sink_ref: str) -> dict | None:
    """The source-to-sink taint path as a SARIF codeFlow, or None when neither ref exists."""
    steps = [_ref_related_location(role, ref)
             for role, ref in (("source", source_ref), ("sink", sink_ref)) if ref]
    if not steps:
        return None
    return {"threadFlows": [{"locations": [{"location": s, "importance": "essential"}
                                          for s in steps]}]}


def build_sarif(report: FinalReport, application_id: str | None,
                app_info: AppInfo | None, *, cfg=None) -> dict:
    """The SARIF 2.1.0 document for *report*, as an insertion-ordered dict."""
    # cfg is optional at every call site, so these fallbacks must track config._STEP_DEFAULTS
    dup_guard = knob(cfg, "step9.duplicate_result_guard", True)
    posture_channel = knob(cfg, "output.posture_channel", True)
    results = []
    rule_ids: list[str] = []          # distinct emitted ruleIds, in first-seen order
    rep_name: dict[str, str] = {}     # ruleId → first resolvable CWE name
    eff_cwes: list[str] = []          # effective CWE per finding (taxonomy input)
    rule_cwe: dict[str, str] = {}     # ruleId → first resolvable effective CWE, for the rule tag
    rule_sev: dict[str, str] = {}     # ruleId → highest result security-severity, for the rule
    # Recomputed from the vector (-1.0 sentinel), so a stale DTO cvss_score cannot skew ranking
    labels = [_class_label(rf0.finding) for rf0 in report.findings]
    scores = [_cvss_score(rf0.finding.cvss_vector) for rf0 in report.findings]
    msgs = [_result_message(rf0.finding, scores[k])
            for k, rf0 in enumerate(report.findings)]
    # Resolved BEFORE the loop or report order beats severity; aliases too, as a winner can be late
    dup_keys: list[tuple] = []
    winner_of: dict[tuple, int] = {}
    alias_ids: dict[int, list[str]] = {}
    # Seeded with every PRIMARY up front, so order cannot matter; path_prefix applied producer-side
    seen_dup_sites: set[tuple[str, int, str]] = set()
    if dup_guard:
        dup_keys = [_dup_result_key(rf0.finding, labels[k][0], msgs[k])
                    for k, rf0 in enumerate(report.findings)]
        ranks = [_survivor_rank(rf0) for rf0 in report.findings]
        for i0 in range(len(report.findings)):
            held = winner_of.get(dup_keys[i0])
            if held is None or ranks[i0] < ranks[held]:
                winner_of[dup_keys[i0]] = i0
        for i0, rf0 in enumerate(report.findings):
            won_by = winner_of[dup_keys[i0]]
            if won_by != i0 and rf0.finding.case_id:
                alias_ids.setdefault(won_by, []).append(rf0.finding.case_id)
            f0 = rf0.finding
            seen_dup_sites.add((f0.file or "unknown", f0.line_start,
                                labels[i0][0] or f0.vuln_class.value))
    for i, rf in enumerate(report.findings, 1):
        f = rf.finding
        sev = rf.severity.value.upper()
        if dup_guard and winner_of[dup_keys[i - 1]] != i - 1:
            # Skip BEFORE rules/taxa mutation; the twin's id is published on the survivor's aliases
            COUNTERS.bump("s9_sarif_dup_result_suppressed")
            continue
        eff_cwe, category = labels[i - 1]
        cvss_score = scores[i - 1]
        msg = msgs[i - 1]
        rule_id = category or sev.lower()
        if rule_id and rule_id not in rule_ids:
            rule_ids.append(rule_id)
        if rule_id and rule_id not in rep_name and eff_cwe:
            nm = cwe_name(eff_cwe)
            if nm:
                rep_name[rule_id] = nm
        if eff_cwe:
            eff_cwes.append(eff_cwe)
        props: dict = {
            "severity": sev.lower(),
            "security-severity": _security_severity(sev, cvss_score),
            "cvssRating": _cvss_rating(cvss_score if cvss_score >= 0
                                       else float(_security_severity(sev, cvss_score))),
            "category": category,
            "cvssVector": f.cvss_vector,
        }
        rule_cwe.setdefault(rule_id, eff_cwe)
        # String max would sort "9.0" above "10.0", so compare numerically.
        rule_sev[rule_id] = max(rule_sev.get(rule_id, "0.0"),
                                props["security-severity"], key=float)
        if eff_cwe:
            props["cwe"] = cwe_label(eff_cwe)
            props["cweId"] = eff_cwe
            nm = cwe_name(eff_cwe)
            if nm:
                props["cweName"] = nm
        if cvss_score >= 0:
            props["cvssScore"] = round(cvss_score, 1)
        if f.vsvs_score is not None:
            props["vulContextSeverityVector"] = f.vsvs_vector
            props["vulContextSeverityScore"] = round(f.vsvs_score, 1)
            props["vulContextSeverityRating"] = f.vsvs_rating
        if f.offensive_priority:
            _label = OFFENSIVE_LABELS.get(f.offensive_priority, "")
            props["offensivePriority"] = f.offensive_priority
            props["offensivePriorityLabel"] = _label
            # Markdown asterisks are deliberate: this matches the report line's tail verbatim
            props["offensivePriorityReason"] = f"{_label} | *{f.offensive_reason}*".strip()
        # No exploit-verification, confidence or votes keys: no stage produces a real value
        props["description"] = _section_description(i, rf)

        result: dict = {
            "ruleId": rule_id,
            "level": _sarif_level(sev),
            "message": {"text": msg},
            "locations": [{
                "physicalLocation": {
                    # Verbatim path: no _md_cell folding of backticks or pipes.
                    "artifactLocation": {"uri": f.file or "unknown"},
                    "region": {"startLine": f.line_start},
                }
            }],
            "properties": props,
        }
        if eff_cwe:
            result["taxa"] = [{
                "toolComponent": {"name": "CWE", "guid": CWE_TAXONOMY_GUID},
                "id": eff_cwe,
            }]
        related = []
        for d in f.duplicates:
            if dup_guard:
                # One key collapses own/sibling/earlier anchors; the role-annotated refs are exempt
                gkey = (d.file, d.line_start, eff_cwe or f.vuln_class.value)
                if gkey in seen_dup_sites:
                    COUNTERS.bump("s9_sarif_dup_site_deduped")
                    continue
                seen_dup_sites.add(gkey)
            region: dict = {"startLine": d.line_start}
            if d.line_end and d.line_end != d.line_start:
                region["endLine"] = d.line_end
            entry: dict = {
                "physicalLocation": {
                    "artifactLocation": {"uri": d.file},
                    "region": region,
                },
                "message": {"text": _DEDUP_RELATED_MSG},
            }
            meta = {k: v for k, v in (
                ("title", d.title),
                ("vulnClass", d.vuln_class.value),
                ("sourceRef", d.source_ref),
                ("sinkRef", d.sink_ref),
            ) if v}
            if meta:
                entry["properties"] = meta
            related.append(entry)
        if related:
            # After description so it serializes last, before the refs join: dup sites only
            props["dedupRelatedLocationCount"] = len(related)
        if (flow := _taint_code_flow(f.source_ref, f.sink_ref)) is not None:
            result["codeFlows"] = [flow]
        if related:
            result["relatedLocations"] = related
        if f.backfilled_refs:
            props["backfilledRefs"] = list(f.backfilled_refs)
        # Carried verbatim from the s6-stamped DTO field; s9 does no routing.
        if posture_channel:
            props["channel"] = f.channel or "main"
        if f.origin:
            # "detector" or "s6_discovered"; chunk_id is never emitted, so lineage is lost here
            props["origin"] = f.origin
        if (aliases := alias_ids.get(i - 1)):
            props[ALIAS_KEY] = aliases
        if cvss_score >= 0:
            # SARIF result.rank is 0.0-100.0, so the 0-10 CVSS base score scales up
            result["rank"] = round(cvss_score * 10.0, 1)
        if f.case_id:
            result["partialFingerprints"] = {FINGERPRINT_KEY: f.case_id}
        results.append(result)

    rules = []
    for rid in rule_ids:
        rule: dict = {"id": rid, "name": rid}
        if rid in rep_name:
            rule["shortDescription"] = {"text": rep_name[rid]}
        tags = ["security"]
        if rule_cwe.get(rid):
            tags.append(f"external/cwe/{rule_cwe[rid].lower()}")
        rule["properties"] = {"tags": tags, "security-severity": rule_sev[rid]}
        rules.append(rule)

    taxa = []
    for cid in sorted(set(eff_cwes), key=lambda c: int(c.split("-")[-1])):
        nm = cwe_name(cid)
        n = cid.split("-")[-1]
        taxon: dict = {
            "id": cid,
            "helpUri": f"https://cwe.mitre.org/data/definitions/{n}.html",
        }
        if nm:
            taxon["name"] = nm
            taxon["shortDescription"] = {"text": nm}
        taxa.append(taxon)
    taxonomy = {
        "guid": CWE_TAXONOMY_GUID,
        "name": "CWE",
        "organization": "MITRE",
        "shortDescription": {"text": "The MITRE Common Weakness Enumeration"},
        "informationUri": "https://cwe.mitre.org/",
        "taxa": taxa,
    }

    # One block: the checkpointed profile and CLI app_info can disagree and mislabel the report
    prof = report.app_profile
    run_props: dict = {"applicationId": (prof.application_id if prof else "")
                       or application_id or ""}
    if prof:
        run_props["cmdbSource"] = prof.source
        run_props["applicationName"] = prof.name
    elif app_info:
        run_props["cmdbSource"] = app_info.source
        run_props["applicationName"] = app_info.name

    run: dict = {
        "tool": {"driver": {
            "name": "Agentic SAST",
            "version": _PKG_VERSION,
            "rules": rules,
            "supportedTaxonomies": [{"guid": CWE_TAXONOMY_GUID}],
        }},
        "taxonomies": [taxonomy],
        "properties": run_props,
        "results": results,
    }
    # Health comes from the report, no sidecar, and is emitted on EVERY run for observability
    health = _scan_health(report)
    notifications = []
    for stg, n in sorted((health.get("errors_by_stage") or {}).items()):
        # "non-fatal" is a wording contract with the MD Scan Health section
        notifications.append({
            "level": "warning",
            "message": {"text": f"{stg}: {n} non-fatal error(s) logged"},
        })
    cf = int(health.get("chunks_failed", 0) or 0)
    if cf:
        notifications.append({
            "level": "warning",
            "message": {"text": f"{cf} deep-dive unit(s) failed or timed "
                                "out; their findings are absent"},
        })
    if health.get("degraded"):
        # Degradation means chain/narrative enrichment was unavailable, never missing ranking
        notifications.append({
            "level": "warning",
            "message": {"text": health.get("degraded_reason")
                        or "report degraded (no reason recorded)"},
        })
    truncated = int(health.get("threats_truncated", 0) or 0)
    if truncated:
        notifications.append({
            "level": "warning",
            "message": {"text": f"{truncated} threat(s) exceeded the step2.max_threats cap "
                                f"and were never investigated; threatsTotal counts only the "
                                f"{health['threats_total']} that remained"},
        })
    invocation: dict = {
        "executionSuccessful": bool(health.get("executionSuccessful", True)),
    }
    if notifications:
        invocation["toolExecutionNotifications"] = notifications
    run["invocations"] = [invocation]
    run_props["enrichmentUnavailable"] = bool(health.get("enrichment_unavailable"))
    run_props["deepdiveSkipped"] = bool(health.get("deepdive_skipped"))
    # exit-0-but-empty though executionSuccessful=true; always emitted (absence=older doc)
    run_props["hollow"] = bool(health.get("hollow"))
    # A THIRD question: coverage lost, not "degraded" or "hollow"; reason codes say which fired
    run_props["coverageDegraded"] = bool(health.get("coverage_degraded"))
    run_props["coverageDegradedReasons"] = list(
        health.get("coverage_degraded_reasons") or [])
    # Ranked threats S3 minted no unit for were never reviewed, so no finding is not an all-clear.
    # Always emitted: null = payload predates the field (as in findings.json), [] = full coverage
    run_props["threatsTotal"] = health["threats_total"]
    run_props["threatsWithoutUnit"] = health["threats_without_unit"]
    # threatsTotal is post-cap, so without these it reads as everything that was ever found
    run_props["threatsBeforeCap"] = int(health.get("threats_before_cap", 0) or 0)
    run_props["threatsTruncated"] = int(health.get("threats_truncated", 0) or 0)
    run_props["threatsPromoted"] = int(health.get("threats_promoted", 0) or 0)

    return {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [run],
    }


def write_sarif(report: FinalReport, sarif_path: Path,
                application_id: str | None, app_info: AppInfo | None,
                *, cfg=None) -> Path:
    """Build, redact and write the SARIF; returns the path written."""
    doc = build_sarif(report, application_id, app_info, cfg=cfg)
    with open(sarif_path, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(redact_tree(doc), indent=2))
        fh.write("\n")
    # The emitted count, not len(report.findings): the dup guard suppresses twins
    n_results = len(doc["runs"][0]["results"])
    console.write(f"  SARIF written: {sarif_path} ({n_results} results)")
    return sarif_path
