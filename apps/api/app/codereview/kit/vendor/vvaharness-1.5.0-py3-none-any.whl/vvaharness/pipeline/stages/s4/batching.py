# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Group units into shared sessions, preferring units whose files overlap."""

from __future__ import annotations

from vvaharness.models import InvestigationUnit, UnitSize


def _overlap(a: InvestigationUnit, b: InvestigationUnit) -> int:
    """How many files the two units have in common."""
    return len(set(a.files) & set(b.files))


def _best_partner(seed: list[InvestigationUnit],
                  pool: list[InvestigationUnit]) -> InvestigationUnit:
    """The pooled unit sharing most files with *seed*; ties break on risk then id."""
    seed_files = {f for u in seed for f in u.files}
    return min(pool, key=lambda u: (-len(seed_files & set(u.files)), u.risk_rank, u.id))


def plan_batches(units: list[InvestigationUnit], size: int) -> list[list[InvestigationUnit]]:
    """Partition *units* into batches of at most *size*, co-locating file-sharing units."""
    if size <= 1:
        return [[u] for u in units]
    ordered = sorted(units, key=lambda u: (u.risk_rank, u.id))
    # LARGE units run alone: a shared session re-sends every member's code every turn.
    large = [[u] for u in ordered if u.size == UnitSize.LARGE]
    pool = [u for u in ordered if u.size != UnitSize.LARGE]
    batches: list[list[InvestigationUnit]] = []
    while pool:
        batch = [pool.pop(0)]
        while pool and len(batch) < size:
            batch.append(pool.pop(pool.index(_best_partner(batch, pool))))
        batches.append(batch)
    return batches + large
