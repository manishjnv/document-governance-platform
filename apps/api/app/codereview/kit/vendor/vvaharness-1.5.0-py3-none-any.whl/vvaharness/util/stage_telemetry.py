# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Process-wide per-stage telemetry: what each pipeline stage did, and for how long."""
# PHASE_MAP is the COSTING key; an absent phase rolls to totals.unattributed; s11, and s6 when
# exploit verification ran, are cost_estimated
from __future__ import annotations

import threading
from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING, TypedDict, cast

from vvaharness.util.pricing import (
    ModelPricing,
    PricingTable,
    TokenBucket,
    bucket_cost_usd,
)

if TYPE_CHECKING:  # avoid a runtime util -> orchestrator import; hints only
    from vvaharness.orchestrator.checkpoints import StageProvenance

STAGE_IDS: tuple[str, ...] = ("s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7",
                              "s8", "s9", "s10", "s11")

PHASE_MAP: dict[str, tuple[str, str | None]] = {
    "s0-seed": ("s0", None),
    "s1-autoexclude": ("s1", "autoexclude"),
    "s1-preprocess": ("s1", "preprocess"),
    "s2-threatmodel": ("s2", "threatmodel"),
    "s3-decompose": ("s3", "decompose"),
    "s4-deepdive": ("s4", "deepdive"),
    "s5-prefilter": ("s5", "dedup"),
    "s6-verify": ("s6", "verify"),
    # One phase for all four EV roles, costed at the attacker's model (else judge, mapper,
    # classify: the attacker is optional); ev-replay has no manifest
    "s6-ev": ("s6", "exploit_verification.attacker"),
    "s7-dedup": ("s7", "dedup"),
    "s8-chain": ("s8", "chain"),
    "s10-remediate": ("s10", "remediate"),
    "remediation-agent-remediate": ("s10", "remediate"),
    "s11-validate": ("s11", "validate"),
}

STAGE_ROLES: dict[str, str | None] = {
    "s0": None,
    "s1": "preprocess",
    "s2": "threatmodel",
    "s3": "decompose",
    "s4": "deepdive",
    "s5": "dedup",
    "s6": "verify",
    "s7": "dedup",
    "s8": "chain",
    "s9": None,
    "s10": "remediate",
    "s11": "validate",
}

ESTIMATED_COST_STAGES: frozenset[str] = frozenset({"s11"})
# Roles costed at one model while their phase also carries other models' calls
ESTIMATED_COST_ROLES: frozenset[str] = frozenset({"exploit_verification.attacker"})
# The attacker is optional, but EV's other roles still spend under its phase: price at the next
_ROLE_FALLBACKS: dict[str, tuple[str, ...]] = {
    "exploit_verification.attacker": ("exploit_verification.judge",
                                      "exploit_verification.mapper",
                                      "exploit_verification.classify"),
}

_NOT_RUN = "not_run"
_RUNNING = "running"


class StageRecord(TypedDict):
    """One stage's recorded label, terminal outcome and wall-clock duration."""

    label: str
    outcome: str
    duration_sec: float | None


class TokenSnapshot(TypedDict, total=False):
    """The shape of ``TOKENS.snapshot()``."""

    prompt: int
    completion: int
    total: int
    calls: int
    calls_with_usage: int
    # Explicit-null completions coerced to 0; missing it here is how the composer once lost it
    completion_absent: int
    by_phase: dict[str, TokenBucket]


class UnattributedTokens(TypedDict):
    """Tokens from phases that map to no stage.

    Key parity with the per-stage token rows is deliberate and load-bearing:
    the manifest's reconciliation identity is ``Σ stages + unattributed =
    totals`` for EVERY token key. This bucket originally carried only
    prompt/completion/calls, so an unmapped phase with cache traffic (the
    preflight cache probe) left the manifest unreconcilable with itself — one
    campaign arm's stage rows summed to cache_write 3,838 against totals of
    9,180, and the 5,342-token gap was reportable nowhere.
    """

    prompt: int
    completion: int
    cache_read: int
    cache_write: int
    calls: int


class StageEntry(TypedDict):
    """One ``stages.<id>`` object in the run manifest."""

    label: str
    outcome: str
    duration_sec: float | None
    tokens: TokenBucket
    model: str | None
    cost_usd: float | None
    cost_estimated: bool
    # A CACHED stage's origin config_sha256 (None when fresh); compare to spot stale-config reuse
    cached_from_config_sha: str | None


class Totals(TypedDict):
    """The manifest's ``totals`` object."""

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    cache_read_tokens: int
    cache_write_tokens: int
    calls: int
    calls_with_usage: int
    # Anomaly counters, persisted because stderr is reclaimed and only the manifest survives
    completion_absent: int
    cache_unparsed_calls: int
    cost_usd: float | None
    unattributed: UnattributedTokens
    # Already in the five columns, so Σ stages + unattributed = totals holds across a cached run
    cached_carryover: TokenBucket


class PricingProvenance(TypedDict):
    """Which price table produced the costs, for reproducibility."""

    file: str
    sha256: str
    source: str


class PricingStatus(TypedDict):
    """Why manifest costs are available, estimated, or unknown."""

    status: str
    reason: str


class StageSection(TypedDict):
    """The manifest fields this module owns."""

    stages: dict[str, StageEntry]
    totals: Totals
    pricing: PricingProvenance | None
    pricing_status: PricingStatus


def _copy(record: StageRecord) -> StageRecord:
    return StageRecord(label=record["label"], outcome=record["outcome"],
                       duration_sec=record["duration_sec"])


class _StageRecorder:
    """Process-wide recorder of per-stage outcome and duration."""
    # Locked: stages never overlap, but a stage body can touch the recorder off the main thread.

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._stages: dict[str, StageRecord] = {}

    def start(self, stage_id: str, label: str = "") -> None:
        """Open *stage_id*; it stays ``running`` until ``done``/``mark``."""
        with self._lock:
            self._stages[stage_id] = StageRecord(label=label, outcome=_RUNNING,
                                                 duration_sec=None)

    def done(self, stage_id: str, *, outcome: str = "completed",
             duration_sec: float | None = None) -> None:
        """Close *stage_id* with its terminal outcome and measured duration."""
        with self._lock:
            record = self._stages.get(stage_id)
            if record is None:
                record = StageRecord(label="", outcome=outcome,
                                     duration_sec=None)
                self._stages[stage_id] = record
            record["outcome"] = outcome
            record["duration_sec"] = duration_sec

    def mark(self, stage_id: str, outcome: str, label: str = "") -> None:
        """Record a stage that ran no timed body (cached/skipped/disabled)."""
        with self._lock:
            self._stages[stage_id] = StageRecord(label=label, outcome=outcome,
                                                 duration_sec=None)

    def reset(self) -> None:
        """Drop every record — one scan's telemetry per manifest."""
        with self._lock:
            self._stages = {}

    def snapshot(self) -> dict[str, StageRecord]:
        """Copy the records, ordered s0-first with unknown ids appended."""
        with self._lock:
            known = [s for s in STAGE_IDS if s in self._stages]
            extra = [s for s in self._stages if s not in STAGE_IDS]
            return {s: _copy(self._stages[s]) for s in known + extra}


STAGES = _StageRecorder()


class _CachedProvenanceRecorder:
    """Process-wide record of a ``--resume``'d stage's ACTUAL model/via/config/token provenance."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._entries: dict[str, Mapping[str, object]] = {}

    def record(self, stage_id: str, provenance: Mapping[str, object]) -> None:
        with self._lock:
            self._entries[stage_id] = provenance

    def reset(self) -> None:
        with self._lock:
            self._entries = {}

    def snapshot(self) -> dict[str, Mapping[str, object]]:
        with self._lock:
            return dict(self._entries)


CACHED_PROVENANCE = _CachedProvenanceRecorder()


def _sum_buckets(buckets: Sequence[TokenBucket]) -> TokenBucket:
    return TokenBucket(
        prompt=sum(b.get("prompt", 0) for b in buckets),
        completion=sum(b.get("completion", 0) for b in buckets),
        cache_read=sum(b.get("cache_read", 0) for b in buckets),
        cache_write=sum(b.get("cache_write", 0) for b in buckets),
        calls=sum(b.get("calls", 0) for b in buckets),
    )


def _has_tokens(bucket: TokenBucket) -> bool:
    return (bucket.get("prompt", 0) + bucket.get("completion", 0)
            + bucket.get("cache_read", 0)) > 0


def _group_phases(
    token_snap: TokenSnapshot,
) -> tuple[dict[str, list[tuple[str | None, TokenBucket]]], UnattributedTokens]:
    by_stage: dict[str, list[tuple[str | None, TokenBucket]]] = {}
    unattributed = UnattributedTokens(prompt=0, completion=0, cache_read=0,
                                      cache_write=0, calls=0)
    for phase, bucket in token_snap.get("by_phase", {}).items():
        mapped = PHASE_MAP.get(phase)
        if mapped is None:
            # Copy EVERY key `_sum_buckets` reads; dropping cache fields desynced _totals
            unattributed["prompt"] += bucket.get("prompt", 0)
            unattributed["completion"] += bucket.get("completion", 0)
            unattributed["cache_read"] += bucket.get("cache_read", 0)
            unattributed["cache_write"] += bucket.get("cache_write", 0)
            unattributed["calls"] += bucket.get("calls", 0)
            continue
        stage_id, role = mapped
        by_stage.setdefault(stage_id, []).append((role, bucket))
    return by_stage, unattributed


def stage_token_bucket(step_id: str, token_snap: TokenSnapshot) -> TokenBucket:
    """Every phase ``PHASE_MAP`` attributes to *step_id*, summed into one bucket."""
    by_stage, _ = _group_phases(token_snap)
    return _sum_buckets([bucket for _, bucket in by_stage.get(step_id, [])])


def _resolve_model(role: str | None,
                   role_models: Mapping[str, str]) -> str | None:
    """The model id a stage's role resolves to."""
    if role is None:
        return None
    for r in (role, *_ROLE_FALLBACKS.get(role, ())):
        if role_models.get(r):
            return role_models[r]
    return None


def _rate_for(role: str | None, role_models: Mapping[str, str],
              pricing: PricingTable) -> ModelPricing | None:
    model_id = _resolve_model(role, role_models)
    if model_id is None:
        return None
    return pricing.models.get(model_id)


def _stage_cost(phases: Sequence[tuple[str | None, TokenBucket]],
                role_models: Mapping[str, str],
                pricing: PricingTable | None) -> float | None:
    """Sum a stage's per-phase costs, or ``None`` when it cannot be priced."""
    if pricing is None:
        return None
    total = 0.0
    for role, bucket in phases:
        rate = _rate_for(role, role_models, pricing)
        if rate is not None:
            # The table's own multipliers, so OpenAI models are not costed at Anthropic's ratios.
            total += bucket_cost_usd(bucket, rate, pricing.cache_defaults)
        elif _has_tokens(bucket):
            return None
    return total


def _provenance_cost(model_id: str | None, bucket: TokenBucket,
                     pricing: PricingTable | None) -> float | None:
    """Cost a cached stage's OWN historical bucket against its OWN recorded model id."""
    if pricing is None:
        return None
    rate = pricing.models.get(model_id) if model_id else None
    if rate is not None:
        return bucket_cost_usd(bucket, rate, pricing.cache_defaults)
    return None if _has_tokens(bucket) else 0.0


def _stage_entry(stage_id: str, record: StageRecord | None,
                 phases: Sequence[tuple[str | None, TokenBucket]],
                 role_models: Mapping[str, str],
                 pricing: PricingTable | None,
                 provenance: StageProvenance | None = None) -> StageEntry:
    role = STAGE_ROLES.get(stage_id)
    if provenance is not None:
        # A cached stage reports what it was ACTUALLY produced under, not this run's role_models
        model = provenance.get("model")
        # cast: a JSON-round-tripped dict, safe because _sum_buckets uses .get() for every key
        raw_tokens = cast(TokenBucket, provenance.get("tokens") or {})
        # A stage can be cached AND partly live (s1 autoexclude): ADD, never replace, or totals skew
        live_tokens = _sum_buckets([bucket for _, bucket in phases])
        tokens = _sum_buckets([raw_tokens, live_tokens])
        cached_cost = _provenance_cost(model, raw_tokens, pricing)
        live_cost = _stage_cost(phases, role_models, pricing)
        cost = (None if cached_cost is None or live_cost is None
                else cached_cost + live_cost)
        cached_from_config_sha = provenance.get("config_sha256")
    else:
        model = _resolve_model(role, role_models)
        tokens = _sum_buckets([bucket for _, bucket in phases])
        cost = _stage_cost(phases, role_models, pricing)
        cached_from_config_sha = None
    return StageEntry(
        label=record["label"] if record else "",
        outcome=record["outcome"] if record else _NOT_RUN,
        duration_sec=record["duration_sec"] if record else None,
        tokens=tokens,
        model=model,
        cost_usd=cost,
        cost_estimated=(stage_id in ESTIMATED_COST_STAGES
                        or any(r in ESTIMATED_COST_ROLES and _has_tokens(b)
                               for r, b in phases)),
        cached_from_config_sha=cached_from_config_sha,
    )


def _total_cost(stages: Mapping[str, StageEntry]) -> float | None:
    costs = [entry["cost_usd"] for entry in stages.values()]
    priced = [c for c in costs if c is not None]
    if len(priced) != len(costs):
        return None
    return sum(priced)


def _totals(token_snap: TokenSnapshot, stages: Mapping[str, StageEntry],
            unattributed: UnattributedTokens,
            cached_provenance: Mapping[str, StageProvenance]) -> Totals:
    by_phase = token_snap.get("by_phase", {})
    combined = _sum_buckets(list(by_phase.values()))
    # cache_unparsed is NOT in TokenBucket: it counts CALLS, and pricing must never read it
    cache_unparsed_calls = sum(
        b.get("cache_unparsed", 0) for b in by_phase.values()
        if isinstance(b.get("cache_unparsed"), int))
    # Read the envelope, NOT stages[id]["tokens"]: a partly-cached stage would double-count
    cached_carryover = _sum_buckets([
        cast(TokenBucket, prov.get("tokens") or {})
        for prov in cached_provenance.values()
    ])
    return Totals(
        prompt_tokens=token_snap.get("prompt", 0) + cached_carryover["prompt"],
        completion_tokens=(token_snap.get("completion", 0)
                           + cached_carryover["completion"]),
        total_tokens=(token_snap.get("total", 0) + cached_carryover["prompt"]
                     + cached_carryover["completion"]),
        cache_read_tokens=(combined.get("cache_read", 0)
                          + cached_carryover["cache_read"]),
        cache_write_tokens=(combined.get("cache_write", 0)
                           + cached_carryover["cache_write"]),
        calls=token_snap.get("calls", 0) + cached_carryover["calls"],
        calls_with_usage=token_snap.get("calls_with_usage", 0),
        completion_absent=token_snap.get("completion_absent", 0),
        cache_unparsed_calls=cache_unparsed_calls,
        cost_usd=_total_cost(stages),
        unattributed=unattributed,
        cached_carryover=cached_carryover,
    )


def _provenance(pricing: PricingTable | None) -> PricingProvenance | None:
    if pricing is None:
        return None
    return PricingProvenance(file=pricing.path, sha256=pricing.sha256,
                             source=pricing.source)


def _pricing_status(stages: Mapping[str, StageEntry],
                    pricing: PricingTable | None) -> PricingStatus:
    if pricing is None:
        return {"status": "unavailable", "reason": "no pricing table configured"}
    unpriced = sorted({entry["model"] for entry in stages.values()
                       if entry["cost_usd"] is None and entry["model"]})
    if unpriced:
        return {
            "status": "incomplete",
            "reason": "pricing missing for model(s): " + ", ".join(unpriced),
        }
    return {"status": "available", "reason": "pricing table applied"}


def _ordered_stage_ids(stage_snap: Mapping[str, StageRecord],
                       by_stage: Mapping[str, object]) -> list[str]:
    present = set(stage_snap) | set(by_stage)
    known = [s for s in STAGE_IDS if s in present]
    extra = [s for s in stage_snap if s not in STAGE_IDS]
    return known + extra


def compose_stage_section(stage_snap: Mapping[str, StageRecord],
                          token_snap: TokenSnapshot,
                          role_models: Mapping[str, str],
                          pricing: PricingTable | None,
                          cached_provenance: Mapping[str, StageProvenance] | None = None,
                          ) -> StageSection:
    """Build the manifest's ``stages``/``totals``/``pricing`` fields."""
    # Pure: every input is a snapshot; cost_usd is null for an unpriced model, and so are totals
    by_stage, unattributed = _group_phases(token_snap)
    cached_provenance = cached_provenance or {}
    stages = {
        stage_id: _stage_entry(stage_id, stage_snap.get(stage_id),
                               by_stage.get(stage_id, []), role_models, pricing,
                               cached_provenance.get(stage_id))
        for stage_id in _ordered_stage_ids(stage_snap, by_stage)
    }
    return StageSection(stages=stages,
                        totals=_totals(token_snap, stages, unattributed,
                                       cached_provenance),
                        pricing=_provenance(pricing),
                        pricing_status=_pricing_status(stages, pricing))
