# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""S11's fact tools and report channel for the Claude harness, as in-process MCP tools."""

# No native schema here: AgentDefinition has no per-subagent field, --json-schema is session-scoped

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from vvaharness.backends.harness.models import MCP_TOOL_PREFIX

if TYPE_CHECKING:
    from collections.abc import Sequence

    from claude_agent_sdk import SdkMcpTool
    from claude_agent_sdk.types import McpSdkServerConfig

    from vvaharness.backends.harness.models import FactToolSpec

#: MCP server name; tools arrive as ``mcp__facts__X``, admitted via permissions.py MCP_TOOL_PREFIX
SERVER_NAME = "facts"
TOOL_PREFIX = f"{MCP_TOOL_PREFIX}{SERVER_NAME}__"

#: Report-submission tool name; not a fact tool but the validated channel for a persona verdict
SUBMIT_TOOL = "SubmitPersonaReport"


def mcp_name(bare: str) -> str:
    """The wire name the model sees for a bridged tool."""
    return TOOL_PREFIX + bare


def rewrite_tool_names(names: Sequence[str] | None,
                       bridged: Sequence[str]) -> list[str] | None:
    """Rewrite bare *bridged* names in a tool list to their ``mcp__facts__`` form."""
    # TRAP: a bare grant matches nothing, so the persona loses the tool; None in/out = no override
    if names is None:
        return None
    bridged_set = set(bridged)
    return [mcp_name(n) if n in bridged_set else n for n in names]


class PersonaReportCollector:
    """Holds the reports personas submit during one session, newest-wins per persona."""

    def __init__(self) -> None:
        """Start empty; one collector serves exactly one session."""
        self._reports: list[dict] = []

    def add(self, report: dict) -> None:
        """Record one validated report, replacing an earlier one from the same persona."""
        key = (report.get("persona"), report.get("tracking_id"))
        self._reports = [
            r for r in self._reports
            if (r.get("persona"), r.get("tracking_id")) != key
        ]
        self._reports.append(report)

    @property
    def reports(self) -> list[dict]:
        """The collected reports, in submission order."""
        return list(self._reports)

    def __len__(self) -> int:
        """How many reports have been submitted."""
        return len(self._reports)


def _content(text: str, *, is_error: bool = False) -> dict[str, Any]:
    """An MCP tool result payload."""
    payload: dict[str, Any] = {"content": [{"type": "text", "text": text}]}
    if is_error:
        payload["is_error"] = True
    return payload


def _serialize(result: object) -> str:
    """Render a fact-tool result as text, JSON when structured."""
    if isinstance(result, str):
        return result
    try:
        return json.dumps(result, default=str)
    except (TypeError, ValueError):
        return str(result)


def _fact_tool(spec: FactToolSpec, sdk_tool: Any) -> SdkMcpTool[Any]:
    """Wrap one fact spec as an SDK tool; *sdk_tool* is the SDK's ``tool`` decorator."""
    @sdk_tool(spec.name, spec.description, dict(spec.input_schema))
    async def _handler(args: dict[str, Any]) -> dict[str, Any]:
        try:
            # Off-loop so a large diff cannot stall the event loop draining the CLI's stream.
            import asyncio  # noqa: PLC0415 — local to the handler

            result = await asyncio.to_thread(spec.fn, **dict(args))
        except Exception as exc:
            return _content(f"{type(exc).__name__}: {exc}", is_error=True)
        return _content(_serialize(result))

    return _handler


def _submit_tool(report_model: type, collector: PersonaReportCollector,
                 sdk_tool: Any) -> SdkMcpTool[Any]:
    """Build the report-submission tool, validating on submit into *collector*."""
    # Must stay lazy: options.py imports rewrite_tool_names from here, so a top-level import cycles
    from vvaharness.backends.harness.claude.options import (  # noqa: PLC0415 — import cycle
        _sanitize_schema,
    )

    @sdk_tool(SUBMIT_TOOL,
              f"Submit your final {report_model.__name__}. Call this exactly "
              f"once, as your last action. The report is validated on "
              f"submission; if it is rejected, fix the named fields and call "
              f"this again.",
              _sanitize_schema(report_model.model_json_schema()))
    async def _submit(args: dict[str, Any]) -> dict[str, Any]:
        try:
            report = report_model.model_validate(dict(args))
        except Exception as exc:
            # Name the invalid fields so the persona can retry (deepagents just drops bad reports)
            return _content(
                f"Report rejected — not a valid {report_model.__name__}: {exc}. "
                f"Fix the fields named above and call {SUBMIT_TOOL} again.",
                is_error=True)
        collector.add(report.model_dump(mode="json"))
        return _content("Report accepted.")

    return _submit


def build_fact_tools(
    specs: Sequence[FactToolSpec], *, report_model: type | None = None,
) -> tuple[list[SdkMcpTool[Any]], list[str], PersonaReportCollector]:
    """Build the ``SdkMcpTool`` objects for *specs*, their wire names, and the collector."""
    from claude_agent_sdk import (  # noqa: PLC0415 — lazy: the SDK stays optional
        tool as sdk_tool,
    )

    collector = PersonaReportCollector()
    tools = [_fact_tool(spec, sdk_tool) for spec in specs]
    names = [mcp_name(spec.name) for spec in specs]

    if report_model is not None:
        tools.append(_submit_tool(report_model, collector, sdk_tool))
        names.append(mcp_name(SUBMIT_TOOL))

    return tools, names, collector


def build_fact_mcp(
    specs: Sequence[FactToolSpec], *, report_model: type | None = None,
) -> tuple[McpSdkServerConfig, list[str], PersonaReportCollector]:
    """Build the in-process MCP server for *specs*, plus its report collector."""
    from claude_agent_sdk import (  # noqa: PLC0415 — lazy: the SDK stays optional
        create_sdk_mcp_server,
    )

    tools, names, collector = build_fact_tools(specs, report_model=report_model)
    return create_sdk_mcp_server(SERVER_NAME, tools=tools), names, collector


#: Appended to each persona prompt on this backend only; the persona .md files are NOT edited
SUBMIT_PROMPT_SUFFIX = (
    "\n\n## Report submission (this run)\n\n"
    f"Submit your final report by calling the `{mcp_name(SUBMIT_TOOL)}` tool with the "
    "report object as its arguments. It is validated on submission and will tell you "
    "which fields to fix if it is rejected. Print the same report as a ```json block "
    "as well, so it is visible in the transcript.\n\n"
    "Your fact tools are named with an `mcp__facts__` prefix on this run: "
    "`mcp__facts__DiffTouched`, `mcp__facts__ChangedLines`, `mcp__facts__DiffImpactMap`, "
    "`mcp__facts__PatternScan`, `mcp__facts__TestInventory`."
)

__all__ = [
    "SERVER_NAME",
    "SUBMIT_PROMPT_SUFFIX",
    "SUBMIT_TOOL",
    "TOOL_PREFIX",
    "PersonaReportCollector",
    "build_fact_mcp",
    "build_fact_tools",
    "mcp_name",
    "rewrite_tool_names",
]
