# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Resolves a profile's ``sdk.plugins`` block into the one PluginSet a scan installs."""
from __future__ import annotations

from collections.abc import Callable
from importlib import import_module

from vvaharness.sdk.plugins import PluginSet, VvahPlugin
from vvaharness.util import logs
from vvaharness.util.config import knob

log = logs.get_logger(__name__)

#: Only these names are loadable; a profile naming an arbitrary module is deliberately refused,
#: since that would make config a code-execution surface. The targets are resolved lazily so that
#: importing the SDK does not import every plugin, and so a plugin may import the SDK back.
BUILTIN_PLUGINS: dict[str, str] = {
    "semgrep": "vvaharness.plugins.semgrep:SemgrepPlugin",
}


def _plugin_specs(cfg: object) -> tuple[dict, ...]:
    """The profile's ``sdk.plugins`` entries, each a mapping with at least a ``name``."""
    raw = knob(cfg, "sdk.plugins", []) or []
    if not isinstance(raw, (list, tuple)):
        raise TypeError("sdk.plugins must be a list of mappings")
    specs = []
    for entry in raw:
        if not isinstance(entry, dict) or not entry.get("name"):
            raise TypeError(f"each sdk.plugins entry needs a name: {entry!r}")
        specs.append(dict(entry))
    return tuple(specs)


def _built(spec: dict) -> VvahPlugin:
    """One plugin built from its profile entry, with ``name`` consumed as the lookup key."""
    options = dict(spec)
    name = options.pop("name")
    target = BUILTIN_PLUGINS.get(name)
    if target is None:
        raise ValueError(f"unknown sdk plugin {name!r}; known: {sorted(BUILTIN_PLUGINS)}")
    factory = _resolve(target)
    for key in ("configs", "rulesets"):
        if key in options:
            options[key] = tuple(options[key] or ())
    return factory(**options)


def _resolve(target: str) -> Callable[..., VvahPlugin]:
    """The class behind one BUILTIN_PLUGINS entry, imported only when that plugin is configured."""
    module_name, _, attr = target.partition(":")
    return getattr(import_module(module_name), attr)


def load_plugin_set(cfg: object) -> PluginSet:
    """The configured plugins, already validated and ordered; empty when none are configured."""
    specs = _plugin_specs(cfg)
    if not specs:
        return PluginSet()
    plugins = PluginSet([_built(spec) for spec in specs])
    log.info("sdk plugins loaded: %s", ", ".join(plugins.names))
    return plugins


__all__ = ["BUILTIN_PLUGINS", "load_plugin_set"]
