# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Locating the `claude` binary, probing its capabilities, and formatting its errors."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path

from vvaharness.report.redact import redact
from vvaharness.util import console, logs
from vvaharness.util.events import Event

# Token accounting is shared with the SDK backend (util/tokens.py); re-exported for legacy imports

log = logs.get_logger(__name__)




def _which_abs(*names: str) -> str | None:
    """shutil.which(), but reject a hit sourced from Windows's implicit cwd search (CWE-427).

    That search prepends os.curdir to the lookup path unconditionally, so a cwd-planted
    executable (e.g. a hostile scanned repo's claude.cmd) resolves through the curdir
    entry and joins to a RELATIVE path — never the absolute path a real PATH directory
    produces. Rejecting non-absolute hits removes the forged match without touching a
    legitimate install.
    """
    for name in names:
        hit = shutil.which(name)
        if hit and Path(hit).is_absolute():
            return hit
    return None


def _find_claude_cmd() -> list[str]:
    """Resolve the claude CLI to an absolute-path command list, avoiding bare-name PATH resolution."""
    override = os.environ.get("VVAHARNESS_CLAUDE_BINARY")
    if override:
        if Path(override).is_file():
            console.write(f"  [cli] using VVAHARNESS_CLAUDE_BINARY={override}")
            return [override]
        log.warning(Event.CLI_BINARY_OVERRIDE_MISSING, path=override)
    if os.name == "nt":
        # Belt-and-suspenders for the bare-name fallback below: this tells CreateProcess
        # (which subprocess uses) to drop the current directory from its own search order
        # for any bare command name, on this process and everything it spawns (CWE-427).
        os.environ.setdefault("NoDefaultCurrentDirectoryInExePath", "1")
        cmd_path = _which_abs("claude", "claude.cmd", "claude.CMD")
        if cmd_path:
            pkg = Path(cmd_path).parent / "node_modules" / "@anthropic-ai" / "claude-code"
            # ≥2.1.x ships a native binary — call it directly, no Node needed.
            native = pkg / "bin" / "claude.exe"
            if native.exists():
                return [str(native)]
            # ≤2.0.x: Node + cli.js
            cli_js = pkg / "cli.js"
            if cli_js.exists():
                node = _which_abs("node") or "node"
                return [node, str(cli_js)]
            # Last resort: the .cmd shim by full path — a bare "claude" fails WinError 2 on Windows.
            return [cmd_path]
        log.warning("'claude' not found on PATH; using bare name")
        return ["claude"]
    # Unix: pin to the absolute path PATH resolves to, instead of a bare name.
    resolved = shutil.which("claude")
    if resolved:
        return [resolved]
    log.warning("'claude' not found on PATH; using bare name")
    return ["claude"]


# Resolve once at import time
_CLAUDE_CMD = _find_claude_cmd()

# MOST RESTRICTIVE FIRST; `bypassPermissions` deliberately ABSENT — it would unrestrict the host
_PERMISSION_FALLBACKS = ("dontAsk", "manual", "default", "acceptEdits")

_caps_cache: dict | None = None

_PROBE_SENTINELS = ("--vvah-capability-probe-aaa", "--vvah-capability-probe-bbb")


def _cli_output(*args: str, timeout: int = 20) -> str:
    """Both streams of one `claude` invocation, or "" when it could not be run at all."""
    try:
        r = subprocess.run([*_CLAUDE_CMD, *args], capture_output=True, text=True,
                           timeout=timeout, stdin=subprocess.DEVNULL)
    except Exception:
        return ""
    return (r.stdout or "") + (r.stderr or "")


def _resume_capable() -> bool:
    """True once the installed `claude` build is >= 2.1.286 (fixed `--resume` after a kill)."""
    # Both streams, not just stdout's first line: a banner or notice line printed before the
    # version (same tolerance the --help probe uses) must not downgrade a capable CLI to replay.
    m = re.search(r"(\d+)\.(\d+)\.(\d+)", _cli_output("--version"))
    if not m:
        return False
    return tuple(int(g) for g in m.groups()) >= (2, 1, 286)


def _parse_probe(flag: str) -> str:
    """Run *flag* behind two sentinels so argument parsing always fails, and return what it said."""
    return _cli_output(flag, *_PROBE_SENTINELS, "-p", "x", "--output-format", "json", timeout=30)


def _flag_accepted(flag: str, help_text: str) -> bool:
    """True when this CLI accepts *flag*, trusting --help only as positive evidence."""
    if flag in help_text:
        return True
    if not help_text:
        return False
    out = _parse_probe(flag)
    return (f"unknown option '{flag}'" not in out
            and any(sentinel in out for sentinel in _PROBE_SENTINELS))


def _cli_capabilities() -> dict:
    """Probe the installed CLI once and memoise the flags/values it actually accepts."""
    global _caps_cache
    if _caps_cache is not None:
        return _caps_cache
    help_text = _cli_output("--help")
    # Parse modes from choices list only; a blob scan false-matched "auto" in "auto-updater".
    modes: set[str] = set()
    m = re.search(r"--permission-mode\b.*?\(choices:\s*([^)]*)\)",
                  help_text, re.DOTALL)
    if m:
        modes = set(re.findall(r'"([^"]+)"', m.group(1)))
    probed = bool(help_text)
    _caps_cache = {
        "effort": _flag_accepted("--effort", help_text),
        "max_turns": _flag_accepted("--max-turns", help_text),
        "max_budget": _flag_accepted("--max-budget-usd", help_text),
        # `--allowedTools` alone left 28 tools incl Bash/Edit/Write (2.1.270); `--tools` is required
        "tools": _flag_accepted("--tools", help_text),
        "disallowed_tools": _flag_accepted("--disallowedTools", help_text),
        "permission_prompts": _flag_accepted("--permission-prompts", help_text),
        "strict_mcp_config": _flag_accepted("--strict-mcp-config", help_text),
        "setting_sources": _flag_accepted("--setting-sources", help_text),
        "disable_slash_commands": _flag_accepted("--disable-slash-commands", help_text),
        # Only read jail here: without it a session read /etc/hosts (2.1.270); off for apiKeyHelper
        "restricted": _flag_accepted("--restricted", help_text),
        # Optimistic when unprobed: an unreadable --help must NOT downgrade structured output
        "json_schema": not probed or _flag_accepted("--json-schema", help_text),
        "permission_modes": modes,
        "probed": probed,
        # A version floor, not a --help flag: an older or unparsable build keeps the replay path.
        "resume": _resume_capable(),
    }

    return _caps_cache


def _safe_permission_mode(requested: str) -> str:
    """Map a requested --permission-mode to one this CLI actually accepts, falling back if unsupported."""
    caps = _cli_capabilities()
    modes = caps["permission_modes"]
    if not modes:                      # couldn't read help — don't second-guess
        return requested
    if requested in modes:
        return requested
    for m in _PERMISSION_FALLBACKS:
        if m in modes:
            log.warning(Event.CLI_PERMISSION_MODE_UNAVAILABLE, requested=requested, using=m)
            return m
    # Nothing recognised: pick sorted (deterministic), never bypassPermissions, and say so loudly
    fallback = next((m for m in sorted(modes) if m != "bypassPermissions"),
                    None)
    if fallback is None:
        raise RuntimeError(
            f"this `claude` build advertises only {sorted(modes)} as "
            f"--permission-mode values; refusing to run a scan session under "
            f"bypassPermissions. Install a supported CLI build.")
    log.warning(Event.CLI_NO_PERMISSION_MODE, offered=sorted(_PERMISSION_FALLBACKS),
                fallback=fallback)
    return fallback


def _tail(text: str | None, n: int = 1200) -> str:
    if not text:
        return ""
    text = text.strip()
    if len(text) <= n:
        return text
    return "...\n" + text[-n:]


def _short_cmd(cmd: list[str]) -> str:
    """Render argv with long args (system prompts) elided so error lines stay readable."""
    out = []
    for a in cmd:
        if len(a) > 80:
            head = a[:60].replace("\n", " ")
            out.append(f"{head}...<{len(a)} chars>")
        else:
            out.append(a)
    return " ".join(out)


def _extract_envelope_error(stdout: str | None) -> str | None:
    """If stdout is a claude --output-format json envelope carrying an error, return a one-line summary."""
    if not stdout:
        return None
    s = stdout.strip()
    # Anchor on whichever bracket comes first so the list envelope isn't truncated at an inner '{'.
    candidates = [p for p in (s.find("{"), s.find("[")) if p >= 0]
    if not candidates:
        return None
    try:
        env = json.loads(s[min(candidates):])
    except Exception:
        return None

    if isinstance(env, list):
        # Pull the terminal result event (or any error-bearing event).
        evt = next((e for e in reversed(env)
                    if isinstance(e, dict)
                    and (e.get("type") == "result"
                         or e.get("is_error")
                         or e.get("subtype") in ("error", "error_during_execution"))),
                   None)
        env = evt
    if not isinstance(env, dict):
        return None
    if not (env.get("is_error") or env.get("subtype") in ("error", "error_during_execution")):
        return None
    status = env.get("api_error_status")
    msg = env.get("result") or env.get("error") or env.get("message") or "unknown error"
    return f"{status} {msg}" if status else str(msg)


def _format_cli_error(prefix: str, cmd: list[str], result: subprocess.CompletedProcess) -> str:
    env_err = _extract_envelope_error(result.stdout)
    if env_err:
        return f"{prefix}: {env_err} (rc={result.returncode})"

    # redact() BEFORE _tail(), never after: a credential straddling the cut loses its anchor
    err_tail = _tail(redact(result.stderr))
    out_tail = _tail(redact(result.stdout))
    parts = [
        f"{prefix} (rc={result.returncode})",
        f"cmd: {_short_cmd(cmd)}",
    ]
    if err_tail:
        parts.append(f"stderr tail:\n{err_tail}")
    if out_tail:
        parts.append(f"stdout tail:\n{out_tail}")
    if not err_tail and not out_tail:
        parts.append("no stdout/stderr captured")
    return "\n".join(parts)
