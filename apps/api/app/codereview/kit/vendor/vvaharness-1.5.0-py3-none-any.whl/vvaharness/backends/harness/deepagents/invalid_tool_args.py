# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Middleware that repairs a tool call langchain could not parse as JSON."""

# request.override touches only the outgoing request, not agent state, so the SAME unrepaired
# call recurs every later turn; the counter dedupes by call id so it still bumps once per call.

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from langchain.agents.middleware.types import AgentMiddleware
from langchain_core.messages import AIMessage, AnyMessage, InvalidToolCall, ToolMessage

from vvaharness.util.counters import COUNTERS

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable, Sequence

    from langchain.agents.middleware.types import ModelCallResult, ModelRequest


def _repair_block(block: Any, repaired_ids: frozenset[str]) -> Any:
    """Clear the raw ``arguments`` string on the Responses-leg ``function_call`` block it names."""
    if (isinstance(block, dict) and block.get("type") == "function_call"
            and block.get("call_id") in repaired_ids):
        return {**block, "arguments": "{}"}
    return block


def _record_invalid_call(
    invalid: InvalidToolCall, call_id: str, existing_tool_message_ids: frozenset[str],
    counted_ids: set[str]
) -> ToolMessage | None:
    """Count *invalid* once per call id; its paired error ToolMessage, or None when one exists."""
    if call_id not in counted_ids:
        counted_ids.add(call_id)
        COUNTERS.bump("deepagents_tool_args_invalid_json")
    if call_id in existing_tool_message_ids:
        return None
    error = invalid.get("error") or "arguments were not valid JSON"
    return ToolMessage(content=f"ERROR: tool arguments were not valid JSON: {error}",
                       tool_call_id=call_id, name=invalid.get("name"))


def _repair_message(
    message: AIMessage, existing_tool_message_ids: frozenset[str], counted_ids: set[str]
) -> tuple[AIMessage, list[ToolMessage]]:
    """*message* with every invalid tool call moved into ``tool_calls`` with ``args={}``.

    An id-less call is left in ``invalid_tool_calls`` untouched: ``ToolMessage`` requires a
    ``tool_call_id``, and langchain's own repair skips exactly this case the same way.
    """
    repaired_ids: set[str] = set()
    new_tool_calls = list(message.tool_calls)
    remaining_invalid: list[InvalidToolCall] = []
    extra_tool_messages: list[ToolMessage] = []
    for invalid in message.invalid_tool_calls:
        call_id = invalid.get("id")
        if call_id is None:
            remaining_invalid.append(invalid)
            continue
        new_tool_calls.append({"name": invalid.get("name") or "", "args": {}, "id": call_id,
                               "type": "tool_call"})
        repaired_ids.add(call_id)
        extra = _record_invalid_call(invalid, call_id, existing_tool_message_ids, counted_ids)
        if extra is not None:
            extra_tool_messages.append(extra)
    content = message.content
    if isinstance(content, list):
        content = [_repair_block(block, frozenset(repaired_ids)) for block in content]
    repaired = message.model_copy(
        update={"tool_calls": new_tool_calls, "invalid_tool_calls": remaining_invalid,
                "content": content})
    return repaired, extra_tool_messages


def _repair(
    messages: Sequence[AnyMessage], counted_ids: set[str]
) -> list[AnyMessage] | None:
    """*messages* with every invalid tool call repaired, or ``None`` when nothing changed."""
    existing_tool_message_ids = frozenset(
        m.tool_call_id for m in messages if isinstance(m, ToolMessage))
    out: list[AnyMessage] = []
    changed = False
    for message in messages:
        if isinstance(message, AIMessage) and message.invalid_tool_calls:
            repaired, extra = _repair_message(message, existing_tool_message_ids, counted_ids)
            out.append(repaired)
            out.extend(extra)
            changed = True
        else:
            out.append(message)
    return out if changed else None


class RepairInvalidToolArgs(AgentMiddleware):
    """Repair an unparsable tool call before the next model call sees it again."""

    def __init__(self) -> None:
        """Track which call ids were already counted, so a resent call id counts once."""
        super().__init__()
        self._counted_ids: set[str] = set()

    def _repaired_request(self, request: ModelRequest) -> ModelRequest:
        repaired = _repair(request.messages, self._counted_ids)
        return request if repaired is None else request.override(messages=repaired)

    def wrap_model_call(
        self, request: ModelRequest, handler: Callable[[ModelRequest], ModelCallResult]
    ) -> ModelCallResult:
        """Repair any invalid tool call in the outgoing request, then call the model."""
        return handler(self._repaired_request(request))

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelCallResult]],
    ) -> ModelCallResult:
        """Async counterpart of :meth:`wrap_model_call`."""
        return await handler(self._repaired_request(request))


__all__ = ["RepairInvalidToolArgs"]
