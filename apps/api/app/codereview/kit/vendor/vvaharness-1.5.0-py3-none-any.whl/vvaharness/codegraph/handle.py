# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The live handle a scan carries from S0 through to whichever stage last queries the graph."""
from __future__ import annotations

from dataclasses import dataclass

from context_graph_sdk.api import Workspace
from context_graph_sdk.code_graph import CodeGraph

from vvaharness.util import logs

log = logs.get_logger(__name__)


@dataclass
class GraphHandle:
    """Owns the workspace backing ``graph`` — call :meth:`close` once, at end of scan."""

    workspace: Workspace
    graph: CodeGraph
    project_id: str
    node_count: int | None = None
    edge_count: int | None = None
    enrichers: tuple[str, ...] = ()

    def close(self) -> None:
        """Release the workspace's file lock and any open query workers."""
        self.workspace.close()
