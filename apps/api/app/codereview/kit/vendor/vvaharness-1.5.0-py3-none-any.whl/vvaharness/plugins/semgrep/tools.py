# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Read-only tools over the Semgrep subgraph an enricher attached to the code graph."""
from __future__ import annotations

from langchain_core.tools import BaseTool, tool

from vvaharness.codegraph.tools import GraphToolContext

_MAX_ROWS = 25
_MAX_TRACE_STEPS = 40

_FINDINGS_FOR_FILE = """
MATCH (subject)-[:FLAGGED_BY]->(f:SemgrepFinding)-[:DETECTED_BY]->(r:SemgrepRule)
WHERE f.filePath = $file
RETURN f.ruleId AS ruleId, f.filePath AS path, f.semgrepStartLine AS line,
       f.severity AS severity, subject.name AS symbol,
       r.cweIds AS cweIds, r.vulnerabilityClasses AS classes
ORDER BY line, ruleId
LIMIT 25
"""

_TRACE_FOR_RULE = """
MATCH (f:SemgrepFinding)-[trace:TRACE_TOUCHES]->(symbol)
WHERE f.ruleId = $rule_id
RETURN f.ruleId AS ruleId, trace.step AS step, trace.role AS role,
       trace.filePath AS path, trace.startLine AS line, symbol.name AS symbol
ORDER BY step
LIMIT 40
"""

_CALLERS_OF_FLAGGED_SINKS = """
MATCH (f:SemgrepFinding)-[trace:TRACE_TOUCHES]->(sink)<-[:CALLS]-(caller)
WHERE trace.role = 'sink' AND f.filePath = $file
RETURN f.ruleId AS ruleId, sink.name AS sink, caller.name AS caller,
       caller.filePath AS callerPath
ORDER BY sink, caller
LIMIT 25
"""

_SCAN_COVERAGE = """
MATCH (s:SemgrepScan)
RETURN s.complete AS complete, s.findingCount AS findings,
       s.errorCount AS errors, s.skippedCount AS skipped
LIMIT 1
"""


def _rows(gtx: GraphToolContext, query: str, params: dict) -> list[dict]:
    """Bounded cypher rows as plain dicts, or a one-key error dict the model can act on."""
    try:
        return [r.to_dict() for r in gtx.handle.graph.cypher(query, params).rows]
    except Exception as exc:
        return [{"error": f"{type(exc).__name__}: {exc}",
                 "hint": "no Semgrep subgraph in this scan; the enricher did not run"}]


def semgrep_findings_tool(gtx: GraphToolContext) -> BaseTool:
    """Builds ``GraphSemgrepFindings``, the per-file view of what Semgrep flagged."""

    @tool
    def GraphSemgrepFindings(file: str) -> list[dict]:  # noqa: N802
        """Semgrep findings on *file*, each with its rule id, severity, enclosing symbol, and the rule's CWE ids. Empty means Semgrep flagged nothing here, which is not proof the file is safe."""  # noqa: E501
        return _rows(gtx, _FINDINGS_FOR_FILE, {"file": file})

    return GraphSemgrepFindings


def semgrep_trace_tool(gtx: GraphToolContext) -> BaseTool:
    """Builds ``GraphSemgrepTaintTrace``, the ordered source-to-sink steps behind one finding."""

    @tool
    def GraphSemgrepTaintTrace(rule_id: str) -> list[dict]:  # noqa: N802
        """Ordered taint steps for findings of *rule_id*, each step carrying an explicit role of source, intermediate or sink. Semgrep reports representative routes, not every route, and an empty result means it recorded no explicit trace rather than that no flow exists."""  # noqa: E501
        return _rows(gtx, _TRACE_FOR_RULE, {"rule_id": rule_id})

    return GraphSemgrepTaintTrace


def semgrep_sink_callers_tool(gtx: GraphToolContext) -> BaseTool:
    """Builds ``GraphSemgrepSinkCallers``, joining traced sinks onto the structural call graph."""

    @tool
    def GraphSemgrepSinkCallers(file: str) -> list[dict]:  # noqa: N802
        """Functions that call a Semgrep-traced sink in *file* — the reachability question a finding alone cannot answer. An empty caller list means nothing in the graph reaches that sink, so it is an entry point or unreachable."""  # noqa: E501
        return _rows(gtx, _CALLERS_OF_FLAGGED_SINKS, {"file": file})

    return GraphSemgrepSinkCallers


def semgrep_coverage_tool(gtx: GraphToolContext) -> BaseTool:
    """Builds ``GraphSemgrepCoverage``, the scan's own completeness report."""

    @tool
    def GraphSemgrepCoverage() -> list[dict]:  # noqa: N802
        """Whether this repository's Semgrep scan was complete, with its finding, error and skip counts. A complete scan means no represented coverage loss; it is not a security assurance."""  # noqa: E501
        return _rows(gtx, _SCAN_COVERAGE, {})

    return GraphSemgrepCoverage


SEMGREP_TOOLS = {
    "GraphSemgrepFindings": semgrep_findings_tool,
    "GraphSemgrepTaintTrace": semgrep_trace_tool,
    "GraphSemgrepSinkCallers": semgrep_sink_callers_tool,
    "GraphSemgrepCoverage": semgrep_coverage_tool,
}

SEMGREP_TOOL_NAMES: tuple[str, ...] = tuple(SEMGREP_TOOLS)

__all__ = ["SEMGREP_TOOLS", "SEMGREP_TOOL_NAMES"]
