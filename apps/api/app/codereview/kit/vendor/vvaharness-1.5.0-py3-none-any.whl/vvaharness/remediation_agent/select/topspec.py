# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Parse and resolve the ``--top N`` cap from the CLI flag or the active profile."""
from __future__ import annotations

from collections.abc import Sequence

# Wildcard "no cap", deliberately distinct from None so CLI --top all overrides a profile cap
ALL_FINDINGS = "all"
_ALL_TOKENS = frozenset({"all", "*"})


def _coerce_top_value(raw: str, *, source: str) -> int | str:
    """Coerce a raw ``--top`` / ``top_n_findings`` value to a positive int or :data:`ALL_FINDINGS`."""
    token = (raw or "").strip().lower()
    if token in _ALL_TOKENS:
        return ALL_FINDINGS
    try:
        n = int(token)
    except (TypeError, ValueError):
        raise ValueError(
            f"{source} expects a positive integer or 'all'/'*', got {raw!r}")
    if n <= 0:
        raise ValueError(
            f"{source} must be a positive integer or 'all'/'*', got {n}")
    return n


def parse_top_arg(args: Sequence[str]) -> int | str | None:
    """Parse ``--top N`` / ``--top=N`` (or the ``all``/``*`` wildcard) from a raw argv slice."""
    raw: str | None = None
    for i, a in enumerate(args):
        if a == "--top":
            if i + 1 >= len(args):
                raise ValueError(
                    "--top requires a value, e.g. --top 5 or --top all")
            raw = args[i + 1]
            break
        if a.startswith("--top="):
            raw = a.split("=", 1)[1]
            break
    if raw is None:
        return None
    return _coerce_top_value(raw, source="--top")


def cfg_top_n_findings(cfg) -> int | str | None:
    """Read the profile-driven top-N cap from ``step_remediate.top_n_findings``."""
    # None ONLY when step_remediate is absent; garbage degrades to the wildcard, never raises here
    sr = getattr(cfg, "step_remediate", None)
    if sr is None:
        return None
    raw = getattr(sr, "top_n_findings", None)
    if raw is None:
        # Key absent but block present → no cap (remediate everything).
        return ALL_FINDINGS
    try:
        return _coerce_top_value(str(raw), source="top_n_findings")
    except ValueError:
        # null / 0 / negative / unparseable in a profile → wildcard rather than crashing the run.
        return ALL_FINDINGS


def resolve_top(cli_top: int | str | None, cfg) -> int | None:
    """Resolve the effective top-N cap for :func:`select_top_by_cvss`: a positive int, or ``None``."""
    # CLI wins; ALL_FINDINGS collapses to None here so callers never see the sentinel
    chosen = cli_top if cli_top is not None else cfg_top_n_findings(cfg)
    if isinstance(chosen, int):
        return chosen
    # None ("flag/key absent") or the ALL_FINDINGS wildcard → no cap.
    return None
