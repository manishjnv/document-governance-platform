# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The shipped GraphEnricher: runs Semgrep once and writes its findings onto the code graph."""
from __future__ import annotations

import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

from context_graph_sdk.identity import ProjectId, make_local_id
from context_graph_sdk.models import (
    GraphEdge,
    GraphMutation,
    GraphNode,
    GraphSnapshot,
    freeze_properties,
)
from context_graph_sdk.pipeline import PluginContext
from context_graph_sdk.plugins import PluginMetadata, PluginPhase

from vvaharness.plugins.semgrep.findings import read_semgrep_json, relative_path
from vvaharness.util import logs
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

SCAN_LABEL = "SemgrepScan"
FINDING_LABEL = "SemgrepFinding"
RULE_LABEL = "SemgrepRule"
LOCATION_LABEL = "SemgrepLocation"

FLAGGED_BY = "FLAGGED_BY"
DETECTED_BY = "DETECTED_BY"
TRACE_TOUCHES = "TRACE_TOUCHES"

MAX_FINDING_NODES = 500
MAX_TRACE_STEPS = 20
MAX_EDGES = 18_000
MIN_BUDGET_SECONDS = 15.0
MAX_TRACE_NESTING = 6

_TRACE_ROLES = (("taint_source", "source"), ("intermediate_vars", "intermediate"),
                ("taint_sink", "sink"))
_MAX_MESSAGE_CHARS = 1_000
_SEVERITY_ORDER = {"ERROR": 0, "WARNING": 1, "INFO": 2}


@dataclass(frozen=True)
class _Located:
    """One resolvable graph location: a repo-relative path and the line a finding sits on."""

    path: str
    line: int


@dataclass(frozen=True)
class _Symbols:
    """The existing snapshot, indexed so a Semgrep line resolves to the node that encloses it."""

    spans: dict[str, tuple[tuple[int, int, str], ...]]
    files: dict[str, str]

    def resolve(self, at: _Located) -> str | None:
        """The innermost symbol node id containing *at*, else that path's File node, else None."""
        best: tuple[int, str] | None = None
        for start, end, node_id in self.spans.get(at.path, ()):
            if start <= at.line <= end and (best is None or end - start < best[0]):
                best = (end - start, node_id)
        return best[1] if best is not None else self.files.get(at.path)


def _index(graph: GraphSnapshot) -> _Symbols:
    """Indexes the snapshot's line spans and File nodes once, rather than per finding."""
    spans: dict[str, list[tuple[int, int, str]]] = {}
    files: dict[str, str] = {}
    for node in graph.nodes:
        props = node.properties.to_dict()
        path = props.get("filePath")
        if not isinstance(path, str):
            continue
        if "File" in node.labels:
            files.setdefault(path, node.id)
        start, end = props.get("startLine"), props.get("endLine")
        if isinstance(start, int) and isinstance(end, int) and end >= start:
            spans.setdefault(path, []).append((start, end, node.id))
    return _Symbols({path: tuple(sorted(rows)) for path, rows in spans.items()}, files)


def _argv(executable: str, configs: tuple[Path, ...], rulesets: tuple[str, ...],
          root: str, output: Path) -> list[str]:
    """The one Semgrep command line this enricher runs; no shell, every rule source explicit."""
    argv = [executable, "--json", "--quiet", "--metrics=off", "--disable-version-check",
            "--output", str(output)]
    for config in configs:
        argv += ["--config", str(config)]
    for ruleset in rulesets:
        argv += ["--config", ruleset]
    return [*argv, root]


def _cwe_ids(metadata: dict) -> tuple[str, ...]:
    """A rule's declared CWE ids as the graph stores them, tolerating the bare-string form."""
    raw = metadata.get("cwe") or []
    values = [raw] if isinstance(raw, str) else [v for v in raw if isinstance(v, str)]
    return tuple(dict.fromkeys(v.split(":")[0].strip() for v in values if v.strip()))


def _classes(metadata: dict) -> tuple[str, ...]:
    """A rule's OWASP/vulnerability-class labels, which carry the diversity CWE ids do not."""
    out: list[str] = []
    for key in ("vulnerability_class", "owasp", "category"):
        raw = metadata.get(key) or []
        values = [raw] if isinstance(raw, str) else [v for v in raw if isinstance(v, str)]
        out += [v.strip() for v in values if v.strip()]
    return tuple(dict.fromkeys(out))


def _trace_steps(extra: dict, root: str) -> tuple[tuple[str, _Located], ...]:
    """Ordered ``(role, location)`` steps from a result's dataflow trace, source first."""
    trace = extra.get("dataflow_trace") or {}
    if not isinstance(trace, dict):
        return ()
    steps: list[tuple[str, _Located]] = []
    for key, role in _TRACE_ROLES:
        for entry in _flatten(trace.get(key)):
            located = _location(entry, root)
            if located is not None:
                steps.append((role, located))
    return tuple(steps[:MAX_TRACE_STEPS])


def _flatten(value: object, depth: int = 0) -> list[dict]:
    """Every mapping inside Semgrep's nested trace arrays, whose shape varies by version."""
    if isinstance(value, dict):
        return [value]
    if isinstance(value, (list, tuple)) and depth < MAX_TRACE_NESTING:
        return [found for item in value for found in _flatten(item, depth + 1)]
    return []


def _location(entry: dict, root: str) -> _Located | None:
    """One trace entry's repo-relative path and start line, or None when it carries neither."""
    path = entry.get("path")
    line = (entry.get("start") or {}).get("line") if isinstance(entry.get("start"), dict) else None
    if isinstance(path, str) and isinstance(line, int):
        return _Located(relative_path(path, root), line)
    return None


def _ranked(results: list[dict]) -> list[dict]:
    """Results in severity-then-location order, so a cap drops the least severe rows first."""
    def key(result: dict) -> tuple[int, str, int, str]:
        extra = result.get("extra") or {}
        severity = str(extra.get("severity", "")).upper()
        return (_SEVERITY_ORDER.get(severity, 3), str(result.get("path") or ""),
                int((result.get("start") or {}).get("line") or 0),
                str(result.get("check_id") or ""))
    return sorted((r for r in results if isinstance(r, dict)), key=key)[:MAX_FINDING_NODES]


@dataclass(frozen=True)
class _Coverage:
    """What the scan itself reported about its own completeness, which findings cannot say."""

    note: str
    complete: bool = False
    findings: int = 0
    errors: int = 0
    skipped: int = 0
    rules: int = 0


def _scan_node(project_id: ProjectId, coverage: _Coverage) -> GraphNode:
    """The one node ``GraphSemgrepCoverage`` reads, present even when the scan could not run."""
    return GraphNode(
        project_id=project_id,
        local_id=make_local_id("semgrep-scan", project_id.value),
        labels=(SCAN_LABEL,),
        properties=freeze_properties({
            "complete": coverage.complete, "findingCount": coverage.findings,
            "errorCount": coverage.errors, "skippedCount": coverage.skipped,
            "ruleCount": coverage.rules, "note": coverage.note[:_MAX_MESSAGE_CHARS],
            "tool": "semgrep",
        }),
    )


class _Builder:
    """Accumulates nodes and edges under one explicit edge budget, since a breach is rejected."""

    def __init__(self, project_id: ProjectId) -> None:
        self.project_id = project_id
        self.nodes: dict[str, GraphNode] = {}
        self.edges: dict[str, GraphEdge] = {}

    def node(self, local_id: str, labels: tuple[str, ...], properties: dict) -> str:
        """Adds a node unless its identity is already present, returning its global id."""
        node = GraphNode(project_id=self.project_id, local_id=local_id, labels=labels,
                         properties=freeze_properties(properties))
        self.nodes.setdefault(node.id, node)
        return node.id

    def edge(self, source: str, relationship: str, target: str, *, discriminator: str = "",
             properties: dict | None = None) -> bool:
        """Adds one edge, or returns False once the edge budget is spent."""
        if len(self.edges) >= MAX_EDGES:
            return False
        edge = GraphEdge(project_id=self.project_id, source_id=source,
                         relationship_type=relationship, target_id=target,
                         discriminator=discriminator,
                         properties=freeze_properties(properties or {}))
        self.edges.setdefault(edge.id, edge)
        return True

    def anchor(self, symbols: _Symbols, at: _Located) -> str:
        """The node a finding hangs off: the enclosing symbol, the File, or a minted stand-in."""
        resolved = symbols.resolve(at)
        if resolved is not None:
            return resolved
        return self.node(make_local_id("semgrep-location", at.path), (LOCATION_LABEL,),
                         {"name": at.path, "filePath": at.path})

    def mutation(self) -> GraphMutation:
        """Everything accumulated, as the single mutation the SDK applies or rejects whole."""
        return GraphMutation(project_id=self.project_id, nodes=tuple(self.nodes.values()),
                             edges=tuple(self.edges.values()))


def _rule_id(builder: _Builder, check_id: str, metadata: dict) -> str:
    """The SemgrepRule node for *check_id*, minted once however many findings cite it."""
    return builder.node(
        make_local_id("semgrep-rule", check_id), (RULE_LABEL,),
        {"name": check_id, "ruleId": check_id, "cweIds": list(_cwe_ids(metadata)),
         "vulnerabilityClasses": list(_classes(metadata))})


def _add_finding(builder: _Builder, symbols: _Symbols, result: dict, ordinal: int,
                 root: str) -> bool:
    """Writes one result as a finding node wired to its rule, its subject and its trace."""
    raw_path = result.get("path")
    line = (result.get("start") or {}).get("line")
    if not isinstance(raw_path, str) or not isinstance(line, int):
        return False
    path = relative_path(raw_path, root)
    extra = result.get("extra") or {}
    metadata = extra.get("metadata") or {}
    check_id = str(result.get("check_id") or "semgrep")
    end_line = (result.get("end") or {}).get("line")
    finding = builder.node(
        make_local_id("semgrep-finding", check_id, path, str(line), str(ordinal)),
        (FINDING_LABEL,),
        {"name": check_id, "ruleId": check_id, "filePath": path, "semgrepStartLine": line,
         "semgrepEndLine": end_line if isinstance(end_line, int) else line,
         "severity": str(extra.get("severity") or "").upper() or "UNKNOWN",
         "message": str(extra.get("message") or check_id)[:_MAX_MESSAGE_CHARS],
         "fingerprint": str(extra.get("fingerprint") or "")})
    builder.edge(builder.anchor(symbols, _Located(path, line)), FLAGGED_BY, finding)
    builder.edge(finding, DETECTED_BY, _rule_id(builder, check_id, metadata))
    for step, (role, located) in enumerate(_trace_steps(extra, root)):
        target = symbols.resolve(located)
        if target is not None and target != finding:
            builder.edge(finding, TRACE_TOUCHES, target, discriminator=str(step),
                         properties={"step": step, "role": role, "filePath": located.path,
                                     "startLine": located.line})
    return True


def _mutation(project_id: ProjectId, graph: GraphSnapshot, document: dict,
              root: str = "") -> GraphMutation:
    """The whole Semgrep subgraph for one report: scan, rules, findings, subjects and traces."""
    raw = document.get("results")
    results = _ranked(raw if isinstance(raw, list) else [])
    builder = _Builder(project_id)
    symbols = _index(graph)
    written = sum(_add_finding(builder, symbols, r, i, root) for i, r in enumerate(results))
    errors = document.get("errors")
    skipped = (document.get("paths") or {}).get("skipped")
    error_count = len(errors) if isinstance(errors, list) else 0
    dropped = len(raw) - len(results) if isinstance(raw, list) else 0
    scan = _scan_node(project_id, _Coverage(
        note=f"{dropped} of {len(results) + dropped} results dropped at "
             f"MAX_FINDING_NODES={MAX_FINDING_NODES}" if dropped else "ok",
        complete=not dropped and not error_count, findings=written, errors=error_count,
        skipped=len(skipped) if isinstance(skipped, list) else 0,
        rules=sum(1 for n in builder.nodes.values() if RULE_LABEL in n.labels)))
    builder.nodes.setdefault(scan.id, scan)
    return builder.mutation()


@dataclass(frozen=True)
class SemgrepEnricher:
    """Runs Semgrep over the analyzed repository and attaches its findings to the code graph."""

    configs: tuple[Path, ...] = ()
    rulesets: tuple[str, ...] = ()
    executable: str = "semgrep"
    timeout_seconds: float = 120.0
    priority: int = 100

    @property
    def metadata(self) -> PluginMetadata:
        """Post-derivation, so symbols and their line spans already exist to attach to."""
        return PluginMetadata(phase=PluginPhase.POST_DERIVATION, priority=self.priority,
                              name="semgrep", version="1")

    def enrich(self, context: PluginContext) -> GraphMutation:
        """The Semgrep subgraph, or a scan node saying why there is none; never raises."""
        project_id = context.project.project_id
        budget = min(self.timeout_seconds, context.deadline_monotonic - time.monotonic())
        refusal = self._refusal(context, budget)
        if refusal:
            return self._degrade(project_id, refusal)
        root = str(context.project.source_path)
        document, note = self._report(root, budget)
        if document is None:
            return self._degrade(project_id, note)
        return _mutation(project_id, context.graph, document, root)

    def _degrade(self, project_id: ProjectId, note: str) -> GraphMutation:
        """Record the absence on the graph AND where an operator will see it."""
        COUNTERS.bump("semgrep_scan_degraded")
        log.warning(Event.SEMGREP_SCAN_DEGRADED, reason=note, executable=self.executable,
                    remedy="install semgrep on PATH and confirm the rule source is reachable "
                           "(SSL_CERT_FILE / REQUESTS_CA_BUNDLE behind a private CA)")
        return _degraded(project_id, note)

    def _refusal(self, context: PluginContext, budget: float) -> str:
        """Why this scan cannot run, or empty when it can; a refusal degrades, it does not raise."""
        checks = (
            (context.cancellation.is_cancelled, "cancelled before the Semgrep scan started"),
            (not context.project.source_path, "the project carries no source path to scan"),
            (not self.configs and not self.rulesets,
             "no local rule files and no rulesets were configured"),
            (budget < MIN_BUDGET_SECONDS,
             f"{budget:.0f}s is under the {MIN_BUDGET_SECONDS:.0f}s floor a Semgrep scan needs"),
        )
        return next((reason for failed, reason in checks if failed), "")

    def _report(self, root: str, budget: float) -> tuple[dict | None, str]:
        """One bounded Semgrep run's parsed report, or None and the reason it produced none."""
        try:
            with tempfile.TemporaryDirectory(prefix="vvah-semgrep-") as work:
                output = Path(work) / "semgrep.json"
                argv = _argv(self.executable, self.configs, self.rulesets, root, output)
                done = subprocess.run(argv, capture_output=True, text=True,  # noqa: S603
                                      check=False, timeout=budget, cwd=root)
                if not output.is_file():
                    detail = (done.stderr or done.stdout or "").strip()[:_MAX_MESSAGE_CHARS]
                    return None, f"semgrep exited {done.returncode} without a report: {detail}"
                return read_semgrep_json(output), ""
        except Exception as exc:
            return None, f"{type(exc).__name__}: {exc}"[:_MAX_MESSAGE_CHARS]


def _degraded(project_id: ProjectId, note: str) -> GraphMutation:
    """A mutation carrying only the scan node, so the absence of evidence is itself queryable."""
    return GraphMutation(
        project_id=project_id,
        nodes=(_scan_node(project_id, _Coverage(note=note)),))


__all__ = [
    "DETECTED_BY",
    "FINDING_LABEL",
    "FLAGGED_BY",
    "LOCATION_LABEL",
    "MAX_EDGES",
    "MAX_FINDING_NODES",
    "MAX_TRACE_STEPS",
    "RULE_LABEL",
    "SCAN_LABEL",
    "TRACE_TOUCHES",
    "SemgrepEnricher",
]
