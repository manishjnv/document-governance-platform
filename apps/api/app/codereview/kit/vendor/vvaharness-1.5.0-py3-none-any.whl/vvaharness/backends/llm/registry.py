# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Backend dispatcher: step files import prompt()/agentic() from HERE, never a backend directly."""

# `via: deepagents` is deliberately NOT registered here — see DEEPAGENTS_ROLES below.
from __future__ import annotations

from collections.abc import Mapping
from importlib import import_module
from typing import Any, Final

from vvaharness.backends.llm.cli import parse_json_response  # noqa: F401 — re-exported
from vvaharness.backends.llm.models import (
    LlmBackend,
    ModelExtras,
    ModulePath,
    ResolvedModel,
)
from vvaharness.util import logs
from vvaharness.util.events import Event
from vvaharness.util.response_quality import check_response_quality
from vvaharness.util.scan_progress import get_active_tracker
from vvaharness.util.tokens import TOKENS  # also re-exported
from vvaharness.util.warn_once import warn_once

log = logs.get_logger(__name__)

# Not in _BACKENDS by design: get_backend() fails loudly; preflight.py/environment.py enforce this
DEEPAGENTS_ROLES = frozenset({
    "remediate", "validate",          # S10/S11 — harness graph, in-stage branch
    "preprocess",                     # S1 — harness graph (agentic), in-stage branch
    "autoexclude",                    # pre-S1 — harness graph, in-stage branch
    "threatmodel", "decompose",       # S2/S3 — in-stage branch
    "deepdive",                       # S4 — dispatch_agentic seam
    "verify",                         # S6 — dispatch_agentic seam
    "dedup", "chain",                 # S7/S8 — in-stage branch
    "graph_annotate",                 # S0 label — never dispatched (no annotator exists)
    "exploit_verification.classify", "exploit_verification.mapper",
    "exploit_verification.judge", "exploit_verification.attacker",
})

# Post-detection (S10/S11): a probe failure only WARNs; detection roles stay fatal (silent gaps)
POST_SCAN_ROLES = frozenset({"remediate", "validate"})


def provider_of(model_cfg: object) -> str | None:
    """Provider selector from a model config node, when it declares one."""
    provider = getattr(model_cfg, "provider", None)
    return provider if isinstance(provider, str) else None


def use_responses_api_of(model_cfg: object) -> bool | None:
    """Transport override from a model config node, when it declares a boolean one."""
    value = getattr(model_cfg, "use_responses_api", None)
    return value if isinstance(value, bool) else None


def output_cap_of(model_cfg: object) -> int | None:
    """A model's own output-token ceiling, when its config node declares one."""
    # Deliberately NOT read from ``ModelExtras``: dropped-knob warnings would call this cap ignored
    value = getattr(model_cfg, "max_tokens", None)
    return int(value) if isinstance(value, (int, float)) and value > 0 else None


def clamp_output_tokens(requested: int, model_cfg: object, *, tag: str | None = None) -> int:
    """*requested* bounded by the model's own declared ``max_tokens`` cap, if any."""
    # A cap below the step's ``max_tokens`` 400s on the FIRST send; only ever lowers, never raises
    cap = output_cap_of(model_cfg)
    if cap is None or requested <= cap:
        return requested
    model_id = getattr(model_cfg, "id", None) or str(model_cfg)
    stage = tag.split()[0] if tag else ""
    log.warning(Event.OUTPUT_TOKENS_CLAMPED, stage=stage or "llm", model=model_id,
                requested=requested, cap=cap)
    return cap


#: Every key a consumer reads off a model config node; preflight/doctor warn on the rest.
KNOWN_MODEL_NODE_KEYS: Final[frozenset[str]] = frozenset(
    {"id", "via", "provider", "temperature", "thinking_budget", "betas",
     "use_responses_api", "max_tokens"}
)


def unrecognized_model_keys(model_cfg: object) -> tuple[str, ...]:
    """Raw keys on a dict-backed model config node that no consumer reads."""
    data = getattr(model_cfg, "_data", None)
    if not isinstance(data, dict):
        return ()
    return tuple(sorted(str(k) for k in data if str(k) not in KNOWN_MODEL_NODE_KEYS))


def resolve(model_cfg: Any) -> ResolvedModel:
    """Normalize a model config; a bare str ⇒ the default via, else its .id/.via win."""
    if isinstance(model_cfg, str):
        return ResolvedModel(model_cfg, DEFAULT_LLM_VIA, ModelExtras())

    model_id = getattr(model_cfg, "id", None)
    if model_id is None:
        raise ValueError(
            f"Model config must be a string or have an `id` field: got {model_cfg!r}"
        )
    via = getattr(model_cfg, "via", None) or DEFAULT_LLM_VIA
    extras = ModelExtras()
    temperature = getattr(model_cfg, "temperature", None)
    if temperature is not None:
        extras["temperature"] = float(temperature)
    thinking_budget = getattr(model_cfg, "thinking_budget", None)
    if thinking_budget:
        extras["thinking_budget"] = int(thinking_budget)
    betas = getattr(model_cfg, "betas", None)
    if betas:
        extras["betas"] = list(betas)
    return ResolvedModel(model_id, via, extras)


# Backends are named by import path and resolved on selection, so picking one never imports its SDK.
_BACKENDS: Final[Mapping[str, ModulePath]] = {
    "cli": ModulePath("vvaharness.backends.llm.cli"),
    "sdk": ModulePath("vvaharness.backends.llm.sdk"),
    "openai": ModulePath("vvaharness.backends.llm.openai"),
}

#: Selected when a model config names no backend.
DEFAULT_LLM_VIA: Final = "cli"


def available() -> list[str]:
    """Return the registered ``via`` names."""
    return sorted(_BACKENDS)


def targets() -> Mapping[str, ModulePath]:
    """Return the shipped module paths, so a test can assert every one still resolves."""
    return _BACKENDS


def get_backend(via: str, model_id: str) -> LlmBackend:
    """Resolve *via* to its backend module, naming the model if unknown; imported lazily here."""
    path = _BACKENDS.get(via)
    if path is None:
        raise ValueError(f"Unknown backend `via: {via}` for model {model_id}")
    module = import_module(path)
    if not isinstance(module, LlmBackend):
        msg = f"backend module {path!r} does not provide prompt() and agentic()"
        raise TypeError(msg)
    return module


def _flatten_blocks(user_prompt: str | list[dict]) -> str:
    """Render a prompt as one string, joining the text blocks of a content-block list."""
    if isinstance(user_prompt, str):
        return user_prompt
    return "\n\n".join(
        str(b.get("text", "")) for b in user_prompt
        if isinstance(b, dict) and b.get("type") == "text"
    )


#: Model-node keys already reported as unsupported on the cli route, once per process.
_WARNED_CLI_DROPPED: set[str] = set()

#: Keys a model node may carry that the `claude` binary has no way to send.
_CLI_UNSUPPORTED_KEYS: Final = ("temperature", "thinking_budget", "betas")


def warn_cli_dropped_knobs(model_id: str, extras: ModelExtras) -> None:
    """One-time WARN naming model-node keys this route cannot send."""
    # Popped silently: a pinned ``temperature`` looks applied and is not; --cache-probe arms match
    dropped = [k for k in _CLI_UNSUPPORTED_KEYS if k in extras]
    if not dropped:
        return
    warn_once(
        _WARNED_CLI_DROPPED, f"{model_id}:{','.join(dropped)}",
        f"WARN [cli]: models entry {model_id!r} sets {', '.join(dropped)}, which the "
        f"`claude` CLI has no flag for — ignored on this route. "
        f"For a PINNED temperature, a thinking budget, or beta headers, route this "
        f"role via: sdk or via: openai. NOTE: doctor --cache-probe's thinking-on and "
        f"thinking-off arms are byte-identical on a via:cli route because of this.")


def _fold_for_cli(user_prompt: str | list[dict], kw: dict[str, Any]) -> str | list[dict]:
    """Adapt *kw* in place for the CLI route, returning the (possibly prefixed) prompt."""
    # Prefix folds into the user turn; dropping ``temperature`` is NOT determinism, just a default
    kw.pop("temperature", None)
    kw.pop("thinking_budget", None)
    kw.pop("betas", None)
    cache_prefix = kw.pop("cache_prefix", None)
    if not cache_prefix:
        return user_prompt
    if isinstance(user_prompt, list):
        return [{"type": "text", "text": cache_prefix}, *user_prompt]
    return cache_prefix + user_prompt


def prompt(user_prompt: str | list[dict], *, model: Any, **kw: Any) -> str:
    """Route a single-turn completion to the backend the model config selects."""
    model_id, via, extras = resolve(model)
    backend = get_backend(via, model_id)
    if kw.get("max_tokens") is not None:
        kw["max_tokens"] = clamp_output_tokens(int(kw["max_tokens"]), model, tag=kw.get("tag"))
    if via == "openai":
        # By design: openai's truncation retry is bounded only by a declared cap; sdk/cli use 64k
        kw["output_cap"] = output_cap_of(model)
    tracker = get_active_tracker()
    if tracker is not None:
        # Log the prefix too: for a specialist shard `cache_prefix` carries most of the request.
        _prefix = kw.get("cache_prefix") or ""
        _body = _flatten_blocks(user_prompt)
        tracker.llm_payload(
            phase=TOKENS.current_phase(),
            backend=via,
            model_id=model_id,
            tag=str(kw.get("tag", "") or ""),
            user_prompt=(_prefix + _body) if _prefix else _body,
            system_prompt=str(kw.get("system_prompt", "") or ""),
        )
    if via == DEFAULT_LLM_VIA:
        warn_cli_dropped_knobs(model_id, extras)
        user_prompt = _fold_for_cli(user_prompt, kw)
    else:
        for k, v in extras.items():
            kw.setdefault(k, v)
    return backend.prompt(user_prompt, model=model_id, **kw)


def agentic(user_prompt: str, *, model: Any, **kw) -> str:
    """Route a tool-using loop to the backend the model config selects."""
    # Fold cache_prefix here (no agentic() accepts it; parity only, no cache hit); VVAH-E003 gate
    model_id, via, extras = resolve(model)
    backend = get_backend(via, model_id)
    if via == DEFAULT_LLM_VIA:
        warn_cli_dropped_knobs(model_id, extras)
    if kw.get("max_output_tokens") is not None:
        # Only sdk/openai carry this key here; the cli legs are clamped in
        # dispatch_agentic() before this call, since the MCP-bridged leg never reaches here.
        kw["max_output_tokens"] = clamp_output_tokens(
            int(kw["max_output_tokens"]), model, tag=kw.get("tag"))
    if via == "openai":
        kw["output_cap"] = output_cap_of(model)
        kw["use_responses_api"] = use_responses_api_of(model)
    cache_prefix = kw.pop("cache_prefix", None)
    if cache_prefix:
        user_prompt = cache_prefix + user_prompt
    # stream_cb is CLI-only: dropped for sdk/openai (TypeError). `timeout` is forwarded to every
    # via now -- sdk/openai enforce it themselves as a session clock before each turn, and the
    # Agent SDK delegation and deepagents leg enforce it too.
    if via != DEFAULT_LLM_VIA:
        kw.pop("stream_cb", None)
    text = backend.agentic(user_prompt, model=model_id, **kw)
    # No output_tokens: TOKENS holds the multi-turn aggregate, not this reply's own count.
    check_response_quality(text, stage=str(kw.get("tag", "") or ""))
    return text
