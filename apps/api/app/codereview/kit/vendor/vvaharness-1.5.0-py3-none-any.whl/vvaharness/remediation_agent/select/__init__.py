# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared "top N by CVSS" finding selection — limit and reorder — used by both remediation entry points."""
from __future__ import annotations

from vvaharness.remediation_agent.select.pq import (
    band_score,
    drop_non_main_channel,
    select_top_by_cvss,
    select_top_logged,
)
from vvaharness.remediation_agent.select.topspec import (
    ALL_FINDINGS,
    _coerce_top_value,
    cfg_top_n_findings,
    parse_top_arg,
    resolve_top,
)

__all__ = [
    "ALL_FINDINGS",
    "_coerce_top_value",
    "band_score",
    "cfg_top_n_findings",
    "drop_non_main_channel",
    "parse_top_arg",
    "resolve_top",
    "select_top_by_cvss",
    "select_top_logged",
]
