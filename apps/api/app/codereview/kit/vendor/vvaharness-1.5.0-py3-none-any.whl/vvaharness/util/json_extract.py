# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Pull a JSON object/array out of a model response that may have prose around it."""
from __future__ import annotations
from vvaharness.util import logs

import json
import re
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

_FENCE = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.DOTALL)
# Leading fence opener only: peeks at the first content char without needing a closing fence
_FENCE_OPEN = re.compile(r"^```\w*\s*")

# The balanced-span scan is O(openers x length), so a '{'-heavy blob is bounded, not abandoned
_MAX_JSON_INPUT = 5_000_000

_VALID_ESCAPE = set('"\\/nrtu')


def _repair_invalid_escapes(s: str) -> str:
    """Best-effort repair: double any backslash that does NOT introduce a valid JSON escape."""
    out: list[str] = []
    i, n = 0, len(s)
    while i < n:
        ch = s[i]
        if ch == "\\":
            nxt = s[i + 1] if i + 1 < n else ""
            if nxt in _VALID_ESCAPE:
                out.append(ch)
                out.append(nxt)
                i += 2
                continue
            out.append("\\\\")   # invalid / trailing escape -> literal backslash
            i += 1
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def _balanced_span(s: str, start: int) -> str | None:
    open_ch = s[start]
    close_ch = "}" if open_ch == "{" else "]"
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(s)):
        ch = s[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == open_ch:
                depth += 1
            elif ch == close_ch:
                depth -= 1
                if depth == 0:
                    return s[start:i + 1]
    return None


def extract_json(text: str) -> dict | list:
    if len(text) > _MAX_JSON_INPUT:
        log.warning(Event.JSON_INPUT_TRUNCATED, size=len(text), cap=_MAX_JSON_INPUT)
        text = text[:_MAX_JSON_INPUT]
    stripped = text.strip()
    # ALWAYS keep the whole response as a final candidate, so JSON OUTSIDE a fence survives
    candidates: list[str] = []
    # A literal ``` inside a JSON string truncates non-greedy findall(); fullmatch gets it all
    whole = _FENCE.fullmatch(stripped)
    if whole:
        candidates.append(whole.group(1))
    candidates += _FENCE.findall(text)
    candidates.append(text)

    # When the response starts with '{', a top-level list is a sub-span; hold it, keep scanning
    peek = _FENCE_OPEN.sub("", stripped, count=1)
    want_dict = peek[:1] == "{"
    held_list: list | None = None
    last_err: Exception | None = None

    for cand in candidates:
        i = 0
        while i < len(cand):
            if cand[i] not in "{[":
                i += 1
                continue
            span = _balanced_span(cand, i)
            if span is None:
                # Unbalanced opener (a stray "{" in prose): keep scanning, do not abandon it
                i += 1
                continue
            val = None
            try:
                val = json.loads(span)
            except json.JSONDecodeError as e:
                last_err = e
                # LLMs frequently emit invalid backslash escapes inside string values.
                repaired = _repair_invalid_escapes(span)
                if repaired != span:
                    try:
                        val = json.loads(repaired)
                    except json.JSONDecodeError:
                        pass
            if val is None:
                i += len(span)
                continue
            if want_dict and isinstance(val, list):
                if held_list is None:
                    held_list = val
                i += len(span)
                continue
            return val

    if held_list is not None:
        return held_list
    if last_err:
        raise last_err
    raise ValueError("no JSON object found in response")
