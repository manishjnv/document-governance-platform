# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Ctrl-C propagation: the abort flag, live-process registry and process-tree kill."""
from __future__ import annotations

import os
import signal
import subprocess
import threading

from vvaharness.util import logs

# Token accounting is shared with the SDK backend (util/tokens.py); re-exported for legacy imports

log = logs.get_logger(__name__)



# Only the main thread sees KeyboardInterrupt, so s4/s6 pool workers call abort() on Ctrl-C.

_ABORT = threading.Event()
_LIVE_LOCK = threading.Lock()
_LIVE: set[subprocess.Popen] = set()


def aborted() -> bool:
    return _ABORT.is_set()


#: Own process group per `claude` so the whole tree can be signalled; Windows uses ``taskkill /T``
_NEW_GROUP_KW: dict = {} if os.name == "nt" else {"start_new_session": True}


def _kill_tree(proc: subprocess.Popen) -> None:
    """Kill *proc* AND the tool processes it spawned."""
    # kill() alone orphans the binary's tool subprocesses; ALWAYS the child's pgid, never 0 or ours
    if proc.poll() is not None:
        return
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                           capture_output=True, timeout=10)
            return
        try:
            pgid = os.getpgid(proc.pid)
        except (OSError, AttributeError):
            pgid = None
        # Guard against ever signalling our own group, however that came about.
        if pgid is not None and pgid != os.getpgrp():
            os.killpg(pgid, signal.SIGKILL)
        else:
            proc.kill()
    except Exception:
        # Last resort: the direct child, which is what this did before.
        try:
            proc.kill()
        except Exception:
            pass


def _stop_tree(proc: subprocess.Popen, grace: float) -> None:
    """SIGINT proc's own process group, wait up to grace, then _kill_tree() if it ignored that."""
    # A session that flushes its session file on SIGINT stays resumable; SIGKILL never does.
    if proc.poll() is not None:
        return
    if os.name == "nt":
        _kill_tree(proc)
        return
    try:
        pgid = os.getpgid(proc.pid)
        if pgid != os.getpgrp():
            os.killpg(pgid, signal.SIGINT)
    except (OSError, AttributeError):
        pass
    try:
        proc.wait(timeout=grace)
    except subprocess.TimeoutExpired:
        _kill_tree(proc)


#: For processes not in _LIVE (the cli_mcp bridge's SDK-launched binary); hooks must never raise
_ABORT_HOOKS: list = []


def register_abort_hook(fn) -> None:
    """Register *fn* to be called by :func:`abort`, for out-of-band `claude` processes."""
    if fn not in _ABORT_HOOKS:
        _ABORT_HOOKS.append(fn)


def abort() -> int:
    """Set the stop flag and kill every in-flight `claude` subprocess, returning the count signalled."""
    _ABORT.set()
    with _LIVE_LOCK:
        procs = list(_LIVE)
    for p in procs:
        _kill_tree(p)
    # Iterate a copy: a hook may register another mid-teardown
    for hook in list(_ABORT_HOOKS):
        try:
            hook()
        except Exception:
            pass
    return len(procs)


def reset_abort() -> None:
    """Clear the global stop flag, so a programmatic abort() doesn't poison later repos in a batch run."""
    _ABORT.clear()
