# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Running a scan from Python, through the same entry point and trust gate as the CLI."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

_PROFILE_DIR = Path(__file__).resolve().parent.parent / "config" / "profiles"


class ScanOptionsError(ValueError):
    """Raised when scan options cannot be turned into a valid command line."""


def profile_path(profile: str | Path) -> Path:
    """A shipped profile resolved by bare name, or an explicit path used as given."""
    candidate = Path(profile)
    if candidate.suffix or candidate.parent != Path():
        return candidate
    shipped = _PROFILE_DIR / f"{profile}.yaml"
    if not shipped.is_file():
        available = sorted(p.stem for p in _PROFILE_DIR.glob("*.yaml"))
        raise ScanOptionsError(f"no shipped profile {profile!r}; available: {available}")
    return shipped


@dataclass(frozen=True)
class ScanOptions:
    """One scan's inputs; anything omitted keeps the CLI's own default for that flag."""

    repo: Path | str
    profile: str | Path | None = None
    stop_after: str | None = None
    resume: bool = False
    application_id: str | None = None
    repo_name: str | None = None
    extra_argv: tuple[str, ...] = field(default_factory=tuple)

    def argv(self) -> list[str]:
        """This scan as a ``vvaharness scan`` argument list, for running and for reproducing."""
        argv = ["--repo", str(self.repo)]
        if self.profile is not None:
            argv += ["--config", str(profile_path(self.profile))]
        for flag, value in (("--stop-after", self.stop_after),
                            ("--application-id", self.application_id),
                            ("--repo-name", self.repo_name)):
            if value:
                argv += [flag, value]
        resume = ["--resume"] if self.resume else []
        return argv + resume + list(self.extra_argv)


@dataclass(frozen=True)
class ScanResult:
    """A finished scan's outcome, plus the argv that produced it so a run is reproducible."""

    exit_code: int
    argv: tuple[str, ...]

    @property
    def ok(self) -> bool:
        """True when the scan completed with no in-pipeline failure."""
        return self.exit_code == 0


def scan(options: ScanOptions) -> ScanResult:
    """Runs one scan through ``vvaharness scan``'s own entry point, returning its outcome."""
    from vvaharness.orchestrator import entry
    argv = options.argv()
    _reject_unknown_flags(argv)
    return ScanResult(exit_code=entry.main(argv), argv=tuple(argv))


def _reject_unknown_flags(argv: list[str]) -> None:
    """Fails before any work when extra_argv carries a flag the CLI does not define."""
    from vvaharness.orchestrator import entry
    try:
        entry.build_parser().parse_args(argv)
    except SystemExit as exc:
        raise ScanOptionsError(f"invalid scan options: {argv}") from exc


__all__ = ["ScanOptions", "ScanOptionsError", "ScanResult", "profile_path", "scan"]
