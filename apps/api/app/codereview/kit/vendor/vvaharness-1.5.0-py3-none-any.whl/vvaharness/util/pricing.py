# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Operator-supplied model price table used to cost a run's token counts."""
# USD/Mtok by exact model id; one read_fraction can't fit 0.50x and 0.10x; must NEVER fail a scan
from __future__ import annotations

import hashlib
import os
import threading
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import TypedDict

import yaml

from vvaharness.util import console

PRICING_FILE_ENV = "VVAHARNESS_PRICING_FILE"
_PER_MTOK = 1_000_000.0

# Last resort only: Anthropic 5-min-TTL economics, WRONG for most OpenAI models (writes free)
FALLBACK_CACHE_READ_FRACTION = 0.10
FALLBACK_CACHE_WRITE_MULTIPLIER = 1.25


@dataclass(frozen=True)
class CacheRateDefaults:
    """Table-declared multipliers for deriving absent cache rates."""

    read_fraction: float = FALLBACK_CACHE_READ_FRACTION
    write_multiplier: float = FALLBACK_CACHE_WRITE_MULTIPLIER
    #: True when both values came from this module, not the table, so the load path can say so
    is_fallback: bool = True


class TokenBucket(TypedDict, total=False):
    """One ``util.tokens`` per-phase bucket — the unit of costing."""

    prompt: int
    completion: int
    cache_read: int
    cache_write: int
    calls: int


@dataclass(frozen=True)
class ModelPricing:
    """Dollar rates per million tokens for one exact model id."""

    input_per_mtok: float
    output_per_mtok: float
    cache_read_per_mtok: float | None = None
    cache_creation_per_mtok: float | None = None


@dataclass(frozen=True)
class PricingTable:
    """A loaded price table plus the provenance recorded in the manifest."""

    models: dict[str, ModelPricing]
    path: str
    sha256: str
    source: str
    cache_defaults: CacheRateDefaults = CacheRateDefaults()


def _rate(raw: Mapping[str, object], key: str) -> float | None:
    value = raw.get(key)
    if isinstance(value, bool) or not isinstance(value, int | float):
        return None
    return float(value)


def _model_pricing(raw: object) -> ModelPricing | None:
    if not isinstance(raw, Mapping):
        return None
    inp = _rate(raw, "input_per_mtok")
    out = _rate(raw, "output_per_mtok")
    if inp is None or out is None:
        return None
    return ModelPricing(
        input_per_mtok=inp,
        output_per_mtok=out,
        cache_read_per_mtok=_rate(raw, "cache_read_per_mtok"),
        cache_creation_per_mtok=_rate(raw, "cache_creation_per_mtok"),
    )


def _parse_cache_defaults(data: object) -> CacheRateDefaults:
    """Read optional table-level ``cache_rate_defaults``."""
    if not isinstance(data, Mapping):
        return CacheRateDefaults()
    raw = data.get("cache_rate_defaults")
    if not isinstance(raw, Mapping):
        return CacheRateDefaults()
    read = _rate(raw, "read_fraction")
    write = _rate(raw, "write_multiplier")
    if read is None and write is None:
        return CacheRateDefaults()
    return CacheRateDefaults(
        read_fraction=(FALLBACK_CACHE_READ_FRACTION if read is None else read),
        write_multiplier=(FALLBACK_CACHE_WRITE_MULTIPLIER
                          if write is None else write),
        is_fallback=False,
    )


def _parse_models(data: object) -> dict[str, ModelPricing]:
    if not isinstance(data, Mapping):
        return {}
    raw_models = data.get("models")
    if not isinstance(raw_models, Mapping):
        return {}
    out: dict[str, ModelPricing] = {}
    for name, spec in raw_models.items():
        priced = _model_pricing(spec)
        if isinstance(name, str) and priced is not None:
            out[name] = priced
    return out


def _table_from_file(path: Path, source: str) -> PricingTable | None:
    try:
        blob = path.read_bytes()
        data: object = yaml.safe_load(blob.decode("utf-8"))
    except (OSError, UnicodeDecodeError, yaml.YAMLError) as e:
        console.write(f"  [pricing] WARNING: ignoring price table {path}: {e}")
        return None
    models = _parse_models(data)
    if not models:
        console.write(f"  [pricing] WARNING: no usable model rates in {path}; "
                      f"costs will be reported as null")
        return None
    defaults = _parse_cache_defaults(data)
    # The manifest records provenance only, so this stderr note is the ONLY sign of derived rates
    for name, priced in models.items():
        omitted = [field for field, rate in
                   (("cache_read_per_mtok", priced.cache_read_per_mtok),
                    ("cache_creation_per_mtok", priced.cache_creation_per_mtok))
                   if rate is None]
        if not omitted:
            continue
        origin = ("built-in fallback — Anthropic-shaped, verify it suits this "
                  "model's provider" if defaults.is_fallback
                  else "from cache_rate_defaults")
        console.write(f"  [pricing] NOTE: {name} omits {', '.join(omitted)}; deriving "
                      f"from input_per_mtok at reads x{defaults.read_fraction:g}, "
                      f"writes x{defaults.write_multiplier:g} ({origin})")
    return PricingTable(models=models, path=str(path),
                        sha256=hashlib.sha256(blob).hexdigest(), source=source,
                        cache_defaults=defaults)


def _selected_source(cfg_pricing_file: str | None) -> tuple[str, str] | None:
    env_path = os.environ.get(PRICING_FILE_ENV, "").strip()
    if env_path:
        return env_path, "env"
    if cfg_pricing_file:
        return str(cfg_pricing_file), "config"
    return None


def load_pricing(cfg_pricing_file: str | None) -> PricingTable | None:
    """Load the active price table, or ``None`` when costing is unavailable."""
    # ``VVAHARNESS_PRICING_FILE`` overrides *cfg_pricing_file*.
    selected = _selected_source(cfg_pricing_file)
    if selected is None:
        return None
    raw_path, source = selected
    return _table_from_file(Path(raw_path).expanduser(), source)


#: Keyed on the RESOLVED (path, source), so a VVAHARNESS_PRICING_FILE change is a distinct entry
_PRICING_CACHE: dict[tuple[str, str] | None, PricingTable | None] = {}
_PRICING_CACHE_LOCK = threading.Lock()


def load_pricing_cached(cfg_pricing_file: str | None) -> PricingTable | None:
    """Memoized ``load_pricing`` — same contract, one disk read per distinct resolved table."""
    selected = _selected_source(cfg_pricing_file)
    with _PRICING_CACHE_LOCK:
        if selected not in _PRICING_CACHE:
            _PRICING_CACHE[selected] = (
                _table_from_file(Path(selected[0]).expanduser(), selected[1])
                if selected is not None else None
            )
        return _PRICING_CACHE[selected]


def bucket_cost_usd(bucket: TokenBucket, pricing: ModelPricing,
                    cache_defaults: CacheRateDefaults | None = None) -> float:
    """Cost one token bucket at *pricing*'s rates."""
    d = cache_defaults or CacheRateDefaults()
    cache_write = bucket.get("cache_write", 0)
    fresh = max(bucket.get("prompt", 0) - cache_write, 0)
    write_rate = (pricing.input_per_mtok * d.write_multiplier
                  if pricing.cache_creation_per_mtok is None
                  else pricing.cache_creation_per_mtok)
    read_rate = (pricing.input_per_mtok * d.read_fraction
                 if pricing.cache_read_per_mtok is None
                 else pricing.cache_read_per_mtok)
    total = (fresh * pricing.input_per_mtok
             + cache_write * write_rate
             + bucket.get("cache_read", 0) * read_rate
             + bucket.get("completion", 0) * pricing.output_per_mtok)
    return total / _PER_MTOK
