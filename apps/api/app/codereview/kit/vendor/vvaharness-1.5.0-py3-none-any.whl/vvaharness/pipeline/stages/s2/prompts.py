# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 2's prompt text: the system brief, the evidence block and the repair re-ask."""
from __future__ import annotations

from vvaharness.evidence import (
    ThreatEvidence,
    render_api_artefacts_block,
    render_components_block,
    render_config_reps_block,
    render_docs_block,
    render_entry_points_block,
    render_inventory_block,
    render_language_block,
    render_manifests_block,
    render_modules_block,
)
from vvaharness.models import CVE, AppProfile, ContextPackage, Control
from vvaharness.rules.repo_kinds import BASELINES, STRIDE_BY_KIND, repo_kind


SYSTEM = """\
You are an application-security threat modeler. You receive a STRUCTURAL
snapshot of a codebase — docs, manifests, the component list, the
agentically-mapped MODULES (purpose-tagged) and ENTRY POINTS (kind +
auth-reachability), representative CONFIG files, and API-contract artefacts —
NOT the source code bodies. From this you produce a threat model: what the
system IS, what it PROTECTS, where untrusted input ENTERS, and what an
attacker would TRY.

A threat survives a patch. "Heap overflow in parser.c:412" is a vulnerability;
"RCE via untrusted media parsing" is a threat. You produce threats.

Work through these stages:

1. SYSTEM CONTEXT — from docs/manifests/tree: what is this application, what
   does it do, who runs it, where (service / CLI / library / batch job)?

2. ASSETS — what does it protect or produce? Data (PII, payment data, secrets,
   credentials), process integrity, service availability, downstream consumers.
   Assign sensitivity: low|medium|high|critical.

3. TRUST BOUNDARIES — every place untrusted input enters or privilege changes.
   Derive from manifests, framework hints in the tree, and docs. Include
   supply-chain and infra/IAM surfaces. Name the crossing
   ("unauth network → application logic", "tenant A → shared DB").

4. THREATS — for EACH trust boundary, walk STRIDE (Spoofing, Tampering,
   Repudiation, Info-disclosure, DoS, Elevation) and emit the plausible ones.
   Use prior CVEs as EVIDENCE that raises likelihood; design controls LOWER it.
   Score impact (low|medium|high|critical|existential) and likelihood
   (very_rare|rare|possible|likely|almost_certain). Assign ids T1, T2, … in the
   order you emit them; ordering does not matter — the caller ranks
   deterministically. Do NOT drop a threat because you are unsure: a plausible
   threat with likelihood "rare" is useful, a missing threat is not. Downstream
   stages re-check every threat against the real source code and discard the ones
   that do not hold up.

5. OPEN QUESTIONS — things the snapshot can't tell you (deployment exposure,
   upstream WAF, who supplies inputs, risk appetite).

Respond with ONLY a JSON object — no prose, no markdown fences:
{
  "system_context": "1-3 paragraphs",
  "assets": [{"name":"str","description":"str","sensitivity":"low|medium|high|critical"}],
  "trust_boundaries": [{"entry_point":"str","crossing":"str","reachable_assets":["asset name"]}],
  "threats": [{"id":"T1","threat":"one sentence, names the outcome",
               "actor":"remote_unauth|remote_auth|adjacent_network|local_user|local_admin|supply_chain|insider",
               "surface":"entry_point name from trust_boundaries",
               "surface_files":["repo-relative/path.py", "..."],
               "asset":"asset name",
               "impact":"low|medium|high|critical|existential",
               "likelihood":"very_rare|rare|possible|likely|almost_certain",
               "controls":"current mitigations or 'none'",
               "evidence":"CVE ids / commit hashes or ''"}],
  "open_questions": ["str"]
}

Every element of "assets", "trust_boundaries" and "threats" MUST be an object
carrying the keys shown above — never a bare string. A bare string where an
object is required fails schema validation and discards the ENTIRE response;
it is the one malformation observed to do so in production runs.

Coverage rules:
  - Every trust_boundary MUST appear as the surface of ≥1 threat.
  - Every threat whose surface names concrete code MUST list every file that
    implements or is reachable from it in "surface_files", using the exact
    repo-relative paths from FILE INVENTORY / ENTRY POINTS / MODULES above —
    never a path you have not seen there. An empty "surface_files" on a
    code-backed threat means no later stage can act on it.
  - Every MINIMUM BASELINE item, if any are supplied, MUST be either the basis of
    a threat (with "evidence" starting "baseline: <ID>") or named in
    open_questions with a one-clause reason. Never drop a baseline item without a
    written trace.

BREADTH — account for the WHOLE inventory, not just the application code:

FILE INVENTORY is the complete list of in-scope files. It is the ONLY exhaustive
one: MODULES names modules, not files, and ENTRY POINTS covers a handful of
handlers. Every path you may name comes from the inventory.

You are the only stage that decides what gets looked at. A file named in no
threat's "surface_files" is never opened by any later stage — not skimmed, not
scanned, not reviewed. Silently leaving one out is a decision that nothing
downstream can reverse or even see.

So work the inventory directory by directory and cover it:
  - Templates and views (templates/, views/, *.html, *.jsx, *.vue) hold stored
    and reflected XSS, and they are the single most commonly skipped directory.
    An HTML template that renders user-controlled data is a threat surface.
  - Container, orchestration and CI files (Dockerfile*, docker-compose*.y*ml,
    *.tf, k8s manifests, .github/**, uwsgi.ini, nginx*.conf, Procfile) hold
    hardcoded secrets, disabled TLS, privileged containers and exposed debug
    ports. These are real findings and they live nowhere else.
  - Dependency manifests (requirements*.txt, package.json, pom.xml, go.mod)
    pin vulnerable versions.
  - Client-side code (frontend/, static/, *.js) holds embedded credentials,
    disabled auth checks and unvalidated redirects.
  - __init__.py, base classes and shared helpers are where an absent control
    that looks per-route is actually centralised — or absent everywhere.

Do not merge unrelated files into one catch-all threat to make the arithmetic
work: a threat naming twenty files across five directories is one unit for one
claim and it investigates none of them properly. Emit a SEPARATE, specifically
worded threat per coherent surface — per template, per infra file, per
blueprint. More threats, each narrow and each with its own small
"surface_files", is the shape that works.

BREADTH WITHIN A FILE — one file is not one threat:

Covering the inventory is necessary, not sufficient. A SINGLE file routinely
holds MANY distinct weakness classes, and a small repo can be one file holding
twenty. SQL injection, command injection, reflected XSS, path traversal, SSRF,
unsafe deserialization, XXE, open redirect, weak crypto, a hardcoded secret and
a missing authorization check are ELEVEN separate threats with eleven separate
fixes, and all eleven fit in one 200-line handler module. One threat saying
"this file does not validate input" is not a threat model of that file; it is a
sentence about it, and every class it folded in is lost for the whole scan.

So after you have covered the inventory by directory, go back over each file you
named and ask what ELSE is in it. For every file, enumerate one threat per
weakness class you have evidence for — a different sink, a different sanitizer
missing, a different asset, a different fix — and give each its own "threat"
wording naming that class. Two threats on the same path with the same
"surface_files" are correct and expected when they are different classes.
Never fold two classes into one broader claim because they share a file, and
never stop at one threat for a file you can name a second class in.

Then check your own work before you answer: take the inventory, subtract every
path you named across all "surface_files", and look at what is left. For each
remaining file either add the threat you missed, or — only if it genuinely
cannot carry a security weakness — leave it. Put the count and the reason in
open_questions as: "unreviewed: <n> file(s) — <reason>"."""
#: Generic on purpose: native file-tool names differ per route.
_AGENTIC_SYSTEM_LINE = (
    "\n\nYou have read-only tools to read and search the repository's files: "
    "you may open the configuration files listed by path in the evidence — "
    "and any other repository file — to confirm details before emitting the "
    "JSON."
)

#: Appended after _AGENTIC_SYSTEM_LINE only when ctx.graph_handle is present.
_GRAPH_TOOLS_SYSTEM_LINE = (
    "\n\nYou also have 6 read-only graph tools over the analyzed codebase: "
    "GraphContext(file, symbol) for callers, callees, imports, implementors and "
    "call paths in ONE call — prefer it over GraphNeighbors; "
    "GraphImpact(file, symbol, direction) for transitive reachability, where "
    "direction=\"upstream\" returns everything that can reach the symbol and an "
    "empty result means nothing calls it, so it is an entry point or dead code; "
    "GraphNeighbors(file, function) for direct callers/callees only; "
    "GraphCommunityOf(file) for which module a file belongs to; "
    "GraphImporters(file) for files that import it; and "
    "GraphSinksInCommunity(community) for unsafe sinks already known in a "
    "module. Use them to confirm trust boundaries and blast radius before "
    "emitting the JSON."
)


#: Only when step2.bash grants the shell; with it off, naming `execute` points at an uncallable tool
_SHELL_SYSTEM_LINE = (
    "\n\nYou also have `execute`, a read-only POSIX shell (`grep`, `sed`, "
    "`awk`, `head`, `python3`, pipes; `rg` is NOT installed). Reach for it when "
    "a whole file is the wrong unit of answer: "
    "`grep -rEn 'pat1|pat2' --include='*.py' .` locates every occurrence of "
    "several patterns with paths and line numbers in ONE call, `grep -rl` and "
    "`grep -rc` give filenames and counts, and `sed -n '40,80p' path` returns "
    "exactly the span you want. This is how you cover a wide inventory "
    "cheaply — one search across every router beats opening them one at a "
    "time, and everything a tool returns is re-sent on every later turn of "
    "this session. grep exiting 1 means no match, which is an answer. "
    "Read-only commands only: no writes, no installs, no network, and stay "
    "inside this repository."
)
def _baseline_block(ev: ThreatEvidence, ctx: ContextPackage | None, mode: str) -> tuple[set[str], str]:
    if mode == "none":
        return set(), ""
    kinds = {"web-api"} if mode == "owasp" else repo_kind(ev, ctx)
    seen: set[str] = set()
    items: list[tuple[str, str]] = []
    for k in sorted(kinds):
        for bid, text in BASELINES.get(k, ()):
            if bid not in seen:
                seen.add(bid)
                items.append((bid, text))
    if not items:
        return kinds, ""
    body = "\n".join(f"  - [{bid}] {text}" for bid, text in items)
    return kinds, (
        f"\nMINIMUM BASELINE for repo kind {{{', '.join(sorted(kinds))}}} — this is "
        f"a coverage floor, not a checklist to tick. A disposition is REQUIRED for "
        f"EVERY item; silent omission is a contract violation. For each item, do "
        f"exactly one of:\n"
        f"  (a) emit a threat whose \"evidence\" starts with \"baseline: <ID>\", "
        f"setting likelihood to reflect how strongly this snapshot supports it "
        f"(\"rare\" is a perfectly good answer for a plausible-but-unconfirmed "
        f"surface). Continue the string after the id with the concrete evidence "
        f"for THIS repo — e.g. \"baseline: BL-WEB-A03; routes/search.ts builds "
        f"SQL by string concatenation\" — and give \"surface\" a real path when "
        f"one exists. Write the bare id alone only when this snapshot genuinely "
        f"offers nothing; a threat pinned to no file forfeits its guaranteed "
        f"review unit in a later stage;\n"
        f"  (b) add an open_questions entry starting \"<ID>: \" with a one-clause "
        f"reason no matching surface exists in the evidence above.\n"
        f"You are looking at STRUCTURE, not source code, so you usually cannot rule "
        f"an item out — when in doubt, choose (a) with a low likelihood. A later "
        f"stage re-checks every threat against the real code.\n{body}\n")
def _build_user_prompt(repo_name: str, ev: ThreatEvidence,
                       cves: list[CVE], controls: list[Control],
                       app_profile: AppProfile | None = None,
                       baseline_block: str = "") -> str:
    lang_block = render_language_block(ev)
    comp_block = render_components_block(ev)
    inv_block = render_inventory_block(ev)
    mod_block = render_modules_block(ev)
    ep_block = render_entry_points_block(ev, STRIDE_BY_KIND)
    cfg_block = render_config_reps_block(ev)
    api_block = render_api_artefacts_block(ev)
    docs_block = render_docs_block(ev)
    manifest_block = render_manifests_block(ev)

    cve_block = "\n".join(
        f"  - {c.id} (CVSS {c.cvss}, {'patched' if c.patched else 'UNPATCHED'}): {c.summary}"
        for c in cves
    ) or "  (none on file)"
    ctl_block = "\n".join(
        f"  - [{c.kind}] {c.name} → protects: {', '.join(c.protects) or 'global'}"
        + (f" — {c.notes}" if c.notes else "")
        for c in controls
    ) or "  (none on file)"

    cmdb_block = ""
    if app_profile:
        cmdb_block = (app_profile.to_prompt_block()
                      + "\n  → Use externally_facing to set default actor "
                        "(remote_unauth only if YES; otherwise adjacent_network/"
                        "remote_auth). Use PCI/PAN/PII flags to set asset "
                        "sensitivity = critical.\n\n")

    notes_block = ""
    if ev.s1_notes:
        notes_block = f"\nMAPPER OBSERVATIONS (s1 free-form):\n{ev.s1_notes}\n"

    # Ordered by decreasing staticness for a stable cache prefix; repo_root deliberately unrendered
    return f"""{baseline_block}{cmdb_block}LANGUAGE BREAKDOWN:
{lang_block}

COMPONENTS (top-level directories):
{comp_block}

FILE INVENTORY — every in-scope file, grouped by directory. This is the COMPLETE
list and the only exhaustive one in this prompt; MODULES below names modules,
not files. Every path you put in "surface_files" must come from here, and every
path here is one no later stage will ever open unless you name it:
{inv_block}

REPRESENTATIVE CONFIGURATION (one per component, post-dedup — entries under a
"=== path ===" header carry redacted, length-capped file contents revealing
data stores, message buses, key/secret managers, TLS posture, external
endpoints; entries listed as "- path" are present by name only):
{cfg_block}

API CONTRACT ARTEFACTS (OpenAPI/Swagger/Protobuf/GraphQL/WSDL/META-INF — the
explicit external interface):
{api_block}

DOCUMENTATION:
{docs_block}

BUILD / DEPENDENCY MANIFESTS:
{manifest_block}

KNOWN PRIOR CVEs (use as evidence; raises likelihood):
{cve_block}

DESIGN CONTROLS (lower likelihood where they apply):
{ctl_block}

TARGET: {repo_name}
PRIMARY LANGUAGE: {ev.primary_language or 'unknown'}
FILES IN AST FRONTIER: {ev.file_count} (from {ev.original_file_count} total in-scope files)

MODULES (s1-mapped — treat as asset candidates):
{mod_block}

ENTRY POINTS (s1-mapped — these ARE the trust boundaries; STRIDE hint per kind):
{ep_block}
{notes_block}
Produce the threat model JSON now. Anchor each trust_boundary.entry_point to
one of the ENTRY POINTS above where possible; use the STRIDE hint to seed
threats per boundary."""
def _repair_json_prompt(raw: str, err: Exception) -> str:
    """Returns a one-shot prompt asking the model to restructure `raw` into the schema without inventing content."""
    return f"""REPAIR TASK:
The previous threat-model response failed to parse against the required
schema. Return ONLY a corrected JSON object that (a) is syntactically valid
JSON and (b) matches the schema in the system prompt exactly — in particular,
every element of "assets", "trust_boundaries" and "threats" must be an object
with the keys shown there, never a bare string. Preserve the original content
faithfully: do not add, remove, or reword any asset, boundary, or threat
beyond what restructuring requires.

PARSE/VALIDATION ERROR:
{type(err).__name__}: {err}

BROKEN RESPONSE:
{raw}
"""
