# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The 3-gate evidence status block (source, sink, missing-control) as its own reusable sub-model."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

# Deliberately DISTINCT from s11's validation.enums.gates.GateStatus; never co-imported
EvidenceGateStatus = Literal["pass", "partial", "fail"]
# Back-compat alias, re-exported in models.__all__; prefer ``EvidenceGateStatus`` in new code.
GateStatus = EvidenceGateStatus


class Gates(BaseModel):
    # Default "fail" is conservative: a verdict omitting a gate still validates, not discarded
    source: EvidenceGateStatus = Field(default="fail", description="Gate A — attacker-controlled source identified")
    sink: EvidenceGateStatus = Field(default="fail", description="Gate B — security-relevant sink reachable from source")
    missing_control: EvidenceGateStatus = Field(default="fail", description="Gate C — missing/insufficient validation")
