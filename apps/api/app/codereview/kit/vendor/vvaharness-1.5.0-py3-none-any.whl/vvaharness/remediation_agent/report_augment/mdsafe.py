# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Escape untrusted (LLM/plugin-controlled) text before interpolating it into Markdown (CWE-79)."""
from __future__ import annotations

# Folds every splitlines() separator (U+2028/9) and strips bidi/zero-width (Trojan-Source) chars
from vvaharness.models import _MD_INVISIBLE_RX, _MD_LINEBREAK_RX

# Metacharacters forging emphasis/links/HTML/table cells; newlines are collapsed to spaces FIRST
_MD_ESCAPE = {
    "\\": "\\\\", "`": "\\`", "*": "\\*", "_": "\\_",
    "[": "\\[", "]": "\\]", "|": "\\|", "#": "\\#",
    "<": "&lt;", ">": "&gt;", "&": "&amp;",
}


def _md_escape(value: object) -> str:
    """Escape untrusted (model/DTO-controlled) text for safe inline Markdown."""
    text = _MD_LINEBREAK_RX.sub(" ", str(value))
    text = _MD_INVISIBLE_RX.sub("", text)
    return "".join(_MD_ESCAPE.get(ch, ch) for ch in text)


def _md_code_span(value: object) -> str:
    """Render untrusted text as a safe inline code span."""
    # In a backtick span only backticks/controls break out; &<> still entity-escaped (CWE-79)
    text = _MD_LINEBREAK_RX.sub(" ", str(value))
    text = _MD_INVISIBLE_RX.sub("", text)
    text = text.replace("`", "")
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return f"`{text}`"
