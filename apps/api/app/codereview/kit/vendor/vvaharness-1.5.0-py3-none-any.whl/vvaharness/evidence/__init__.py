# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deterministic threat-model evidence: disk reads, docs, manifests, config reps, API artefacts."""
from __future__ import annotations

from vvaharness.evidence.api_artefacts import _API_SURFACE_GLOBS, gather_api_artefacts
from vvaharness.evidence.configs import (
    _CONFIG_EXTS,
    _CONFIG_REP_RAW_CEILING,
    _config_rep_contents,
    _select_config_reps,
    gather_config_reps,
)
from vvaharness.evidence.docs import (
    _DOC_CANDIDATES,
    _DOC_EXTRA_MAX,
    _DOC_NAME_RX,
    gather_docs,
)
from vvaharness.evidence.gather import ThreatEvidence, _cap_int, gather
from vvaharness.evidence.manifests import (
    _MANIFEST_CANDIDATES,
    _MANIFEST_RAW_CEILING,
    _apply_manifest_total_cap,
    _find_manifests,
    _structural_truncate,
    gather_manifests,
)
from vvaharness.evidence.read import _cap_text, _contained, _read_capped
from vvaharness.evidence.render import (
    render_api_artefacts_block,
    render_components_block,
    render_config_reps_block,
    render_docs_block,
    render_entry_points_block,
    render_inventory_block,
    render_language_block,
    render_manifests_block,
    render_modules_block,
)

__all__ = [
    "_API_SURFACE_GLOBS",
    "_CONFIG_EXTS",
    "_CONFIG_REP_RAW_CEILING",
    "_DOC_CANDIDATES",
    "_DOC_EXTRA_MAX",
    "_DOC_NAME_RX",
    "_MANIFEST_CANDIDATES",
    "_MANIFEST_RAW_CEILING",
    "ThreatEvidence",
    "_apply_manifest_total_cap",
    "_cap_int",
    "_cap_text",
    "_config_rep_contents",
    "_contained",
    "_find_manifests",
    "_read_capped",
    "_select_config_reps",
    "_structural_truncate",
    "gather",
    "gather_api_artefacts",
    "gather_config_reps",
    "gather_docs",
    "gather_manifests",
    "render_api_artefacts_block",
    "render_components_block",
    "render_config_reps_block",
    "render_docs_block",
    "render_entry_points_block",
    "render_inventory_block",
    "render_language_block",
    "render_manifests_block",
    "render_modules_block",
]
