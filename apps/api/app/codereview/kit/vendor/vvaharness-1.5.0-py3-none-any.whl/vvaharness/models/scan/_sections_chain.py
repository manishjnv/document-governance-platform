# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""FinalReport's chain, unreachable-file and threat-model renderers."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from vvaharness.models.scan._render import (
    _demote_md_headings,
    _escape_angles,
    _md_cell,
)
from vvaharness.models.scan.findings import Chain
from vvaharness.models.scan.threat import ThreatModel

if TYPE_CHECKING:
    from vvaharness.models.scan.report import FinalReport

log = logging.getLogger(__name__)

_UNPROMOTED_SHOWN = 20


def _chain_lines(report, n: int, c: Chain) -> list[str]:
    """One chain's rendered block, numbered by its 1-based ordinal in the sorted list."""
    steps_str = " → ".join(
        f"#{idx+1} {_md_cell(report.findings[idx].finding.title)}"
        for idx in c.steps
    )
    blocked = (
        f"  \n**Blocked by:** "
        f"{', '.join(_md_cell(x) for x in c.blocked_by_controls)}"
        if c.blocked_by_controls else ""
    )
    # "Requires" and "Blocked by" are opposites and must NEVER share a label (reads as mitigated)
    requires = (
        f"  \n**Requires:** "
        f"{', '.join(_md_cell(x) for x in c.preconditions)}"
        if c.preconditions else ""
    )
    # Model prose: escape angles here; folded cells use plain translate, never the fence walker
    reached = (
        "  \n**Reached via:** "
        f"{_escape_angles(_md_cell(c.entry_reachability))}"
        if c.entry_reachability else ""
    )
    out = [
        # Model title: a newline in it would terminate this heading; the "Chain N" ordinal stays out
        f"### Chain {n} — [{c.severity.value.upper()}] {_md_cell(c.title)}",
        f"**Path:** {steps_str}{reached}{requires}{blocked}",
    ]
    if c.link_evidence:
        # The model's hop-to-hop mechanisms, already id-rewritten upstream to this report's #N
        out.extend(["", "**Step links:**"])
        for ln in c.link_evidence:
            mech = (" — " + _escape_angles(_md_cell(ln.mechanism))
                    if ln.mechanism else "")
            loc = (f" (`{_md_cell(ln.file).replace(chr(96), chr(0x2CB))}"
                   f":{ln.line}`)" if ln.file and ln.line else "")
            out.append(f"- {ln.from_id} → {ln.to_id}{mech}{loc}")
    # Read straight off `severity_decision`: re-deriving from one bool words both edges wrong
    _decision_note = {
        "lift_withheld": ("severity not raised to the strongest "
                          "constituent finding"),
        "self_raise_capped": ("severity capped at the strongest "
                              "constituent finding"),
    }
    meta: list[str] = []
    if c.link_coverage:
        meta.append(f"Link coverage: {_md_cell(c.link_coverage)}")
    if note := _decision_note.get(c.severity_decision):
        meta.append(note)
    meta.extend(_md_cell(a) for a in c.quality_notes)
    meta.extend(_md_cell(a) for a in c.disclosures)
    if meta:
        out.extend(["", f"_{' · '.join(meta)}_"])
    out.extend([
        "",
        _demote_md_headings(c.narrative, escape_angles=True),
        "",
    ])
    return out

def _unpromoted_pairs_text(report: FinalReport) -> str:
    """The unpromoted (owner, target) pairs as `#N → #M`, capped at _UNPROMOTED_SHOWN."""
    pairs = report.unpromoted_links
    shown = ", ".join(f"#{o + 1} → #{t + 1}" for o, t in pairs[:_UNPROMOTED_SHOWN])
    more = len(pairs) - _UNPROMOTED_SHOWN
    return f"{shown} (+{more} more)" if more > 0 else shown

def _unpromoted_link_leadin(report: FinalReport) -> list[str]:
    """One italic note for feeds links no shipped chain carries; empty when there are none."""
    n = len(report.unpromoted_links)
    if not n:
        return []
    return [(f"_The chain pass marked {n} link(s) between findings as chain potential that "
             f"no chain below carries in order: {_unpromoted_pairs_text(report)}. Disclosed, "
             "not promoted: a chain needs link evidence, a marked link does not._"), ""]

def _chain_removal_leadins(report: FinalReport) -> list[str]:
    """Notes for chains removed before rendering, shown even when other chains survive."""
    return [line for note, n in (
        (f"_{report.chains_dropped} further proposed chain(s) were "
         "removed: their steps did not resolve to two or more "
         "distinct findings in this report._", report.chains_dropped),
        (f"_{report.chains_deduped} further proposed chain(s) were "
         "identical to a chain already shown and were collapsed._",
         report.chains_deduped),
        ((f"_{report.chains_invalid} further proposed chain(s) were removed: the reply "
          "wrote them in a shape this report could not read (a required field missing "
          "or unreadable)._"), report.chains_invalid),
    ) if n for line in (note, "")]

def _terminal_diversity_leadin(report: FinalReport) -> list[str]:
    """One italic note when several chains end at one place; empty when every chain ends apart."""
    # Keyed on the terminal LOCATION, not the index, so two copies of one sink count once
    n = len(report.chains)
    m = len({(f.file, f.line_start)
             for f in (report.findings[c.steps[-1]].finding for c in report.chains if c.steps)})
    if n <= m:
        return []
    return [(f"_{n} chain(s) below end at {m} distinct final step(s); a count of chains "
             "is not a count of distinct sinks._"), ""]

def _summary_reconciliation_note(report: FinalReport) -> list[str]:
    """One italic note under the summary when chains were removed; the summary is unparsed."""
    n = report.chains_dropped + report.chains_invalid
    if not n:
        return []
    return [(f"_{n} proposed chain(s) were removed before this report: their steps did not "
             "resolve to two or more distinct findings in this report, or the entry was "
             "written in a shape this report could not read; the summary above may still "
             "describe them._"), ""]

def _empty_chain_section_copy(report: FinalReport) -> list[str]:
    """Empty-section copy for no surviving chain; states only what reached this report."""
    clauses = [note for note, n in (
        (f"{report.chains_dropped} proposed chain(s) were removed "
         "because their steps did not resolve to two or more distinct "
         "findings in this report.", report.chains_dropped),
        (f"{report.chains_deduped} proposed chain(s) were identical to "
         "another and were collapsed.", report.chains_deduped),
        ((f"{report.chains_invalid} proposed chain(s) were written in a shape this report "
          "could not read and were removed."), report.chains_invalid),
        ((f"{len(report.unpromoted_links)} link(s) between findings were marked as chain "
          f"potential ({_unpromoted_pairs_text(report)}) but no surviving chain carries "
          "them."), len(report.unpromoted_links)),
    ) if n]
    if clauses:
        return [f"No exploit chains are reported — {' '.join(clauses)}", ""]
    return [("No exploit chains were identified — no chain entry combining findings "
             "reached this report."), ""]

def _chain_pass_caveat(report: FinalReport) -> list[str]:
    """The fixed caveat under every chain section a pass produced: the prose above is unparsed."""
    # No findings, no pass: the zero-findings report is built without one
    if not report.findings:
        return []
    return [("_Only chain entries the chain pass submitted are checked; a path the summary "
             "or a finding's Exploitability note above describes without one has not been "
             "checked._"), ""]

def _render_unreachable_appendix(report) -> list[str]:
    """Appendix listing the files named by no investigation unit, capped per `cap`."""
    cap = 200
    files = report.unreachable_files
    out = [
        "",
        "## Appendix — Files Named by No Investigation Unit "
        f"({len(files)})",
        "",
        (f"**{len(files)}** file(s) in scope were named by no "
         "investigation unit when the threat model was decomposed, so no "
         "review pass read them. Treat this list as the scan's coverage "
         "gap — a finding in one of these files cannot appear above."),
        "",
    ]
    for f in files[:cap]:
        # Repo-controlled paths: the backtick fold stops a hostile filename closing this span
        out.append(f"- `{_md_cell(f).replace(chr(96), chr(0x2CB))}`")
    if len(files) > cap:
        out.append(f"- _… and {len(files) - cap} more (full list in "
                   f"the s3 checkpoint manifest)_")
    out.append("")
    return out

def _app_profile_lines(report) -> list[str]:
    """The CMDB block, shared by the threat-model section and its no-threat-model fallback."""
    ap = report.app_profile
    if not ap:
        return []
    sens = ", ".join(s for s, ok in (
        ("PCI-scoped", ap.pci_scoped),
        ("processes PAN", ap.processes_pan),
        ("PII", ap.pii)) if ok) or "standard"
    return [
        "### Application profile (CMDB)",
        # CMDB-supplied, not tool-derived: escape, or a newline or `|` injects Markdown
        (f"- ID: `{_md_cell(ap.application_id).replace(chr(96), chr(0x2CB))}`"
         f"  ({_md_cell(ap.name) or '-'})"),
        f"- Externally facing: **{'YES' if ap.externally_facing else 'NO'}**",
        f"- Data sensitivity: {sens}",
        f"- Source: {_md_cell(ap.source)}",
        "",
    ]

def _ranked_threat_rows(tm: ThreatModel, without_unit: list[str] | None) -> list[str]:
    """The Ranked-threats table, with a unit column when S3's per-threat disposition is known."""
    header = "| ID | Threat | Actor | Surface | Asset | Impact | Likelihood | Controls |"
    rule = "|---|---|---|---|---|---|---|---|"
    if without_unit is not None:
        header += " Investigation unit |"
        rule += "---|"
    missing = set(without_unit or ())
    out = ["### Ranked threats", "", header, rule]
    for tid, t in zip(tm.threat_ids(), tm.threats, strict=True):
        row = (f"| {_md_cell(t.id)} | {_md_cell(t.threat)} | "
               f"{_md_cell(t.actor)} | {_md_cell(t.surface)} | "
               f"{_md_cell(t.asset)} | {_md_cell(t.impact)} | "
               f"{_md_cell(t.likelihood)} | "
               f"{_md_cell(t.controls) or '-'} |")
        if without_unit is not None:
            # Cause-neutral: no validated surface file, or a cached manifest older than the
            # threat model on --resume; the Pipeline Diagnostics line lists the same ids
            row += " **none — never reviewed** |" if tid in missing else " minted |"
        out.append(row)
    out.append("")
    return out


def _render_threat_model(report) -> list[str]:
    tm = report.threat_model
    out = ["## Threat Model", ""]
    out.extend(_app_profile_lines(report))
    if tm.system_context:
        out.extend(["### System context", "",
                    _demote_md_headings(tm.system_context,
                                        escape_angles=True), ""])
    if tm.assets:
        out.extend(["### Assets", "",
                    "| Asset | Sensitivity | Description |",
                    "|---|---|---|"])
        for a in tm.assets:
            out.append(f"| {_md_cell(a.name)} | {_md_cell(a.sensitivity)} "
                       f"| {_md_cell(a.description)} |")
        out.append("")
    if tm.trust_boundaries:
        out.extend(["### Trust boundaries", ""])
        for b in tm.trust_boundaries:
            ra = ", ".join(_md_cell(x) for x in b.reachable_assets) or "-"
            out.append(f"- **{_md_cell(b.entry_point)}** — "
                       f"{_md_cell(b.crossing)} → {ra}")
        out.append("")
    if tm.threats:
        out.extend(_ranked_threat_rows(tm, report.threats_without_unit))
    if tm.open_questions:
        # Model prose can read like a count; labelled, not unified with s3_unreachable_files
        out.extend(["### Open questions", "",
                   ("_Model-authored during threat modeling — an "
                    "estimate, not a computed count; see this report's "
                    "own coverage figures (e.g. unreachable files, "
                    "below) for the deterministic numbers._"),
                   ""])
        out.extend(f"- {_md_cell(q)}" for q in tm.open_questions)
        out.append("")
    return out
