# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Host-literal predicates, shared so copies cannot disagree."""
# Shared so copies cannot disagree (an earlier pair split on 127.0.0.2); spelling only, NO lookups
from __future__ import annotations

import ipaddress

#: Hostnames that name the local machine (compare lower-cased).
_LOCAL_NAMES = {"localhost", "localhost."}


def ip_literal(host: str):
    """``host`` parsed as an IP address, or ``None`` when it is a name."""
    try:
        return ipaddress.ip_address(host.strip().strip("[]"))
    except ValueError:
        return None


def is_loopback_host(host: str) -> bool:
    """True if ``host`` is *spelled* as the local machine: ``localhost`` or a loopback IP literal."""
    if not host:
        return False
    h = host.strip().strip("[]")
    if h.lower() in _LOCAL_NAMES:
        return True
    ip = ip_literal(h)
    return bool(ip and ip.is_loopback)
