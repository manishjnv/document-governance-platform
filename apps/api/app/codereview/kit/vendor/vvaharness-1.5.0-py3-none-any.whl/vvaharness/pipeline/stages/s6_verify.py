# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Step 6 — adversarial verification; only TRUE_POSITIVE findings continue to s7."""
from __future__ import annotations
from vvaharness.util import logs

import contextlib
import json
import os
import queue
import re
import tempfile
import threading
import time
from collections import Counter
from collections.abc import Callable, Collection
from concurrent.futures import FIRST_COMPLETED, Executor, Future, wait
from datetime import UTC, datetime
from functools import partial
from pathlib import Path

from vvaharness.backends.harness.models import TruncatedResponseError
from vvaharness.backends.llm import cli
from vvaharness.backends.llm.cli import GuardrailBlocked
from vvaharness.backends.llm.models import (
    ModelRefusal,
    call_timeout_error,
    guardrail_gate_hit,
    refusal_resend_allowed,
    validate_detection_tools,
)
from vvaharness.backends.llm.registry import resolve
from vvaharness.evidence import _cap_int
from vvaharness.models import ContextPackage, DroppedFinding, Finding
from vvaharness.orchestrator.store import ensure_state_dir
from vvaharness.pipeline.stages.replay import settle_future
from vvaharness.pipeline.stages.s5.enrich import FileCache
from vvaharness.pipeline.stages.s6.batching import (
    Item,
    filed_lines,
    label,
    plan_batches,
    sweep_ceiling_secs,
    sweep_effort,
)
from vvaharness.pipeline.stages.s6.outcomes import (
    VerificationOutcome,
    apply_outcome,
    classify,
    discovered,
    remap_reason_ids,
    unverified,
)
from vvaharness.pipeline.stages.s6.session import verify_batch
from vvaharness.report.redact import redact
from vvaharness.util import console
from vvaharness.util import errlog as _errlog
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.response_quality import (
    is_deterministic_failure,
    is_structured_output_failure,
    is_timeout_failure,
)
from vvaharness.util.warn_once import warn_once
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

#: Heartbeat and ceiling-check wake interval; module-level so tests can shrink it, not a config knob
_HEARTBEAT_SECS = 60.0
# Verdicts needed before "all at one score" is a signal, not agreement; deliberately not tied to batch_size
_UNIFORM_CONFIDENCE_MIN = 12
#: Marks a verdict reached by replaying a deadline-killed session tool-free from its transcript
_REPLAYED_LABEL = "[replayed] "
# Listed in warn_once._REGISTRY_SITES: reset per repo in a batch run
_WARNED_REPLAYED_DISCOVERIES: set[str] = set()


class _DaemonPool(Executor):
    """Up to *max_workers* daemon threads on a FIFO queue; a stalled batch never holds exit."""

    # Not ThreadPoolExecutor: its atexit hook joins every worker whatever the daemon flag.
    # The bound is load-bearing: a captive batch keeps its slot, which _run_wave's sweep counts
    def __init__(self, max_workers: int, thread_name_prefix: str = "s6-verify") -> None:
        if max_workers <= 0:
            raise ValueError("max_workers must be greater than 0")
        self._max_workers = max_workers
        self._prefix = thread_name_prefix
        self._queue: queue.SimpleQueue = queue.SimpleQueue()
        self._threads: list[threading.Thread] = []
        self._lock = threading.Lock()
        self._shutdown = False

    def submit(self, fn, /, *args, **kwargs) -> Future:
        with self._lock:
            if self._shutdown:
                raise RuntimeError("cannot schedule new futures after shutdown")
            fut: Future = Future()
            self._queue.put((fut, partial(fn, *args, **kwargs)))
            # Limitation: a thread per submit up to the bound, no idle reuse
            if len(self._threads) < self._max_workers:
                t = threading.Thread(target=self._work, daemon=True,
                                     name=f"{self._prefix}_{len(self._threads)}")
                t.start()
                self._threads.append(t)
            return fut

    def _work(self) -> None:
        while (item := self._queue.get()) is not None:
            settle_future(*item)
            # An idle worker must not pin its last batch's closure and result while it blocks
            del item

    def shutdown(self, wait: bool = True, *, cancel_futures: bool = False) -> None:
        with self._lock:
            self._shutdown = True
            while cancel_futures:
                try:
                    item = self._queue.get_nowait()
                except queue.Empty:
                    break
                if item is not None:
                    item[0].cancel()
            for _ in self._threads:
                self._queue.put(None)
        if wait:
            for t in self._threads:
                t.join()


def _file_cache(repo_root: str, cfg) -> FileCache:
    """Return the per-stage cached file reader for repo-relative paths."""
    # s5's FileCache, not s6 IO: inherits s5's max_file_kb cap and path-safety, and counts the same
    return FileCache(repo_root, max_kb=int(knob(cfg, "step1.max_file_kb", 1024)))


def run(findings: list[Finding], ctx: ContextPackage, cfg, *, run_id: str = ""
        ) -> tuple[list[Finding], list[DroppedFinding]]:
    """Verify every finding, re-verify the first pass's own discoveries, and return (verified, dropped)."""
    log.info("s6/verify: starting verification - findings=%d", len(findings))
    progress = _S6Progress(len(findings), cfg, run_id)
    if not findings:
        progress.finish()
        log.info("s6/verify: no findings to verify")
        return [], []

    parallel = getattr(cfg.step6_verify, "parallel", 5)
    min_conf = getattr(cfg.step6_verify, "min_confidence", 7)
    split_retry = bool(knob(cfg, "step6_verify.split_retry", True))
    via = resolve(cfg.models.verify).via
    tool_timeout_s = getattr(cfg.step6_verify, "tool_timeout_s", None)  # via: deepagents only
    # Fail closed pre-pool: on via:sdk a mutating tool mutates the repo; only via:cli may keep Bash
    tools = validate_detection_tools(
        getattr(cfg.step6_verify, "allowed_tools", None),
        config_key="step6_verify.allowed_tools", via=via)
    console.write(f"  [s6-verify] verifying {len(findings)} findings "
                  f"({parallel} parallel, gate≥{min_conf}/10)...")

    verified: list[Finding] = []
    dropped: list[DroppedFinding] = []

    items = label(findings)
    batches = plan_batches(items, _cap_int(cfg.step6_verify, "batch_size", 12))
    if len(batches) < len(items):
        console.write(f"  [s6-verify] {len(items)} findings grouped into {len(batches)} "
                      f"batched session(s)")
    cache = _file_cache(ctx.repo_root, cfg)
    sink = _Sink(verified, dropped, progress, min_conf, filed_lines(items),
                 {f.canonical_key() for f in findings}, repo_root=ctx.repo_root,
                 # knob(): a bare `trait_stamps:` must use the default, as session.py's prompt does
                 stamps=bool(knob(cfg, "step6_verify.trait_stamps", True)),
                 reframe=bool(knob(cfg, "step6_verify.reframe_enabled", False)),
                 inventory=(set(ctx.all_files)
                            if getattr(ctx, "all_files", None) else None),
                 line_count=cache.line_count, read_lines=cache.lines)

    # Backstop, not a peer: must never fire before the backend clock it backs up (sweep_ceiling_secs)
    cli_effort = cli._effective_effort(None)
    ceiling = sweep_ceiling_secs(cfg.step6_verify, via=via, cli_effort=cli_effort)
    tier = sweep_effort(cfg.step6_verify, via=via, cli_effort=cli_effort)
    # Only import the vendor module when configured, so s6_verify stays importable without it otherwise.
    if tool_timeout_s is None:
        timeout_override = contextlib.nullcontext()
    else:
        from vvaharness.backends.harness.deepagents.options.filesystem import (
            patched_read_timeouts,
        )
        timeout_override = patched_read_timeouts(tool_timeout_s)

    # Scoped to the whole pool, not per-call: the patched names are process-global.
    with timeout_override:
        # One pool and one try/finally across both passes, so neither pass can leak it
        ex = _DaemonPool(max_workers=parallel)
        try:
            # Wave 1's captives feed wave 2: with parallel=1 an empty set makes its sweep unreachable
            captive = _run_wave(batches, ctx, cfg, tools, sink, ex,
                                split_retry=split_retry, ceiling=ceiling,
                                parallel=parallel, sweep_tier=tier)
            _reverify_discoveries(ctx, cfg, tools, sink, ex, captive,
                                  split_retry=split_retry, ceiling=ceiling,
                                  parallel=parallel, sweep_tier=tier)
        finally:
            # wait=False: a ceiling-stalled worker must not block the stage; daemons can't block exit
            ex.shutdown(wait=False, cancel_futures=True)

    tp = len(verified)
    fp = sum(1 for d in dropped if d.reason == "FALSE_POSITIVE")
    unc = sum(1 for d in dropped if d.reason == "UNCONFIRMED")
    gb = sum(1 for d in dropped if d.reason == "GUARDRAIL_BLOCKED")
    inc = sum(1 for d in dropped if d.reason == "INCONCLUSIVE")
    # Counted explicitly, not by remainder: a remainder silently absorbs any future new reason
    errs = sum(1 for d in dropped if d.reason == "VERIFY_ERROR")
    console.write(f"  [s6-verify] done: {tp} TRUE_POSITIVE, {fp} FALSE_POSITIVE, "
                  f"{unc} UNCONFIRMED, {gb} GUARDRAIL_BLOCKED, {inc} INCONCLUSIVE, "
                  f"{errs} errors")
    log.info("s6/verify: verification complete - "
             "tp=%d fp=%d unconfirmed=%d guardrail=%d inconclusive=%d errors=%d",
             tp, fp, unc, gb, inc, errs)
    _flag_uniform_confidence(sink.confidences, min_conf)
    return verified, dropped


def _flag_uniform_confidence(confidences: Counter[int], min_confidence: int) -> None:
    """Count and warn when every verdict in the stage carried one confidence, so the scores carry no ranking."""
    n = confidences.total()
    if n < _UNIFORM_CONFIDENCE_MIN or len(confidences) != 1:
        return
    (value,) = confidences
    COUNTERS.bump("s6_confidence_uniform", n)
    clamped = COUNTERS.get("s6_confidence_clamped")
    gate = ("admitted every TRUE_POSITIVE" if value >= min_confidence
            else "dropped every TRUE_POSITIVE as UNCONFIRMED")
    log.warning(Event.S6_UNIFORM_CONFIDENCE, verdicts=n, confidence=value, clamped=clamped,
                min_confidence=min_confidence, gate=gate)


def _reverify_discoveries(ctx: ContextPackage, cfg, tools, sink: _Sink,
                          ex: _DaemonPool, captive: set, *,
                          split_retry: bool, ceiling: int, parallel: int,
                          sweep_tier: str | None
                          ) -> None:
    """Independently judge each ``origin="s6_discovered"`` finding, replacing its unverified admission."""
    to_reverify = [f for f in sink.verified if f.origin == "s6_discovered"]
    if not to_reverify:
        return
    # Filter scan.py's `verified` IN PLACE so no alias goes stale; sink.seen keys block re-minting
    sink.verified[:] = [f for f in sink.verified if f.origin != "s6_discovered"]
    console.write(f"  [s6-verify] re-verifying {len(to_reverify)} verifier-discovered "
                  f"finding(s) independently...")
    items = label(to_reverify)
    batches = plan_batches(items, _cap_int(cfg.step6_verify, "batch_size", 12))
    sink.mint_discoveries = False
    # Widen total BEFORE this wave's record() calls, else remaining goes negative and status sticks
    sink.progress.widen_total(len(to_reverify))
    # Pre-file every site: a peer batch calling it a "confirmed repeat" must not ship a duplicate
    for f in to_reverify:
        sink.filed.setdefault(f.file, set()).add(f.line_start)
    # No clones here: scan.py's ledger assumes one row per s6_discovered finding
    sink.clone_repeats = False
    try:
        # abort_on_guardrail off: raising would discard wave 1's FALSE_POSITIVE audit rows
        _run_wave(batches, ctx, cfg, tools, sink, ex, captive=captive,
                 split_retry=split_retry, ceiling=ceiling, parallel=parallel,
                 sweep_tier=sweep_tier, abort_on_guardrail=False)
    finally:
        sink.mint_discoveries = True
        sink.clone_repeats = True


def _run_wave(batches: list[list[Item]], ctx: ContextPackage, cfg, tools,
             sink: _Sink, ex: _DaemonPool, *, split_retry: bool,
             ceiling: int, parallel: int, sweep_tier: str | None,
             captive: set = frozenset(),
             abort_on_guardrail: bool = True) -> set:
    """Drain every batch through the caller-owned pool *ex* into *sink*, returning this call's residual captives."""
    # Pool is the caller's, shut down there; every index-keyed local is per-call, so no collisions
    guardrail_hits = 0
    guardrail_gate = max(3, parallel)
    started: dict[int, float] = {}   # batch index -> monotonic start, set by its own worker
    # Read by a captive worker pre-repair: a resolved batch must not issue a fresh billed call
    abandoned: dict[int, threading.Event] = {}
    # Shared by the lone-finding resend and the refused-batch split: a gateway route does neither
    refusal_resend = refusal_resend_allowed(cfg, cfg.models.verify)

    def _submit(idx: int, batch: list[Item], *, refusal_child: bool = False):
        flag = abandoned.setdefault(idx, threading.Event())
        # A refused batch splits rather than resends; its singletons are the resend
        resend = refusal_resend and len(batch) == 1 and not refusal_child

        def timed() -> dict:
            # Thread start, not submit time: a queued batch has spent none of its own wall clock
            started[idx] = time.monotonic()
            return verify_batch(batch, ctx, cfg, tools, abandoned=flag.is_set,
                                resend_refusal=resend)
        return ex.submit(timed)

    futs = {_submit(idx, batch): (idx, batch)
            for idx, batch in enumerate(batches)}
    pending = set(futs)
    # Split indices run past the originals, so no collision; total_submitted tracks mid-run splits
    next_idx = len(batches)
    total_submitted = len(batches)

    def _split_and_resubmit(batch: list[Item], e: Exception, *, counter: str,
                            reason_prefix: str, label: str,
                            refusal_child: bool = False) -> list[int]:
        """Split *batch* into one-finding batches, resubmit each, and return the new batch indices."""
        nonlocal next_idx, total_submitted
        console.write(f"    [s6-verify] {_ids(batch)} verify {label} — retrying "
                      f"{len(batch)} finding(s) individually")
        COUNTERS.bump(counter)
        new_indices: list[int] = []
        for fid, f in batch:
            # recovered=True: a failed retry logs its own verify_error#<fid>; this is the attempt
            _errlog.log("s6-verify", f"{reason_prefix}#{fid}", e,
                        file=getattr(f, "file", None),
                        line=getattr(f, "line_start", None),
                        vuln_class=str(getattr(f, "vuln_class", "")),
                        recovered=True)
            cidx = next_idx
            next_idx += 1
            total_submitted += 1
            child = [(fid, f)]
            fut2 = _submit(cidx, child, refusal_child=refusal_child)
            futs[fut2] = (cidx, child)
            pending.add(fut2)
            new_indices.append(cidx)
        return new_indices

    # A batch index enters `resolved` exactly once (result, raise, ceiling); the rest is discarded
    resolved: set[int] = set()
    # Structured-split indices feeding s6_structured_retry_recovered; truncation split has no pair
    structured_split_children: set[int] = set()
    # Bounds the structured retry to once per finding: an index already here goes to VERIFY_ERROR
    structured_singleton_retried: set[int] = set()
    # Once per finding; only a multi-finding batch splits on timeout, a singleton would respend it
    timeout_split_retried: set[int] = set()
    # Children of a partial reply's omitted members, feeding s6_outcome_members_recovered
    member_children: set[int] = set()
    # Once per batch: a singleton child cannot omit-and-split again (len(batch) > 1 bounds it too)
    member_resubmitted: set[int] = set()
    def _timeout_splittable(idx: int, batch: list[Item]) -> bool:
        return (split_retry and len(batch) > 1
                and idx not in timeout_split_retried and not cli.aborted())

    def _timeout_split(batch: list[Item], e: Exception) -> None:
        timeout_split_retried.update(_split_and_resubmit(
            batch, e, counter="s6_batch_timeout_split",
            reason_prefix="timeout-split", label="TIMEOUT"))
    # Ceiling-resolved but still in the provider call; shrinks too, and copied so no wave is mutated
    captive: set = set(captive)
    captive_full_since: float | None = None
    quiet_since = time.monotonic()
    _wake = min(_HEARTBEAT_SECS, ceiling) if ceiling > 0 else _HEARTBEAT_SECS
    try:
        while pending:
            # Wake on the SHORTER interval: waking every 60s under a 30s ceiling would enforce 60s
            done, _ = wait(pending, timeout=_wake, return_when=FIRST_COMPLETED)
            for fut in done:
                pending.discard(fut)
                idx, batch = futs[fut]
                if idx in resolved:
                    # The explicit lock on the single-resolution rule.
                    continue
                resolved.add(idx)
                quiet_since = time.monotonic()
                try:
                    outcomes = fut.result()
                except GuardrailBlocked as e:
                    # An org-guardrail trip counts once toward the abort gate whether it's split
                    # or dropped; a model refusal never does
                    guardrail_hits, gate_label = guardrail_gate_hit(
                        e, guardrail_hits, guardrail_gate)
                    console.write(f"    [s6-verify] {_ids(batch)} GUARDRAIL-BLOCKED "
                                  f"({gate_label})")
                    # Checked BEFORE the split decision: cumulative hits must trip the breaker
                    # on schedule, not get deferred by however many rounds a batch keeps splitting
                    if (abort_on_guardrail and guardrail_hits >= guardrail_gate
                            and not sink.verified):
                        cli.abort()
                        # the caller's finally shuts the pool down
                        raise RuntimeError(
                            f"s6-verify: {guardrail_hits} cumulative guardrail "
                            "blocks with zero successes — aborting run.") from e
                    # On an Anthropic route a refused batch splits once so siblings of the one
                    # flagged member still get verdicts; a refused singleton is final. Flagged
                    # content is never re-sent to an OpenAI-compatible gateway.
                    if isinstance(e, ModelRefusal):
                        if (refusal_resend and split_retry and len(batch) > 1
                                and not cli.aborted()):
                            _split_and_resubmit(
                                batch, e, counter="s6_batch_refusal_split",
                                reason_prefix="refusal-split", label="REFUSED",
                                refusal_child=True)
                            continue
                        sink.fail(batch, "GUARDRAIL_BLOCKED", e)
                        continue
                    if split_retry and len(batch) > 1 and not cli.aborted():
                        _split_and_resubmit(
                            batch, e, counter="s6_batch_guardrail_split",
                            reason_prefix="guardrail-split", label="GUARDRAIL-BLOCKED")
                        continue
                    sink.fail(batch, "GUARDRAIL_BLOCKED", e)
                    continue
                except TruncatedResponseError as e:
                    # One retry deep: a singleton has no split left, so VERIFY_ERROR; once each
                    if split_retry and len(batch) > 1 and not cli.aborted():
                        _split_and_resubmit(
                            batch, e, counter="s6_batch_truncated_split",
                            reason_prefix="truncated-split", label="TRUNCATED")
                        continue
                    console.write(f"    [s6-verify] {_ids(batch)} verify TRUNCATED: "
                                  f"{redact(str(e))}")
                    sink.fail(batch, "VERIFY_ERROR", e)
                    continue
                except Exception as e:
                    # A structured-output failure is a batch-shape failure the split cures
                    if (split_retry and is_structured_output_failure(e)
                            and idx not in structured_singleton_retried
                            and not cli.aborted()):
                        # Per child, not per split event, so recovered can't exceed attempted
                        COUNTERS.bump("s6_structured_retry_attempted", len(batch))
                        new_indices = _split_and_resubmit(
                            batch, e, counter="s6_batch_structured_split",
                            reason_prefix="structured-split",
                            label="STRUCTURED-OUTPUT REJECTED")
                        structured_split_children.update(new_indices)
                        structured_singleton_retried.update(new_indices)
                        continue
                    if is_timeout_failure(e) and _timeout_splittable(idx, batch):
                        # Out of clock is a batch-SIZE failure like truncation: split to one/call
                        _timeout_split(batch, e)
                        continue
                    # Any other failure splits too, UNLESS it would fail the same way on retry
                    # (deterministic) or the run is being torn down (abort must not fan out resends)
                    if (split_retry and len(batch) > 1
                            and not is_deterministic_failure(e) and not cli.aborted()):
                        _split_and_resubmit(
                            batch, e, counter="s6_batch_generic_split",
                            reason_prefix="generic-split", label="ERROR")
                        continue
                    console.write(f"    [s6-verify] {_ids(batch)} verify ERROR: "
                                  f"{redact(str(e))}")
                    sink.fail(batch, "VERIFY_ERROR", e)
                    continue
                # Every omitted member, including all of them, resubmits as a fresh singleton
                # judgement — not a restatement, so an empty reply splits too. The `resolved`
                # set blocks a late result from an abandoned batch from resubmitting again;
                # `len(batch) > 1` stops an already-singleton child from splitting again.
                missing = [(fid, f) for fid, f in batch if fid not in outcomes]
                skip: set[str] = set()
                if (split_retry and missing and len(batch) > 1
                        and idx not in member_resubmitted and not cli.aborted()):
                    COUNTERS.bump("s6_outcome_members_resubmitted", len(missing))
                    new_indices = _split_and_resubmit(
                        missing,
                        RuntimeError(f"verifier omitted {len(missing)} of {len(batch)} members"),
                        counter="s6_batch_members_split", reason_prefix="members-split",
                        label="MEMBERS OMITTED")
                    member_resubmitted.update(new_indices)
                    member_children.update(new_indices)
                    skip = {fid for fid, _ in missing}
                sink.accept(batch, outcomes, skip=skip)
                if idx in structured_split_children:
                    COUNTERS.bump("s6_structured_retry_recovered")
                if idx in member_children and batch[0][0] in outcomes:
                    COUNTERS.bump("s6_outcome_members_recovered")
            now = time.monotonic()
            if ceiling > 0:
                for fut in list(pending):
                    idx, batch = futs[fut]
                    begun = started.get(idx)
                    if begun is None or now - begun <= ceiling:
                        continue
                    resolved.add(idx)
                    pending.discard(fut)
                    captive.add(fut)
                    abandoned[idx].set()
                    COUNTERS.bump("s6_batch_ceiling_expired")
                    err = call_timeout_error(
                        stage="s6", route="stage-ceiling", budget_s=ceiling,
                        effort=sweep_tier,
                        cause_text=f"batch exceeded step6_verify.batch_wall_clock_ceiling ({ceiling}s)")
                    split = _timeout_splittable(idx, batch)
                    console.write(f"    [s6-verify] {_ids(batch)} exceeded the {ceiling}s "
                                  f"batch wall-clock ceiling ({int(now - begun)}s in "
                                  f"flight) — "
                                  f"{'split-retrying' if split else 'resolved VERIFY_ERROR'}"
                                  f"; any late result will be discarded")
                    if split:
                        # Parent stays resolved/abandoned/captive; children each get a full ceiling
                        _timeout_split(batch, err)
                    else:
                        sink.fail(batch, "VERIFY_ERROR", err)
                # Prune first: an only-growing count would write off a queue about to run
                captive = {f for f in captive if not f.done()}
                if len(captive) >= parallel and pending:
                    # All-captive must HOLD a further ceiling, or one slow second costs every batch
                    if captive_full_since is None:
                        captive_full_since = now
                    elif now - captive_full_since >= ceiling:
                        for fut in list(pending):
                            idx, batch = futs[fut]
                            # cancel() is False once started, so it is the never-started test
                            if fut.cancel():
                                resolved.add(idx)
                                pending.discard(fut)
                                COUNTERS.bump("s6_batch_never_started")
                                sink.fail(batch, "VERIFY_ERROR", TimeoutError(
                                    f"batch never started: all {parallel} "
                                    f"worker(s) held by ceiling-expired batches "
                                    f"for {ceiling}s"))
                else:
                    captive_full_since = None
            if pending and now - quiet_since >= _HEARTBEAT_SECS:
                # One line per silent wake: a batch can otherwise sit 30min mute; not progress_file
                longest = max((now - started[futs[f][0]] for f in pending
                               if futs[f][0] in started), default=0.0)
                console.write(f"  [s6-verify] heartbeat: "
                              f"{total_submitted - len(pending)}/{total_submitted} "
                              f"batches done; longest in-flight {int(longest)}s")
                quiet_since = now
    except (KeyboardInterrupt, SystemExit):
        n = cli.abort()
        console.write(f"  [s6-verify] interrupted — killed {n} running verifier "
                      f"process(es), cancelling {sum(1 for f in futs if not f.done())} "
                      f"pending")
        raise    # the caller's finally cancels and shuts the pool down
    # Pruned once more: a stale future would start the next wave's captive count above reality
    return {f for f in captive if not f.done()}


class _S6Progress:
    """Optional atomic on-disk progress reporter for concurrent S6 work."""

    def __init__(self, total: int, cfg, run_id: str):
        self.total = total
        self.enabled = bool(getattr(cfg.step6_verify, "progress_file", False))
        self.path: Path | None = None
        self._lock = threading.Lock()
        self._counts: dict[str, int] = {}
        self._completed = 0
        if self.enabled:
            safe_run_id = re.sub(r"[^A-Za-z0-9_.-]", "_", run_id or "current")
            self.path = ensure_state_dir("s6_progress", safe_run_id) / "s6_progress.json"
            self._write("running")

    def record(self, outcome: str) -> None:
        if not self.enabled:
            return
        with self._lock:
            self._completed += 1
            self._counts[outcome] = self._counts.get(outcome, 0) + 1
            self._write("completed" if self._completed == self.total else "running")

    def widen_total(self, n: int) -> None:
        """Add *n* to the target, before a later wave's own `record()` calls land."""
        if not self.enabled:
            return
        with self._lock:
            self.total += n
            self._write("completed" if self._completed == self.total else "running")

    def finish(self) -> None:
        if not self.enabled:
            return
        with self._lock:
            self._write("completed")

    def _write(self, status: str) -> None:
        assert self.path is not None
        payload = {
            "status": status,
            "total": self.total,
            "completed": self._completed,
            "remaining": self.total - self._completed,
            "outcomes": dict(sorted(self._counts.items())),
            "updated_at": datetime.now(UTC).isoformat(),
        }
        fd, tmp_name = tempfile.mkstemp(
            prefix=".s6_progress.", suffix=".tmp", dir=self.path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as tmp:
                json.dump(payload, tmp, separators=(",", ":"))
                tmp.write("\n")
                tmp.flush()
                os.fsync(tmp.fileno())
            os.replace(tmp_name, self.path)
        finally:
            try:
                os.unlink(tmp_name)
            except FileNotFoundError:
                pass


def _ids(batch: list[Item]) -> str:
    """The batch's finding ids, for a single log line."""
    return ",".join(fid for fid, _ in batch)


# Every alternative must carry a NEGATION claim, or "parsed from json" / "import json at the top"
# would read as a contradiction of their own module. "<module> is not imported" (optionally
# quoted/backticked, optionally followed by " module", "isn't"/"never" as alternate negations),
# or a negated import ("does not import x", "never imports x", "no import of x", "missing import
# for x"); a bare "module x" / "import x" / "from x" names no claim, so it never matches.
_PREMISE_IMPORT_RX = re.compile(
    r"[`'\"]?([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)[`'\"]?(?:\s+module)?\s+"
    r"(?:is\s+not|isn't|is\s+never|never)\s+imported\b"
    r"|\b(?:not|never|no|without|missing)\s+(?:an?\s+)?import(?:s|ed|ing)?\b"
    r"(?:\s+(?:of|for))?\s+([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)",
    re.IGNORECASE)
# "<module> is undefined/not defined" (optionally quoted/backticked); a bare name claim like this
# proves only that an `import X` is missing — a `from X import ...` binds a member of X, not X
# itself, so it is not a contradiction of "X is not defined".
_PREMISE_DEFINED_RX = re.compile(
    r"[`'\"]?([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)[`'\"]?\s+is\s+(?:undefined|not\s+defined)\b",
    re.IGNORECASE)
# Captured by a prose word next to the negation ("is", "module", "the"...) rather than the
# module/name itself; never a real contradiction target.
_PREMISE_PROSE_STOPWORDS = frozenset({
    "is", "module", "the", "this", "that", "it", "which",
    "name", "variable", "function", "class", "method",
})


def _premise_module(reason: str) -> tuple[str, bool] | None:
    """The module/name *reason* claims is unimported or undefined, and whether a bare
    ``from X import ...`` of it also counts as a contradiction (true for an "imported" claim;
    false for a bare "is not defined" claim, which only a direct ``import X`` resolves).
    None when *reason* names no such claim."""
    for rx, allow_from in ((_PREMISE_IMPORT_RX, True), (_PREMISE_DEFINED_RX, False)):
        for m in rx.finditer(reason or ""):
            token = next((g for g in m.groups() if g), None)
            if token and token.lower() not in _PREMISE_PROSE_STOPWORDS:
                return token, allow_from
    return None


def _resolve_module_file(module: str, inventory: Collection[str] | None) -> str | None:
    """*module*'s file in *inventory* by suffix match (the package may sit under `src/`), or None."""
    if inventory is None:
        return None
    rel = module.replace(".", "/")
    candidates = (f"{rel}.py", f"{rel}/__init__.py")
    return next((entry for entry in inventory
                 if entry in candidates or entry.endswith(tuple(f"/{c}" for c in candidates))),
                None)


def _premise_contradicted(reason: str, finding_file: str,
                          inventory: Collection[str] | None,
                          read_lines: Callable[[str], list[str] | None]) -> str | None:
    """The module a FALSE_POSITIVE *reason* wrongly calls unimported, or None when nothing refutes it."""
    found = _premise_module(reason)
    if found is None:
        return None
    module, allow_from = found
    # A resolved file wins; an unresolved module (stdlib, or no inventory) falls back to the
    # finding's own file -- the only file an import of it could plausibly sit in
    target = _resolve_module_file(module, inventory) or finding_file
    lines = read_lines(target)
    if not lines:
        return None
    # "X is not defined" is a NAME claim: `from X import y` binds only `y`, not `X`, so it is
    # not a contradiction; "X is not imported" is a MODULE claim, which `from X import y` does refute.
    pattern = (rf"^\s*(?:import\s+{re.escape(module)}\b|from\s+{re.escape(module)}\b)" if allow_from
              else rf"^\s*import\s+{re.escape(module)}\b")
    stmt_rx = re.compile(pattern)
    return module if any(stmt_rx.match(ln) for ln in lines) else None


class _Sink:
    """Routes each judged finding into the verified list or one of the drop buckets."""

    def __init__(self, verified: list[Finding], dropped: list[DroppedFinding],
                 progress: _S6Progress, min_confidence: int,
                 filed: dict[str, set[int]], seen: set[tuple], *,
                 repo_root: str, stamps: bool = True, reframe: bool = False,
                 inventory: set[str] | None = None,
                 line_count: Callable[[str], int | None] = lambda _f: None,
                 read_lines: Callable[[str], list[str] | None] = lambda _f: None,
                 mint_discoveries: bool = True):
        self.verified = verified
        self.dropped = dropped
        self.progress = progress
        self.min_confidence = min_confidence
        # Off in the re-verify pass: additional_findings is counted and discarded, not admitted
        self.mint_discoveries = mint_discoveries
        # Toggled in _reverify_discoveries only: scan.py's ledger assumes one row per s6_discovered
        self.clone_repeats = True
        self.stamps = stamps
        self.reframe = reframe
        # s5's coordinate gate re-applied to post-s5 replies; a None inventory skips it, as s5 does
        self.inventory = inventory
        self.repo_root = repo_root
        self.line_count = line_count
        # FALSE_POSITIVE premise check (_premise_contradicted): never opens a file directly
        self.read_lines = read_lines
        # Shared and mutable across the stage, so two sessions can never file the same new line
        self.filed = filed
        self.seen = seen
        # Every judged score, for run()'s uniform-confidence check; no artefact keeps the spread
        self.confidences: Counter[int] = Counter()
        self._lock = threading.Lock()

    def _reserver(self, file: str):
        """A checked-and-reserve callback over *file*'s filed lines (atomic under the sink lock)."""
        def reserve(line: int) -> bool:
            with self._lock:
                lines = self.filed.setdefault(file, set())
                if line in lines:
                    return False
                lines.add(line)
                return True
        return reserve

    def fail(self, batch: list[Item], reason: str, exc: Exception) -> None:
        """Drop every member of a batch whose session raised, one errlog row each."""
        # redact() before the [:200] cut: this ships in the report, and slicing bisects a secret
        detail = redact(str(exc))[:200]
        for fid, f in batch:
            _errlog.log("s6-verify", f"{reason.lower()}#{fid}", exc,
                        file=getattr(f, "file", None),
                        line=getattr(f, "line_start", None),
                        vuln_class=str(getattr(f, "vuln_class", "")))
            self.dropped.append(_drop(f, reason, detail))
            self.progress.record(reason)

    def accept(self, batch: list[Item], outcomes: dict[str, VerificationOutcome], *,
               skip: Collection[str] = ()) -> None:
        """Apply the session's outcomes, recording any member it never judged except *skip*'s."""
        # This batch's own id->"file:line": a cited sibling must resolve in its minting batch, even
        # one in *skip* (resubmitted, so its own verdict and progress land with its child)
        display = {fid: f"{member.file}:{member.line_start}" for fid, member in batch}
        for fid, f in batch:
            if fid in skip:
                continue
            outcome = outcomes.get(fid)
            if outcome is None:
                self._undetermined(fid, f)
                continue
            self._judged(f, outcome, display)
            self._discoveries(f, outcome)

    def _undetermined(self, fid: str, f: Finding) -> None:
        """A finding the session returned no verdict for stays visible, never reads as clean."""
        # An absent verdict is undetermined: FALSE_POSITIVE would flatter the confirmation rate
        COUNTERS.bump("s6_finding_no_outcome")
        detail = "verifier returned no verdict for this finding"
        _errlog.log("s6-verify", f"no-outcome#{fid}", detail,
                    file=f.file, line=f.line_start)
        self.dropped.append(_drop(unverified(f, detail), "VERIFY_ERROR", detail))
        self.progress.record("VERIFY_ERROR")

    def _judged(self, f: Finding, outcome: VerificationOutcome,
               display: dict[str, str] | None = None) -> None:
        """Route one judged finding and any repeat site the verifier confirmed with it."""
        display = display or {}
        bucket = classify(outcome, self.min_confidence)
        if bucket == "FALSE_POSITIVE":
            module = _premise_contradicted(outcome.reason, f.file,
                                           self.inventory, self.read_lines)
            if module:
                COUNTERS.bump("s6_fp_premise_contradicted")
                # A hold, not a retry: the refutation stands contradicted, not resubmitted
                _errlog.log("s6-verify", f"{f.file}:{f.line_start}",
                            "false-positive premise contradicted by the code",
                            reason="s6_fp_premise_contradicted", module=module)
                bucket = "INCONCLUSIVE"
        self.confidences[outcome.confidence] += 1
        # Reserve lines only for a finding that ships, or a discarded clone blocks a real repeat
        results = apply_outcome(
            f, outcome,
            self._reserver(f.file) if bucket == "TRUE_POSITIVE" else None,
            stamps=self.stamps, reframe=self.reframe,
            # EOF bound, always read (FileCache): None leaves every correction and clone unbounded
            max_line=self.line_count(f.file),
            clone_repeats=self.clone_repeats)
        # verdict_reason is the one verdict prose the report renders (report.py), so a verdict
        # reached by the lossy tool-free replay says so there
        label = _REPLAYED_LABEL if outcome.replayed else ""
        for r in results:
            r.verdict_reason = remap_reason_ids(r.verdict_reason, display)
            if label and bucket == "TRUE_POSITIVE":
                r.verdict_reason = label + r.verdict_reason
        cvss_display = ('-' if results[0].cvss_score is None
                         else results[0].cvss_score)
        console.write(f"    [s6-verify] {f.file}:{f.line_start} -> {outcome.verdict} "
                      f"({outcome.confidence}/10) cvss={cvss_display}")
        if bucket == "TRUE_POSITIVE":
            self.verified.extend(results)
            primary = results[0]
            # A clone has no verdict line; name the primary by its CORRECTED site, not f's
            for r in results[1:]:
                console.write(f"    [s6-verify] {r.file}:{r.line_start} -> TRUE_POSITIVE "
                              f"(repeat of {primary.file}:{primary.line_start})")
            for r in results:
                if not r.cvss_vector:
                    # Normal (the prompt discourages guessing); s8's floor falls back to the label
                    COUNTERS.bump("s6_confirmed_without_vector")
            if label:
                COUNTERS.bump("s6_replayed_tp_shipped")
            self.progress.record(bucket)
            return
        detail = (f"verifier confidence {outcome.confidence}/10 below gate "
                  f"{self.min_confidence}") if bucket == "UNCONFIRMED" else outcome.reason
        self.dropped.append(_drop(results[0], bucket, label + detail))
        self.progress.record(bucket)

    def _in_repo(self, f: Finding) -> bool:
        """Apply s5's coordinate rule to a discovery: file in the inventory and readable, line within EOF."""
        if self.inventory is None:
            return True
        if f.file not in self.inventory:
            return False
        eof = self.line_count(f.file)
        return eof is not None and 1 <= int(f.line_start or 0) <= eof

    def _discoveries(self, f: Finding, outcome: VerificationOutcome) -> None:
        """Admit weaknesses the session found itself, once each, above the confidence floor."""
        if not self.mint_discoveries:
            # The re-verify pass must not mint more, or discoveries chain into an unverified fan-out
            if outcome.additional_findings:
                COUNTERS.bump("s6_finding_discovered_reverify_discarded",
                              len(outcome.additional_findings))
            return
        if outcome.replayed and outcome.additional_findings:
            # A tool-free replay never read the code, so a weakness it names is ungrounded
            n = len(outcome.additional_findings)
            COUNTERS.bump("s6_replayed_discoveries_dropped", n)
            warn_once(_WARNED_REPLAYED_DISCOVERIES, "s6-replayed-discoveries",
                      f"WARN [s6-verify]: dropped {n} discovery(ies) a replayed verdict for "
                      f"{f.file}:{f.line_start} proposed — a tool-free replay cannot ground a new "
                      "finding; every later drop is counted in s6_replayed_discoveries_dropped")
            return
        if outcome.confidence < self.min_confidence:
            COUNTERS.bump("s6_finding_discovered_unconfirmed",
                          len(outcome.additional_findings))
            return
        # Sessions sharing a file see the same defects; without dedupe a 40-finding file reports 40x
        # inventory None = the gate stood down (empty all_files), so there is nothing to resolve against
        for extra in discovered(outcome, f, repo_root=self.repo_root,
                                inventory=self.inventory or ()):
            if not self._in_repo(extra):
                # Minted after s5's inventory/EOF gate, so a fabricated path must not ship
                COUNTERS.bump("s6_finding_discovered_out_of_repo")
                continue
            key = extra.canonical_key()
            with self._lock:
                if key in self.seen:
                    COUNTERS.bump("s6_finding_discovered_duplicate")
                    continue
                self.seen.add(key)
            self.verified.append(extra)
            COUNTERS.bump("s6_finding_discovered_kept")
            if not extra.cvss_vector:
                # discovered() never inherits the primary's CVSS, scored for another weakness
                COUNTERS.bump("s6_confirmed_without_vector")


def _drop(f: Finding, reason: str, detail: str) -> DroppedFinding:
    return DroppedFinding(
        file=f.file,
        line=f.line_start,
        vuln_class=f.vuln_class,
        title=f.title,
        chunk_id=f.chunk_id,
        reason=reason,
        detail=detail,
    )
