# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared post-S2 callgraph consumers.

These helpers are intentionally read-only and deterministic: they consume the
SQLite-hydrated ``ctx.call_graph`` already attached to ContextPackage and
avoid stage-local re-derivation logic in s3/s4/s5/s6/s7/s8.

``ctx.call_graph`` is an entry-point/sink qnode index, not a call graph: it
carries file/function membership for the qnodes vvaharness's static
entry-point and sink detection identified, but no caller->callee edges and no
AST-derived def-site spans. :func:`qnodes_at` resolves against that file
membership; :func:`neighborhood` and :class:`GraphView`'s reverse-edge view
are therefore always empty by construction, not merely in practice. The
indices are built once per run and memoized per ContextPackage.
"""
from __future__ import annotations

import weakref
from collections import defaultdict

from vvaharness.models import ContextPackage


def _q_file(qn: str) -> str:
    return qn.rpartition("::")[0]


def parse_hop(hop: str) -> tuple[str, int | None]:
    """Parse a seed/codeflow hop formatted as "file:line"."""
    file_part, sep, line_part = hop.rpartition(":")
    if sep and file_part and line_part.isdigit():
        return file_part, max(1, int(line_part))
    return hop, None




def seed_paths_by_file(seed_taint_paths: list[list[str]] | None) -> dict[str, list[list[str]]]:
    """Index seed taint paths by every file they touch."""
    out: dict[str, list[list[str]]] = defaultdict(list)
    for path in seed_taint_paths or ():
        touched: set[str] = set()
        for hop in path:
            f, _ln = parse_hop(hop)
            if f:
                touched.add(f)
        for f in touched:
            out[f].append(path)
    return out


def best_source_from_seed(paths: list[list[str]]) -> str | None:
    """Return the first source hop from a set of seed paths touching a file."""
    for path in paths:
        if not path:
            continue
        src = path[0]
        sf, sl = parse_hop(src)
        if sf and sl is not None:
            return f"{sf}:{sl}"
        if src:
            return src
    return None


def entry_anchor_lines(ctx: ContextPackage) -> dict[str, list[int]]:
    """Entry-point def-site line anchors by file."""
    del ctx
    return {}


def graph_qnodes_by_file(ctx: ContextPackage) -> dict[str, list[str]]:
    """``file -> ordered unique list of every qnode ctx.call_graph places in it``."""
    out: dict[str, list[str]] = defaultdict(list)
    seen: dict[str, set[str]] = defaultdict(set)
    for qn in (getattr(ctx, "call_graph", None) or {}):
        f = _q_file(qn)
        if f and qn not in seen[f]:
            out[f].append(qn)
            seen[f].add(qn)
    return dict(out)


def qnodes_at(view: GraphView, file: str, line_start: int, line_end: int,
              *, limit: int = 6) -> list[str]:
    """Qnodes ``ctx.call_graph`` places in ``file`` (its only resolution signal; ``line_start``/``line_end`` are..."""
    del line_start, line_end
    file = (file or "").replace("\\", "/")
    cg = view.file_qnodes.get(file)
    if cg:
        return list(dict.fromkeys(cg))[:limit]
    return []


def neighborhood(view: GraphView, qnodes, *, max_edges: int = 8) -> dict:
    """Shared callers/callees view for s6/s7/s8."""
    graph = view.forward
    around: dict[str, dict[str, list[str]]] = {}
    for qn in qnodes:
        around[qn] = {
            "callers": (view.rev.get(qn) or [])[:max_edges],
            "callees": (graph.get(qn) or [])[:max_edges],
        }
    return around


class GraphView:
    """Memoized per-run bundle of the shared graph indices."""

    __slots__ = ("file_qnodes", "forward", "rev")

    def __init__(self, ctx: ContextPackage) -> None:
        self.forward = getattr(ctx, "call_graph", None) or {}
        self.file_qnodes = graph_qnodes_by_file(ctx)
        self.rev: dict[str, list[str]] = {}


# weakref-validated id() key: a reused id cannot return a stale view; pydantic ctx bars WeakKeyDict
_VIEW_CACHE: dict[int, tuple] = {}


def graph_view(ctx: ContextPackage) -> GraphView:
    """Return the memoized :class:`GraphView` for ``ctx`` (built once)."""
    key = id(ctx)
    entry = _VIEW_CACHE.get(key)
    if entry is not None:
        ref, view = entry
        if ref() is ctx:
            return view
    view = GraphView(ctx)
    try:
        ref = weakref.ref(ctx)
    except TypeError:  # pragma: no cover - pydantic models are weakref-able
        def ref(_c=ctx):
            return _c
    _VIEW_CACHE[key] = (ref, view)
    return view
