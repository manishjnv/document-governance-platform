# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""orchestrator.store — single-file SQLite state store under ``$VVAHARNESS_STATE_DIR`` holding per-run checkpoint blobs, callgraph snapshots, and run metadata."""
from __future__ import annotations

from vvaharness.orchestrator.store._db import (
    _PERM_WARNED,
    _POSIX,
    _REPLAY_MAX_BYTES,
    _SCHEMA_VERSION,
    StoreError,
    _create_db_file_safe,
    connect,
    db_location,
    db_path,
    delete_run,
    delete_run_graphs,
    delete_steps,
    ensure_state_dir,
    register_run,
    run_exists,
    reset_run,
    state_root,
    steps_with_prefix,
)
from vvaharness.orchestrator.store._schema import _DDL
from vvaharness.orchestrator.store.callgraph import load_callgraph, save_callgraph
from vvaharness.orchestrator.store.replays import (
    delete_replays,
    load_ev_probes,
    load_replays,
    prune_replays,
    save_ev_probes,
    save_replays,
)

__all__ = [
    "_DDL",
    "_PERM_WARNED",
    "_POSIX",
    "_REPLAY_MAX_BYTES",
    "_SCHEMA_VERSION",
    "StoreError",
    "_create_db_file_safe",
    "connect",
    "db_location",
    "db_path",
    "delete_replays",
    "delete_run",
    "delete_run_graphs",
    "delete_steps",
    "ensure_state_dir",
    "load_callgraph",
    "load_ev_probes",
    "load_replays",
    "prune_replays",
    "register_run",
    "run_exists",
    "reset_run",
    "save_callgraph",
    "save_ev_probes",
    "save_replays",
    "state_root",
    "steps_with_prefix",
]
