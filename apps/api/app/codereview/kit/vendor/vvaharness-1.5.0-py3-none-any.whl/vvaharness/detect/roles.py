# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Turn matcher hits into typed EntryPoint / Sink records."""
from __future__ import annotations

from typing import Literal, get_args

from vvaharness.detect.matcher import Hit
from vvaharness.models.scan.surface import EntryPoint, Sink

_EPKind = Literal["network", "ipc", "file", "cli", "deserialization", "framework", "other"]
_EP_KINDS: frozenset[str] = frozenset(get_args(_EPKind))


def _sink_function(hit: Hit) -> str:
    return hit.spec.rule_id.rsplit("-", 1)[-1]


def hits_to_sinks(hits: list[Hit]) -> list[Sink]:
    """Build one Sink per sink-role hit, deduped by (file, line, function)."""
    seen: set[tuple[str, int, str]] = set()
    sinks: list[Sink] = []
    for hit in hits:
        if hit.spec.role != "sink":
            continue
        function = _sink_function(hit)
        key = (hit.file, hit.line, function)
        if key in seen:
            continue
        seen.add(key)
        sinks.append(Sink(
            file=hit.file,
            line=hit.line,
            function=function,
            snippet=hit.snippet,
            cwe=[hit.spec.cwe],
        ))
    return sinks


def hits_to_entry_points(hits: list[Hit]) -> list[EntryPoint]:
    """Build one EntryPoint per source-role hit, deduped by (file, kind)."""
    seen: set[tuple[str, str]] = set()
    entry_points: list[EntryPoint] = []
    for hit in hits:
        if hit.spec.role != "source":
            continue
        kind: _EPKind = hit.spec.kind if hit.spec.kind in _EP_KINDS else "other"  # type: ignore[assignment]
        key = (hit.file, kind)
        if key in seen:
            continue
        seen.add(key)
        entry_points.append(EntryPoint(
            file=hit.file,
            function=hit.snippet,
            kind=kind,
        ))
    return entry_points
