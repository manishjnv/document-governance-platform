# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Re-export of the harness exception hierarchy, which is defined in ``models``."""

# NEVER define a class here: a copy compares by identity, voiding the VVAH-E001/E002 halt guards

from vvaharness.backends.harness.models import (
    AuthenticationError,
    DegenerateResponseError,
    HarnessCLINotFoundError,
    HarnessConnectionError,
    HarnessError,
    HarnessJSONDecodeError,
    HarnessMessageParseError,
    HarnessProcessError,
    ProxyError,
    is_halt_error,
    is_token_error,
)

__all__ = [
    "AuthenticationError",
    "DegenerateResponseError",
    "HarnessCLINotFoundError",
    "HarnessConnectionError",
    "HarnessError",
    "HarnessJSONDecodeError",
    "HarnessMessageParseError",
    "HarnessProcessError",
    "ProxyError",
    "is_halt_error",
    "is_token_error",
]
