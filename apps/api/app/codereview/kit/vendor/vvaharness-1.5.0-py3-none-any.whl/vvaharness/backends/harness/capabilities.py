# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""What a harness backend does differently, for hosts that must shape input before running it."""

# S10/S11 only: never consult for a detection prompt(); keyed by via, not Harness, to dodge imports

from __future__ import annotations

from collections.abc import Mapping
from typing import Final, NamedTuple

__all__ = ["HarnessCapabilities", "capabilities_for"]


class HarnessCapabilities(NamedTuple):
    """Backend traits a host must know before it can build the right prompt."""

    reads_injected_claude_config: bool
    returns_schema_validated_reports: bool


#: Unknown selectors get every trait off, so a new backend opts in rather than inheriting.
_NONE: Final = HarnessCapabilities(
    reads_injected_claude_config=False,
    returns_schema_validated_reports=False,
)

_BY_VIA: Final[Mapping[str, HarnessCapabilities]] = {
    # "cli"/"sdk" are one harness (ClaudeHarness): traits MUST stay identical; auto-loads .claude/
    "cli": HarnessCapabilities(
        reads_injected_claude_config=True,
        returns_schema_validated_reports=True,
    ),
    "sdk": HarnessCapabilities(
        reads_injected_claude_config=True,
        returns_schema_validated_reports=True,
    ),
    # Native subagents carry an output schema, so the host synthesizes gates deterministically
    "deepagents": HarnessCapabilities(
        reads_injected_claude_config=False,
        returns_schema_validated_reports=True,
    ),
}


def capabilities_for(via: str | None) -> HarnessCapabilities:
    """Return the traits of the HARNESS *via* selects, all off for an unrecognised value."""
    return _BY_VIA.get(via or "", _NONE)
