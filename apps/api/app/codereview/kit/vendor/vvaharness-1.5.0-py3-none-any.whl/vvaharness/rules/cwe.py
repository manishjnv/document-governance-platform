# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""CWE id normalisation, weakness-class equivalence, and the OWASP-2025 label map."""

from __future__ import annotations

import re

# Families absent here fall back to Injection, the modal category for a taint sink.
OWASP_2025_BY_SEMANTIC: dict[str, tuple[str, ...]] = {
    "html-response": ("A03:2025-Injection",),
    "command-exec": ("A03:2025-Injection",),
    "sql-exec": ("A03:2025-Injection",),
    "url-fetch": ("A10:2025-SSRF", "A03:2025-Injection"),
    "file-io": ("A01:2025-Broken-Access-Control", "A03:2025-Injection"),
    "deserialization": ("A08:2025-Software-and-Data-Integrity-Failures",),
    "template-render": ("A03:2025-Injection",),
    "credentials": ("A02:2025-Cryptographic-Failures",),
}


_CWE_RE = re.compile(r"CWE[-_ ]?0*(\d{1,4})", re.IGNORECASE)


def norm_cwe(value: object) -> str | None:
    """Canonicalize a CWE reference: 'cwe_089', 'CWE-0089', '89' -> 'CWE-89'."""
    match = _CWE_RE.search(str(value or ""))
    return f"CWE-{int(match.group(1))}" if match else None


# One weakness per row (s4 fan-out, s5/s7 collapse, s5 re-anchor); the first id names a survivor
_WEAKNESS_CLUSTERS: tuple[tuple[str, ...], ...] = (
    # SQL injection, Data Query Logic neutralization, and the dedicated SQL-injection variant.
    ("CWE-89", "CWE-943", "CWE-564"),
    # OS Command Injection / Command Injection.
    ("CWE-78", "CWE-77"),
    # Path Traversal family.
    ("CWE-22", "CWE-23", "CWE-36"),
    # XSS family.
    ("CWE-79", "CWE-80"),
    # Missing Authorization / Improper Access Control family.
    ("CWE-862", "CWE-285", "CWE-284"),
)
# Disjoint clusters make key equality an equivalence, so a dedup pass may test the group root alone.
_WEAKNESS_KEY: dict[str, str] = {c: cluster[0] for cluster in _WEAKNESS_CLUSTERS for c in cluster}

# GENERIC PARENTS, redundant against anything specific; 20 vs 74 are deliberately NOT folded
_GENERIC_PARENT_CWES: frozenset[str] = frozenset({"CWE-20", "CWE-74"})


def weakness_key(value: object) -> str | None:
    """norm_cwe(*value*) with cluster siblings folded onto one id; None when unparseable."""
    cwe = norm_cwe(value)
    return _WEAKNESS_KEY.get(cwe, cwe) if cwe else None


def same_weakness(cwe_a: object, cwe_b: object) -> bool:
    """True when *cwe_a* and *cwe_b* name the same underlying weakness."""
    # An input that fails to normalise returns False: "cannot tell" is never evidence of a match.
    a = norm_cwe(cwe_a)
    b = norm_cwe(cwe_b)
    if not a or not b:
        return False
    if a == b:
        return True
    a_generic = a in _GENERIC_PARENT_CWES
    b_generic = b in _GENERIC_PARENT_CWES
    if a_generic != b_generic:
        return True
    if a_generic and b_generic:
        return False
    return weakness_key(a) == weakness_key(b)


__all__ = [
    "OWASP_2025_BY_SEMANTIC",
    "norm_cwe",
    "same_weakness",
    "weakness_key",
]
