# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Build/dependency manifests: bounded walk, per-format structural truncation, aggregate cap."""
from __future__ import annotations

import json
import tomllib
from pathlib import Path

from vvaharness.evidence._grouping import _round_robin_select
from vvaharness.evidence.read import _cap_text, _contained, _read_capped
from vvaharness.scope import _DEFAULT_EXCLUDE_DIRS, _has_target_build_marker
from vvaharness.util import logs

log = logs.get_logger(__name__)

_MANIFEST_CANDIDATES = (
    "package.json", "pom.xml", "build.gradle", "build.gradle.kts",
    "setup.py", "pyproject.toml", "requirements.txt",
    "go.mod", "Cargo.toml", "Gemfile", "composer.json",
    "Dockerfile", "docker-compose.yml", "docker-compose.yaml",
    ".csproj",
)

# Raw pre-parse ceiling; the USEFUL cap (manifest_cap) applies to the structurally-extracted text.
_MANIFEST_RAW_CEILING = 500_000

_PACKAGE_JSON_KEYS = ("name", "version", "dependencies", "devDependencies",
                     "peerDependencies", "require", "require-dev", "scripts")
_PYPROJECT_PROJECT_KEYS = ("name", "version", "dependencies", "optional-dependencies")


def _truncate_package_json(raw: str, cap: int) -> str | None:
    """Keep only the name/version/dependency keys of a package.json-shaped manifest."""
    try:
        data = json.loads(raw)
    except Exception:
        log.debug("manifest structural truncation: unparseable JSON", exc_info=True)
        return None
    if not isinstance(data, dict):
        return None
    keep = {k: v for k, v in data.items() if k in _PACKAGE_JSON_KEYS}
    return _cap_text(json.dumps(keep, indent=2, sort_keys=True), cap) if keep else None


def _pyproject_keep(data: dict) -> dict:
    """The `[project]` and Poetry dependency tables, the two Python framework-detection signals."""
    keep: dict = {}
    project = data.get("project") if isinstance(data, dict) else None
    if isinstance(project, dict):
        sub = {k: v for k, v in project.items() if k in _PYPROJECT_PROJECT_KEYS}
        if sub:
            keep["project"] = sub
    tool = data.get("tool") if isinstance(data, dict) else None
    poetry = tool.get("poetry") if isinstance(tool, dict) else None
    if isinstance(poetry, dict) and "dependencies" in poetry:
        keep["tool"] = {"poetry": {"dependencies": poetry["dependencies"]}}
    return keep


def _truncate_pyproject_toml(raw: str, cap: int) -> str | None:
    """tomllib, not json.loads: pyproject is TOML, and its deps drive Python framework detection."""
    try:
        data = tomllib.loads(raw)
    except Exception:
        log.debug("manifest structural truncation: unparseable TOML", exc_info=True)
        return None
    keep = _pyproject_keep(data)
    return _cap_text(json.dumps(keep, indent=2, sort_keys=True, default=str), cap) if keep else None


_TRUNCATORS = {
    "package.json": _truncate_package_json,
    "composer.json": _truncate_package_json,
    "pyproject.toml": _truncate_pyproject_toml,
}


def _structural_truncate(kind: str, raw: str, cap: int) -> str:
    """Keep a manifest's dependency section, not a blind prefix; falls back to a plain cap."""
    truncate = _TRUNCATORS.get(kind)
    kept = truncate(raw, cap) if truncate else None
    return kept if kept is not None else _cap_text(raw, cap)


def _apply_manifest_total_cap(manifests: list[tuple[str, str]],
                              total_cap: int) -> list[tuple[str, str]]:
    """Aggregate cap across every manifest, applied after each file's own truncation cap."""
    out: list[tuple[str, str]] = []
    remaining = total_cap
    for name, text in manifests:
        if remaining <= 0:
            break
        if len(text) > remaining:
            text = _cap_text(text, remaining)
        out.append((name, text))
        remaining -= len(text)
    return out


def _dir_manifest_hits(root: Path, d: Path) -> dict[str, list[Path]]:
    """Manifest candidates directly inside `d`, containment-checked, grouped by candidate name."""
    hits: dict[str, list[Path]] = {}
    for name in _MANIFEST_CANDIDATES:
        candidates = sorted(d.glob(f"*{name}")) if name.startswith(".") else [d / name]
        for p in candidates:
            # A manifest-named link can target any in-root file (.git/config, a key); S2 is unredacted
            if p.is_symlink():
                continue
            if p.is_file() and _contained(root, p) is not None:
                hits.setdefault(name, []).append(p)
    return hits


def _walkable_children(d: Path) -> list[Path]:
    """Subdirectories eligible for the manifest walk: not excluded, not a symlink.

    Mirrors s1_preprocess's ``target/`` carve-out (see
    ``vvaharness.scope.walk._has_target_build_marker``): a directory literally
    named ``target`` is only excluded when a Maven/Gradle/Cargo/sbt/Leiningen
    build marker sits in `d`, so this walk never disagrees with the production
    one about what counts as build output vs. app code.
    """
    try:
        children = sorted(c for c in d.iterdir() if c.is_dir())
    except OSError:
        return []
    return [
        c for c in children
        if not c.is_symlink()
        and (
            c.name not in _DEFAULT_EXCLUDE_DIRS
            or (c.name == "target" and not _has_target_build_marker(d, []))
        )
    ]


def _walk_for_manifests(root: Path, d: Path, depth: int, max_depth: int,
                        hits_by_kind: dict[str, list[Path]]) -> None:
    """Depth-bounded walk honouring s1's exclusion set; never descends into a symlinked dir."""
    for name, paths in _dir_manifest_hits(root, d).items():
        hits_by_kind.setdefault(name, []).extend(paths)
    if depth >= max_depth:
        return
    for child in _walkable_children(d):
        _walk_for_manifests(root, child, depth + 1, max_depth, hits_by_kind)


def _find_manifests(root: Path, max_depth: int, max_total: int,
                    max_per_kind: int) -> list[tuple[str, Path]]:
    """Bounded search, deduped per kind, then breadth-first across kinds up to `max_total`."""
    hits_by_kind: dict[str, list[Path]] = {}
    _walk_for_manifests(root, root, 0, max_depth, hits_by_kind)
    for kind in hits_by_kind:
        hits_by_kind[kind] = hits_by_kind[kind][:max_per_kind]
    ordered_kinds = [k for k in _MANIFEST_CANDIDATES if k in hits_by_kind]
    return _round_robin_select(hits_by_kind, max_total, keys=ordered_kinds)


def _manifest_relpath(root: Path, p: Path) -> str:
    try:
        return str(p.relative_to(root)).replace("\\", "/")
    except ValueError:
        return str(p)


def gather_manifests(root: Path, walk_bounds: tuple[int, int, int],
                     manifest_cap: int, manifest_total_cap: int) -> list[tuple[str, str]]:
    """Find, read, structurally truncate, and aggregate-cap the manifest block."""
    max_depth, max_total, max_per_kind = walk_bounds
    manifests_struct: list[tuple[str, str]] = []
    for kind, p in _find_manifests(root, max_depth, max_total, max_per_kind):
        raw = _read_capped(root, p, _MANIFEST_RAW_CEILING)
        if not raw:
            continue
        relpath = _manifest_relpath(root, p)
        manifests_struct.append((relpath, _structural_truncate(kind, raw, manifest_cap)))
    return _apply_manifest_total_cap(manifests_struct, manifest_total_cap)
