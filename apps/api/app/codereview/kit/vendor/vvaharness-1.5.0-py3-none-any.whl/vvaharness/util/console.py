# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The product's human-facing output: status tables and banners; diagnostics go to util.logs."""
from __future__ import annotations

import os
import re
import sys
from typing import Any

from rich.console import Console
from rich.table import Table
from rich.theme import Theme

from vvaharness.report.redact import redact

__all__ = ["ICON", "STATUS_STYLE", "THEME", "banner", "console", "counts", "mark", "status_row",
           "status_table", "write"]

ICON: dict[str, str] = {"ok": "✓", "warn": "⚠", "fail": "✗", "skip": "–"}

STATUS_STYLE: dict[str, str] = {"ok": "ok", "warn": "warn", "fail": "fail", "skip": "muted"}

THEME = Theme({
    "ok": "bold green",
    "warn": "bold yellow",
    "fail": "bold red",
    "muted": "dim",
    "model": "cyan",
    "route": "magenta",
    "heading": "bold",
    "wordmark": "bold #1434CB",
    "wordmark.shadow": "#1434CB",
    "wordmark.tag": "#F7B600",
})

NO_BANNER_ENV = "VVAHARNESS_NO_BANNER"

_WORDMARK: tuple[str, ...] = (
    "██╗   ██╗██╗   ██╗ █████╗ ██╗  ██╗",
    "██║   ██║██║   ██║██╔══██╗██║  ██║",
    "██║   ██║██║   ██║███████║███████║",
    "╚██╗ ██╔╝╚██╗ ██╔╝██╔══██║██╔══██║",
    " ╚████╔╝  ╚████╔╝ ██║  ██║██║  ██║",
    "  ╚═══╝    ╚═══╝  ╚═╝  ╚═╝╚═╝  ╚═╝",
)


#: Width used when the stream is not a terminal, so a piped or captured table keeps every
#: cell intact instead of being folded at rich's 80-column default.
_PIPED_WIDTH = 200

# rich strips only BEL/BS/VT/FF/CR; ESC, DEL and C1 (8-bit CSI \x9b) would reach the terminal live
_CONTROL_RX = re.compile("[\x00-\x08\x0b-\x1f\x7f-\x9f]")


def _safe(text: Any) -> str:
    """Redacted *text* with every terminal control except newline and tab replaced by a space."""
    return _CONTROL_RX.sub(" ", redact(str(text)))


def console(*, err: bool = True) -> Console:
    """A Console resolved per call, so capsys and a reassigned stream both work."""
    stream = sys.stderr if err else sys.stdout
    isatty = getattr(stream, "isatty", None)
    return Console(
        file=stream,
        theme=THEME,
        no_color=bool(os.environ.get("NO_COLOR")),
        soft_wrap=False,
        highlight=False,
        emoji=False,
        width=None if callable(isatty) and isatty() else _PIPED_WIDTH,
    )


def _encodable(stream: object, lines: tuple[str, ...]) -> bool:
    """True when *stream*'s encoding can carry every glyph, so printing cannot raise."""
    encoding = getattr(stream, "encoding", None) or "utf-8"
    try:
        for line in lines:
            line.encode(encoding)
    except (LookupError, UnicodeEncodeError):
        return False
    return True


def banner(*, err: bool = True, force: bool = False) -> bool:
    """Print the VVAH wordmark; False when it was suppressed, so a caller can print its own header."""
    from rich.text import Text

    from vvaharness import __version__

    stream = sys.stderr if err else sys.stdout
    isatty = getattr(stream, "isatty", None)
    if not force and (os.environ.get(NO_BANNER_ENV)
                      or not (callable(isatty) and isatty())):
        return False
    out = console(err=err)
    if not _encodable(stream, _WORDMARK):
        out.print(Text("VVAH", style="wordmark"), soft_wrap=True)
    else:
        out.print("")
        for row, line in enumerate(_WORDMARK):
            out.print(Text(f"  {line}", style="wordmark" if row < 3 else "wordmark.shadow"),
                      soft_wrap=True)
    tag = Text("  ")
    tag.append(f"v{__version__}", style="wordmark.tag")
    tag.append("  ·  ", style="muted")
    tag.append("agentic SAST", style="muted")
    out.print(tag, soft_wrap=True)
    out.print("")
    return True


def write(text: str, *, err: bool = True) -> None:
    """Print one console line verbatim; the product's replacement for a bare stderr print."""
    from rich.text import Text

    console(err=err).print(Text(_safe(text)), soft_wrap=True)


def counts(stage: str, label: str, /, **fields: Any) -> str:
    """Render one `[stage] label  k v · k v` summary; returns the compact form for telemetry."""
    from rich.text import Text

    redacted = {key: _safe(value) for key, value in fields.items()}
    line = Text("  ")
    line.append(f"[{_safe(stage)}]", style="muted")
    line.append(f" {_safe(label)}  ")
    for i, (key, value) in enumerate(redacted.items()):
        if i:
            line.append(" · ", style="muted")
        line.append(f"{_safe(key).replace('_', ' ')} ", style="muted")
        line.append(f"{value}", style="model")
    console().print(line, soft_wrap=True)
    return " ".join(f"{k}={v}" for k, v in redacted.items())


def status_table(*, title: str, columns: tuple[str, ...]) -> Table:
    """An aligned, borderless status table — the shape preflight and doctor print their probes as."""
    from rich.text import Text

    table = Table(
        title=Text(title),
        title_justify="left",
        title_style="heading",
        box=None,
        pad_edge=False,
        show_edge=False,
        header_style="muted",
    )
    for name in columns:
        table.add_column(name, overflow="fold")
    return table


def status_row(table: Table, outcome: str, *cells: Any) -> None:
    """Add one row led by *outcome*'s glyph, styled by severity; cells render verbatim."""
    from rich.text import Text

    glyph = Text(ICON.get(outcome, "?"), style=STATUS_STYLE.get(outcome, "muted"))
    table.add_row(glyph, *[Text(_safe(c)) for c in cells])


def mark(outcome: str, text: str, *, indent: int = 2, lead: str = "", err: bool = True) -> None:
    """Write one glyph-led product line, coloured by *outcome* on a terminal."""
    from rich.text import Text

    line = Text(f"{lead}{' ' * indent}")
    line.append(ICON.get(outcome, "?"), style=STATUS_STYLE.get(outcome, "muted"))
    line.append(f" {_safe(text)}")
    console(err=err).print(line, soft_wrap=True)
