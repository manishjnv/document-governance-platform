# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 7's one model call: the semantic pass, degrading to no-collapse on any failure."""
from __future__ import annotations

from vvaharness.backends.harness.models import is_halt_error
from vvaharness.backends.llm import deepagents as _deepagents
from vvaharness.backends.llm.models import refusal_resend_allowed
from vvaharness.models import ContextPackage, Finding
from vvaharness.pipeline.stages.s7.outcomes import DedupDecisions, parse_decisions
from vvaharness.pipeline.stages.s7.prompts import SYSTEM, build_payload
from vvaharness.report.redact import redact
from vvaharness.util import console
from vvaharness.util import errlog as _errlog
from vvaharness.util.config import knob
from vvaharness.util.response_quality import dispatch_or_retry_unforced, stage_floors

# VVAH-E003 floors under the shortest real reply (~130 chars/~30 tok); a None token count can't trip
MIN_RESPONSE_CHARS = 90
MIN_RESPONSE_TOKENS = 15


def semantic_dedup(verified: list[Finding], unresolved: list[int], cfg,
                   ctx: ContextPackage,
                   label: str = "s7-dedup") -> list[tuple[int, int, str, bool]]:
    """Returns (local_idx, local_canonical_idx, reasoning, independent_sites) rows for duplicates."""
    # label=CALLING stage; hyphenated=errlog key, spaced=floors tag (test_s7_s8_response_floors.py)
    tag = label.replace("-", " ")
    effort = knob(cfg, "step7_dedup.effort", None) or None

    def _dispatch(*, drop_thinking: bool) -> str:
        # cwd roots the virtual filesystem at the repo; a wrong root silently changes visibility
        return _deepagents.dispatch_prompt(
            build_payload(verified, unresolved),
            model=cfg.models.dedup,
            cfg=cfg,
            cwd=ctx.repo_root,
            system_prompt=SYSTEM,
            max_tokens=getattr(cfg.step7_dedup, "max_tokens", 64000),
            response_model=DedupDecisions,
            tag=tag,
            effort=None if drop_thinking else effort,
        )

    try:
        with stage_floors(tag, min_chars=MIN_RESPONSE_CHARS,
                          min_tokens=MIN_RESPONSE_TOKENS):
            # Only an effort can lose the forced tool_choice (memoised model or manual thinking)
            # and shares the output budget; with none a retry just repeats
            raw = dispatch_or_retry_unforced(
                _dispatch, "semantic", stage=label.split("-", 1)[0],
                effort=_deepagents.droppable_effort(cfg.models.dedup, effort, agentic=False),
                may_retry=lambda: effort is not None,
                resend_refusal=refusal_resend_allowed(cfg, cfg.models.dedup))
    except Exception as e:  # provider errors are heterogeneous
        if is_halt_error(e):
            raise
        console.write(f"    [{label}] semantic dedup call failed (non-fatal): "
                      f"{redact(str(e))}")
        _errlog.log(label, "semantic", e)
        return []
    return parse_decisions(raw, len(unresolved), label)
