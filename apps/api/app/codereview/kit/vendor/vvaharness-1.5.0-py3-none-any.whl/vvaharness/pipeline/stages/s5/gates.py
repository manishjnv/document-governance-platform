# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""What s5 still refuses: a coordinate that does not exist, and test-path noise."""
from __future__ import annotations

from vvaharness.models import Finding
from vvaharness.pipeline.stages.s5.rules import EXCLUDE_PATH_RE, is_secret_class
from vvaharness.util.counters import COUNTERS


def reject_path(f: Finding, valid_files: set[str] | None) -> tuple[str, str] | None:
    """The path-level (reason, detail) for dropping *f*, judged with no disk I/O."""
    if EXCLUDE_PATH_RE.search(f.file) and not is_secret_class(f):
        return "EXCLUDED", "test/mock/example path"
    if valid_files is not None and f.file not in valid_files:
        return "EXCLUDED", "file not in repo inventory"
    return None


def reject(f: Finding, valid_files: set[str] | None,
           lines: list[str] | None) -> tuple[str, str] | None:
    """The (reason, detail) for dropping *f*, or None to keep it after clamping `line_end` to EOF."""
    verdict = reject_path(f, valid_files)
    if verdict is not None:
        return verdict
    if lines is None:
        return "EXCLUDED", "file could not be read from the repo"
    line = int(f.line_start or 0)
    if not 1 <= line <= len(lines):
        return "EXCLUDED", f"line {line} outside {f.file} (1-{len(lines)})"
    # Only point both s4-born and detector rows pass through, so clamp here.
    if f.line_end > len(lines):
        f.line_end = len(lines)
        COUNTERS.bump("s5_line_end_clamped_eof")
    return None
