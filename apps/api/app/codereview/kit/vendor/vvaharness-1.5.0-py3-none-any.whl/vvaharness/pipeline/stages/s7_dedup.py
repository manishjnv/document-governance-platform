# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 7 — deduplication: a deterministic same-site pass, then one model call on the rest."""
from __future__ import annotations

from vvaharness.models import ContextPackage, DroppedFinding, Finding
from vvaharness.pipeline.stages.s7.collapse import (
    TRIVIAL_REASON,
    attach_duplicates,
    collapse_trivial,
    cwe_conflict,
)
from vvaharness.pipeline.stages.s7.session import semantic_dedup
from vvaharness.util import console, logs
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event

log = logs.get_logger(__name__)


def prefilter(findings: list[Finding], line_tol: int,
              group_lines: list[int] | None = None
              ) -> tuple[list[Finding], list[DroppedFinding]]:
    """Collapse same-file, same-vuln_class or same-weakness findings within ``line_tol`` on ``group_lines``, with no model call."""
    if len(findings) <= 1:
        return list(findings), []

    # group_lines must be s4's anchors, or s5's re-anchor pulls two distinct sinks into line_tol
    canonical_of = collapse_trivial(findings, line_tol, group_lines)

    attach_duplicates(
        findings, canonical_of,
        {j: TRIVIAL_REASON for j in canonical_of},
    )

    keep = [f for i, f in enumerate(findings) if i not in canonical_of]
    dropped = [
        DroppedFinding(
            file=f.file, line=f.line_start, vuln_class=f.vuln_class,
            title=f.title, chunk_id=f.chunk_id, reason="DUPLICATE",
            detail=TRIVIAL_REASON,
        )
        for i, f in enumerate(findings) if i in canonical_of
    ]
    return keep, dropped


def run(verified: list[Finding], cfg, *, label: str = "s7-dedup",
        ctx: ContextPackage) -> tuple[list[Finding], list[DroppedFinding]]:
    """Return (canonical_findings, duplicate_dropped) after the trivial then semantic collapse."""
    if len(verified) <= 1:
        return list(verified), []

    line_tol = getattr(cfg.step7_dedup, "line_tolerance", 3)

    # Group on pre_anchor_line, never post-re-anchor, or two distinct sinks get collapsed here
    group_lines = [int(getattr(f, "pre_anchor_line", 0)) or int(f.line_start)
                   for f in verified]
    canonical_of = collapse_trivial(verified, line_tol, group_lines)
    reasoning: dict[int, str] = {j: TRIVIAL_REASON for j in canonical_of}

    unresolved = [i for i in range(len(verified)) if i not in canonical_of]
    console.counts(label, "pre-filter", trivial_dups=len(canonical_of),
                   unresolved=len(unresolved))

    # None tells attach_duplicates to discard duplicate sites rather than retain them.
    keep_same_site: set[int] | None = (
        set() if knob(cfg, "step7_dedup.per_sink_keep", True) else None)
    if keep_same_site is not None:
        # A merged pair has two anchors: discarding the lower lost real sites 15 lines apart
        keep_same_site.update(canonical_of)

    def root(i: int) -> int:
        while i in canonical_of:
            i = canonical_of[i]
        return i

    if len(unresolved) >= 2 and getattr(cfg.step7_dedup, "semantic", True):
        sem = semantic_dedup(verified, unresolved, cfg, ctx=ctx, label=label)
        blocked = 0
        for local_idx, local_canon, why, independent_sites in sem:
            # semantic_dedup returns positions in `unresolved`, not global indices.
            g_idx = unresolved[local_idx]
            g_canon = unresolved[local_canon]
            if g_idx in canonical_of or g_canon >= g_idx:
                continue
            # Test the ROOT, not the named canonical: an earlier row may hide g_canon's real CWE
            if cwe_conflict(verified[g_idx], verified[root(g_canon)]):
                blocked += 1
                continue
            canonical_of[g_idx] = g_canon
            reasoning[g_idx] = why
            # Fail-safe: keep the member's line only when the model ruled the sites independent
            if independent_sites and keep_same_site is not None:
                keep_same_site.add(g_idx)
        if blocked:
            COUNTERS.bump("s7_dedup_cwe_conflict_blocked", blocked)
            log.warning(Event.S7_CWE_CONFLICT_BLOCKED, stage=label, blocked=blocked)

    # Merging each dup onto its canonical is how the MD report and SARIF surface every call site
    attach_duplicates(verified, canonical_of, reasoning, keep_same_site=keep_same_site)

    canonical: list[Finding] = []
    new_index_of: dict[int, int] = {}
    for i, f in enumerate(verified):
        if i not in canonical_of:
            new_index_of[i] = len(canonical)
            canonical.append(f)

    dropped: list[DroppedFinding] = []
    for i, f in enumerate(verified):
        if i in canonical_of:
            r = root(i)
            dropped.append(DroppedFinding(
                file=f.file, line=f.line_start, vuln_class=f.vuln_class,
                title=f.title, chunk_id=f.chunk_id,
                reason="DUPLICATE",
                detail=reasoning.get(i, "duplicate"),
                canonical_idx=new_index_of.get(r),
            ))

    console.counts(label, "done", canonical=len(canonical),
                   duplicates_collapsed=len(dropped))
    return canonical, dropped
