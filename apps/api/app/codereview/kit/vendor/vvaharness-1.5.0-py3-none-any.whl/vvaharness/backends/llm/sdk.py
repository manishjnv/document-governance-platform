# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Anthropic SDK backend; mirrors cli.py's prompt()/agentic() surface, routed by registry.py."""

# Streams to dodge HTTP timeouts on large max_tokens, caches the prompt, auto-retries 429/5xx.
# Cache markers are placed only where all THREE gates agree: the route accepts `cache_control`
# (`_cache_route`), the kill switch is on, and the cumulative prefix clears the model's minimum
# cacheable size (`_cache_prefix_meets_minimum`).
from __future__ import annotations

import json
import os
import re
import ssl
import threading
import time
from typing import TYPE_CHECKING, Any, Final, cast
from urllib.parse import urlsplit

# Lazy import: anthropic is optional unless a role actually uses via:sdk.
import anthropic
import httpx2  # a hard dependency of anthropic (and openai), so always present when this module imports
from pydantic import BaseModel

from vvaharness.util import logs

if TYPE_CHECKING:
    from collections.abc import Callable

from vvaharness.backends.harness.deepagents.limits import MODEL_MAX_OUTPUT_TOKENS
from vvaharness.backends.harness.models import (
    AuthenticationError,
    TruncatedResponseError,
)
from vvaharness.backends.llm import cache as _cache
from vvaharness.backends.llm import tools as _localtools
from vvaharness.backends.llm.cli import _truncation_error
from vvaharness.backends.llm.models import (
    AGENTIC_MAX_TOKENS,
    ANTHROPIC_STOP_REFUSAL,
    DEFAULT_READ_TOOLS,
    DEFAULT_REQUEST_TIMEOUT_SECONDS,
    PARAM_REJECTION_STATUS,
    RATE_LIMIT_TRANSIENT_RX,
    RESPONSE_MODEL_TOOL_NAME,
    RETRYABLE_STATUS,
    SERVER_ERROR_TRANSIENT_RX,
    STRUCTURED_PROSE_REASK,
    STRUCTURED_REASK_MAX,
    TRUNCATED_REPLIES_COUNTER,
    TRUNCATED_RETRY_ATTEMPTED_COUNTER,
    TRUNCATED_RETRY_RECOVERED_COUNTER,
    ClockKind,
    SdkConfig,
    call_timeout_error,
    cause_chain,
    effort_scaled_seconds,
    finish_truncated,
    is_gateway_wrapped_param_rejection,
    jittered_delay,
    model_refusal,
    note_budget_use,
    proxy_error,
    rejection_text,
    response_model_tool,
    truncation_retry_max,
    turn_options,
    wait_overrun,
    with_submit_instruction,
)
from vvaharness.backends.llm.tls import (
    anthropic_auth_kwargs,
    coerce_verify,
    load_client_chain,
    resolve_client_chain,
    scoped_no_proxy_env,
    warn_verify_disabled,
)
from vvaharness.report.redact import redact
from vvaharness.util import console
from vvaharness.util import errlog as _errlog
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event
from vvaharness.util.response_quality import (
    StructuredOutputRejected,
    check_response_quality,
    is_timeout_failure,
    output_tokens_for_gate,
    structured_failure_detail,
)
from vvaharness.util.scan_progress import is_stage_only
from vvaharness.util.tokens import TOKENS, TokenUsage, estimate_tokens
from vvaharness.util.warn_once import warn_once

log = logs.get_logger(__name__)

_AUTH_STATUS_RX = re.compile(
    r"unauthorized|invalid[_ ]api[_ ]key"
    # Bounded, not `.*`: an unanchored wildcard let a 400 reading "invalid_request_error ...
    # prompt is too long" match, so an oversized chunk was logged as an authentication error.
    # \btoken\b: `max_tokens` cap rejections must not read as auth (same as openai's regex).
    r"|invalid[^\n]{0,24}\btoken\b|\btoken\b[^\n]{0,24}(?:expired|invalid|revoked)"
    r"|authentication[_ ]failed",
    re.IGNORECASE,
)
_AUTH_MAX_RETRIES_SDK = 3
_AUTH_BACKOFF_SDK = (2, 4, 8)

# Lazy, thread-safe singleton client (s4/s6 run in ThreadPoolExecutor).

_client = None
_client_lock = threading.Lock()
#: The `anthropic-beta` value baked into the live client's DEFAULT headers, or "". Only the OAuth
#: auth mode sets one (`oauth-2025-04-20`, without which the workspace token 401s), and a
#: per-request `extra_headers` would REPLACE it, so `_beta_headers` merges it back in.
_client_default_betas: str = ""
_cfg: SdkConfig = {"api_key": None, "base_url": None, "verify_ssl": True,
              "ca_cert": None, "client_cert": None, "no_proxy": None,
              # allow_api_key_fallback: sdk borrows the shared ANTHROPIC key only if sole backend.
              "allow_api_key_fallback": False,
              # None means "use the published per-model minimum" (_CACHE_MIN_TOKENS_TABLE); a
              # forced global floor is wrong in both directions, so it needs a measured reason.
              "cache_min_block_tokens": None,
              # "auto" detects the marker regime from base_url and fails closed on anything
              # unrecognised; anthropic/vertex/bedrock declare it; "none" forces no markers.
              "cache_route": "auto",
              # Fail-closed protects an UNKNOWN route from an unsupported field, but cannot
              # protect a KNOWN route from a wrong capability fact — a gateway that silently
              # strips or rejects a marker looks identical to one that honours it. Hence a
              # config switch rather than a code revert.
              "cache_markers": "on"}


def configure(*, api_key: str | None = None, base_url: str | None = None,
              verify_ssl: bool | str | None = None,
              ca_cert: str | None = None,
              client_cert: str | tuple | None = None,
              no_proxy: str | None = None,
              allow_api_key_fallback: bool | None = None,
              cache_min_block_tokens: int | None = None,
              cache_markers: str | None = None,
              cache_route: str | None = None) -> None:
    """Called once by the orchestrator before any SDK step; prefers ANTHROPIC_SDK_API_KEY."""
    global _client
    with _client_lock:
        if api_key:
            _cfg["api_key"] = api_key
        if base_url:
            _cfg["base_url"] = base_url
        if allow_api_key_fallback is not None:
            _cfg["allow_api_key_fallback"] = bool(allow_api_key_fallback)
        if verify_ssl is not None:
            _cfg["verify_ssl"] = coerce_verify(verify_ssl)
        if ca_cert:
            _cfg["ca_cert"] = ca_cert
        if client_cert:
            _cfg["client_cert"] = client_cert
        if no_proxy:
            _cfg["no_proxy"] = no_proxy
        if cache_min_block_tokens is not None:
            _cfg["cache_min_block_tokens"] = int(cache_min_block_tokens)
        if cache_markers is not None:
            _cfg["cache_markers"] = cache_markers
        if cache_route is not None:
            # PyYAML parses an unquoted `off`/`no` as False, so accept it as the documented
            # "none". An unrecognised value warns and falls back to "auto": the field only ever
            # gates an optimisation, so it must never fail the run.
            v = "none" if cache_route is False else str(cache_route).strip().lower()
            if v not in ("auto", "none",
                         _ROUTE_ANTHROPIC, _ROUTE_VERTEX, _ROUTE_BEDROCK):
                log.warning(Event.CACHE_ROUTE_UNKNOWN, cache_route=cache_route)
                v = "auto"
            _cfg["cache_route"] = v
        _client = None  # force rebuild on next call


def _mtls_verify(verify: bool | str) -> bool | str | ssl.SSLContext:
    """Return `verify` upgraded to an SSL context carrying the configured client chain."""
    # Never pass ``cert=`` to the httpx client (the httpx-0.28.1 trap; see tls.load_client_chain).
    # EVERY chain shape is pre-checked, not just the combined-PEM string: guarding the pre-check
    # with ``isinstance(str)`` let a ``(cert, key)`` pair with an absent KEY warn about the file
    # that was PRESENT.
    client_cert = resolve_client_chain(_cfg["client_cert"], label="sdk")
    if not client_cert:
        return verify
    context = httpx2.create_ssl_context(verify=verify, trust_env=True)
    if not load_client_chain(context, client_cert, label="sdk"):
        return verify
    return context


def _get_client():
    global _client, _client_default_betas
    if _client is not None:
        return _client
    with _client_lock:
        if _client is None:
            # Two retry layers, deliberately. `max_retries` stays at the library default (2) so
            # the worst case is 3x3=9 sends per prompt() call, matching the deepagents route.
            # The wrapper ladder is NOT redundant: it is the only layer that can see a transient a
            # gateway reports INSIDE an HTTP 200 body, which the SDK reads as success. Its flat 60s
            # stays flat because those bodies carry no retry-after to read.
            kw = {"max_retries": 2}
            # Dedicated env var so sdk can target a different gateway/key than the CLI backend.
            key = _cfg["api_key"] or os.environ.get("ANTHROPIC_SDK_API_KEY")
            if not key and _cfg.get("allow_api_key_fallback"):
                # Sole-sdk profile only: falls back to the shared ANTHROPIC key, not from via:cli.
                key = (os.environ.get("ANTHROPIC_API_KEY")
                       or os.environ.get("ANTHROPIC_AUTH_TOKEN"))
                if key:
                    console.write("    [sdk] no ANTHROPIC_SDK_API_KEY — falling back to "
                                  "ANTHROPIC_API_KEY/ANTHROPIC_AUTH_TOKEN (sdk is the "
                                  "only backend)")
            if not key:
                # Constructing the client with NO auth kwarg does NOT fail: the SDK resolves
                # ANTHROPIC_API_KEY from the ambient environment itself — precisely the credential
                # `allow_api_key_fallback` exists to withhold when a via:cli role shares the run.
                # Fail closed on the harness's own rule instead.
                raise AuthenticationError(
                    "no sdk credential resolved: set ANTHROPIC_SDK_API_KEY or "
                    "`sdk.api_key` in your config. ANTHROPIC_API_KEY is accepted "
                    "only when sdk/deepagents are the sole backends in the profile "
                    "(sdk.allow_api_key_fallback), so it is deliberately NOT read "
                    "here — an ambient key must never silently bill a run whose "
                    "via:cli roles authenticate as someone else.",
                    backend="sdk")
            auth_kw = anthropic_auth_kwargs(key)
            # Read the beta header off what the auth helper actually produced rather than
            # re-deriving it from the token prefix: SDK-1's merge below must send exactly
            # the value the client was built with, and reading it here means the two can
            # never drift from tls.anthropic_auth_kwargs.
            _client_default_betas = str(
                (auth_kw.get("default_headers") or {}).get("anthropic-beta") or "")
            kw.update(auth_kw)
            if _cfg["base_url"]:
                kw["base_url"] = _cfg["base_url"]
            # ca_cert (path) wins over verify_ssl (bool); httpx treats str `verify=` as CA bundle.
            ca = _cfg["ca_cert"]
            if ca and not os.path.exists(ca):
                log.warning(Event.TLS_CA_FALLBACK, path=ca, verify_ssl=_cfg['verify_ssl'])
                ca = None
            verify = ca or _cfg["verify_ssl"]
            if verify is False:
                # No urllib3 warning filter here: `anthropic` is an httpx client and
                # httpx emits no InsecureRequestWarning at all, so the filter this line
                # used to install muted nothing and merely implied the wrong HTTP stack.
                warn_verify_disabled(_cfg["base_url"], label="sdk",
                                     default_endpoint="<default Anthropic endpoint>",
                                     ca_hint="sdk.ca_cert")
            # httpx drops `cert=` whenever `verify=` is a str CA path or False, so a
            # configured client cert is loaded onto an explicit context — see _mtls_verify.
            verify = _mtls_verify(verify)
            if verify is not True:
                kw["http_client"] = anthropic.DefaultHttpxClient(verify=verify)
            with scoped_no_proxy_env(_cfg.get("no_proxy")):
                _client = anthropic.Anthropic(**kw)
    return _client


# Cache-marker capability gate. registry.resolve() only knows the TRANSPORT ("sdk"): Anthropic
# direct, Vertex and Bedrock are told apart only here, from the base_url. An unrecognised endpoint
# gets NO markers: a rejected field fails a scan, an ignored one only costs an optimisation.

_ROUTE_ANTHROPIC = "anthropic"   # cache_control
_ROUTE_VERTEX = "vertex"         # cache_control, same shape as Anthropic direct
_ROUTE_BEDROCK = "bedrock"       # no markers here — see _build_cache_prefix_content
_ROUTE_UNKNOWN = "unknown"       # no markers of any kind

# Every marker this module places is gated on this ONE set, so there is a single coherent policy
# rather than some markers failing closed while others go out unconditionally.
_CACHE_CONTROL_ROUTES = (_ROUTE_ANTHROPIC, _ROUTE_VERTEX)

# Anchored on the registrable domain: a bare substring test promoted any corporate hostname merely
# CONTAINING "vertex"/"bedrock" into a marker-capable route — the one direction that risks a
# rejected field rather than a missed optimisation.
_BEDROCK_HOST_RX = re.compile(
    r"(?:^|\.)bedrock[a-z0-9-]*(?:\.[a-z0-9-]+)*\.amazonaws\.com$", re.IGNORECASE)
# The hyphen alternative admits the regional `<region>-aiplatform.…` form real Vertex uses.
_VERTEX_HOST_RX = re.compile(
    r"(?:^|[.-])aiplatform\.googleapis\.com$", re.IGNORECASE)
_ANTHROPIC_HOST_RX = re.compile(r"(?:^|\.)anthropic\.com$", re.IGNORECASE)

#: Route classifications already noted as withholding cache markers. Registering this set in
#: ``warn_once._REGISTRY_SITES`` is NOT optional: an unregistered set survives the between-repo
#: reset and repo N>1 silently loses the note.
_CACHE_ROUTE_NOTED: set[str] = set()


def _cache_route(client, *, config=None, emit_note: bool = True) -> str:
    """Classify which cache-marker regime `client` is talking to, from its own resolved base_url."""
    # Never from the model id or from `via`: at this transport those are indistinguishable.
    # An unrecognised endpoint is `_ROUTE_UNKNOWN` — guessing wrong risks a 400 on a strict
    # gateway. An explicit `cache_route` beats detection, because sniffing can only fail CLOSED
    # and a genuinely Anthropic-compatible gateway has no other way to say so.
    settings = _cfg if config is None else config
    forced = settings.get("cache_route", "auto")
    if forced is False:
        forced = "none"          # a directly-poked _cfg gets configure()'s YAML tolerance too
    forced = str(forced or "auto").strip().lower()
    if forced == "none":
        return _ROUTE_UNKNOWN
    if forced in (_ROUTE_ANTHROPIC, _ROUTE_VERTEX, _ROUTE_BEDROCK):
        return forced
    base_url = getattr(client, "base_url", None) or settings.get("base_url") or ""
    host = urlsplit(str(base_url)).hostname or str(base_url)
    host = (host or "").lower()
    if not host:
        return _ROUTE_ANTHROPIC
    if _BEDROCK_HOST_RX.search(host):
        return _ROUTE_BEDROCK
    if _VERTEX_HOST_RX.search(host):
        return _ROUTE_VERTEX
    if _ANTHROPIC_HOST_RX.search(host):
        return _ROUTE_ANTHROPIC
    # Failing closed is correct but SILENT: a live scan through an unrecognised gateway sent
    # ~8.1M prompt tokens uncached with cache_read=0 everywhere, and the only mechanism that names
    # the cause (`doctor --cache-probe`) is opt-in. So the fallthrough itself tells the operator,
    # here rather than at a withhold site: all three withhold sites gate through this function, and
    # a note at any one of them is invisible to profiles that exercise only the others.
    # Only the AUTO-DETECTED fallthrough notes: an explicit `cache_route: none` or
    # `cache_markers: off` is the operator's decision, not a missed one.
    # Wording note: markers default to ON when the key is absent, so do NOT quote
    # `cache_markers: on` as though the operator wrote it — they would grep a shipped profile,
    # find nothing, and discount the remedy.
    if not emit_note:
        return _ROUTE_UNKNOWN
    warn_once(
        _CACHE_ROUTE_NOTED, _ROUTE_UNKNOWN,
        "    [sdk] note: prompt caching is enabled by default, but the "
        "configured endpoint is not recognised as Anthropic, Vertex or "
        "Bedrock (route classification: unknown), so cache markers are "
        "withheld and prompt tokens are billed uncached on this route. If "
        "the gateway is Anthropic-Messages-compatible, set "
        "`cache_route: anthropic` in your config to enable prompt caching. "
        "This affects cost only; scan results are unchanged.")
    return _ROUTE_UNKNOWN


def _cache_markers_enabled() -> bool:
    """The kill switch: `cache_markers: off` suppresses every marker, on every route."""
    return _cache.markers_enabled(_cfg)


# Published per-model minimum cacheable prefix sizes, in REAL tokens. Below the minimum the API
# silently caches NOTHING — no error, just cache_creation_input_tokens=0 while the marker still
# spends one of the request's 4 slots. The sequence is NON-MONOTONIC across releases (opus-4-5/4-6
# need MORE than 4-7), so no version-ordering heuristic is safe and an unseen model gets the
# largest published minimum. First match wins, so specific minors precede family catch-alls.
_CACHE_MIN_TOKENS_TABLE: tuple[tuple[re.Pattern, int], ...] = (
    (re.compile(r"opus-5|fable-5", re.IGNORECASE), 512),
    (re.compile(r"opus-4[-.]?[56]|haiku-4[-.]?5", re.IGNORECASE), 4096),
    (re.compile(r"opus-4[-.]?7|haiku-3[-.]?5", re.IGNORECASE), 2048),
    # opus-4, opus-4-1, opus-4-8 and every sonnet-4* / sonnet-5* variant.
    (re.compile(r"opus-4|sonnet-[45]", re.IGNORECASE), 1024),
)
_CACHE_MIN_TOKENS_FALLBACK = 4096


def _cache_min_tokens_for(model: str) -> int:
    """Minimum cacheable prefix size (real tokens) for `model`, or the operator's forced floor."""
    override = _cfg.get("cache_min_block_tokens")
    if override is not None:
        # 0 disables the size gate (every marker placed; the provider silently
        # ignores below-minimum ones); negatives clamp to 0.
        return max(0, int(override))
    for rx, floor in _CACHE_MIN_TOKENS_TABLE:
        if rx.search(model or ""):
            return floor
    return _CACHE_MIN_TOKENS_FALLBACK


# Same value and rationale as the openai path, defined once in llm/cache.py.
_CACHE_EST_MARGIN = _cache.CACHE_EST_MARGIN


def _cache_prefix_meets_minimum(text: str, model: str, *,
                                preceding: str = "") -> bool:
    """Whether a breakpoint after `text` is estimated to clear the model's minimum cacheable size."""
    floor = _cache_min_tokens_for(model)
    est = estimate_tokens(preceding) + estimate_tokens(text)
    return est * _CACHE_EST_MARGIN >= floor


def _build_cache_prefix_content(client, cache_prefix: str | None,
                                user_prompt: str | list[dict], *,
                                model: str,
                                preceding: str = "") -> str | list[dict]:
    """Decide how to deliver `cache_prefix` + `user_prompt`, in order of preference."""
    # When a marker cannot be placed the prefix is still concatenated LEADING into one block, so
    # a route with only an implicit cache still benefits. Markers are the smaller half of this
    # optimisation; a prompt's prefix is never destabilised to attempt one.
    if not cache_prefix:
        return user_prompt

    route = None
    if _cache_markers_enabled():
        candidate = _cache_route(client)
        if (candidate in _CACHE_CONTROL_ROUTES
                and _cache_prefix_meets_minimum(cache_prefix, model,
                                                preceding=preceding)):
            route = candidate

    # Blocks can't be string-concatenated, so both shapes prepend the prefix as its own text
    # block — with cache_control when the gate allows, plain otherwise.
    if isinstance(user_prompt, list):
        prefix_block: dict = {"type": "text", "text": cache_prefix}
        if route is not None and user_prompt:
            prefix_block["cache_control"] = {"type": "ephemeral"}
        return [prefix_block, *user_prompt]

    # An empty trailing text block is rejected by the API, and a prefix equal to the whole prompt
    # leaves nothing behind it — there is nothing to gain from a breakpoint with an empty half.
    if route is not None and user_prompt:
        return [
            {"type": "text", "text": cache_prefix,
             "cache_control": {"type": "ephemeral"}},
            {"type": "text", "text": user_prompt},
        ]
    # Bedrock is withheld for a NARROWER reason than the other unrecognised routes: its Anthropic
    # models do accept `cache_control`, but this package cannot sign SigV4, so a Bedrock-looking
    # base_url is necessarily an unverified intermediary — and Bedrock reports usage under names
    # this codebase does not parse, so even a working marker would read as zero.
    return cache_prefix + user_prompt


def _build_system_content(client, system_prompt: str, model: str, *,
                          tools_text: str = "") -> str | list[dict]:
    """System block for one call: one block carrying a marker when one is worth placing, else the plain string (..."""
    # Every marker must obey `_CACHE_CONTROL_ROUTES`: an unconditional marker here contradicted
    # `_cache_route`'s fail-closed rationale, since a gateway strict enough to 400 would reject the
    # system block before the withheld prefix breakpoint ever protected anything.
    # The minimum is CUMULATIVE and tool schemas render ahead of the system block, so their
    # serialized text participates via `tools_text`.
    if (_cache_markers_enabled()
            and _cache_route(client) in _CACHE_CONTROL_ROUTES
            and _cache_prefix_meets_minimum(system_prompt, model,
                                            preceding=tools_text)):
        return [{
            "type": "text",
            "text": system_prompt,
            "cache_control": {"type": "ephemeral"},
        }]
    return system_prompt


_PARSED_USAGE_CACHE_KEYS = _cache.ANTHROPIC_PARSED_CACHE_KEYS


def _note_unparsed_cache_keys(usage: dict | None) -> None:
    """Flag cache accounting reported under key names this module does not parse."""
    _cache.note_unparsed_cache_keys(usage, via="sdk")


def _bank_usage(msg: anthropic.types.Message) -> TokenUsage | None:
    """Bank *msg*'s usage into TOKENS (a call with none still counts) and return it."""
    usage = cast("TokenUsage", msg.usage.model_dump()) if msg.usage else None
    _note_unparsed_cache_keys(usage)
    TOKENS.add(usage)
    return usage


# prompt() — single-shot, no tools. Same return contract as cli.prompt().

#: Ceiling on total attempts after bounded extra-send grants (param-drop / truncation retry).
_ATTEMPTS_CEILING: Final = 6

_NO_TEMP_MODELS: set[str] = set()
_NO_THINK_MODELS: set[str] = set()
#: Models that 400'd on a FORCED tool_choice, remembered so the rest of the run advertises the
#: structured-output tool without forcing it and asks for it by name in the system prompt instead
#: (see the tool_choice param-drop arm).
_NO_TOOL_CHOICE_MODELS: set[str] = set()
#: Param drops already announced, so a model tier warns once, not once per call.
_WARNED_DROPS: set[str] = set()
_NO_TEMP_RX = re.compile(
    r"opus-4[-.]?([7-9]|\d{2,})|opus-[5-9]|sonnet-[5-9]|haiku-[5-9]",
    re.IGNORECASE,
)


def _warn_max_budget_unenforced(fn: str, max_budget_usd: float | None) -> None:
    """One-time WARN that `max_budget_usd` is accepted but never enforced here."""
    # Same "name the drop" idiom as the param-drop WARNs above (reusing their `_WARNED_DROPS`
    # registry): the raw Anthropic loop this module drives has no spend-cap mechanism of its own
    # -- only the Claude-side transports (`via: cli`, the Agent SDK, `cli_mcp`) actually enforce
    # it -- so a profile setting one here looked applied and silently was not.
    if max_budget_usd is None:
        return
    warn_once(
        _WARNED_DROPS, f"max_budget_usd:{fn}",
        f"WARN [sdk]: max_budget_usd={max_budget_usd} is accepted by {fn}() "
        f"but not enforced on this route -- no spend cap is applied here; "
        f"max_turns is the bound that applies instead. Route this role "
        f"via: cli for an enforced budget.")


def _supports_temperature(model: str) -> bool:
    if model in _NO_TEMP_MODELS:
        return False
    return not _NO_TEMP_RX.search(model)


def _beta_headers(betas: list[str] | None) -> dict[str, str] | None:
    """The `extra_headers` for a request that asks for *betas*, or None when it asks for none."""
    # TRAP (anthropic 0.125.0): a per-request ``extra_headers`` REPLACES a default header of the
    # same name. On an OAuth client, whose only auth carrier beyond the token IS the default
    # ``anthropic-beta: oauth-2025-04-20``, a role that also sets ``betas:`` silently dropped the
    # OAuth beta and 401'd the whole role — so re-join the client's own default first.
    if not betas:
        return None
    joined = [b for b in _client_default_betas.split(",") if b.strip()]
    for b in betas:
        if str(b) not in joined:
            joined.append(str(b))
    return {"anthropic-beta": ",".join(joined)}


def _is_transient_sdk(error: anthropic.APIStatusError) -> bool:
    """True for a retryable status, or a transient a gateway reported in the message instead."""
    # The message fallback is what a status set cannot do: a gateway has delivered "Rate limiting
    # temporarily unavailable" as an APIStatusError with status_code=200. Connection-drop prose is
    # not matched here — this transport raises dropped sockets as anthropic.APIConnectionError,
    # which has its own retry branch.
    if error.status_code in RETRYABLE_STATUS:
        return True
    # Prose may not PROMOTE an explicit auth status: a 401/403 does not heal on a retry, however
    # transient its wording, and a DLP or proxy block page returned under one routinely says
    # "Service Unavailable". Kept even though prompt() now decides auth first, because agentic()
    # has no auth branch at all and would otherwise burn its whole ladder on an unhealable status.
    # openai._is_transient_oai carries the identical rule.
    if error.status_code in (401, 403):
        return False
    # rejection_text() drops a pydantic echo of the request: a PROMPT naming "rate limit" or
    # "Internal Server Error" (routine in security prompts) must not make a permanent 422 transient.
    body = rejection_text(error)
    return bool(RATE_LIMIT_TRANSIENT_RX.search(body)
                or SERVER_ERROR_TRANSIENT_RX.search(body))


# Re-exported under the module-private names this file already uses, so the tool
# name and schema shape now come from ONE definition shared with `openai.agentic`
# (see models.response_model_tool). They were identical by hand before; a stage's
# extractor keys on the name, so a drift here would silently break one route.
_RESPONSE_MODEL_TOOL_NAME = RESPONSE_MODEL_TOOL_NAME
_response_model_tool = response_model_tool


def _extract_response_model(response_model: type[BaseModel], msg, *, model: str) -> BaseModel:
    """Validate the structured tool call in *msg*, or raise :class:`StructuredOutputRejected`."""
    # Both failure shapes — a rejected schema and "no tool call at all" — are the SAME defect
    # ``dispatch_or_retry_unforced`` recovers from, so both must raise the one marker; a bare
    # ValidationError/RuntimeError is invisible to ``is_structured_output_failure``. The marker
    # carries the final's stop_reason so the seam's ``finish=`` label reads the same on every route.
    finish = getattr(msg, "stop_reason", None)
    for b in msg.content:
        if getattr(b, "type", None) != "tool_use":
            continue
        if b.name == _RESPONSE_MODEL_TOOL_NAME:
            try:
                return response_model.model_validate(b.input)
            except Exception as e:
                raise StructuredOutputRejected(
                    f"Anthropic SDK call to {model}: '{_RESPONSE_MODEL_TOOL_NAME}' "
                    f"reply failed validation: {e}", finish=finish,
                ) from e
    raise StructuredOutputRejected(
        f"Anthropic SDK call to {model} ended without calling "
        f"'{_RESPONSE_MODEL_TOOL_NAME}' (stop_reason={finish}).", finish=finish,
    )


def _refusal_category(msg: anthropic.types.Message) -> str | None:
    """The provider's label on a refused reply (``stop_details.category``), None when absent."""
    # stop_reason is this route's whole refusal seam; is_model_refusal_rejection is not used here.
    category = getattr(getattr(msg, "stop_details", None), "category", None)
    return category if isinstance(category, str) else None


def _raise_if_refused(msg: anthropic.types.Message, *, tag: str | None) -> None:
    """Raise the typed refusal for a refused reply; callers bank its usage first."""
    if getattr(msg, "stop_reason", None) == ANTHROPIC_STOP_REFUSAL:
        raise model_refusal(route="sdk", stage=tag or "", category=_refusal_category(msg))


def _effort_thinking_kwargs(model: str, effort: str | None) -> dict:
    """Adaptive-thinking kwargs for *effort* on *model*, or ``{}`` (A5 mapping, shared)."""
    # ONE translation for both ``prompt()`` and ``agentic()``: the ``EffortLevel`` -> thinking
    # mapping ``via: deepagents`` uses (``_anthropic_thinking_kwargs``), skipped for a model
    # already learned to reject thinking. ``None`` yields ``{}`` without importing the mapping, so
    # an effort-less call never pulls in langchain.
    if effort is None or model in _NO_THINK_MODELS:
        return {}
    from vvaharness.backends.harness.deepagents.options.model_building import (  # noqa: PLC0415 — lazy: keeps langchain out of a plain sdk leg
        _anthropic_thinking_kwargs,
    )
    return _anthropic_thinking_kwargs(effort)


def _forcing_blocked(model: str, thinking: dict | None) -> bool:
    """Whether a forced tool_choice must be withheld: a memoised model, or manual thinking."""
    # Adaptive thinking accepts tool_choice tool/any (thinking.md "Thinking with tool use"); only
    # manual `enabled` thinking is limited to auto/none. Some 5.x models reject `tool` on every
    # request (a 400 or a streamed bad_request_error naming tool_choice) and treat `any` as `auto`,
    # so the instruction text yields the submit call; _unforce_rejected_tool_choice memoises them.
    return model in _NO_TOOL_CHOICE_MODELS or (thinking or {}).get("type") == "enabled"


def _warn_tool_choice_dropped_for_thinking(model: str, effort: str | None) -> None:
    """Name, once per model, that manual thinking cost a forced structured-output tool_choice."""
    warn_once(
        _WARNED_DROPS, f"tool_choice_dropped_for_thinking:{model}",
        f"WARN [sdk]: {model} has effort={effort!r} with manual (`enabled`) thinking "
        f"and a response_model -- manual thinking allows only tool_choice auto/none "
        f"(adaptive thinking would accept the forcing), so tool_choice is left at "
        f"its default (auto) for this model. The structured-output tool is still "
        f"advertised and validated when called, the system prompt asks for it by "
        f"name, and a prose reply is re-asked once in-session (agentic) or retried "
        f"once without effort by the calling stage (prompt).")
    COUNTERS.bump("sdk_tool_choice_dropped_for_thinking")


def _unforce_rejected_tool_choice(kw: dict, e: anthropic.APIStatusError, low: str, *,
                                  client, model: str, system_prompt: str | None,
                                  response_model: type[BaseModel] | None,
                                  tools_text: str = "") -> bool:
    """Memoise *model* and unforce *kw* when the rejection names the forced ``tool_choice``."""
    # A model rule, not a combination error: a model that rejects forcing does so on every request,
    # so the memo holds for the run. `tools` stays advertised and _extract_response_model still
    # raises on a reply that skips the tool. The rejection can arrive as a 400/422, or (gateway)
    # as a 200-status stream relaying the same rejection mid-stream instead.
    if not ("tool_choice" in kw and "tool_choice" in low
            and (e.status_code in PARAM_REJECTION_STATUS
                 or is_gateway_wrapped_param_rejection(e))):
        return False
    _NO_TOOL_CHOICE_MODELS.add(model)
    warn_once(
        _WARNED_DROPS, f"tool_choice:{model}",
        f"WARN [sdk]: {model} rejected a forced `tool_choice` (status={e.status_code}) — "
        f"retrying with the tool advertised but not forced. Structured output is "
        f"no longer GUARANTEED for this model; a reply that skips the "
        f"tool fails loudly rather than shipping unvalidated.")
    kw.pop("tool_choice", None)
    if response_model is not None:  # always, when tool_choice was set
        # The request that just lost its forcing carries the ask instead
        kw["system"] = _build_system_content(
            client, with_submit_instruction(system_prompt, response_model), model,
            tools_text=tools_text)
    return True


def _reforce_tool_choice(kw: dict, tool_choice: dict, *, client, model: str,
                         system_prompt: str | None,
                         response_model: type[BaseModel] | None,
                         tools_text: str = "") -> None:
    """Force the structured tool again and restore the un-augmented system block."""
    # Byte-identical to a never-unforced request, so the system cache breakpoint still reads
    if response_model is None or model in _NO_TOOL_CHOICE_MODELS:
        return
    kw["tool_choice"] = tool_choice
    if system_prompt:
        kw["system"] = _build_system_content(client, system_prompt, model, tools_text=tools_text)
    else:
        kw.pop("system", None)


def prompt(
    user_prompt: str | list[dict],
    *,
    model: str,
    cache_prefix: str | None = None,
    system_prompt: str | None = None,
    max_tokens: int | None = None,
    temperature: float | None = None,
    thinking_budget: int | None = None,
    betas: list[str] | None = None,
    # Accepted-but-ignored so the dispatcher can pass through cli.prompt() calls without crashing.
    json_schema: dict | None = None,
    output_format: str = "text",
    cwd: str | None = None,
    max_budget_usd: float | None = None,
    timeout: int | None = None,
    tag: str | None = None,
    response_model: type[BaseModel] | None = None,
    # Reasoning-effort tier, same A5 mapping as agentic(); None keeps the request as before.
    effort: str | None = None,
) -> str:
    _warn_max_budget_unenforced("prompt", max_budget_usd)
    client = _get_client()
    max_tok = max_tokens or 16000

    # Forced under adaptive thinking too (see _forcing_blocked), exactly as in agentic(); the tool
    # stays advertised and validated either way.
    effort_kw = _effort_thinking_kwargs(model, effort)
    forced = response_model is not None and not _forcing_blocked(model, effort_kw.get("thinking"))
    # `system_prompt` stays un-augmented so a re-forced request can restore it byte-identically
    system_text = system_prompt
    if response_model is not None and not forced:
        # Unforced (memoised model, or manual thinking): name the tool as the only accepted reply,
        # before the system text is measured for the cache breakpoint below
        system_text = with_submit_instruction(system_prompt, response_model)

    # The system prompt renders ahead of the user turn, so it counts toward the cumulative minimum
    # for the prefix breakpoint. On s4 this is decisive: system + shard prefix clear the model
    # minimum together even when neither would alone.
    user_content = _build_cache_prefix_content(
        client, cache_prefix, user_prompt,
        model=model, preceding=system_text or "")

    kw: dict = {
        "model": model,
        "max_tokens": max_tok,
        # user_content, not user_prompt: whatever _build_cache_prefix_content decided — the
        # untouched prompt when no cache_prefix was passed, else prefix-then-remainder with a
        # breakpoint only where the route/minimum/kill-switch gate allows one.
        "messages": [{"role": "user", "content": user_content}],
    }
    if response_model is not None:
        kw["tools"] = [_response_model_tool(response_model)]
        if forced:
            kw["tool_choice"] = {"type": "tool", "name": _RESPONSE_MODEL_TOOL_NAME}
        elif model not in _NO_TOOL_CHOICE_MODELS:
            _warn_tool_choice_dropped_for_thinking(model, effort)
    # Merged, never assigned: see _beta_headers — a bare assignment clobbers the OAuth
    # client's default anthropic-beta carrier and 401s the role.
    beta_headers = _beta_headers(betas)
    if beta_headers:
        kw["extra_headers"] = beta_headers
    if thinking_budget and model not in _NO_THINK_MODELS:
        # Legacy: `thinking_budget` never reaches the wire (adaptive has no budget_tokens); it only
        # turns thinking on and sizes headroom, kept because thinking is billed inside max_tokens
        # (thinking.md) and the cache probe sends max_tokens=256 with it (preflight._PROBE_*).
        if max_tok <= thinking_budget:
            max_tok = thinking_budget + 8000
            kw["max_tokens"] = max_tok
        kw["thinking"] = {"type": "adaptive"}
        temperature = None
    if effort_kw:
        # Anthropic rejects a temperature alongside thinking, as on the budget arm above.
        kw.update(effort_kw)
        temperature = None
    if temperature is not None:
        if _supports_temperature(model):
            kw.setdefault("extra_body", {})["temperature"] = temperature
        elif model not in _NO_TEMP_MODELS:
            _NO_TEMP_MODELS.add(model)
            console.write(f"    [sdk] note: {model} does not accept `temperature`; "
                          f"dropping T={temperature} for this and subsequent calls")
    if system_text:
        # s4 reuses this block across unit×run for cache-read savings, but placement is gated
        # identically to the prefix breakpoint — see _build_system_content.
        kw["system"] = _build_system_content(client, system_text, model)

    # A disabled SESSION ceiling (timeout 0/None, S6-off) must not disable this REQUEST hang-stop,
    # hence `timeout or DEFAULT...` rather than passing a falsy timeout straight through.
    request_timeout = effort_scaled_seconds(
        timeout or DEFAULT_REQUEST_TIMEOUT_SECONDS, effort, kind=ClockKind.REQUEST)

    _up_chars = (
        sum(len(b.get("text", "")) for b in user_prompt if isinstance(b, dict))
        if isinstance(user_prompt, list) else len(user_prompt)
    )
    console.write(f"    [sdk] prompt -> {model}{f' [{tag}]' if tag else ''} "
                  f"({_up_chars} chars, "
                  f"max_tokens={max_tok}"
                  f"{f', T={temperature}' if 'temperature' in kw.get('extra_body', {}) else ''}"
                  f"{f', thinking={thinking_budget}' if 'thinking' in kw and not effort_kw else ''}"
                  f"{f', effort={effort}' if effort_kw else ''}"
                  f", timeout={request_timeout:g}s)")

    session_t0 = time.monotonic()
    session_budget = request_timeout

    attempts, retry_wait = 3, 60
    auth_attempt = 0
    msg = None
    # VVAH-E005 state: one cap-bounded doubled-budget retry per call, then fail loud.
    trunc_retried = False
    trunc_retry_at = 0
    # `attempts` is read live so a param-drop on the final attempt can grant one bounded extra send.
    attempt = 0
    while attempt < attempts:
        attempt += 1
        try:
            # Stream so large max_tokens (64k) doesn't trip the HTTP timeout; just need final msg.
            _t0 = time.monotonic()
            send = turn_options(session_t0, session_budget, request_timeout)
            stream_client = client.with_options(**send)
            with stream_client.messages.stream(**kw) as stream:
                msg = _drain_within_deadline(
                    stream, deadline=_t0 + send["timeout"],
                    stage=tag, effort=effort, budget_s=request_timeout)
            note_budget_use(time.monotonic() - _t0, request_timeout, effort)
            if finish_truncated(msg.stop_reason):
                # Budget exhausted (max_tokens, or the context window on 4.5+ models): one doubled
                # retry bounded by the model's own cap, then E005.
                # The clipped attempt was paid for: bank it like the other three routes do.
                clipped_usage = _bank_usage(msg)
                produced = clipped_usage.get("output_tokens") if clipped_usage else None
                requested_now = kw["max_tokens"]
                retry_at = (None if trunc_retried else truncation_retry_max(
                    requested_now, cap=MODEL_MAX_OUTPUT_TOKENS))
                if retry_at is not None:
                    # A final-attempt truncation still gets its retry, capped like param-drops.
                    if attempt == attempts and attempts < _ATTEMPTS_CEILING:
                        attempts += 1
                    if attempt < attempts:
                        trunc_retried, trunc_retry_at = True, retry_at
                        COUNTERS.bump(TRUNCATED_RETRY_ATTEMPTED_COUNTER)
                        log.warning(Event.TRUNCATED_RETRY, route="sdk", stop_reason=msg.stop_reason,
                                    budget=requested_now, retry_at=retry_at)
                        _errlog.log(
                            tag or "sdk", tag or "truncation",
                            f"VVAH-E005 warning: reply truncated at "
                            f"max_tokens={requested_now}; retrying once at "
                            f"{retry_at}",
                            error_code=TruncatedResponseError.error_code,
                            recovered=True, produced=produced)
                        kw["max_tokens"] = retry_at
                        msg = None
                        continue
                raise _truncation_error(requested=max_tok, retried=trunc_retry_at, tag=tag,
                                        retry_at=retry_at, produced=produced)
            if trunc_retried:
                COUNTERS.bump(TRUNCATED_RETRY_RECOVERED_COUNTER)
            break
        except anthropic.APIStatusError as e:
            body = str(getattr(e, "message", e))
            low = rejection_text(e).lower()
            if ("temperature" in kw.get("extra_body", {}) and "temperature" in low
                    and e.status_code in PARAM_REJECTION_STATUS):
                _NO_TEMP_MODELS.add(model)
                console.write(f"    [sdk] {model} rejected `temperature` — "
                              f"retrying without it")
                kw.get("extra_body", {}).pop("temperature", None)
                if attempt == attempts and attempts < _ATTEMPTS_CEILING:
                    attempts += 1  # grant the cleaned request one more send (capped)
                continue
            # tool_choice BEFORE thinking, deliberately: such a 400 routinely names BOTH
            # parameters, so with the thinking arm first the model was permanently recorded in
            # _NO_THINK_MODELS for a rejection that was about tool_choice, and every later call
            # silently lost its configured thinking.
            if _unforce_rejected_tool_choice(kw, e, low, client=client, model=model,
                                             system_prompt=system_prompt,
                                             response_model=response_model):
                if attempt == attempts and attempts < _ATTEMPTS_CEILING:
                    attempts += 1  # grant the cleaned request one more send (capped)
                continue
            if ("thinking" in kw and "thinking" in low
                    and e.status_code in PARAM_REJECTION_STATUS):
                # Status-gated like the arms above and agentic(): a 5xx/529 whose text names
                # thinking is an outage for the transient arm, not a parameter rejection.
                # Only remember the model as thinking-incapable when the body says the
                # FEATURE is unsupported. A bare 400 that merely mentions thinking (a
                # combination error, an unrelated invalid_request whose text names the
                # field) drops it for THIS request only — a process-wide memo off that
                # evidence silently downgrades every later call on the model.
                unsupported = ("not supported" in low or "unexpected" in low
                               or "adaptive" in low or "unrecognized" in low
                               or "unknown" in low)
                if unsupported:
                    _NO_THINK_MODELS.add(model)
                console.write(f"    [sdk] {model} rejected extended thinking "
                              f"({kw['thinking']}) — retrying without it"
                              f"{'' if unsupported else ' (this request only)'}")
                kw.pop("thinking", None)
                if effort_kw:
                    # Mirrors agentic()'s arm: the effort tier rides with thinking, and a forcing
                    # manual thinking had withheld comes back (with the plain system block).
                    kw.pop("output_config", None)
                    _reforce_tool_choice(
                        kw, {"type": "tool", "name": _RESPONSE_MODEL_TOOL_NAME},
                        client=client, model=model, system_prompt=system_prompt,
                        response_model=response_model)
                if attempt == attempts and attempts < _ATTEMPTS_CEILING:
                    attempts += 1  # grant the cleaned request one more send (capped)
                continue
            # VVAH-E001: auth cannot heal on a retry, so a few fast retries then halt, and the
            # check must come BEFORE the transient arm. With the order reversed, a body carrying
            # BOTH auth and transient prose took the 60s ladder twice then died on the post-loop
            # parameter-drop guard, losing AuthenticationError, the errors.jsonl error_code, the
            # remediation block and the batch halt.
            # A RETRYABLE status still beats prose: a 503/429 whose payload happens to say
            # "authentication_failed" is an outage. Only a status no retry can help — or an
            # explicit 401 — is auth (_auth_failure_sdk, the rule agentic() applies too).
            if _auth_failure_sdk(e):
                # `attempt < attempts` as well as the auth budget: with the two equal, every send
                # was spent on a `continue` and the raise below was UNREACHABLE — a wrong
                # credential surfaced as the post-loop parameter-drop RuntimeError with no
                # AuthenticationError, no VVAH-E001 code and no batch halt.
                if auth_attempt < _AUTH_MAX_RETRIES_SDK and attempt < attempts:
                    wait = _AUTH_BACKOFF_SDK[min(auth_attempt,
                                                 len(_AUTH_BACKOFF_SDK) - 1)]
                    if overrun := wait_overrun(wait, session_t0, session_budget,
                                               stage=tag or "", route="sdk", effort=effort):
                        raise overrun from e
                    console.write(f"    [sdk] authentication error "
                                  f"(status={e.status_code}, attempt "
                                  f"{auth_attempt + 1}/{_AUTH_MAX_RETRIES_SDK}); "
                                  f"retrying in {wait}s")
                    time.sleep(wait)
                    auth_attempt += 1
                    continue
                # redact() BEFORE [:400]: truncating first can cut a JWT segment / PEM end
                # marker so the pattern no longer matches and raw credential text survives.
                raise AuthenticationError(redact(body)[:400],
                                          status_code=e.status_code,
                                          backend="sdk") from e
            if _is_transient_sdk(e) and attempt < attempts:
                wait = jittered_delay(retry_wait)
                if overrun := wait_overrun(wait, session_t0, session_budget,
                                           stage=tag or "", route="sdk", effort=effort):
                    raise overrun from e
                console.write(f"    [sdk] transient error (status={e.status_code}, "
                              f"attempt {attempt}/{attempts}, model={model}); retrying "
                              f"in {wait:.1f}s")
                time.sleep(wait)
                continue
            # Scrub the response body (may reflect auth headers/cookies) before the exception text.
            raise RuntimeError(
                f"Anthropic SDK call failed (status={e.status_code}, model={model}): "
                f"{redact(body)}"
            ) from e
        except (anthropic.APIConnectionError, httpx2.TransportError) as e:
            if is_timeout_failure(e):
                raise call_timeout_error(
                    stage=tag or "", route="sdk", budget_s=request_timeout, effort=effort,
                    cause_text=f"Anthropic SDK request exceeded {request_timeout:g}s") from e
            if proxy := proxy_error(e, backend="sdk"):
                raise proxy from e
            if attempt < attempts:
                wait = jittered_delay(retry_wait)
                if overrun := wait_overrun(wait, session_t0, session_budget,
                                           stage=tag or "", route="sdk", effort=effort):
                    raise overrun from e
                console.write(f"    [sdk] connection error (attempt {attempt}/{attempts}): "
                              f"{e} — retrying in {wait:.1f}s")
                time.sleep(wait)
                continue
            raise RuntimeError(
                f"Anthropic SDK connection error after {attempts} attempts "
                f"(model={model}): {redact(str(e))}\n"
                f"  cause: {redact(cause_chain(e) or 'no underlying cause reported')}\n"
                f"  hint: this is a network/TLS/DNS/proxy failure, not an auth/model "
                f"error. On corp networks set SSL_CERT_FILE to your CA bundle, and "
                f"check HTTPS_PROXY / ANTHROPIC_SDK_BASE_URL."
            ) from e

    if msg is None:
        raise RuntimeError(
            f"Anthropic SDK call to {model} exhausted all retries without a "
            f"successful response (every attempt hit a parameter-drop retry). "
            f"Final request kwargs keys: {sorted(kw)}."
        )

    usage = _bank_usage(msg)
    if usage:
        _in = (usage.get("input_tokens", 0)
               + (usage.get("cache_creation_input_tokens") or 0)
               + (usage.get("cache_read_input_tokens") or 0))
        cr = usage.get("cache_read_input_tokens") or 0
        cw = usage.get("cache_creation_input_tokens") or 0
        out = usage.get("output_tokens", 0)
        cache_info = f" (cache_read={cr}, cache_write={cw})" if (cr or cw) else ""
        console.write(f"    [sdk] usage: in={_in}{cache_info} out={out}")
    # After banking: a refusal mid-stream is billed
    _raise_if_refused(msg, tag=tag)

    if response_model is not None:
        text = _extract_response_model(response_model, msg, model=model).model_dump_json()
    else:
        text = "".join(b.text for b in msg.content if b.type == "text")
    # absent-vs-zero matters; see output_tokens_for_gate.
    out_tokens = output_tokens_for_gate(usage)
    check_response_quality(text.strip(), stage=tag or "",
                           output_tokens=out_tokens)
    return text.strip()


# agentic(): read-only tool loop (Read/Glob/Grep); mutation/Bash delegates to agent_sdk.py sandbox.

_AGENTIC_MAX_TOK = AGENTIC_MAX_TOKENS
_AGENTIC_MAX_TURNS = 40


def _assistant_blocks(content) -> list[dict]:
    """Serialize SDK response blocks back into the dict shape the Messages API expects on the next turn."""
    out: list[dict] = []
    for b in content:
        bt = getattr(b, "type", None)
        if bt == "text":
            # The API rejects an empty text block (see _build_cache_prefix_content); nothing lost
            if b.text.strip():
                out.append({"type": "text", "text": b.text})
        elif bt == "tool_use":
            out.append({"type": "tool_use", "id": b.id,
                        "name": b.name, "input": b.input})
        else:
            try:
                d = b.model_dump()
                d.pop("cache_control", None)  # never persist markers in history
                out.append(d)
            except Exception:
                pass
    return out


def _with_cache_marker(client, msgs: list[dict]) -> list[dict]:
    """Return a copy of `msgs` with cache_control stripped and one ephemeral marker placed on the last content b..."""
    out: list[dict] = []
    last_block: dict | None = None
    for m in msgs:
        c = m.get("content")
        if isinstance(c, list):
            cc: list = []
            for b in c:
                if isinstance(b, dict):
                    b = {k: v for k, v in b.items() if k != "cache_control"}
                    last_block = b
                cc.append(b)
            out.append({**m, "content": cc})
        else:
            out.append(m)
    if (last_block is not None and _cache_markers_enabled()
            and _cache_route(client) in _CACHE_CONTROL_ROUTES):
        last_block["cache_control"] = {"type": "ephemeral"}
    return out


def _auth_failure_sdk(error: anthropic.APIStatusError) -> bool:
    """Whether *error* is an unhealable credential failure (VVAH-E001); echoed request stripped."""
    return bool(error.status_code == 401
                or (_AUTH_STATUS_RX.search(rejection_text(error))
                    and error.status_code not in RETRYABLE_STATUS))


def _drain_within_deadline(stream: Any, *, deadline: float, stage: str | None,
                           effort: str | None, budget_s: float | None) -> Any:
    """Iterate *stream* to its final message, closing it once the wall-clock *deadline* passes.

    A per-request SDK timeout bounds each individual read, so a trickle of small chunks (each
    arriving well inside that window) can otherwise run past the stage's own wall-clock budget
    forever. This checks the clock between chunks instead of trusting the transport layer to.
    Duck-typed on iterability so a stream double exposing only `get_final_message()` (every
    pre-existing test fake) is unaffected; the real SDK's `MessageStream` supports both.
    """
    if hasattr(stream, "__iter__"):
        for _event in stream:
            if time.monotonic() >= deadline:
                stream.close()
                raise call_timeout_error(
                    stage=stage or "", route="sdk", budget_s=budget_s, effort=effort,
                    cause_text=f"sdk stream exceeded its {budget_s:g}s wall-clock budget")
    return stream.get_final_message()


def _check_agentic_stop(msg, *, client, messages: list[dict], call_kw: dict,
                        model: str, tag: str | None, requested: int,
                        response_model: type[BaseModel] | None = None,
                        dispatchable: bool = False,
                        effort: str | None = None,
                        request_timeout: float | None = None,
                        session_t0: float | None = None,
                        session_budget: float | None = None):
    """Return ``(msg, override_text)``."""
    if not finish_truncated(getattr(msg, "stop_reason", None)):
        return msg, None
    retry_at = truncation_retry_max(requested, cap=MODEL_MAX_OUTPUT_TOKENS)
    if retry_at is not None:
        COUNTERS.bump(TRUNCATED_RETRY_ATTEMPTED_COUNTER)
        log.warning(Event.TRUNCATED_RETRY, route="sdk", stop_reason=msg.stop_reason,
                    budget=requested, retry_at=retry_at)
        _errlog.log(
            tag or "sdk", tag or "truncation",
            f"VVAH-E005 warning: agentic reply truncated at "
            f"max_tokens={requested}; retrying once at {retry_at}",
            error_code=TruncatedResponseError.error_code, recovered=True)
        retry_kw = {**call_kw, "max_tokens": retry_at}
        try:
            _t0 = time.monotonic()
            send = turn_options(session_t0 or _t0, session_budget, request_timeout)
            retry_client = client.with_options(**send)
            with retry_client.messages.stream(
                    messages=_with_cache_marker(client, messages), **retry_kw) as stream:
                retried = _drain_within_deadline(
                    stream, deadline=_t0 + send["timeout"],
                    stage=tag, effort=effort, budget_s=request_timeout)
            note_budget_use(time.monotonic() - _t0, request_timeout, effort)
        except anthropic.APIStatusError as e:
            # Same auth-first rule as the primary send: an unhealable
            # credential must surface as VVAH-E001, not a raw SDK exception
            # `orchestrator/batch.py` has no halt rule for.
            if _auth_failure_sdk(e):
                raise AuthenticationError(
                    redact(str(getattr(e, "message", e)))[:400],
                    status_code=e.status_code, backend="sdk") from e
            low = rejection_text(e).lower()
            if e.status_code in PARAM_REJECTION_STATUS and _CTX_OVERFLOW_RX.search(low):
                # The doubled budget is what pushed input+output over the
                # context window (measured: a history that fit at the
                # original cap can exceed it at double). Not useful to
                # retry a retry — fall back to the plain, un-retried raise.
                COUNTERS.bump(TRUNCATED_REPLIES_COUNTER)
                raise TruncatedResponseError(
                    "agentic reply hit the output-token budget, and the "
                    "doubled-budget retry would overflow the context "
                    "window; no useful retry",
                    stage=tag or "", requested=requested, retried=0) from e
            raise RuntimeError(redact(
                f"Anthropic SDK agentic truncation-retry failed "
                f"(status={e.status_code}, model={model}): "
                f"{getattr(e, 'message', e)}"
            )) from e
        except (anthropic.APIConnectionError, httpx2.TransportError) as e:
            if is_timeout_failure(e):
                raise call_timeout_error(
                    stage=tag or "", route="sdk", budget_s=request_timeout, effort=effort,
                    cause_text=f"Anthropic SDK agentic truncation-retry exceeded "
                               f"{request_timeout:g}s") from e
            if proxy := proxy_error(e, backend="sdk"):
                raise proxy from e
            raise RuntimeError(redact(
                f"Anthropic SDK agentic truncation-retry connection error "
                f"(model={model}): {e}"
            )) from e
        if retried.usage:
            retried_usage = cast("TokenUsage", retried.usage.model_dump())
            _note_unparsed_cache_keys(retried_usage)
            TOKENS.add(retried_usage)
        if finish_truncated(getattr(retried, "stop_reason", None)):
            COUNTERS.bump(TRUNCATED_REPLIES_COUNTER)
            raise TruncatedResponseError(
                "agentic reply still hit the output-token budget after the "
                "doubled retry",
                stage=tag or "", requested=requested, retried=retry_at)
        # A `dispatchable` tool call (submit included) goes to the turn loop; no check belongs here.
        undispatched_call = (getattr(retried, "stop_reason", None) == "tool_use"
                             and not dispatchable)
        if undispatched_call and response_model is None:
            # No tool_choice was forcing anything here, so a tool call at the doubled budget IS
            # an anomaly, and this is the forced-final call site with no turn loop left to dispatch
            # it from — fail loudly rather than misread its content blocks as final text.
            raise TruncatedResponseError(
                "agentic reply's doubled-budget retry unexpectedly requested "
                "a tool call; refusing to guess at dispatching it from the "
                "truncation-retry seam",
                stage=tag or "", requested=requested, retried=retry_at)
        COUNTERS.bump(TRUNCATED_RETRY_RECOVERED_COUNTER)
        if undispatched_call and response_model is not None:
            # The forced call the original (clipped) attempt was making
            # completed on retry — extract it exactly as the caller
            # already would have on a first-try success.
            return retried, _extract_response_model(
                response_model, retried, model=model).model_dump_json()
        return retried, None
    COUNTERS.bump(TRUNCATED_REPLIES_COUNTER)
    raise TruncatedResponseError(
        f"agentic reply hit the output-token budget (stop_reason="
        f"{msg.stop_reason}, max_tokens={requested}); already at "
        f"the model output cap ({MODEL_MAX_OUTPUT_TOKENS}); no useful retry",
        stage=tag or "", requested=requested, retried=0)


#: Marker on an evicted tool result, so `_shrink_history` advances instead of re-picking.
_EVICTED_MARK = "[evicted to fit context]"
_CTX_OVERFLOW_RX = re.compile(
    r"context.?length|context length|exceed.*(?:token|limit)|too long", re.I)


def _shrink_history(messages: list[dict]) -> bool:
    """Evict the oldest not-yet-evicted oversized tool result, returning whether it shrank one."""
    # The Anthropic-shape counterpart of ``openai._shrink_history`` — same policy, same marker,
    # same advance-not-repick contract. It cannot BE that function: here a tool result is a
    # ``{"type": "tool_result", ...}`` block inside a user message, not a ``role: "tool"``
    # message, so only the walk differs.
    for m in messages:
        blocks = m.get("content")
        if not isinstance(blocks, list):
            continue
        for b in blocks:
            if not isinstance(b, dict) or b.get("type") != "tool_result":
                continue
            c = b.get("content")
            if (isinstance(c, str) and len(c) > 1200
                    and not c.endswith(_EVICTED_MARK)):
                b["content"] = c[:800] + "\n…" + _EVICTED_MARK
                return True
    return False


def agentic(
    user_prompt: str,
    *,
    model: str,
    system_prompt: str | None = None,
    allowed_tools: list[str] | None = None,
    cwd: str,
    max_budget_usd: float | None = None,   # accepted for parity; unused
    permission_mode: str = "auto",         # accepted for parity; unused
    max_turns: int | None = None,
    # Session deadline: forwarded to the mutating-tool delegation below (which enforces it); the
    # raw loop enforces it itself as a session clock -- it raises CallTimeoutError before
    # starting a turn once this many seconds (effort-scaled) have elapsed.
    timeout: int | None = None,
    tag: str | None = None,
    # `extra_tools` are Anthropic tool schemas; `extra_dispatch(name, input)` runs one and
    # returns its string result, or None to DEFER (a localtools name, or genuinely unknown).
    # A caller tool is the caller's to log and size-cap in its own dispatch; this loop only logs
    # the localtools IT runs.
    extra_tools: list[dict] | None = None,
    extra_dispatch=None,
    response_model: type[BaseModel] | None = None,
    # Per-turn output ceiling, defaulting to AGENTIC_MAX_TOKENS (16k). `via: cli`'s agentic leg
    # accepts no such parameter in either shape, so it stays on its own default and the dispatcher
    # warns once instead of silently dropping a configured ceiling.
    max_output_tokens: int | None = None,
    # Out-of-loop EvidenceGate enforcement: called right after a structured submit VALIDATES,
    # before it is accepted as the final answer. Bounded by the gate's own `max_rejections`, NOT
    # by `STRUCTURED_REASK_MAX`, which bounds schema malformation — a different failure.
    submit_guard: Callable[[], str | None] | None = None,
    # Out-of-loop tool WITHDRAWAL (B4): called at the top of every turn; a returned name
    # is dropped from `base_kw["tools"]` for the remaining turns instead of staying bound
    # so the model can keep spending turns on calls the adapter's budget only refuses.
    # Mirrors `ToolCallBudget.wrap_model_call`'s in-loop withdrawal on `via: deepagents`.
    # `None` keeps every existing caller (none of which passes this) byte-identical.
    exhausted_tools: Callable[[], frozenset[str]] | None = None,
    # Reasoning-effort tier (A5): this route had NO parameter for it at all -- only
    # `prompt()`'s `thinking_budget` carried extended thinking, never `agentic()`.
    # Translated through the same `EffortLevel` vocabulary `via: deepagents` uses
    # (`_anthropic_thinking_kwargs`) into adaptive-thinking kwargs. `None` (the
    # default) keeps every existing caller byte-identical.
    effort: str | None = None,
) -> str:
    turns_cap = int(max_turns) if max_turns else _AGENTIC_MAX_TURNS
    out_cap = int(max_output_tokens) if max_output_tokens else _AGENTIC_MAX_TOK
    # `None` means unspecified (take the read-only default); an EMPTY list means the caller
    # wants no localtools at all. Folding the two together with `or` made that request
    # impossible to express, and silently added read tools a caller supplying its own would
    # then advertise twice — which the API rejects outright.
    allowed = list(DEFAULT_READ_TOOLS) if allowed_tools is None else list(allowed_tools)
    if "Bash" in allowed:
        raise ValueError(
            "sdk.agentic: `Bash` is forbidden on `via: sdk`; remove it from "
            "allowed_tools or switch that role to `via: cli`.")
    ok, missing = _localtools.supported(allowed)
    if missing:
        # The local raw-anthropic loop is read-only. A role needing file-MUTATION tools or Bash
        # is routed to the Claude Agent SDK, which provides them inside a cwd-confined permission
        # sandbox, so `via: sdk` stays a drop-in for fix-mode remediation.
        if extra_tools:
            # The Agent SDK path can't carry a caller-supplied tool, so a request that
            # mixes both has no coherent routing. No shipped caller does this.
            raise ValueError(
                "sdk.agentic: extra_tools cannot be combined with mutating/Bash tools "
                f"that route to the Claude Agent SDK ({missing})")

        # Mutation/Bash tools route to the Agent SDK's sandbox, keeping `via: sdk` fix-mode-capable.
        from vvaharness.backends.llm import (  # noqa: PLC0415 — lazy: agent SDK is optional
            agent_sdk as _agent_sdk,
        )
        console.write(f"    [sdk] agentic requests {missing} (mutating/Bash) — "
                      f"delegating to the Claude Agent SDK backend")
        return _agent_sdk.agentic(
            user_prompt, model=model, system_prompt=system_prompt,
            allowed_tools=allowed, cwd=cwd, max_budget_usd=max_budget_usd,
            permission_mode=permission_mode, max_turns=max_turns, tag=tag,
            timeout=timeout, effort=effort,
        )
    # Below this point the raw Anthropic loop drives the call itself, not the
    # Agent SDK delegation above (which DOES forward and enforce both knobs) —
    # only this path drops them.
    _warn_max_budget_unenforced("agentic", max_budget_usd)
    client = _get_client()
    # Two clocks compose: request_timeout bounds a call already in flight; the session clock
    # below (derived from `timeout`) stops the loop from STARTING a turn past its budget.
    request_timeout = effort_scaled_seconds(
        DEFAULT_REQUEST_TIMEOUT_SECONDS, effort, kind=ClockKind.REQUEST)
    session_budget = (effort_scaled_seconds(timeout, effort, kind=ClockKind.SESSION)
                      if timeout else None)
    session_t0 = time.monotonic()
    tools = [*_localtools.anthropic_schemas_for(ok), *(extra_tools or [])]
    advertised = ok + [t.get("name") for t in (extra_tools or [])]
    if response_model is not None:
        tools = [*tools, _response_model_tool(response_model)]
        advertised = [*advertised, _RESPONSE_MODEL_TOOL_NAME]

    base_kw: dict = {"model": model, "max_tokens": out_cap,
                     "tools": tools}
    thinking_kwargs = _effort_thinking_kwargs(model, effort)
    base_kw.update(thinking_kwargs)
    # `system_prompt` stays un-augmented so a re-forced request can restore it byte-identically
    system_text = system_prompt
    if response_model is not None:
        if not _forcing_blocked(model, thinking_kwargs.get("thinking")):
            # Sent under adaptive thinking too; only advisory on some 5.x models (_forcing_blocked)
            base_kw["tool_choice"] = {"type": "any"}
        else:
            # Unforced (memoised model, or manual thinking): ask for the tool by name
            if model not in _NO_TOOL_CHOICE_MODELS:
                _warn_tool_choice_dropped_for_thinking(model, effort)
            system_text = with_submit_instruction(system_prompt, response_model)
    tools_text = json.dumps(tools, default=str)
    if system_text:
        # Tool schemas render ahead of the system block and count toward the cumulative minimum,
        # so their serialized size is what precedes it.
        base_kw["system"] = _build_system_content(client, system_text, model,
                                                  tools_text=tools_text)
    # As a block, not a bare string, so _with_cache_marker can land the history
    # breakpoint on turn 1 instead of re-billing the prompt as a write on turn 2.
    messages: list[dict] = [{"role": "user",
                             "content": [{"type": "text", "text": user_prompt}]}]

    tag_sfx = f" [{tag}]" if tag else ""
    console.write(f"    [sdk] agentic -> {model}{tag_sfx} (tools={advertised}, "
                  f"max_turns={turns_cap}, cwd={cwd})")

    tool_calls_total = 0
    # Bounds the submit-validation re-ask ladder below independently of the
    # overall turn budget: a model that keeps mis-shaping the same submit
    # must not spend the WHOLE turn budget on retries that keep failing the
    # same way (shared with openai.py's identical ladder).
    submit_rejects = 0
    # One in-session re-ask per call when a structured session ends on prose (openai.py's twin)
    schema_nudged = False
    # B4: names already dropped from `base_kw["tools"]`, so the withdrawal below only
    # rebuilds the list (and prints) the turn a name is newly exhausted, not every turn.
    withdrawn: frozenset[str] = frozenset()
    for turn in range(1, turns_cap + 1):
        if session_budget and time.monotonic() - session_t0 >= session_budget:
            # The orphaned turn is discarded today anyway: stopping here just stops its billing.
            raise call_timeout_error(
                stage=tag or "", route="sdk", budget_s=session_budget, effort=effort,
                cause_text=f"session clock exceeded {session_budget:g}s before turn {turn}")
        if exhausted_tools is not None:
            newly_exhausted = exhausted_tools() - withdrawn
            if newly_exhausted:
                withdrawn |= newly_exhausted
                base_kw["tools"] = [t for t in base_kw["tools"]
                                    if t.get("name") not in withdrawn]
                console.write(f"    [sdk] withdrawing exhausted tool(s) "
                              f"{sorted(newly_exhausted)} for the remaining turns{tag_sfx}")
        msg = None
        transients = 0
        shrinks = 0
        while msg is None:
            try:
                _t0 = time.monotonic()
                send = turn_options(session_t0, session_budget, request_timeout)
                turn_client = client.with_options(**send)
                with turn_client.messages.stream(messages=_with_cache_marker(client, messages),
                                                 **base_kw) as stream:
                    msg = _drain_within_deadline(
                        stream, deadline=_t0 + send["timeout"],
                        stage=tag, effort=effort, budget_s=request_timeout)
                note_budget_use(time.monotonic() - _t0, request_timeout, effort)
            except anthropic.APIStatusError as e:
                # Auth FIRST, the same rule and for the same reason as prompt()'s arm: a
                # mid-scan expired credential is unhealable, and without this the loop
                # spent its whole transient ladder on it and then raised a generic
                # RuntimeError — no VVAH-E001, no remediation block, no batch halt.
                if _auth_failure_sdk(e):
                    raise AuthenticationError(
                        redact(str(getattr(e, "message", e)))[:400],
                        status_code=e.status_code, backend="sdk") from e
                low = rejection_text(e).lower()
                # Context-window overflow: evict the oldest oversized tool result and
                # retry, as the openai loop has always done. Bounded at 16 evictions.
                if (e.status_code in PARAM_REJECTION_STATUS and _CTX_OVERFLOW_RX.search(low)
                        and shrinks < 16 and _shrink_history(messages)):
                    shrinks += 1
                    console.write(f"      [sdk] context overflow (turn {turn}); evicted "
                                  f"oldest tool output [{shrinks}], retrying")
                    continue
                # tool_choice BEFORE thinking, as in prompt(): bounded, since the memo unforces
                if _unforce_rejected_tool_choice(base_kw, e, low, client=client, model=model,
                                                 system_prompt=system_prompt,
                                                 response_model=response_model,
                                                 tools_text=tools_text):
                    continue
                # Only memo the model as thinking-incapable when the body names the FEATURE: a
                # process-wide memo off a bare 400 that merely mentions thinking would silently
                # downgrade every later call on that model.
                if (e.status_code in PARAM_REJECTION_STATUS and "thinking" in base_kw
                        and "thinking" in low):
                    unsupported = ("not supported" in low or "unexpected" in low
                                  or "adaptive" in low or "unrecognized" in low
                                  or "unknown" in low)
                    if unsupported:
                        _NO_THINK_MODELS.add(model)
                    base_kw.pop("thinking", None)
                    base_kw.pop("output_config", None)
                    _reforce_tool_choice(base_kw, {"type": "any"}, client=client, model=model,
                                         system_prompt=system_prompt,
                                         response_model=response_model, tools_text=tools_text)
                    console.write(f"    [sdk] {model} rejected extended thinking — "
                                  f"retrying without it"
                                  f"{'' if unsupported else ' (this request only)'}")
                    continue
                if _is_transient_sdk(e) and transients < 4:
                    transients += 1
                    wait = jittered_delay(min(60, 20 * transients))
                    if overrun := wait_overrun(wait, session_t0, session_budget,
                                               stage=tag or "", route="sdk", effort=effort):
                        raise overrun from e
                    console.write(f"    [sdk] agentic transient (status={e.status_code}, "
                                  f"turn={turn}, retry {transients}/4); retrying in "
                                  f"{wait:.1f}s")
                    time.sleep(wait)
                    continue
                raise RuntimeError(redact(
                    f"Anthropic SDK agentic call failed (status={e.status_code}, "
                    f"model={model}, turn={turn}): {getattr(e, 'message', e)}"
                )) from e
            except (anthropic.APIConnectionError, httpx2.TransportError) as e:
                if is_timeout_failure(e):
                    raise call_timeout_error(
                        stage=tag or "", route="sdk", budget_s=request_timeout, effort=effort,
                        cause_text=f"Anthropic SDK agentic call exceeded "
                                   f"{request_timeout:g}s (turn={turn})") from e
                if proxy := proxy_error(e, backend="sdk"):
                    raise proxy from e
                if transients < 4:
                    transients += 1
                    wait = jittered_delay(min(60, 20 * transients))
                    if overrun := wait_overrun(wait, session_t0, session_budget,
                                               stage=tag or "", route="sdk", effort=effort):
                        raise overrun from e
                    console.write(f"    [sdk] agentic connection error (turn={turn}, "
                                  f"retry {transients}/4); retrying in {wait:.1f}s")
                    time.sleep(wait)
                    continue
                raise RuntimeError(redact(
                    f"Anthropic SDK agentic connection error (model={model}, "
                    f"turn={turn}): {e}\n  cause: "
                    f"{cause_chain(e) or 'no underlying cause reported'}"
                )) from e

        if msg.usage:
            turn_usage = cast("TokenUsage", msg.usage.model_dump())
            _note_unparsed_cache_keys(turn_usage)
            TOKENS.add(turn_usage)

        if finish_truncated(msg.stop_reason):
            msg, override = _check_agentic_stop(
                msg, client=client, messages=messages, call_kw=base_kw,
                model=model, tag=tag, requested=out_cap,
                response_model=response_model, dispatchable=True,
                effort=effort, request_timeout=request_timeout,
                session_t0=session_t0, session_budget=session_budget)
            if override is not None:
                return override
            # msg may now have stop_reason == "tool_use" (the retry finished
            # a tool call the clipped attempt was mid-way through) — fall
            # through to the dispatch loop below exactly as a first-try
            # tool_use would.
        # After the truncation check, so a refusal on its doubled retry is caught too
        _raise_if_refused(msg, tag=tag)
        if msg.stop_reason != "tool_use":
            text = "".join(b.text for b in msg.content
                           if getattr(b, "type", None) == "text").strip()
            # Prose where a submit was expected: ask once by name (as openai.agentic does); never
            # on the last turn (the forced-final cannot force under thinking and raises on prose).
            if response_model is not None and not schema_nudged and turn < turns_cap:
                schema_nudged = True
                COUNTERS.bump("llm_structured_prose_reask")
                log.warning(Event.STRUCTURED_PROSE_REASK, route="sdk", model=model,
                            tool=_RESPONSE_MODEL_TOOL_NAME, tag=tag or None)
                blocks = _assistant_blocks(msg.content)
                # An assistant turn needs text or tool_use (thinking-only is empty once prior
                # thinking is stripped); consecutive user turns merge, as the forced-final relies on
                if any(b.get("type") in ("text", "tool_use") for b in blocks):
                    messages.append({"role": "assistant", "content": blocks})
                messages.append({"role": "user",
                                 "content": [{"type": "text", "text": STRUCTURED_PROSE_REASK}]})
                continue
            console.write(f"    [sdk] agentic done in {turn} turn(s), "
                          f"{tool_calls_total} tool call(s)")
            return text

        messages.append({"role": "assistant",
                         "content": _assistant_blocks(msg.content)})
        results: list[dict] = []
        for b in msg.content:
            if getattr(b, "type", None) != "tool_use":
                continue
            if response_model is not None and b.name == _RESPONSE_MODEL_TOOL_NAME:
                try:
                    validated = response_model.model_validate(b.input)
                except Exception as exc:
                    # Bounded by STRUCTURED_REASK_MAX independently of the overall turn budget, so
                    # one malformed submit that keeps failing the same way cannot spend the whole
                    # ladder — losing the unit to it is the failure this seam exists to stop.
                    submit_rejects += 1
                    COUNTERS.bump("llm_structured_submit_rejected")
                    if submit_rejects >= STRUCTURED_REASK_MAX:
                        log.warning(Event.STRUCTURED_SUBMIT_REJECTED, route="sdk",
                                    tool=_RESPONSE_MODEL_TOOL_NAME, error=type(exc).__name__,
                                    rejects=submit_rejects)
                        detail, _ = structured_failure_detail(exc)
                        # recovered=True: raw submit returned; the stage's own parser decides
                        _errlog.log(
                            tag or "sdk", tag or "structured",
                            f"{_RESPONSE_MODEL_TOOL_NAME} rejected {submit_rejects} time(s); "
                            f"raw submit returned",
                            detail=detail, reason="llm_structured_reask_gave_up", recovered=True)
                        return json.dumps(dict(b.input or {}))
                    console.write(f"    [sdk] {_RESPONSE_MODEL_TOOL_NAME} rejected "
                                  f"({type(exc).__name__}) — re-asking")
                    results.append({
                        "type": "tool_result",
                        "tool_use_id": b.id,
                        "content": (f"Rejected: {str(exc)[:600]}. Fix the named "
                                    f"fields and call the tool again."),
                    })
                    continue
                if submit_guard is not None:
                    hold_text = submit_guard()
                    if hold_text is not None:
                        console.write(f"    [sdk] {_RESPONSE_MODEL_TOOL_NAME} accepted but "
                                      f"evidence-gated — re-asking")
                        results.append({
                            "type": "tool_result",
                            "tool_use_id": b.id,
                            "content": hold_text,
                        })
                        continue
                console.write(f"    [sdk] agentic done in {turn} turn(s), "
                              f"{tool_calls_total} tool call(s)")
                return validated.model_dump_json()
            tool_calls_total += 1
            args = dict(b.input or {})
            # A caller-supplied tool goes to extra_dispatch (the caller logs and caps it);
            # a localtools name returns None from it and is executed and logged here, so
            # the log follows whichever layer actually ran the tool. Same precedence as
            # openai.agentic — without it the extra_tools advertised above are offered to
            # the model and then never run.
            out = extra_dispatch(b.name, args) if extra_dispatch is not None else None
            if out is None and b.name not in ok:
                # An ungranted localtool never runs, whatever name the model emits
                out = _localtools.UNGRANTED_TOOL_ERROR.format(name=b.name)
            if out is None:
                # Capped like the openai loop's localtool results: one whole-file Read
                # otherwise consumed the window here, and the 400 it caused had no
                # recovery arm on this route at all.
                out = _localtools.cap_tool_result(
                    _localtools.execute(b.name, args, cwd=cwd))
                if not is_stage_only():
                    console.write(
                        f"      [sdk] tool {b.name}({_localtools.summarize_args(b.input)}) -> "
                        f"{len(out)} chars{tag_sfx}")
            results.append({"type": "tool_result",
                            "tool_use_id": b.id,
                            "content": out})
        # cache_control is applied at request time; history stays marker-free under the 4-block cap.
        messages.append({"role": "user", "content": results})

    # Budget exhausted: force a final answer. Unlike oai.agentic() the full tools list stays: the
    # memo arm below only catches a rejection naming tool_choice, not one of a rewritten list.
    log.warning(Event.LLM_TURN_CAP_EXHAUSTED, turns_cap=turns_cap, model=model, tag=tag_sfx)
    COUNTERS.bump("llm_turn_cap_exhausted")
    # Block-shaped, not a bare string, so the tail marker can land on it.
    if response_model is not None:
        messages.append({
            "role": "user",
            "content": [{"type": "text",
                         "text": "Tool budget exhausted. Call "
                                 f"{_RESPONSE_MODEL_TOOL_NAME} now with your best "
                                 "answer based on what you have read so far."}],
        })
    else:
        messages.append({
            "role": "user",
            "content": [{"type": "text",
                         "text": "Tool budget exhausted. Reply now with your final "
                                 "answer based on what you have read so far; do not "
                                 "call any tool."}],
        })
    final_kw = {k: v for k, v in base_kw.items() if k != "tools"}
    # Forced (or tools forbidden) unless the model rejects forcing or thinking is manual: the
    # same rule as the loop above (_forcing_blocked), so this LAST attempt for the unit never
    # sends a tool_choice the loop had learned to withhold; the except arm learns what the loop's
    # accepted `any` never surfaced. `none` is never withheld: every model accepts it, and
    # dropping it would let a memoised model's text-mode final call a tool.
    if response_model is None:
        final_kw["tool_choice"] = {"type": "none"}
    elif _forcing_blocked(model, final_kw.get("thinking")):
        final_kw.pop("tool_choice", None)
    else:
        final_kw["tool_choice"] = {"type": "tool", "name": _RESPONSE_MODEL_TOOL_NAME}
    final_kw["tools"] = tools  # API requires tools when tool_choice is set
    # Setting tool_choice at all ({"type": "none"} forbids tools, it forces none)
    # invalidates the MESSAGES cache for this call while the tools+system caches
    # still read; the marker here is a write with no reader — max-turns only.
    final_transients = 0
    while True:
        try:
            _t0 = time.monotonic()
            send = turn_options(session_t0, session_budget, request_timeout)
            final_client = client.with_options(**send)
            with final_client.messages.stream(messages=_with_cache_marker(client, messages),
                                              **final_kw) as stream:
                msg = _drain_within_deadline(
                    stream, deadline=_t0 + send["timeout"],
                    stage=tag, effort=effort, budget_s=request_timeout)
            note_budget_use(time.monotonic() - _t0, request_timeout, effort)
            break
        except anthropic.APIStatusError as e:
            if _auth_failure_sdk(e):   # auth-first, same rule as the turn loop above
                raise AuthenticationError(
                    redact(str(getattr(e, "message", e)))[:400],
                    status_code=e.status_code, backend="sdk") from e
            # Bounded: the memo pops tool_choice, so the resend cannot fail the same way
            if _unforce_rejected_tool_choice(final_kw, e, rejection_text(e).lower(),
                                             client=client, model=model,
                                             system_prompt=system_prompt,
                                             response_model=response_model,
                                             tools_text=json.dumps(final_kw["tools"],
                                                                   default=str)):
                continue
            if _is_transient_sdk(e) and final_transients < 4:
                final_transients += 1
                wait = jittered_delay(min(60, 20 * final_transients))
                if overrun := wait_overrun(wait, session_t0, session_budget,
                                           stage=tag or "", route="sdk", effort=effort):
                    raise overrun from e
                console.write(f"    [sdk] agentic forced-final transient "
                              f"(status={e.status_code}, retry {final_transients}/4); "
                              f"retrying in {wait:.1f}s")
                time.sleep(wait)
                continue
            raise RuntimeError(redact(
                f"Anthropic SDK agentic forced-final failed "
                f"(status={e.status_code}, model={model}): "
                f"{getattr(e, 'message', e)}"
            )) from e
        except (anthropic.APIConnectionError, httpx2.TransportError) as e:
            if is_timeout_failure(e):
                raise call_timeout_error(
                    stage=tag or "", route="sdk", budget_s=request_timeout, effort=effort,
                    cause_text=f"Anthropic SDK agentic forced-final exceeded "
                               f"{request_timeout:g}s") from e
            if proxy := proxy_error(e, backend="sdk"):
                raise proxy from e
            if final_transients < 4:
                final_transients += 1
                wait = jittered_delay(min(60, 20 * final_transients))
                if overrun := wait_overrun(wait, session_t0, session_budget,
                                           stage=tag or "", route="sdk", effort=effort):
                    raise overrun from e
                console.write(f"    [sdk] agentic forced-final connection error "
                              f"(retry {final_transients}/4); retrying in {wait:.1f}s")
                time.sleep(wait)
                continue
            raise RuntimeError(redact(
                f"Anthropic SDK agentic forced-final connection error "
                f"(model={model}): {e}\n  cause: "
                f"{cause_chain(e) or 'no underlying cause reported'}"
            )) from e
    if msg.usage:
        final_usage = cast("TokenUsage", msg.usage.model_dump())
        _note_unparsed_cache_keys(final_usage)
        TOKENS.add(final_usage)
    msg, override = _check_agentic_stop(
        msg, client=client, messages=messages, call_kw=final_kw, model=model,
        tag=tag, requested=out_cap, response_model=response_model,
        effort=effort, request_timeout=request_timeout,
        session_t0=session_t0, session_budget=session_budget)
    if override is not None:
        return override
    # Before the response_model branch, so the text-mode final is covered too
    _raise_if_refused(msg, tag=tag)
    if response_model is not None:
        return _extract_response_model(response_model, msg, model=model).model_dump_json()
    return "".join(b.text for b in msg.content
                   if getattr(b, "type", None) == "text").strip()
