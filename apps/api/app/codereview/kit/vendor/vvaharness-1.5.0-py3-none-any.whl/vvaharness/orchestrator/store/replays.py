# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Exploit-verification replay bundles and probe logs, per run."""
from __future__ import annotations
from vvaharness.util import logs

import sqlite3

from vvaharness.orchestrator.store._db import _REPLAY_MAX_BYTES, connect
from vvaharness.util.events import Event

log = logs.get_logger(__name__)


def save_replays(run_id: str, items: list[tuple[str, bytes]]) -> int:
    """Replace this run's exploit-verification replay bundles with ``items``."""
    # Replaces the whole set: call ONLY when EV ran, else a SAST rescan clears it; JSON not pickle
    con = connect()
    written = 0
    try:
        with con:
            con.execute("INSERT OR IGNORE INTO runs(run_id, repo_root) VALUES (?, '')",
                        (run_id,))
            con.execute("UPDATE runs SET updated_at = datetime('now') WHERE run_id = ?",
                        (run_id,))
            con.execute("DELETE FROM ev_replays WHERE run_id = ?", (run_id,))
            for key, blob in items:
                if len(blob) > _REPLAY_MAX_BYTES:
                    log.warning(Event.REPLAY_TOO_LARGE, key=key[:12], size=len(blob),
                                cap=_REPLAY_MAX_BYTES)
                    continue
                con.execute(
                    "INSERT OR REPLACE INTO ev_replays(run_id, finding_key, payload, size) "
                    "VALUES (?, ?, ?, ?)", (run_id, key, blob, len(blob)))
                written += 1
    finally:
        con.close()
    return written


def prune_replays(run_id: str, keep_keys) -> int:
    """Drop this run's replay bundles whose ``finding_key`` is not in ``keep_keys``."""
    # save_replays runs end of S6, BEFORE S7 dedup; call only post-dedup, so empty keep_keys clears
    keep = set(keep_keys or ())
    stale: list[str] = []
    con = connect()
    try:
        with con:
            rows = con.execute("SELECT finding_key FROM ev_replays WHERE run_id = ?",
                               (run_id,)).fetchall()
            stale = [r[0] for r in rows if r[0] not in keep]
            for key in stale:
                con.execute("DELETE FROM ev_replays WHERE run_id = ? AND finding_key = ?",
                            (run_id, key))
    finally:
        con.close()
    return len(stale)


def load_replays(run_id: str) -> list[tuple[str, bytes]]:
    """Return this run's replay bundles as ``[(finding_key, payload_bytes), …]``, oldest first (stable order for..."""
    con = connect()
    try:
        rows = con.execute(
            "SELECT finding_key, payload, size FROM ev_replays WHERE run_id = ? "
            "ORDER BY created_at, finding_key", (run_id,)).fetchall()
    finally:
        con.close()
    out: list[tuple[str, bytes]] = []
    for key, payload, size in rows:
        if size > _REPLAY_MAX_BYTES:               # belt-and-braces; CHECK enforces it
            log.warning(Event.REPLAY_STORED_TOO_LARGE, key=key[:12], cap=_REPLAY_MAX_BYTES)
            continue
        out.append((key, payload))
    return out


def delete_replays(run_id: str) -> int:
    """Drop this run's replay bundles. Returns rows deleted."""
    con = connect()
    try:
        with con:
            cur = con.execute("DELETE FROM ev_replays WHERE run_id = ?", (run_id,))
            return cur.rowcount or 0
    finally:
        con.close()


#: ``ev_probes`` columns in insert order; omitted -> NULL, extra -> ignored (caller is not trusted)
_EV_PROBE_COLS = (
    "finding_key", "finding_title", "file", "line_start", "line_end", "cwe", "vuln_class",
    "ev_class", "ev_subtype", "ev_verdict", "endpoint_method", "endpoint_path",
    "payload_label", "injection_point", "req_method", "req_url", "req_query", "req_body",
    "authed", "auth_applied", "resp_status", "resp_ms", "resp_snippet")


def save_ev_probes(run_id: str, rows: list[dict]) -> int:
    """Replace this run's exploit-verification probe log with ``rows``."""
    # Replaces the set: call ONLY when EV ran; router._probe_rows redacts, auth_applied has no token
    cols = ", ".join(_EV_PROBE_COLS)
    ph = ", ".join("?" for _ in _EV_PROBE_COLS)
    con = connect()
    written = 0
    try:
        with con:
            con.execute("INSERT OR IGNORE INTO runs(run_id, repo_root) VALUES (?, '')",
                        (run_id,))
            con.execute("UPDATE runs SET updated_at = datetime('now') WHERE run_id = ?",
                        (run_id,))
            con.execute("DELETE FROM ev_probes WHERE run_id = ?", (run_id,))
            for r in rows:
                con.execute(
                    f"INSERT INTO ev_probes(run_id, {cols}) VALUES (?, {ph})",
                    (run_id, *(r.get(c) for c in _EV_PROBE_COLS)))
                written += 1
    finally:
        con.close()
    return written


def load_ev_probes(run_id: str) -> list[dict]:
    """Every stored probe for ``run_id`` as column dicts, in insertion order."""
    con = connect()
    try:
        con.row_factory = sqlite3.Row
        cur = con.execute(
            f"SELECT id, run_id, {', '.join(_EV_PROBE_COLS)}, created_at "
            f"FROM ev_probes WHERE run_id = ? ORDER BY id", (run_id,))
        return [dict(row) for row in cur.fetchall()]
    finally:
        con.close()
