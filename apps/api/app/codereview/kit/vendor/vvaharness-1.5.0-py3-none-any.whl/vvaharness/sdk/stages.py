# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The per-stage map: which DTO each stage produces, and what you can customise there."""
from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from vvaharness.models import (
    ContextPackage,
    FinalReport,
    Finding,
    SeedPackage,
    TaskManifest,
    ThreatModel,
)


class Phase(StrEnum):
    """The four phases a scan moves through; each tells a different story about the target."""

    DISCOVER = "discover"
    ANALYZE = "analyze"
    VERIFY = "verify"
    REMEDIATE = "remediate"


class Seam(StrEnum):
    """What a plugin can customise at a stage."""

    ENRICH_GRAPH = "enrich-graph"
    SWAP_GRAPH = "swap-graph"
    BRING_DTO = "bring-dto"
    ADD_TOOLS = "add-tools"
    ADD_SUBAGENTS = "add-subagents"


@dataclass(frozen=True)
class Stage:
    """One stage: its phase, the DTO it produces, and the seams open at it."""

    id: str
    phase: Phase
    name: str
    dto: type | None
    payload: str
    agentic: bool = False
    injectable: bool = False
    seams: tuple[Seam, ...] = ()
    caveat: str = ""


#: Ordered as a scan runs them. `payload` is the exact checkpoint envelope `--resume` reads, which
#: is why it is spelled out rather than implied by `dto`: four stages wrap their DTO in a dict.
STAGES: tuple[Stage, ...] = (
    Stage("s0", Phase.DISCOVER, "Seed", SeedPackage, "SeedPackage",
          seams=(Seam.ENRICH_GRAPH, Seam.SWAP_GRAPH),
          caveat="the graph is built here, so this is the only place an enricher runs"),
    Stage("s1", Phase.DISCOVER, "Precompute", ContextPackage, "ContextPackage",
          injectable=True, seams=(Seam.BRING_DTO,),
          caveat="ContextPackage.graph_handle is exclude=True, so an injected one has no graph "
                 "and S2/S4/S6 warn then stand down"),
    Stage("s2", Phase.ANALYZE, "Threat model", ThreatModel, "ThreatModel",
          agentic=True, injectable=True,
          seams=(Seam.BRING_DTO, Seam.ADD_TOOLS, Seam.ADD_SUBAGENTS)),
    Stage("s3", Phase.ANALYZE, "Decompose", TaskManifest, "TaskManifest",
          injectable=True, seams=(Seam.BRING_DTO,),
          caveat="deterministic: one InvestigationUnit per threat, zero model calls"),
    Stage("s4", Phase.ANALYZE, "Deep dive", Finding,
          '{"findings": list[Finding], "outcomes": dict[str, str]}',
          agentic=True, injectable=True,
          seams=(Seam.BRING_DTO, Seam.ADD_TOOLS, Seam.ADD_SUBAGENTS),
          caveat="seed this to run S5 onward on findings you already have"),
    Stage("s5", Phase.VERIFY, "Prefilter", Finding,
          '{"findings": list[Finding], "pre_dropped": list[Finding]}',
          injectable=True, seams=(Seam.BRING_DTO,)),
    Stage("s6", Phase.VERIFY, "Verify", Finding,
          '{"verified": list[Finding], "dropped": list[Finding]}',
          agentic=True, seams=(Seam.ADD_TOOLS, Seam.ADD_SUBAGENTS)),
    Stage("s7", Phase.VERIFY, "Dedupe", Finding,
          "(pre_dropped, verified, dropped, canonical, dup_dropped, s5_out_count)",
          caveat="a 6-tuple, not a dict; the only stage whose envelope is positional"),
    Stage("s8", Phase.VERIFY, "Report", FinalReport, "FinalReport"),
    Stage("s9", Phase.VERIFY, "SARIF", None, "str (path to the written sarif)"),
    Stage("s10", Phase.REMEDIATE, "Remediate", None, "not checkpointed by scan_repo",
          agentic=True, seams=(Seam.ADD_TOOLS, Seam.ADD_SUBAGENTS),
          caveat="reachable as vvaharness.sdk.remediate(finding, repo=...)"),
    Stage("s11", Phase.REMEDIATE, "Validate", None, "not checkpointed by scan_repo",
          agentic=True, caveat="reachable as vvaharness.sdk.validate(finding, remediation, ...)"),
)

_BY_ID: dict[str, Stage] = {s.id: s for s in STAGES}

#: Stage ids whose checkpoint `scan_repo` writes, so a seeded one makes `--resume` skip the stage.
CHECKPOINTED: tuple[str, ...] = tuple(s.id for s in STAGES
                                      if not s.payload.startswith("not checkpointed"))


def stage(stage_id: str) -> Stage:
    """One stage by id, or a KeyError naming every id there is."""
    try:
        return _BY_ID[stage_id]
    except KeyError:
        raise KeyError(f"no stage {stage_id!r}; known: {sorted(_BY_ID)}") from None


def stages_in(phase: Phase | str) -> tuple[Stage, ...]:
    """Every stage of *phase*, in run order."""
    wanted = Phase(phase)
    return tuple(s for s in STAGES if s.phase is wanted)


def stages_with(seam: Seam | str) -> tuple[Stage, ...]:
    """Every stage where *seam* is open, in run order."""
    wanted = Seam(seam)
    return tuple(s for s in STAGES if wanted in s.seams)


def injectable_stages() -> tuple[Stage, ...]:
    """Every stage whose DTO you can supply yourself instead of having vvaharness compute it."""
    return tuple(s for s in STAGES if s.injectable)


__all__ = [
    "CHECKPOINTED",
    "STAGES",
    "Phase",
    "Seam",
    "Stage",
    "injectable_stages",
    "stage",
    "stages_in",
    "stages_with",
]
