# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The deterministic repo walk, its exclusions, and config dedup."""
from __future__ import annotations

from vvaharness.scope.configs import (
    _dedup_configs,
    _flatten_keys,
    _rep_score,
    _shape_hash,
    _suspicious_set,
)
from vvaharness.scope.walk import (
    _DEDUP_DEFAULTS,
    _DEFAULT_EXCLUDE_DIRS,
    _DEFAULT_EXCLUDE_EXTS,
    _DEFAULT_EXCLUDE_GLOBS,
    _INSECURE_RX,
    _SECRET_RX,
    EmptyScopeError,
    _exclusion_sets,
    _has_target_build_marker,
    _norm_rel,
    _resolve_scope_path,
    _walk_repo,
    glob_hit,
    resolve_inventory_path,
    scope_after,
)

__all__ = [
    "_DEDUP_DEFAULTS",
    "_DEFAULT_EXCLUDE_DIRS",
    "_DEFAULT_EXCLUDE_EXTS",
    "_DEFAULT_EXCLUDE_GLOBS",
    "_INSECURE_RX",
    "_SECRET_RX",
    "EmptyScopeError",
    "_dedup_configs",
    "_exclusion_sets",
    "_flatten_keys",
    "_has_target_build_marker",
    "_norm_rel",
    "_rep_score",
    "_resolve_scope_path",
    "_shape_hash",
    "_suspicious_set",
    "_walk_repo",
    "glob_hit",
    "resolve_inventory_path",
    "scope_after",
]
