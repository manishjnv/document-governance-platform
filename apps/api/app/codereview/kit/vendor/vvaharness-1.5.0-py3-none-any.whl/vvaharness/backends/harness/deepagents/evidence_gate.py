# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Reject a session's structured verdict until every todo on its plan is completed."""

from __future__ import annotations

import threading
from collections.abc import Awaitable, Callable
from typing import Any

from langchain.agents.middleware.types import (
    AgentMiddleware,
    ModelRequest,
    ModelResponse,
    ToolCallRequest,
)
from langchain_core.messages import HumanMessage, ToolMessage
from langgraph.types import Command

from vvaharness.util.counters import COUNTERS
from vvaharness.util.warn_once import stage_label, warn_once

_DONE = frozenset({"completed"})

_WARNED_RELENTED: set[str] = set()


def _relent_warning(counter: str, max_rejections: int, required: frozenset[str]) -> str:
    """The once-per-(stage family, run) WARN line for the first relent on *counter*."""
    reason = f"missing {', '.join(sorted(required))}" if required else "an unfinished plan"
    return (
        f"WARN {stage_label(counter)}: the evidence gate rejected a verdict "
        f"{max_rejections} time(s) for {reason}, then relented -- this stage's output "
        f"shipped without that evidence. Count in {counter}_relented. Raise this stage's "
        "rejection limit in the scan config, or review this run's output by hand."
    )


def _todos(state: object) -> list[dict[str, Any]]:
    """The live todo list from agent state, or [] when planning is not in play."""
    try:
        raw = state.get("todos") if hasattr(state, "get") else getattr(state, "todos", None)
    except (AttributeError, TypeError):
        return []
    return [t for t in (raw or []) if isinstance(t, dict)]


def _outstanding(todos: list[dict[str, Any]]) -> list[str]:
    """Contents of every todo not yet completed, in order."""
    return [str(t.get("content", "?")) for t in todos if t.get("status") not in _DONE]


def _nudge(outstanding: list[str]) -> HumanMessage:
    """The turn handed back to the model in place of its premature verdict."""
    listed = "\n".join(f"  - {c}" for c in outstanding)
    return HumanMessage(content=(
        f"HOLD. You tried to report a verdict, but {len(outstanding)} todo(s) on your own plan "
        f"are not completed:\n{listed}\n\n"
        "That verdict is rejected and has not been recorded. Do the outstanding work now — read "
        "the code each todo names (to the END of the file; continue any paginated Read), load the "
        "skill it calls for, grep for the sibling sites, enumerate the places a missing control "
        "belongs. Then mark each todo completed with `write_todos` and report.\n\n"
        "If a todo genuinely does not apply, mark it completed and say why in your rationale. Do "
        "not resend the same verdict without new evidence."
    ))


class EvidenceGate(AgentMiddleware):
    """Reject a structured verdict while any todo is still outstanding."""

    def __init__(self, *, max_rejections: int = 3,
                 counter: str = "evidence_gate_rejected",
                 required_tools: frozenset[str] = frozenset(),
                 require_tool_call: bool = False,
                 ignored_tools: frozenset[str] = frozenset()) -> None:
        """Reject premature verdicts up to *max_rejections* times, then relent."""
        super().__init__()
        self._max = max_rejections
        self._counter = counter
        self._required = required_tools
        self._require_tool_call = require_tool_call
        self._ignored = ignored_tools
        self._called: set[str] = set()
        self._rejected = 0
        self._lock = threading.Lock()

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage | Command[Any]],
    ) -> ToolMessage | Command[Any]:
        """Record which required tools the session has used, then execute."""
        self._called.add(request.tool_call["name"])
        return handler(request)

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command[Any]]],
    ) -> ToolMessage | Command[Any]:
        """Async counterpart of :meth:`wrap_tool_call`."""
        self._called.add(request.tool_call["name"])
        return await handler(request)

    @property
    def name(self) -> str:
        """Per-instance name; langchain asserts middleware names are unique per agent."""
        return f"{self.__class__.__name__}[{self._counter}]"

    @property
    def required_tools(self) -> frozenset[str]:
        """The tools a verdict must be backed by, readable by a non-langchain backend."""
        # For sdk/openai/cli, which lack wrap_model_call; after max_rejections it relents to WARN
        return self._required

    def _claim(self) -> bool:
        """Record a rejection, returning whether the gate may still reject."""
        with self._lock:
            if self._rejected >= self._max:
                return False
            self._rejected += 1
            return True

    def note_call(self, name: str) -> None:
        """Record a tool call made OUT OF LOOP, on a route with no ``wrap_tool_call`` seam."""
        # The adapter MUST feed this, or hold_for_verdict refuses every sdk/openai/cli submit
        with self._lock:
            self._called.add(name)

    def hold_for_verdict(self) -> str | None:
        """The OUT-OF-LOOP form of the verdict rejection, mirroring ``ToolCallBudget.refusal_for``."""
        if not self._required or (self._required & self._called):
            return None
        if not self._claim():
            COUNTERS.bump(f"{self._counter}_relented")
            warn_once(_WARNED_RELENTED, self._counter,
                      _relent_warning(self._counter, self._max, self._required))
            return None
        COUNTERS.bump(self._counter)
        return (
            "Rejected: you have not called any of "
            + ", ".join(sorted(self._required))
            + " to establish reachability from the call graph before submitting this "
            "verdict. Call one now: GraphImporters(file) for who imports a file, "
            "GraphNeighbors(file, function) for its callers and callees, "
            "GraphCommunityOf(file) for its module, GraphSinksInCommunity(community) for "
            "the other sinks near it. These are deterministic and answer in one call what "
            "a file sweep answers badly. Call one, then resend your verdict with that "
            "evidence."
        )

    def _tool_call_items(self) -> list[str]:
        """One outstanding item when require_tool_call is unmet, else none."""
        if self._require_tool_call and not (self._called - self._ignored):
            return ["read the code with a tool before you report"]
        return []

    def _premature(self, request: ModelRequest, response: ModelResponse) -> list[str]:
        """Outstanding todos when *response* carries a verdict prematurely, else []."""
        if getattr(response, "structured_response", None) is None:
            return []
        outstanding = _outstanding(_todos(request.state))
        if self._required and not (self._required & self._called):
            outstanding = [*outstanding, (
                "establish reachability from the call graph — you have not called any of "
                + ", ".join(sorted(self._required))
                + ". Call one now: GraphImporters(file) for who imports a file, "
                "GraphNeighbors(file, function) for its callers and callees, "
                "GraphCommunityOf(file) for its module, GraphSinksInCommunity(community) for "
                "the other sinks near it. These are deterministic and answer in one call what "
                "a file sweep answers badly"
            )]
        outstanding = [*outstanding, *self._tool_call_items()]
        if not outstanding:
            return []
        if not self._claim():
            COUNTERS.bump(f"{self._counter}_relented")
            warn_once(_WARNED_RELENTED, self._counter,
                      _relent_warning(self._counter, self._max, self._required))
            return []
        COUNTERS.bump(self._counter)
        return outstanding

    def _retry_request(self, request: ModelRequest, outstanding: list[str]) -> ModelRequest:
        """*request* with the hold message appended."""
        # Rejected reply deliberately dropped: Anthropic 400s on a tool_use with no tool_result
        return request.override(messages=[*request.messages, _nudge(outstanding)])

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        """Call the model, re-asking while it reports a verdict on an unworked plan."""
        response = handler(request)
        while (outstanding := self._premature(request, response)):
            request = self._retry_request(request, outstanding)
            response = handler(request)
        return response

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelResponse:
        """Async counterpart of :meth:`wrap_model_call`."""
        response = await handler(request)
        while (outstanding := self._premature(request, response)):
            request = self._retry_request(request, outstanding)
            response = await handler(request)
        return response


__all__ = ["EvidenceGate"]
