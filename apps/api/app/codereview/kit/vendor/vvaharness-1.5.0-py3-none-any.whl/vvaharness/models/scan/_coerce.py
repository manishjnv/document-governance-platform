# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Lenient coercion helpers for model validators."""
from __future__ import annotations

import logging

log = logging.getLogger(__name__)

def _norm(v) -> str:
    return str(v or "").strip().lower().replace("-", "_").replace(" ", "_")


def _coerce_enum(v, valid: set[str], alias: dict[str, str], default: str) -> str:
    raw = str(v or "").strip()
    if raw in valid:                       # exact (case-preserving) hit
        return raw
    k = _norm(v)
    if k in valid:
        return k
    return alias.get(k, default)


def _coerce_int(v, default: int = 0) -> int:
    if isinstance(v, bool):                # bool ⊂ int in Python; reject
        return default
    if isinstance(v, int):
        return v
    if isinstance(v, float):
        # int(nan) raises ValueError and int(inf) raises OverflowError.
        if v != v or v in (float("inf"), float("-inf")):  # noqa: PLR0124 -- idiomatic NaN check
            return default
        return int(v)
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return default


def flag(v: object) -> bool:
    """Coerce a model-emitted flag to a bool, falling back to False rather than raising."""
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        return v.strip().lower() in {"true", "yes", "1"}
    if isinstance(v, (int, float)):
        return bool(v)
    return False


def text(v: object) -> str:
    """Coerce any value to a str, mapping None to the empty string."""
    return v if isinstance(v, str) else ("" if v is None else str(v))


def _coerce_scalar_str(v, default, label: str):
    """Normalise an off-schema scalar-string LLM field; unrecognised shapes pass to Pydantic."""
    if isinstance(v, str):
        return v
    # Tail list elements are lost, including their file<->threat association.
    if isinstance(v, (list, tuple)):
        first = next((x for x in v if x not in (None, "")), None)
        log.warning("LLM output coercion: %s was a %d-element list; "
                    "keeping the first element %r", label, len(v), first)
        return _coerce_scalar_str(first, default, label)
    if v is None:
        if default is None:
            return None                       # valid for Optional fields
        log.warning("LLM output coercion: %s was null; using default %r",
                    label, default)
        return default
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        log.warning("LLM output coercion: %s was a bare %s (%r); using its "
                    "string form", label, type(v).__name__, v)
        return str(v)
    return v                                  # unrecognisable — let Pydantic reject


def _coerce_str_list(v, label: str):
    """Normalise an off-schema list-of-strings LLM field; unrecognised shapes pass to Pydantic."""
    if isinstance(v, list):
        return v
    if v is None:
        log.warning("LLM output coercion: %s was null; using an empty list",
                    label)
        return []
    if isinstance(v, tuple):
        return list(v)
    if isinstance(v, (str, int, float)) and not isinstance(v, bool):
        log.warning("LLM output coercion: %s was a bare %s; wrapping it in "
                    "a list", label, type(v).__name__)
        s = str(v).strip()
        return [s] if s else []
    return v                                  # unrecognisable — let Pydantic reject
