# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Breadth-before-depth group selection, shared by manifest and config-rep discovery."""
from __future__ import annotations

from collections.abc import Sequence
from itertools import zip_longest
from typing import TypeVar

_T = TypeVar("_T")


def _round_robin_select(groups: dict[str, list[_T]], max_total: int,
                        keys: Sequence[str] | None = None) -> list[tuple[str, _T]]:
    """One item per group per round, in `keys` order (default: dict order), up to `max_total`."""
    ordered_keys = list(keys) if keys is not None else list(groups)
    rows = zip_longest(*(groups[k] for k in ordered_keys))
    selected: list[tuple[str, _T]] = []
    for row in rows:
        pairs = zip(ordered_keys, row, strict=True)
        selected.extend((k, item) for k, item in pairs if item is not None)
        if len(selected) >= max_total:
            break
    return selected[:max_total]
