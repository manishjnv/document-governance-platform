# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 7 — decide what counts as ONE finding: collapse duplicates into canonicals."""
from __future__ import annotations

from vvaharness.pipeline.stages.s7.collapse import (
    STRICT_CWE_CLASS,
    TRIVIAL_REASON,
    attach_duplicates,
    collapse_trivial,
    cwe_conflict,
    dedup_locations,
    dup_location,
)
from vvaharness.pipeline.stages.s7.outcomes import (
    DedupDecision,
    DedupDecisions,
    parse_decisions,
)
from vvaharness.pipeline.stages.s7.prompts import SYSTEM, build_payload
from vvaharness.pipeline.stages.s7.session import (
    MIN_RESPONSE_CHARS,
    MIN_RESPONSE_TOKENS,
    semantic_dedup,
)

__all__ = [
    "MIN_RESPONSE_CHARS", "MIN_RESPONSE_TOKENS", "STRICT_CWE_CLASS", "SYSTEM",
    "TRIVIAL_REASON", "DedupDecision", "DedupDecisions", "attach_duplicates",
    "build_payload", "collapse_trivial", "cwe_conflict", "dedup_locations",
    "title_overlap",
    "dup_location", "parse_decisions", "semantic_dedup",
]
