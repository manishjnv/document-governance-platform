# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Data contracts passed between pipeline steps; no raw dicts cross step boundaries."""

from vvaharness.models.case import Attempt, FindingCase
from vvaharness.models.context import ScoringPolicy
from vvaharness.models.derive import merge_readiness_for, state_of, verdict_state
from vvaharness.models.gates import EvidenceAnchor, GateAssessment
from vvaharness.models.provenance import (
    HARNESS_REGISTRY,
    LLM_REGISTRY,
    Provenance,
)
from vvaharness.models.remediation import (
    FileChange,
    Remediation,
    RemediationEvidence,
    finalize,
)
from vvaharness.models.scan import (
    _MD_INVISIBLE_RX,
    _MD_LINEBREAK_RX,
    CVE,
    OFFENSIVE_LABELS,
    AppProfile,
    Asset,
    Chain,
    ContextPackage,
    Control,
    DroppedFinding,
    DupLocation,
    EntryPoint,
    FinalReport,
    Finding,
    InvestigationUnit,
    LinkEvidence,
    ModuleInfo,
    RankedFinding,
    ScanMetrics,
    ScopeEntry,
    SeedPackage,
    Severity,
    Sink,
    TaskManifest,
    Threat,
    ThreatModel,
    TrustBoundary,
    UnitSize,
    VulnClass,
    _cap_assets,
    _cap_boundaries,
    _cap_threats,
    _demote_md_headings,
    _md_cell,
    _snippet_fence,
    _vector_span,
)
from vvaharness.models.verdict import Ticket, Verdict
from vvaharness.models.vocab import (
    CANONICAL_GATE_NAMES,
    EVIDENCE_GATES,
    FIX_VALIDATION_GATES,
    CaseState,
    Decision,
    Disposition,
    GateStatus,
    MergeReadiness,
    RemediationKind,
    RemediationOutcome,
    normalise_gate_name,
)

__all__ = [
    "CANONICAL_GATE_NAMES",
    "CVE",
    "EVIDENCE_GATES",
    "FIX_VALIDATION_GATES",
    "HARNESS_REGISTRY",
    "LLM_REGISTRY",
    "OFFENSIVE_LABELS",
    "AppProfile",
    "Asset",
    "Attempt",
    "CaseState",
    "Chain",
    "ContextPackage",
    "Control",
    "Decision",
    "Disposition",
    "DroppedFinding",
    "DupLocation",
    "EntryPoint",
    "EvidenceAnchor",
    "FileChange",
    "FinalReport",
    "Finding",
    "FindingCase",
    "GateAssessment",
    "GateStatus",
    "InvestigationUnit",
    "LinkEvidence",
    "MergeReadiness",
    "ModuleInfo",
    "Provenance",
    "RankedFinding",
    "Remediation",
    "RemediationEvidence",
    "RemediationKind",
    "RemediationOutcome",
    "ScanMetrics",
    "ScopeEntry",
    "ScoringPolicy",
    "SeedPackage",
    "Severity",
    "Sink",
    "TaskManifest",
    "Threat",
    "ThreatModel",
    "Ticket",
    "TrustBoundary",
    "UnitSize",
    "Verdict",
    "VulnClass",
    "finalize",
    "merge_readiness_for",
    "normalise_gate_name",
    "state_of",
    "verdict_state",
]
