# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Step 5 — enrich s4's findings for s6, and refuse only coordinates that do not exist."""
from __future__ import annotations

from vvaharness.models import ContextPackage, DroppedFinding, Finding
from vvaharness.pipeline.callgraph_consumer import (
    entry_anchor_lines,
    seed_paths_by_file,
)
from vvaharness.pipeline.stages import s7_dedup
from vvaharness.pipeline.stages.s5 import detectors, reanchor
from vvaharness.pipeline.stages.s5.enrich import FileCache, enrich
from vvaharness.pipeline.stages.s5.gates import reject, reject_path
from vvaharness.util import console, logs
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS

log = logs.get_logger(__name__)


def _dropped(f: Finding, reason: str, detail: str) -> DroppedFinding:
    """One audit-trail entry, so a removal is never silent."""
    return DroppedFinding(file=f.file, line=f.line_start, vuln_class=f.vuln_class,
                          title=f.title, chunk_id=f.chunk_id, reason=reason, detail=detail)


def _line_tolerance(cfg) -> int:
    """s5's trivial-dedup window, falling back to s7's shared key."""
    s5 = getattr(cfg, "step5_prefilter", None)
    s7 = getattr(cfg, "step7_dedup", None)
    # A profile's 0 (exact-line matching) is a real value, so test None, not falsiness.
    tol = getattr(s5, "line_tolerance", None)
    if tol is None:
        tol = getattr(s7, "line_tolerance", 3)
    return int(tol)


def _breakdown(dropped: list[DroppedFinding]) -> str:
    """Drop reasons as one countable line for the operator."""
    by: dict[str, int] = {}
    for d in dropped:
        by[d.reason] = by.get(d.reason, 0) + 1
    return ", ".join(f"{n} {k.lower()}" for k, n in sorted(by.items()))


def run(findings: list[Finding], ctx: ContextPackage, cfg
        ) -> tuple[list[Finding], list[DroppedFinding]]:
    """Enrich every finding, drop those whose coordinates do not exist, dedupe the rest."""
    log.info("s5/enrich: starting - findings=%d", len(findings))
    cache = FileCache(ctx.repo_root, max_kb=int(knob(cfg, "step1.max_file_kb", 1024)))
    valid_files = set(ctx.all_files) if ctx.all_files else None
    anchors = entry_anchor_lines(ctx)
    seeds = seed_paths_by_file(ctx.seed_taint_paths)
    tol = _line_tolerance(cfg)

    reanchorer = None
    if knob(cfg, "step5_prefilter.sink_reanchor", True):
        reanchorer = reanchor.Reanchorer(
            cache, reanchor.sink_patterns_by_cwe(),
            int(knob(cfg, "step5_prefilter.sink_reanchor_max_move_lines", 40)))

    keep: list[Finding] = []
    # Dedup judges proximity on s4's PRE-reanchor line, so re-anchoring cannot collapse two sinks
    pre_anchor: list[int] = []
    dropped: list[DroppedFinding] = []
    for raw in findings:
        # Path gate first: enrich/reanchor read disk, so an out-of-inventory path must do no I/O
        f = raw
        verdict = reject_path(raw, valid_files)
        if verdict is None:
            f = enrich(raw, cache, anchors, seeds, reanchorer)
            verdict = reject(f, valid_files, cache.lines(f.file))
        if verdict is None:
            f.pre_anchor_line = int(raw.line_start)
            keep.append(f)
            pre_anchor.append(int(raw.line_start))
            continue
        reason, detail = verdict
        # "test/mock/example path" must not mint a slashed counter key.
        COUNTERS.bump(f"s5_dropped_{detail.split()[0].lower().replace('/', '_')}")
        dropped.append(_dropped(f, reason, detail))

    keep, dup_dropped = s7_dedup.prefilter(keep, tol, pre_anchor)
    dropped.extend(dup_dropped)

    # After reanchor+prefilter: the detectors' dedup-against-kept needs post-reanchor coordinates
    n_det = 0
    if knob(cfg, "step5_detectors.enabled", True):
        max_rows = int(knob(cfg, "step5_detectors.max_rows", 200))
        for row in detectors.run(keep, ctx, cache, tol, max_rows):
            # No reanchorer: a detector row already sits on the statement its rule matched.
            f = enrich(row, cache, anchors, seeds)
            verdict = reject(f, valid_files, cache.lines(f.file))
            if verdict is None:
                keep.append(f)
                n_det += 1
                continue
            COUNTERS.bump("s5_det_rejected")
            dropped.append(_dropped(f, *verdict))

    tail = f" ({_breakdown(dropped)})" if dropped else " (nothing dropped)"
    det_sfx = f" +{n_det} detector" if n_det else ""
    console.write(f"  [s5-enrich] {len(findings)} → {len(keep)}{det_sfx}{tail}")
    log.info("s5/enrich: complete - input=%d output=%d dropped=%d detector=%d",
             len(findings), len(keep), len(dropped), n_det)
    return keep, dropped
