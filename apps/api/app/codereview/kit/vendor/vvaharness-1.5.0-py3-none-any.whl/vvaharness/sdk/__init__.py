# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The vvaharness SDK: run a scan, remediate a finding, or extend the pipeline."""
from vvaharness.api import (
    MergeReadiness,
    Remediation,
    ScoringPolicy,
    Verdict,
    merge_readiness_for,
    remediate,
    state_of,
    validate,
)
from vvaharness.models import (
    ContextPackage,
    FinalReport,
    Finding,
    InvestigationUnit,
    SeedPackage,
    TaskManifest,
    ThreatModel,
)
from vvaharness.sdk.handoff import (
    DISCOVERY_STAGES,
    MAX_INJECTED_FINDINGS,
    Handoff,
    HandoffError,
    inject_findings,
)
from vvaharness.sdk.plugins import (
    MAX_PLUGIN_GRAPH_TOOLS,
    MAX_PLUGINS,
    Contribution,
    GraphEnricher,
    PluginInfo,
    PluginSet,
    VvahPlugin,
)
from vvaharness.sdk.runner import (
    ScanOptions,
    ScanOptionsError,
    ScanResult,
    profile_path,
    scan,
)
from vvaharness.sdk.stages import (
    CHECKPOINTED,
    STAGES,
    Phase,
    Seam,
    Stage,
    injectable_stages,
    stage,
    stages_in,
    stages_with,
)

__all__ = [
    "CHECKPOINTED",
    "DISCOVERY_STAGES",
    "MAX_INJECTED_FINDINGS",
    "MAX_PLUGINS",
    "MAX_PLUGIN_GRAPH_TOOLS",
    "STAGES",
    "ContextPackage",
    "Contribution",
    "FinalReport",
    "Finding",
    "GraphEnricher",
    "Handoff",
    "HandoffError",
    "InvestigationUnit",
    "MergeReadiness",
    "Phase",
    "PluginInfo",
    "PluginSet",
    "Remediation",
    "ScanOptions",
    "ScanOptionsError",
    "ScanResult",
    "ScoringPolicy",
    "Seam",
    "SeedPackage",
    "Stage",
    "TaskManifest",
    "ThreatModel",
    "Verdict",
    "VvahPlugin",
    "inject_findings",
    "injectable_stages",
    "merge_readiness_for",
    "profile_path",
    "remediate",
    "scan",
    "stage",
    "stages_in",
    "stages_with",
    "state_of",
    "validate",
]
