# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""One agentic verification session per batch of findings: tools, dispatch, reduction."""
from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from langchain.agents.middleware import AgentMiddleware

from vvaharness.backends.harness import ToolBuilder, compose_tool_builders
from vvaharness.backends.harness.deepagents.evidence_gate import EvidenceGate
from vvaharness.backends.harness.deepagents.model_call_budget import ModelCallBudget
from vvaharness.backends.harness.deepagents.tool_budget import ToolCallBudget
from vvaharness.backends.harness.models import CallTimeoutError
from vvaharness.backends.llm import cli
from vvaharness.backends.llm import deepagents as _deepagents
from vvaharness.backends.llm.models import RESPONSE_MODEL_VIAS
from vvaharness.backends.llm.registry import resolve
from vvaharness.codegraph.build import graph_is_degenerate
from vvaharness.codegraph.tools import (
    GRAPH_TOOL_NAMES,
    build_graph_tool_builder,
    graph_tool_names,
)
from vvaharness.evidence import _cap_int
from vvaharness.models import ContextPackage, Finding
from vvaharness.pipeline.stages.replay import (
    S6_REPLAY_INSTRUCTION,
    RecordTranscript,
    Transcript,
    deadline_bound,
    release_pinned_session,
    replay_prompt,
    resume_or_replay,
    run_with_deadline,
    session_id_for,
)
from vvaharness.pipeline.stages.s6.batching import ceiling_secs
from vvaharness.pipeline.stages.s6.outcomes import (
    VerificationOutcome,
    VerificationOutcomes,
    split_batch_reply,
)
from vvaharness.pipeline.stages.s6.prompts import (
    build_shared_context,
    build_system_prompt,
    build_verify_prompt,
    repair_prompt,
)
from vvaharness.util import console
from vvaharness.util import errlog as _errlog
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.response_quality import dispatch_or_retry_unforced, stage_floors
from vvaharness.util.warn_once import warn_once

#: The replay restates a transcript; it needs the smallest reasoning budget.
_REPLAY_EFFORT = "low"

_PRIMARY_MIN_CHARS = 40
_PRIMARY_MIN_TOKENS = 10

# The repair says "restate, do NOT reconsider", so a verdictless primary would fabricate one
_VERDICT_TOKENS = ("TRUE_POSITIVE", "FALSE_POSITIVE", "INCONCLUSIVE")


def _has_verdict_material(raw) -> bool:
    """Whether the primary reply committed to at least one verdict."""
    return isinstance(raw, str) and any(t in raw for t in _VERDICT_TOKENS)


#: Routes warned about once per process.
_WARNED_NO_GRAPH: set[str] = set()

#: Degenerate-graph stand-downs warned about once per process.
_WARNED_DEGENERATE_GRAPH: set[str] = set()


def _graph_enabled(cfg, s6) -> bool:
    """Whether this scan composes the read-only graph tools onto the verifier."""
    if not getattr(s6, "graph_tools", False):
        return False
    # Gate on the route too: naming tools the session cannot call invites fabricated tool output
    via = resolve(cfg.models.verify).via
    ok, reason = _deepagents.route_carries_tools(cfg, via)
    if not ok:
        warn_once(
            _WARNED_NO_GRAPH, via,
            f"WARN [s6]: step6_verify.graph_tools is on but {reason} — verifying "
            f"without the graph tools, and NOT telling the model about tools it "
            f"cannot call. Route models.verify via: deepagents, sdk or openai to "
            f"use them.")
    return ok


def _call_budget(s6, members: int) -> ModelCallBudget | None:
    """The session's model-call cap, or None when `step6_verify.max_model_calls` is <= 0."""
    limit = _cap_int(s6, "max_model_calls", 0)
    if limit <= 0:
        return None
    return ModelCallBudget(limit=limit + max(0, members - 1),
                           outcome_tools=frozenset({VerificationOutcomes.__name__,
                                                    VerificationOutcome.__name__}),
                           counter="s6_model_call_budget_final_turn")


def _per_item(base: int, members: int) -> int:
    """*base* as a PER-FINDING allowance, scaled up to cover the whole batch."""
    # Configured per finding, spent per SESSION: a flat cap starves a batch; members>=1 yields base
    return base * max(1, members)


def _tool_setup(ctx: ContextPackage, cfg, s6, members: int = 1
                ) -> tuple[ToolBuilder | None, tuple[str, ...],
                           tuple[AgentMiddleware, ...]]:
    """Compose the verifier's tool builder, fact-tool names and per-session middleware."""
    middleware: list[AgentMiddleware | None] = []
    builder: ToolBuilder | None = None
    names: tuple[str, ...] = ()
    if _graph_enabled(cfg, s6):
        builder = compose_tool_builders(build_graph_tool_builder(ctx))
        names = graph_tool_names()
        limit = _cap_int(s6, "graph_tool_budget", 4)  # matches the registered default
        if limit > 0:
            middleware.append(ToolCallBudget(frozenset(graph_tool_names()),
                                             limit=_per_item(limit, members),
                                             counter="s6_graph_tool_budget_exhausted"))
        if getattr(s6, "require_graph", False):
            # No TodoListMiddleware in s6, so an unsatisfiable requirement rejects EVERY verdict
            required_tools = frozenset(GRAPH_TOOL_NAMES)
            if graph_is_degenerate(ctx, cfg):
                warn_once(
                    _WARNED_DEGENERATE_GRAPH, "s6-require-graph",
                    "WARN [s6]: step6_verify.require_graph is on but the code "
                    "graph is absent or degenerate (zero edges, or fewer "
                    "nodes than step0.min_graph_nodes_for_gate) — standing "
                    "the graph-tool requirement down.")
                COUNTERS.bump("evidence_gate_stood_down_degenerate_graph")
                required_tools = frozenset()
            middleware.append(EvidenceGate(
                max_rejections=_per_item(_cap_int(s6, "evidence_gate_refusals", 3), members),
                counter="s6_evidence_gate_rejected",
                required_tools=required_tools,
            ))
    middleware.append(_call_budget(s6, members))
    return builder, names, tuple(m for m in middleware if m)


def _load_code(files: list[str], repo_root: Path, s6) -> str | None:
    """Whole-file text for the batch when `step6_verify.inline_source` is on, else None."""
    if not getattr(s6, "inline_source", False):
        return None
    from vvaharness.pipeline.stages.s4_deepdive import _load_files_full
    # stage="s6" keys the loader's redaction warn-once separately from s4's.
    return _load_files_full(files, repo_root, stage="s6")


_STRUCTURED_VIAS = RESPONSE_MODEL_VIAS


def _response_model(cfg) -> type[VerificationOutcomes] | None:
    """The structured-output model, on the routes that honour one."""
    return (VerificationOutcomes
            if resolve(cfg.models.verify).via in _STRUCTURED_VIAS else None)


def _effort(cfg) -> str | None:
    """`step6_verify.effort`, or None (unset: the backend default, today's behaviour)."""
    return knob(cfg, "step6_verify.effort", None) or None


@dataclass
class _Attempt:
    """One dispatch attempt's provenance: whether its verdicts came from the transcript replay."""

    replayed: bool = False


def _dispatch(items: list[tuple[str, Finding]], ctx: ContextPackage, cfg,
              tools: list[str], tag: str, *, drop_thinking: bool = False,
              attempt: _Attempt | None = None) -> str:
    """Run one verification session over *items*, replaying its transcript if the deadline bites."""
    # Per attempt: dispatch_or_retry_unforced may call this twice, and a resend must not inherit
    # the first attempt's replay provenance
    attempt = _Attempt() if attempt is None else attempt
    attempt.replayed = False
    s6 = cfg.step6_verify
    transcript = Transcript()
    deadline = int(knob(cfg, "step6_verify.batch_deadline", 0) or 0)
    session_id = session_id_for("s6", tag.replace(" ", "-"))
    try:
        return run_with_deadline(
            lambda: _agentic_leg(items, ctx, cfg, tools, tag, transcript,
                                 session_id=session_id, drop_thinking=drop_thinking),
            seconds=deadline, stage=tag, effort=_effort(cfg))
    except CallTimeoutError:
        console.write(f"  [s6-verify] {tag}: deadline {deadline}s hit — resuming the session "
                      f"for the verdicts")
        def _replay() -> str:
            attempt.replayed = True
            return _replay_leg(items, ctx, cfg, tag, transcript, s6)
        return resume_or_replay(
            session_id, _replay,
            model=cfg.models.verify, cfg=cfg, instruction=S6_REPLAY_INSTRUCTION,
            stage="s6", tag=tag,
            timeout=_cap_int(s6, "resume_timeout", 60))
    finally:
        release_pinned_session(session_id)


def _replay_leg(items: list[tuple[str, Finding]], ctx: ContextPackage, cfg, tag: str,
                transcript: Transcript, s6) -> str:
    """Re-ask for the verdicts with no tools, from the transcript the killed batch reached."""
    COUNTERS.bump("s6_deadline_replay")
    code = _load_code(list(dict.fromkeys(f.file for _, f in items)), Path(ctx.repo_root), s6)
    # Lowest effort here too: the verification reasoning is already in the transcript
    started = time.monotonic()
    out = _deepagents.dispatch_prompt(
        replay_prompt(transcript, build_verify_prompt(items, ctx, code),
                      instruction=S6_REPLAY_INSTRUCTION, stage="s6"),
        model=cfg.models.verify,
        cfg=cfg,
        cwd=str(ctx.repo_root),
        graph_name="s6-verify",
        tag=f"{tag} replay",
        max_tokens=int(knob(cfg, "step6_verify.replay_max_tokens", 12000)),
        timeout=int(knob(cfg, "step6_verify.replay_timeout", 60)),
        response_model=_response_model(cfg),
        effort=_REPLAY_EFFORT,
    )
    console.write(f"  [s6-verify] {tag}: replay returned in {time.monotonic() - started:.1f}s")
    return out


def _agentic_leg(items: list[tuple[str, Finding]], ctx: ContextPackage, cfg,
                 tools: list[str], tag: str, transcript: Transcript,
                 *, session_id: str, drop_thinking: bool = False) -> str:
    """The unbounded verification session that the batch deadline wraps."""
    s6 = cfg.step6_verify
    repo_root = Path(ctx.repo_root)
    files = list(dict.fromkeys(f.file for _, f in items))
    code = _load_code(files, repo_root, s6)
    tool_builder, fact_tools, middleware = _tool_setup(ctx, cfg, s6, len(items))
    middleware = (*middleware, RecordTranscript(transcript))
    with stage_floors(tag, min_chars=_PRIMARY_MIN_CHARS, min_tokens=_PRIMARY_MIN_TOKENS):
        return _deepagents.dispatch_agentic(
            build_verify_prompt(items, ctx, code),
            model=cfg.models.verify,
            cfg=cfg,
            cwd=str(repo_root),
            # Defaults mirror the registry; _graph_enabled is route-only, so require a real graph
            system_prompt=build_system_prompt(
                graph=(_graph_enabled(cfg, s6) and ctx.graph_handle is not None
                      and not graph_is_degenerate(ctx, cfg)),
                trait_stamps=bool(knob(cfg, "step6_verify.trait_stamps", True)),
                reframe=bool(knob(cfg, "step6_verify.reframe_enabled", False))),
            graph_name="s6-verify",
            tag=tag,
            allowed_tools=list(tools),
            tool_builder=tool_builder,
            fact_tools=fact_tools,
            response_model=_response_model(cfg),
            parent_middleware=middleware,
            cache_prefix=build_shared_context(ctx) or None,
            max_budget_usd=getattr(s6, "max_budget_usd", 10.0),
            max_turns=getattr(s6, "max_turns", None),
            # Primary only: the repair stays effort-less, since a dropped forced tool_choice
            # (memoised model or manual thinking) argues for it
            effort=None if drop_thinking else _effort(cfg),
            # knob() not getattr: a null overlay must give 32000, not None -> internal 16000
            max_output_tokens=int(knob(cfg, "step6_verify.max_tokens", 32000)),
            # Already the discard deadline; a disabled ceiling (<=0) must arrive as None, not 0
            timeout=deadline_bound(ceiling_secs(s6) or None,
                                   int(knob(cfg, "step6_verify.batch_deadline", 0) or 0),
                                   None if drop_thinking else _effort(cfg),
                                   via=resolve(cfg.models.verify).via),
            session_id=session_id,
        )


def verify_batch(items: list[tuple[str, Finding]], ctx: ContextPackage, cfg,
                 tools: list[str], *,
                 abandoned: Callable[[], bool] = lambda: False,
                 resend_refusal: bool = False
                 ) -> dict[str, VerificationOutcome]:
    """Verify one batch of (id, finding) pairs, returning the outcomes that parsed."""
    # s6_verify allows resend_refusal for a lone finding only; a refused multi-finding batch splits
    ids = [fid for fid, _ in items]
    tag = f"s6 verify[{len(items)}] {ids[0]}"
    effort = _effort(cfg)
    attempt = _Attempt()
    # effort can leave the tool unforced (via: deepagents drops forcing under thinking; a via: sdk
    # model may reject it) so prose can end the session, or clip at a budget the route could not
    # grow (a 64000 override; the shipped 32000 doubles first, so a still-clipped batch goes to
    # s6_verify's split as before); no retry without effort or if abandoned. The refusal resend is
    # also vetoed on abort: sdk/deepagents workers never poll cli.aborted()
    raw = dispatch_or_retry_unforced(
        lambda *, drop_thinking: _dispatch(items, ctx, cfg, tools, tag,
                                           drop_thinking=drop_thinking, attempt=attempt),
        tag, stage="s6",
        effort=_deepagents.droppable_effort(cfg.models.verify, effort, agentic=True),
        may_retry=lambda: effort is not None and not abandoned(),
        resend_refusal=resend_refusal,
        may_resend_refusal=lambda: not abandoned() and not cli.aborted())
    outcomes = split_batch_reply(raw, ids)
    if outcomes:
        return _stamped(outcomes, attempt.replayed)
    # The stage already discards this thread's result, so a repair call misattributes spend
    if abandoned():
        COUNTERS.bump("s6_outcome_repair_skipped_abandoned")
        return {}
    if not _has_verdict_material(raw):
        # recovered=True: this records the skipped repair, not the loss; members resolve downstream
        console.write(f"  [s6-verify] {tag}: primary reply had no verdict material; "
                      f"skipping the repair re-ask (it can only restate a verdict "
                      f"that was never reached)")
        _errlog.log("s6-verify", tag, "primary reply had no verdict material",
                    reason="s6_outcome_repair_skipped_no_verdict", recovered=True)
        COUNTERS.bump("s6_outcome_repair_skipped_no_verdict")
        return {}
    COUNTERS.bump("s6_outcome_repaired_attempt")
    # A differing tag means the global VVAH-E003 floors apply; one outcome is under 150 chars
    repair_tag = f"{tag} json-repair"
    with stage_floors(repair_tag, min_chars=_PRIMARY_MIN_CHARS,
                      min_tokens=_PRIMARY_MIN_TOKENS):
        repaired = _deepagents.dispatch_prompt(
            repair_prompt(raw, ids),
            model=cfg.models.verify,
            cfg=cfg,
            cwd=str(ctx.repo_root),
            graph_name="s6-verify",
            tag=repair_tag,
            # A repair re-emits the full outcome set, so a smaller budget makes it a truncation
            max_tokens=int(knob(cfg, "step6_verify.max_tokens", 32000)),
            response_model=_response_model(cfg),
        )
    outcomes = split_batch_reply(repaired, ids)
    if outcomes:
        COUNTERS.bump("s6_outcome_repaired_ok")
    # The repair restates the primary's raw reply, so it carries that reply's provenance
    return _stamped(outcomes, attempt.replayed)


def _stamped(outcomes: dict[str, VerificationOutcome],
             replayed: bool) -> dict[str, VerificationOutcome]:
    """*outcomes* with every replay flag set from the attempt, never from the model's reply."""
    for outcome in outcomes.values():
        outcome.replayed = replayed
    return outcomes
