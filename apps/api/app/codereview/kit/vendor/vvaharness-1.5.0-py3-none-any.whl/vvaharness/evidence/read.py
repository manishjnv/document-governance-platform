# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The containment-checked, length-capped chokepoint every on-disk read goes through."""
from __future__ import annotations

from pathlib import Path

from vvaharness.util import errlog as _errlog


def _contained(root: Path, p: Path) -> Path | None:
    """Resolve `p`; return it if inside `root`, else None (also covers a dangling symlink)."""
    try:
        rp = p.resolve(strict=True)
    except OSError:
        return None
    try:
        rroot = root.resolve(strict=True)
    except OSError:
        return None
    return rp if rp.is_relative_to(rroot) else None


def _cap_text(txt: str, cap_chars: int) -> str:
    if len(txt) > cap_chars:
        return txt[:cap_chars] + f"\n…(truncated, {len(txt)} chars total)"
    return txt


def _read_capped(root: Path, p: Path, cap_chars: int, *,
                 whole_or_nothing: bool = False) -> str:
    """Containment-check, read, cap `p`; `whole_or_nothing`: "" not a truncated prefix."""
    rp = _contained(root, p)
    if rp is None:
        # recovered=True: the containment refusal is policy working as designed, not a loss.
        _errlog.log("s2", "containment",
                    f"refused to read outside repo root: {p}",
                    reason="containment_refused", recovered=True)
        return ""
    try:
        txt = rp.read_text(encoding="utf-8", errors="replace")
    except Exception:
        txt = ""
    if whole_or_nothing and len(txt) > cap_chars:
        return ""
    return _cap_text(txt, cap_chars)
