# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 9 — emits the scan's SARIF document for the ingest hub and the IDE."""
from __future__ import annotations

from pathlib import Path

from vvaharness.models import FinalReport
from vvaharness.pipeline.stages.s9.typed_sarif import write_sarif
from vvaharness.report.appcontext import AppInfo


def run(report: FinalReport, sarif_path: Path, *,
        application_id: str | None = None,
        app_info: AppInfo | None = None, cfg=None) -> Path:
    """Writes *report*'s SARIF to *sarif_path* and returns the path written."""
    # Without cfg, step9.duplicate_result_guard and output.posture_channel are unreachable defaults
    return write_sarif(report, sarif_path, application_id, app_info, cfg=cfg)
