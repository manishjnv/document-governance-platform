# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""remediation_agent.report_augment.sarif — add remediation blocks to the SARIF copy."""
from __future__ import annotations

import json
from pathlib import Path

from vvaharness.pipeline.stages.s9.typed_sarif import (
    FINGERPRINT_KEY,
    record_result_block,
    result_fingerprint,
    result_identifies,
)
from vvaharness.remediation_agent.report_augment.dto import (
    CaseRecord,
    _finding_of,
    _remediation_block,
    _skipped_record,
)
from vvaharness.util import console


def _result_loc(sarif_result: dict) -> tuple[str, int]:
    """Return (uri, startLine) for a SARIF result, or ("", -1) when unavailable."""
    try:
        pl = sarif_result["locations"][0]["physicalLocation"]
        return pl["artifactLocation"]["uri"], int(pl["region"]["startLine"])
    except (KeyError, IndexError, TypeError, ValueError):
        return "", -1


def _match_by_loc(results: list[dict], file: str, line: int) -> dict | None:
    """Return the result whose physical location is exactly (file, line)."""
    for r in results:
        if _result_loc(r) == (file, line):
            return r
    return None


def _match_by_title(results: list[dict], title: str) -> dict | None:
    """Return the first result whose message text starts with *title*."""
    for r in results:
        if str(r.get("message", {}).get("text", "")).startswith(title):
            return r
    return None


# Under properties: SARIF 2.1.0 forbids extra result keys; aliases key S9-folded twins by case id
BLOCK_KEY = "remediation"
ALIAS_BLOCK_KEY = "remediationAliases"


def _case_id_of(record: CaseRecord) -> str:
    case = record.case
    if case is None:
        return ""
    return str(case.case_id or (case.finding.case_id if case.finding else "") or "")


def _match_sarif(results: list[dict], record: CaseRecord) -> dict | None:
    """Match a SARIF result to a case."""
    # Fingerprint wins (survives multi-CWE pileups); loc/title exclude foreign fingerprints
    finding = _finding_of(record)
    if finding is None:
        return None
    case_id = _case_id_of(record)
    if case_id:
        for r in results:
            if result_identifies(r, case_id):
                return r
    candidates = [r for r in results
                  if not case_id or not result_fingerprint(r)
                  or result_identifies(r, case_id)]
    by_loc = (_match_by_loc(candidates, finding.file, finding.line_start)
              if finding.file else None)
    if by_loc is not None:
        return by_loc
    title = finding.title.strip()
    return _match_by_title(candidates, title) if title else None


def _augment_sarif(path: Path, records: list[CaseRecord]) -> dict[int, CaseRecord]:
    """Add a ``properties.remediation`` block to every SARIF result, returning the 1-based ordinal -> matched-case map the Markdown augmenter reuses."""
    doc = json.loads(path.read_text(encoding="utf-8"))
    runs = doc.get("runs") or [{}]
    results = runs[0].get("results", []) if runs else []
    matched_ids: set[int] = set()
    ordinal_matches: dict[int, CaseRecord] = {}
    # A result claimed by two different records is unsafe for either — drop both.
    ordinal_collisions: set[int] = set()
    by_print = aliased = 0
    for record in records:
        match = _match_sarif(results, record)
        if match is None:
            continue
        for idx, r in enumerate(results):
            if r is match:
                ordinal = idx + 1
                prior = ordinal_matches.get(ordinal)
                if prior is not None and prior is not record:
                    ordinal_collisions.add(ordinal)
                else:
                    ordinal_matches[ordinal] = record
                break
        case_id = _case_id_of(record)
        if case_id and result_identifies(match, case_id):
            by_print += 1
        if not record_result_block(match, case_id, _remediation_block(record),
                                   key=BLOCK_KEY, alias_key=ALIAS_BLOCK_KEY):
            aliased += 1
            continue
        matched_ids.add(id(match))
    for ordinal in ordinal_collisions:
        ordinal_matches.pop(ordinal, None)
    console.write(f"  [s10] SARIF augment: matched {len(matched_ids)}/{len(records)} "
                  f"case(s), {by_print} by {FINGERPRINT_KEY}"
                  + (f", {aliased} recorded under {ALIAS_BLOCK_KEY}" if aliased else ""))
    # Unprocessed findings → explicit skipped block.
    skipped = _remediation_block(_skipped_record())
    for r in results:
        if id(r) not in matched_ids:
            r.setdefault("properties", {})[BLOCK_KEY] = dict(skipped)
    path.write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
    return ordinal_matches
