# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""S6's output contract: a verdict per finding that can also CORRECT it, plus the batch reducer."""
from __future__ import annotations

import math
import re
from collections.abc import Callable, Collection
from typing import Literal

from pydantic import BaseModel, Field, field_validator
from pydantic.json_schema import SkipJsonSchema

from vvaharness.models.scan.findings import Finding
from vvaharness.models.scan._coerce import flag as _coerce_bool
from vvaharness.pipeline.stages.s4.outcomes import InvestigatedFinding, fan_out
from vvaharness.report.cvss import rating as cvss_rating
from vvaharness.report.cvss import score as cvss_score
from vvaharness.rules.cwe import norm_cwe
from vvaharness.util.counters import COUNTERS
from vvaharness.util.json_extract import extract_json

# `"9/10"` / `"9 / 10"`: the prompt's own score notation echoed back.
_OUT_OF_TEN = re.compile(r"\s*([^/]*?)\s*/\s*10\s*")


class VerificationOutcome(BaseModel):
    finding_id: str = Field(description="Echo the FINDING id you were given, verbatim.")
    verdict: Literal["TRUE_POSITIVE", "FALSE_POSITIVE", "INCONCLUSIVE"] = Field(description=
        "TRUE_POSITIVE = the weakness is real and reachable. FALSE_POSITIVE = you read the code "
        "and it does not hold; name the control or fact that refutes it in `reason`. "
        "INCONCLUSIVE = you could not reach the evidence either way. Use it — it is recorded as "
        "undetermined and is the honest answer, where a guessed FALSE_POSITIVE silently deletes "
        "a finding nobody will look at again.")
    confidence: int = Field(ge=0, le=10, description=
        "0-10 on the evidence you actually saw. This is a hard gate: a TRUE_POSITIVE below the "
        "configured floor is dropped as unconfirmed, so do not deflate a finding you confirmed, "
        "and do not inflate one you did not.")

    @field_validator("confidence", mode="before")
    @classmethod
    def _clamp_confidence(cls, v: object) -> object:
        """Clamp a model-emitted score into 0-10 instead of failing the whole batch; a "N/10" string (the prompt's own scale) reads as N, any other fraction still fails."""
        m = _OUT_OF_TEN.fullmatch(v) if isinstance(v, str) else None
        try:
            f = float(m.group(1) if m else v)  # type: ignore[arg-type]
        except (TypeError, ValueError):
            return v
        except OverflowError:
            # float(10**400) overflows where float("1e999") reads inf: same saturation, by sign
            f = math.inf if isinstance(v, int) and v > 0 else -math.inf
        if not math.isfinite(f):
            # int(inf) raises OverflowError the except misses, so 1e999 drops the batch; NaN floors
            score = 10 if f > 0 else 0
        else:
            score = min(10, max(0, int(f)))
        if score != f:
            # Invisible downstream (stderr prints the stored value), so the rewrite is counted here
            COUNTERS.bump("s6_confidence_clamped")
        return score
    reason: str = Field(description="Why, in one or two sentences. Required for every verdict.")
    corrected_cwe: str = Field(default="", description=
        "Set this when the weakness is REAL but the reported CWE is wrong — the id your evidence "
        "actually supports, e.g. the finding says CWE-862 but the missing control is a CSRF token, "
        "so CWE-352. Use it with verdict TRUE_POSITIVE: the defect stands, only its label was off. "
        "Refuting a real weakness because its id was imprecise loses a finding for no reason. "
        "Leave empty when the reported CWE is right.")
    corrected_line_start: int = Field(default=0, description=
        "Set this when the weakness is REAL but reported at the wrong line — the line of the "
        "DANGEROUS STATEMENT ITSELF, never the enclosing def/class/decorator header. Use it "
        "with TRUE_POSITIVE. Leave 0 when the reported line already IS the sink.")
    confirmed_repeat_lines: list[int] = Field(default=[], description=
        "Lines in this same file where you verified the IDENTICAL defect and which are NOT already "
        "one of the findings in this session. The scanner has usually found the repeats it could "
        "see; you are reading the file properly, so this is for the site it missed. Each becomes "
        "its own confirmed finding reusing this one's description, so a site costs one integer. "
        "A line already listed above is ignored — say the ones nobody filed.")
    cvss_vector: str = Field(default="", description=
        "A CVSS 3.1 base vector, e.g. 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H'. Empty "
        "string if you cannot justify one — never invent metrics to fill it.")
    control_absence: bool = Field(default=False, description=
        "True when this finding describes a missing or absent control — a check, gate, limit or "
        "protection that is not there — rather than a value, privilege, or reachable state an "
        "attacker takes forward. 'No rate limiting on the login route' is an absent control "
        "(true); 'SQL injection returns the password hashes' hands the attacker data (false). "
        "When unsure, leave false.")
    channel: str = Field(default="main", description=
        "'posture' when the finding describes how the artifact is built or deployed — container, "
        "CI, or dependency hygiene — rather than a defect in the application's own code; "
        "otherwise 'main'. 'The container runs as root' is posture; 'the upload handler writes "
        "unsanitised filenames' is main. When unsure, leave 'main'.")
    reframed: bool = Field(default=False, description=
        "Set true ONLY when a reframe duty in the system prompt instructed you to: you refuted "
        "the finding's framing but confirmed the underlying exposure and relabelled it via "
        "corrected_cwe. Leave false otherwise.")

    @field_validator("control_absence", "reframed", mode="before")
    @classmethod
    def _coerce_flag(cls, v: object) -> bool:
        """Coerce a model-emitted flag to bool, falling back to False rather than failing the batch."""
        return _coerce_bool(v)

    @field_validator("channel", mode="before")
    @classmethod
    def _coerce_channel(cls, v: object) -> str:
        """Return 'posture' only for exactly that stamp, and the 'main' default for anything else."""
        return "posture" if (isinstance(v, str)
                             and v.strip().lower() == "posture") else "main"
    additional_findings: list[InvestigatedFinding] = Field(default=[], description=
        "DISTINCT weaknesses you noticed in this file while verifying, which the finding above "
        "does not cover. You already have the file open, so reporting one costs almost nothing and "
        "leaving it out means nobody looks at this code again. Same evidence bar as the verdict: "
        "report what you can point at, not what could conceivably be wrong. Empty is fine and "
        "common.")
    # Harness-only, hidden from the model schema; verify_batch overwrites what the model sent
    replayed: SkipJsonSchema[bool] = False


class VerificationOutcomes(BaseModel):
    outcomes: list[VerificationOutcome] = Field(description=
        "ONE entry per FINDING you were given, each echoing that finding's own id. A finding you "
        "omit is recorded as unverified, which drops it — so judge every one, including the ones "
        "you are refuting.")


def _validate_direct(raw: str) -> VerificationOutcomes | None:
    try:
        return VerificationOutcomes.model_validate_json(raw)
    except ValueError:
        return None


def _validate_salvaged(raw: str) -> VerificationOutcomes | None:
    try:
        return VerificationOutcomes.model_validate(extract_json(raw))
    except ValueError:
        return None


def _validate_lone(raw: str) -> VerificationOutcomes | None:
    try:
        return VerificationOutcomes(outcomes=[VerificationOutcome.model_validate_json(raw)])
    except ValueError:
        return None


def parse_outcomes(raw: str) -> VerificationOutcomes | None:
    """Parse a reply into outcomes, tolerating JSON-in-prose and a bare single outcome."""
    for attempt in (_validate_direct, _validate_salvaged, _validate_lone):
        parsed = attempt(raw)
        if parsed is not None:
            return parsed
    stripped = (raw or "").strip()
    COUNTERS.bump("s6_outcome_truncated" if stripped and not stripped.endswith("}")
                  else "s6_outcome_malformed")
    return None


def split_batch_reply(raw: str, finding_ids: list[str]) -> dict[str, VerificationOutcome]:
    """Fan one batched reply out per finding, dropping ids we never asked about."""
    parsed = parse_outcomes(raw)
    if parsed is None:
        return {}
    wanted = set(finding_ids)
    by_id: dict[str, VerificationOutcome] = {}
    for outcome in parsed.outcomes:
        if outcome.finding_id not in wanted:
            COUNTERS.bump("s6_batch_finding_id_invented")
            continue
        by_id[outcome.finding_id] = outcome
    absent = len(wanted) - len(by_id)
    if absent:
        COUNTERS.bump("s6_batch_finding_omitted", absent)
    return by_id


# `reason` ships to the report, so batching.py's fN ids remap; guards match s8.outcomes._PROSE_ID_RX
_REASON_PROSE_ID_RX = re.compile(r"(?<![\w./$-])f\d+\b(?!\.\w)")


def remap_reason_ids(reason: str, display: dict[str, str]) -> str:
    """Rewrite each batch-local ``fN`` token in *reason* to *display*'s ``file:line``, leaving an unknown id as written."""
    if not reason:
        return reason
    return _REASON_PROSE_ID_RX.sub(
        lambda m: display.get(m.group(0), m.group(0)), reason)


def _corrections(f: Finding, outcome: VerificationOutcome,
                 max_line: int | None = None) -> dict:
    """The verifier's fixes to *f*'s coordinates, bounded by *max_line* (the file's EOF, None when unknown)."""
    fixed: dict = {}
    cwe = norm_cwe(outcome.corrected_cwe)
    if cwe and cwe != f.cwe:
        fixed["cwe"] = cwe
        COUNTERS.bump("s6_finding_cwe_corrected")
    line = outcome.corrected_line_start
    if line > 0 and line != f.line_start:
        # pre_anchor_line is the header s5 moved off (0 if unrun), so a correction back is refused
        if f.pre_anchor_line > 0 and line == f.pre_anchor_line:
            COUNTERS.bump("s6_finding_line_correction_reverted_reanchor")
        elif max_line is not None and line > max_line:
            COUNTERS.bump("s6_finding_line_correction_ignored")
        else:
            fixed["line_start"] = line
            fixed["line_end"] = max(f.line_end, line)
            # s7 must judge the corrected line, not the stale pre-move coordinate.
            fixed["pre_anchor_line"] = 0
            COUNTERS.bump("s6_finding_line_corrected")
    # s5/gates.reject judges only line_start, so this is the only bound on line_end.
    if max_line is not None:
        end = fixed.get("line_end", f.line_end)
        if end > max_line:
            fixed["line_end"] = max_line
            COUNTERS.bump("s6_finding_line_end_clamped_eof")
    return fixed


def _trait_stamps(outcome: VerificationOutcome) -> dict:
    """The verifier's trait stamps, writing only non-default values so a missing stamp keeps the Finding's defaults."""
    stamped: dict = {}
    if outcome.control_absence:
        stamped["control_absence"] = True
        COUNTERS.bump("s6_stamp_control_absence")
    if outcome.channel == "posture":
        stamped["channel"] = "posture"
        COUNTERS.bump("s6_stamp_channel_posture")
    return stamped


def _verdict_fields(outcome: VerificationOutcome) -> dict:
    """The verdict half of the update, with CVSS scored from the vector the verifier gave."""
    # Finding.verdict has no INCONCLUSIVE slot; FALSE_POSITIVE would delete it, so it maps to None
    vector = outcome.cvss_vector.strip() or None
    score = cvss_score(vector) if vector else None
    if outcome.verdict == "TRUE_POSITIVE" and vector and score == 0.0:
        # A real weakness scored zero-impact must not rank last by that 0.0; ship it unscored
        COUNTERS.bump("s6_cvss_zero_impact_on_tp")
        vector, score = None, None
    return {
        "verdict": outcome.verdict if outcome.verdict != "INCONCLUSIVE" else None,
        "verdict_confidence": outcome.confidence,
        "verdict_reason": outcome.reason,
        "cvss_vector": vector,
        "cvss_score": score,
        "cvss_rating": cvss_rating(score) if score is not None else None,
    }


def classify(outcome: VerificationOutcome, min_confidence: int) -> str:
    """The drop bucket this outcome belongs in, so routing reads the verdict, not the Finding."""
    # A tool-free replay is lossy: its low-confidence refutation must not delete the finding unseen
    if (outcome.replayed and outcome.verdict == "FALSE_POSITIVE"
            and outcome.confidence < min_confidence):
        COUNTERS.bump("s6_replayed_fp_held")
        return "INCONCLUSIVE"
    if outcome.verdict == "INCONCLUSIVE":
        COUNTERS.bump("s6_verdict_inconclusive")
        return "INCONCLUSIVE"
    if outcome.verdict == "FALSE_POSITIVE":
        return "FALSE_POSITIVE"
    if outcome.confidence < min_confidence:
        return "UNCONFIRMED"
    return "TRUE_POSITIVE"


def _new_repeat_lines(primary: Finding, outcome: VerificationOutcome,
                      reserve: Callable[[int], bool],
                      max_line: int | None = None) -> list[int]:
    """Confirmed repeat sites that are genuinely new and within *max_line* (EOF, None when unknown)."""
    fresh, stale, oob = [], 0, 0
    for n in sorted(set(outcome.confirmed_repeat_lines)):
        if n <= 0 or n == primary.line_start:
            continue
        if max_line is not None and n > max_line:
            oob += 1
            continue
        # reserve() must check and claim in one step, or two sessions race on the same new line
        if not reserve(n):
            stale += 1
            continue
        fresh.append(n)
    if oob:
        COUNTERS.bump("s6_finding_repeat_beyond_eof", oob)
    if stale:
        COUNTERS.bump("s6_finding_repeat_already_filed", stale)
    if fresh:
        COUNTERS.bump("s6_finding_repeat_confirmed", len(fresh))
    return fresh


def apply_outcome(f: Finding, outcome: VerificationOutcome,
                  reserve: Callable[[int], bool] | None = None, *,
                  stamps: bool = True, reframe: bool = False,
                  max_line: int | None = None,
                  clone_repeats: bool = True) -> list[Finding]:
    """*f* carrying the verdict and any correction, plus one clone per new confirmed repeat site."""
    update = {**_verdict_fields(outcome), **_corrections(f, outcome, max_line)}
    if stamps:
        update.update(_trait_stamps(outcome))
    primary = f.model_copy(update=update)
    if outcome.verdict != "TRUE_POSITIVE":
        return [primary]
    if reserve is None:
        reserve = lambda _line: True
    elif primary.line_start != f.line_start:
        # Claim the corrected line so a sibling's "confirmed repeat" there reads as already filed
        reserve(primary.line_start)
    if reframe and outcome.reframed:
        # A reframed verdict relabels, so it ships alone -- after the claim, so no sibling re-files
        COUNTERS.bump("s6_verdict_reframed")
        return [primary]
    if not clone_repeats:
        if outcome.confirmed_repeat_lines:
            # The re-verify wave owes one verdict each; a clone is a row the ledger misses
            COUNTERS.bump("s6_repeat_clone_reverify_discarded",
                          len(outcome.confirmed_repeat_lines))
        return [primary]
    # A repeat site is a point, not a span copy: a wide span overlaps and dedup collapses the clones
    extra = _new_repeat_lines(primary, outcome, reserve, max_line)
    # Refs/snippet name the PRIMARY's line, so carrying them mis-points; mirrors s4 _at_line
    return [primary, *(primary.model_copy(
                update={"line_start": n, "line_end": n, "is_repeat_clone": True,
                        "code_snippet": "", "sink_ref": None, "source_ref": None,
                        "backfilled_refs": [], "pre_anchor_line": 0})
                       for n in extra)]


def discovered(outcome: VerificationOutcome, parent: Finding, *,
               repo_root: str, inventory: Collection[str]) -> list[Finding]:
    """The weaknesses this session found on its own, fanned out as s4 fans out its own, whatever the parent's verdict."""
    if not outcome.additional_findings:
        return []
    # "+s6"+s6_discovered exclude from the s5 ledger/raw counts/SARIF; no CVSS; clones keep origin
    chunk = f"{parent.chunk_id or 's6'}+s6"
    verdict = {
        "verdict": "TRUE_POSITIVE",
        "verdict_confidence": outcome.confidence,
        "verdict_reason": f"found while verifying {parent.file}:{parent.line_start}",
        "origin": "s6_discovered",
    }
    out: list[Finding] = []
    for extra in outcome.additional_findings:
        out.extend(fan_out(extra, chunk, [parent.cwe] if parent.cwe else [],
                           repo_root=repo_root, inventory=inventory))
    COUNTERS.bump("s6_finding_discovered", len(out))
    return [f.model_copy(update=verdict) for f in out]


def unverified(f: Finding, detail: str) -> Finding:
    """*f* left with no verdict, so a lost reply reads as undetermined rather than clean."""
    return f.model_copy(update={"verdict": None, "verdict_confidence": 0,
                                "verdict_reason": detail})
