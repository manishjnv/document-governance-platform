# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Loop-budget constants for the DeepAgents backend, free of ``deepagents`` imports."""

from __future__ import annotations

#: Extra supersteps beyond max_turns, so a long tool loop isn't truncated mid-flight.
#:
#: DO NOT read ``max_turns`` as a turn cap on the streaming route: LangGraph counts supersteps
#: (graph NODES), roughly ``2 * turns + 3``, and the builder asks for ``max_turns + 900`` — so
#: ``max_turns: 40`` permits ~470 turns. It is a FLOOR on the loop budget, not a ceiling.
#: A subagent's subgraph starts its OWN superstep counter against this same limit, so this also
#: bounds every persona loop on the frozen S10/S11 path. Two deliberate divergences callers rely
#: on: the one-shot path uses a tight ``+5`` (a parser turn that loops has already failed), and
#: ``via: sdk``/``via: cli`` enforce ``max_turns`` as a HARD turn cap. Exhausting the budget is
#: recovered, not lost — the backend yields a terminal snapshot before raising
#: ``HarnessProcessError(recursion_limited=True)`` and both consumers force-finalize from it.
RECURSION_HEADROOM: int = 900

#: Per-request timeout (seconds) for every model call; a hang-stop, not a spend budget.
MODEL_TIMEOUT_SECONDS: float = 1800.0

#: Output-token ceiling; explicit, since langchain's 128000 default 400s on lower-cap models.
MODEL_MAX_OUTPUT_TOKENS: int = 64000

#: NOT 4: _TRANSIENT_ATTEMPTS=3 multiplies to 9 sends at 2, 15 at 4; each retry re-arms the timeout
MODEL_MAX_RETRIES: int = 2

__all__ = ["MODEL_MAX_OUTPUT_TOKENS", "MODEL_MAX_RETRIES",
           "MODEL_TIMEOUT_SECONDS", "RECURSION_HEADROOM"]
