# vvaharness SDK — writing a plugin

A plugin adds evidence and tools to a vvaharness scan without changes to the pipeline. It can
write onto the code graph that S2, S4 and S6 query, give those agents new graph tools, and define
a subagent. It implements one Protocol, `VvahPlugin`, and returns one `Contribution`. Every field
of a `Contribution` is optional, so a plugin fills only the seams it needs.

A scan loads a plugin only when `BUILTIN_PLUGINS` lists it and the profile names it (see
[Installing a plugin](#installing-a-plugin)). `scan()` has no plugin argument.

```python
from vvaharness.sdk import Contribution, PluginInfo

class MyPlugin:
    @property
    def info(self) -> PluginInfo:
        return PluginInfo(name="myscanner", version="1")

    def contribute(self) -> Contribution:
        return Contribution(
            enrichers=(MyGraphEnricher(),),       # write onto the code graph
            graph_tools={"GraphMyThing": build},  # tools S2, S4 and S6 may call
            subagents=(my_specialist(),),         # a specialist with its own context window
        )
```

`VvahPlugin` is `runtime_checkable`, so conformance is the contract. There is no base
class to inherit and nothing to register at import time.

## The three seams a plugin fills today

| seam | field | reaches |
| --- | --- | --- |
| graph enrichment | `enrichers` | `Workspace.analyze`, so every graph query downstream |
| agent tools | `graph_tools` | S2, S4 and S6 — advertised, permitted and budgeted together |
| subagents | `subagents` | extension API; not yet consumed by detection stages |

`enrichers` are `context_graph_sdk.plugins.GraphEnricher` — we re-export that Protocol
rather than defining a parallel one, because the SDK owns the graph and already bounds
plugin execution (deadline, cancellation, `PluginRegistry` validation, and two enricher
phases, `PRE_DERIVATION` and `POST_DERIVATION`; the registry rejects any other phase).

`graph_tools` maps a model-facing tool name to a factory,
`Callable[[GraphToolContext], BaseTool]` (`ToolFactory` in `vvaharness.codegraph.tools`). A stage
calls the factory when it opens a session. `GraphToolContext` gives the factory the graph
`handle` and the scan's `ctx` (`ContextPackage`).

## Installing a plugin

Plugins are selected by a profile. The shipped `semgrep` profile enables the Semgrep plugin
with the registry rulesets `p/security-audit`, `p/python` and `p/secrets`, which Semgrep fetches
over the network. It needs a `semgrep` binary on PATH:

```text
vvaharness scan --repo <path> --config vvaharness/config/profiles/semgrep.yaml
```

To use local rule files instead, keep the shipped profile as it is and put a `config.local.yaml`
next to it. vvaharness deep-merges that file over the profile, so the credentials in the
profile's `sdk:` block stay in place. The overlay must be owned by you and not group- or
world-writable, because it can change model routes and endpoints; on POSIX systems the scan
refuses it otherwise.
`plugins` is a key **inside** `sdk:`:

```yaml
sdk:
  plugins:
    - name: semgrep
      configs: ["/absolute/path/to/local-rules.yml"]   # local rule files
      rulesets: []                                     # no registry fetch
```

Every key except `name` becomes a keyword argument of the plugin's constructor. In a single YAML
file, a second top-level `sdk:` replaces the first, credentials included, so never add one. The
[User Guide](../../docs/USER_GUIDE.md#select-and-safely-override-a-profile) describes the overlay
in full.

Only names in `BUILTIN_PLUGINS` (`vvaharness/sdk/loading.py`) resolve. A dotted import
path is **deliberately refused**: a profile naming an arbitrary module would turn config
into a code-execution surface. Adding a plugin to that table is the one change that does
need a pull request, and it is one line.

## Bounds

| bound | value | why |
| --- | ---: | --- |
| `MAX_PLUGINS` | 16 | a plugin set is loaded once per scan and must stay inspectable |
| `MAX_PLUGIN_GRAPH_TOOLS` | 8 | every tool is advertised in the system prompt of three stages |
| plugin name length | 64 | the name is the plugin's identity |

Two plugins registering the same graph-tool name raise, rather than one silently shadowing
the other. A plugin tool named like a built-in graph tool (`GraphContext`, `GraphImpact`,
`GraphNeighbors`, `GraphCommunityOf`, `GraphImporters`, `GraphSinksInCommunity`) raises too.
Two plugins sharing a name raise. A non-conforming object raises `TypeError` instead of being
skipped. Order is `(priority, name)`, so a set has exactly one order.

## Failure contract

Plugin code runs while the scan builds its code graph, so a plugin failure decides whether the
scan runs at all.

- **A plugin that raises fails the scan.** An exception from `enrich()`, or a mutation over an
  SDK bound, makes `Workspace.analyze` raise `PluginError`. The scan stops after S0, before S1,
  prints `scan failed`, and exits 1. A plugin constructor or `contribute()` that raises stops the
  scan at the same point. Record a failure on the graph instead: return a node whose property
  says what went wrong.
- **A hung `enrich()` hangs the analysis.** The SDK's deadline (300s, shared by every enricher and
  by correlation in one analysis) is *cooperative*: it is checked before `enrich()` and after the
  mutation applies, so the runner cannot interrupt a blocked callback. Bound your own I/O.
- **SDK bounds apply per enricher and per analysis.** Each enricher may emit at most 10,000 nodes,
  20,000 edges and 20,000 removals. All enrichers in one analysis share 50,000 work units, and an
  analysis accepts at most 64 enrichers. A breach rejects the mutation, and the scan fails as above.
- **`PluginContext.configuration` is always empty.** `Workspace.analyze` passes an empty
  `FrozenMap`. Configure a plugin through its constructor: the profile passes every key except
  `name` as a keyword argument.

## Remediate and validate from code

> [!WARNING]
> **`remediate()` defaults to `mode="fix"` and edits target source.** Pass
> `mode="report-only"` to get a proposed patch with no edits, review it, and apply it yourself.

- **`sdk.validate(finding, remediation, *, repo, config=None)` is implemented**
  and returns a `Verdict`. It copies `repo` as it is into a temporary workspace, writes
  `remediation.diff` there as `diff.patch` for review, runs S11 and cleans up without writing
  back to the repository.
- **`validate()` does not apply the diff.** Pass a `repo` that already contains the fix, so the
  review judges the patched code.
- `ValidationCaseError` is raised when `repo` is not a directory, `finding.file` is empty, or
  the diff is empty. `ValidationBusyError` is raised when you call `validate()` inside a running
  event loop; call it from a worker thread instead. Import both from
  `vvaharness.validation.case_api`.
- Handled session failures are inconclusive, not proof of a fix.
- The public wrapper uses default DeepAgents validation settings and needs its dependencies
  and Anthropic authentication. Its `config` argument supplies only the parent directory; it
  does not parse YAML backend/model settings. Lower-level typed validation configuration
  supports other routes.
- Both calls spend model tokens and send target source to the configured model provider.

## Current limitations

These are properties of the harness, not of your plugin. Check them before you debug a plugin
that seems to do nothing:

- `graph_tools` reach DeepAgents, the SDK/OpenAI tool adapters, and CLI sessions
  with MCP tools enabled. They require a working code graph; budget and stage
  tool settings still apply.
- No detection stage passes `subagents` yet, so the subagent seam is available but not
  yet consumed by S2/S4/S6.

## Tool docstrings are data

A `@tool` docstring becomes the JSON-schema `description` the model reads. Write it as
instruction, state what an empty result means, and never reflow it as if it were prose.
The Semgrep variant's tools are the worked example: each says what absence proves, because
"Semgrep flagged nothing" is not "this file is safe".

## The reference variant

`vvaharness/plugins/semgrep/` is a full variant, not a snippet: a shipped enricher, four
read-only tools over the subgraph it writes, and a triage subagent that keeps raw finding
volume out of the main context window. Read it in that order — `plugin.py`, `enricher.py`,
`tools.py`, `triage.py`.

`SemgrepEnricher` is built for you from the rules the plugin was given, so
`SemgrepPlugin(configs=(rules,))` is the whole setup. Pass `enricher=` to substitute your own
`GraphEnricher`.

What it writes, and what the four tools therefore query:

| node | carries |
| --- | --- |
| `SemgrepScan` (exactly 1) | `complete`, `findingCount`, `errorCount`, `skippedCount`, and a `note` |
| `SemgrepRule` (1 per rule) | `ruleId`, `cweIds`, `vulnerabilityClasses` |
| `SemgrepFinding` (1 per result) | `ruleId`, `filePath`, `semgrepStartLine`, `severity`, `message` |

| edge | from → to |
| --- | --- |
| `FLAGGED_BY` | the innermost **existing** symbol containing the line → the finding |
| `DETECTED_BY` | the finding → its rule |
| `TRACE_TOUCHES` | the finding → each traced symbol, carrying `step` and an explicit `role` |

Three decisions worth knowing, because each is load-bearing:

- **Every finding gets a `FLAGGED_BY` subject, always.** Symbol, else that path's `File` node,
  else a minted `SemgrepLocation`. The tools' Cypher requires that pattern, and an `OPTIONAL
  MATCH` composite cartesian-products into `QueryTimeoutError` on this backend — so the
  guarantee lives in the enricher, not the query. Without it a finding on a path the walk
  skipped (every dotfile) would be silently invisible.
- **`enrich()` never raises**, because a raising enricher fails the scan. No semgrep on PATH, no
  rules, a run that writes no report, a cancelled run, too little deadline left — each returns a
  `SemgrepScan` node whose `note` says which, so `GraphSemgrepCoverage` can report it. An
  absent subgraph is a queryable fact, not a missing one. Rule files are checked earlier: a
  `configs` entry that is not a local file raises `SemgrepConfigError` when the profile loads,
  and the scan stops before S1.
- **It runs `POST_DERIVATION`**, after symbols and their line spans exist to attach to, and
  after community/importance derivation so it cannot skew either.

Bounds: `MAX_FINDING_NODES` 500 (severity-ranked, so a cap drops INFO before ERROR and the
scan node says how many went), `MAX_TRACE_STEPS` 20 per finding, `MAX_EDGES` 18,000 — all under
the SDK's per-enricher ceiling of 10,000 nodes / 20,000 edges, which rejects the mutation whole.

## Running it

> [!IMPORTANT]
> **`scan()` runs the same pipeline as the CLI.** It spends model tokens and sends target source
> to the configured model provider. Scan only code you are authorized to scan, and run
> `vvaharness estimate --repo <path>` first; it makes no model call.

```python
from vvaharness.sdk import ScanOptions, scan

result = scan(ScanOptions(repo="/path/to/app", profile="semgrep", stop_after="s9"))
print(result.exit_code, result.argv)
```

`scan()` goes through `vvaharness scan`'s own entry point, so it inherits the config trust gate
that rejects a profile read from inside the scanned repo. `ScanOptions.argv()` is public: print it
to reproduce any programmatic run on the command line.

## Bringing your own findings

Use a handoff when you already ran Semgrep and want vvaharness to verify, dedupe and report what
it found, without its own model discovery in S2–S4. S5 rule detectors and S6 verification can
still add findings; those carry `origin` `detector` or `s6_discovered`. This differs from the
`semgrep` profile, which runs Semgrep inside a scan and adds its results to the graph as
evidence.

> [!IMPORTANT]
> **Run the handoff against a dedicated, empty state directory.** Set `VVAHARNESS_STATE_DIR`
> before `inject_findings`. `inject_findings` writes only the s2–s4 checkpoints, so s5–s8
> checkpoints from an earlier scan of the same path would be resumed in place of your findings.

Convert the report, seed the S4 checkpoint, then resume:

```python
import os
import tempfile

from vvaharness.plugins.semgrep import findings_from_semgrep
from vvaharness.sdk import ScanOptions, inject_findings, scan

os.environ["VVAHARNESS_STATE_DIR"] = tempfile.mkdtemp(prefix="vvah-handoff-")

repo     = "/path/to/app"
findings = findings_from_semgrep("semgrep.json", repo=repo)   # repo= is REQUIRED in practice
handoff  = inject_findings(repo, findings)                    # seeds s4, and s2+s3 as empty

scan(ScanOptions(repo=repo, resume=True, stop_after="s9"))     # runs S5 onward on your findings
```

Resume only a trusted target. `stop_after="s9"` keeps the run detection-only: S10 remediation and
S11 validation do not run. The resumed scan still spends model tokens in the auto-exclude survey
and in S6–S8.

`inject_findings` writes the s4 envelope `scan.py` reads back —
`{"findings": [...], "outcomes": {...}, "input_kind": "external"}`. The `input_kind` marker tells
the report metrics that no deep dive ran.

### What runs, and why it is not "S0–S4"

Each stage reuses its checkpoint only when the stage before it was reused too. Seeding s4 alone
would run S2, which is agentic and costs a model call you did not ask for, and a fresh S2 makes
S3 and S4 run again. `inject_findings` therefore also seeds empty `s2` and `s3` checkpoints, and
reports them on `Handoff.skipped`.

Pass `skip_discovery=False` only to reuse real s2 and s3 checkpoints that an earlier scan of the
same checkout left in the same state directory. If either is missing, S4 runs its own deep dive
and replaces the injected findings. With a fresh state directory, keep the default.

It does not seed s0 or s1. They make no model call, and S5 needs the file inventory that s1
builds. The code graph is built on every run, between s0 and s1. Before s0, the auto-exclude
survey (on in every shipped profile) makes one model call, and its exclusions apply to your
findings too. To skip it, pass `extra_argv=("--no-auto-step1",)` in `ScanOptions`.

| step | in a handoff | model call |
| --- | --- | --- |
| auto-exclude survey (before s0) | runs, unless `--no-auto-step1` | yes |
| s0 seed | runs | no |
| code graph (between s0 and s1) | built on every run | no |
| s1 preprocess | runs | no |
| s2 threat model | skipped: seeded empty | — |
| s3 decompose | skipped: seeded empty | — |
| s4 deep dive | skipped: your findings | — |
| s5 enrich + prefilter | runs; rule detectors can add findings | no |
| s6 verify | runs; can add findings | yes |
| s7 dedupe | runs | when findings need semantic grouping |
| s8 report | runs | when findings remain |
| s9 SARIF | runs | no |

### Check paths before you inject

S5 drops a finding whose location the scan cannot see. Each drop appears in the S5 console line
and in the report's dropped list, but the finding never reaches S6.

- **Convert with `repo=`.** Semgrep reports *absolute* paths when it scans an absolute target.
  vvaharness keys findings on repo-relative paths, so without `repo=` S5 drops each such finding
  as `EXCLUDED / file not in repo inventory`. Always convert with
  `findings_from_semgrep(report, repo=repo)`.
- **Inject only files the scan can see.** A finding outside `ctx.all_files` is dropped by S5
  whatever you do. Paths the repo walk excluded (vendored trees, earlier `security-scan/` output,
  anything the profile's globs or the auto-exclude survey cut) cannot reach S6. Check against
  `ContextPackage.all_files` first.
- **S5 also drops** findings on test, mock or example paths (secrets and information leaks are
  kept) and findings whose line is outside the file.

### What the conversion does and does not do

- The first CWE a rule reports becomes the finding's `cwe`; the class comes from the first of
  the rule's CWEs that maps onto the 12-member `VulnClass` (not necessarily the same CWE), and
  the rule's other CWE ids are not carried. An **unmapped** CWE becomes `other` rather than being
  dropped, because a finding vvaharness cannot classify is still a finding it must carry.
- A result with no `path` or no `start.line` **is** dropped. vvaharness keys findings by
  `file:line`, so inventing a location would corrupt dedup downstream.
- A report with no `results` key raises rather than returning an empty list, because a silent `[]`
  reads as "the scan was clean".
- `origin` is stamped `semgrep:<rule-id>`, so a report can always say which rule produced a row.

Bounds: `MAX_FINDINGS` 2,000 results per report, `MAX_JSON_BYTES` 64 MiB,
`MAX_INJECTED_FINDINGS` 2,000.

## See also

- [Integrations](../../docs/integrations.md) — the operator view of both Semgrep modes.
- [Features](../../docs/features.md#sdk-integrate-discovery-in-python) — the SDK overview and
  its integration choices.
