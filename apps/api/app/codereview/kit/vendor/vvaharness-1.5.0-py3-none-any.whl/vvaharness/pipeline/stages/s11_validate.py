# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""s11_validate — thin wrapper that hooks the validation package (`vvaharness/validation/`) into the pipeline as a stage entry point."""
from __future__ import annotations

from collections.abc import MutableMapping
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vvaharness.config import Config


def run(  # signature is the orchestrator's keyword contract (scan.py)
    repo: Path | str,
    *,
    cfg: Config,  # orchestrator passes cfg=cfg; keep the keyword accepted
    config_path: str,
    finding_ids: list[str] | None = None,
    resume: bool = False,
    report_md: Path | str | None = None,
    progress: MutableMapping[str, int] | None = None,
) -> int:
    """Invoke the s11 validation package against the case records s10 left under security-remediation/."""
    from vvaharness.validation.cli import main as validate_main
    argv = ["--repo", str(repo)]
    for flag, value in (("--config", config_path), ("--scan-report", report_md)):
        if value:
            argv += [flag, str(value)]
    for finding_id in finding_ids or ():
        argv += ["--finding", finding_id]
    if resume:
        argv.append("--resume")
    code = (validate_main(argv, progress=progress)
            if progress is not None else validate_main(argv))
    # Best-effort reporting: neither the rollup nor its orchestrator-wide import may change our code
    try:
        from vvaharness.orchestrator import case_rollup
        case_rollup.record(repo)
    except Exception:
        pass
    return code
