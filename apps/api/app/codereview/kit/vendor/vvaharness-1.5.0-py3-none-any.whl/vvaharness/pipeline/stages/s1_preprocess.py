# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Step 1 — injects CVEs/controls, merges the s0 seed, and derives modules, notes and language from the graph."""
from __future__ import annotations
from vvaharness.util import logs

from pathlib import Path

from vvaharness.backends.llm import tools as _localtools
from vvaharness.codegraph import (
    GraphHandle,
    communities_as_modules,
    primary_language,
    system_context_notes,
)
from vvaharness.lang.detect import EXT_TO_LANG
from vvaharness.models import CVE, ContextPackage, Control
from vvaharness.scope import (
    EmptyScopeError,
    _dedup_configs,
    _resolve_scope_path,
    _walk_repo,
)
from vvaharness.util import console
from vvaharness.util import errlog as _errlog
from vvaharness.util.events import Event

log = logs.get_logger(__name__)


QSEP = "::"
MODULE_SCOPE = "<module>"


def q_join(file: str, name: str) -> str:
    return f"{file}{QSEP}{name}"


def q_split(qname: str) -> tuple[str, str]:
    if QSEP in qname:
        f, _, n = qname.rpartition(QSEP)
        return f, n
    return "", qname


def q_file(qname: str) -> str:
    return q_split(qname)[0]


def q_name(qname: str) -> str:
    return q_split(qname)[1]


def _modules_from_graph(graph_handle: GraphHandle, resolve_in_scope) -> list[dict]:
    """Leiden communities, filtered to the in-scope inventory, as ``ModuleInfo`` dicts."""
    modules: list[dict] = []
    for name, files in communities_as_modules(graph_handle).items():
        in_scope = sorted({hit for f in files if (hit := resolve_in_scope(f))})
        if in_scope:
            modules.append({"name": name, "files": in_scope})
    return modules


def run(repo_root: str, cfg, known_cves: list[CVE], controls: list[Control],
        seed=None, graph_handle: GraphHandle | None = None) -> ContextPackage:
    """Merges the optional s0 seed and graph into a ContextPackage, making no model call."""
    # Reuse s0's walk, not a second walk; falls back when s0 was off or its checkpoint has no walk
    if seed is not None and getattr(seed, "all_files", None):
        all_files, excluded = list(seed.all_files), dict(seed.excluded)
    else:
        all_files, excluded = _walk_repo(repo_root, cfg)
    # Jail agentic reads to the inventory or .git/config is readable; before dedup so siblings stay
    _localtools.set_scope(repo_root, all_files)
    all_files, dedup_report = _dedup_configs(all_files, Path(repo_root), cfg)
    excluded["config_dedup"] = dedup_report
    tracker = getattr(cfg, "_scan_progress", None)
    if tracker is not None:
        tracker.discovered(all_files)

    # Seed paths are normalized so './foo', 'foo', '<abs>/foo' and 'foo\bar' all match the inventory
    keep = set(all_files)
    # In --group-by-app a seed path may omit its top-level repo dir, so try each as a prefix first
    top_dirs = sorted(d.name for d in Path(repo_root).iterdir()
                      if d.is_dir() and d.name not in ("checkpoints",
                                                       "security-scan"))

    ambiguous: list[str] = []   # matched 2+ top dirs: dropped, never guessed

    def _resolve_in_scope(path: str) -> str | None:
        hit, amb = _resolve_scope_path(path, repo_root, keep, top_dirs)
        if amb:
            ambiguous.append(path)        # raw seed string, for the log
        return hit

    data: dict = {"unsafe_sinks": [], "entry_points": []}

    if seed:
        seed_sinks = [dict(s.model_dump(), file=hit)
                      for s in seed.unsafe_sinks
                      if (hit := _resolve_in_scope(s.file))]
        seed_eps = [dict(e.model_dump(), file=hit)
                    for e in seed.entry_points
                    if (hit := _resolve_in_scope(e.file))]
        data["unsafe_sinks"].extend(seed_sinks)
        data["entry_points"].extend(seed_eps)
        log.info("s1/preprocess: merged s0 seed - sinks=%d entry_points=%d",
                 len(seed_sinks), len(seed_eps))
        # Semgrep codeFlow hops are "file:line"; re-resolve so s3._reachable_files can trust them
        seed_paths: list[list[str]] = []
        for path in getattr(seed, "taint_paths", None) or []:
            resolved = []
            for hop in path:
                f, sep, ln = hop.rpartition(":")
                hit = _resolve_in_scope(f or hop)
                if hit:
                    resolved.append(f"{hit}:{ln}" if sep else hit)
            if len(resolved) >= 2:
                seed_paths.append(resolved)
        data["seed_taint_paths"] = seed_paths
        log.debug("s1/preprocess: seed taint paths processed - paths=%d", len(seed_paths))

        # Framework entry points arrive inside seed.entry_points, not separately.
        framework_unresolvable: set[str] = set()
        for ep in getattr(seed, "entry_points", []) or []:
            if getattr(ep, "kind", "").lower() == "framework" and not _resolve_in_scope(ep.file):
                framework_unresolvable.add(f"{ep.file}::{ep.function}")
        if framework_unresolvable:
            sample = ", ".join(sorted(framework_unresolvable)[:3])
            n_str = f" (+{len(framework_unresolvable)-3} more)" if len(framework_unresolvable) > 3 else ""
            log.warning(Event.S1_FRAMEWORK_ENTRY_UNRESOLVED, count=len(framework_unresolvable),
                        sample=f"{sample}{n_str}")

        if seed_sinks or seed_eps or seed_paths:
            console.write(f"  [s1] merged s0 seed: +{len(seed_eps)} entry points, "
                          f"+{len(seed_sinks)} sinks, {len(seed_paths)} codeFlow paths")

    if ambiguous:
        uniq = sorted(set(ambiguous))
        sample = ", ".join(uniq[:5]) + ("…" if len(uniq) > 5 else "")
        log.warning(Event.S1_AMBIGUOUS_PATHS_DROPPED, count=len(ambiguous), sample=sample)

    data["repo_root"] = repo_root
    if graph_handle is not None:
        data["language"] = primary_language(graph_handle)
        data["modules"] = _modules_from_graph(graph_handle, _resolve_in_scope)
        data["notes"] = system_context_notes(graph_handle)
    else:
        data["modules"] = []
        data["notes"] = ""
    # `language` is required with no default; fall back to the commonest ext if the graph has none
    if not data.get("language"):
        ext_counts: dict[str, int] = {}
        for f in all_files:
            lang = EXT_TO_LANG.get(Path(f).suffix.lower())
            if lang:
                ext_counts[lang] = ext_counts.get(lang, 0) + 1
        data["language"] = (max(ext_counts, key=lambda k: ext_counts[k])
                            if ext_counts else "unknown")
    data["all_files"] = all_files
    data["excluded"] = excluded
    data["known_cves"] = [c.model_dump() for c in known_cves]
    data["design_controls"] = [c.model_dump() for c in controls]

    # models.py field_validator(mode="before") coerces off-schema enums/ints, so this never raises
    pkg = ContextPackage.model_validate(data)
    n_ex_dirs = sum(excluded["dirs"].values())
    n_ex_exts = sum(excluded["exts"].values())
    n_ex_globs = sum(excluded["globs"].values())
    n_ex_size = excluded["oversize"]
    n_ex_dedup = (excluded.get("config_dedup") or {}).get("dropped", 0) or 0
    n_in_scope = len(pkg.all_files)
    n_total = n_in_scope + n_ex_dirs + n_ex_exts + n_ex_globs + n_ex_size + n_ex_dedup
    console.write(f"  [s1] file inventory: {n_total} on disk -> {n_in_scope} in scope "
                  f"(excluded: {n_ex_dirs} dir, {n_ex_exts} ext, {n_ex_globs} glob, "
                  f"{n_ex_size} oversize, {n_ex_dedup} config-dedup)")
    console.counts("s1", "done", modules=len(pkg.modules),
                   entry_points=len(pkg.entry_points), sinks=len(pkg.unsafe_sinks),
                   files_in_scope=n_in_scope)
    # Every later stage would process the empty set and report success, so refuse here instead
    if not n_in_scope:
        raise EmptyScopeError(
            f"0 files in scope after exclusions ({n_total} on disk: "
            f"{n_ex_dirs} dir, {n_ex_exts} ext, {n_ex_globs} glob, "
            f"{n_ex_size} oversize, {n_ex_dedup} config-dedup). Nothing was "
            f"analysed, so no conclusion can be drawn about this repository. "
            f"Re-run with --no-auto-step1, or widen the step1 exclusions.")
    # All-zero output on a non-empty inventory: record it so scan health/SARIF show the degradation
    if (n_in_scope and not pkg.modules and not pkg.entry_points
            and not pkg.unsafe_sinks):
        _errlog.log("s1", "context-package",
                    "S1 produced 0 modules, 0 entry points and 0 sinks "
                    f"with {n_in_scope} files in scope",
                    reason="s1_zero_output",
                    files_in_scope=n_in_scope)
    return pkg
