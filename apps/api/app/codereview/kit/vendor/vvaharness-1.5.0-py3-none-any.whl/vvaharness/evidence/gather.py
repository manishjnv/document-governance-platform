# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The deterministic (no-LLM) threat-model evidence snapshot: ThreatEvidence DTO + gather()."""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from pydantic import BaseModel, ConfigDict

from vvaharness.evidence.api_artefacts import gather_api_artefacts
from vvaharness.evidence.configs import gather_config_reps
from vvaharness.evidence.docs import gather_docs
from vvaharness.evidence.manifests import gather_manifests
from vvaharness.lang.detect import EXT_TO_LANG, LANG_DISPLAY
from vvaharness.models import ContextPackage
from vvaharness.util import logs
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

_LANG_BY_EXT = {ext: LANG_DISPLAY.get(key, key) for ext, key in EXT_TO_LANG.items()}


def _cap_int(s2: object, key: str, default: int) -> int:
    """An operator-configured integer cap; 0 survives, anything unusable falls back to `default`."""
    v = getattr(s2, key, None)
    if v is None:
        return default
    try:
        n = int(v)
    except (TypeError, ValueError, OverflowError):
        return default
    return n if n >= 0 else default


@dataclass(frozen=True)
class _Caps:
    """Every `step2.*` integer cap `gather()` reads, sanitized through `_cap_int`."""

    doc_cap: int
    manifest_cap: int
    manifest_total_cap: int
    max_manifest_depth: int
    max_manifests: int
    max_manifests_per_kind: int
    max_graph_files: int
    max_entry_points: int
    max_graph_sinks: int
    max_modules: int
    max_graph_edges: int
    max_config_reps: int
    max_config_rep_chars: int
    max_config_rep_bodies: int
    max_api_artefacts: int
    max_modules_prompt: int
    max_entry_points_prompt: int
    max_inventory_files: int


def _resolve_caps(s2: object) -> _Caps:
    return _Caps(
        doc_cap=_cap_int(s2, "max_doc_chars", 20000),
        manifest_cap=_cap_int(s2, "max_manifest_chars", 4000),
        manifest_total_cap=_cap_int(s2, "max_manifest_total_chars", 24000),
        max_manifest_depth=_cap_int(s2, "max_manifest_depth", 3),
        max_manifests=_cap_int(s2, "max_manifests", 12),
        max_manifests_per_kind=max(1, _cap_int(s2, "max_manifests_per_kind", 2)),
        max_graph_files=_cap_int(s2, "max_graph_files", 220),
        max_entry_points=_cap_int(s2, "max_entry_points", 400),
        max_graph_sinks=_cap_int(s2, "max_graph_sinks", 80),
        max_modules=_cap_int(s2, "max_modules", 100),
        max_graph_edges=_cap_int(s2, "max_graph_edges", 100),
        max_config_reps=_cap_int(s2, "max_config_reps", 80),
        max_config_rep_chars=_cap_int(s2, "max_config_rep_chars", 2000),
        max_config_rep_bodies=_cap_int(s2, "max_config_rep_bodies", 12),
        max_api_artefacts=_cap_int(s2, "max_api_artefacts", 100),
        # Prompt caps are separate keys from the frontier caps above.
        max_modules_prompt=_cap_int(s2, "max_prompt_modules", 100),
        max_entry_points_prompt=_cap_int(s2, "max_prompt_entry_points", 400),
        max_inventory_files=_cap_int(s2, "max_inventory_files", 1200),
    )


class ThreatEvidence(BaseModel):
    """The deterministic snapshot s2's prompt is built from."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    file_count: int
    original_file_count: int
    primary_language: str
    languages: tuple[tuple[str, int], ...] = ()
    top_dirs: tuple[str, ...] = ()
    modules: tuple[tuple[str, str, int], ...] = ()             # (name, purpose, loc)
    modules_truncated: bool = False
    entry_points: tuple[tuple[str, bool, str, str], ...] = ()  # (kind, unauth, file, function)
    entry_points_truncated: bool = False
    config_reps: tuple[tuple[str, str], ...] = ()              # (rel_path, body or "")
    api_artefacts: tuple[str, ...] = ()
    docs: tuple[tuple[str, str], ...] = ()                     # (name, capped body)
    manifests: tuple[tuple[str, str], ...] = ()                # (rel_path, truncated body)
    inventory: tuple[str, ...] = ()
    inventory_truncated: bool = False
    s1_notes: str = ""


def _build_frontier(ctx: ContextPackage | None, caps: _Caps) -> ContextPackage | None:
    """The AST-relevant sample of `ctx`; graph-derived blocks read this, not `ctx` directly."""
    if not ctx:
        return None
    frontier = ctx.ast_context_view(
        max_files=caps.max_graph_files,
        max_entry_points=caps.max_entry_points,
        max_sinks=caps.max_graph_sinks,
        max_modules=caps.max_modules,
        max_edges=caps.max_graph_edges,
    )
    _note_frontier_cuts(ctx, frontier, caps)
    return frontier


def _note_cut(counter: str, kind: str, total: int, kept: int, cap_keys: list[str]) -> None:
    """Count and warn when an S2 evidence kind lost items, naming the step2 cap(s) that bound it."""
    if kept >= total:
        return
    COUNTERS.bump(counter, total - kept)
    log.warning(Event.S2_CAP_TRUNCATED, kind=kind, kept=kept, total=total,
                excluded=total - kept, cap=",".join(f"step2.{k}" for k in cap_keys))


def _note_frontier_cuts(ctx: ContextPackage, frontier: ContextPackage, caps: _Caps) -> None:
    """Surface every item ast_context_view kept out of the S2 evidence, per kind."""
    # Entry points, sinks and modules lose items two ways: their file fell outside the
    # max_graph_files frontier, or their own cap; name whichever actually bound
    allowed = set(frontier.all_files)
    _note_cut("s2_frontier_files_excluded", "files", len(ctx.all_files),
              len(frontier.all_files), ["max_graph_files"])
    for kind, files, kept, key, limit in (
        ("entry_points", [e.file for e in ctx.entry_points], len(frontier.entry_points),
         "max_entry_points", caps.max_entry_points),
        ("sinks", [s.file for s in ctx.unsafe_sinks], len(frontier.unsafe_sinks),
         "max_graph_sinks", caps.max_graph_sinks),
    ):
        inside = sum(f in allowed for f in files)
        _note_cut(f"s2_frontier_{kind}_excluded", kind, len(files), kept,
                  [k for k, hit in (("max_graph_files", inside < len(files)),
                                    (key, inside > limit)) if hit])
    inside = sum(any(p in allowed for p in m.files) for m in ctx.modules)
    _note_cut("s2_frontier_modules_excluded", "modules", len(ctx.modules), len(frontier.modules),
              [k for k, hit in (("max_graph_files", inside < len(ctx.modules)),
                                ("max_modules", inside > caps.max_modules)) if hit])


def _language_counts(full_files: list[str]) -> Counter[str]:
    counts: Counter[str] = Counter()
    for rel in full_files:
        lang = _LANG_BY_EXT.get(PurePosixPath(rel).suffix.lower())
        if lang:
            counts[lang] += 1
    return counts


def _sorted_entry_points(active_ctx: ContextPackage | None) -> list[tuple[str, bool, str, str]]:
    eps = [(e.kind, e.reachable_from_unauth, e.file, e.function)
           for e in (active_ctx.entry_points if active_ctx else [])]
    eps.sort(key=lambda t: (t[0] != "network", not t[1], t[0], t[2]))
    return eps


def gather(repo_root: str, cfg: object, ctx: ContextPackage | None) -> ThreatEvidence:
    """Assemble ThreatEvidence: graph blocks read the AST frontier, shape blocks read all files."""
    root = Path(repo_root)
    caps = _resolve_caps(getattr(cfg, "step2", None))

    frontier = _build_frontier(ctx, caps)
    active_ctx = frontier or ctx
    frontier_files = list(active_ctx.all_files) if active_ctx else []
    full_files = list(ctx.all_files) if ctx else frontier_files

    modules = [(m.name, m.purpose, m.loc) for m in (active_ctx.modules if active_ctx else [])]
    eps = _sorted_entry_points(active_ctx)

    docs = gather_docs(root, full_files, caps.doc_cap)
    manifests = gather_manifests(
        root, (caps.max_manifest_depth, caps.max_manifests, caps.max_manifests_per_kind),
        caps.manifest_cap, caps.manifest_total_cap)
    cfg_reps = gather_config_reps(root, full_files, caps.max_config_reps,
                                  caps.max_config_rep_chars, caps.max_config_rep_bodies)
    api_artefacts = gather_api_artefacts(full_files, caps.max_api_artefacts)
    top_dirs = sorted({rel.split("/", 1)[0] for rel in full_files if "/" in rel})

    # The prompt marks these cuts "…(truncated)" for the model; the operator gets the same signal
    for counter, kind, total, limit, key in (
        ("s2_prompt_modules_truncated", "prompt_modules", len(modules),
         caps.max_modules_prompt, "max_prompt_modules"),
        ("s2_prompt_entry_points_truncated", "prompt_entry_points", len(eps),
         caps.max_entry_points_prompt, "max_prompt_entry_points"),
        ("s2_inventory_files_truncated", "inventory_files", len(full_files),
         caps.max_inventory_files, "max_inventory_files"),
    ):
        _note_cut(counter, kind, total, min(total, limit), [key])

    return ThreatEvidence(
        file_count=len(frontier_files),
        original_file_count=len(ctx.all_files) if ctx else len(frontier_files),
        primary_language=ctx.language if ctx else "",
        languages=tuple(_language_counts(full_files).most_common()),
        top_dirs=tuple(top_dirs),
        modules=tuple(modules[:caps.max_modules_prompt]),
        modules_truncated=len(modules) > caps.max_modules_prompt,
        entry_points=tuple(eps[:caps.max_entry_points_prompt]),
        entry_points_truncated=len(eps) > caps.max_entry_points_prompt,
        config_reps=tuple(cfg_reps),
        api_artefacts=tuple(api_artefacts),
        docs=tuple(docs),
        manifests=tuple(manifests),
        inventory=tuple(sorted(full_files)[:caps.max_inventory_files]),
        inventory_truncated=len(full_files) > caps.max_inventory_files,
        s1_notes=getattr(ctx, "notes", "") if ctx else "",
    )
