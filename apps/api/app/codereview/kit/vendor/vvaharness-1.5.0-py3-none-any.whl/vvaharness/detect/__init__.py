# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deterministic source/sink detection over source text."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from vvaharness.detect.matcher import Hit, scan_files
from vvaharness.detect.patterns import default_corpus
from vvaharness.detect.roles import hits_to_entry_points, hits_to_sinks
from vvaharness.detect.spec import MatchSpec
from vvaharness.models.scan.surface import EntryPoint, Sink

__all__ = [
    "Hit",
    "MatchSpec",
    "Result",
    "default_corpus",
    "scan",
]


@dataclass(frozen=True)
class Result:
    """The typed output of one detect.scan() call."""

    entry_points: list[EntryPoint]
    unsafe_sinks: list[Sink]
    hits: list[Hit]


def scan(repo_root: Path, rel_paths: list[str]) -> Result:
    """Match the corpus against every listed file and return typed results."""
    hits = scan_files(repo_root, rel_paths, default_corpus())
    return Result(
        entry_points=hits_to_entry_points(hits),
        unsafe_sinks=hits_to_sinks(hits),
        hits=hits,
    )
