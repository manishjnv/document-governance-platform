# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""FinalReport's metrics, scan-health, coverage and scope renderers."""
from __future__ import annotations

import logging
from collections import Counter
from typing import TYPE_CHECKING

from vvaharness.models.scan._finding_section import _EV_POSITIVE_ONLY_NOTE
from vvaharness.models.scan._render import (
    _md_cell,
)
from vvaharness.models.scan._sections_pipeline import (
    _render_chunk_kind_line,
    _render_pipeline_diagnostics,
)

if TYPE_CHECKING:  # typing only: report.py imports this module at runtime
    from vvaharness.models.scan.metrics import ScanMetrics
    from vvaharness.models.scan.report import FinalReport

log = logging.getLogger(__name__)


def _render_metrics(report, *, unreachable_appendix: bool = True) -> list[str]:
    m = report.metrics
    lines = [
        "## Scan Metrics",
        "",
        f"- Scan ID: {m.scan_id}",
        f"- Module: {m.module_name}",
        f"- Start: {m.start_ts}",
        f"- End: {m.end_ts}",
        f"- Duration (sec): {m.duration_sec:.0f}",
        f"- Files in scope: {m.total_files_in_scope}",
        f"- Files analyzed (unique): {m.analyzed_files_unique}",
        f"- Coverage: {m.coverage_pct:.1f}% (files analyzed / files in scope)",
        _render_chunk_kind_line(report),
        f"- Tokens (prompt): {m.prompt_tokens if m.prompt_tokens is not None else 'unavailable'}",
        f"- Tokens (completion): {m.completion_tokens if m.completion_tokens is not None else 'unavailable'}",
        f"- Tokens (total): {m.total_tokens if m.total_tokens is not None else 'unavailable'}",
        "",
    ]
    if m.folders_scanned:
        lines.append(f"- Folders scanned: {len(m.folders_scanned)}")
    lines.extend(_render_pipeline_diagnostics(report,
        unreachable_appendix=unreachable_appendix))
    if m.tokens_by_phase:
        lines.extend([
            "### Tokens by Phase",
            "",
            ("_Prompt = fresh + cache-write (billable). Cache-read shown "
            "separately, NOT included in totals._"),
            "",
            "| Phase | Calls | Prompt | Completion | Total | % | Cache-read (excl.) |",
            "|---|---:|---:|---:|---:|---:|---:|",
        ])
        grand = sum(b["prompt"] + b["completion"]
                    for b in m.tokens_by_phase.values()) or 1
        for ph, b in sorted(m.tokens_by_phase.items(),
                            key=lambda kv: -(kv[1]["prompt"] + kv[1]["completion"])):
            phase_label = "unscoped (outside stage wrapper)" if ph in {
                "unlabeled", "unscoped"
            } else ph
            tot = b["prompt"] + b["completion"]
            lines.append(
                f"| {phase_label} | {b['calls']} | {b['prompt']:,} | {b['completion']:,} "
                f"| {tot:,} | {tot / grand * 100:.1f} | {b['cache_read']:,} |"
            )
        lines.append("")
    if m.loc_in_scope_by_language:
        lines.extend([
            "### Language LOC Coverage",
            "",
            "| Language | LOC in scope | LOC scanned | Coverage % |",
            "|---|---:|---:|---:|",
        ])
        for lang, loc_in in sorted(m.loc_in_scope_by_language.items()):
            loc_sc = m.loc_scanned_by_language.get(lang, 0)
            pct = (loc_sc / loc_in * 100) if loc_in else 0.0
            lines.append(f"| {lang} | {loc_in} | {loc_sc} | {pct:.1f} |")
        lines.append("")
    return lines

def _render_verification(report: FinalReport, *, posture_channel: bool = True) -> list[str]:
    """The ## Verification funnel, with every term needed to reconcile raw -> reported."""
    drops = report.dropped
    by_reason = Counter(d.reason for d in drops)
    fp, unc, dup = (by_reason["FALSE_POSITIVE"], by_reason["UNCONFIRMED"],
                    by_reason["DUPLICATE"])
    # Undetermined verifications are NOT confirmed FPs; counted apart, not folded into FP
    verr = report._undetermined_drop_count()
    # "+s6" marks a verifier-discovered row (s6/outcomes.py:discovered), the one the ledger
    # check excludes. Never a DUPLICATE row: s7 copies chunk_id, so a confirmed discovery it
    # later collapses would otherwise read as dropped on re-verify.
    reverify_dropped = sum(1 for d in drops
                           if d.reason != "DUPLICATE" and d.chunk_id.endswith("+s6"))
    # canonical_idx is None only on s5's pre-verification collapse ("DUP (pre-verify)")
    dup_pre = sum(1 for d in drops
                  if d.reason == "DUPLICATE" and d.canonical_idx is None)
    verified_tp, verified_fp = report._verified_tp_fp()
    _tp_plus_fp = verified_tp + verified_fp
    # Spelled out: Scan Health counts undetermined outcomes as verdicts too
    rate = (f"{verified_tp / _tp_plus_fp * 100:.1f}%" if _tp_plus_fp
            else "n/a (no TRUE_POSITIVE/FALSE_POSITIVE verdicts)")
    m = report.metrics
    discovered = m.discovered_true_positive_count if m else 0
    clones = m.repeat_clone_true_positive_count if m else 0
    # The Findings heading counts the main list only when posture findings are split out
    n_posture = (sum(1 for rf in report.findings if rf.finding.channel == "posture")
                 if posture_channel else 0)
    split = (f" ({len(report.findings) - n_posture} application-defect + {n_posture} posture)"
             if n_posture else "")
    out = [
        "## Verification",
        f"- Raw findings (pre-verification): {report.raw_findings_count}",
        (f"- Verified true positives: {verified_tp} → {len(report.findings)} "
         f"reported after dedup{split}"),
    ]
    if discovered + clones:
        # Omitted at 0: an s8 checkpoint predating the fields reads 0 and must not claim it
        out.append(f"  - of which {discovered} verifier-discovered and {clones} repeat-site "
                   "clone(s) — minted during verification, so not in the raw count")
    out.extend([
        f"- False positives (dropped): {fp}",
        f"- Unconfirmed (dropped — verifier confidence below the gate): {unc}",
        f"- Verifier errors or inconclusive (excluded — undetermined, not confirmed clean): {verr}",
    ])
    if reverify_dropped:
        out.append("- Verifier-discovered findings dropped on re-verify (inside the three "
                   f"dropped counts above, not in the raw count): {reverify_dropped}")
    out.extend([
        (f"- Duplicates collapsed (all passes): {dup} — {dup_pre} before verification, "
         f"{dup - dup_pre} after"),
        f"- Verifier confirmation rate: {rate}",
        ("  - True positives as a share of the verifier's true- and false-positive "
         "verdicts on candidates the harness itself produced; the harness grading its "
         "own findings, not precision against ground truth."),
    ])
    out.extend(_ev_lines(report))
    return out


def _ev_lines(report: FinalReport) -> list[str]:
    """EV's roll-up (when a reported finding was live-tested) and rescued-row lines."""
    # Counts findings IN THIS REPORT; the live-tested total of record is S6's funnel line
    _ev = [rf.finding.ev_status for rf in report.findings]
    ev_confirmed = _ev.count("CONFIRMED")
    ev_not = _ev.count("NOT_CONFIRMED")
    ev_inconc = _ev.count("INCONCLUSIVE")
    ev_tested = ev_confirmed + ev_not + ev_inconc
    out: list[str] = []
    if ev_tested:
        out = [
            (f"- Exploit verification: {ev_confirmed} confirmed live, "
             f"{ev_not} not confirmed, {ev_inconc} requiring review "
             f"({ev_tested} live-tested)"),
            f"  - {_EV_POSITIVE_ONLY_NOTE}",
        ]
    # A rescued row (router.py:_rescue) is in the reported count but not the true-positive
    # count above. Not gated on ev_tested: s7 is EV-blind and may collapse the rescued row
    # onto an untested canonical. Omitted at 0 like "of which" (older checkpoints read 0).
    m = report.metrics
    rescued = m.ev_rescued_count if m else 0
    if rescued:
        out.append("- Kept without a true-positive verdict (exploit-verified live, dropped "
                   f"by the static verifier): {rescued}")
    return out


#: (counter prefix, stage label) for every stage whose evidence gate may relent.
_RELENT_STAGES: tuple[tuple[str, str], ...] = (
    ("s2", "S2 threat model"),
    ("s4", "S4 deep-dive"),
    ("s6", "S6 verification"),
)


def _relent_lines(m: ScanMetrics | None) -> list[str]:
    """One ⚠️ bullet per stage whose evidence gate relented without full evidence."""
    if m is None:
        return []
    out: list[str] = []
    for prefix, label in _RELENT_STAGES:
        relented = getattr(m, f"{prefix}_evidence_gate_rejected_relented", 0)
        if not relented:
            continue
        rejected = getattr(m, f"{prefix}_evidence_gate_rejected", 0)
        out.append(
            f"- ⚠️ {label} proceeded without graph-tool evidence after "
            f"{rejected} rejected attempt(s) "
            f"(`{prefix}_evidence_gate_rejected_relented`={relented})."
        )
    return out


def _unranked_lines(report: FinalReport) -> list[str]:
    """One bullet with S8's ranked/omitted split, present only when a finding went unranked."""
    ranked, by_design, feeder_missed = report.unranked_split()
    total = ranked + by_design + feeder_missed
    if not (by_design or feeder_missed):
        return []
    line = f"- S8 ranked {ranked} of {total} finding(s)"
    if by_design:
        line += f"; {by_design} omitted by design (no chain role)"
    if feeder_missed:
        line += f"; {feeder_missed} feed a chain step but got no entry"
    return [line + "."]


def _render_scan_health(report) -> list[str]:
    """The Scan Health section: coverage loss and per-stage errors, empty when healthy."""
    from pathlib import Path
    m = report.metrics
    lines: list[str] = []
    degraded = getattr(report, "degraded", False)
    failed = m.chunks_failed if m else 0
    errs = (m.errors_by_stage if m else {}) or {}
    hollow = report.is_hollow()
    coverage = report.coverage_degraded()
    relents = _relent_lines(m)
    unranked = _unranked_lines(report)
    if not (degraded or failed or errs or hollow or coverage or relents or unranked
            or (m and m.deepdive_skipped)):
        return lines
    lines.extend(["## Scan Health", ""])
    if m and m.deepdive_skipped:
        lines.append("- External findings supplied; S4 deep-dive intentionally skipped. "
                     "No deep-dive coverage is claimed; downstream verification is separate.")
    if hollow:
        lines.append(
            "- ⚠️ **Hollow scan** — analysis completed but the "
            "threat-model pass produced no usable threats on a non-empty "
            "repository; coverage and ranking for this scan may be "
            "understated.")
    lines.extend(_coverage_degraded_lines(report, coverage))
    if degraded:
        # s8 always supplies a reason; the fallback is for hand-built reports.
        reason = getattr(report, "degraded_reason", "") or "(no reason recorded)"
        lines.append(f"- ⚠️ **DEGRADED** — {reason}")
    if failed:
        attempted = (m.chunks_attempted or m.chunks_total) if m else 0
        lines.append(f"- ⚠️ Degraded coverage: {failed}/{attempted} deep-dive "
                     "chunk(s) failed or timed out — their findings are "
                     "absent from this report. (Unit count, not files; needn't "
                     "match the file coverage % above.)")
    if errs:
        brk = ", ".join(f"{s}={n}" for s, n in sorted(errs.items()))
        # "Non-fatal", not "unrecovered": include_recovered=True here, unlike util/status.py's line
        lines.append(f"- Non-fatal errors logged by stage: {brk}")
    lines.extend(relents)
    lines.extend(unranked)
    if m and m.errors_log_path:
        lines.append(f"- Full error log: `{Path(m.errors_log_path).name}`")
    lines.append("")
    return lines

def _coverage_degraded_lines(report, reasons: tuple[str, ...]) -> list[str]:
    """One ``- ⚠️`` bullet, with its magnitude, per ``coverage_degraded()`` reason code."""
    m = report.metrics
    out: list[str] = []
    if "s6_undetermined" in reasons:
        # Denominator is every VERDICT reached, not the findings shipped; same pre-dedup pair
        n = report._undetermined_drop_count()
        tp, fp = report._verified_tp_fp()
        total = n + tp + fp
        out.append(
            f"- ⚠️ **Verification coverage loss** — {n} of {total} "
            f"verdicts were undetermined ({n / total * 100:.0f}%); those "
            "findings are neither confirmed nor cleared.")
    if "zero_analysis" in reasons:
        # s6_discovered rows are a model's judgement, so naming only a detector would understate
        _all_detector = all(rf.finding.origin == "detector"
                            for rf in report.findings)
        _source = ("from a deterministic detector, not a reviewed "
                   "analysis" if _all_detector else
                   "from detectors and the verifier's re-verify wave, "
                   "not a reviewed analysis")
        if m.deepdive_skipped:
            _source = "from external input and downstream processing, not S4 deep-dive analysis"
        out.append(
            f"- ⚠️ **No file reached deep-dive analysis** — "
            f"{m.total_files_in_scope} file(s) were in scope but 0 were "
            f"analysed (0% coverage), so every finding in this report "
            f"comes {_source}.")
    if "llm_turn_cap_exhausted" in reasons:
        out.append(
            f"- ⚠️ **Turn budget exhausted** — "
            f"{m.llm_turn_cap_exhausted} agentic session(s) exhausted "
            "their turn budget and were forced to answer from partial "
            "evidence. Their units still recorded outcome=completed: "
            "this discloses reduced depth, it does not mean those units "
            "failed.")
    return out

def _render_scope_appendix(report) -> list[str]:
    m = report.metrics
    out = ["", "---", "", "## Appendix: Scan Scope", ""]

    if m.folders_scanned:
        out.append(f"### Folders scanned ({len(m.folders_scanned)})")
        out.append("")
        # Repo-controlled names in code spans: without the backtick fold a dir name injects Markdown
        for d in m.folders_scanned:
            out.append(f"- `{_md_cell(d).replace(chr(96), chr(0x2CB))}/`")
        out.append("")

    ex = m.excluded or {}
    dd_dropped = (ex.get("config_dedup") or {}).get("dropped") or 0
    if dd_dropped or any(ex.get(k) for k in ("dirs", "exts", "globs",
                                             "oversize", "symlinks",
                                             "symlink_targets")):
        n_total = (sum((ex.get("dirs") or {}).values())
                   + sum((ex.get("exts") or {}).values())
                   + sum((ex.get("globs") or {}).values())
                   + (ex.get("oversize") or 0)
                   + sum((ex.get("symlinks") or {}).values())
                   + sum((ex.get("symlink_targets") or {}).values())
                   + dd_dropped)
        out.append(f"### Excluded from scan ({n_total} files)")
        out.append("")
        if ex.get("dirs"):
            out.append("**Folders** (matched `exclude_dirs`):")
            out.append("")
            for d, n in sorted(ex["dirs"].items(), key=lambda kv: -kv[1]):
                out.append(f"- `{_md_cell(d).replace(chr(96), chr(0x2CB))}/`"
                           f" — {n} file(s)")
            out.append("")
        if ex.get("exts"):
            out.append("**File types** (matched `exclude_exts`):")
            out.append("")
            for e, n in sorted(ex["exts"].items(), key=lambda kv: -kv[1]):
                out.append(f"- `*{_md_cell(e).replace(chr(96), chr(0x2CB))}`"
                           f" — {n} file(s)")
            out.append("")
        if ex.get("globs"):
            out.append("**Patterns** (matched `exclude_globs`):")
            out.append("")
            for g, n in sorted(ex["globs"].items(), key=lambda kv: -kv[1]):
                out.append(f"- `{_md_cell(g).replace(chr(96), chr(0x2CB))}`"
                           f" — {n} file(s)")
            out.append("")
        if ex.get("oversize"):
            out.append(f"**Oversize** (> `max_file_kb`): {ex['oversize']} files")
            out.append("")
            for path, sz in ex.get("oversize_files") or []:
                out.append(f"- `{_md_cell(path).replace(chr(96), chr(0x2CB))}`"
                           f" — {sz / 1024:.0f} KB")
            if ex.get("oversize_files"):
                out.append("")
        if ex.get("symlinks"):
            out.append("**Symlinks** (target resolves outside the repo — "
                       "not followed):")
            out.append("")
            for path, n in sorted(ex["symlinks"].items(),
                                  key=lambda kv: -kv[1]):
                out.append(f"- `{_md_cell(path).replace(chr(96), chr(0x2CB))}`"
                           + (f" — {n} files" if n != 1 else ""))
            out.append("")
        if ex.get("symlink_targets"):
            out.append("**Symlinks** (target is excluded from scope):")
            out.append("")
            out.extend(f"- `{_md_cell(path).replace(chr(96), chr(0x2CB))}`"
                       for path in sorted(ex["symlink_targets"]))
            out.append("")
        dd = ex.get("config_dedup") or {}
        if dd.get("dropped"):
            out.append(
                f"**Config dedup**: {dd['candidates']} config files -> "
                f"{dd['clusters']} shape-clusters; kept {dd['kept_reps']} "
                f"representatives + {dd['promoted']} promoted "
                f"(suspicious value), dropped {dd['dropped']} "
                f"near-duplicates.")
            out.append("")
            for c in dd.get("top_clusters") or []:
                out.append(
                    f"- `{_md_cell(c['sample']).replace(chr(96), chr(0x2CB))}`"
                    f" x{c['size']} "
                    f"(kept {len(c['reps'])}, dropped {c['dropped']})")
            if dd.get("promoted_files"):
                out.append("")
                out.append("Promoted (suspicious value not present in "
                           "cluster representative):")
                out.append("")
                # `why` names the matched KEY/rule, value stripped, but still derives from repo text
                for p, why in dd["promoted_files"]:
                    out.append(
                        f"- `{_md_cell(p).replace(chr(96), chr(0x2CB))}` — "
                        f"`{_md_cell(why).replace(chr(96), chr(0x2CB))}`")
            out.append("")

    return out
