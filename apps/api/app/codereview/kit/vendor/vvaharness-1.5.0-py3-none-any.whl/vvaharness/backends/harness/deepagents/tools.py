# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Logical->native tool-name resolution for the DeepAgents backend."""

# Must import no ``deepagents`` symbol: importable on 3.10, pinned by test_deepagents_optional

from __future__ import annotations

from typing import TYPE_CHECKING, Final

from langchain_core.tools import BaseTool

from vvaharness.backends.harness.models import (
    LOGICAL_TO_NATIVE,
    MCP_TOOL_PREFIX,
    MUTATING_TOOLS,
    ORCHESTRATION_TOOLS,
    StreamingOptions,
    ToolPolicy,
)
from vvaharness.util.warn_once import warn_once

if TYPE_CHECKING:
    from collections.abc import Sequence

#: Logical names deliberately absent from LOGICAL_TO_NATIVE; derived from the shared vocabularies
_UNMAPPED_BY_DESIGN: Final[frozenset[str]] = ORCHESTRATION_TOOLS | MUTATING_TOOLS

#: Unknown names already warned about; resolvers run per stage and sub-agent, so repeats flood
_WARNED_UNKNOWN_TOOLS: set[str] = set()


def _warn_unknown_tools(options: StreamingOptions, allowed: set[str]) -> None:
    """WARN once per distinct allow-listed name that resolves to no tool at all."""
    # Fail-safe: never raises, a typo must not abort a scan; prints the tool NAME only, never args
    known = LOGICAL_TO_NATIVE.keys() | _UNMAPPED_BY_DESIGN | set(options.fact_tools)
    for name in sorted(allowed - known):
        if name.startswith(MCP_TOOL_PREFIX):
            continue
        warn_once(
            _WARNED_UNKNOWN_TOOLS,
            name,
            f"WARN [deepagents]: unrecognised tool name {name!r} in the "
            f"allow-list — it maps to no tool on this backend and is ignored",
        )


def _allowed_tool_names(
    options: StreamingOptions, allowed_tools: Sequence[str] | None
) -> set[str]:
    """Resolve the effective allow-list: explicit *allowed_tools* else the policy's."""
    policy = options.tool_policy if options.tool_policy is not None else ToolPolicy()
    return set(allowed_tools if allowed_tools is not None else policy.allowed_tools)


def native_tool_names(
    options: StreamingOptions, allowed_tools: Sequence[str] | None
) -> tuple[str, ...]:
    """Resolve the logical allow-list to the native names this backend exposes."""
    allowed = _allowed_tool_names(options, allowed_tools)
    _warn_unknown_tools(options, allowed)
    return tuple(
        native for logical, native in LOGICAL_TO_NATIVE.items() if logical in allowed
    )


def session_tool_names(tools: Sequence[BaseTool]) -> frozenset[str]:
    """Names of the caller-built session tools, for the executor permit set."""
    # Fail closed: a nameless entry drops, _tool_name would WIDEN this allowlist, native names raise
    from vvaharness.backends.harness.deepagents.models import (  # noqa: PLC0415 — lazy: `.models` imports the deepagents distribution; a top-level import would break tests/test_deepagents_optional.py
        ALL_NATIVE_TOOLS,
    )

    names = frozenset(
        name
        for name in (getattr(tool, "name", None) for tool in tools)
        if isinstance(name, str)
    )
    reserved = names & ALL_NATIVE_TOOLS
    if reserved:
        raise ValueError(
            f"session tool name(s) {sorted(reserved)} collide with reserved "
            f"native tool names; rename them — permitting a native by way of a "
            f"session tool would bypass the executor-seam gate"
        )
    return names


def build_tools(
    options: StreamingOptions,
    *,
    allowed_tools: Sequence[str] | None,
) -> list[BaseTool]:
    """Build only the tools DeepAgents does not already provide."""
    # Returning [] is correct (natives come from middleware); WARN repeated: this is the prod path
    _warn_unknown_tools(options, _allowed_tool_names(options, allowed_tools))
    return []


__all__ = ["build_tools", "native_tool_names", "session_tool_names"]
