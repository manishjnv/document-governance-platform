# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Bringing your own findings: seed a stage's checkpoint, then resume from the stage after it."""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

from vvaharness.models import Finding, TaskManifest, ThreatModel
from vvaharness.orchestrator import store as _store
from vvaharness.orchestrator.checkpoints import run_id_for, save_ckpt

MAX_INJECTED_FINDINGS = 2_000

#: Stages whose checkpoint must also be seeded for a resumed run to skip discovery. `scan_repo`
#: gates every stage on its OWN checkpoint, so seeding s4 alone still RUNS s2 -- which is agentic
#: and costs a model call the caller explicitly did not ask for. s0/s1 are deliberately NOT seeded:
#: they are deterministic and free, and s1 builds the graph S6 verification reads.
DISCOVERY_STAGES: tuple[str, ...] = ("s2", "s3")


class HandoffError(ValueError):
    """Raised when findings cannot be handed to the pipeline."""


@dataclass(frozen=True)
class Handoff:
    """A seeded checkpoint: which run it belongs to, and how to resume onto it."""

    run_id: str
    stage: str
    finding_count: int
    skipped: tuple[str, ...] = ()

    @property
    def resume_argv(self) -> tuple[str, ...]:
        """The flag a scan needs to pick this up instead of recomputing the stage."""
        return ("--resume",)


def inject_findings(repo: Path | str, findings: Sequence[Finding], *,
                    skip_discovery: bool = True) -> Handoff:
    """Seeds the S4 checkpoint with *findings* so a resumed scan runs S5 onward on them."""
    if not findings:
        raise HandoffError("no findings to inject")
    if len(findings) > MAX_INJECTED_FINDINGS:
        raise HandoffError(
            f"{len(findings)} findings exceeds MAX_INJECTED_FINDINGS={MAX_INJECTED_FINDINGS}")
    bad = [f for f in findings if not isinstance(f, Finding)]
    if bad:
        raise HandoffError(f"every item must be a Finding; got {type(bad[0]).__name__}")
    repo_path = Path(repo).expanduser().resolve()
    if not repo_path.is_dir():
        raise HandoffError(f"repo is not a directory: {repo}")
    run_id = run_id_for(repo_path)
    ckpt_dir = _store.state_root() / "checkpoints" / run_id
    _store.register_run(run_id, repo_root=str(repo_path), repo_name=repo_path.name, app_id=None)
    save_ckpt(ckpt_dir, run_id, "s4",
              {"findings": list(findings), "outcomes": _outcomes(findings),
               "input_kind": "external"})
    skipped = _seed_discovery(ckpt_dir, run_id) if skip_discovery else ()
    return Handoff(run_id=run_id, stage="s4", finding_count=len(findings), skipped=skipped)


def _seed_discovery(ckpt_dir: Path, run_id: str) -> tuple[str, ...]:
    """Seeds empty s2/s3 checkpoints so the resumed run reports them cached instead of running."""
    save_ckpt(ckpt_dir, run_id, "s2", ThreatModel())
    save_ckpt(ckpt_dir, run_id, "s3", TaskManifest(units=[]))
    return DISCOVERY_STAGES


def _outcomes(findings: Sequence[Finding]) -> dict[str, str]:
    """One outcome per distinct origin, so S4's coverage tally names who supplied the findings."""
    origins = {str(getattr(f, "origin", None) or "external") for f in findings}
    return dict.fromkeys(sorted(origins), "injected")


__all__ = ["DISCOVERY_STAGES", "MAX_INJECTED_FINDINGS", "Handoff", "HandoffError",
           "inject_findings"]
