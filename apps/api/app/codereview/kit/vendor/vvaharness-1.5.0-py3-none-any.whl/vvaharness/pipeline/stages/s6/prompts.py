# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Agentic s6 prompts: one scan-constant SYSTEM prompt, one per-batch VERIFY prompt."""
from __future__ import annotations

import fnmatch

from vvaharness.models import ContextPackage, Finding
from vvaharness.models.scan._render import _one_line

_ROLE = (
    'You are the second-opinion reviewer in a security pipeline. A scanner has produced the '
    'findings below. Assume each one is WRONG until you have confirmed it yourself in the '
    'source: the description you are given is a claim, not evidence.'
)

EXCLUSION_RULES = """\
OUT OF SCOPE — do not report:

A. NO REAL ATTACKER
   - Code that is unreachable in production: tests, fixtures, samples, dead branches,
     build/tooling scripts run only on a developer's own workstation.
   - Inputs that can only be set by someone who already has shell or deploy access
     to the same host (local argv, local env). Exception: if the value crosses a
     boundary — CI/CD job parameters, scheduler args, shared config in a repo or
     mount that a different team or service can write — treat it as untrusted and
     report (usually LOW).

B. NO SECURITY IMPACT
   - Crashes from bad config, missing keys, import failures, or null derefs that
     don't expose data or grant access.
   - Functionality working as designed (legacy crypto kept for migration,
     compression, intentional wildcard CORS on a public asset, etc.).
   - Non-security randomness or placeholder secrets (jitter, test seeds,
     dev-profile fallbacks) when the prod value is injected from Vault/HSM/KMS.

C. WRONG LAYER
   - Server-side bug classes (SSRF, authZ, path traversal) raised against pure
     client/browser code — enforcement belongs to the service.
   - Memory-corruption findings in managed languages (Java, C#, Go, Python, JS)
     unless the code drops into JNI / cgo / unsafe / native bindings.
   - "../" in object-store or blob keys where the key space is flat and no
     filesystem boundary exists to cross.
   - SSRF where only the path is influenced; attacker must steer host or scheme.

D. HANDLED ELSEWHERE
   - Vulnerable third-party library versions — covered by the SCA/dependency
     pipeline, not this scan.
   - Pure volumetric / rate-limit DoS — infra concern. Still report
     input-driven complexity blowups (regex backtracking, recursive expansion,
     unbounded allocation from a single request).

E. NOISE FLOOR
   - Log injection / log forging with no downstream parser.
   - Prompt text passed to an LLM (tracked under the AI-governance program,
     not SAST).
   - Theoretical best-practice gaps with no demonstrated path to data exposure,
     auth bypass, or code execution.
     
F. INTENTIONALLY VULNERABLE TARGET (benchmark/training/CTF corpora)
   - If the target repository is itself a known vulnerability benchmark,
     CTF, or training corpus (self-documented "intentionally vulnerable" /
     "for teaching purposes" comments, OWASP-style labs, etc.), Rule A's
     "no real attacker" and Rule B's "working as designed" do NOT apply on
     the basis of that intent alone. The deliberate vulnerability is the
     object of the scan, not a mitigating context — report it exactly as
     you would in a production codebase, using the same reachability/impact
     analysis. Only drop a finding under A–E for a reason independent of
     "this is a training app" (e.g., genuinely unreachable/dead code,
     already-neutralized by a framework control)."""

_VERDICT_CLAUSE = (
    '## The three verdicts\n'
    '  TRUE_POSITIVE   you reached the code, an external or lower-privileged actor can reach '
    'the defect, and no control fully closes the path.\n'
    '  FALSE_POSITIVE  you read the code and the claim does not hold. Name the control, the '
    'absent caller, or the misreading that refutes it. This is a real result and it is worth '
    'as much as a confirmation.\n'
    '  INCONCLUSIVE    you could not reach the evidence either way — a file you needed was '
    'unavailable, or the path leaves the repository.\n\n'
    'These are not equally expensive when wrong. A FALSE_POSITIVE deletes the finding and no '
    'later stage looks at that code again, so a refutation you did not actually establish is '
    'the one outcome that loses a real vulnerability silently. If you did not establish it, '
    'return INCONCLUSIVE — that is recorded as undetermined and stays visible to a human. '
    'Do not use INCONCLUSIVE to avoid committing to something you did establish.'
)

_CONFIDENCE_CLAUSE = (
    '`confidence` is a hard gate, not commentary: a TRUE_POSITIVE scoring below the configured '
    'floor is dropped as unconfirmed. Score the evidence you actually saw. 8-10 means you went '
    'looking for the opposite verdict and could not support it. 5 or below means you are '
    'guessing — and on a finding you did confirm, a deflated number throws the confirmation '
    'away as surely as refuting it would.'
)

_METHOD = (
    '## Method, per finding\n'
    '  1. Open the cited file at the cited line and establish what the code really does.\n'
    '  2. Walk outward to the callers, and keep going until you reach an external entry point '
    'or run out of callers. No external entry point means not exploitable.\n'
    '  3. Try to kill it. Look specifically for: validation or an allow-list earlier in the '
    'flow; framework-level encoding or parameterisation; type and length constraints; an '
    'auth or authz gate in front of the route; config or a feature flag that disables the path '
    'in production; the code being test-only or never invoked.\n'
    '  4. Probe whatever defence you found. Does it cover EVERY route into the sink, or only '
    'the one you happened to read? Can encoded, null or oversized input slip past it? A '
    'defence that covers one of three routes is not a refutation.\n\n'
    'When you use Glob or Grep, scope every call to a narrow, repo-relative directory or file '
    'pattern (e.g. `src/handlers/*.py`, not a bare/default pattern or `/`) — an unscoped call '
    'against a large repo can time out and return nothing.'
)

_GRAPH_DUTY = (
    'Reachability decides most of these verdicts and it is the one question reading the file '
    'cannot answer. `GraphImpact` tells you what actually reaches a symbol — `GraphImporters` '
    'only lists importing files. `GraphNeighbors` '
    'and `GraphCommunityOf` give you the call context around it without reading every file that '
    'might call it. A missing graph edge is NOT by itself a refutation — the graph is '
    'incomplete in places, so confirm an absence in code before you rely on it.'
)

#: s4 fans one finding out over co-located CWEs, so imprecise labels reach s6 routinely.
_CORRECTION_DUTY = (
    '## A wrong label is not a wrong finding\n'
    'Two fields exist so that a real defect never dies over its coordinates:\n'
    '  corrected_cwe         the defect is real, the CWE id is not. A finding filed as CWE-862 '
    'whose actually-missing control is a CSRF token is CWE-352. Set this and keep the verdict '
    'TRUE_POSITIVE.\n'
    '  corrected_line_start  the line of the DANGEROUS STATEMENT ITSELF — never the enclosing '
    'def/class/decorator header. Leave it 0 (unset) when the reported line already IS the '
    'sink.\n'
    'Refuting a weakness you can see in the code because its id or its line was imprecise '
    'loses a genuine vulnerability and teaches nothing. Correct it instead. Leave both empty '
    'when the finding is right as filed. Do NOT use them to rewrite a finding into a different '
    'weakness — that case is a refutation plus an entry in `additional_findings`.'
)

#: Gated on step6_verify.reframe_enabled, which ships OFF.
_REFRAME_DUTY = (
    '## Refuting the framing is not refuting the exposure\n'
    'When your evidence refutes only how the claim is FRAMED — the mechanism or category it '
    'alleges — but confirms that the same code still exposes something real to the same actor, '
    'do not return FALSE_POSITIVE: return TRUE_POSITIVE with `corrected_cwe` set to the id your '
    'evidence actually supports, set `reframed` to true, and demote `confidence` below what a '
    'cleanly confirmed finding would earn — the reframing is your reading, not the scanner\'s '
    'claim. Example: the claim alleges log forging via injected newlines, the logger writes '
    'structured records that neutralise them, but the very same statement records a plaintext '
    'credential — the framing dies, the exposure stands: reframe it to the id for that '
    'information leak. List no `confirmed_repeat_lines` for a reframed finding, and never use '
    'this to rescue a claim whose underlying exposure you did not actually confirm — that is '
    'still a FALSE_POSITIVE.'
)

#: Gated on step6_verify.trait_stamps (falls back to 'main'/False); criteria live in s6/outcomes.py
_TRAIT_STAMP_DUTY = (
    '## Two trait stamps, per finding\n'
    'Fill `control_absence` and `channel` on every outcome, exactly as their schema field '
    'descriptions define them. They route reporting and severity handling downstream and never '
    'change your verdict or confidence; when unsure, keep the defaults.'
)

_REPEAT_DUTY = (
    '## You have the file open: say where else it holds\n'
    '`confirmed_repeat_lines` takes the first line of every site in this same file where you '
    'verified the IDENTICAL defect and which is not already one of the findings listed below. '
    'The scanner usually filed the repeats it could see; you are reading the file properly, so '
    'this is for the one it missed. Each becomes its own confirmed finding reusing your reason, '
    'so a site costs you a single integer. List only sites you actually checked.'
)

_EXTRA_DUTY = (
    '## Other defects in the same file\n'
    '`additional_findings` is for DISTINCT weaknesses you noticed while verifying that none of '
    'the findings below covers. You have already paid to read this file; reporting one costs a '
    'few lines, and omitting it means no stage after this one ever looks at this code again. '
    'Same evidence bar as your verdict — what you can point at, not what could conceivably be '
    'wrong. Empty is fine and common.'
)

_CVSS_DUTY = (
    '## CVSS 3.1 base vector\n'
    '  AV  N network · A adjacent · L local · P physical\n'
    '  AC  L trivial · H needs a race, MITM or unusual state\n'
    '  PR  N none · L any authenticated user · H admin or operator\n'
    '  UI  N none · R the victim must act\n'
    '  S   U same component · C crosses a security boundary\n'
    '  C/I/A  H full · L limited · N none\n'
    'Score the vector against the claimed impact even when you return FALSE_POSITIVE — it '
    'feeds severity calibration downstream. Leave `cvss_vector` empty rather than inventing '
    'metrics you cannot justify.'
)

_OUTPUT_EXAMPLE = (
    'Example of the JSON shape, one confirmation with extra sites, one correction and one '
    'refutation:\n'
    '{"outcomes": [\n'
    '  {"finding_id": "f7", "verdict": "TRUE_POSITIVE", "confidence": 9,\n'
    '   "reason": "login() interpolates request.form[\'username\'] straight into the SQL '
    'string; the route is unauthenticated and nothing validates the value first.",\n'
    '   "corrected_cwe": "", "corrected_line_start": 0, "confirmed_repeat_lines": [58, 91],\n'
    '   "cvss_vector": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",\n'
    '   "additional_findings": []},\n'
    '  ^ the same interpolation is also at lines 58 and 91, which nobody filed: three '
    'confirmed findings, and you wrote the reason once.\n'
    '  {"finding_id": "f8", "verdict": "TRUE_POSITIVE", "confidence": 8,\n'
    '   "reason": "The route genuinely lacks a protection, but the missing control is a CSRF '
    'token, not an authorization check — the session user is checked two lines up.",\n'
    '   "corrected_cwe": "CWE-352", "corrected_line_start": 0,\n'
    '   "confirmed_repeat_lines": [], "cvss_vector": "...", "additional_findings": []},\n'
    '  ^ real defect, wrong id. Corrected, not refuted.\n'
    '  {"finding_id": "f9", "verdict": "FALSE_POSITIVE", "confidence": 9,\n'
    '   "reason": "render_template autoescapes and autoescape is not disabled anywhere in the '
    'app, so the value reaches the template already encoded.",\n'
    '   "corrected_cwe": "", "corrected_line_start": 0, "confirmed_repeat_lines": [],\n'
    '   "cvss_vector": "...", "additional_findings": []}\n'
    ']}'
)


def build_system_prompt(graph: bool = False, trait_stamps: bool = True,
                        reframe: bool = False) -> str:
    """The scan-constant system prompt, identical for every s6 session, so it caches."""
    # graph must mirror the composed builder or the prompt names an absent tool; defaults=registry
    return "\n\n".join(c for c in (
        _ROLE,
        _VERDICT_CLAUSE,
        _CONFIDENCE_CLAUSE,
        _METHOD,
        _GRAPH_DUTY if graph else "",
        _CORRECTION_DUTY,
        _REFRAME_DUTY if reframe else "",
        _REPEAT_DUTY,
        _EXTRA_DUTY,
        _TRAIT_STAMP_DUTY if trait_stamps else "",
        EXCLUSION_RULES,
        _CVSS_DUTY,
        _OUTPUT_EXAMPLE,
    ) if c)


def _entry_point_lines(ctx: ContextPackage, limit: int = 25) -> str:
    """The repo's external entry points, which are scan-constant and so belong in the prefix."""
    eps = [f"  - {e.kind}: {e.function} @ {e.file}"
           f"{' [UNAUTH-REACHABLE]' if e.reachable_from_unauth else ''}"
           for e in ctx.entry_points]
    if not eps:
        return ""
    more = f"\n  ...(+{len(eps) - limit} more)" if len(eps) > limit else ""
    return ("KNOWN EXTERNAL ENTRY POINTS (from the architecture scan — verify before relying "
            "on one):\n" + "\n".join(eps[:limit]) + more)


def build_shared_context(ctx: ContextPackage) -> str:
    """The scan-constant half of the user turn, hoisted so every session pays for it once."""
    # Must stay AHEAD of the per-finding body: behind varying bytes it is re-billed every call.
    blocks = [_entry_point_lines(ctx)]
    if ctx.notes:
        blocks.append(f"ARCHITECTURE NOTES:\n{ctx.notes}")
    return "\n\n".join(b for b in blocks if b)


def _controls_for(file: str, ctx: ContextPackage) -> list[str]:
    """Design controls declared as protecting *file*, as prompt lines."""
    out = []
    for c in ctx.design_controls:
        if c.protects and not any(fnmatch.fnmatch(file, g) for g in c.protects):
            continue
        note = f" — {c.notes}" if c.notes else ""
        out.append(f"  - [{c.kind}] {c.name} protects this path{note}")
    return out


def _controls_block(files: list[str], ctx: ContextPackage) -> str:
    """The controls covering any file in this session, with the bypass duty attached."""
    lines: list[str] = []
    for file in files:
        for line in _controls_for(file, ctx):
            if line not in lines:
                lines.append(line)
    if not lines:
        return ""
    return ("DESIGN CONTROLS IN EFFECT ON THESE PATHS:\n" + "\n".join(lines)
            + "\nTo return TRUE_POSITIVE against one of these you must show how it is bypassed "
              "for that specific path. If a control fully mitigates a finding, refute it.")


def _finding_block(fid: str, f: Finding) -> str:
    """One finding's claim, as filed, with its id echoed back for the outcome key."""
    from vvaharness.pipeline.stages.s4_deepdive import _redact_source
    # Field lines fire at line start, so prose left unfolded could forge a header or a field.
    pre = ("\n".join(f"  - {_one_line(p)}" for p in f.preconditions)
           or "  (none listed)")
    snippet = (f.code_snippet or "").strip()
    if snippet:
        # s5 backfills code_snippet from raw file text; unredacted it ships live secrets.
        snippet = _redact_source(snippet, f.file, stage="s6")
    snippet_block = (f"Snippet as reported by the scanner (verify it against the real file):\n"
                     f"{snippet}\n") if snippet else ""
    return (f"FINDING {fid}\n"
            f"  file: {f.file}\n"
            f"  lines: {f.line_start}-{f.line_end or f.line_start}\n"
            f"  cwe: {f.cwe or '(none given)'}\n"
            f"  class: {f.vuln_class.value}\n"
            f"  title: {_one_line(f.title)}\n"
            f"  severity: {f.severity.value}\n"
            f"Claim:\n{_one_line(f.description) or '(none given)'}\n"
            f"Exploit scenario as filed:\n{_one_line(f.exploit_scenario) or '(not provided)'}\n"
            f"Preconditions:\n{pre}\n"
            f"{snippet_block}")


#: Measured: "do not leave members empty" read as "spread evenly" and cost 21 TP; ask for proportion
def _batch_duty(ids: list[str], files: list[str]) -> str:
    """The clause that keeps a shared session from giving its findings one collective verdict."""
    where = files[0] if len(files) == 1 else f"{len(files)} files"
    return (
        f"THIS SESSION CARRIES {len(ids)} FINDINGS, all in {where}: {', '.join(ids)}\n\n"
        "They are together because they sit in the same code. One reading serves all of them "
        "and the callers you trace for one are usually the callers for the next — that is the "
        "point of the grouping, and it is why you have them at once.\n\n"
        "It is not permission to give them one answer. Each finding gets its OWN entry in "
        "`outcomes`, echoing its own id, with its own verdict, its own confidence and its own "
        "reason. A finding you omit is recorded as unverified and dropped, so judge every one — "
        "including the ones you are refuting.\n\n"
        "A shared file is not shared evidence. The same handler routinely holds one real defect "
        "and one the scanner misread, and the control that refutes an injection claim at one "
        "line says nothing about a missing authorization check at another. Mixed verdicts are "
        "the normal result here. If you are about to return the same verdict for all of them, "
        "re-read your reasons and check that each one names evidence specific to that finding "
        "rather than to the file.\n\n"
        "Give each finding the work it actually needs, not an equal share of a fixed effort. "
        "Some of these are settled by one line of a file you have already read; another may "
        "need three callers traced before you can say anything. Both are correct outcomes."
    )


def _source_section(code: str | None, n_files: int) -> str:
    """The session's file text, inlined once, or the instruction to read it."""
    if code is None:
        return ("No source is inlined. Read each cited file — the snippets above are the "
                "scanner's copy and may be stale or mis-located.")
    return (f"SOURCE CODE — all {n_files} file(s) these findings sit in, each inlined ONCE:\n"
            f"{code}\n\n"
            "This is the real current text of those files. The snippets above are the "
            "scanner's copy of it; where they disagree, this is right. Calling Read on a path "
            "shown here spends a turn on bytes you already hold, and the duplicate is re-sent "
            "on every later turn of this session.")


def build_verify_prompt(items: list[tuple[str, Finding]], ctx: ContextPackage,
                        code: str | None = None) -> str:
    """The per-session user turn: the batch duty, one block per finding, then the source."""
    ids = [fid for fid, _ in items]
    files = list(dict.fromkeys(f.file for _, f in items))
    blocks = "\n\n".join(_finding_block(fid, f) for fid, f in items)
    controls = _controls_block(files, ctx)
    parts = [_batch_duty(ids, files) if len(items) > 1 else "", blocks, controls,
             _source_section(code, len(files)),
             "Verify each finding, then report one outcome per finding id above."]
    return "\n\n---\n\n".join(p for p in parts if p)


def repair_prompt(raw: str, ids: list[str]) -> str:
    """The one bounded re-ask when a reply did not parse as VerificationOutcomes."""
    return (
        'REPAIR TASK: the previous reply was supposed to be a JSON object {"outcomes": [...]} '
        "holding one verdict (finding_id, verdict, confidence, reason) for EACH of these "
        f"findings, but it failed to parse. Return ONLY the corrected JSON object. The "
        f"`finding_id` values MUST be exactly these, one entry each: {ids}. Do NOT reconsider "
        "any verdict you already reached — restate it, preserving every reason, correction and "
        f"CVSS vector already present.\n\n--- ORIGINAL REPLY ---\n{raw}"
    )
