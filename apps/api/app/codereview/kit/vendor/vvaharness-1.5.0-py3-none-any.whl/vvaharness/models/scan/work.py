# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The work units s3 emits: one InvestigationUnit per threat, plus the TaskManifest holding them."""
from __future__ import annotations

import logging
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, field_validator

from vvaharness.models.scan._coerce import _coerce_enum, _coerce_int, _coerce_str_list
from vvaharness.models.scan.surface import EntryPoint, Sink
from vvaharness.models.scan.threat import ThreatModel
from vvaharness.models.vocab import VulnClass

log = logging.getLogger(__name__)

class UnitSize(StrEnum):
    SMALL = "small"      # fits in one context, exhaustive
    MEDIUM = "medium"    # fits, but tight
    LARGE = "large"      # too big to inline — file list + sink hints, model Reads on demand


_UNIT_SIZES = {"small", "medium", "large"}
_UNIT_SIZE_ALIAS = {
    "xs": "small", "tiny": "small", "s": "small",
    "m": "medium", "med": "medium", "moderate": "medium",
    "normal": "medium", "default": "medium",
    "l": "large", "xl": "large", "xxl": "large",
    "big": "large", "huge": "large", "x_large": "large",
}


def threat_unit_id(threat_id: str) -> str:
    """The unit id s3 mints for a threat; collisions add -N, so the bare id always exists."""
    return f"threat-{threat_id.lower()}"


class InvestigationUnit(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    id: str                          # "threat-t8"
    threat: str                      # the claim to confirm or refute
    surface: str                     # prose attack surface, from Threat.surface
    actor: str                       # who is attacking — Threat.actor's Literal, carried as str
    asset: str                       # what is at stake — Threat.asset
    impact: str                      # Threat.impact's Literal, carried as str
    likelihood: str                  # Threat.likelihood's Literal, carried as str
    controls: str = ""               # what already defends this — Threat.controls
    evidence: str = ""               # where s2 saw it — Threat.evidence
    files: list[str] = Field(default=[], alias="file_ids")  # this threat's whole validated surface, uncut
    sinks: list[Sink] = []           # ctx.unsafe_sinks joined on `file in files` — file:line, snippet, cwe
    entry_points: list[EntryPoint] = []  # ctx.entry_points joined on `file in files`
    related_cves: list[str] = []     # ctx.known_cves joined on affected_files ∩ files
    cwes: list[str] = []             # derived: union of sinks[].cwe — the CweGuidance lookup keys
    communities: list[str] = []      # call-graph community name(s) files fall in — a tool-arg annotation,
                                      # NOT a splitter; order-dependent on ctx.modules, cosmetic only
    risk_rank: int = 999             # 26 - impact*likelihood; 1 = highest risk, descending
    size: UnitSize = UnitSize.MEDIUM
    languages: list[str] = []        # detected from file extensions (s3)

    @field_validator("size", mode="before")
    @classmethod
    def _v_size(cls, v):
        return _coerce_enum(v, _UNIT_SIZES, _UNIT_SIZE_ALIAS, "medium")

    @field_validator("risk_rank", mode="before")
    @classmethod
    def _v_rank(cls, v):
        return _coerce_int(v, 999)

    @field_validator("files", "related_cves", "cwes", "communities", "languages",
                     mode="before")
    @classmethod
    def _v_str_list(cls, v, info):
        return _coerce_str_list(v, f"InvestigationUnit.{info.field_name}")


class TaskManifest(BaseModel):
    units: list[InvestigationUnit]
    # Files dropped by the ctx.all_files check; the report appendix lists them so coverage is auditable.
    unreachable_files: list[str] = []
    # Threats with no validated surface file, so they never minted a unit; kept for audit.
    threats_without_unit: list[str] = []

    @field_validator("unreachable_files", mode="before")
    @classmethod
    def _v_unreachable_files(cls, v):
        return _coerce_str_list(v, "TaskManifest.unreachable_files")

    @field_validator("threats_without_unit", mode="before")
    @classmethod
    def _v_threats_without_unit(cls, v):
        return _coerce_str_list(v, "TaskManifest.threats_without_unit")

    def sorted_units(self) -> list[InvestigationUnit]:
        return sorted(self.units, key=lambda u: u.risk_rank)

    def threats_without_unit_for(self, tm: ThreatModel | None) -> list[str]:
        """*tm*'s threats with no unit here; s3's recorded drops when there is no *tm*."""
        # Derived from the units, not read off s3's list: on --resume a re-run s2 can pair with a
        # cached manifest built from an older threat model, and absence must not read as minted
        if tm is None:
            return list(self.threats_without_unit)
        minted = {u.id for u in self.units}
        return [tid for tid in tm.threat_ids() if threat_unit_id(tid) not in minted]


class DupLocation(BaseModel):
    """A dedup-collapsed finding, kept on `Finding.duplicates` so every site is still reported."""
    file: str
    line_start: int
    line_end: int = 0
    vuln_class: VulnClass
    title: str = ""
    chunk_id: str = ""
    source_ref: str | None = None
    sink_ref: str | None = None
    reasoning: str = ""              # why dedup merged this into the canonical
