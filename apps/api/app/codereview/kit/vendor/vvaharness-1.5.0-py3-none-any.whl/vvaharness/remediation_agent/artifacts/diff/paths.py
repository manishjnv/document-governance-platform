# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Repo-relative path normalisation + repo confinement (CWE-22) shared by every diff artifact."""
from __future__ import annotations

import re
from pathlib import Path

from vvaharness.util import logs

log = logs.get_logger(__name__)

# Path.is_absolute() only sees UNC/drive prefixes ON Windows; a POSIX runner would leak NetNTLMv2
_UNC_OR_DRIVE = re.compile(r"^(?:[\\/]{2}|[A-Za-z]:)")


def _norm_path(ref: str) -> str:
    """Normalise a finding/verdict file reference to a clean repo-relative path."""
    ref = (ref or "").strip()
    if not ref:
        return ""
    # Strip only a trailing ``:<line>`` / ``:<start-end>`` suffix — a drive-letter colon must survive.
    return re.sub(r":\d+(?:-\d+)?$", "", ref)


def _safe_repo_path(repo: Path, ref: str) -> Path | None:
    """Resolve a file reference to a path confined to *repo*, or ``None`` when it escapes."""
    # LLM refs: abs/../symlink escape reads arbitrary files (CWE-22); revert_files reuses this
    rel = _norm_path(ref)
    if not rel or Path(rel).is_absolute() or _UNC_OR_DRIVE.match(rel):
        return None
    try:
        target = (repo / rel).resolve()
        target.relative_to(repo.resolve())
    except (ValueError, OSError):
        return None
    return target
