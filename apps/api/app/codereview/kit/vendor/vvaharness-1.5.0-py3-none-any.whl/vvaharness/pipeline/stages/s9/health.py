# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Builds S9's scan-health block for the SARIF."""
from __future__ import annotations

from vvaharness.models import FinalReport


def scan_health(report: FinalReport) -> dict:
    """Returns the degradation facts the SARIF emitter stamps onto the run invocation."""
    m = report.metrics
    empty_scope = bool(m is not None and not m.total_files_in_scope)
    coverage_degraded_reasons = report.coverage_degraded()
    return {
        # WS3b: false only for empty scope; a pre-S9 death emits no SARIF, so stage failure is moot
        "executionSuccessful": not empty_scope,
        # Shared with the Markdown renderer; a second copy let SARIF and report disagree
        "hollow": report.is_hollow(),
        "degraded": report.degraded,
        "degraded_reason": report.degraded_reason,
        # Narrower than degraded: chains=[] is not a trustworthy zero result
        "enrichment_unavailable": report.enrichment_unavailable,
        # Coverage loss only, distinct from "degraded" and "hollow".
        "coverage_degraded": bool(coverage_degraded_reasons),
        "coverage_degraded_reasons": list(coverage_degraded_reasons),
        "chunks_failed": m.chunks_failed if m else 0,
        "deepdive_skipped": m.deepdive_skipped if m else False,
        "errors_by_stage": (m.errors_by_stage if m else {}),
        # Threats s3 minted no unit for; shared with _sections_pipeline.py Pipeline Diagnostics.
        # None (not []) = a payload that predates the field, so coverage is unknown, not full
        "threats_total": len(report.threat_model.threats) if report.threat_model else 0,
        "threats_without_unit": (None if report.threats_without_unit is None
                                 else list(report.threats_without_unit)),
        # Pre-cap, so a consumer can see threats_total is post-cap 
        "threats_before_cap": m.s2_threats_raw if m else 0,
        "threats_truncated": m.s2_threats_truncated if m else 0,
        "threats_promoted": m.s2_threats_promoted if m else 0,
    }
