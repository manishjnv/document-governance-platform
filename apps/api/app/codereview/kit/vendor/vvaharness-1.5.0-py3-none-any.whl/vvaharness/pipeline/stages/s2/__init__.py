# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 2 — the application threat model, reasoned over s1's mapped attack surface."""
from __future__ import annotations
from vvaharness.util import logs

import re
from pathlib import Path

# Module import keeps the monkeypatch seam for tests.
from langchain.agents.middleware import TodoListMiddleware

from vvaharness.backends.harness.deepagents.evidence_gate import EvidenceGate
from vvaharness.backends.harness.deepagents.tool_budget import ToolCallBudget
from vvaharness.backends.llm import deepagents as _deepagents
from vvaharness.backends.llm.models import (
    RESPONSE_MODEL_VIAS,
    refusal_resend_allowed,
    validate_detection_tools,
)
from vvaharness.backends.llm.registry import resolve
from vvaharness.codegraph.build import graph_is_degenerate
from vvaharness.codegraph.tools import (
    GRAPH_TOOL_NAMES,
    build_graph_tool_builder,
    graph_tool_names,
)
from vvaharness.evidence import (
    ThreatEvidence,
    _cap_int,
    gather,
    render_api_artefacts_block,
    render_components_block,
    render_config_reps_block,
    render_docs_block,
    render_entry_points_block,
    render_inventory_block,
    render_language_block,
    render_manifests_block,
    render_modules_block,
)
from vvaharness.models import (
    CVE,
    AppProfile,
    ContextPackage,
    Control,
    Threat,
    ThreatModel,
    _cap_assets,
    _cap_boundaries,
    _cap_threats,
)
from vvaharness.pipeline.stages.s2_planning import (
    PLAN_SYSTEM_PROMPT as S2_PLAN_SYSTEM_PROMPT,
)
from vvaharness.pipeline.stages.s2_planning import (
    PLAN_TOOL_DESCRIPTION as S2_PLAN_TOOL_DESCRIPTION,
)
from vvaharness.report.redact import redact
from vvaharness.rules.repo_kinds import BASELINES, STRIDE_BY_KIND, repo_kind
from vvaharness.scope import resolve_inventory_path
from vvaharness.skills import inject_skills
from vvaharness.util import console
from vvaharness.util import errlog as _errlog
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.json_extract import extract_json
from vvaharness.util.response_quality import dispatch_or_retry_unforced
from vvaharness.util.warn_once import warn_once

log = logs.get_logger(__name__)


from vvaharness.pipeline.stages.s2.baseline import (
    _BASELINE_EVIDENCE_RX,
    _baseline_audit,
    _category_covered_elsewhere,
    _category_terms,
    _required_baselines,
)
from vvaharness.pipeline.stages.s2.outcomes import (
    _finalize_threats,
    _parse_threat_model,
    _warn_output_caps,
)
from vvaharness.pipeline.stages.s2.prompts import (
    SYSTEM,
    _AGENTIC_SYSTEM_LINE,
    _GRAPH_TOOLS_SYSTEM_LINE,
    _baseline_block,
    _build_user_prompt,
    _repair_json_prompt,
)
from vvaharness.pipeline.stages.replay import (
    RecordTranscript,
    Transcript,
    replay_prompt,
    run_with_deadline,
)
from vvaharness.pipeline.stages.s2.session import (
    _DISPATCH_TAG,
    _WARNED_DEGENERATE_GRAPH,
    _WARNED_NO_GRAPH_TOOLS,
    _graph_tool_route_ok,
    _retry_if_hollow,
    _threatmodel_call,
)
from vvaharness.util.events import Event

__all__ = ["RecordTranscript", "SYSTEM", "Transcript", "gather", "replay_prompt",
           "run", "run_with_deadline"]


def run(repo_root: str, repo_name: str, cfg,
        known_cves: list[CVE], controls: list[Control],
        ctx: ContextPackage | None = None,
        app_profile: AppProfile | None = None) -> ThreatModel:
    s2 = getattr(cfg, "step2", None)
    tracker = getattr(cfg, "_scan_progress", None)
    log.info("s2/threatmodel: starting threat modeling for %s", repo_name)
    if ctx is not None:
        log.debug("s2/threatmodel: context has_ast_view=%s files=%d",
                  hasattr(ctx, 'ast_context_view'), len(getattr(ctx, 'all_files', []) or []))
    ev = gather(repo_root, cfg, ctx)
    note = console.counts("s2", "evidence", files=ev.file_count, modules=len(ev.modules),
                          entry_points=len(ev.entry_points), config_reps=len(ev.config_reps),
                          api_artefacts=len(ev.api_artefacts), docs=len(ev.docs),
                          manifests=len(ev.manifests))
    if tracker is not None:
        tracker.stage_note("s2", f"evidence {note}")
    console.write(f"  [s2] frontier: {ev.file_count} / {ev.original_file_count} files "
                  f"(AST-focused evidence view)")

    baseline_mode = getattr(s2, "baseline", "auto")
    kinds, baseline = _baseline_block(ev, ctx, baseline_mode)
    COUNTERS.note("s2_repo_kinds", ",".join(sorted(kinds)))
    console.write(f"  [s2] baseline={baseline_mode} repo_kind={sorted(kinds) or '-'}")

    user = _build_user_prompt(repo_name, ev, known_cves, controls,
                              app_profile=app_profile,
                              baseline_block=baseline)
    if tracker is not None:
        tracker.stage_note("s2", "threat-model LLM request started")

    effort = getattr(s2, "effort", None) or None
    try:
        # A memoised model or manual thinking can still drop forced tool_choice (a session may
        # end on prose), and the tier's thinking shares step2.max_tokens: either failure gets
        # one resend without it
        raw = dispatch_or_retry_unforced(
            lambda *, drop_thinking: _threatmodel_call(user, cfg, repo_root, ctx,
                                                       drop_thinking=drop_thinking,
                                                       require_tool_call=ev.file_count > 0),
            repo_name, stage="s2",
            effort=_deepagents.droppable_effort(cfg.models.threatmodel, effort, agentic=True),
            may_retry=lambda: bool(getattr(s2, "empty_retry", True)),
            resend_refusal=refusal_resend_allowed(cfg, cfg.models.threatmodel))
    except Exception as e:
        # Record-then-raise, never swallow: swallowing reads as a stage that merely found
        # nothing. One record even after a failed retry (one bad reply != two failures).
        log.error(Event.S2_CALL_FAILED, detail=redact(str(e)))
        _errlog.log("s2", repo_name, e, reason="threat_model_call_failed")
        raise
    if tracker is not None:
        tracker.stage_note("s2", "threat-model LLM response received")

    try:
        tm = _parse_threat_model(raw)
    except Exception as parse_err:
        # Repair keeps the full step2 caps: it re-emits the FULL model, so a smaller cap truncates
        console.write(f"  [s2] threat-model response did not parse, retrying repair "
                      f"— {parse_err}")
        # Deliberately NOT errlogged: a non-zero errors_by_stage reads as degraded; counter instead
        COUNTERS.bump("s2_parse_repair_attempted")
        repaired = None
        try:
            # Same dispatch seam: the registry has no deepagents backend, so registry.prompt raises
            repaired = _deepagents.dispatch_prompt(
                _repair_json_prompt(raw, parse_err),
                model=cfg.models.threatmodel,
                cfg=cfg,
                cwd=repo_root,
                system_prompt=SYSTEM,
                max_tokens=getattr(s2, "max_tokens", 64000),
                timeout=_cap_int(s2, "timeout", 1800),
                tag="s2 threatmodel json-repair",
            )
            tm = _parse_threat_model(repaired)
        except Exception as e:
            # No threat model != found nothing: the raise makes the orchestrator bump s2_degraded
            log.error(Event.S2_RESPONSE_UNPARSEABLE, detail=str(e))
            # redact the FULL text BEFORE the [:500] cut, or capping first leaks a bisected secret
            _errlog.log("s2", repo_name, e,
                        reason="threat_model_parse_failed",
                        raw_head=redact((repaired if repaired is not None
                                         else raw) or "")[:500],
                        note="s2 JSON extraction or model validation failed "
                             "after one repair retry; s3–s8 will receive no "
                             "threat context")
            raise
        COUNTERS.bump("s2_parse_repair_recovered")
        log.warning(Event.S2_PARSE_REPAIR_RECOVERED)

    _finalize_threats(tm, ctx)

    tm = _retry_if_hollow(tm, ev, user, cfg, repo_root, ctx)

    if not tm.threats:                    # success path, not inside an except —
        # DELIBERATELY UNMARKED: the only signal of a vacuous reply; completed_with_errors is meant
        _errlog.log(
            "s2", "threatmodel",
            "zero threats — s3's per-threat annotator has nothing to "
            "annotate; the run proceeds with no threat-derived targeting",
        )
        if ev.file_count > 0:
            # Becomes Metrics.s2_degraded; a zero-file repo stays un-bumped, nothing to model
            COUNTERS.bump("s2_degraded")

    # Audit BEFORE the cap: baseline threats are low-likelihood, so they rank last and truncate
    undisposed = _baseline_audit(tm, kinds)

    max_threats = _cap_int(s2, "max_threats", 50)
    max_assets = _cap_int(s2, "max_assets", 40)
    max_boundaries = _cap_int(s2, "max_trust_boundaries", 60)
    raw_counts = (len(tm.threats), len(tm.assets), len(tm.trust_boundaries))
    tm = _cap_threats(tm, max_threats)
    tm = _cap_assets(tm, max_assets)
    tm = _cap_boundaries(tm, max_boundaries)
    _warn_output_caps(raw_counts, tm, (max_threats, max_assets, max_boundaries))

    # A count tells an operator nothing actionable; the ids themselves do.
    COUNTERS.note("s2_baseline_undisposed", ",".join(sorted(undisposed)))
    if undisposed:
        # The ids NOT undisposed are available to cover an undisposed id's alias
        disposed = _required_baselines(kinds) - set(undisposed)
        # ALL covered elsewhere is a note; a PARTIAL match must not be marked recovered=True
        all_covered_elsewhere = all(
            _category_covered_elsewhere(bid, tm.threats, disposed=disposed)
            for bid in undisposed)
        if all_covered_elsewhere:
            _errlog.log("s2", repo_name, "baseline items undisposed",
                        reason="baseline_items_undisposed",
                        baseline_ids=sorted(undisposed),
                        recovered=True)
            COUNTERS.bump("s2_baseline_undisposed_recovered")
        else:
            # DELIBERATELY UNMARKED: s3 targets units off baseline threats, so this is a real gap
            _errlog.log("s2", repo_name, "baseline items undisposed",
                        reason="baseline_items_undisposed",
                        baseline_ids=sorted(undisposed))
        log.warning(Event.S2_BASELINE_UNDISPOSED, count=len(undisposed),
                    baseline_ids=sorted(undisposed),
                    covered_elsewhere=all_covered_elsewhere)

    console.counts("s2", "done", assets=len(tm.assets),
                   trust_boundaries=len(tm.trust_boundaries), threats=len(tm.threats))
    log.info("s2/threatmodel: threat model complete - assets=%d boundaries=%d threats=%d",
             len(tm.assets), len(tm.trust_boundaries), len(tm.threats))
    return tm
