# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""S11 for one in-memory case, so a caller never has to write a case file to disk to validate it."""
from __future__ import annotations

import asyncio
import shutil
import tempfile
import uuid
from datetime import UTC, datetime
from pathlib import Path

from vvaharness.models import (
    Finding,
    FindingCase,
    Provenance,
    Remediation,
    ScoringPolicy,
    Verdict,
)
from vvaharness.remediation_agent.artifacts.report import build_report
from vvaharness.remediation_agent.target import RemediationTarget
from vvaharness.util.tokens import TOKENS, reported_between
from vvaharness.validation.config import Config, load_config
from vvaharness.validation.constants.scoring import FIX_POLICY
from vvaharness.validation.execution.pipeline import execute_plan
from vvaharness.validation.ingest.manifest_builder import build_manifest
from vvaharness.validation.ingest.workspace import stage_workspace
from vvaharness.validation.io.case_writeback import build_verdict
from vvaharness.validation.models import RunMetadata
from vvaharness.validation.models.plans import FixValidationPlan

#: Stamped on every verdict this entry point produces, so a programmatic validation is
#: distinguishable from one the CLI ran over a discovered case file.
ENGINE = "vvaharness.sdk.validate"


class ValidationCaseError(ValueError):
    """Raised when a finding and remediation cannot be validated as a case."""


class ValidationBusyError(RuntimeError):
    """Raised when called from inside a running event loop, which ``asyncio.run`` forbids."""


def case_for(finding: Finding, remediation: Remediation) -> FindingCase:
    """The case S11 validates: the finding, plus the one attempt that claims to fix it."""
    target = RemediationTarget(finding=finding, index=1)
    return build_report(target, remediation)


def _refusal(finding: Finding, remediation: Remediation, repo: Path) -> str:
    """Why this case cannot be validated, or empty when it can."""
    checks = (
        (not repo.is_dir(), f"repo is not a directory: {repo}"),
        (not finding.file, "the finding carries no file, so no workspace can be staged for it"),
        (not remediation.diff,
         "the remediation carries no diff, so there is nothing to apply and judge"),
    )
    return next((why for failed, why in checks if failed), "")


def _already_running() -> bool:
    """True when an event loop owns this thread, which makes ``asyncio.run`` illegal."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return False
    return True


def _provenance(started: datetime, spend_before: object) -> Provenance:
    """The verdict's origin, with this call's own session window and spend closed on."""
    usd, turns = reported_between(spend_before, TOKENS.spend())
    return Provenance(engine=ENGINE, started=started, ended=datetime.now(UTC),
                      usd=usd, turns=turns)


def _judge(case: FindingCase, repo: Path, workspace: Path, *, config: Config,
           policy: ScoringPolicy) -> Verdict:
    """Stage, run the gates and score; the caller owns *workspace* and removes it."""
    started = datetime.now(UTC)
    spend_before = TOKENS.spend()
    session_id = uuid.uuid4().hex
    stage_workspace(repo, workspace, case.attempts[-1].remediation.diff)
    plan = FixValidationPlan(
        case_id=case.case_id,
        session_id=session_id,
        manifest=build_manifest(case, session_id=session_id),
        workspace_dir=workspace,
        output_dir=workspace,
        provenance=_provenance(started, spend_before),
        policy=policy,
    )
    outcome = asyncio.run(
        execute_plan(plan, config, post_results=False, meta=RunMetadata(total_findings=1))
    )
    return build_verdict(case, workspace,
                         provenance=_provenance(started, spend_before),
                         policy=policy, session_failed=outcome.session_failed)


def validate_case(finding: Finding, remediation: Remediation, *, repo: Path,
                  config: Config | None = None,
                  policy: ScoringPolicy | None = None) -> Verdict:
    """Validate one remediation against *repo* and return its verdict; writes nothing to *repo*."""
    repo = Path(repo)
    refusal = _refusal(finding, remediation, repo)
    if refusal:
        raise ValidationCaseError(refusal)
    if _already_running():
        raise ValidationBusyError(
            "validate_case drives an asyncio pipeline and cannot be called from a running event "
            "loop; call it from a worker thread, or await the validation pipeline directly."
        )
    case = case_for(finding, remediation)
    resolved_policy = policy if policy is not None else FIX_POLICY
    resolved_config = config if config is not None else load_config(project_root=repo)
    workspace_root = Path(tempfile.mkdtemp(prefix="vvah-validate-"))
    try:
        return _judge(case, repo, workspace_root / case.case_id,
                      config=resolved_config, policy=resolved_policy)
    finally:
        shutil.rmtree(workspace_root, ignore_errors=True)


__all__ = [
    "ENGINE",
    "ValidationBusyError",
    "ValidationCaseError",
    "case_for",
    "validate_case",
]
