# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Load the gate, the playbook, and the repo's detected frameworks once per run."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from vvaharness.config import is_network_path
from vvaharness.orchestrator.config_paths import _resolve_against
from vvaharness.remediation_agent.frameworks import detect_frameworks
from vvaharness.remediation_agent.playbook import Playbook
from vvaharness.remediation_agent.policy_gate import RemediationGate
from vvaharness.util import logs

log = logs.get_logger(__name__)


def _sr(cfg, key: str, default):
    sr = getattr(cfg, "step_remediate", None)
    return getattr(sr, key, default) if sr else default


def policy_enabled(cfg) -> bool:
    """Whether the policy gate / playbook are active for this run."""
    return bool(_sr(cfg, "enforce_policy", True))


@dataclass
class PolicyContext:
    """Everything the per-finding loop needs to enforce policy."""
    gate: RemediationGate
    playbook: Playbook
    frameworks: set[str]
    enabled: bool = True



def _resolve_input(cfg, raw: str | None) -> str | None:
    """Resolve a configured input path, or ``None`` when it is unset or does not exist."""
    # None → bundled default: a missing file fails closed and denies EVERY finding (default profile)
    if not raw:
        return None
    # _resolve_against only rejects UNC when cfg_dir is set; unguarded, a UNC override leaks NTLM
    if is_network_path(raw):
        raise ValueError(
            f"refusing network/UNC remediation input path {raw!r} "
            f"(reading it could leak credentials over SMB)")
    cfg_dir = getattr(cfg, "_data", {}).get("_config_dir") if cfg else None
    resolved = _resolve_against(Path(cfg_dir), raw) if cfg_dir else raw
    if resolved and not Path(resolved).exists():
        log.warning("configured remediation input %r not found at %s — "
                    "falling back to bundled default", raw, resolved)
        return None
    return resolved


def build_context(cfg, repo_root: str | Path) -> PolicyContext:
    """Load the gate + playbook (honouring profile path overrides) and detect the repo's frameworks once."""
    policy_file = _resolve_input(cfg, _sr(cfg, "policy_file", None))
    playbook_file = _resolve_input(cfg, _sr(cfg, "playbook_file", None))
    gate = RemediationGate(policy_file)
    pb = Playbook(playbook_file)
    try:
        fw = detect_frameworks(repo_root)
    except Exception:                                  # noqa: BLE001
        fw = set()
    return PolicyContext(gate=gate, playbook=pb, frameworks=fw,
                         enabled=policy_enabled(cfg))
