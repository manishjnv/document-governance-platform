# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""remediation_agent.report_parser.parse — finding-header parsing and the done-marker."""
from __future__ import annotations

import re

from vvaharness.remediation_agent.report_parser.fields import to_scan_finding
from vvaharness.remediation_agent.report_parser.finding import Finding
from vvaharness.remediation_agent.target import RemediationTarget

# Invisible marker appended to a finding header once remediated, so "done" survives across runs in the report itself.
DONE_MARKER = "<!-- remediation-agent:done -->"

# Finding header ``### 1. [CRITICAL] title``; the trailing group captures the done marker
_HEADER_RE = re.compile(
    r"^###\s+(\d+)\.\s*\[(CRITICAL|HIGH|MEDIUM|LOW|INFO)\]\s*(.+?)\s*"
    r"(<!--\s*remediation-agent:done\s*-->)?\s*$",
    re.IGNORECASE,
)
# The ``**File:** `routers/jira.py:174-174``` line emitted under each header.
_FILE_RE = re.compile(r"^\*\*File:\*\*\s*`([^`]+)`")


def parse_findings(md_text: str) -> list[RemediationTarget]:
    """Extract findings from a scan report's Markdown as typed remediation targets."""
    return [
        RemediationTarget(finding=to_scan_finding(parsed), index=parsed.index,
                          done=parsed.done)
        for parsed in _parse_blocks(md_text)
    ]


def _parse_blocks(md_text: str) -> list[Finding]:
    """Split *md_text* into the per-finding markdown blocks, as parse intermediates."""
    findings: list[Finding] = []
    current: Finding | None = None
    buf: list[str] = []

    def _flush() -> None:
        if current is not None:
            current.body = "\n".join(buf).strip()

    for line in md_text.splitlines():
        m = _HEADER_RE.match(line)
        if m:
            _flush()
            current = Finding(
                index=int(m.group(1)),
                severity=m.group(2).upper(),
                title=m.group(3).strip(),
                done=bool(m.group(4)),  # DONE_MARKER captured by the header regex
            )
            findings.append(current)
            buf = [line]
            continue
        if current is not None:
            buf.append(line)
            if current.file is None:
                fm = _FILE_RE.match(line.strip())
                if fm:
                    current.file = fm.group(1).strip()
    _flush()
    return findings

