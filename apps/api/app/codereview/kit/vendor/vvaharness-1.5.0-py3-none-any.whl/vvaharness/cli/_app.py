# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The Typer application: command names and help; each command forwards argv to its existing parser."""
from __future__ import annotations

from typing import Any

import typer

from vvaharness.validation.constants.artifacts import VALIDATE_COMMANDS

__all__ = ["COMMANDS", "Interrupted", "app", "run"]

# typer >= 0.26 vendors click as typer.core._click; older typer exposes it as typer.core.click.
_click = getattr(typer.core, "_click", None) or typer.core.click

_PASSTHROUGH: dict[str, Any] = {"allow_extra_args": True, "ignore_unknown_options": True,
                               "help_option_names": []}

app = typer.Typer(
    name="vvaharness",
    help="Agentic SAST pipeline: scan a repository for vulnerabilities.",
    add_completion=True,
    rich_markup_mode="rich",
    context_settings={"help_option_names": ["-h", "--help"]},
)


class Interrupted(Exception):
    """Carries a Ctrl-C out past Typer, which would turn it into exit 130 silently."""


def _delegate(command: str, ctx: typer.Context) -> None:
    """Hand *command* and its untouched argv to the existing handler, surfacing its exit code."""
    from vvaharness import cli

    try:
        code = cli._dispatch([command, *ctx.args])
    except KeyboardInterrupt as exc:
        raise Interrupted from exc
    raise typer.Exit(code)


@app.command("setup", context_settings=_PASSTHROUGH,
             help="Guided readiness check: AI agents, keys, deps, gateway, config.")
def setup(ctx: typer.Context) -> None:
    _delegate("setup", ctx)


@app.command("init", context_settings=_PASSTHROUGH, hidden=True, help="Alias for `setup`.")
def init(ctx: typer.Context) -> None:
    _delegate("init", ctx)


@app.command("doctor", context_settings=_PASSTHROUGH,
             help="Check credentials and live backend connectivity (read-only). "
                  "[dim]--cache-probe adds a live prompt-cache diagnostic that spends real "
                  "tokens; it never runs during a scan.[/dim]")
def doctor(ctx: typer.Context) -> None:
    _delegate("doctor", ctx)


@app.command("estimate", context_settings=_PASSTHROUGH,
             help="Print a rough scope/cost preview for a repo (no API spend).")
def estimate(ctx: typer.Context) -> None:
    _delegate("estimate", ctx)


@app.command("gc", context_settings=_PASSTHROUGH,
             help="Delete old runs: checkpoints and code-graph workspaces (--keep-runs / --max-age-days / --dry-run).")
def gc(ctx: typer.Context) -> None:
    _delegate("gc", ctx)


@app.command("scan", context_settings=_PASSTHROUGH,
             help="Scan a repo (or --repo-file batch) for vulnerabilities. "
                  "[dim]The packaged default skips S10/S11; --remediate enables S10 only and can "
                  "edit source. In-scan S11 needs step_validate.enabled: true, and --stop-after s9 "
                  "skips both.[/dim]")
def scan(ctx: typer.Context) -> None:
    _delegate("scan", ctx)


@app.command("remediate", context_settings=_PASSTHROUGH,
             help="Walk findings from a prior scan and remediate them (Remediation Agent).")
def remediate(ctx: typer.Context) -> None:
    _delegate("remediate", ctx)


@app.command("validate", context_settings=_PASSTHROUGH,
             help="Run the s11 agentic validation agent on applied remediations.")
def validate(ctx: typer.Context) -> None:
    _delegate("validate", ctx)


@app.command("s11", context_settings=_PASSTHROUGH, hidden=True,
             help="Alias for `validate`.")
def s11(ctx: typer.Context) -> None:
    _delegate("s11", ctx)


@app.command("ev-replay", context_settings=_PASSTHROUGH,
             help="Re-check exploit-verified findings against a REDEPLOYED target.")
def ev_replay(ctx: typer.Context) -> None:
    _delegate("ev-replay", ctx)


COMMANDS: frozenset[str] = frozenset({
    "setup", "init", "doctor", "estimate", "gc", "scan", "remediate", "ev-replay",
    *VALIDATE_COMMANDS,
})


def run(args: list[str]) -> int:
    """Dispatch *args* through the Typer app, returning the exit code instead of exiting."""
    command = typer.main.get_command(app)
    try:
        return int(command.main(args=args, prog_name="vvaharness", standalone_mode=False) or 0)
    except typer.Exit as exc:
        return int(exc.exit_code)
    except (Interrupted, typer.Abort) as exc:
        raise KeyboardInterrupt from exc
    except _click.exceptions.ClickException as exc:
        exc.show()
        return int(exc.exit_code)
