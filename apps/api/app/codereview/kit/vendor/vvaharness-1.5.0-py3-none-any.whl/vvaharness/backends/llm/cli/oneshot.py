# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""`prompt()` — one request, one reply, no tools."""
from __future__ import annotations

import json
import subprocess
import time

from vvaharness.backends.harness.deepagents.limits import MODEL_MAX_OUTPUT_TOKENS
from vvaharness.backends.llm.cli import cancel as _cancel
from vvaharness.backends.llm.cli import discovery as _discovery
from vvaharness.backends.llm.cli import env as _env
from vvaharness.backends.llm.cli import envelope as _envelope
from vvaharness.backends.llm.cli import retry as _retry
from vvaharness.backends.llm.cli import session as _session
from vvaharness.backends.llm.models import (
    ANTHROPIC_STOP_MAX_TOKENS,
    TRUNCATED_RETRY_RECOVERED_COUNTER,
    ClockKind,
    call_timeout_error,
    effort_scaled_seconds,
    note_budget_use,
    truncation_retry_max,
)
from vvaharness.util import console, logs
from vvaharness.util.counters import COUNTERS
from vvaharness.util.response_quality import check_response_quality, output_tokens_for_gate
from vvaharness.util.tokens import TOKENS

log = logs.get_logger(__name__)


def prompt(
    user_prompt: str | list[dict],
    *,
    model: str,
    system_prompt: str | None = None,
    json_schema: dict | None = None,
    output_format: str = "text",
    cwd: str | None = None,
    max_budget_usd: float | None = None,
    max_tokens: int | None = None,
    timeout: int = 1800,
    tag: str | None = None,
    effort: str | None = None,   # per-call tier; None => the global cli.effort
) -> str:
    """Single-shot prompt with no tools; returns the model's text response."""
    # Flat text only and no Messages API here, so dropping cache_control markers loses nothing
    if isinstance(user_prompt, list):
        user_prompt = "\n\n".join(
            b.get("text", "") for b in user_prompt
            if isinstance(b, dict) and b.get("type") == "text"
        )
    if _cancel._ABORT.is_set():
        raise RuntimeError("aborted by user (Ctrl-C)")
    tier = _env._effective_effort(effort)
    wall = effort_scaled_seconds(timeout, tier, kind=ClockKind.REQUEST)
    cmd = [*_discovery._CLAUDE_CMD, "-p", "--model", model, *_env._effort_argv(effort)]

    if system_prompt:
        cmd += ["--system-prompt", system_prompt]
    # Always request the JSON envelope (for .usage); text is unwrapped from .result on return.
    cmd += ["--output-format", "json"]
    if json_schema:
        if _discovery._cli_capabilities()["json_schema"]:
            cmd += ["--json-schema", json.dumps(json_schema)]
        else:
            # No --json-schema: degrade loudly to an in-prompt schema, no longer validator-checked
            log.warning("this `claude` build does not advertise "
                  "--json-schema; embedding the schema in the prompt instead. "
                  "Structured output is no longer validator-enforced — upgrade the "
                  "CLI, or route the role via: sdk, for schema guarantees.")
            user_prompt = (
                f"{user_prompt}\n\nRespond with ONLY a JSON object conforming to "
                f"this JSON Schema:\n{json.dumps(json_schema)}"
            )
    # Forward the spend cap only when the CLI advertises --max-budget-usd (probe-gated).
    if max_budget_usd and _discovery._cli_capabilities().get("max_budget"):
        cmd += ["--max-budget-usd", str(max_budget_usd)]

    # Disable all tools — pure reasoning

    cmd += ["--tools", ""]
    # cwd is still inside the scanned repo: its hooks would run on this host, so drop its settings
    cmd += _session._confinement_argv(allowed_tools=None, disallowed_tools=None,
                             permission_prompts=None)

    # claude CLI reads max output tokens from env, not a flag.
    env = _env._call_env(max_tokens=max_tokens, effort=effort)

    tag_sfx = f" [{tag}]" if tag else ""
    console.write(f"    [cli] prompt mode -> {model}{tag_sfx} ({len(user_prompt)} chars"
                  f"{f', max_tokens={max_tokens}' if max_tokens else ''})")

    # VVAH-E005: one doubled-budget retry then fail loud, the same shape as sdk.py/openai.py
    trunc_retried = 0
    while True:
        # Reset per attempt — note_budget_use below must compare PER-ATTEMPT elapsed
        # against `wall` (the per-attempt budget), not time accumulated across retries.
        _call_start = time.monotonic()
        try:
            result = _retry._run_with_retry(
                cmd,
                label=f"prompt({model}){tag_sfx}",
                input=user_prompt,
                cwd=cwd,
                timeout=wall,
                timeout_retries=0,
                env=env,
                heartbeat_label=f"prompt mode ({model}){tag_sfx}",
            )
        except subprocess.TimeoutExpired as e:
            raise call_timeout_error(
                stage=tag or "", route="cli", budget_s=wall, effort=tier,
                cause_text=f"claude subprocess exceeded {wall}s") from e

        if result.returncode != 0:
            cap = _retry._truncation_cap(result)
            if cap is None:
                raise RuntimeError(
                    _discovery._format_cli_error("claude CLI failed", cmd, result))
            # The CLI error names the budget it hit; the caller's own value wins when set
            requested = max_tokens or cap
            retry_at = (None if trunc_retried else
                        truncation_retry_max(requested,
                                             cap=MODEL_MAX_OUTPUT_TOKENS))
            if retry_at is not None:
                _retry._log_truncation_retry(tag=tag, requested=requested,
                                      retry_at=retry_at, label="cli")
                # A copy: the retry raises only the token cap and keeps the effort pin it carried
                env = dict(env or {})
                env["CLAUDE_CODE_MAX_OUTPUT_TOKENS"] = str(retry_at)
                trunc_retried = retry_at
                continue
            raise _retry._truncation_error(requested=requested, retried=trunc_retried,
                                    tag=tag, retry_at=retry_at)

        # With `--tools ""` a multi-turn envelope can only be a split reply, so stitch it
        text, usage, turns, usd, stop_reason, model_usage = _envelope._parse_envelope(
            result.stdout, stitch_continuations=True, tag=tag)
        # Insurance, not reachable on 2.1.270 (the cap failure reports stop_sequence)
        if stop_reason == ANTHROPIC_STOP_MAX_TOKENS:
            requested = max_tokens or MODEL_MAX_OUTPUT_TOKENS
            retry_at = (None if trunc_retried else
                        truncation_retry_max(requested,
                                             cap=MODEL_MAX_OUTPUT_TOKENS))
            if retry_at is not None:
                _retry._log_truncation_retry(tag=tag, requested=requested,
                                      retry_at=retry_at, label="cli")
                env = dict(env or {})
                env["CLAUDE_CODE_MAX_OUTPUT_TOKENS"] = str(retry_at)
                trunc_retried = retry_at
                continue
            raise _retry._truncation_error(requested=requested, retried=trunc_retried,
                                    tag=tag, retry_at=retry_at)
        if trunc_retried:
            COUNTERS.bump(TRUNCATED_RETRY_RECOVERED_COUNTER)
        break

    note_budget_use(time.monotonic() - _call_start, wall, tier)
    _envelope._note_unparsed_cache_keys(usage)
    TOKENS.add(usage, usd=usd, turns=turns)
    _retry._log_usage(usage, stop_reason=stop_reason, model_usage=model_usage)
    _envelope._raise_if_refused(stop_reason, tag=tag, stdout=result.stdout)
    check_response_quality(text, stage=tag or "",
                           output_tokens=output_tokens_for_gate(usage))
    return text
