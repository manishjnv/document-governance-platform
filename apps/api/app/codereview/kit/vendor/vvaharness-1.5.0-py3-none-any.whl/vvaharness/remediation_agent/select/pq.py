# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The "top N by CVSS" selector: a heapq queue with a band fallback and a stable tie-breaker."""
from __future__ import annotations

import heapq
import math
from collections.abc import Callable, Sequence
from typing import TypeVar

from vvaharness.util import console

T = TypeVar("T")


# CVSS 3.1 band anchors when no numeric score: a band-only CRITICAL outranks a numeric 7.5 HIGH
_BAND_SCORE: dict[str, float] = {
    "CRITICAL": 9.0,
    "HIGH": 7.0,
    "MEDIUM": 4.0,
    "LOW": 1.0,
    "INFO": 0.0,
}


def band_score(severity: str | None) -> float:
    """Fallback numeric score for a qualitative severity band; unknown/empty bands score 0.0."""
    return _BAND_SCORE.get((severity or "").strip().upper(), 0.0)


def select_top_by_cvss(
    items: Sequence[T],
    n: int | None,
    score_of: Callable[[T], float | None],
    *,
    severity_of: Callable[[T], str | None] | None = None,
) -> list[T]:
    """Return the *n* highest-CVSS items, ordered highest→lowest."""
    # (-score, index): min-heap gives highest first, index breaks ties so items are never compared
    if n is None or n <= 0:
        return list(items)

    def _score(it: T) -> float:
        s = score_of(it)
        # NaN is not a score: one NaN key silently derails the whole heap's ordering for --top N
        if s is not None and not math.isnan(s):
            return float(s)
        sev = (severity_of(it) if severity_of is not None
               else getattr(it, "severity", None))
        return band_score(sev)

    heap: list[tuple[float, int]] = [(-_score(it), i) for i, it in enumerate(items)]
    heapq.heapify(heap)
    return [items[heapq.heappop(heap)[1]] for _ in range(min(n, len(heap)))]


def select_top_logged(
    items: Sequence[T],
    n: int | None,
    score_of: Callable[[T], float | None],
    *,
    severity_of: Callable[[T], str | None] | None = None,
    log_prefix: str,
) -> list[T]:
    """:func:`select_top_by_cvss` plus the shared "selecting top N of M" log line."""
    # Logged only when the selection actually narrows the set (0 < n < total).
    total = len(items)
    selected = select_top_by_cvss(items, n, score_of, severity_of=severity_of)
    if n is not None and 0 < n < total:
        console.write(f"  {log_prefix} selecting top {n} of {total} finding(s) "
                      f"by CVSS score")
    return selected


def drop_non_main_channel(items: Sequence[T], *, log_prefix: str) -> list[T]:
    """*items* minus every finding the s6 verifier stamped ``channel == "posture"``."""
    # Fail-safe: ONLY exactly "posture" is dropped; junk and empty channel values are all KEPT
    kept = [it for it in items
            if (it.finding.channel or "").strip().casefold() != "posture"]
    skipped = len(items) - len(kept)
    if skipped:
        console.write(f"  {log_prefix} skipping {skipped} posture-stamped finding(s) "
                      f"(build/deploy/dependency posture, not application code); "
                      f"every other channel value is kept")
    return kept
