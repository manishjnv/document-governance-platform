# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""The state DB itself: where it lives, how it is opened and hardened, and run rows."""
from __future__ import annotations

import os
import shutil
import sqlite3
import stat
from collections.abc import Collection
from pathlib import Path

from vvaharness.orchestrator.store._schema import _DDL, _DDL_V2, _DDL_V3
from vvaharness.util.warn_once import warn_once

_SCHEMA_VERSION = 3

# Bundles are small (bodies capped at 512 bytes); enforced here AND by a CHECK, so direct INSERT too
_REPLAY_MAX_BYTES = 1024 * 1024

# Confidentiality: payloads embed scanned SOURCE, sqlite3 creates at umask 0644; pin 0600 + sidecars
_DB_FILE_MODE = 0o600
_STATE_DIR_MODE = 0o700
_SIDECAR_SUFFIXES = ("-wal", "-shm", "-journal")
# Windows has no meaningful chmod/POSIX mode bits: every hardening step below is gated on this.
_POSIX = os.name == "posix"
_PERM_WARNED: set[str] = set()


def _warn_once(key: str, message: str) -> None:
    """Permission problems degrade to a single stderr warning per path per process — a confidentiality hardening..."""
    warn_once(_PERM_WARNED, key, f"  [store] WARN: {message}")


def _tighten_mode(path: Path, mode: int) -> None:
    """Best-effort chmod of *path* down to *mode* when it is looser."""
    # Never raises; never loosens an already-tighter mode; non-POSIX is skipped entirely
    if not _POSIX:
        return
    try:
        current = stat.S_IMODE(path.stat().st_mode)
    except OSError:
        return  # absent (e.g. no sidecar yet) — nothing to tighten
    if not (current & ~mode):
        return  # already at least as tight as the target
    try:
        os.chmod(path, mode)
    except OSError as e:
        _warn_once(str(path),
                   f"could not tighten permissions on {path} (mode "
                   f"{current:o}; it holds scanned-source snippets): {e}")


class StoreError(RuntimeError):
    """A state-store precondition we refuse to silently work around: a symlinked state directory or DB path, or a state root that exists but is not a directory."""


def state_root() -> Path:
    """Where scan state lives, resolved and nothing more."""
    # Deliberately NO I/O: scan.py resolves this pre-safety-check, so --stop-after must not mkdir ~
    return Path(os.environ.get("VVAHARNESS_STATE_DIR")
                or Path.home() / ".vvaharness" / "state")


def ensure_state_dir(*parts: str) -> Path:
    """Return ``state_root()/ *parts``, creating each level owner-only."""
    # Only place state-root dirs are made; tighten EVERY level (parents=True leaves umask default)
    root = state_root()
    if _POSIX:
        # lstat BEFORE anything follows it: is_dir() would follow, letting a planted link redirect
        try:
            lst = root.lstat()
        except OSError:
            lst = None
        if lst is not None and stat.S_ISLNK(lst.st_mode):
            raise StoreError(
                f"refusing to use state directory {root}: it is a symlink")
    if root.is_dir():
        # NOT one decision: VVAHARNESS_STATE_DIR -> warn only (operator chose it); default -> repair
        if _POSIX:
            try:
                mode = stat.S_IMODE(root.stat().st_mode)
            except OSError:
                mode = 0
            if mode & 0o077:
                if os.environ.get("VVAHARNESS_STATE_DIR"):
                    _warn_once(
                        str(root),
                        f"state directory {root} is group/other-accessible "
                        f"(mode {mode:o}) and holds scanned-source snippets — "
                        "consider `chmod 700` if it is not shared on purpose")
                else:
                    _tighten_mode(root, _STATE_DIR_MODE)
                    _warn_once(
                        str(root),
                        f"tightened {root} from mode {mode:o} to 700 — it holds "
                        "scanned-source snippets. Set VVAHARNESS_STATE_DIR to a "
                        "path you manage if you need to share this state")
    else:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except FileExistsError as e:
            # exist_ok forgives only an existing *directory*; a plain file is refused cleanly
            raise StoreError(
                f"refusing to use state directory {root}: it exists and is not "
                "a directory") from e
        # A directory this process created is owner-only by construction.
        _tighten_mode(root, _STATE_DIR_MODE)
    path = root
    for part in parts:
        path = path / part
        path.mkdir(parents=True, exist_ok=True)
        _tighten_mode(path, _STATE_DIR_MODE)
    return path


#: Shared by both resolvers below so the filename exists once.
_DB_NAME = "vvaharness.db"


def db_location() -> Path:
    """The DB path, creating NOTHING -- the read-only counterpart of `db_path`."""
    # Asking whether state exists must not create the state directory; `gc` needs exactly this
    return state_root() / _DB_NAME


def run_exists(run_id: str) -> bool:
    """Look up a run without creating, migrating or changing store permissions."""
    path = db_location()
    try:
        for candidate in (state_root(), path):
            if candidate.is_symlink():
                raise StoreError(f"refusing to inspect state path {candidate}: it is a symlink")
        try:
            path.stat()
        except FileNotFoundError:
            return False
        con = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
        try:
            return con.execute("SELECT 1 FROM runs WHERE run_id = ?", (run_id,)).fetchone() is not None
        finally:
            con.close()
    except (OSError, sqlite3.Error) as error:
        raise StoreError(f"could not inspect state database at {path}: {error}") from error


def db_path() -> Path:
    """Resolve the state DB path the same way scan.py resolves the legacy ``checkpoints/`` root, so ``--resume`` and the in-target safety check see the same location."""
    return ensure_state_dir() / _DB_NAME


def _create_db_file_safe(path: Path) -> None:
    """Create the DB file owner-only, refusing a symlink planted at *path*."""
    # Pre-create 0600 before sqlite3's 0644; O_EXCL|O_NOFOLLOW (sqlite3 lacks both), lstat if extant
    try:
        os.close(os.open(path, os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_RDWR,
                         _DB_FILE_MODE))
        return  # freshly created by us, so not a symlink
    except OSError as err:
        open_err = err  # already exists, or is a symlink; either way, checked below
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        # Report the create's own cause (e.g. EACCES on a read-only dir), not lstat's ENOENT.
        raise FileNotFoundError(
            f"could not create state DB at {path}: {open_err.strerror}") from open_err
    if stat.S_ISLNK(st.st_mode):
        raise StoreError(f"refusing to open state DB at {path}: it is a symlink")


def connect() -> sqlite3.Connection:
    """Open the state DB, ensure the schema exists, and return a connection — cheap enough to call per operation since sqlite3 connections are thread-affine."""
    path = db_path()
    if _POSIX:
        _create_db_file_safe(path)
    con = sqlite3.connect(path)
    # Per-connection pragmas — must be set on every handle.
    con.execute("PRAGMA foreign_keys = ON")
    con.execute("PRAGMA busy_timeout = 30000")
    con.execute("PRAGMA synchronous  = NORMAL")
    # Skipped entirely once user_version matches, so the hot path is three pragmas + one read.
    have = con.execute("PRAGMA user_version").fetchone()[0]
    if have != _SCHEMA_VERSION:
        _migrate(con, have)
    # Tighten a 0644 DB from an older release plus WAL/SHM/journal sidecars (same payload bytes)
    for p in (path, *(path.with_name(path.name + s)
                      for s in _SIDECAR_SUFFIXES)):
        _tighten_mode(p, _DB_FILE_MODE)
    return con


def _migrate(con: sqlite3.Connection, have: int) -> None:
    # v0 gets all of _DDL; an existing DB runs migrations cumulatively, so v1 gets both V2 and V3
    if have == 0:
        con.executescript(_DDL)
    else:
        if have < 2:
            con.executescript(_DDL_V2)
        if have < 3:
            con.executescript(_DDL_V3)
    con.execute(f"PRAGMA user_version = {_SCHEMA_VERSION}")
    con.commit()


def register_run(run_id: str, *, repo_root: str,
                 repo_name: str | None = None,
                 app_id: str | None = None) -> None:
    """Upsert the per-run metadata row, called once at the top of ``scan_repo()`` so ``gc`` can rank runs by recency."""
    con = connect()
    with con:
        con.execute(
            "INSERT INTO runs(run_id, repo_root, repo_name, app_id) "
            "VALUES (?, ?, ?, ?) "
            "ON CONFLICT(run_id) DO UPDATE SET "
            "  repo_root = excluded.repo_root, "
            "  repo_name = excluded.repo_name, "
            "  app_id    = excluded.app_id, "
            "  updated_at = datetime('now')",
            (run_id, repo_root, repo_name, app_id),
        )
    con.close()


def reset_run(run_id: str) -> int:
    """Delete every checkpoint row for one run (fixed s1..s9 steps and dynamic remediate_/validate_ steps), call..."""
    # ev_replays DELIBERATELY NOT cleared: must outlive a rescan; delete_run reaps via FK cascade
    con = connect()
    try:
        with con:
            cleared = 0
            cur = con.execute("DELETE FROM checkpoints WHERE run_id = ?", (run_id,))
            cleared += cur.rowcount or 0
            cur = con.execute("DELETE FROM callgraph_snapshots WHERE run_id = ?", (run_id,))
            cleared += cur.rowcount or 0
            return cleared
    finally:
        con.close()


def steps_with_prefix(run_id: str, prefix: str) -> list[str]:
    """Return *run_id*'s checkpoint step keys starting with *prefix*, sorted — the dynamic keys hash engine identity and a case id, so no caller can reconstruct one to look it up directly."""
    con = connect()
    try:
        rows = con.execute("SELECT step FROM checkpoints WHERE run_id = ?",
                           (run_id,)).fetchall()
        return sorted(r[0] for r in rows if r[0].startswith(prefix))
    finally:
        con.close()


def delete_steps(run_id: str, prefix: str, keep: Collection[str]) -> list[str]:
    """Delete *run_id*'s checkpoint rows whose step starts with *prefix* and is not in *keep* — the complement of :func:`reset_run` for the standalone remediate/validate commands. Returns the deleted keys, sorted."""
    con = connect()
    try:
        with con:
            rows = con.execute("SELECT step FROM checkpoints WHERE run_id = ?",
                               (run_id,)).fetchall()
            victims = sorted(r[0] for r in rows
                             if r[0].startswith(prefix) and r[0] not in keep)
            con.executemany("DELETE FROM checkpoints WHERE run_id = ? AND step = ?",
                            [(run_id, v) for v in victims])
        return victims
    finally:
        con.close()


def delete_run_graphs(run_id: str) -> None:
    """Remove the run's code-graph workspaces under ``graphs/<run_id>``; absent is fine."""
    shutil.rmtree(state_root() / "graphs" / run_id, ignore_errors=True)


def delete_run(run_id: str) -> bool:
    """Fully evict a single run: delete its ``runs`` row (dropping ``checkpoints`` and ``ev_replays`` via ON DEL..."""
    # Same guard as `prune_checkpoints`: `connect()` would create the DB just to report no such run
    if not db_location().exists():
        return False
    con = connect()
    try:
        with con:
            cur = con.execute("DELETE FROM runs WHERE run_id = ?", (run_id,))
            deleted = cur.rowcount or 0
        if deleted:
            # incremental_vacuum frees one page per fetched row: unfetched, it frees one page
            con.execute("PRAGMA incremental_vacuum").fetchall()
            con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        delete_run_graphs(run_id)
        return deleted > 0
    finally:
        con.close()
