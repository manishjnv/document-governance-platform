# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Agentic S4's output contract, and the reducer from outcomes to findings and verdicts."""
from __future__ import annotations

from collections.abc import Collection
from typing import Literal

from pydantic import BaseModel, Field, field_validator

from vvaharness.models.scan._coerce import _coerce_int
from vvaharness.models.scan.findings import Finding
from vvaharness.models.scan.work import InvestigationUnit
from vvaharness.models.vocab import Severity, VulnClass
from vvaharness.rules.cwe import norm_cwe, same_weakness
from vvaharness.scope import resolve_inventory_path
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.json_extract import extract_json


class InvestigatedFinding(BaseModel):
    cwe: str = Field(description="Exactly one most-specific CWE id, e.g. CWE-89.")
    file: str = Field(description="Repo-relative path, from this threat's FILES list.")
    line_start: int = Field(description="1-indexed FIRST line of the weakness's span. For a "
                            "handler or block the span may start at its decorator or signature — "
                            "`sink_line`, not this field, names the dangerous statement itself.")
    sink_line: int = Field(default=0, description="Exact 1-indexed line of the single statement "
                           "that embodies the defect — the dangerous call, query, render, write "
                           "or cookie-set. 0 when no single statement does (e.g. a missing "
                           "control).")

    line_end: int = Field(default=0, description="1-indexed LAST line of the weakness, inclusive — "
                          "the end of the vulnerable statement, block or handler, NOT a repeat of "
                          "line_start. Span the whole construct: an unguarded route runs from its "
                          "decorator to the end of its function body. Use 0 only when you "
                          "genuinely cannot bound it.")
    also_cwes: list[str] = Field(default=[], description=
        "Other DISTINCT weakness classes present at this same location, as CWE ids. One location "
        "routinely holds several: a cookie set without HttpOnly (CWE-1004) is usually also set "
        "without Secure (CWE-614); a route with no CSRF token (CWE-352) often also has no "
        "authorization check (CWE-862). Each id here becomes its own reported finding at this "
        "line, so naming one costs a few characters and omitting it loses a real defect. Do not "
        "list a parent or sibling of `cwe` that means the same thing — only genuinely different "
        "weaknesses.")
    repeat_lines: list[int] = Field(default=[], description=
        "When this IDENTICAL defect repeats at other call sites in the SAME file, the first line "
        "of every additional site — one integer each, no prose. The description you already wrote "
        "is reused verbatim for each, so listing a site costs you almost nothing while omitting "
        "it loses the finding entirely. Report the sites, never a summary of them: one finding "
        "whose line span swallows several call sites is wrong, and so is picking one site and "
        "dropping the rest. Leave empty only when the defect genuinely occurs once.")
    preconditions: list[str] = Field(default=[], description=
        "What must independently be true, beyond reaching this code, for the weakness to be "
        "exploitable — one concrete condition per entry, not a restatement of `description`. Name "
        "the actual gate: the endpoint is reachable by an unauthenticated caller; a feature flag "
        "or config value is set a particular way; the attacker needs a specific input shape (a "
        "negative amount, an oversized payload, a crafted redirect target); the caller needs a "
        "particular role or an active session. A reviewer judging exploitability off your report "
        "alone needs these named, so listing one costs a few words while omitting it loses real "
        "context. Leave empty only when the weakness fires unconditionally on any input that "
        "reaches this code — never as a default for not having checked.")

    @field_validator("sink_line", "line_end", mode="before")
    @classmethod
    def _coerce_line(cls, v: object) -> int:
        """Fold anything not int-like to 0 so one malformed integer cannot fail the whole outcome and discard the unit's findings."""
        return _coerce_int(v, 0)

    @field_validator("repeat_lines", mode="before")
    @classmethod
    def _coerce_repeat_lines(cls, v: object) -> object:
        """Fold each malformed repeat site to 0, which `fan_out` skips, costing that site and not the finding."""
        if v is None:
            return []
        if isinstance(v, (list, tuple)):
            return [_coerce_int(x, 0) for x in v]
        return v
    vuln_class: VulnClass = Field(description="Weakness class; unrecognized labels fold to OTHER.")
    title: str = Field(description=
        "One line, at most 12 words, naming the weakness and its location. No prose.")
    severity: Severity = Field(description=
        "One enum value. s6 re-scores every finding from a CVSS vector, so do not argue it here.")
    description: str = Field(description=
        "AT MOST TWO SENTENCES: the defect and why it is one. The code is quoted for the reader "
        "already — do not restate it, do not repeat the title, and do not re-derive the exploit "
        "(exploit_scenario covers that) or the fix (recommendation covers that).")
    exploit_scenario: str = Field(description=
        "Concrete input -> impact, in at most five sentences. Every application feature, flow "
        "or component the scenario relies on or leads to (a password-reset flow, an admin "
        "panel, mail sending, a file store) must be one you saw in this repository's code; "
        "where the follow-on depends on one you did not see, write it conditionally ('if the "
        "application offers a password reset') or stop at the impact the code shows. A "
        "consequence the code does not support is a false claim, not a stronger finding.")
    recommendation: str = Field(description=
        "AT MOST TWO SENTENCES: the concrete change, naming the API or control to use. No "
        "restatement of the defect, no alternatives list, no code block.")


class InvestigationOutcome(BaseModel):
    unit_id: str = Field(description="Echo the UNIT id you were given, verbatim.")
    verdict: Literal["confirmed", "refuted", "inconclusive"] = Field(description=
        "refuted = you read the whole surface and the claim does not hold; say why in rationale. "
        "inconclusive = you could not reach the evidence. Do NOT use confirmed as a default.")
    rationale: str = Field(description="Why, in 1-3 sentences. Required for refuted.")
    findings: list[InvestigatedFinding] = Field(default=[], description=
        "EVERY distinct weakness class you have evidence for — a list, not one. "
        "Empty is correct and expected when verdict is refuted.")


class InvestigationOutcomes(BaseModel):
    outcomes: list[InvestigationOutcome] = Field(description=
        "ONE entry per UNIT you were given, each echoing that unit's own id. Report every unit, "
        "including the ones you refuted — a unit you omit is recorded as uninvestigated, not clean.")


def _validate_direct(raw: str) -> InvestigationOutcome | None:
    try:
        return InvestigationOutcome.model_validate_json(raw)
    except ValueError:
        return None


def _validate_batch_direct(raw: str) -> InvestigationOutcomes | None:
    try:
        return InvestigationOutcomes.model_validate_json(raw)
    except ValueError:
        return None


def _validate_batch_salvaged(raw: str) -> InvestigationOutcomes | None:
    try:
        return InvestigationOutcomes.model_validate(extract_json(raw))
    except ValueError:
        return None


def _as_batch(raw: str) -> InvestigationOutcomes | None:
    """Parse a batched reply, tolerating a bare single outcome from a one-unit batch."""
    batch = _validate_batch_direct(raw) or _validate_batch_salvaged(raw)
    if batch is not None:
        return batch
    lone = parse_outcome(raw)
    return InvestigationOutcomes(outcomes=[lone]) if lone is not None else None


def split_batch_reply(raw: str, unit_ids: list[str]) -> dict[str, str | None]:
    """Fan one batched reply out to per-unit replies that `reduce_outcomes` reads unchanged."""
    batch = _as_batch(raw)
    if batch is None:
        return {}
    wanted = set(unit_ids)
    by_unit: dict[str, str | None] = {}
    for outcome in batch.outcomes:
        if outcome.unit_id not in wanted:
            COUNTERS.bump("s4_batch_unit_id_invented")
            continue
        by_unit[outcome.unit_id] = outcome.model_dump_json()
    absent = len(wanted) - len(by_unit)
    if absent:
        COUNTERS.bump("s4_batch_unit_omitted", absent)
    return by_unit


def _validate_salvaged(raw: str) -> InvestigationOutcome | None:
    try:
        return InvestigationOutcome.model_validate(extract_json(raw))
    except ValueError:
        return None


def _bump_parse_failure(raw: str) -> None:
    stripped = raw.strip()
    if stripped and not stripped.endswith("}"):
        COUNTERS.bump("s4_outcome_truncated")
    else:
        COUNTERS.bump("s4_outcome_malformed")


def parse_outcome(raw: str) -> InvestigationOutcome | None:
    """Parse one session's raw reply into an `InvestigationOutcome`, or `None`, never raising."""
    outcome = _validate_direct(raw)
    if outcome is not None:
        return outcome
    outcome = _validate_salvaged(raw)
    if outcome is not None:
        return outcome
    _bump_parse_failure(raw)
    return None


def _resolved_cwe(f: InvestigatedFinding, fallback_cwes: list[str]) -> str | None:
    """*f*'s normalised CWE, falling back to the unit's when the model omitted a usable one."""
    cwe = norm_cwe(f.cwe)
    if cwe:
        return cwe
    cwe = fallback_cwes[0] if fallback_cwes else None
    if cwe:
        COUNTERS.bump("s4_finding_cwe_backfilled")
    return cwe


def _at_line(f: InvestigatedFinding, chunk_id: str, cwe: str | None,
             line_start: int, width: int, sink_ref: str | None) -> Finding:
    """One reported finding anchored at *line_start*, carrying *f*'s prose verbatim."""
    return Finding(
        title=f.title, file=f.file, line_start=line_start,
        line_end=line_start + width, vuln_class=f.vuln_class,
        severity=f.severity, cwe=cwe, description=f.description,
        exploit_scenario=f.exploit_scenario, recommendation=f.recommendation,
        preconditions=f.preconditions,
        chunk_id=chunk_id, sink_ref=sink_ref,
    )


def _extra_cwes(f: InvestigatedFinding, primary: str | None, *, max_extra: int) -> list[str]:
    """*f*'s `also_cwes`, normalised and deduped, minus any `same_weakness` match for *primary*, capped at *max_extra*."""
    seen: list[str] = []
    collapsed = 0
    for raw in f.also_cwes:
        c = norm_cwe(raw)
        if not c or c == primary or c in seen:
            continue
        if primary and same_weakness(primary, c):
            collapsed += 1
            continue
        seen.append(c)
    if collapsed:
        COUNTERS.bump("s4_finding_extra_cwe_collapsed", collapsed)
    cap = max(max_extra, 0)
    if len(seen) > cap:
        COUNTERS.bump("s4_finding_extra_cwes_capped", len(seen) - cap)
    return seen[:cap]


def fan_out(f: InvestigatedFinding, chunk_id: str,
            fallback_cwes: list[str] | None = None, cfg=None, *,
            repo_root: str, inventory: Collection[str]) -> list[Finding]:
    """Fan *f* out over its repeat sites and its surviving co-located weakness classes, with `file` resolved to inventory form."""
    f = f.model_copy(update={"file": resolve_inventory_path(repo_root, f.file, inventory)})
    cwe = _resolved_cwe(f, fallback_cwes or [])
    width = max(f.line_end, f.line_start) - f.line_start
    anchors = [f.line_start]
    anchors += [n for n in sorted(set(f.repeat_lines)) if n > 0 and n != f.line_start]
    # s5/s7 merge only weakness_key siblings; generic-parent extras never merge downstream: die here
    max_extra = int(knob(cfg, "step4.max_extra_cwes", 2))
    cwes = [cwe, *_extra_cwes(f, cwe, max_extra=max_extra)]
    if len(anchors) > 1:
        COUNTERS.bump("s4_finding_repeat_sites", len(anchors) - 1)
        COUNTERS.bump("s4_finding_with_repeats")
    if len(cwes) > 1:
        COUNTERS.bump("s4_finding_extra_cwes", len(cwes) - 1)
        COUNTERS.bump("s4_finding_with_extra_cwes")
    # sink_line names ONE statement, so a repeat-line clone would point at another site's statement
    sink = f"{f.file}:{f.sink_line}" if f.sink_line >= 1 else None
    if sink:
        COUNTERS.bump("s4_finding_sink_line")
    return [_at_line(f, chunk_id, c, n, width, sink if n == f.line_start else None)
            for n in anchors for c in cwes]


def reduce_outcomes(
    units: list[InvestigationUnit], raw_outcomes: dict[str, str | None], cfg=None, *,
    repo_root: str, inventory: Collection[str],
) -> tuple[list[Finding], dict[str, str]]:
    """Reduce every session's raw reply into findings plus a per-unit verdict map, where a lost session reads as failed or uninvestigated rather than clean."""
    by_unit = {u.id: "uninvestigated" for u in units}
    units_by_id = {u.id: u for u in units}
    findings: list[Finding] = []
    for unit_id, raw in raw_outcomes.items():
        if unit_id not in by_unit:
            COUNTERS.bump("s4_unit_id_invented")
            continue
        if raw is None:
            continue
        outcome = parse_outcome(raw)
        if outcome is None:
            by_unit[unit_id] = "failed"
            continue
        by_unit[unit_id] = outcome.verdict
        unit = units_by_id[unit_id]
        for f in outcome.findings:
            findings.extend(fan_out(f, unit.id, unit.cwes, cfg,
                                    repo_root=repo_root, inventory=inventory))
    missing = sum(1 for v in by_unit.values() if v == "uninvestigated")
    if missing:
        COUNTERS.bump("s4_unit_no_outcome", missing)
    return findings, by_unit
