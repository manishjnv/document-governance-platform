# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deterministic eligibility gate: the only place deciding whether a finding reaches the patch agent."""
from __future__ import annotations

from vvaharness.remediation_agent.policy_gate.action import (
    Action,
    Decision,
)
from vvaharness.remediation_agent.policy_gate.diffscan import (
    cap_verdict,
    inspect_diff,
)
from vvaharness.remediation_agent.policy_gate.gate import (
    DEFAULT_POLICY_PATH,
    RULES_DIR,
    RemediationGate,
)
from vvaharness.remediation_agent.policy_gate.matching import (  # noqa: F401
    _first_match,
    _glob_match,
)

__all__ = [
    "DEFAULT_POLICY_PATH",
    "RULES_DIR",
    "Action",
    "Decision",
    "RemediationGate",
    "cap_verdict",
    "inspect_diff",
]
