# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Directory names a scan leaves in a target checkout, so stage writes and ``_purge_clone`` cannot drift."""

from __future__ import annotations

from pathlib import Path
from typing import Final

__all__ = [
    "CASE_DIR_NAME",
    "CASE_FILE_NAME",
    "FINDINGS_JSON_NAME",
    "SCAN_DIR_NAME",
    "UnsafeArtifactDir",
    "artifact_dir",
]

#: Detection output: the Markdown report, the SARIF, the error log, and findings.json.
SCAN_DIR_NAME: Final = "security-scan"

#: Remediation output: one subdirectory per finding, each holding that case's record.
CASE_DIR_NAME: Final = "security-remediation"

#: The per-case record; the subdirectory is named by the remediation agent's slug, not by ``case_id``.
CASE_FILE_NAME: Final = "finding_case.json"

#: The typed scan result, so a later process reads findings instead of re-parsing Markdown.
FINDINGS_JSON_NAME: Final = "findings.json"


class UnsafeArtifactDir(RuntimeError):
    """The place a scan was about to write its artifacts is not a real directory inside the target checkout."""
    # Raised, not worked around: artifacts would land outside the tree the operator pointed at


def _link_target(path: Path) -> str:
    """The link target, for the error message only; never raises."""
    try:
        return str(path.readlink())
    except OSError:
        return "?"


def artifact_dir(repo: Path | str, name: str) -> Path:
    """``<repo>/<name>``, verified to be a real directory inside *repo*."""
    # Committed symlink redirects writes (mkdir(exist_ok=True) follows); cf scope/walk.py; no mkdir
    root = Path(repo)
    out = root / name
    if out.is_symlink():
        raise UnsafeArtifactDir(
            f"refusing to write scan artifacts through a symlink: "
            f"'{out}' is a symbolic link (-> {_link_target(out)}). Remove or "
            f"rename it in the target checkout and re-run.")
    if out.exists() and not out.is_dir():
        raise UnsafeArtifactDir(
            f"refusing to write scan artifacts: '{out}' exists and is not a "
            f"directory. Remove or rename it in the target checkout and re-run.")
    try:
        inside = out.resolve().is_relative_to(root.resolve())
    except OSError as exc:  # unresolvable component (dangling link, permissions)
        raise UnsafeArtifactDir(
            f"refusing to write scan artifacts: '{out}' cannot be "
            f"resolved ({exc}).") from exc
    if not inside:
        raise UnsafeArtifactDir(
            f"refusing to write scan artifacts outside the target: '{out}' "
            f"resolves to '{out.resolve()}', which is not inside "
            f"'{root.resolve()}'.")
    return out
