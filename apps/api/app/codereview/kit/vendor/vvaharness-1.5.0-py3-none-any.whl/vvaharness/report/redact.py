# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Sensitive-data redaction for emitted reports (MD + SARIF), applied at the write boundary."""
from __future__ import annotations

import re
import threading
from collections import OrderedDict
from typing import Callable, TypeVar

#: Preserves the caller's structure type through redact_tree.
_TreeT = TypeVar("_TreeT")

# Validators

def _luhn(digits: str) -> bool:
    total, odd = 0, True
    for ch in reversed(digits):
        n = int(ch)
        if not odd:
            n *= 2
            if n > 9:
                n -= 9
        total += n
        odd = not odd
    return total % 10 == 0


_PAN_MIN_DIGITS, _PAN_MAX_DIGITS = 12, 19


def _iin(lo: int, hi: int) -> frozenset[int]:
    """An inclusive ISO/IEC 7812 issuer-prefix range, so every network row is one membership test."""
    return frozenset(range(lo, hi + 1))


_CARD_NETWORKS: tuple[tuple[str, int, int, int, frozenset[int]], ...] = (
    ("amex", 15, 15, 2, _iin(34, 34) | _iin(37, 37)),
    ("visa", 13, 19, 1, _iin(4, 4)),
    ("mastercard", 16, 16, 2, _iin(51, 55)),
    ("mastercard-2-series", 16, 16, 4, _iin(2221, 2720)),
    ("discover-6011", 16, 19, 4, _iin(6011, 6011)),
    ("discover-65", 16, 19, 2, _iin(65, 65)),
    ("discover-64x", 16, 19, 3, _iin(644, 649)),
    ("jcb", 16, 19, 4, _iin(3528, 3589)),
    ("unionpay", 16, 19, 2, _iin(62, 62)),
    ("diners", 14, 19, 2, _iin(36, 36)),
    ("maestro", 12, 19, 4,
     frozenset({5018, 5020, 5038, 5893, 6304, 6759, 6761, 6762, 6763})),
    ("rupay-508", 16, 16, 3, _iin(508, 508)),
    ("rupay-8x", 16, 16, 2, _iin(81, 82)),
)


def _cc_network(digits: str) -> bool:
    """IIN/BIN gate so random Luhn-passing 16-digit ids aren't masked."""
    n = len(digits)
    if n < _PAN_MIN_DIGITS or n > _PAN_MAX_DIGITS:
        return False
    return any(lo <= n <= hi and int(digits[:width]) in prefixes
               for _, lo, hi, width, prefixes in _CARD_NETWORKS)


_SSN_NEVER_ISSUED_AREA = 666


def _ssn_valid(d: str) -> bool:
    """Rejects only impossible groupings; ITIN areas 900-999 stay allowed since they're masked anyway."""
    area, group, serial = int(d[:3]), int(d[3:5]), int(d[5:9])
    return not (area == 0 or area == _SSN_NEVER_ISSUED_AREA or group == 0 or serial == 0)


def _bearer_credential(m: re.Match) -> bool:
    """True only when the value has a non-alphabetic char, so prose like ``HTTP Basic Auth`` is skipped."""
    return any(not c.isalpha() for c in m.group("bv"))

_SECRET_CODE_SHAPE = re.compile(
    r"^\("                 # leading paren / cast:   (sasl_secret_t
    r"|^[A-Za-z_]\w*\("    # function call:          parse(
    r"|^[A-Za-z_]\w*\.\w"  # member access:          obj.field / this.field
)

# Applies to STRONG keywords too: ident.ident( never occurs in a credential; `params.get(` shipped
_SECRET_CODE_SHAPE_DOTTED_CALL = re.compile(r"^[A-Za-z_]\w*\.\w+\(")

# Digit-free on purpose: `sk_live_abc123` must carry; RESIDUAL: generic <20-char value ships
_IDENTIFIER_SHAPE = re.compile(r"[A-Za-z]+(?:_[A-Za-z]+)+")

# Next-line `KEY=` is a SIBLING key, masking it poisons the registry; `(?!=)` spares base64 padding
_NEXT_LINE_ENV_KEY = re.compile(r"[A-Z][A-Z0-9_]*=(?!=)")

_REDACTED_TAG_FRAGMENT = r"\[redacted-[a-z0-9-]+]"
_REDACTED_TAG_RX = re.compile(r"(?i)" + _REDACTED_TAG_FRAGMENT)

# Skipping a fully-matching value (`_mask` output, sample config) keeps redact idempotent
_PLACEHOLDER_RX = re.compile(
    r"(?i)\$\{?[A-Z0-9_.]+}?|%[A-Z0-9_]+%|<[^>]+>|\*{3,}|x{3,}"
    r"|\[?redacted]?|" + _REDACTED_TAG_FRAGMENT +
    r"|null|none|true|false|changeme|your[_-]?\w+|placeholder|example"
)


# Patterns

_b64u = r"[A-Za-z0-9_-]"

_PATTERNS: list[tuple[str, re.Pattern, Callable[[re.Match], bool] | None]] = [
    ("PAN",
        re.compile(r"(?<![0-9A-Za-z])"
                # \s also matches Unicode NBSP/thin/figure space, so a PAN split by those isn't bypassed.
                r"(?:\d[\s\-]?){12,18}\d"
                 # Only alphanumeric adjacency breaks standalone; punctuated paths still mask
                 r"(?![0-9A-Za-z])"),
     lambda m: (lambda d: _cc_network(d) and _luhn(d))(re.sub(r"\D", "", m.group(0)))),
    ("CVV",
     re.compile(r"(?i)\b(cvv2?|cvc2?|cid|csc)\b\s*[:=]?\s*\"?(\d{3,4})\"?"),
     None),
    ("TRACK",
     re.compile(r"%B\d{12,19}\^[^?]{2,90}\?"),
     None),

    ("SSN",
     # Separator class includes Unicode spaces so a split SSN isn't bypassed; \n/\r excluded to avoid spanning table rows.
     re.compile(r"(?<!\d)(\d{3})[-.\t \u00a0\u2009\u202f\u2007]"
                r"(\d{2})[-.\t \u00a0\u2009\u202f\u2007](\d{4})(?!\d)"),
     lambda m: _ssn_valid(m.group(1) + m.group(2) + m.group(3))),
    # Keyword-gated BARE 9-digit SSN/ITIN, so arbitrary 9-digit ids/timestamps aren't masked.
    ("SSN-CTX",
     re.compile(
         r"(?i)\b(ssn|social[\s_-]*sec(?:urity)?(?:[\s_-]*(?:no|num|number))?"
         r"|itin|tin|taxpayer[\s_-]*id)\b['\"]?\s*[:=#-]?\s*['\"]?"
         r"(?<!\d)(\d{9})(?!\d)"),
     lambda m: _ssn_valid(m.group(2))),

    ("AWS-KEY",
     re.compile(r"\b(?:AKIA|ASIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA)[0-9A-Z]{16}\b"),
     None),
    ("GITHUB-TOKEN",
     re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{36,255}"
                r"|github_pat_[A-Za-z0-9_]{22}_[A-Za-z0-9]{59})\b"),
     None),
    ("SLACK-TOKEN",
     re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,72}\b"),
     None),
    # The credential THIS product uses; bare tokens carry no `key=` prefix for SECRET to anchor on.
    ("ANTHROPIC-KEY",
     re.compile(r"\bsk-ant-[A-Za-z0-9_-]{16,}\b"),
     None),
    ("STRIPE-KEY",
     re.compile(r"\b(?:sk|rk)_(?:live|test)_[A-Za-z0-9]{24,99}\b"),
     None),
    ("GOOGLE-API-KEY",
     re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b"),
     None),
    ("AZURE-SAS",
     re.compile(r"(?i)\bsig=[0-9A-Za-z%+/=]{20,}\b"),
     None),
    ("TWILIO-KEY",
     re.compile(r"\bSK[0-9a-fA-F]{32}\b"),
     None),

    ("JWT",
     re.compile(r"\beyJ" + _b64u + r"{10,}\." + _b64u + r"{10,}\." + _b64u + r"{10,}\b"),
     None),
    ("BEARER",
     re.compile(r"(?i)\b(?:Bearer|Basic)\s+(?P<bv>[A-Za-z0-9+/=._-]{8,})\b"),
     _bearer_credential),

    # Masks ONLY the password component; only fires on real userinfo, so a host:port URL never matches.
    ("URL-CRED",
     re.compile(r"(?i)\b([a-z][a-z0-9+.\-]*://[^\s:/@]+:)([^\s/@]{1,256})@"),
     None),

    # Unbounded lazy body is linear-safe; a bounded cap used to FAIL OPEN on large keys (RSA-16384, multi-key bundles).
    ("PRIVATE-KEY",
     re.compile(r"-{5}BEGIN [A-Z ]*PRIVATE KEY-{5}[\s\S]*?-{5}END [A-Z ]*PRIVATE KEY-{5}"),
     None),

    ("SECRET",
     re.compile(
         # camelCase/UPPER_SNAKE boundaries; private_key rides beside PEM (sentinel stops re-match)
         r"(?i)(?:\b|(?<=[a-z])|(?<=_))(pass(?:word|wd)?|passphrase|pwd"
         # Compound *_key names BEFORE bare `secret`, or `SECRET_KEY` stops at `secret` and fails \b
         r"|(?:secret|signing|encryption|aes|jwt|hmac|master)[_-]?key|secret"
         r"|api[_-]?key|access[_-]?key|private[_-]?key"
         r"|client[_-]?secret|auth[_-]?token|token|credential)s?\b"
         # `op` accepts `==`/`!=`/`:=` too (`if password == "abcdef":` shipped
         # verbatim before), and is captured so the validator below can demand a
         # QUOTED value for those: `password == stored_password` is a comparison
         # against an identifier, not a credential.
         # `presp`/`postsp` instead of `\s*` because `\s` matches `\n`: a keyword
         # at end-of-line used to swallow the start of the next, unrelated line.
         # `closer` (a dict/set literal being closed, `{'user', 'password'}:`) is
         # real code, so when it matches the value must stay same-line — pinned by
         # `test_secret_separator_does_not_cross_a_newline`. Otherwise one `\n`
         # plus indentation may precede the value (the YAML/Java/JS shape) —
         # pinned by `test_secret_multiline_keyword_value_is_masked`.
         # That continuation MUST keep newline AND indent both mandatory, not
         # `\r?\n?[ \t]*`: (1) ReDoS — two adjacent greedy whitespace classes over
         # the same run took `password=` + 20k spaces + `abc` from 3.6ms to
         # 3969ms, and evidence/configs.py feeds 500k chars of repo config here,
         # so one planted line stalled a whole scan; (2) an un-indented next line
         # is a SIBLING key, and taking it as the value both over-masked and
         # poisoned the value-carry registry (see `_NEXT_LINE_ENV_KEY`).
         r"['\"`]?(?P<closer>[)\]}])?(?P<presp>[ \t]*)(?P<op>[!=]?[:=]=?)(?P<postsp>[ \t]*)"
         # Lookaheads not a guard, else the child's KEY=value ships clear; sync _NEXT_LINE_ENV_KEY
         r"(?(closer)|(?:\r?\n[ \t]+"
         r"(?!(?-i:[A-Z][A-Z0-9_]*=(?!=)))"
         r"(?![^\s'\"`,;\x00]{0,255}:(?:[\s'\"`,;\x00]|$)))?)"
         # \x00 excluded so SECRET never re-captures a placeholder sentinel left by an earlier pattern.
         r"(?:[bBrRuU]{1,2}(?=['\"]))?(?P<q>['\"`]?)(?P<v>[^\s'\"`,;\x00]{6,256})(?P=q)"),
     # Matching a placeholder/sentinel value makes redact() idempotent instead of double-bracketing on a second pass.
     lambda m: not _PLACEHOLDER_RX.fullmatch(m.group("v"))
     and (m.group("op") in (":", "=") or bool(m.group("q")))
     # Leading `<` is markup; both rejected variants fail OPEN; RESIDUAL: `<`-leading secret ships
     and not (m.group("v") or "").startswith("<")),

    # `<password>…</password>` has no `:`/`=` for SECRET; labelled SECRET and ordered AFTER it
    ("SECRET-XML",
     re.compile(r"(?i)<(pass(?:word|wd)?|passphrase|pwd|secret|api[_-]?key"
                r"|access[_-]?key|client[_-]?secret|auth[_-]?token|token"
                # \x00 excluded: past 10 placeholders a sentinel is a 4-char run
                r"|credential)>\s*(?P<v>[^<\s\x00]{4,256})\s*</\1>"),
     lambda m: not _PLACEHOLDER_RX.fullmatch(m.group("v"))),

    # jwt.encode/decode take the signing secret positionally, so no key:op:value anchor exists
    ("SECRET-ARG",
     re.compile(r"\bjwt\.(?:encode|decode)\(\s*[^,()]*,\s*[bBrRuU]{0,2}(?P<q>['\"])"
                r"(?P<v>[^'\"\s\x00]{6,256})(?P=q)"),
     lambda m: not _PLACEHOLDER_RX.fullmatch(m.group("v"))),
]


# Value carry: anchored rules miss prose restatements; _KNOWN_LOCK for s4's pool
_KNOWN_VALUES: OrderedDict[str, None] = OrderedDict()
_KNOWN_LOCK = threading.Lock()

#: Hard cap; unbounded was a measured regression. LRU not FIFO: a ~2048 one-off burst lost a secret
_KNOWN_VALUES_MAX = 2048

#: Raised from 6: a 6-9 char mixed-case id like `MyClass1` mangled every later mention
_MIN_KNOWN_LEN = 10

#: Length at which an all-lowercase-alphabetic span is distinctive enough alone.
_KNOWN_LONG_ENOUGH_ALONE = 12


def _class_diversity(value: str) -> int:
    """How many of {lowercase, uppercase, digit, symbol} appear in *value*."""
    return sum((
        any(c.islower() for c in value),
        any(c.isupper() for c in value),
        any(c.isdigit() for c in value),
        any(not c.isalnum() for c in value),
    ))


def _rememberable(value: str) -> bool:
    """Is *value* distinctive enough to remember for restatement matching?"""
    # Higher bar than safety.py's `_maskable` by design: its single-trait test let `MyClass1` in
    if len(value) < _MIN_KNOWN_LEN:
        return False
    if len(value) >= _KNOWN_LONG_ENOUGH_ALONE:
        return True
    return _class_diversity(value) >= 2


def _remember_known_value(value: str) -> None:
    """Register *value* in the bounded value-carry registry."""
    # Caller must hold `_KNOWN_LOCK`; re-registering refreshes to most-recent, not evicts
    if value in _KNOWN_VALUES:
        _KNOWN_VALUES.move_to_end(value)
        return
    if len(_KNOWN_VALUES) >= _KNOWN_VALUES_MAX:
        _KNOWN_VALUES.popitem(last=False)
    _KNOWN_VALUES[value] = None


def reset_known_values() -> None:
    """Clear the run-scoped value-carry registry."""
    # Once per repo (`orchestrator/batch.py`); NEVER mid-repo, the registry must span a repo's calls
    with _KNOWN_LOCK:
        _KNOWN_VALUES.clear()


# Public API

def _redact_impl(text: str, *, carry: bool = True) -> tuple[str, dict[str, int]]:
    """Core masking pass. Returns (masked_text, counts)."""
    # Strip any pre-existing NUL bytes, since NUL is reserved as the in-band placeholder sentinel below.
    if "\x00" in text:
        text = text.replace("\x00", "")
    counts: dict[str, int] = {}
    placeholders: list[str] = []
    sentinel = "\x00{}\x00"

    def _mask(label: str, m: re.Match, *, span: str | None = None,
              remember: bool = True) -> str:
        counts[label] = counts.get(label, 0) + 1
        # Keep N newlines (PEM) or later line numbers shift; `span` is the part truly replaced
        value = span if span is not None else m.group(0)
        nl = value.count("\n")
        # `remember` is SECRET's escape hatch: a code-shaped residual must NEVER enter the registry
        if nl == 0 and remember and _rememberable(value):
            with _KNOWN_LOCK:
                _remember_known_value(value)
        placeholders.append(f"[REDACTED-{label}]" + "\n" * nl)
        return sentinel.format(len(placeholders) - 1)

    out = text
    for label, rx, validator in _PATTERNS:
        def _sub(m: re.Match, _label=label, _ok=validator) -> str:
            if _ok is not None and not _ok(m):
                return m.group(0)
            if _label == "SECRET":
                v = m.group("v")
                quoted = bool(m.group("q"))
                # `*` and `|` stripped too, or markdown bold and table cells ride inside the value
                v_core = v if quoted else (v.rstrip(").}]!?>*|") or v)
                if len(v_core) < 6:
                    v_core = v
                # Idempotence #2: a placeholder-prefixed value with a tail would grow text each pass
                if _REDACTED_TAG_RX.match(v):
                    return m.group(0)
                # Second check; `not q` is required or a quoted key-shaped value ships in the clear
                if not m.group("q") and "\n" in m.group(0)[: m.start("v") - m.start(0)] and (
                        v.endswith(":") or _NEXT_LINE_ENV_KEY.match(v)):
                    return m.group(0)
                keyword = re.sub(r"[^a-z]", "", m.group(1).lower())
                # Add to the alternation, add here, or lowercase ships; secret/token/credential OUT
                strong = {"password", "passwd", "pwd", "apikey",
                          "accesskey", "clientsecret", "authtoken",
                          "passphrase", "privatekey", "secretkey", "signingkey",
                          "encryptionkey", "aeskey", "jwtkey", "hmackey", "masterkey"}
                unquoted = not quoted
                generic_unquoted = keyword not in strong and unquoted
                # Tight `KEY=value` is a .env assignment, not prose; `TOKEN=abc123` shipped unmasked
                tight_equals_assignment = (
                    m.group("op") == "=" and not m.group("presp")
                    and not m.group("postsp"))
                # Generic keyword: skip prose; a 20+ char lowercase run is a passphrase, not a word
                short = len(v_core) < 20
                identifier = short and bool(_IDENTIFIER_SHAPE.fullmatch(v_core))
                plain_word = (generic_unquoted and not tight_equals_assignment
                              and v_core.islower() and (
                                  (v_core.isalpha() and short) or identifier))
                # GENERIC-only skip; strong=dotted-call; RESIDUAL: unquoted `Ab1.cd2(Xy9` ships
                code_shape = unquoted and bool(
                    _SECRET_CODE_SHAPE.match(v_core) if generic_unquoted
                    else _SECRET_CODE_SHAPE_DOTTED_CALL.match(v_core))
                if plain_word or code_shape:
                    return m.group(0)
                head = m.group(0)[: m.start("v") - m.start(0)]
                tail = v[len(v_core):] + m.group(0)[m.end("v") - m.start(0):]
                # Masked locally, NEVER remembered: `db_password` would re-mask every later file
                remember = not (unquoted and (
                    _SECRET_CODE_SHAPE.match(v_core) or identifier))
                return head + _mask(_label, m, span=v_core,
                                    remember=remember) + tail
            if _label in ("SECRET-XML", "SECRET-ARG"):
                # Relabelled "SECRET" so counts stay one vocabulary.
                return (m.group(0)[: m.start("v") - m.start(0)]
                        + _mask("SECRET", m, span=m.group("v"))
                        + m.group(0)[m.end("v") - m.start(0):])
            if _label == "CVV":
                return m.group(0)[: m.start(2) - m.start(0)] + _mask(_label, m, span=m.group(2))
            if _label == "SSN-CTX":
                # Relabelled "SSN" so counts match the separated-SSN rule.
                return m.group(0)[: m.start(2) - m.start(0)] + _mask("SSN", m, span=m.group(2))
            if _label == "URL-CRED":
                return m.group(1) + _mask(_label, m, span=m.group(2)) + "@"
            return _mask(_label, m)
        out = rx.sub(_sub, out)

    # Value carry: mask unanchored restatements; works only as _KNOWN_VALUES persists
    if carry and _KNOWN_VALUES:
        with _KNOWN_LOCK:
            # Longest-first so a short value never masks inside a long one; lex tiebreak is stable
            known = sorted(_KNOWN_VALUES, key=lambda s: (-len(s), s))
        for value in known:
            if value in out:
                # A hit is a USE: refresh LRU here, since `_mask` refreshes only if `_rememberable`
                with _KNOWN_LOCK:
                    if value in _KNOWN_VALUES:
                        _KNOWN_VALUES.move_to_end(value)
                out = re.sub(re.escape(value),
                              lambda m: _mask("SECRET-RESTATED", m),
                              out)

    if placeholders:
        def _reinsert(m: re.Match) -> str:
            idx = int(m.group(1))
            # Defensive: an out-of-range index can only come from a sentinel collision; leave it untouched rather than raise.
            return placeholders[idx] if 0 <= idx < len(placeholders) else m.group(0)
        out = re.sub(r"\x00(\d+)\x00", _reinsert, out)
    return out, counts


def redact(text: str, *, carry: bool = True) -> str:
    """Mask card data, PII and credential material in `text`; use `redact_counts()` under concurrency."""
    if not text:
        return text
    out, counts = _redact_impl(text, carry=carry)
    redact.last_counts = dict(counts)  # type: ignore[attr-defined]
    return out


def redact_counts(text: str, *, carry: bool = True) -> tuple[str, dict[str, int]]:
    """Thread-safe `redact()`: returns (masked_text, counts) without touching `redact.last_counts`."""
    if not text:
        return text, {}
    return _redact_impl(text, carry=carry)


#: carry=False here: a remembered literal in a path (`access_token.py`) or id must not be replaced
_NO_CARRY_KEYS = frozenset({
    "file", "uri", "source_ref", "sink_ref", "chunk_id", "case_id", "ruleId",
    "partialFingerprints", "aliasFindingIds", "filePath", "file_path",
    "filenames", "path",
})


def redact_tree(obj: _TreeT, *, carry: bool = True) -> _TreeT:
    """Recursively redact every string leaf of a JSON-serialisable structure, before json.dumps."""
    if isinstance(obj, dict):
        return {k: redact_tree(v, carry=carry and k not in _NO_CARRY_KEYS)  # type: ignore[return-value]
                for k, v in obj.items()}
    if isinstance(obj, list):
        return [redact_tree(v, carry=carry) for v in obj]  # type: ignore[return-value]
    if isinstance(obj, tuple):
        return tuple(redact_tree(v, carry=carry) for v in obj)  # type: ignore[return-value]
    if isinstance(obj, str):
        return redact(obj, carry=carry)  # type: ignore[return-value]
    return obj
