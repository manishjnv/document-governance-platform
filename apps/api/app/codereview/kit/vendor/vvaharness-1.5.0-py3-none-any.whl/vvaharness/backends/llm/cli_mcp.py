# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""In-process SDK-MCP bridge: caller-supplied tools inside the pinned `claude` binary."""

# In-process is not an optimisation, it is the only possible transport: the tools close over a
# live ArcadeDB GraphHandle that a second process cannot reopen, so a stdio MCP server could
# never serve them. The SDK spawns the SAME pinned binary (cli._CLAUDE_CMD[0]) as cli.py.
# Security posture: the read jail is the `_pre_tool_use_gate` PreToolUse hook, NOT
# ``--restricted`` — that flag is mutually exclusive with ``setting_sources=("user",)``'s
# apiKeyHelper auth rationale and would break gateway auth outright. Do not add it.
# Known gap: Bash under an explicit shell grant is unconfinable on either route.
# TodoListMiddleware stays deepagents-only; no prompt claim about ``write_todos`` is made here.
from __future__ import annotations

import asyncio
import json
import os
import re
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from vvaharness.backends.harness.models import (
    AuthenticationError,
    ProxyError,
)
from vvaharness.backends.llm import cli as _cli
from vvaharness.backends.llm.models import (
    ANTHROPIC_STOP_REFUSAL,
    CLI_STRUCTURED_OUTPUT_TOOL,
    CLI_TOKEN_CAP_RX,
    TIMEOUT_STOP_GRACE_SECONDS,
    TRUNCATED_RETRY_RECOVERED_COUNTER,
    ClockKind,
    call_timeout_error,
    effort_scaled_seconds,
    model_refusal,
    note_budget_use,
)
from vvaharness.report.redact import redact
from vvaharness.util import console
from vvaharness.util.counters import COUNTERS
from vvaharness.util.response_quality import check_response_quality
from vvaharness.util.scan_progress import is_stage_only
from vvaharness.util.tokens import TOKENS, TokenUsage
from vvaharness.util.warn_once import warn_once

if TYPE_CHECKING:
    from collections.abc import Sequence

#: Names reach the model as ``mcp__vvah_facts__X``; permissions.py's MCP_TOOL_PREFIX admits them
SERVER_NAME = "vvah_facts"
TOOL_PREFIX = f"mcp__{SERVER_NAME}__"

#: One entry per distinct degradation already reported, so stderr is not flooded.
_WARNED: set[str] = set()

#: Never called a graph tool despite `require_graph`; out of loop this counter + WARN is all
EVIDENCE_UNENFORCED_COUNTER = "cli_mcp_evidence_gate_unenforced"


def available() -> bool:
    """Whether the Claude Agent SDK this bridge needs is importable."""
    try:
        import claude_agent_sdk  # noqa: F401, PLC0415 — availability probe only
    except Exception:  # noqa: BLE001 — any import failure means "not available"
        return False
    return True


def mcp_name(bare: str) -> str:
    """The wire name the model sees for a bridged tool."""
    return TOOL_PREFIX + bare


# ── tool materialisation ─────────────────────────────────────────────────────

def _materialize(tool_builder, *, model: str, cwd: str,
                 fact_tools: Sequence[str]) -> list[Any]:
    """Run the caller's ``ToolBuilder`` and keep only its fact tools."""
    # ``allowed_tools=()`` drops readers (the CLI has natives); the name filter is the belt
    from vvaharness.backends.harness import StreamingOptions  # noqa: PLC0415 — lazy

    wanted = set(fact_tools)
    if not wanted:
        return []
    options = StreamingOptions(model=model, cwd=Path(cwd),
                               fact_tools=tuple(fact_tools))
    built = tool_builder(options, allowed_tools=()) or []
    return [t for t in built if getattr(t, "name", None) in wanted]


def _tool_schema(langchain_tool: Any) -> dict[str, Any]:
    """The JSON-schema dict for a langchain tool's arguments."""
    args = dict(getattr(langchain_tool, "args", None) or {})
    required = [
        name for name, spec in args.items()
        if isinstance(spec, dict) and "default" not in spec
    ]
    return {"type": "object", "properties": args, "required": required}


def _budget_refusal(parent_middleware: Sequence[Any], name: str) -> str | None:
    """Refusal text when the caller's own ToolCallBudget has no allowance left."""
    for mw in parent_middleware or ():
        refusal = getattr(mw, "refusal_for", None)
        if refusal is None:
            continue
        text = refusal(name)
        if text:
            return text
    return None


def _required_fact_tools(parent_middleware: Sequence[Any]) -> frozenset[str]:
    """Tool names the caller's EvidenceGate would have demanded before a verdict."""
    required: set[str] = set()
    for mw in parent_middleware or ():
        names = getattr(mw, "required_tools", None)
        if names:
            required |= set(names)
    return frozenset(required)


def _submit_guard(parent_middleware: Sequence[Any]) -> str | None:
    """Text to deny the forced ``StructuredOutput`` submit with, or ``None`` to allow it."""
    for mw in parent_middleware or ():
        hold = getattr(mw, "hold_for_verdict", None)
        if hold is None:
            continue
        text = hold()
        if text:
            return text
    return None


def _log_tool_call(name: str, payload: dict[str, Any], tag_sfx: str) -> None:
    """One stderr line per successful bridged tool call, in the sdk/deepagents line shape."""
    # NAME and SIZE only: content is never logged
    if is_stage_only():
        return
    size = len(payload["content"][0]["text"])
    console.write(f"      [cli-mcp] tool {name} -> {size} chars{tag_sfx}")


def _to_sdk_tools(langchain_tools: Sequence[Any], *,
                  parent_middleware: Sequence[Any],
                  called: set[str], tag: str | None = None) -> list[Any]:
    """Convert langchain tools to in-process SdkMcpTools with budget + redaction."""
    from claude_agent_sdk import tool as sdk_tool  # noqa: PLC0415 — lazy: SDK optional

    tag_sfx = f" [{tag}]" if tag else ""
    out: list[Any] = []
    for lc_tool in langchain_tools:
        # Bind EVERY loop variable as a default arg: late binding leaks the LAST tool's description
        def _make(bound_tool=lc_tool, bound_name=lc_tool.name,
                  bound_desc=(lc_tool.description or "").strip()):
            @sdk_tool(bound_name, bound_desc or bound_name,
                      _tool_schema(bound_tool))
            async def _handler(args: dict[str, Any]) -> dict[str, Any]:
                refusal = _budget_refusal(parent_middleware, bound_name)
                if refusal is not None:
                    return _content(refusal, is_error=True)
                called.add(bound_name)
                for mw in parent_middleware or ():
                    note = getattr(mw, "note_call", None)
                    if note is not None:
                        note(bound_name)
                try:
                    # Off-loop: a slow sync query must not stall the loop draining the CLI stream
                    result = await asyncio.to_thread(bound_tool.invoke, dict(args))
                except Exception as exc:  # noqa: BLE001 — a tool fault must not kill the loop
                    COUNTERS.bump(f"cli_mcp_tool_error_{bound_name}")
                    return _content(
                        f"{type(exc).__name__}: {redact(str(exc))}", is_error=True)
                payload = _content(_serialize(result))
                _log_tool_call(bound_name, payload, tag_sfx)
                return payload

            return _handler

        out.append(_make())
    return out


def _schema_for(response_model: type) -> dict[str, object]:
    """Lower a pydantic ``response_model`` to a plain schema dict for ``output_format``."""
    schema = dict(response_model.model_json_schema())
    schema.pop("title", None)
    schema.pop("$schema", None)
    return schema


def _serialize(result: object) -> str:
    """Render a tool result as text, JSON when it is structured."""
    if isinstance(result, str):
        return result
    try:
        return json.dumps(result, default=str)
    except (TypeError, ValueError):
        return str(result)


def _content(text: str, *, is_error: bool = False) -> dict[str, Any]:
    """An MCP tool result payload. Output is redaction-masked, as on every other route."""
    from vvaharness.backends.llm.agent_sdk import (  # noqa: PLC0415 — shared masker
        _redact_tool_output,
    )

    payload: dict[str, Any] = {
        "content": [{"type": "text", "text": cast("str", _redact_tool_output(text))}]
    }
    if is_error:
        payload["is_error"] = True
    return payload


# ── session options ──────────────────────────────────────────────────────────

def _bridge_env() -> dict[str, str]:
    """Ambient environment plus this route's TLS/proxy carriers — and nothing else."""
    # NOT agent_sdk._sdk_env(): it moves a subscription/OAuth operator onto API-key billing
    return {**os.environ, **_cli.env._tls_extra}


def _session_env(extra_env: dict[str, str] | None, tier: str | None) -> dict[str, str]:
    """The bridged session's env: ambient + TLS + per-call overrides + the cli session pins."""
    # Same pins as the cli route (see _session_pins)
    return {**_bridge_env(), **(extra_env or {}), **_cli._session_pins(tier)}


def _build_options(*, model: str, system_prompt: str | None,
                   allowed_tools: Sequence[str] | None, cwd: str,
                   mcp_tool_names: Sequence[str],
                   max_turns: int | None, max_budget_usd: float | None,
                   effort: str | None, allow_shell: bool, server: Any,
                   response_model: type | None = None,
                   parent_middleware: Sequence[Any] = (),
                   extra_env: dict[str, str] | None = None) -> Any:
    """Compose ClaudeAgentOptions for one bridged detection session."""
    try:
        from claude_agent_sdk import (  # noqa: PLC0415 — lazy: SDK stays optional
            ClaudeAgentOptions,
            HookMatcher,
        )
    except ImportError as e:
        raise RuntimeError(
            "This Claude Agent SDK build has no PreToolUse hook support "
            "(HookMatcher), which is what enforces this bridge's deny-by-default "
            "gate and read jail — reinstall vvaharness to pull in a newer SDK "
            "release, or set `cli.mcp_tools: false` to fall back to the plain "
            "subprocess route."
        ) from e
    from vvaharness.backends.llm.agent_sdk import (  # noqa: PLC0415 — shared gate/hook helpers
        _build_redaction_hooks,
        _resolve_within_root,
    )

    root = Path(cwd).resolve()
    native = _cli.session._bare_tool_names(allowed_tools)
    # Bash only on an explicit caller grant (step2.bash), never force-added: repos inject RCE
    if not allow_shell:
        native = [n for n in native if n != "Bash"]
    granted = frozenset(native)
    # Casefolded: resolve() does not case-normalise, so `Read(./.GIT/config)` slips a compare
    deny_dirs_cf = frozenset(d.casefold() for d in _cli._READ_DENY_DIRS)

    async def _pre_tool_use_gate(input_data, tool_use_id, context):  # noqa: ANN001, ARG001
        """PreToolUse hook: deny-by-default availability + read-jail path confinement."""
        # Must stay a PreToolUse hook, never `can_use_tool`: every tool this session can call is a
        # BARE entry in `allowed_tools`, which the SDK auto-approves before `can_use_tool` is ever
        # consulted, so that check (and any path check added to it) never ran.
        # DETECTION session: unlike agent_sdk's remediation gate there is no write arm at all —
        # Edit/Write is denied like any other tool absent from `granted`.
        # Read jail: `disallowed_tools`'s `Read(./{d}/**)` grammar is unconfirmed for Glob/Grep and
        # a regex cannot follow a symlink, so this hook ALSO resolves every path-typed argument
        # against `root`. `Grep`'s `pattern` stays unresolved: it is a content regex, so a literal
        # `"../"` in a search string must still search, not deny.
        # Fail-closed: an unexpected exception must deny, never fall through to the CLI's own
        # (looser) rule evaluation.
        def _deny(reason: str) -> dict:
            return {"hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": reason,
            }}

        try:
            tool_name = (input_data or {}).get("tool_name") or ""
            tool_input = (input_data or {}).get("tool_input") or {}

            if tool_name.startswith(TOOL_PREFIX):
                # Without this arm deny-by-default would refuse the very tools this module delivers
                return {}
            if tool_name == CLI_STRUCTURED_OUTPUT_TOOL:
                # CLI-published, never in `allowed_tools`: without this arm every submit is denied
                if response_model is None:
                    return _deny(f"{tool_name} is not permitted — this session has "
                                 f"no response_model configured.")
                # No mid-loop seam: this denial is how the EvidenceGate nudge reaches the model
                hold_text = _submit_guard(parent_middleware)
                if hold_text is not None:
                    return _deny(hold_text)
                return {}
            if tool_name not in granted:
                return _deny(f"{tool_name} is not permitted in this detection "
                             f"session — only {sorted(granted)} and this scan's "
                             f"fact tools are available, and nothing may modify "
                             f"the scanned repository.")
            keys = ("file_path", "path", "notebook_path")
            if tool_name == "Glob":
                keys = (*keys, "pattern")
            elif tool_name == "Grep":
                # `glob` is path-shaped and was NOT denied; `pattern` stays out (content regex)
                keys = (*keys, "glob")
            found_path_arg = False
            for key in keys:
                raw = tool_input.get(key)
                if not raw:
                    continue
                found_path_arg = True
                resolved = _resolve_within_root(root, raw)
                if resolved is None:
                    return _deny(f"{tool_name} target {raw!r} is outside the "
                                 f"repository root, unresolvable, or a symlink — "
                                 f"reads are confined to {root}")
                # Top-level only, like cli.py's `./{d}/**`: a nested same-named dir is not a target
                parts = resolved.relative_to(root).parts
                if parts and parts[0].casefold() in deny_dirs_cf:
                    return _deny(f"{tool_name} target {raw!r} falls under the "
                                 f"internal {parts[0]!r} directory, which is "
                                 f"never readable in a scan session.")
            # Read's path must FAIL CLOSED: "no decision" auto-approves a pathless, unconfined Read
            if tool_name == "Read" and not found_path_arg:
                return _deny(f"{tool_name} requires a file path argument, and none "
                             f"was found in this call — denied as a precaution "
                             f"rather than defaulting to an unconfined read.")
            return {}
        except Exception as exc:  # noqa: BLE001 — a gate must fail closed, not open
            return _deny(f"the security gate could not evaluate this call "
                         f"({type(exc).__name__}) and denies it as a precaution.")

    # Masks NATIVE tool output (MCP results in `_content`); best-effort: an old SDK returns None
    redaction_hooks = _build_redaction_hooks() or {}
    hooks = {**redaction_hooks, "PreToolUse": [HookMatcher(hooks=[_pre_tool_use_gate])]}

    # Unset effort inherits the scan-pinned `cli.effort`, never the operator's interactive default
    tier = _cli._effective_effort(effort)

    opts = ClaudeAgentOptions(
        model=model,
        cwd=str(root),
        env=_session_env(extra_env, tier),
        cli_path=_cli._CLAUDE_CMD[0],
        mcp_servers={SERVER_NAME: server},
        # Verified: without this a target repo's `.mcp.json` server IS spawned into the session
        strict_mcp_config=True,
        # `user` keeps apiKeyHelper auth; repo settings could re-grant Bash or register host hooks
        setting_sources=("user",),
        # A scanned repo's `.claude/commands` / skills are prompt-injection surface.
        extra_args={"disable-slash-commands": None},
        # AVAILABILITY, not an allowlist: `--permission-mode auto` can approve an unlisted tool
        tools=native,
        allowed_tools=[*native, *mcp_tool_names],
        # `.git` holds tokens; prior output is not evidence. Read only — the hook covers Glob/Grep
        disallowed_tools=[
            *([] if allow_shell else ["Bash"]),
            *(f"Read(./{d}/**)" for d in _cli._READ_DENY_DIRS),
        ],
        permission_mode="default",
        hooks=hooks,
        # Covers the @path-expansion half the disable-slash-commands arg above doesn't;
        # scanned-repo text (code snippets, finding descriptions) reaches this prompt.
        verbatim_prompts=True,
    )
    if system_prompt is not None:
        opts.system_prompt = system_prompt
    if max_turns is not None:
        opts.max_turns = int(max_turns)
    if max_budget_usd is not None:
        opts.max_budget_usd = float(max_budget_usd)
    if tier:
        opts.effort = tier
    if response_model is not None:
        opts.output_format = {"type": "json_schema", "schema": _schema_for(response_model)}
    return opts


# ── session runner ───────────────────────────────────────────────────────────

class _SessionTruncatedError(Exception):
    """Internal signal: the terminal ``ResultMessage`` reported a ``max_tokens`` stop."""
    # Never let a caller see this class: only agentic_with_tools' retry loop may catch it.


class _SessionResultError(Exception):
    """Internal signal: the terminal ``ResultMessage`` reported an error."""
    # Deliberately NOT RuntimeError: it must reach the generic arm so _reraise_transport types it


async def _run(*, user_prompt: str, opts: Any, timeout: float | None = None,
               tag: str | None = None, effort: str | None = None) -> str:
    """Stream one bridged session to completion and return its final text."""
    # Trust-check the terminal ResultMessage: an errored/cut-off session returns text as complete
    from claude_agent_sdk import (  # noqa: PLC0415 — lazy: SDK stays optional
        AssistantMessage,
        ClaudeSDKClient,
        TextBlock,
    )

    from vvaharness.backends.llm.agent_sdk import drain_until_result  # noqa: PLC0415 — shared drain

    parts: list[str] = []

    def _on_message(message: Any) -> None:
        if _cli.aborted():
            # Not in cli.py's kill-list: this poll is the only stop path
            raise RuntimeError("aborted by user (Ctrl-C)")
        if isinstance(message, AssistantMessage):
            for block in message.content:
                if isinstance(block, TextBlock):
                    parts.append(block.text)
                    _cli.stream_trace(json.dumps({
                        "type": "assistant",
                        "message": {"content": [{"type": "text",
                                                 "text": block.text}]},
                    }))

    started = time.monotonic()
    async with ClaudeSDKClient(options=opts) as client:
        await client.query(user_prompt)
        drained = await drain_until_result(client, on_message=_on_message, timeout=timeout,
                                           grace=TIMEOUT_STOP_GRACE_SECONDS)
    elapsed = time.monotonic() - started

    result = drained.result
    usage = cast("dict | None", result.usage) if result is not None else None
    usd = result.total_cost_usd if result is not None else None
    turns = result.num_turns if result is not None else None
    # Unconditional: a usage-less session is still one call, and None (not 0) means "unreported"
    TOKENS.add(cast("TokenUsage", usage), usd=usd, turns=turns)

    if drained.timed_out:
        raise call_timeout_error(
            stage=tag or "", route="cli-mcp", budget_s=timeout, effort=effort,
            cause_text=f"cli MCP bridge session exceeded {timeout:g}s")

    note_budget_use(elapsed, timeout, effort)
    stop_reason = result.stop_reason if result is not None else None
    if stop_reason:
        console.write(f"    [cli-mcp] usage: stop_reason={stop_reason}")
    result_text = result.result if result is not None else None
    _check_terminal_result(
        stop_reason=stop_reason,
        is_error=result.is_error if result is not None else False,
        subtype=result.subtype if result is not None else None,
        api_error_status=result.api_error_status if result is not None else None,
        errors=result.errors if result is not None else None,
        result_text=result_text, tag=tag)
    structured = result.structured_output if result is not None else None
    _note_structured_miss(opts, structured)
    structured_text = _cli._structured_text({"structured_output": structured})
    return (structured_text or result_text or "".join(parts)).strip()


def _note_structured_miss(opts: Any, structured: object) -> None:
    """Count and announce a structured session that ended with no ``structured_output``."""
    # Not a raise: dispatch_or_retry_unforced would re-run the whole session for it, and the
    # stage's own JSON parse/repair of the text reply is the cheaper recovery.
    if opts.output_format is None or structured is not None:
        return
    COUNTERS.bump("cli_mcp_structured_output_missing")
    warn_once(_WARNED, f"structured_missing:{opts.model}",
              f"WARN [cli-mcp]: a structured session on {opts.model} ended without a "
              f"structured_output; using the text reply instead (the calling stage "
              f"parses or repairs it). Counted under `cli_mcp_structured_output_missing`.")


def _check_terminal_result(*, stop_reason: str | None, is_error: bool,
                           subtype: str | None, api_error_status: int | None,
                           errors: list | None, result_text: str | None,
                           tag: str | None = None) -> None:
    """Raise unless the terminal ``ResultMessage`` is a complete, trustworthy reply."""
    # Refusal first (usage already banked): it may also report is_error, hiding it as untyped
    if stop_reason == ANTHROPIC_STOP_REFUSAL:
        raise model_refusal(route="cli-mcp", stage=tag or "", category=None)
    # ``max_tokens`` next: a truncated submit can also carry ``is_error`` on some CLI builds
    if stop_reason == _cli.ANTHROPIC_STOP_MAX_TOKENS:
        raise _SessionTruncatedError(stop_reason)
    if is_error or (subtype and subtype != "success"):
        detail = "; ".join(str(e) for e in (errors or []) if e) or (
            (result_text or "").strip() or "no detail reported by the CLI")
        # The real CLI reports a cap hit as stop_reason=stop_sequence with this prose instead
        # (cli.py's own _truncation_cap() exists for the identical reason) -- check that shape too
        if CLI_TOKEN_CAP_RX.search(detail):
            raise _SessionTruncatedError(stop_reason)
        raise _SessionResultError(
            f"subtype={subtype!r} is_error={is_error} "
            f"api_error_status={api_error_status!r}: {detail}")


def _reraise_transport(exc: Exception, *, tag: str) -> None:
    """Map an SDK-side failure onto this codebase's typed transport errors."""
    # Never passes cli._run_with_retry, so no classification for free; regexes are cli.py's own
    text = redact(str(exc))[:400]
    if _cli._PROXY_FAILURE.search(text):
        raise ProxyError(
            text, status_code=407 if re.search(r"\b407\b", text) else None,
            backend="cli") from exc
    if _cli._AUTH_FAILURE.search(text):
        raise AuthenticationError(text, status_code=401, backend="cli") from exc
    raise RuntimeError(f"cli MCP bridge failed [{tag}]: {text}") from exc


def _truncation_retry_budget(trunc_retried: int, *, tag: str | None,
                             max_tokens: int | None = None) -> tuple[int, int | None]:
    """(requested, retry_at) for one doubled-budget truncation retry; logs when useful."""
    # ResultMessage reports only ``stop_reason``, never the budget hit: on a retry, what was
    # actually sent (trunc_retried) wins; else a caller-supplied max_tokens; else env/ceiling
    if trunc_retried or max_tokens:
        requested = trunc_retried or max_tokens
    else:
        try:
            requested = int(os.environ.get("CLAUDE_CODE_MAX_OUTPUT_TOKENS")
                            or _cli.MODEL_MAX_OUTPUT_TOKENS)
        except (TypeError, ValueError):
            requested = _cli.MODEL_MAX_OUTPUT_TOKENS
    retry_at = (None if trunc_retried else
                _cli.truncation_retry_max(requested, cap=_cli.MODEL_MAX_OUTPUT_TOKENS))
    if retry_at is not None:
        _cli._log_truncation_retry(tag=tag, requested=requested, retry_at=retry_at,
                                   label="cli-mcp")
    return requested, retry_at


def agentic_with_tools(
    user_prompt: str,
    *,
    model: str,
    system_prompt: str | None = None,
    allowed_tools: Sequence[str] | None = None,
    cwd: str,
    tool_builder: Any,
    fact_tools: Sequence[str] = (),
    parent_middleware: Sequence[Any] = (),
    max_turns: int | None = None,
    max_budget_usd: float | None = None,
    max_tokens: int | None = None,
    effort: str | None = None,
    allow_shell: bool = False,
    response_model: type | None = None,
    tag: str | None = None,
    timeout: float | None = None,
) -> str:
    """Run an agentic `claude` session that can call the caller's in-process tools."""
    # Bounds EACH attempt, not a shared deadline; without it a session bills on in a dead thread
    if not available():
        raise RuntimeError(
            "via: cli with caller-supplied tools needs the Claude Agent SDK "
            "(claude-agent-sdk), which is a declared dependency. Reinstall "
            "vvaharness (pip install .), set `cli.mcp_tools: false` to run this "
            "stage without its graph/CWE tools, or route the role via: deepagents.")
    from claude_agent_sdk import (  # noqa: PLC0415 — lazy: SDK stays optional
        create_sdk_mcp_server,
    )

    if _cli.aborted():
        raise RuntimeError("aborted by user (Ctrl-C)")

    lc_tools = _materialize(tool_builder, model=model, cwd=cwd,
                            fact_tools=fact_tools)
    if not lc_tools:
        # Nothing to bridge: fail loudly rather than run a silently tool-less session
        raise RuntimeError(
            f"cli MCP bridge was asked for tools {sorted(fact_tools)} but the "
            f"caller's tool_builder produced none — refusing to run a tool-less "
            f"session that the prompt advertises tools for.")

    called: set[str] = set()
    sdk_tools = _to_sdk_tools(lc_tools, parent_middleware=parent_middleware,
                              called=called, tag=tag)
    server = create_sdk_mcp_server(SERVER_NAME, tools=sdk_tools)
    wire_names = [mcp_name(t.name) for t in lc_tools]

    # Resolved once, reused for both the session clock and opts.effort (_build_options is idempotent
    # on an already-resolved tier).
    tier = _cli._effective_effort(effort)
    scaled_timeout = effort_scaled_seconds(timeout, tier, kind=ClockKind.SESSION)

    tag_sfx = f" [{tag}]" if tag else ""
    console.write(f"    [cli-mcp] agentic mode -> {model}{tag_sfx}, cwd={cwd}, "
                  f"tools={[t.name for t in lc_tools]}"
                  f"{f', max_tokens={max_tokens}' if max_tokens else ''}")

    # VVAH-E005: one doubled-budget retry then raise; only this loop sees _SessionTruncatedError
    trunc_retried = 0
    extra_env = {"CLAUDE_CODE_MAX_OUTPUT_TOKENS": str(max_tokens)} if max_tokens else None
    while True:
        opts = _build_options(
            model=model, system_prompt=system_prompt, allowed_tools=allowed_tools,
            cwd=cwd, mcp_tool_names=wire_names, max_turns=max_turns,
            max_budget_usd=max_budget_usd, effort=tier, allow_shell=allow_shell,
            server=server, response_model=response_model,
            parent_middleware=parent_middleware, extra_env=extra_env,
        )
        try:
            text = asyncio.run(_run(user_prompt=user_prompt, opts=opts,
                                    timeout=scaled_timeout, tag=tag, effort=tier))
        except _SessionTruncatedError:
            requested, retry_at = _truncation_retry_budget(
                trunc_retried, tag=tag, max_tokens=max_tokens)
            if retry_at is not None:
                extra_env = {"CLAUDE_CODE_MAX_OUTPUT_TOKENS": str(retry_at)}
                trunc_retried = retry_at
                continue
            raise _cli._truncation_error(requested=requested, retried=trunc_retried,
                                         tag=tag, retry_at=retry_at) from None
        except (AuthenticationError, ProxyError, RuntimeError, TimeoutError):
            raise
        except Exception as exc:  # noqa: BLE001 — SDK raises a wide, versioned family
            _reraise_transport(exc, tag=tag or "")
            raise  # unreachable; _reraise_transport always raises
        if trunc_retried:
            COUNTERS.bump(TRUNCATED_RETRY_RECOVERED_COUNTER)
        break

    _report_evidence_degradation(parent_middleware, called, tag=tag or "")
    check_response_quality(text, stage=tag or "")
    return text


def _report_evidence_degradation(parent_middleware: Sequence[Any],
                                 called: set[str], *, tag: str) -> None:
    """Count and announce a verdict that shipped without ever consulting a required tool."""
    # _submit_guard already relented after max_rejections; residual telemetry, not a skipped gate
    required = _required_fact_tools(parent_middleware)
    if not required or (required & called):
        return
    COUNTERS.bump(EVIDENCE_UNENFORCED_COUNTER)
    warn_once(
        _WARNED, f"evidence-gate:{tag}",
        f"WARN [cli-mcp]: {tag or 'this stage'} requires graph evidence, but the "
        f"session called none of {sorted(required)}. The forced structured-output "
        f"submit was already denied and re-asked up to max_rejections times before "
        f"being let through. The reply was accepted as-is and counted under "
        f"`{EVIDENCE_UNENFORCED_COUNTER}` in Pipeline Diagnostics.")


__all__ = [
    "EVIDENCE_UNENFORCED_COUNTER",
    "SERVER_NAME",
    "TOOL_PREFIX",
    "agentic_with_tools",
    "available",
    "mcp_name",
]
