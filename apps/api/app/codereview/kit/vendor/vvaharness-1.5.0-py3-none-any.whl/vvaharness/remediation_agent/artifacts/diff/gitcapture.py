# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Real ``git diff`` capture: a scoped diff for a file set, plus the unscoped whole-tree changed set."""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from vvaharness.remediation_agent.artifacts.diff.paths import _norm_path, _safe_repo_path
from vvaharness.util import logs

log = logs.get_logger(__name__)


def changed_files_whole_tree(repo: Path) -> list[str]:
    """Return EVERY changed path in *repo*'s working tree (repo-relative)."""
    # Post-gate ground truth for edits omitted from verdict.changes; NEVER git add -N (writes index)
    repo = Path(repo)
    root = repo.resolve()
    try:
        chk = subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, timeout=15)
        if chk.returncode != 0 or chk.stdout.strip() != "true":
            return []
        top = subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, timeout=15)
        if top.returncode != 0 or not top.stdout.strip():
            return []
        toplevel = Path(top.stdout.strip()).resolve()
        out = subprocess.run(
            # Pathspec confines the scan to repo's own subtree even when repo has no
            # .git of its own and sits nested inside a larger enclosing work tree --
            # without it, git silently reports the WHOLE enclosing tree's changes.
            ["git", "-C", str(repo), "status", "--porcelain", "-z",
             "--untracked-files=all", "--", "."],
            capture_output=True, text=True, timeout=60)
        if out.returncode != 0:
            return []
    except Exception:  # noqa: BLE001 — never break a run
        return []

    files: list[str] = []
    seen: set[str] = set()

    def _add(path: str) -> None:
        if not path:
            return
        # git status reports paths relative to the discovered toplevel, which is
        # repo itself only when repo is its own git root. Re-relativize to repo so
        # a nested (non-own-git) repo never leaks an enclosing-tree-relative path,
        # and drop anything that still falls outside repo as a defensive no-op.
        try:
            rel = (toplevel / path).resolve().relative_to(root).as_posix()
        except ValueError:
            return
        if rel not in seen:
            seen.add(rel)
            files.append(rel)

    # Rename/copy's bare NUL token has no `XY ` prefix: a 3-char strip mangles it and escapes revert
    records = out.stdout.split("\0")
    i, n = 0, len(records)
    while i < n:
        rec = records[i]
        i += 1
        if not rec:
            continue
        _add(rec[3:] if len(rec) > 3 else "")
        if ("R" in rec[:2] or "C" in rec[:2]) and i < n:
            _add(records[i])
            i += 1
    return files


def capture_git_diff(repo: Path, files: list[str], *,
                     baseline: dict[str, str | None] | None = None) -> str | None:
    """Return a unified ``git diff`` for *files* in *repo* (scoped to *baseline*'s pre-edit content when given), or ``None`` when no diff can be produced."""
    # Runs against a throwaway copy of the index (GIT_INDEX_FILE) so the repo's real index is never touched.
    repo = Path(repo)
    # Confine LLM-controlled refs before git: a UNC ref leaks the runner's NetNTLMv2 hash via SMB
    root = repo.resolve()
    paths: list[str] = []
    for f in (files or []):
        safe = _safe_repo_path(repo, f)
        if safe is not None:
            paths.append(safe.relative_to(root).as_posix())
    if not paths:
        return None
    env = {**os.environ, "LC_ALL": "C"}
    git = ["git", "-C", str(repo), "-c", "color.ui=false"]
    try:
        chk = subprocess.run(
            [*git, "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, timeout=15, env=env)
        if chk.returncode != 0 or chk.stdout.strip() != "true":
            return None

        gd = subprocess.run([*git, "rev-parse", "--git-dir"],
                            capture_output=True, text=True, timeout=15, env=env)
        git_dir = Path(gd.stdout.strip()) if gd.returncode == 0 and gd.stdout.strip() else None
        if git_dir is not None and not git_dir.is_absolute():
            git_dir = (repo / git_dir).resolve()
        real_index = (git_dir / "index") if git_dir is not None else None

        with tempfile.TemporaryDirectory() as tmp:
            tmp_index = Path(tmp) / "index"
            if real_index is not None and real_index.exists():
                shutil.copyfile(real_index, tmp_index)
            scoped_env = {**env, "GIT_INDEX_FILE": str(tmp_index)}

            if baseline:
                baseline_norm = {_norm_path(k): v for k, v in baseline.items()}
                for rel in paths:
                    if rel not in baseline_norm:
                        continue
                    old = baseline_norm[rel]
                    if old is None:
                        # Didn't exist pre-case: drop it so it diffs as a brand-new file.
                        subprocess.run([*git, "update-index", "--force-remove", "--", rel],
                                       capture_output=True, text=True, timeout=30, env=scoped_env)
                        continue
                    blob = subprocess.run([*git, "hash-object", "-w", "--stdin"],
                                          input=old, capture_output=True, text=True,
                                          timeout=30, env=scoped_env)
                    sha = blob.stdout.strip()
                    if blob.returncode == 0 and sha:
                        subprocess.run(
                            [*git, "update-index", "--add", "--cacheinfo",
                             f"100644,{sha},{rel}"],
                            capture_output=True, text=True, timeout=30, env=scoped_env)

            subprocess.run([*git, "add", "-N", "--", *paths],
                           capture_output=True, text=True, timeout=30, env=scoped_env)
            out = subprocess.run(
                [*git, "diff", "--no-ext-diff", "--", *paths],
                capture_output=True, text=True, timeout=60, env=scoped_env)
            diff = out.stdout
            return diff if diff.strip() else None
    except Exception:  # noqa: BLE001 — diff capture must never break a run
        return None
