# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""In-process langchain-tool adapter: caller fact tools on `via: sdk` / `via: openai`."""

# In-process is the only transport (live ArcadeDB GraphHandle); todos/subagents stay deepagents-only
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from pydantic import ValidationError

from vvaharness.backends.llm import tools as _localtools
from vvaharness.report.redact import redact, redact_counts
from vvaharness.util import console
from vvaharness.util.counters import COUNTERS
from vvaharness.util.scan_progress import is_stage_only
from vvaharness.util.warn_once import warn_once

if TYPE_CHECKING:
    from collections.abc import Sequence

#: Bumped when a session shipped a verdict without ever calling a required tool.
EVIDENCE_UNENFORCED_COUNTER = "llm_adapter_evidence_gate_unenforced"

#: One entry per distinct degradation already reported, so stderr is not flooded.
_WARNED: set[str] = set()


def _materialize(tool_builder: Any, *, model: str, cwd: str,
                 fact_tools: Sequence[str]) -> list[Any]:
    """Run the caller's ``ToolBuilder`` and keep only its fact tools."""
    from vvaharness.backends.harness import StreamingOptions  # noqa: PLC0415 — lazy

    wanted = set(fact_tools)
    if not wanted:
        return []
    options = StreamingOptions(model=model, cwd=Path(cwd),
                               fact_tools=tuple(fact_tools))
    built = tool_builder(options, allowed_tools=()) or []
    return [t for t in built if getattr(t, "name", None) in wanted]


def _tool_schema(langchain_tool: Any) -> dict[str, Any]:
    """The JSON-schema object for a langchain tool's arguments."""
    args = dict(getattr(langchain_tool, "args", None) or {})
    required = [
        name for name, spec in args.items()
        if isinstance(spec, dict) and "default" not in spec
    ]
    return {"type": "object", "properties": args, "required": required}


def _anthropic_schema(langchain_tool: Any) -> dict[str, Any]:
    """One Anthropic Messages tool schema for a langchain tool."""
    name = str(getattr(langchain_tool, "name", "") or "")
    desc = (getattr(langchain_tool, "description", "") or "").strip()
    return {"name": name, "description": desc or name,
            "input_schema": _tool_schema(langchain_tool)}


def _budget_refusal(parent_middleware: Sequence[Any], name: str) -> str | None:
    """Refusal text when one of the caller's own budgets has no allowance left."""
    for mw in parent_middleware or ():
        refusal = getattr(mw, "refusal_for", None)
        if refusal is None:
            continue
        text = refusal(name)
        if text:
            return text
    return None


def _required_fact_tools(parent_middleware: Sequence[Any]) -> frozenset[str]:
    """Tool names the caller's EvidenceGate would have demanded before a verdict."""
    required: set[str] = set()
    for mw in parent_middleware or ():
        names = getattr(mw, "required_tools", None)
        if names:
            required |= set(names)
    return frozenset(required)


def _serialize(result: object) -> str:
    """Render a tool result as text, JSON when it is structured."""
    if isinstance(result, str):
        return result
    try:
        return json.dumps(result, default=str)
    except (TypeError, ValueError):
        return str(result)


@dataclass
class ToolStack:
    """The materialised tools for one session, in the shape both agentic loops accept."""

    #: Anthropic-shape tool schemas to pass as ``extra_tools``.
    schemas: list[dict[str, Any]]
    #: Tool names, for the dispatch log line.
    names: tuple[str, ...]
    #: Tools a verdict must be backed by, per the caller's EvidenceGate.
    required: frozenset[str] = frozenset()
    _tools: dict[str, Any] = field(default_factory=dict)
    _middleware: tuple[Any, ...] = ()
    _called: set[str] = field(default_factory=set)

    @staticmethod
    def _validation_error(lc_tool: Any, args: dict[str, Any]) -> ValidationError | None:
        """*args* checked against *lc_tool*'s schema, or ``None`` when it has none or passes."""
        schema = getattr(lc_tool, "args_schema", None)
        if not hasattr(schema, "model_validate"):
            return None
        try:
            schema.model_validate(args or {})
        except ValidationError as exc:
            return exc
        return None

    def _tool_fault(self, name: str, args: dict[str, Any], exc: Exception, *,
                    tag: str | None) -> str:
        """Count, log, and format a tool fault as the adapter's standard error string."""
        COUNTERS.bump(f"llm_adapter_tool_error_{name}")
        err = f"ERROR: {type(exc).__name__}: {redact(str(exc))}"
        self._log_dispatch(name, args, err, tag=tag)
        return err

    def _rejected(self, lc_tool: Any, name: str, args: dict[str, Any], *,
                 tag: str | None) -> str | None:
        """Validation or budget rejection text for this call, or ``None`` to proceed."""
        invalid = self._validation_error(lc_tool, args)
        if invalid is not None:
            return self._tool_fault(name, args, invalid, tag=tag)
        refusal = _budget_refusal(self._middleware, name)
        if refusal is not None:
            self._log_dispatch(name, args, f"refused: {refusal}", tag=tag)
            return refusal
        return None

    def dispatch(self, name: str, args: dict[str, Any], *,
                tag: str | None = None) -> str | None:
        """Run one adapted tool, or return ``None`` so the loop's localtools get the name."""
        lc_tool = self._tools.get(name)
        if lc_tool is None:
            return None
        rejection = self._rejected(lc_tool, name, args, tag=tag)
        if rejection is not None:
            return rejection
        self._called.add(name)
        for mw in self._middleware or ():
            note = getattr(mw, "note_call", None)
            if note is not None:
                note(name)
        try:
            result = lc_tool.invoke(dict(args or {}))
        except Exception as exc:
            return self._tool_fault(name, args, exc, tag=tag)
        masked, _ = redact_counts(_serialize(result))
        out = _localtools.cap_tool_result(masked)
        self._log_dispatch(name, args, f"{len(out)} chars", tag=tag)
        return out

    def _log_dispatch(self, name: str, args: dict[str, Any], outcome: str, *,
                      tag: str | None = None) -> None:
        if is_stage_only():
            return
        console.write(f"      [tool-adapter] tool {name}({_localtools.summarize_args(args)}) "
                      f"-> {outcome}{f' [{tag}]' if tag else ''}")

    def exhausted_tools(self) -> frozenset[str]:
        """Union of every metered tool name whose caller-owned budget is now spent."""
        out: set[str] = set()
        for mw in self._middleware or ():
            names = getattr(mw, "exhausted_tools", None)
            if names is None:
                continue
            out |= set(names())
        return frozenset(out)

    def submit_guard(self) -> str | None:
        """Text to hand back as a tool result instead of the verdict, or ``None`` to allow it."""
        for mw in self._middleware or ():
            hold = getattr(mw, "hold_for_verdict", None)
            if hold is None:
                continue
            text = hold()
            if text:
                return text
        return None

    def report_evidence_degradation(self, *, tag: str, label: str) -> None:
        """Count and announce a verdict that shipped without ever consulting a required tool."""
        # submit_guard already relented after max_rejections; residual telemetry, not a skipped gate
        if not self.required or (self.required & self._called):
            return
        COUNTERS.bump(EVIDENCE_UNENFORCED_COUNTER)
        warn_once(
            _WARNED, f"evidence-gate:{label}:{tag}",
            f"WARN [{label}]: {tag or 'this stage'} requires graph evidence, but the "
            f"session called none of {sorted(self.required)}. submit_guard already "
            f"rejected this verdict's submit up to max_rejections times (the same "
            f"relent every EvidenceGate performs, in-loop or out-of-loop) before "
            f"letting it through. The reply was accepted as-is and counted under "
            f"`{EVIDENCE_UNENFORCED_COUNTER}` in Pipeline Diagnostics.")


def build(tool_builder: Any, *, model: str, cwd: str,
          fact_tools: Sequence[str],
          parent_middleware: Sequence[Any] = ()) -> ToolStack | None:
    """Adapt the caller's ``tool_builder`` for one ``sdk``/``openai`` agentic session."""
    # None means "nothing to carry" so the caller withholds the tool paragraph from the prompt
    if tool_builder is None or not fact_tools:
        return None
    lc_tools = _materialize(tool_builder, model=model, cwd=cwd,
                            fact_tools=fact_tools)
    if not lc_tools:
        return None
    return ToolStack(
        schemas=[_anthropic_schema(t) for t in lc_tools],
        names=tuple(str(t.name) for t in lc_tools),
        required=_required_fact_tools(parent_middleware),
        _tools={str(t.name): t for t in lc_tools},
        _middleware=tuple(parent_middleware or ()),
    )


__all__ = [
    "EVIDENCE_UNENFORCED_COUNTER",
    "ToolStack",
    "build",
]
