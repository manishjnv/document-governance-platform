# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Middleware that caps how many times a session may call a named set of tools."""

# Nothing else bounds tool-call VOLUME: turn and token ceilings bound the conversation, not calls

from __future__ import annotations

import threading
from collections.abc import Awaitable, Callable
from typing import Any

from langchain.agents.middleware.types import (
    AgentMiddleware,
    ModelRequest,
    ModelResponse,
    ToolCallRequest,
)
from langchain_core.messages import HumanMessage, ToolCall, ToolMessage
from langgraph.types import Command

from vvaharness.util.counters import COUNTERS
from vvaharness.util.warn_once import stage_label, warn_once

_BUDGET_MESSAGE = (
    "Your tool-call budget for this session is exhausted. Do not call any "
    "further tool in the metered set; finish from the evidence you already have. "
    "Calling one again will not run and only spends a turn."
)

_DEFAULT_COUNTER = "tool_call_budget_exhausted"

#: counter name -> the scan-config key an operator would raise; unlisted counters get a
#: generic phrase so a future stage's budget still warns without a new table row.
_KNOB_NAMES: dict[str, str] = {
    "s2_graph_tool_budget_exhausted": "step2.graph_tool_budget",
    "s4_graph_tool_budget_exhausted": "step4.graph_tool_budget",
    "s4_cwe_tool_budget_exhausted": "step4.cwe_tool_budget",
    "s6_graph_tool_budget_exhausted": "step6_verify.graph_tool_budget",
}

_WARNED_EXHAUSTED: set[str] = set()


def _calls_counter_name(counter: str, tool: str) -> str:
    """The usage-tally key for *tool*, derived from the exhaustion counter's own name."""
    if counter == _DEFAULT_COUNTER:
        return f"tool_calls_{tool}"
    return f"{counter.removesuffix('_budget_exhausted')}_calls_{tool}"


def _exhaustion_warning(counter: str, limit: int, tool_names: frozenset[str]) -> str:
    """The once-per-(stage, family)-per-run WARN line for the first refusal on *counter*."""
    knob = _KNOB_NAMES.get(counter, "its scan-config budget knob")
    names = ", ".join(sorted(tool_names))
    return (
        f"WARN {stage_label(counter)}: tool-call budget ({knob}={limit} per session) "
        f"exhausted in at least one session for {names} -- further calls there are refused "
        "now, and the tool family is withdrawn once the model calls again; it finishes from "
        f"the evidence it already has. Count in the run manifest under {counter}. Raise the "
        "knob in the scan config if this recurs."
    )


def _refuse(tool_call: ToolCall, content: str) -> ToolMessage:
    """A synthetic error ToolMessage explaining why a call was not executed."""
    return ToolMessage(content=content, name=tool_call["name"],
                       tool_call_id=tool_call["id"], status="error")


def _withdrawn_notice(tool_names: frozenset[str]) -> HumanMessage:
    """The one-time turn appended when a metered tool is removed from availability."""
    return HumanMessage(content=(
        f"Your budget for {', '.join(sorted(tool_names))} is exhausted; it/they have been "
        "withdrawn from your available tools for the rest of this session -- finish from "
        "the evidence you already have rather than asking for it/them again."
    ))


class ToolCallBudget(AgentMiddleware):
    """Refuse any metered tool call once one session has spent its total allowance."""
    # NEVER meter every tool: a structured-output call is a tool call, and blocking it strands

    def __init__(self, tool_names: frozenset[str], *, limit: int,
                 counter: str = "tool_call_budget_exhausted") -> None:
        """Allow *limit* calls across *tool_names* in this session, then refuse the rest."""
        super().__init__()
        self._tool_names = tool_names
        self._limit = limit
        self._counter = counter
        self._spent = 0
        self._lock = threading.Lock()
        self._withdrawal_announced = False

    @property
    def name(self) -> str:
        """Per-instance name; langchain asserts middleware names are unique per agent."""
        # name defaults to the CLASS name: two budgets per session trip factory.py's unique assert
        return f"{self.__class__.__name__}[{self._counter}]"

    def _claim(self) -> bool:
        """Take one unit of budget, returning whether there was any left."""
        with self._lock:
            if self._spent >= self._limit:
                return False
            self._spent += 1
            return True

    def _gate(self, tool_call: ToolCall) -> ToolMessage | None:
        """The refusal to return when the budget is gone, else None to proceed."""
        if tool_call["name"] not in self._tool_names:
            return None
        if self._claim():
            COUNTERS.bump(_calls_counter_name(self._counter, tool_call["name"]))
            return None
        COUNTERS.bump(self._counter)
        warn_once(_WARNED_EXHAUSTED, self._counter,
                  _exhaustion_warning(self._counter, self._limit, self._tool_names))
        return _refuse(tool_call, _BUDGET_MESSAGE)

    def exhausted_tools(self) -> frozenset[str]:
        """The metered tool name(s) with no allowance left, or ``frozenset()`` while any remains."""
        with self._lock:
            return self._tool_names if self._spent >= self._limit else frozenset()

    def refusal_for(self, tool_name: str) -> str | None:
        """Claim one unit for *tool_name*, returning the refusal text when none is left."""
        # OUT-OF-LOOP wrap_tool_call for non-langchain backends; shares this instance's counters
        refusal = self._gate({"name": tool_name, "id": "out-of-loop", "args": {}})
        return None if refusal is None else str(refusal.content)

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage | Command[Any]],
    ) -> ToolMessage | Command[Any]:
        """Execute while budget remains; otherwise refuse without running the tool."""
        return self._gate(request.tool_call) or handler(request)

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command[Any]]],
    ) -> ToolMessage | Command[Any]:
        """Async counterpart of :meth:`wrap_tool_call`."""
        refusal = self._gate(request.tool_call)
        return refusal if refusal is not None else await handler(request)

    def _withdraw(self, request: ModelRequest) -> ModelRequest:
        """*request* with this budget's exhausted tool(s) removed from the tool list."""
        kept = [t for t in (request.tools or [])
               if getattr(t, "name", None) not in self._tool_names]
        messages = request.messages
        if not self._withdrawal_announced:
            self._withdrawal_announced = True
            messages = [*messages, _withdrawn_notice(self._tool_names)]
        return request.override(tools=kept, messages=messages)

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        """Withdraw this budget's tool(s) from the request once its pool is spent."""
        if self.exhausted_tools():
            request = self._withdraw(request)
        return handler(request)

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelResponse:
        """Async counterpart of :meth:`wrap_model_call`."""
        if self.exhausted_tools():
            request = self._withdraw(request)
        return await handler(request)


__all__ = ["ToolCallBudget"]
