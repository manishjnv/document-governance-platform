# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""orchestrator.config_paths — see package docstring."""
from __future__ import annotations
from vvaharness.util import logs

import os
from pathlib import Path

from vvaharness.config import ConfigPolicyError, is_network_path

# Safe at module scope: `exploit_verification/__init__` is empty, `settings` stdlib-only: no cycle
from vvaharness.exploit_verification.settings import EV_MODULES as _EV_MODULES
from vvaharness.util.events import Event

log = logs.get_logger(__name__)


def _app_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _default_config() -> Path:
    cwd_cfg = Path.cwd() / "config.yaml"
    if cwd_cfg.exists():
        return cwd_cfg
    return _packaged_default()


def _packaged_default() -> Path:
    """The bundled default profile — the trusted fallback used when a config sourced from inside the scan target..."""
    return _app_root() / "config" / "profiles" / "default.yaml"


def _path_within(candidate, root) -> bool:
    """True if `candidate` resolves at or under `root` (both fully resolved)."""
    try:
        cand, base = Path(candidate).resolve(), Path(root).resolve()
    except (OSError, RuntimeError):
        return False
    if cand.is_relative_to(base):
        return True
    # resolve() does not case-normalise (APFS/NTFS): `--repo /x/REPO` must still contain /x/Repo/.env
    try:
        base_st = base.stat()
    except OSError:
        return False
    for p in (cand, *cand.parents):
        try:
            if os.path.samestat(p.stat(), base_st):
                return True
        except OSError:
            continue
    return False


def trusted_config(config: str, boundary: str | Path | None, *,
                    explicit: bool, quiet: bool = False) -> str:
    """Refuse a ``--config`` that resolves at/under *boundary* — the untrusted scan target (the ``--repo`` path..."""
    # Explicit -> refuse (exit 2); auto-detected -> warn+fallback; quiet=True -> manifest capture
    if boundary is None or os.environ.get("VVAHARNESS_ALLOW_CWD_CONFIG"):
        return config
    if not _path_within(config, boundary):
        return config
    if explicit:
        raise ConfigPolicyError(
            f"--config {config} resolves inside the scan target ({boundary}) "
            f"— attacker-influenced; refusing. Point --config outside the "
            f"target, or set VVAHARNESS_ALLOW_CWD_CONFIG=1 to override.")
    if not quiet:
        log.warning(Event.CONFIG_INSIDE_TARGET, path=config,
                    override="VVAHARNESS_ALLOW_CWD_CONFIG=1")
    return str(_packaged_default())


def _resolve_against(base: Path, p: str) -> str:
    # Refuse UNC before any is_file()/read: on Windows that leaks NTLM over SMB; raw AND joined path
    if is_network_path(p):
        raise ValueError(
            f"refusing network/UNC input path {p!r} "
            f"(reading it could leak credentials over SMB)")
    pp = Path(p)
    resolved = pp if pp.is_absolute() else (base / pp)
    if is_network_path(resolved):
        raise ValueError(
            f"refusing network/UNC input path {str(resolved)!r} "
            f"(reading it could leak credentials over SMB)")
    return str(resolved)


# The single definition: doctor (util.environment) imports it; its old copy had drifted
_MODEL_ROLES = ("graph_annotate", "callgraph_creation", "autoexclude",
                "preprocess", "threatmodel", "decompose", "deepdive", "verify",
                "dedup", "chain", "remediate", "validate", "exploit_verification")

# Legacy S0 roles, probed only under step0.callgraph_detection: llm; a rules-mode cred check breaks
_CALLGRAPH_ROLES = frozenset({"graph_annotate", "callgraph_creation"})


def _callgraph_llm_selected(cfg) -> bool:
    """True when ``step0.callgraph_detection`` selects the LLM annotator."""
    # Anything but exactly ``llm`` makes the annotator model dead config: do not preflight it
    step0 = getattr(cfg, "step0", None)
    mode = str(getattr(step0, "callgraph_detection", "rules")
               or "rules").strip().lower()
    return mode == "llm"


#: Roles whose config is a MAP of sub-roles; ``validate``: orchestrator only, EV: every sub-role
_SUB_ROLES: dict[str, tuple[str, ...]] = {
    "validate": ("orchestrator",),
    "exploit_verification": _EV_MODULES,
}

#: Derived from the map above so the two cannot drift. Callers that must exclude EV filter on these.
EV_MODEL_ROLES: tuple[str, ...] = tuple(
    f"exploit_verification.{s}" for s in _SUB_ROLES["exploit_verification"])

def _iter_model_roles(cfg):
    """Yield ``(role, model_cfg_node)`` for every configured, ACTIVE model role."""
    for r in _MODEL_ROLES:
        if r in _CALLGRAPH_ROLES and not _callgraph_llm_selected(cfg):
            continue
        m = getattr(cfg.models, r, None)
        if m is None:
            continue
        subs = _SUB_ROLES.get(r)
        if subs is None:
            yield r, m
            continue
        for sub in subs:
            node = getattr(m, sub, None)
            # Absent sub-roles are optional by design; demanding a credential would fail the scan
            if node is None:
                continue
            # `validate` reports under its own name: `llm.POST_SCAN_ROLES` matches no sub-role name
            yield (r if len(subs) == 1 else f"{r}.{sub}"), node


#: Step roles with a configured effort tier; mirrors manifest._ROLE_EFFORT_STEP.
ROLE_EFFORT_KEY: dict[str, tuple[str, str]] = {
    "autoexclude": ("step1", "auto_exclude_effort"),
    "threatmodel": ("step2", "effort"),
    "deepdive": ("step4", "effort"),
    "verify": ("step6_verify", "effort"),
    "dedup": ("step7_dedup", "effort"),
    "chain": ("step8", "effort"),
    "validate": ("step_validate", "effort"),
}


def role_effort(cfg: object, role: str) -> str | None:
    """The effort tier driving *role*'s calls, or None when *role* has none."""
    # EV sub-roles are dotted ("exploit_verification.<sub>"); their tier lives under its own key
    if role.startswith("exploit_verification."):
        from vvaharness.exploit_verification.settings import ev_effort
        return ev_effort(cfg, role.split(".", 1)[1])
    from vvaharness.util.config import knob
    if role == "preprocess":
        # Shares autoexclude's model, and its effort, only when models.autoexclude is unset
        # (s1_autoexclude.py:562); decompose and remediate have no effort key at all.
        if getattr(getattr(cfg, "models", None), "autoexclude", None) is not None:
            return None
        return knob(cfg, "step1.auto_exclude_effort", None) or None
    knob_path = ROLE_EFFORT_KEY.get(role)
    if knob_path is None:
        return None
    return knob(cfg, ".".join(knob_path), None) or None


def highest_effort(tiers) -> str | None:
    """The highest tier in *tiers*, ordered by EFFORT_TIME_FACTOR's REQUEST order; None/unknown ignored."""
    # Lazy: config_paths loads at import time (util/environment.py:40); backends.llm drags in
    # the whole backends.harness package, which this module must not pull in at import time.
    from vvaharness.backends.llm.models import EFFORT_TIME_FACTOR, ClockKind
    order = list(EFFORT_TIME_FACTOR[ClockKind.REQUEST])
    best_rank = -1
    best: str | None = None
    for tier in tiers:
        if tier is None:
            continue
        try:
            rank = order.index(tier)
        except ValueError:
            continue
        if rank > best_rank:
            best_rank = rank
            best = str(tier)
    return best
