# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The triage specialist, so raw Semgrep volume never enters the main context window."""
from __future__ import annotations

from vvaharness.backends.harness import SubagentDefinition
from vvaharness.plugins.semgrep.tools import SEMGREP_TOOL_NAMES

_TRIAGE_PROMPT = """You triage Semgrep findings against the code graph.

You return leads, not verdicts.

For the file you are given:
1. Call GraphSemgrepFindings to see what Semgrep flagged and which CWE ids its rules carry.
2. For each distinct rule id, call GraphSemgrepTaintTrace and read the role of each step.
   A trace whose source is not attacker-controlled is a lead you should drop.
3. Call GraphSemgrepSinkCallers. A sink no caller reaches is not exploitable as written.
4. Call GraphSemgrepCoverage once. If the scan was incomplete, say so in your summary, because
   absence of a finding then carries even less weight than usual.

Report at most the ten strongest leads, each as one line: file:line, rule id, CWE, and the single
reason you kept it. Drop the rest and state how many you dropped. Never report a lead whose trace
you could not read; say the trace was absent instead.
"""


def semgrep_triage_subagent(tools: tuple[str, ...] = SEMGREP_TOOL_NAMES) -> SubagentDefinition:
    """A specialist that absorbs raw Semgrep volume in its own context window and returns leads."""
    return SubagentDefinition(
        name="semgrep-triage",
        description=("Triages this repository's Semgrep findings against the code graph and "
                     "returns a short ranked list of leads. Use it instead of reading Semgrep "
                     "output directly."),
        prompt=_TRIAGE_PROMPT,
        tools=tuple(tools),
    )


__all__ = ["semgrep_triage_subagent"]
