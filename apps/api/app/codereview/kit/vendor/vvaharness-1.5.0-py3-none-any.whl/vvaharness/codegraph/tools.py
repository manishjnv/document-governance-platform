# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Read-only graph-query tools over ``ctx.graph_handle``; S2, S4 and S6 each build these."""
from __future__ import annotations

import functools
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass

from context_graph_sdk import SymbolAmbiguousError, SymbolSelector
from langchain_core.tools import BaseTool, tool

from vvaharness.backends.harness import StreamingOptions
from vvaharness.backends.harness.deepagents.tools import (
    build_tools as build_reader_tools,
)
from vvaharness.codegraph.handle import GraphHandle
from vvaharness.models import ContextPackage
from vvaharness.util.counters import COUNTERS

_CONTEXT_LIMITS = {"candidate_limit": 5, "group_limit": 8, "call_depth": 2,
                   "max_nodes": 60, "max_edges": 120, "max_paths": 8}
_IMPACT_LIMITS = {"candidate_limit": 5, "max_depth": 4,
                  "max_nodes": 80, "max_edges": 160, "max_paths": 10}
_REF_CAP = 20
_PATH_CAP = 6

_NEIGHBORS_QUERY = """
MATCH (fn {name: $function, filePath: $file})-[:CALLS]->(callee)
RETURN DISTINCT callee.filePath AS file, callee.name AS name
LIMIT 25
"""
_CALLERS_QUERY = """
MATCH (caller)-[:CALLS]->(fn {name: $function, filePath: $file})
RETURN DISTINCT caller.filePath AS file, caller.name AS name
LIMIT 25
"""
_IMPORTERS_QUERY = """
MATCH (importer:File)-[:IMPORTS]->(target:File {filePath: $file})
RETURN DISTINCT importer.filePath AS path
LIMIT 25
"""


def _qname(row: dict) -> str:
    """A cypher row rendered as ``file::name``, or empty when either half is missing."""
    file, name = row.get("file"), row.get("name")
    return f"{file}::{name}" if isinstance(file, str) and isinstance(name, str) else ""


def _ref(entity: object) -> str:
    """An entity rendered as ``file::name``, or its name alone when it carries no path."""
    name = getattr(entity, "name", None) or getattr(entity, "qualified_name", None) or ""
    path = getattr(entity, "file_path", None) or getattr(entity, "path", None) or ""
    return f"{path}::{name}" if path and name else str(name or path)


def _refs(entities: Iterable[object] | None) -> list[str]:
    """Up to ``_REF_CAP`` rendered entity references, dropping empties."""
    return [r for e in (entities or ()) if (r := _ref(e))][:_REF_CAP]


def _paths(paths: Iterable[object] | None) -> list[str]:
    """Up to ``_PATH_CAP`` call paths, each an arrow-joined reference chain."""
    return [" -> ".join(_refs(getattr(p, "nodes", ()) or getattr(p, "entities", ())))
            for p in (paths or ())][:_PATH_CAP]


def _selector(file: str, symbol: str | None, line: int | None = None) -> SymbolSelector:
    """A ``SymbolSelector`` for *symbol* scoped to *file*, optionally pinned to *line*."""
    return SymbolSelector(symbol or file, file_path=file, line=line)


def _resolve_error(file: str, symbol: str, exc: Exception) -> dict:
    """A usable answer when the graph cannot resolve *symbol*, instead of a raised tool error."""
    if isinstance(exc, SymbolAmbiguousError):
        hint = (f"several symbols named '{symbol}' exist in {file}. Pass `line` to pick the "
                "one you mean, or name the enclosing class or function so the name is unique.")
    else:
        hint = (f"the graph holds no symbol '{symbol}' in {file}. It indexes functions, methods "
                "and classes — not module-level statements, templates or config. Pass the "
                "enclosing function's exact name, or fall back to Grep for this location.")
    return {"error": f"{type(exc).__name__}: {exc}", "hint": hint}


def _cypher_error(exc: Exception) -> dict:
    """A usable answer when a direct graph query fails, instead of a raised tool error."""
    return {"error": f"{type(exc).__name__}: {exc}"}


def _is_empty_result(result: object) -> bool:
    """``None``, an empty list, or a dict whose list-valued entries are all empty."""
    if isinstance(result, dict):
        return all(not v for v in result.values() if isinstance(v, list))
    return result is None or (isinstance(result, list) and not result)


def _count_result(result: object) -> None:
    """Bumps exactly one ``graph_tool_result_{error,empty,hit}`` counter for *result*."""
    if isinstance(result, dict) and "error" in result:
        COUNTERS.bump("graph_tool_result_error")
    elif _is_empty_result(result):
        COUNTERS.bump("graph_tool_result_empty")
    else:
        COUNTERS.bump("graph_tool_result_hit")


def _counted(fn: Callable[..., object]) -> Callable[..., object]:
    """Counts a graph tool's return value via :func:`_count_result`; place under ``@tool``."""
    @functools.wraps(fn)
    def _wrapper(*args: object, **kwargs: object) -> object:
        result = fn(*args, **kwargs)
        _count_result(result)
        return result
    return _wrapper


def _community_files(ctx: ContextPackage) -> dict[str, list[str]]:
    """``ctx.modules`` re-keyed by module name."""
    return {m.name: m.files for m in (getattr(ctx, "modules", None) or ())}


@dataclass(frozen=True)
class GraphToolContext:
    """Everything a graph-tool factory may read; grows by field, not by signature change."""

    handle: GraphHandle
    ctx: ContextPackage


def _context_tool(gtx: GraphToolContext) -> BaseTool:
    """Builds ``GraphContext``, the one-call neighbourhood query."""

    @tool
    @_counted
    def GraphContext(file: str, symbol: str, line: int | None = None) -> dict:  # noqa: N802
        """Callers, callees, imports, implementors and call paths of *symbol* in *file*, in one call. Prefer this over GraphNeighbors. `file` is the exact repo-relative path; `symbol` is the bare defined name, not `Class.method`, a route, or a template; `line` disambiguates a name defined more than once in the file."""  # noqa: E501
        from context_graph_sdk import ContextLimits
        try:
            res = gtx.handle.graph.context(
                _selector(file, symbol, line), limits=ContextLimits(**_CONTEXT_LIMITS))
        except Exception as exc:
            return _resolve_error(file, symbol, exc)
        return {
            "symbol": _ref(res.symbol),
            "callers": _refs(res.callers),
            "callees": _refs(res.callees),
            "imports": _refs(res.imports),
            "implementors": _refs(res.implementors),
            "call_paths": _paths(res.call_paths),
        }

    return GraphContext


def _impact_tool(gtx: GraphToolContext) -> BaseTool:
    """Builds ``GraphImpact``, the transitive-reachability query."""

    @tool
    @_counted
    def GraphImpact(file: str, symbol: str, direction: str = "upstream",  # noqa: N802
                     line: int | None = None) -> dict:
        """Transitive reachability of *symbol*: direction "upstream" = everything that can reach it (an empty result means nothing calls it, so it is an entry point or dead code), "downstream" = everything it reaches. `file` is the exact repo-relative path; `symbol` is the bare defined name, not `Class.method`, a route, or a template; `line` disambiguates a name defined more than once in the file."""  # noqa: E501
        from context_graph_sdk import ImpactDirection, ImpactLimits
        want = (ImpactDirection.DOWNSTREAM if str(direction).lower().startswith("down")
                else ImpactDirection.UPSTREAM)
        try:
            res = gtx.handle.graph.impact(
                _selector(file, symbol, line), want, limits=ImpactLimits(**_IMPACT_LIMITS))
        except Exception as exc:
            return _resolve_error(file, symbol, exc)
        affected = _refs(res.affected)
        return {
            "symbol": _ref(res.symbol),
            "direction": want.value,
            "affected": affected,
            "reachable": bool(affected),
            "note": ("nothing in the graph reaches this symbol — it is an entry point, "
                     "dispatched by a framework, or unreachable"
                     if not affected and want is ImpactDirection.UPSTREAM else ""),
            "paths": _paths(res.paths),
        }

    return GraphImpact


def _neighbors_tool(gtx: GraphToolContext) -> BaseTool:
    """Builds ``GraphNeighbors`` as two single-MATCH queries; an OPTIONAL MATCH composite cartesian-products into QueryTimeoutError."""  # noqa: E501

    @tool
    @_counted
    def GraphNeighbors(file: str, function: str) -> dict:  # noqa: N802
        """Direct callers and callees of *function* defined in *file*. `file` is the exact repo-relative path; `function` is the bare defined name, not `Class.method`."""  # noqa: E501
        params = {"file": file, "function": function}
        try:
            callees = [_qname(r.to_dict()) for r in gtx.handle.graph.cypher(
                _NEIGHBORS_QUERY, params).rows]
        except Exception as exc:
            return _cypher_error(exc)
        try:
            callers = [_qname(r.to_dict()) for r in gtx.handle.graph.cypher(
                _CALLERS_QUERY, params).rows]
        except Exception as exc:
            # Callees already succeeded — keep them alongside the error, not instead of it
            return {"callees": [q for q in callees if q], **_cypher_error(exc)}
        return {
            "callees": [q for q in callees if q],
            "callers": [q for q in callers if q],
        }

    return GraphNeighbors


def _community_of_tool(gtx: GraphToolContext) -> BaseTool:
    """Builds ``GraphCommunityOf``, a pure scan of ``ctx.modules`` that touches no graph."""

    @tool
    @_counted
    def GraphCommunityOf(file: str) -> str | None:  # noqa: N802
        """Which module/community *file* belongs to, or None if unmapped. `file` is the exact repo-relative path."""  # noqa: E501
        for name, files in _community_files(gtx.ctx).items():
            if file in files:
                return name
        return None

    return GraphCommunityOf


def _importers_tool(gtx: GraphToolContext) -> BaseTool:
    """Builds ``GraphImporters``, the file-level inbound-import query."""

    @tool
    @_counted
    def GraphImporters(file: str) -> list[str] | dict:  # noqa: N802
        """Files that import *file* — a trust-boundary signal, not a function-reachability check. `file` is the exact repo-relative path."""  # noqa: E501
        try:
            rows = gtx.handle.graph.cypher(_IMPORTERS_QUERY, {"file": file}).rows
        except Exception as exc:
            return _cypher_error(exc)
        return [p for r in rows if isinstance(p := r.to_dict().get("path"), str)]

    return GraphImporters


def _sinks_in_community_tool(gtx: GraphToolContext) -> BaseTool:
    """Builds ``GraphSinksInCommunity``, joining ``ctx.unsafe_sinks`` onto a module's file set."""

    @tool
    @_counted
    def GraphSinksInCommunity(community: str) -> list[dict]:  # noqa: N802
        """Unsafe sinks whose file belongs to *community*."""
        files = set(_community_files(gtx.ctx).get(community, ()))
        return [
            {"file": s.file, "line": s.line, "function": s.function}
            for s in (getattr(gtx.ctx, "unsafe_sinks", None) or ())
            if s.file in files
        ]

    return GraphSinksInCommunity


ToolFactory = Callable[[GraphToolContext], BaseTool]

#: Keyed by the model-facing tool name; insertion order fixes the order tools are built in.
GRAPH_TOOLS: dict[str, ToolFactory] = {
    "GraphContext": _context_tool,
    "GraphImpact": _impact_tool,
    "GraphNeighbors": _neighbors_tool,
    "GraphCommunityOf": _community_of_tool,
    "GraphImporters": _importers_tool,
    "GraphSinksInCommunity": _sinks_in_community_tool,
}

#: The built-ins only. Stages must call :func:`graph_tool_names`, which also sees plugin tools.
GRAPH_TOOL_NAMES: tuple[str, ...] = tuple(GRAPH_TOOLS)

_PLUGIN_TOOLS: dict[str, ToolFactory] = {}


def register_graph_tools(tools: Mapping[str, ToolFactory]) -> None:
    """Adds plugin graph tools; call before any stage opens a session, since names are read then."""
    for name, build in tools.items():
        if name in GRAPH_TOOLS or name in _PLUGIN_TOOLS:
            raise ValueError(f"graph tool already registered: {name}")
        _PLUGIN_TOOLS[name] = build


def clear_plugin_graph_tools() -> None:
    """Drops every registered plugin tool, leaving the built-ins; for tests and repeated scans."""
    _PLUGIN_TOOLS.clear()


def graph_tool_names() -> tuple[str, ...]:
    """Built-in names then plugin names; a call, not a constant, so registration is not too late."""
    return GRAPH_TOOL_NAMES + tuple(_PLUGIN_TOOLS)


def _graph_tools(ctx: ContextPackage, allowed: set[str]) -> list[BaseTool]:
    """The graph tools named in *allowed*; empty when ``ctx`` carries no graph handle."""
    handle = getattr(ctx, "graph_handle", None)
    if handle is None:
        return []
    gtx = GraphToolContext(handle=handle, ctx=ctx)
    registered = {**GRAPH_TOOLS, **_PLUGIN_TOOLS}
    return [build(gtx) for name, build in registered.items() if name in allowed]


def build_graph_tool_builder(ctx: ContextPackage) -> Callable[..., list[BaseTool]]:
    """A ``ToolBuilder`` returning the generic reader tools followed by the graph tools."""

    def _build(options: StreamingOptions, *,
               allowed_tools: Sequence[str] | None) -> list[BaseTool]:
        """Gates on ``options.fact_tools``; streaming.py's parent_tools strips fact names out of allowed_tools, so gating on that alone builds nothing."""  # noqa: E501
        reader_tools = build_reader_tools(options, allowed_tools=allowed_tools)
        return reader_tools + _graph_tools(ctx, set(options.fact_tools))

    return _build


__all__ = ["GRAPH_TOOLS", "GRAPH_TOOL_NAMES", "GraphToolContext", "ToolFactory",
           "build_graph_tool_builder", "clear_plugin_graph_tools", "graph_tool_names",
           "register_graph_tools"]
