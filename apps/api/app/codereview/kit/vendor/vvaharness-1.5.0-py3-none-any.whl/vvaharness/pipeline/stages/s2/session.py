# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 2's dispatch: the agentic threat-model call, its graph gate and its hollow retry."""
from __future__ import annotations
from vvaharness.util import logs

import time
from pathlib import Path

# Module import keeps the monkeypatch seam for tests.
from langchain.agents.middleware import TodoListMiddleware

from vvaharness.backends.harness.deepagents.evidence_gate import EvidenceGate
from vvaharness.backends.harness.deepagents.model_call_budget import ModelCallBudget
from vvaharness.backends.harness.deepagents.tool_budget import ToolCallBudget
from vvaharness.backends.harness.models import CallTimeoutError, is_halt_error
from vvaharness.backends.llm import deepagents as _deepagents
from vvaharness.backends.llm.models import RESPONSE_MODEL_VIAS, validate_detection_tools
from vvaharness.backends.llm.registry import resolve
from vvaharness.codegraph.build import graph_is_degenerate
from vvaharness.codegraph.tools import (
    GRAPH_TOOL_NAMES,
    build_graph_tool_builder,
    graph_tool_names,
)
from vvaharness.evidence import ThreatEvidence, _cap_int
from vvaharness.models import ContextPackage, ThreatModel
from vvaharness.pipeline.stages.replay import (
    S2_REPLAY_INSTRUCTION,
    RecordTranscript,
    Transcript,
    deadline_bound,
    release_pinned_session,
    replay_prompt,
    resume_or_replay,
    run_with_deadline,
    session_id_for,
)
from vvaharness.pipeline.stages.s2.outcomes import _finalize_threats, _parse_threat_model
from vvaharness.pipeline.stages.s2.prompts import (
    _AGENTIC_SYSTEM_LINE,
    _GRAPH_TOOLS_SYSTEM_LINE,
    _SHELL_SYSTEM_LINE,
    SYSTEM,
)
from vvaharness.pipeline.stages.s2_planning import (
    PLAN_SYSTEM_PROMPT as S2_PLAN_SYSTEM_PROMPT,
)
from vvaharness.pipeline.stages.s2_planning import (
    PLAN_TOOL_DESCRIPTION as S2_PLAN_TOOL_DESCRIPTION,
)
from vvaharness.skills import inject_skills
from vvaharness.util import console
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.exceptions import S2HollowAfterRetry
from vvaharness.util.warn_once import warn_once
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

_DISPATCH_TAG = "s2 threatmodel"

_GRAPH_NAME = "s2-threatmodel"

#: The replay restates a transcript; it needs the smallest reasoning budget, not the stage's.
_REPLAY_EFFORT = "low"
_WARNED_NO_GRAPH_TOOLS: set[str] = set()

#: Routes already warned that require_graph stood down for a degenerate graph.
_WARNED_DEGENERATE_GRAPH: set[str] = set()

#: Appended to the retry prompt: the fresh call has no memory of the hollow one, and no tools.
_HOLLOW_RETRY_DIRECTIVES = {
    "no_threats": (
        "A previous attempt returned a threat model with zero threats. This call has no tools: "
        "model the system from the snapshot above, naming surface_files only from FILE INVENTORY."),
    "no_validated_surface": (
        "A previous attempt returned threats, but not one named a surface_files path that exists "
        "in the FILE INVENTORY, so every threat was unusable and no later stage could act on any "
        "of them. This call has no tools: model the system from the snapshot above, and give each "
        "threat at least one surface_files path copied EXACTLY from FILE INVENTORY."),
}


def _call_budget(s2) -> ModelCallBudget | None:
    """s2's in-session cut: on the last permitted call every tool but ThreatModel is withdrawn."""
    # This is the cut-and-report that step2.deadline approximated from OUTSIDE the session. The
    # budget does it from INSIDE: same conversation, same message objects, prompt cache intact,
    # no second API call. A wall clock cannot do that -- it can only kill and re-ask.
    limit = _cap_int(s2, "max_model_calls", 0)
    if limit <= 0:
        return None
    return ModelCallBudget(limit=limit,
                           outcome_tools=frozenset({ThreatModel.__name__}),
                           counter="s2_model_call_budget_final_turn")


def _graph_tool_route_ok(cfg: object, *, agentic: bool = True) -> bool:
    """Whether the resolved threatmodel route can actually run the graph tools, warning once if not."""
    via = resolve(cfg.models.threatmodel).via
    ok, reason = _deepagents.route_carries_tools(cfg, via)
    if ok:
        return True
    warn_once(
        _WARNED_NO_GRAPH_TOOLS, f"{via}:{agentic}",
        f"WARN [s2]: step2.graph_tools is on and a code graph exists, but "
        f"{reason} — running S2 without the graph tools, and NOT telling the "
        f"model about tools it cannot call. To use them: route models.threatmodel "
        f"via: deepagents.")
    return False


def _threatmodel_call(user: str, cfg: object, repo_root: str,
                       ctx: ContextPackage | None = None,
                       *, drop_thinking: bool = False,
                       require_tool_call: bool = False) -> str:
    """Issues the primary agentic threat-model completion, with graph tools when the route can carry them."""
    s2 = getattr(cfg, "step2", None)
    via = resolve(cfg.models.threatmodel).via
    tool_builder = None
    fact_tools: tuple[str, ...] = ()
    graph_tools_line = ""
    parent_middleware: tuple[ToolCallBudget, ...] = ()
    gate_installed = False
    if (ctx is not None and getattr(ctx, "graph_handle", None) is not None
            and getattr(s2, "graph_tools", True)
            and _graph_tool_route_ok(cfg, agentic=True)):
        tool_builder = build_graph_tool_builder(ctx)
        fact_tools = graph_tool_names()
        # Tools stay registered on a degenerate graph; the prompt stops selling them as reliable
        degenerate = graph_is_degenerate(ctx, cfg)
        graph_tools_line = "" if degenerate else _GRAPH_TOOLS_SYSTEM_LINE
        parent_middleware = (ToolCallBudget(
            frozenset(graph_tool_names()),
            limit=_cap_int(s2, "graph_tool_budget", 6),
            counter="s2_graph_tool_budget_exhausted",
        ),)
        if getattr(s2, "planning", True):
            parent_middleware += (TodoListMiddleware(
                system_prompt=S2_PLAN_SYSTEM_PROMPT,
                tool_description=S2_PLAN_TOOL_DESCRIPTION,
            ),)
        if getattr(s2, "require_graph", True):
            # Standing down drops only the tool half: EvidenceGate._premature still checks the todos
            required_tools = frozenset(GRAPH_TOOL_NAMES)
            if degenerate:
                warn_once(
                    _WARNED_DEGENERATE_GRAPH, "s2-require-graph",
                    "WARN [s2]: step2.require_graph is on but the code graph is "
                    "absent or degenerate (zero edges, or fewer nodes than "
                    "step0.min_graph_nodes_for_gate) — standing the graph-tool "
                    "requirement down; the todo-list gate still applies.")
                COUNTERS.bump("evidence_gate_stood_down_degenerate_graph")
                required_tools = frozenset()
            parent_middleware += (EvidenceGate(
                max_rejections=_cap_int(s2, "require_graph_rejections", 2),
                counter="s2_evidence_gate_rejected",
                required_tools=required_tools,
                require_tool_call=require_tool_call,
                ignored_tools=frozenset({"write_todos", ThreatModel.__name__}),
            ),)
            gate_installed = True
    if not gate_installed and require_tool_call and via == "deepagents":
        parent_middleware += (EvidenceGate(
            max_rejections=_cap_int(s2, "require_graph_rejections", 2),
            counter="s2_evidence_gate_rejected",
            required_tools=frozenset(),
            require_tool_call=True,
            ignored_tools=frozenset({"write_todos", ThreatModel.__name__}),
        ),)
    max_turns = _cap_int(s2, "max_turns", 12)
    # RESPONSE_MODEL_VIAS, not a local set: s2/s4/s6 must agree on the same route or a scan splits
    threat_model_arg = (
        ThreatModel if via in RESPONSE_MODEL_VIAS
        else None
    )
    system_prompt = (SYSTEM + _AGENTIC_SYSTEM_LINE + graph_tools_line
                     + (_SHELL_SYSTEM_LINE if getattr(s2, "bash", False) else ""))
    session_id = session_id_for("s2", "threatmodel")
    transcript = Transcript()
    parent_middleware += (RecordTranscript(transcript),)
    budget = _call_budget(s2)
    if budget is not None:
        parent_middleware += (budget,)
    deadline = _cap_int(s2, "deadline", 0)
    effort = None if drop_thinking else (getattr(s2, "effort", None) or None)
    try:
        return run_with_deadline(
            lambda: _agentic_leg(user, cfg, repo_root, system_prompt, parent_middleware,
                                 tool_builder, fact_tools, max_turns, threat_model_arg,
                                 session_id=session_id, drop_thinking=drop_thinking),
            seconds=deadline, stage=_DISPATCH_TAG, effort=effort)
    except CallTimeoutError:
        console.write(f"  [s2] deadline {deadline}s hit — resuming the session (or re-asking "
                      f"from the transcript) for the threat model")
        return resume_or_replay(
            session_id,
            lambda: _replay_leg(user, cfg, repo_root, system_prompt, transcript),
            model=cfg.models.threatmodel, cfg=cfg, instruction=S2_REPLAY_INSTRUCTION,
            stage="s2", tag=_DISPATCH_TAG,
            timeout=_cap_int(s2, "resume_timeout", 300))
    finally:
        release_pinned_session(session_id)


def _replay_leg(user: str, cfg: object, repo_root: str, system_prompt: str,
                transcript: Transcript) -> str:
    """Re-asks for the threat model with no tools, from the transcript the killed session reached."""
    # LOWEST effort: the reasoning already happened in the killed session and is IN the transcript,
    # so a high budget pays for it twice -- effort=high cost ~110s of a 237s s2 when measured.
    s2 = getattr(cfg, "step2", None)
    COUNTERS.bump("s2_deadline_replay")
    started = time.monotonic()
    out = _deepagents.dispatch_prompt(
        replay_prompt(transcript, user, instruction=S2_REPLAY_INSTRUCTION,
                      stage="s2"),
        model=cfg.models.threatmodel,
        cfg=cfg,
        cwd=repo_root,
        system_prompt=system_prompt,
        max_tokens=_cap_int(s2, "replay_max_tokens", 16000),
        timeout=_cap_int(s2, "replay_timeout", 300),
        response_model=(ThreatModel
                        if resolve(cfg.models.threatmodel).via in RESPONSE_MODEL_VIAS else None),
        tag=f"{_DISPATCH_TAG} replay",
        graph_name=_GRAPH_NAME,
        effort=_REPLAY_EFFORT,
    )
    console.write(f"  [s2] replay returned in {time.monotonic() - started:.1f}s")
    return out


def _agentic_leg(user: str, cfg: object, repo_root: str, system_prompt: str,
                 parent_middleware: tuple, tool_builder: object, fact_tools: tuple[str, ...],
                 max_turns: int, threat_model_arg: object, *, session_id: str,
                 drop_thinking: bool) -> str:
    """The unbounded agentic threat-model call that the stage deadline wraps."""
    s2 = getattr(cfg, "step2", None)
    return _deepagents.dispatch_agentic(
        user,
        model=cfg.models.threatmodel,
        cfg=cfg,
        system_prompt=system_prompt,
        # via:cli honours it verbatim; else read-only, so graph names go via fact_tools/tool_builder
        allowed_tools=validate_detection_tools(
            getattr(s2, "allowed_tools", None),
            config_key="step2.allowed_tools",
            via=resolve(cfg.models.threatmodel).via),
        cwd=repo_root,
        max_turns=max_turns,
        # step2.timeout binds via:cli and via:deepagents; sdk/openai rely on max_turns alone
        timeout=deadline_bound(_cap_int(s2, "timeout", 1800), _cap_int(s2, "deadline", 0),
                               None if drop_thinking else (getattr(s2, "effort", None) or None),
                               via=resolve(cfg.models.threatmodel).via),
        # knob() not getattr: a null overlay must give 64000, not None -> internal 16000
        max_output_tokens=int(knob(cfg, "step2.max_tokens", 64000)),
        tag=_DISPATCH_TAG,
        graph_name=_GRAPH_NAME,
        tool_builder=tool_builder,
        fact_tools=fact_tools,
        response_model=threat_model_arg,
        parent_middleware=parent_middleware,
        effort=None if drop_thinking else (getattr(s2, "effort", None) or None),
        skill_root=inject_skills(Path(repo_root)) if getattr(s2, "skills", True) else None,
        allow_shell=bool(getattr(s2, "bash", False)),
        session_id=session_id,
    )


def _snapshot_leg(user: str, cfg: object, repo_root: str) -> str:
    """Re-asks for the threat model from the structural snapshot alone, with no tools.

    The hollow reply came from a session that had the schema AND the graph tools on every
    turn, and chose the schema exit without reading anything (a forced tool call cannot
    withdraw an exit the model keeps taking). This leg has no tool policy to withdraw from: it
    is the one-shot seam s2 already owns for its deadline replay and its json-repair retry, so
    the only exit left is the schema, filled from the same FILE INVENTORY/MODULES/ENTRY POINTS
    snapshot the primary call already read.
    """
    s2 = getattr(cfg, "step2", None)
    via = resolve(cfg.models.threatmodel).via
    return _deepagents.dispatch_prompt(
        user,
        model=cfg.models.threatmodel,
        cfg=cfg,
        cwd=repo_root,
        system_prompt=SYSTEM,
        max_tokens=int(knob(cfg, "step2.max_tokens", 64000)),
        timeout=_cap_int(s2, "timeout", 1800),
        response_model=(ThreatModel if via in RESPONSE_MODEL_VIAS else None),
        tag=f"{_DISPATCH_TAG} snapshot",
        graph_name=_GRAPH_NAME,
        effort=getattr(s2, "effort", None) or None,
    )


def _hollow_reason(tm: ThreatModel, resolved: bool) -> str:
    """Why s3 would mint nothing from *tm*, or "" when at least one threat is actionable."""
    if not tm.threats:
        return "no_threats"
    if resolved and not any(t.surface_files for t in tm.threats):
        return "no_validated_surface"
    return ""


def _retry_if_hollow(tm: ThreatModel, ev: ThreatEvidence,
                     user: str, cfg, repo_root: str,
                     ctx: ContextPackage | None) -> ThreatModel:
    """Re-asks once, with no tools, when a non-empty repo yielded nothing s3 could mint a unit for."""
    s2 = getattr(cfg, "step2", None)
    if not getattr(s2, "empty_retry", True):
        return tm
    reason = _hollow_reason(tm, ctx is not None)
    if not reason:
        return tm
    # Zero threats on a zero-file repo is honest: a retry carries the same empty inventory
    if not ev.file_count:
        return tm
    COUNTERS.bump("s2_empty_retry_attempted")
    COUNTERS.bump(f"s2_hollow_{reason}")
    log.warning(Event.S2_HOLLOW_RETRY_ATTEMPTED, reason=reason, threats=len(tm.threats))
    try:
        retry_tm = _parse_threat_model(_snapshot_leg(
            user + "\n\n" + _HOLLOW_RETRY_DIRECTIVES[reason], cfg, repo_root))
    except Exception as e:
        if is_halt_error(e):
            raise
        # Keep the first model; run() logs the loss once, so no errlog (one hollow != 2 failures)
        log.warning(Event.S2_HOLLOW_RETRY_FAILED, detail=str(e))
        return tm
    _finalize_threats(retry_tm, ctx)
    retry_reason = _hollow_reason(retry_tm, ctx is not None)
    if not retry_reason:
        COUNTERS.bump("s2_empty_retry_recovered")
        log.warning(Event.S2_RETRY_RECOVERED, threats=len(retry_tm.threats))
        return retry_tm
    COUNTERS.bump("s2_hollow_after_retry")
    log.error(Event.S2_HOLLOW_RETRY_EMPTY, reason=retry_reason,
              remedy="check the s2 transcript: the model returned no threat naming a file from "
                     "the inventory, twice. Re-run, or route models.threatmodel elsewhere")
    raise S2HollowAfterRetry(retry_reason)
