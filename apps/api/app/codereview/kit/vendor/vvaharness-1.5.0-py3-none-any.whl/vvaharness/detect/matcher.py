# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Regex matching of a MatchSpec corpus against raw source text."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from vvaharness.detect.spec import MatchSpec

_SNIPPET_MAX = 120


@dataclass(frozen=True)
class Hit:
    """One pattern match at one line of one file."""

    file: str
    line: int
    spec: MatchSpec
    snippet: str
    # Last line of a multi-line detector span; 0 = single-line hit.
    line_end: int = 0


def _compiled(specs: list[MatchSpec]) -> list[tuple[MatchSpec, re.Pattern[str]]]:
    return [(spec, re.compile(spec.pattern)) for spec in specs]


def split_lines(text: str) -> list[str]:
    """*text* as lines the way ``ast``, git and every editor count them."""
    # NOT str.splitlines(): it breaks on \f and U+2028, which no line numbering agrees with
    out = text.split("\n")
    if out and out[-1] == "":
        out.pop()
    return [ln.removesuffix("\r") for ln in out]


def _read_text(repo_root: Path, rel_path: str) -> str | None:
    full = repo_root / rel_path
    try:
        return full.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None


def scan_file(
    repo_root: Path,
    rel_path: str,
    compiled: list[tuple[MatchSpec, re.Pattern[str]]],
) -> list[Hit]:
    """Match every pattern against every line of one file."""
    text = _read_text(repo_root, rel_path)
    if text is None:
        return []
    hits: list[Hit] = []
    for line_no, line in enumerate(split_lines(text), start=1):
        for spec, rx in compiled:
            if rx.search(line):
                hits.append(Hit(rel_path, line_no, spec, line.strip()[:_SNIPPET_MAX]))
    return hits


def scan_files(repo_root: Path, rel_paths: list[str], specs: list[MatchSpec]) -> list[Hit]:
    """Match the given corpus against every listed file."""
    compiled = _compiled(specs)
    hits: list[Hit] = []
    for rel_path in rel_paths:
        hits.extend(scan_file(repo_root, rel_path, compiled))
    return hits


# Detector-rule matching: same anchors as the seeding corpus, but spans read past one line


@dataclass(frozen=True)
class CompiledDetector:
    """One detector spec with every regex it declares pre-compiled."""

    spec: MatchSpec
    pattern: re.Pattern[str]
    present: re.Pattern[str] | None
    absent: re.Pattern[str] | None
    file_gate: re.Pattern[str] | None
    near: re.Pattern[str] | None
    span_end: re.Pattern[str] | None


def compile_detectors(specs: list[MatchSpec]) -> list[CompiledDetector]:
    """Compile every ENABLED detector-role spec; other roles and disabled rules drop."""
    def _rx(pat: str) -> re.Pattern[str] | None:
        return re.compile(pat) if pat else None

    return [
        CompiledDetector(
            spec=s, pattern=re.compile(s.pattern),
            present=_rx(s.present_re), absent=_rx(s.absent_re),
            file_gate=_rx(s.file_re), near=_rx(s.near_re),
            span_end=_rx(s.span_end),
        )
        for s in specs
        if s.role == "detector" and s.enabled
    ]


# Triple-quoted forms MUST come first: longest alternation wins, or `"""` reads as empty
_STRING_LITERAL_RX = re.compile(
    r'"""(?:\\.|[^\\])*?"""'
    r"|'''(?:\\.|[^\\])*?'''"
    r"|\"\"\"|'''"
    r"|\"(?:\\.|[^\"\\])*\"?"
    r"|'(?:\\.|[^'\\])*'?"
)
# Up to the closer of a triple-quote opened earlier; no match = still inside the literal
_TRIPLE_CLOSE = {
    '"""': re.compile(r'(?:\\.|[^\\])*?"""'),
    "'''": re.compile(r"(?:\\.|[^\\])*?'''"),
}


def _mask_strings(seg: str, in_triple: str = "") -> tuple[str, str]:
    """*seg* with every string literal blanked, character for character."""
    # A paren in a literal breaks span="call" both ways; single-quote masking is per-line BY DESIGN
    out: list[str] = []
    pos = 0
    if in_triple:
        m = _TRIPLE_CLOSE[in_triple].match(seg)
        if m is None:  # the whole line is still string text
            return " " * len(seg), in_triple
        out.append(" " * m.end())
        pos = m.end()
        in_triple = ""
    while True:
        m = _STRING_LITERAL_RX.search(seg, pos)
        if m is None:
            out.append(seg[pos:])
            break
        out.append(seg[pos:m.start()])
        tok = m.group(0)
        if tok in ('"""', "'''"):  # unterminated opener: string text to EOL
            out.append(" " * (len(seg) - m.start()))
            in_triple = tok
            break
        out.append(" " * len(tok))
        pos = m.end()
    return "".join(out), in_triple


def _call_span(lines: list[str], idx: int, col: int, max_lines: int
               ) -> tuple[str, int] | None:
    """Balanced-paren call text from (idx, col), or None when it never balances."""
    # Text after the balancing paren is trimmed, so a sibling call cannot satisfy a gate
    depth = 0
    parts: list[str] = []
    in_triple = ""
    for i in range(idx, min(idx + max_lines, len(lines))):
        seg = lines[i][col:] if i == idx else lines[i]
        masked, in_triple = _mask_strings(seg, in_triple)
        for j, ch in enumerate(masked):
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    parts.append(seg[:j + 1])
                    return "\n".join(parts), i + 1
        parts.append(seg)
    return None


def _block_span(lines: list[str], idx: int, col: int, end_rx: re.Pattern[str],
                max_lines: int) -> tuple[str, int] | None:
    """Text from (idx, col) through the first line matching *end_rx*, capped."""
    parts: list[str] = []
    for i in range(idx, min(idx + max_lines, len(lines))):
        seg = lines[i][col:] if i == idx else lines[i]
        parts.append(seg)
        if end_rx.search(seg):
            return "\n".join(parts), i + 1
    return None


def _span_for(det: CompiledDetector, lines: list[str], idx: int, col: int
              ) -> tuple[str, int] | None:
    """The gate text for a hit at (idx, col), or None when the span never closes."""
    spec = det.spec
    if spec.span == "call":
        return _call_span(lines, idx, col, max(1, spec.span_max_lines))
    if spec.span == "block" and det.span_end is not None:
        return _block_span(lines, idx, col, det.span_end, max(1, spec.span_max_lines))
    return lines[idx], idx + 1


def _guard_text(det: CompiledDetector, lines: list[str], idx: int,
                body: str, end_line: int) -> str:
    """The text the absent_re guard reads: the span, widened by absent_window lines."""
    # Only the NEGATIVE gate widens: present_re keeps the narrow span or a neighbour fires
    window = det.spec.absent_window
    if window <= 0:
        return body
    lo = max(0, idx - window)
    hi = min(len(lines), end_line + window)
    return "\n".join(lines[lo:hi])


def _near_ok(det: CompiledDetector, lines: list[str], idx: int) -> bool:
    """The proximity gate: near_re within near_window lines of the anchor."""
    if det.near is None:
        return True
    lo = max(0, idx - det.spec.near_window)
    hi = min(len(lines), idx + det.spec.near_window + 1)
    return bool(det.near.search("\n".join(lines[lo:hi])))


#: Same-anchor rule pairs (the two cookie rules) share one walked span instead of repeating
_SpanKey = tuple[str, str, int, int, int]


def _live_detectors(lines: list[str],
                    detectors: list[CompiledDetector]) -> list[CompiledDetector]:
    """The detectors whose whole-file gate admits this file, or all of them when none has one."""
    if not any(d.file_gate is not None for d in detectors):
        return detectors
    text = "\n".join(lines)
    return [d for d in detectors
            if d.file_gate is None or d.file_gate.search(text)]


@dataclass
class _FileScan:
    """One file's detector pass: owns the per-file span memo the anchors share."""

    rel_path: str
    lines: list[str]
    spans: dict[_SpanKey, tuple[str, int] | None] = field(default_factory=dict)

    def _span(self, det: CompiledDetector, idx: int,
              start: int) -> tuple[str, int] | None:
        """The anchor's span body and end line, memoised, or None when it never closed."""
        key = (det.spec.span, det.spec.span_end, det.spec.span_max_lines, idx, start)
        if key not in self.spans:
            self.spans[key] = _span_for(det, self.lines, idx, start)
        return self.spans[key]

    def _rejected(self, det: CompiledDetector, idx: int, body: str,
                  end_line: int) -> bool:
        """True when any of the detector's content or proximity guards rejects the anchor."""
        return ((det.present is not None and not det.present.search(body))
                or (det.absent is not None and bool(det.absent.search(
                    _guard_text(det, self.lines, idx, body, end_line))))
                or not _near_ok(det, self.lines, idx))

    def hit(self, det: CompiledDetector, idx: int, line: str,
            start: int) -> Hit | None:
        """One detector's hit at one anchor, or None when a guard rejects it."""
        span = self._span(det, idx, start)
        if span is None:
            return None  # never balanced/closed within the cap: do not guess
        body, end_line = span
        if self._rejected(det, idx, body, end_line):
            return None
        return Hit(self.rel_path, idx + 1, det.spec,
                   line.strip()[:_SNIPPET_MAX], end_line)

    def line_hits(self, live: list[CompiledDetector], idx: int,
                  line: str) -> list[Hit]:
        """Every detector's hit on one line — one per rule, since each searches once."""
        found = ((det, det.pattern.search(line)) for det in live)
        return [hit for det, m in found if m is not None
                if (hit := self.hit(det, idx, line, m.start())) is not None]


def detector_hits(rel_path: str, lines: list[str],
                  detectors: list[CompiledDetector]) -> list[Hit]:
    """Every compiled detector's hits in one file, at most one per (rule, line)."""
    live = _live_detectors(lines, detectors) if detectors else []
    if not live:
        return []
    # Python only: '#' opens a CSS selector or an anchor href in template text.
    skip_comments = rel_path.endswith(".py")
    scan = _FileScan(rel_path, lines)
    hits: list[Hit] = []
    for idx, line in enumerate(lines):
        if skip_comments and line.lstrip().startswith("#"):
            continue
        hits.extend(scan.line_hits(live, idx, line))
    return hits
