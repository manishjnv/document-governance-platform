# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Repo-kind classifier and its STRIDE/baseline lookup tables for s2."""
from __future__ import annotations

import re

from vvaharness.evidence import ThreatEvidence
from vvaharness.lang.detect import LANG_DISPLAY, is_iac_file, is_web_template
from vvaharness.models import ContextPackage

# A hint for the model, not a constraint.
STRIDE_BY_KIND = {
    "network":"S T R I D E",         
    "framework":       "S T R I D E",  # a framework-routed handler is a
                                        # specialisation of "network", not a lesser "other" boundary
    "ipc":             "T I E",
    "file":            "T I D",
    "cli":             "T E",
    "deserialization": "T E",
    "other":           "T I",
}

WEB_FW_RX = re.compile(
    r"\b(spring|express|fastify|koa|hapi|nest|next|nuxt|django|flask|fastapi|"
    r"tornado|rails|sinatra|laravel|symfony|gin-gonic|echo|fiber|actix|axum|"
    r"asp\.net|ktor|micronaut|quarkus|vertx|play-framework)\b", re.IGNORECASE)

NATIVE_LANGS = {"c", "cpp", "c++", "c-cpp", "c/c++", "rust", "objective-c", "objc"}

# Match BOTH spellings: ThreatEvidence.languages holds LANG_DISPLAY, not EXT_TO_LANG keys
_WEB_TEMPLATE_LANG_LABELS = {"web-template", LANG_DISPLAY["web-template"].lower()}

# The stable id BL-<kind>-<suffix> makes a model's disposition machine-checkable, not fuzzy
BASELINES: dict[str, tuple[tuple[str, str], ...]] = {
    "web-api": (
        ("BL-WEB-A01", "OWASP A01 Broken Access Control (IDOR, path traversal, forced browsing, privilege escalation)"),
        ("BL-WEB-A02", "OWASP A02 Cryptographic Failures (weak/missing crypto, plaintext secrets/transport)"),
        ("BL-WEB-A03", "OWASP A03 Injection (SQL/NoSQL/OS/LDAP/template/header)"),
        ("BL-WEB-A04", "OWASP A04 Insecure Design (missing rate-limit, trust-boundary assumptions)"),
        ("BL-WEB-A05", "OWASP A05 Security Misconfiguration (default creds, debug on, permissive CORS)"),
        ("BL-WEB-A07", "OWASP A07 Identification & Authentication Failures (weak session, missing MFA, JWT flaws)"),
        ("BL-WEB-A08", "OWASP A08 Software & Data Integrity Failures (unsafe deserialization, unsigned updates)"),
        ("BL-WEB-A10", "OWASP A10 Server-Side Request Forgery"),
        ("BL-WEB-XSS", "XSS (reflected / stored / DOM)"),
        ("BL-WEB-CSRF", "CSRF / state-changing GET"),
    ),
    "mobile": (
        ("BL-MOB-M1", "OWASP M1 Improper Credential Usage (hardcoded keys, token leakage)"),
        ("BL-MOB-M3", "OWASP M3 Insecure Authentication/Authorization"),
        ("BL-MOB-M5", "OWASP M5 Insecure Communication (no cert pinning, cleartext traffic)"),
        ("BL-MOB-M8", "OWASP M8 Security Misconfiguration (exported components, debuggable build)"),
        ("BL-MOB-M9", "OWASP M9 Insecure Data Storage (world-readable prefs, unencrypted DB)"),
    ),
    "native": (
        ("BL-NAT-119", "CWE-119/787 Buffer overflow (stack/heap write OOB)"),
        ("BL-NAT-416", "CWE-416 Use-after-free / double-free"),
        ("BL-NAT-190", "CWE-190 Integer overflow leading to undersized allocation"),
        ("BL-NAT-134", "CWE-134 Format-string"),
        ("BL-NAT-362", "CWE-362 TOCTOU / race condition"),
        ("BL-NAT-78", "CWE-78 OS command injection via system()/exec()"),
    ),
    "iac": (
        ("BL-IAC-IAM", "Over-permissive IAM / RBAC (wildcard actions, cluster-admin bindings)"),
        ("BL-IAC-NET", "Public network exposure (0.0.0.0/0 ingress, hostNetwork, public S3/bucket)"),
        ("BL-IAC-SECRETS", "Secrets committed in plaintext / env"),
        ("BL-IAC-PRIV", "Privileged or root containers, missing securityContext"),
        ("BL-IAC-TLS", "Disabled TLS / unencrypted storage classes"),
    ),
    "library": (
        ("BL-LIB-INJ", "Injection via untrusted caller input (SQL/OS/path)"),
        ("BL-LIB-DESER", "Unsafe deserialization (pickle/yaml.load/XMLDecoder/ObjectInputStream)"),
        ("BL-LIB-PATH", "Path traversal in file-handling APIs"),
        ("BL-LIB-REDOS", "ReDoS / algorithmic-complexity DoS"),
    ),
    "web-template": (
        ("BL-TPL-XSS", "XSS via unescaped/raw template output (e.g. Jinja `|safe`, Handlebars `{{{ }}}`, ERB `<%= raw %>`)"),
        ("BL-TPL-SSTI", "Server-side template injection (untrusted input reaching the template source/name)"),
        ("BL-TPL-CSRF", "CSRF-vulnerable forms (state-changing `<form>` with no anti-CSRF token)"),
        ("BL-TPL-SECRET", "Secrets or internal config leaked into rendered markup (hardcoded keys, comments, debug data)"),
    ),
}


def repo_kind(ev: ThreatEvidence, ctx: ContextPackage | None) -> set[str]:
    kinds: set[str] = set()
    all_files = [f.lower() for f in (ctx.all_files if ctx else [])]
    manifest_text = "\n".join(body for _, body in ev.manifests)

    langs = {(ev.primary_language or "").lower(),
             *(lang.lower() for lang, _ in ev.languages)}
    non_template_langs = langs - ({""} | _WEB_TEMPLATE_LANG_LABELS)

    has_entrypoint_or_artefact_signal = (
        any(k in ("network", "framework") for k, *_ in ev.entry_points)
        or bool(ev.api_artefacts))
    manifest_web_fw_match = bool(WEB_FW_RX.search(manifest_text))
    # An all-template tree is scaffolding even if a manifest names a framework; bool(all_files)
    template_dominated = (bool(all_files) and not non_template_langs
                          and any(is_web_template(f) for f in all_files))

    if has_entrypoint_or_artefact_signal or (manifest_web_fw_match and not template_dominated):
        kinds.add("web-api")
    elif template_dominated:
        kinds.add("web-template")

    if (any(f.endswith(("androidmanifest.xml", "info.plist", "podfile"))
            for f in all_files)
            or re.search(r"\bcom\.android\b", manifest_text)):
        kinds.add("mobile")

    if any(is_iac_file(f) for f in all_files):
        kinds.add("iac")

    if langs & NATIVE_LANGS:
        kinds.add("native")

    return kinds or {"library"}


__all__ = [
    "BASELINES",
    "NATIVE_LANGS",
    "STRIDE_BY_KIND",
    "WEB_FW_RX",
    "repo_kind",
]
