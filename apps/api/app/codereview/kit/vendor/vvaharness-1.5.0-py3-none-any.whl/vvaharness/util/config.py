# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""One fail-safe reader for a dotted config knob, shared by every stage."""
from __future__ import annotations


def knob(cfg, path: str, default):
    """``cfg.step8.chain_dedup``-style lookup by dotted *path*, else *default*."""
    # Silent-failure by design: no config, missing key and explicit null ALL read as *default*
    node = cfg
    for part in path.split("."):
        node = getattr(node, part, None)
        if node is None:
            return default
    return node
