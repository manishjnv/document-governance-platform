# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Harness profiles for the OpenAI-compatible models deepagents ships none for."""

from __future__ import annotations

import threading

from deepagents.profiles import HarnessProfile, register_harness_profile

__all__ = [
    "PER_MODEL_PROFILE_KEYS",
    "PROFILED_PROVIDERS",
    "STAGE_PROFILE_KEYS",
    "register_vvah_harness_profiles",
    "stage_profile_suffix",
]

# ruff: noqa: E501

_READ_BEFORE_ANSWERING = """\
<investigate_before_answering>
Never describe code you have not opened. Reading one file and generalising from it is the single most common way this task is failed: the answer is graded on what is actually in the repo, not on what a repo of this kind usually contains. Before you commit to any answer, open every file your answer depends on. If you have named a path, you must have read it. If a tool returned nothing, that is a fact about your query, not a fact about the repo — re-query differently rather than concluding the thing is absent.
</investigate_before_answering>"""

_PARALLEL_TOOL_CALLS = """\
<use_parallel_tool_calls>
Decide every file and lookup you need, then issue those calls together in one batch rather than one at a time. Reading five files is five calls in parallel, not five sequential turns. Only serialise a call whose arguments genuinely depend on a previous result. Never guess a parameter or use a placeholder to avoid a lookup.
</use_parallel_tool_calls>"""

_REFLECT_IN_WRITING = """\
<tool_result_reflection>
After each batch of tool results, state to yourself what you now know that you did not before, and what is still unverified. Let that decide the next batch. Do not proceed to the final answer while a load-bearing claim is still unverified.
</tool_result_reflection>"""

_REFLECT_WITHOUT_WRITING = """\
<tool_result_reflection>
After each batch of tool results, settle what you now know that you did not before, and what is still unverified, and let that decide the next batch — but do not write that stocktake out. It is a decision, not a deliverable, and on this route everything you write is generated text that the answer has to be reached through. Do not proceed to the final answer while a load-bearing claim is still unverified.
</tool_result_reflection>"""

_ENUMERATE_DO_NOT_SUMMARISE = """\
<enumerate_do_not_summarise>
When the output schema asks for a list, the list is the deliverable and its length is part of the answer. One broad item that folds several distinct cases together is a worse answer than several narrow items, and anything you fold in is lost — nothing downstream can recover it. Exhaust the cases you have evidence for before you stop. Do not stop at the first few because they feel representative, and do not merge two cases because they happen to share a file.
</enumerate_do_not_summarise>"""

_BEAT_THE_CLOCK = """\
<the_clock_is_part_of_the_task>
You are on a wall clock and it is shorter than this work takes if you narrate it. A session that runs out of time is not trimmed at the end — it is cut off and restarted from its own transcript, so every second spent on text you did not have to produce is paid twice and the second pass starts from nothing. Three habits cost the whole budget and buy no coverage: writing your reasoning out rather than reasoning and moving on, restating a tool result you have already been shown, and spending a turn per file where one batch would have answered the question. Cite what you read as `path:line` and go on.

None of this is licence to answer with less. The number of items you emit is set by the evidence and is never reduced to make the clock; a short answer that omits half the repo is the expensive outcome, not the cheap one. Shorten the path to the answer, never the answer.
</the_clock_is_part_of_the_task>"""

_DO_NOT_NARRATE = """\
<do_not_narrate>
Everything you write before the final answer is taken out of the room the answer itself has to fit in, and a reply cut off mid-structure is discarded whole rather than truncated. So do not restate, quote or paraphrase code you have read — cite it as `path:line` and move on. Do not narrate your plan or your progress. Do not summarise your own tool results back to yourself in writing. This shortens the sentences and never the list: the number of items is set by the evidence and is never reduced to save room.
</do_not_narrate>"""

_INVESTIGATION_FLOOR = "\n\n".join(
    (
        _READ_BEFORE_ANSWERING,
        _PARALLEL_TOOL_CALLS,
        _REFLECT_IN_WRITING,
        _ENUMERATE_DO_NOT_SUMMARISE,
    )
)

PROFILED_PROVIDERS: tuple[str, ...] = ("openai",)

_PER_MODEL_SUFFIX: dict[str, str] = {}

PER_MODEL_PROFILE_KEYS: tuple[str, ...] = tuple(_PER_MODEL_SUFFIX)

_STAGE_SUFFIX: dict[str, dict[str, str]] = {}

STAGE_PROFILE_KEYS: tuple[str, ...] = tuple(_STAGE_SUFFIX)

_REGISTERED = False
_LOCK = threading.Lock()


def stage_profile_suffix(stage: str | None, registry_key: str) -> str | None:
    """The suffix overriding `registry_key`'s for this stage, or None to leave it in place."""
    by_model = _STAGE_SUFFIX.get(stage or "")
    return by_model.get(registry_key) if by_model else None


def _stage_keyed_models() -> frozenset[str]:
    """Every `provider:model` key any stage overrides, so the swap has a registration to replace."""
    return frozenset(key for by_model in _STAGE_SUFFIX.values() for key in by_model)


def register_vvah_harness_profiles() -> None:
    """Register the investigation floor per provider and per stage-keyed model, then the overrides."""
    global _REGISTERED
    with _LOCK:
        if _REGISTERED:
            return
        profile = HarnessProfile(system_prompt_suffix=_INVESTIGATION_FLOOR)
        for key in PROFILED_PROVIDERS:
            register_harness_profile(key, profile)
        for key in sorted(_stage_keyed_models() - set(_PER_MODEL_SUFFIX)):
            register_harness_profile(key, profile)
        for key, suffix in _PER_MODEL_SUFFIX.items():
            register_harness_profile(key, HarnessProfile(system_prompt_suffix=suffix))
        _REGISTERED = True
