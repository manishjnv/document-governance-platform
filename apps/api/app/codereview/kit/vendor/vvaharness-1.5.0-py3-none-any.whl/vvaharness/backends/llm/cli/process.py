# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Running the `claude` subprocess, buffered and streaming."""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import threading
import time

from vvaharness.backends.llm.cli import cancel as _cancel
from vvaharness.backends.llm.cli import env as _env
from vvaharness.backends.llm.models import (
    TIMEOUT_STOP_GRACE_SECONDS,
)
from vvaharness.report.redact import redact
from vvaharness.util import console, logs

log = logs.get_logger(__name__)


def _run(cmd: list[str], *, input: str | None = None,
         cwd: str | None = None, timeout: int = 600,
         env: dict | None = None,
         heartbeat_label: str | None = None,
         heartbeat_interval: int = 300,
         stream_cb=None,
         should_stop=None) -> subprocess.CompletedProcess:
    """Central subprocess runner with optional periodic progress heartbeat."""
    proc_env = {**os.environ, **_env._tls_extra, **(env or {})}

    if stream_cb is not None or should_stop is not None:
        # `should_stop` needs the line reader, so arming the watchdog alone still streams
        return _run_streaming(cmd, input=input, cwd=cwd, timeout=timeout,
                              proc_env=proc_env,
                              stream_cb=stream_cb or (lambda _line: None),
                              should_stop=should_stop)

    start = time.monotonic()
    deadline = start + timeout
    pending_input = input

    with subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE if input is not None else None,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        cwd=cwd,
        env=proc_env,
        **_cancel._NEW_GROUP_KW,
    ) as proc:
        with _cancel._LIVE_LOCK:
            _cancel._LIVE.add(proc)
        try:
            while True:
                if _cancel._ABORT.is_set():
                    _cancel._kill_tree(proc)
                    out, err = proc.communicate()
                    raise RuntimeError("aborted by user (Ctrl-C)")
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    _cancel._stop_tree(proc, TIMEOUT_STOP_GRACE_SECONDS)
                    out, err = proc.communicate()
                    raise subprocess.TimeoutExpired(cmd, timeout, output=out, stderr=err)

                try:
                    out, err = proc.communicate(
                        input=pending_input,
                        timeout=min(float(heartbeat_interval), remaining),
                    )
                    break
                except subprocess.TimeoutExpired:
                    if heartbeat_label:
                        elapsed = int(time.monotonic() - start)
                        console.write(
                            f"    [cli] {heartbeat_label} still running... {elapsed}s elapsed")
                    pending_input = None
        except KeyboardInterrupt:
            _cancel._ABORT.set()
            _cancel._kill_tree(proc)
            try:
                proc.communicate(timeout=2)
            except Exception:
                pass
            raise
        finally:
            with _cancel._LIVE_LOCK:
                _cancel._LIVE.discard(proc)

        return subprocess.CompletedProcess(proc.args, proc.returncode, out, err)


def _run_streaming(cmd: list[str], *, input: str | None, cwd: str | None,
                   timeout: int, proc_env: dict,
                   stream_cb,
                   should_stop=None) -> subprocess.CompletedProcess:
    """Run the CLI, forwarding each stdout line to *stream_cb* live, still capturing full output."""
    # Drain BOTH pipes in threads or the 64KB stderr buffer deadlocks; should_stop kills per line
    chunks: list[str] = []
    err_chunks: list[str] = []
    stopped = threading.Event()

    def _reader(pipe):
        for line in iter(pipe.readline, ""):
            chunks.append(line)
            try:
                stream_cb(line)
            except Exception:
                pass
            if should_stop is not None and not stopped.is_set():
                try:
                    if should_stop(line):
                        stopped.set()
                        _cancel._kill_tree(proc)
                except Exception:
                    pass
        try:
            pipe.close()
        except Exception:
            pass

    def _err_reader(pipe):
        """Drain stderr continuously so a full pipe buffer can never block the child."""
        try:
            for line in iter(pipe.readline, ""):
                err_chunks.append(line)
        except Exception:
            pass
        try:
            pipe.close()
        except Exception:
            pass

    with subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE if input is not None else None,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        cwd=cwd,
        env=proc_env,
        bufsize=1,  # line-buffered
        **_cancel._NEW_GROUP_KW,
    ) as proc:
        with _cancel._LIVE_LOCK:
            _cancel._LIVE.add(proc)
        reader = threading.Thread(target=_reader, args=(proc.stdout,), daemon=True)
        err_thread = threading.Thread(target=_err_reader, args=(proc.stderr,),
                                      daemon=True)
        reader.start()
        err_thread.start()
        try:
            if input is not None:
                try:
                    proc.stdin.write(input)
                    proc.stdin.close()
                except BrokenPipeError:
                    pass
            try:
                proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                _cancel._stop_tree(proc, TIMEOUT_STOP_GRACE_SECONDS)
                reader.join(timeout=2)
                err_thread.join(timeout=2)
                raise subprocess.TimeoutExpired(
                    cmd, timeout, output="".join(chunks),
                    stderr="".join(err_chunks))
        except KeyboardInterrupt:
            _cancel._ABORT.set()
            _cancel._kill_tree(proc)
            raise
        finally:
            with _cancel._LIVE_LOCK:
                _cancel._LIVE.discard(proc)
        reader.join(timeout=5)
        err_thread.join(timeout=5)
    result = subprocess.CompletedProcess(cmd, proc.returncode, "".join(chunks),
                                         "".join(err_chunks))
    if stopped.is_set():
        # Mark before any returncode check: the kill is non-zero and reads as a CLI failure
        _WATCHDOG_STOPPED.add(id(result))
    return result


#: An id set, not a field: CompletedProcess is not ours to subclass; _was_stopped consumes it
_WATCHDOG_STOPPED: set[int] = set()


def _was_stopped(result: subprocess.CompletedProcess) -> bool:
    """Whether the turn watchdog killed *result*'s process, consuming the mark."""
    key = id(result)
    if key in _WATCHDOG_STOPPED:
        _WATCHDOG_STOPPED.discard(key)
        return True
    return False


# C0 (incl. ESC, CR, LF, BEL), DEL and C1 (incl. 8-bit CSI \x9b): any can drive or forge the terminal
_TERMINAL_CONTROL_RX = re.compile("[\x00-\x1f\x7f-\x9f]")


def _trace_print(text: str, out) -> None:
    print(_TERMINAL_CONTROL_RX.sub(" ", text), file=out, flush=True)


def stream_trace(line: str, *, out=None) -> None:
    """Render one `stream-json` event as a concise `--verbose` trace (tool calls, text, result)."""
    out = out or sys.stderr
    line = (line or "").strip()
    if not line:
        return
    try:
        evt = json.loads(line)
    except (json.JSONDecodeError, TypeError):
        return
    etype = evt.get("type")
    if etype == "assistant":
        for blk in (evt.get("message", {}) or {}).get("content", []) or []:
            if not isinstance(blk, dict):
                continue
            if blk.get("type") == "text" and blk.get("text", "").strip():
                _trace_print(f"    [agent] 💬 {redact(blk['text'].strip())[:400]}", out)
            elif blk.get("type") == "tool_use":
                name = blk.get("name", "?")
                args = blk.get("input", {}) or {}
                summ = ", ".join(f"{k}={v!r}" for k, v in args.items())
                summ = redact(summ)
                if len(summ) > 160:
                    summ = summ[:157] + "..."
                _trace_print(f"    [agent] 🔧 {name}({summ})", out)
    elif etype == "user":
        # tool_result coming back to the model — show a short confirmation.
        for blk in (evt.get("message", {}) or {}).get("content", []) or []:
            if isinstance(blk, dict) and blk.get("type") == "tool_result":
                content = blk.get("content")
                if isinstance(content, list):
                    content = " ".join(
                        c.get("text", "") for c in content
                        if isinstance(c, dict))
                n = len(str(content or ""))
                _trace_print(f"    [agent] ↩ tool result ({n} chars)", out)
    elif etype == "result":
        if evt.get("is_error"):
            _trace_print(
                f"    [agent] ✗ {redact(str(evt.get('result') or evt.get('error') or ''))[:200]}",
                out)
