# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Process-wide stage counters, read once by util.metrics.build()."""
# Batch mode must reset between repos, like TOKENS.reset() -- else repo N+1 inherits N's tallies.
from __future__ import annotations

import threading


class _Counters:
    """Ints you add to, strings you overwrite. Nothing else."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._ints: dict[str, int] = {}
        self._notes: dict[str, str] = {}
        # Never cleared by reset(): carries the whole batch invocation's totals.
        self._retired_ints: dict[str, int] = {}
        self._retired_notes: dict[str, str] = {}

    # snapshot() merges both maps, so one name as count AND note ships a string; RETIRED too
    def bump(self, name: str, n: int = 1) -> None:
        with self._lock:
            if name in self._notes or name in self._retired_notes:
                raise ValueError(
                    f"counter {name!r} is already recorded as a note; a name "
                    f"must be either a count or a note, never both"
                )
            self._ints[name] = self._ints.get(name, 0) + n

    def note(self, name: str, value: str) -> None:
        """Last writer wins -- for one-of-N facts like s3_output_shape."""
        with self._lock:
            if name in self._ints or name in self._retired_ints:
                raise ValueError(
                    f"counter {name!r} is already recorded as a count; a name "
                    f"must be either a count or a note, never both"
                )
            self._notes[name] = value

    def get(self, name: str, default: int = 0) -> int:
        with self._lock:
            return self._ints.get(name, default)

    def snapshot(self) -> dict:
        with self._lock:
            return {**self._ints, **self._notes}

    def snapshot_cumulative(self) -> dict:
        """Every count since process start, across reset() calls."""
        with self._lock:
            merged = dict(self._retired_ints)
            for k, v in self._ints.items():
                merged[k] = merged.get(k, 0) + v
            return {**merged, **self._retired_notes, **self._notes}

    def reset(self) -> None:
        """Clear the current tallies, retiring them into the cumulative totals."""
        with self._lock:
            for k, v in self._ints.items():
                self._retired_ints[k] = self._retired_ints.get(k, 0) + v
            self._retired_notes.update(self._notes)
            self._ints.clear()
            self._notes.clear()

    def reset_all(self) -> None:
        """Forget everything, cumulative history included."""
        # Tests must use this, not `reset()`, which keeps history across calls by design.
        with self._lock:
            self._ints.clear()
            self._notes.clear()
            self._retired_ints.clear()
            self._retired_notes.clear()


COUNTERS = _Counters()
