# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""CWE id → canonical MITRE name; unknown ids resolve to "" so callers fall back to the bare id."""
from __future__ import annotations

# Names verbatim from MITRE; NEVER add a View or Category id — containers are not assignable
CWE_NAMES: dict[str, str] = {
    "CWE-20":   "Improper Input Validation",
    "CWE-22":   "Improper Limitation of a Pathname to a Restricted Directory (Path Traversal)",
    "CWE-23":   "Relative Path Traversal",
    "CWE-36":   "Absolute Path Traversal",
    "CWE-73":   "External Control of File Name or Path",
    "CWE-74":   "Improper Neutralization of Special Elements in Output (Injection)",
    "CWE-77":   "Improper Neutralization of Special Elements used in a Command (Command Injection)",
    "CWE-78":   "Improper Neutralization of Special Elements used in an OS Command (OS Command Injection)",
    "CWE-79":   "Improper Neutralization of Input During Web Page Generation (Cross-site Scripting)",
    "CWE-80":   "Improper Neutralization of Script-Related HTML Tags in a Web Page (Basic XSS)",
    "CWE-88":   "Improper Neutralization of Argument Delimiters in a Command (Argument Injection)",
    "CWE-89":   "Improper Neutralization of Special Elements used in an SQL Command (SQL Injection)",
    "CWE-90":   "Improper Neutralization of Special Elements used in an LDAP Query (LDAP Injection)",
    "CWE-94":   "Improper Control of Generation of Code (Code Injection)",
    "CWE-95":   "Improper Neutralization of Directives in Dynamically Evaluated Code (Eval Injection)",
    "CWE-113":  "Improper Neutralization of CRLF Sequences in HTTP Headers (HTTP Request/Response Splitting)",
    "CWE-117":  "Improper Output Neutralization for Logs",
    "CWE-119":  "Improper Restriction of Operations within the Bounds of a Memory Buffer",
    "CWE-120":  "Buffer Copy without Checking Size of Input (Classic Buffer Overflow)",
    "CWE-121":  "Stack-based Buffer Overflow",
    "CWE-122":  "Heap-based Buffer Overflow",
    "CWE-125":  "Out-of-bounds Read",
    "CWE-134":  "Use of Externally-Controlled Format String",
    "CWE-190":  "Integer Overflow or Wraparound",
    "CWE-200":  "Exposure of Sensitive Information to an Unauthorized Actor",
    "CWE-201":  "Insertion of Sensitive Information Into Sent Data",
    "CWE-204":  "Observable Response Discrepancy",
    "CWE-209":  "Generation of Error Message Containing Sensitive Information",
    "CWE-215":  "Insertion of Sensitive Information Into Debugging Code",
    "CWE-256":  "Plaintext Storage of a Password",
    "CWE-259":  "Use of Hard-coded Password",
    "CWE-269":  "Improper Privilege Management",
    "CWE-276":  "Incorrect Default Permissions",
    "CWE-284":  "Improper Access Control",
    "CWE-285":  "Improper Authorization",
    "CWE-287":  "Improper Authentication",
    "CWE-294":  "Authentication Bypass by Capture-replay",
    "CWE-295":  "Improper Certificate Validation",
    "CWE-306":  "Missing Authentication for Critical Function",
    "CWE-307":  "Improper Restriction of Excessive Authentication Attempts",
    "CWE-311":  "Missing Encryption of Sensitive Data",
    "CWE-312":  "Cleartext Storage of Sensitive Information",
    "CWE-319":  "Cleartext Transmission of Sensitive Information",
    "CWE-321":  "Use of Hard-coded Cryptographic Key",
    "CWE-326":  "Inadequate Encryption Strength",
    "CWE-327":  "Use of a Broken or Risky Cryptographic Algorithm",
    "CWE-328":  "Use of Weak Hash",
    "CWE-330":  "Use of Insufficiently Random Values",
    "CWE-338":  "Use of Cryptographically Weak Pseudo-Random Number Generator (PRNG)",
    "CWE-345":  "Insufficient Verification of Data Authenticity",
    "CWE-346":  "Origin Validation Error",
    "CWE-347":  "Improper Verification of Cryptographic Signature",
    "CWE-352":  "Cross-Site Request Forgery (CSRF)",
    "CWE-359":  "Exposure of Private Personal Information to an Unauthorized Actor",
    "CWE-362":  "Concurrent Execution using Shared Resource with Improper Synchronization (Race Condition)",
    "CWE-367":  "Time-of-check Time-of-use (TOCTOU) Race Condition",
    "CWE-384":  "Session Fixation",
    "CWE-400":  "Uncontrolled Resource Consumption",
    "CWE-416":  "Use After Free",
    "CWE-426":  "Untrusted Search Path",
    "CWE-434":  "Unrestricted Upload of File with Dangerous Type",
    "CWE-436":  "Interpretation Conflict",
    "CWE-444":  "Inconsistent Interpretation of HTTP Requests (HTTP Request/Response Smuggling)",
    "CWE-476":  "NULL Pointer Dereference",
    "CWE-489":  "Active Debug Code",
    "CWE-502":  "Deserialization of Untrusted Data",
    "CWE-521":  "Weak Password Requirements",
    "CWE-522":  "Insufficiently Protected Credentials",
    "CWE-532":  "Insertion of Sensitive Information into Log File",
    "CWE-538":  "Insertion of Sensitive Information into Externally-Accessible File or Directory",
    "CWE-540":  "Inclusion of Sensitive Information in Source Code",
    "CWE-552":  "Files or Directories Accessible to External Parties",
    "CWE-564":  "SQL Injection: Hibernate",
    "CWE-598":  "Use of GET Request Method With Sensitive Query Strings",
    "CWE-601":  "URL Redirection to Untrusted Site (Open Redirect)",
    "CWE-602":  "Client-Side Enforcement of Server-Side Security",
    "CWE-611":  "Improper Restriction of XML External Entity Reference",
    "CWE-613":  "Insufficient Session Expiration",
    "CWE-614":  "Sensitive Cookie in HTTPS Session Without Secure Attribute",
    "CWE-620":  "Unverified Password Change",
    "CWE-639":  "Authorization Bypass Through User-Controlled Key",
    "CWE-640":  "Weak Password Recovery Mechanism for Forgotten Password",
    "CWE-643":  "Improper Neutralization of Data within XPath Expressions (XPath Injection)",
    "CWE-668":  "Exposure of Resource to Wrong Sphere",
    "CWE-672":  "Operation on a Resource after Expiration or Release",
    "CWE-693":  "Protection Mechanism Failure",
    "CWE-732":  "Incorrect Permission Assignment for Critical Resource",
    "CWE-759":  "Use of a One-Way Hash without a Salt",
    "CWE-770":  "Allocation of Resources Without Limits or Throttling",
    "CWE-778":  "Insufficient Logging",
    "CWE-787":  "Out-of-bounds Write",
    "CWE-798":  "Use of Hard-coded Credentials",
    "CWE-799":  "Improper Control of Interaction Frequency",
    "CWE-807":  "Reliance on Untrusted Inputs in a Security Decision",
    "CWE-829":  "Inclusion of Functionality from Untrusted Control Sphere",
    "CWE-841":  "Improper Enforcement of Behavioral Workflow",
    "CWE-843":  "Access of Resource Using Incompatible Type (Type Confusion)",
    "CWE-862":  "Missing Authorization",
    "CWE-863":  "Incorrect Authorization",
    "CWE-915":  "Improperly Controlled Modification of Dynamically-Determined Object Attributes",
    "CWE-916":  "Use of Password Hash With Insufficient Computational Effort",
    "CWE-917":  "Improper Neutralization of Special Elements used in an Expression Language Statement (Expression Language Injection)",
    "CWE-918":  "Server-Side Request Forgery (SSRF)",
    "CWE-923":  "Improper Restriction of Communication Channel to Intended Endpoints",
    "CWE-926":  "Improper Export of Android Application Components",
    "CWE-927":  "Use of Implicit Intent for Sensitive Communication",
    "CWE-942":  "Permissive Cross-domain Security Policy with Untrusted Domains",
    "CWE-943":  "Improper Neutralization of Special Elements in Data Query Logic",
    "CWE-1004": "Sensitive Cookie Without HttpOnly Flag",
    "CWE-1021": "Improper Restriction of Rendered UI Layers or Frames",
    "CWE-1104": "Use of Unmaintained Third Party Components",
    "CWE-1188": "Initialization of a Resource with an Insecure Default",
    "CWE-1236": "Improper Neutralization of Formula Elements in a CSV File",
    "CWE-1275": "Sensitive Cookie with Improper SameSite Attribute",
    "CWE-1333": "Inefficient Regular Expression Complexity",
    "CWE-1336": "Improper Neutralization of Special Elements Used in a Template Engine",
    "CWE-1390": "Weak Authentication",
    "CWE-1391": "Use of Weak Credentials",
}


def cwe_name(cwe_id: str | None) -> str:
    """Return the MITRE name for 'CWE-NNN', or '' if unknown/None."""
    if not cwe_id:
        return ""
    return CWE_NAMES.get(cwe_id.upper().strip(), "")


# VulnClass -> CWE fallback, so cwe_for resolves deterministically, not from an LLM-emitted CWE
VULNCLASS_CWE: dict[str, str] = {
    "use-after-free":         "CWE-416",
    "heap-overflow":          "CWE-122",
    "stack-overflow":         "CWE-121",
    "format-string":          "CWE-134",
    "integer-overflow":       "CWE-190",
    "type-confusion":         "CWE-843",
    "race-condition":         "CWE-362",
    "injection":              "CWE-74",     # generic injection parent
    "unsafe-deserialization": "CWE-502",
    "logic-flaw":             "CWE-841",
    "info-leak":              "CWE-200",
    "other":                  "",           # unresolved → no CWE
}


def cwe_for(cwe_id: str | None, vuln_class) -> str | None:
    """Return `cwe_id` if set, else the VulnClass fallback, else None."""
    if cwe_id:
        return cwe_id.upper().strip()
    key = getattr(vuln_class, "value", None) or str(vuln_class or "")
    fb = VULNCLASS_CWE.get(key, "")
    return fb or None


def cwe_label(cwe_id: str | None) -> str:
    """'CWE-862 - Missing Authorization' or just 'CWE-862' if name unknown."""
    if not cwe_id:
        return ""
    name = cwe_name(cwe_id)
    return f"{cwe_id} - {name}" if name else cwe_id
