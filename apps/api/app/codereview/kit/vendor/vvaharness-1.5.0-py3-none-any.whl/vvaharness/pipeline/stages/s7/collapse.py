# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""The deterministic half of step 7: collapse same-site duplicates, no model call."""
from __future__ import annotations

import re

from vvaharness.models import DupLocation, Finding, VulnClass
from vvaharness.rules.cwe import _GENERIC_PARENT_CWES, norm_cwe, weakness_key
from vvaharness.util.counters import COUNTERS

TRIVIAL_REASON = "trivial: same site, shared weakness within line tolerance"

STRICT_CWE_CLASS = {VulnClass.LOGIC}

#: Catch-all labels a specific sibling should overwrite, never the reverse.
CATCH_ALL_VULN_CLASS = frozenset({VulnClass.OTHER, VulnClass.LOGIC})

#: Below this title token overlap the pair is not TRIVIALLY one weakness; the semantic pass rules.
MIN_TITLE_OVERLAP = 0.15

_TITLE_STOPWORDS = frozenset({
    "via", "the", "and", "with", "to", "of", "on", "no", "or", "for", "is", "by",
    "without", "all", "in", "a", "an", "from", "into", "that", "this", "its",
})


def _title_tokens(title: str) -> frozenset[str]:
    """*title*'s lowercased content words, punctuation and stopwords removed."""
    words = re.findall(r"[a-z0-9]+", title.lower())
    return frozenset(w for w in words if len(w) > 2 and w not in _TITLE_STOPWORDS)


def title_overlap(a: Finding, b: Finding) -> float:
    """Jaccard overlap of two findings' title vocabularies; 1.0 when either title is empty."""
    ta, tb = _title_tokens(a.title), _title_tokens(b.title)
    if not ta or not tb:
        return 1.0
    return len(ta & tb) / len(ta | tb)


# 19 of 23 semantic collapses in the first graded e2e run merged different CWEs (CSRF onto debug)
def cwe_conflict(a: Finding, b: Finding) -> bool:
    """True when both findings carry a CWE and the two ids do not name one weakness."""
    if not (a.cwe and b.cwe):
        return False
    key_a, key_b = weakness_key(a.cwe), weakness_key(b.cwe)
    # An id that fails to parse is never evidence of a match.
    return key_a is None or key_a != key_b


def dup_location(f: Finding, reasoning: str) -> DupLocation:
    """A DupLocation snapshot of *f*'s coordinates carrying *reasoning*."""
    return DupLocation(
        file=f.file,
        line_start=f.line_start,
        line_end=f.line_end,
        vuln_class=f.vuln_class,
        title=f.title,
        chunk_id=f.chunk_id,
        source_ref=f.source_ref,
        sink_ref=f.sink_ref,
        reasoning=reasoning,
    )


def dedup_locations(locs: list) -> list:
    """Drop repeat (file, line_start, line_end) entries, keeping first order."""
    seen: set = set()
    out: list = []
    for d in locs:
        key = (d.file, d.line_start, d.line_end)
        if key not in seen:
            seen.add(key)
            out.append(d)
    return out


def _inherit_main_channel(dup: Finding, canonical: Finding) -> None:
    """Promote *canonical* to the main channel when a collapsed member is main."""
    # Canonical is just the lowest index, so a posture winner would route a real defect out
    if dup.channel == "main" and canonical.channel != "main":
        canonical.channel = "main"
        COUNTERS.bump("s7_dedup_channel_inherited_main")


def _inherit_cluster_cwe(dup: Finding, canonical: Finding) -> None:
    """Name the survivor by its cluster's first-listed id when a collapsed sibling carried it."""
    # Lowest index wins and s7's input is sorted on the raw cwe string: CWE-77 would outrank CWE-78
    key = weakness_key(canonical.cwe)
    if key and key == norm_cwe(dup.cwe) and key != norm_cwe(canonical.cwe):
        canonical.cwe = key
        COUNTERS.bump("s7_dedup_cwe_inherited")


def _inherit_vuln_class(dup: Finding, canonical: Finding) -> None:
    """Give the survivor a dup's specific class when canonical's is a catch-all."""
    # Lowest index wins, so a catch-all member sorting first would outrank a specific sibling
    if (canonical.vuln_class in CATCH_ALL_VULN_CLASS
            and dup.vuln_class not in CATCH_ALL_VULN_CLASS):
        canonical.vuln_class = dup.vuln_class


def attach_duplicates(findings: list[Finding], canonical_of: dict[int, int],
                      reasoning: dict[int, str],
                      keep_same_site: set[int] | None = None) -> None:
    """Append each collapsed finding onto its canonical root as an extra call site."""
    def root(i: int) -> int:
        seen = set()
        while i in canonical_of and i not in seen:
            seen.add(i)
            i = canonical_of[i]
        return i
    roots: set[int] = set()
    for j, parent in canonical_of.items():
        r = root(parent)
        roots.add(r)
        dj, rf = findings[j], findings[r]
        _inherit_main_channel(dj, rf)
        _inherit_cluster_cwe(dj, rf)
        _inherit_vuln_class(dj, rf)
        same_site = (dj.file == rf.file
                     and dj.line_start <= rf.line_end
                     and rf.line_start <= dj.line_end)
        if not same_site:
            rf.duplicates.append(
                dup_location(dj, reasoning.get(j, "duplicate"))
            )
        elif keep_same_site is not None:
            # keep_same_site was ruled "independent sites": each sink line is its own operation
            if j in keep_same_site and dj.line_start != rf.line_start:
                rf.duplicates.append(
                    dup_location(dj, reasoning.get(j, "duplicate"))
                )
                COUNTERS.bump("s7_dedup_same_site_kept")
            else:
                COUNTERS.bump("s7_dedup_same_site_discarded")
        if dj.duplicates:
            rf.duplicates.extend(dj.duplicates)
            dj.duplicates = []
    for r in roots:
        findings[r].duplicates = dedup_locations(findings[r].duplicates)


def collapse_trivial(findings: list[Finding], line_tol: int,
                     group_lines: list[int] | None = None,
                     min_title_overlap: float = MIN_TITLE_OVERLAP) -> dict[int, int]:
    """{dup_idx -> canonical_idx}, lower index canonical, for same file + class, or shared weakness
    across classes, within *line_tol* or overlapping."""
    n = len(findings)

    def group_line(i: int) -> int:
        if group_lines is not None and i < len(group_lines):
            return group_lines[i]
        return findings[i].line_start

    # group_lines holds pre-re-anchor anchors: re-anchoring collapsed sinks 11 lines apart
    glines = [group_line(i) for i in range(n)]
    # Shift each span onto its group line so overlap and proximity share one basis.
    spans = [(glines[i],
              findings[i].line_end + glines[i] - findings[i].line_start)
             for i in range(n)]

    canonical_of: dict[int, int] = {}
    for j in range(n):
        if j in canonical_of:
            continue
        b = findings[j]
        for i in range(j):
            if i in canonical_of:
                continue
            a = findings[i]
            if a.file != b.file:
                continue
            cross_class = a.vuln_class != b.vuln_class
            shared_weakness = False
            if a.cwe and b.cwe:
                key_a, key_b = weakness_key(a.cwe), weakness_key(b.cwe)
                shared_weakness = (key_a is not None and key_a == key_b
                                    and key_a not in _GENERIC_PARENT_CWES)
            # A class mismatch merges only across one shared, non-generic weakness.
            if cross_class and not shared_weakness:
                continue
            # LOGIC is the catch-all; a missing CWE is common pre-s6 and collapsing hides TPs
            if a.cwe and b.cwe:
                if cwe_conflict(a, b):
                    continue
            elif a.vuln_class in STRICT_CWE_CLASS:
                continue
            # An equal CWE is not proof of one weakness, because the CWE is sometimes wrong (#181).
            # Measured over 209 runs / 186 repos / 699 trivial collapses: 15% join titles sharing
            # almost no vocabulary, and those are real distinct weaknesses lost to a mislabel --
            # "Session token generated with non-cryptographic PRNG" carried CWE-1004 and so matched
            # "Session cookie missing Secure, HttpOnly", and a generic "HTML built
            # by string concatenation" absorbs every specific XSS across many repos. A declined pair
            # is KEPT, both halves: run()'s semantic pass is gated on step7_dedup.semantic, which
            # every shipped profile sets false, so nothing arbitrates afterwards. That is the trade
            # -- measured raw FP 26 -> 37 on a small web application, which the reviewer then absorbed to 6 either way.
            if title_overlap(a, b) < min_title_overlap:
                COUNTERS.bump("s7_trivial_collapse_deferred_unlike_titles")
                continue
            close = abs(glines[i] - glines[j]) <= line_tol
            overlap = spans[i][0] <= spans[j][1] and spans[j][0] <= spans[i][1]
            if close or overlap:
                if cross_class:
                    COUNTERS.bump("s7_trivial_collapse_cross_class_merged")
                canonical_of[j] = i
                break
    return canonical_of
