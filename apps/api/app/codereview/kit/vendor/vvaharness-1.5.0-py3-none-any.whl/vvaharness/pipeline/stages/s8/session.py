# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 8's one model call: the chaining pass, raising so run() can ship unranked."""
from __future__ import annotations

import re

from vvaharness.backends.harness.deepagents.model_call_budget import ModelCallBudget
from vvaharness.backends.harness.models import CallTimeoutError
from vvaharness.backends.llm import deepagents as _deepagents
from vvaharness.backends.llm.models import RESPONSE_MODEL_VIAS
from vvaharness.backends.llm.registry import resolve
from vvaharness.evidence import _cap_int
from vvaharness.models import ContextPackage, Finding
from vvaharness.pipeline.stages.replay import (
    S8_REPLAY_INSTRUCTION,
    RecordTranscript,
    Transcript,
    deadline_bound,
    release_pinned_session,
    replay_prompt,
    run_with_deadline,
    session_id_for,
)
from vvaharness.pipeline.stages.s8.outcomes import ChainReport
from vvaharness.pipeline.stages.s8.prompts import SYSTEM, build_prompt, repair_prompt
from vvaharness.util import console
from vvaharness.util.config import knob
from vvaharness.util.response_quality import dispatch_or_retry_unforced, stage_floors
from vvaharness.util.tokens import estimate_tokens

# VVAH-E003 floors under the shortest real reply (~110 chars/~28 tok); all-discarded: run()'s check
MIN_RESPONSE_CHARS = 90
MIN_RESPONSE_TOKENS = 15
TAG = "s8 chain"

#: The replay restates a transcript; it needs the smallest reasoning budget, not the stage's.
_REPLAY_EFFORT = "low"

# A schema key followed by a value opener: the reply tried to answer, it is not prose or `{}`
_REPAIRABLE_RX = re.compile(r'\b(ranked_findings|chains)"?\s*(?::|=|\bis\b)\s*[\[{]')


def _call_budget(s8) -> ModelCallBudget | None:
    """s8's in-session cut: on the last permitted call every tool but ChainReport is withdrawn."""
    # Default 1. s8 reasons over a finding table it is handed whole -- it has nothing to look up, so
    # a second turn can only re-read what is already in the prompt. The budget is what makes the
    # agentic seam safe to use here: the session is resumable, and still cannot spend a second call.
    limit = _cap_int(s8, "max_model_calls", 1)
    if limit <= 0:
        return None
    return ModelCallBudget(limit=limit,
                           outcome_tools=frozenset({ChainReport.__name__}),
                           counter="s8_model_call_budget_final_turn")


def _agentic_leg(user: str, ctx: ContextPackage, cfg, *, session_id: str,
                 parent_middleware: tuple, drop_thinking: bool) -> str:
    """The agentic chaining call that the stage deadline wraps, pinned so it can be resumed."""
    s8 = getattr(cfg, "step8", None)
    effort = knob(cfg, "step8.effort", None) or None
    via = resolve(cfg.models.chain).via
    return _deepagents.dispatch_agentic(
        user,
        model=cfg.models.chain,
        cfg=cfg,
        # cwd roots the deepagents route at the scanned repo; legacy vias ignore it.
        cwd=ctx.repo_root,
        system_prompt=SYSTEM,
        # 2, not 1: turn 1 is the forced ChainReport call, turn 2 is the tool result it ends on.
        max_turns=_cap_int(s8, "max_turns", 2),
        timeout=deadline_bound(_cap_int(s8, "timeout", 3600), _cap_int(s8, "deadline", 0),
                               None if drop_thinking else effort, via=via),
        max_output_tokens=int(knob(cfg, "step8.max_tokens", 64000)),
        response_model=ChainReport if via in RESPONSE_MODEL_VIAS else None,
        # s8 is handed its finding table whole; it has nothing to look up, so no tool is allowed.
        allowed_tools=(),
        parent_middleware=parent_middleware,
        tag=TAG,
        effort=None if drop_thinking else effort,
        session_id=session_id,
    )


def _replay_max_tokens(cfg) -> int:
    """The output cap of every no-tool re-ask: replay and json-repair restate under one clock."""
    return _cap_int(getattr(cfg, "step8", None), "replay_max_tokens", 16000)


def _cold_call(prompt: str, ctx: ContextPackage, cfg, *, tag: str) -> str:
    """One no-tool chain re-ask (replay or json-repair), sized and clocked like the replay leg."""
    s8 = getattr(cfg, "step8", None)
    # Floors are looked up by the exact tag, so the stage scope does not reach this one
    with stage_floors(tag, min_chars=MIN_RESPONSE_CHARS, min_tokens=MIN_RESPONSE_TOKENS):
        return _deepagents.dispatch_prompt(
            prompt,
            model=cfg.models.chain,
            cfg=cfg,
            cwd=ctx.repo_root,
            system_prompt=SYSTEM,
            max_tokens=_replay_max_tokens(cfg),
            # replay_timeout, not the stage clock: the cli folds a None effort into an
            # effort-scaled clock
            timeout=_cap_int(s8, "replay_timeout", 300),
            response_model=(ChainReport if resolve(cfg.models.chain).via in RESPONSE_MODEL_VIAS
                            else None),
            tag=tag,
            effort=_REPLAY_EFFORT,
        )


def _replay_leg(user: str, ctx: ContextPackage, cfg, transcript: Transcript) -> str:
    """Re-asks for the chain analysis with no tools, from the transcript the killed session reached."""
    return _cold_call(
        replay_prompt(transcript, user, instruction=S8_REPLAY_INSTRUCTION, stage="s8"),
        ctx, cfg, tag=f"{TAG} replay")


def repairable(raw: object) -> bool:
    """True when an unparseable reply carries a schema key with a value, so a re-ask can restate it."""
    return isinstance(raw, str) and bool(_REPAIRABLE_RX.search(raw))


def repair_fits(raw: str, cfg) -> bool:
    """True when a restatement of *raw* fits the replay output cap the repair re-ask runs under."""
    # A repair re-emits the whole reply; past the replay cap it would clip or outrun
    # replay_timeout, so it is skipped rather than given the stage cap
    return estimate_tokens(raw) <= _replay_max_tokens(cfg)


def repair_call(raw: str, err: Exception, ctx: ContextPackage, cfg) -> str:
    """The one json-repair re-ask: restates *raw* as a ChainReport, raising on failure."""
    return _cold_call(repair_prompt(raw, err), ctx, cfg, tag=f"{TAG} json-repair")


def chain_call(findings: list[Finding], ctx: ContextPackage, cfg, *,
               labels: list[str] | None = None, allow_resend: bool = True) -> str:
    """Returns the raw chaining reply, raising on failure; ``labels`` names each finding in the prompt so a windowed call's reply resolves against the full list. ``allow_resend=False`` vetoes the drop-tier resend, for a caller that is already sending a resend of its own (the half-window retry after an at-cap clip)."""
    s8 = getattr(cfg, "step8", None)
    effort = knob(cfg, "step8.effort", None) or None
    user = build_prompt(findings, ctx, labels=labels, cfg=cfg)
    deadline = _cap_int(s8, "deadline", 0)
    replayed = False

    def _dispatch(*, drop_thinking: bool) -> str:
        nonlocal replayed
        session_id = session_id_for("s8", "chain")
        transcript = Transcript()
        middleware: tuple = (RecordTranscript(transcript),)
        budget = _call_budget(s8)
        if budget is not None:
            middleware += (budget,)
        try:
            return run_with_deadline(
                lambda: _agentic_leg(user, ctx, cfg, session_id=session_id,
                                     parent_middleware=middleware,
                                     drop_thinking=drop_thinking),
                seconds=deadline, stage=TAG, effort=effort)
        except CallTimeoutError:
            # s8 is a ONE-CALL stage (`_call_budget` above): a kill mid-turn leaves no completed
            # assistant turn to continue, so a resume here would be a second full chain analysis
            # at stage effort under a shorter clock than the one that just expired -- a cold
            # re-run, not a continuation. Go straight to the transcript re-ask instead.
            console.write(f"  [s8] deadline {deadline}s hit — replaying the chain analysis "
                          f"from the transcript")
            replayed = True
            return _replay_leg(user, ctx, cfg, transcript)
        finally:
            release_pinned_session(session_id)

    with stage_floors(TAG, min_chars=MIN_RESPONSE_CHARS, min_tokens=MIN_RESPONSE_TOKENS):
        # Only an effort can lose the forced tool_choice (memoised model or manual thinking) and
        # shares the output budget; with none a retry just repeats
        # A refused chain call loses only the enrichment: s8_chain.py ships the deterministic
        # report regardless, so the resend buys nothing here (a category, where the route reports
        # one, is diagnostic only and gates nothing).
        # A reply that came from the deadline replay leg above is already a cold re-ask under the
        # same deadline; a drop-tier resend of it would be a second, identical cold re-ask, so
        # `replayed` vetoes it. `allow_resend=False` vetoes it the same way for the half-window caller.
        return dispatch_or_retry_unforced(
            _dispatch, "chain", stage="s8",
            effort=_deepagents.droppable_effort(cfg.models.chain, effort, agentic=True),
            may_retry=lambda: allow_resend and effort is not None and not replayed,
            resend_refusal=False)
