# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Representative config files, one per directory, with redacted capped bodies."""
from __future__ import annotations

from pathlib import Path, PurePosixPath

from vvaharness.evidence._grouping import _round_robin_select
from vvaharness.evidence.read import _cap_text, _read_capped
from vvaharness.lang.detect import SECURITY_CONFIG_NAMES
from vvaharness.report.redact import redact
from vvaharness.scope.configs import _rep_score

_CONFIG_EXTS = {".yml", ".yaml", ".json", ".toml", ".ini",
                ".properties", ".conf", ".cfg", ".env"}

# Raw ceiling for a config-rep read, floored at 4x an operator-raised cap.
_CONFIG_REP_RAW_CEILING = 500_000


def _select_config_reps(full_files: list[str], max_reps: int) -> list[str]:
    """One rep per parent dir, preferring a security-named file, then scope env tier."""
    by_dir: dict[str, list[str]] = {}
    for rel in full_files:
        p = PurePosixPath(rel)
        suffix = p.suffix.lower()
        name = p.name.lower()
        if suffix in _CONFIG_EXTS or name in _CONFIG_EXTS or name in SECURITY_CONFIG_NAMES:
            parent = str(p.parent) if str(p.parent) != "." else ""
            by_dir.setdefault(parent, []).append(rel)

    for d in by_dir:
        # _rep_score(f, 0)[0]: scope's env tier, as the tiebreak after security-name preference.
        by_dir[d].sort(key=lambda f: (
            PurePosixPath(f).name.lower() not in SECURITY_CONFIG_NAMES,
            _rep_score(f, 0)[0],
            f,
        ))

    pairs = _round_robin_select(by_dir, max_reps, keys=sorted(by_dir))
    return [rel for _dir, rel in pairs]


def _config_rep_contents(root: Path, rel_paths: list[str], cap_chars: int,
                         max_bodies: int) -> list[tuple[str, str]]:
    """Body for the first max_bodies reps, redacted+capped, security-named first; rest path-only."""
    reps: list[tuple[str, str]] = []
    read_ceiling = max(_CONFIG_REP_RAW_CEILING, cap_chars * 4)
    with_bodies = frozenset(
        sorted(rel_paths, key=lambda r: PurePosixPath(r).name.lower() not in SECURITY_CONFIG_NAMES)
        [: max(max_bodies, 0)]
    )
    for rel in rel_paths:
        body = ""
        if cap_chars > 0 and rel in with_bodies:
            # redact-before-cap: whole_or_nothing means redact() never sees a bisected secret.
            raw = _read_capped(root, root / rel, read_ceiling,
                               whole_or_nothing=True)
            if raw:
                body = _cap_text(redact(raw), cap_chars)
        reps.append((rel, body))
    return reps


def gather_config_reps(root: Path, full_files: list[str], max_reps: int,
                       cap_chars: int, max_bodies: int) -> list[tuple[str, str]]:
    """Select then read config representatives; see `_select_config_reps`/`_config_rep_contents`."""
    return _config_rep_contents(
        root, _select_config_reps(full_files, max_reps), cap_chars, max_bodies)
