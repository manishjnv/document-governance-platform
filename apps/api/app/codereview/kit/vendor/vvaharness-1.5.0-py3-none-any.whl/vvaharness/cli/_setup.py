# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""The interactive `setup` wizard and the agent-file installer it calls."""
from __future__ import annotations

import os
import stat
import sys
from pathlib import Path

from vvaharness.cli._commands import _ICON
from vvaharness.cli._paths import _config_path_from
from vvaharness.util import console

# Windows has no meaningful symlink-planting threat model for a per-user CLI install.
_POSIX = os.name == "posix"


def _symlinked_ancestor(path: Path, anchor: Path) -> Path | None:
    """The first symlink at *path* itself or an existing dir between it and *anchor*, or None."""
    node = path
    while node != anchor and node != node.parent:
        try:
            lst = node.lstat()
        except OSError:
            lst = None  # nothing at this level yet — not a symlink, keep walking up
        if lst is not None and stat.S_ISLNK(lst.st_mode):
            return node
        node = node.parent
    return None


def _cache_advisory(cfg_path: str) -> None:
    import os
    import shlex
    from types import SimpleNamespace
    from urllib.parse import urlsplit

    from vvaharness import config as config_mod
    from vvaharness.backends.llm import cache, sdk
    from vvaharness.orchestrator.config_paths import _iter_model_roles

    try:
        cfg = config_mod.load(cfg_path)
    except (config_mod.ConfigPolicyError, OSError, ValueError):
        return
    if not any(getattr(model, "via", None) == "sdk"
               for _, model in _iter_model_roles(cfg)):
        return
    settings = cfg._data
    if not cache.markers_enabled(settings):
        return
    declared = settings.get("cache_route", "auto")
    if declared is False or str(declared).strip().lower() == "none":
        return
    transport = getattr(cfg, "sdk", None)
    endpoint = (getattr(transport, "base_url", None)
                or os.environ.get("ANTHROPIC_BASE_URL") or "https://api.anthropic.com")
    try:
        route = sdk._cache_route(SimpleNamespace(base_url=endpoint),
                                 config=settings, emit_note=False)
        host = urlsplit(str(endpoint)).hostname
    except ValueError:
        return
    if route != sdk._ROUTE_UNKNOWN:
        return
    print("\n  -> Prompt caching on the configured SDK endpoint (cost only):")
    print(f"      {host or 'Endpoint'} is unrecognised; SDK cache markers are withheld.")
    print("      For an Anthropic-Messages-compatible gateway, set this in")
    print("      config.local.yaml beside the selected profile (trusted, operator-owned):")
    print("          cache_route: anthropic")
    print("      Verify provider support with a live probe (spends model tokens):")
    print(f"          vvaharness doctor --cache-probe --config {shlex.quote(str(cfg_path))}")


def _install_agents() -> int:
    """Drop operating instructions into each installed AI agent's file, leaving existing files untouched."""
    import shutil

    from vvaharness import agentdoc
    cwd, home = Path.cwd(), Path.home()

    def put(path: Path, content: str, *, anchor: Path) -> None:
        if path.exists():
            print(f"    • exists, left as-is: {path}")
            return
        if _POSIX:
            symlink = _symlinked_ancestor(path, anchor)
            if symlink is not None:
                console.mark("warn", f"refusing to write {path}: "
                             f"{symlink} is a symlink", indent=4, err=False)
                return
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        console.mark("ok", f"wrote {path}", indent=4, err=False)

    # Cross-tool standard + Copilot: no CLI to detect, so always provide it.
    put(cwd / "AGENTS.md", agentdoc.AGENT_DOC, anchor=cwd)
    put(cwd / ".github" / "copilot-instructions.md", agentdoc.AGENT_DOC, anchor=cwd)
    if shutil.which("claude"):
        put(cwd / "CLAUDE.md", agentdoc.AGENT_DOC, anchor=cwd)
        put(home / ".claude" / "skills" / "vvaharness" / "SKILL.md",
            agentdoc.CLAUDE_SKILL, anchor=home)
    if shutil.which("gemini"):
        put(cwd / "GEMINI.md", agentdoc.gemini_doc(), anchor=cwd)
    return 0

def _setup(rest: list[str]) -> int:
    """Guided readiness wizard: checks env/deps/config and offers to scaffold a .env; read-only unless --write-env."""
    from vvaharness import __version__
    from vvaharness.util import environment as env
    from vvaharness.util.environment import FAIL

    cfg_path = _config_path_from(rest)
    write_env = "--write-env" in rest

    print(f"\n  ⟐  vvaharness {__version__} — setup\n")
    _prompt_for_remediation_inputs()
    checks = env.run_checks(cfg_path)
    for c in checks:
        print(f"  {_ICON.get(c.status, '?')} {c.name:<30} {c.detail}")

    n_ok, n_warn, n_blocking = env.summarize(checks)
    print("  " + "─" * 60)
    print(f"  {n_ok} ok · {n_warn} warning(s) · {n_blocking} blocking issue(s)")

    prof, why = env.recommend_profile()
    if prof:
        print(f"\n  → Recommended profile: {prof}  ({why})")
        if prof != "default":
            print(f"      vvaharness scan --repo <path> "
                  f"--config vvaharness/config/profiles/{prof}.yaml")

    # Targets the most common trap: gateway token present but no base_url set.
    gw = next((c for c in checks if c.name == "via:sdk endpoint"
               and c.status == FAIL), None)
    gw_url, gw_src = env.detect_gateway()
    ca = env.detect_ca_cert()
    if gw:
        print("\n  → Fix the Anthropic endpoint:")
        if gw_url:
            print(f"      export ANTHROPIC_BASE_URL={gw_url.split('?', 1)[0]}"
                  f"   # found in {gw_src}")
        else:
            print("      export ANTHROPIC_BASE_URL=https://<your-gateway>/")
        if ca:
            # via:sdk/deepagents(anthropic) read SSL_CERT_FILE; NODE_EXTRA_CA_CERTS only hits Node
            print(f"      export SSL_CERT_FILE={ca}   # via:sdk + "
                  "via:deepagents; or set ANTHROPIC_SDK_CA_CERT — the shipped "
                  "profiles expand it into sdk.ca_cert")
        print("      export CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS=1   "
              "# if the gateway rejects beta flags (400)")

    _cache_advisory(cfg_path)

    env_file = Path(".env")
    if not env_file.exists():
        example = Path(".env.example")
        if write_env:
            base = example.read_text(encoding="utf-8") if example.exists() else ""
            extra = ""
            if gw_url:
                extra += f"\n# auto-detected from {gw_src}\nANTHROPIC_BASE_URL={gw_url}\n"
            if ca:
                extra += (
                    "# CA bundle for the Anthropic endpoint — via:sdk and "
                    "via:deepagents read SSL_CERT_FILE\n"
                    "# (shipped profiles also expand ANTHROPIC_SDK_CA_CERT "
                    "into sdk.ca_cert):\n"
                    f"SSL_CERT_FILE={ca}\n"
                    "# only the Node-based paths (via:cli roles, the "
                    "Agent-SDK S11 launcher) read this one:\n"
                    f"NODE_EXTRA_CA_CERTS={ca}\n"
                )
            if gw_url or ca:
                extra += "# uncomment if the gateway rejects beta flags (400):\n" \
                         "# CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS=1\n"
            env_file.write_text(base + extra, encoding="utf-8")
            console.mark("ok", "wrote .env"
                  + (" (incl. detected gateway)" if gw_url else "")
                  + " — fill in any remaining keys, then "
                  "`set -a && source .env && set +a`", indent=2, lead="\n", err=False)

    if "--install-agents" in rest:
        print("\n  Installing AI-agent instructions:")
        _install_agents()
    else:
        print("\n  AI agent driving this? Run `vvaharness setup --install-agents` "
              "to drop the right instructions for your agent (Claude/Copilot/"
              "Gemini) so it runs the tool instead of editing it.")
        print("  (Operating manual: AGENTS.md · capabilities: docs/SKILLS.md)")
    if n_blocking:
        print(f"\n  Not ready: fix the {n_blocking} blocking item(s) above, "
              f"then `vvaharness scan`.\n")
        return 1
    print("\n  Ready ✓  →  vvaharness scan --repo /path/to/target")
    print("  The packaged default profile skips S10 remediation and S11 validation.")
    console.mark("warn", "--remediate enables S10 only and can edit target source; "
          "in-scan S11 needs step_validate.enabled: true.", indent=2, err=False)
    print("    Other profiles or a local overlay can enable S10/S11; "
          "--stop-after s9 skips both with any profile.\n")
    return 0

def _prompt_for_remediation_inputs() -> None:
    """Persist an inputs directory when wheel defaults cannot be resolved."""
    from vvaharness.remediation_agent import rule_paths

    missing = rule_paths.missing_rules(rule_paths.__file__)
    if not missing or not sys.stdin.isatty():
        return
    print("  ! remediation defaults are missing: " + ", ".join(missing))
    while True:
        try:
            answer = input(
                "  Path to the VVAH inputs directory (blank to skip): "
            ).strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not answer:
            return
        directory, absent = rule_paths.validate_inputs_dir(answer)
        if absent:
            print(f"  ! {directory} is missing: {', '.join(absent)}")
            continue
        target = rule_paths.save_inputs_dir(directory)
        console.mark("ok", f"saved remediation inputs directory in {target}", indent=2, err=False)
        return
