# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Streaming (multi-turn) graph compilation and its public entry point."""

from __future__ import annotations

import os
import threading
from typing import TYPE_CHECKING

from langgraph.graph.state import CompiledStateGraph

from vvaharness.backends.harness.deepagents.limits import RECURSION_HEADROOM
from vvaharness.backends.harness.deepagents.models import (
    ALL_NATIVE_TOOLS,
    SUBAGENT_DISPATCH_TOOL,
    CompiledGraph,
    SubagentSpec,
)
from vvaharness.backends.harness.deepagents.options.filesystem import (
    _filesystem_permissions,
    _session_backend,
    _skill_sources,
)
from vvaharness.backends.harness.deepagents.options.graph_builder import _create_agent
from vvaharness.backends.harness.deepagents.options.response_format import _response_format
from vvaharness.backends.harness.deepagents.options.subagents import (
    _build_session_tools,
    _tool_policy,
    get_subagent_specs,
)
from vvaharness.backends.harness.deepagents.tools import session_tool_names
from vvaharness.backends.harness.models import READ_TOOLS, StreamingOptions

if TYPE_CHECKING:
    from langchain_core.tools import BaseTool


def build_subagents(options: StreamingOptions) -> list[SubagentSpec]:
    """Return native DeepAgents subagent specs for the streaming parent."""
    return get_subagent_specs(options)


def _middleware_tool_names(options: StreamingOptions) -> frozenset[str]:
    """Tool names contributed by the caller's middleware (langchain's `AgentMiddleware.tools`)."""
    names: set[str] = set()
    for mw in options.parent_middleware:
        names.update(t.name for t in getattr(mw, "tools", ()) or ())
    return frozenset(names)


def _permitted_tool_calls(
    options: StreamingOptions, session_tools: list[BaseTool]
) -> frozenset[str] | None:
    """Executor-permitted tool names: the caller's set, its session tools, its middleware's tools."""
    if options.permitted_tool_calls is None:
        return None
    permitted = (options.permitted_tool_calls | session_tool_names(session_tools)
                 | _middleware_tool_names(options))
    if options.agents:
        permitted |= frozenset({SUBAGENT_DISPATCH_TOOL})
    return permitted


def _extra_excluded_tools(options: StreamingOptions) -> frozenset[str] | None:
    """Advertisement counterpart of the executor gate: un-offer what it refuses."""
    # From the SAME permitted_tool_calls as PermitTools so the two cannot drift; advertising only
    if options.permitted_tool_calls is None:
        return None
    excluded = ALL_NATIVE_TOOLS - options.permitted_tool_calls
    if options.agents:
        return excluded
    return excluded | frozenset({SUBAGENT_DISPATCH_TOOL})


def _build_streaming_graph(options: StreamingOptions) -> CompiledStateGraph:
    """Compile the parent agent graph and its declarative subagents."""
    subagent_specs = build_subagents(options)
    # The orchestrator only gets read tools; it dispatches subagents via the auto-added task() tool.
    parent_tools = tuple(t for t in _tool_policy(options).allowed_tools if t in READ_TOOLS)
    tools = _build_session_tools(options, parent_tools)
    return _create_agent(
        model_id=options.model,
        env=options.env,
        think_in_prompt=options.think_in_prompt,
        system_prompt=options.system_prompt,
        tools=tools,
        name=options.graph_name,
        skills=_skill_sources(options.skill_root, options.cwd),
        permissions=_filesystem_permissions(options),
        model_provider=options.model_provider,
        redact_reads=bool(subagent_specs) or not options.allow_writes,
        backend=_session_backend(options),
        response_model=options.response_model,
        response_format=_response_format(
            options.response_model, options.model, options.model_provider,
        ),
        subagents=subagent_specs,
        # None (S10/S11 and every non-opted-in caller) adds no exclusion and installs no gate.
        extra_excluded_tools=_extra_excluded_tools(options),
        permitted_tool_calls=_permitted_tool_calls(options, tools),
        # None (the frozen S10/S11 defaults) keeps the model's own ceiling.
        max_output_tokens=options.max_output_tokens,
        output_cap=options.output_cap,
        cache_markers=options.cache_markers,
        # Agentic sessions re-read the marked tail every turn; keep it on.
        cache_tail=True,
        parent_middleware=options.parent_middleware,
        effort=options.effort,
        use_responses_api=options.use_responses_api,
    )


#: session_id -> the compiled graph built for it, so a resume reaches the SAME MemorySaver.
_SESSIONS: dict[str, CompiledGraph] = {}
_SESSIONS_LOCK = threading.Lock()


def build_streaming_agent(options: StreamingOptions) -> CompiledGraph:
    """Return a compiled parent graph and its LangGraph invoke config."""
    graph = _build_streaming_graph(options)
    # Generous headroom: LangGraph ticks the recursion limit per node, not per parallel batch.
    compiled = CompiledGraph(
        graph=graph,
        config={
            "configurable": {"thread_id": options.session_id or os.urandom(8).hex()},
            "recursion_limit": (options.max_turns or 50) + RECURSION_HEADROOM,
        },
    )
    if options.session_id:
        # Held so resume_streaming can re-enter this graph: the conversation lives in its
        # MemorySaver, keyed by thread_id, and dies with the graph object.
        with _SESSIONS_LOCK:
            _SESSIONS[options.session_id] = compiled
    return compiled


def resumable(session_id: str) -> CompiledGraph | None:
    """The compiled graph still holding *session_id*'s conversation, or None once released."""
    with _SESSIONS_LOCK:
        return _SESSIONS.get(session_id)


def release_session(session_id: str) -> None:
    """Drop *session_id*'s graph so its checkpointed conversation can be collected."""
    with _SESSIONS_LOCK:
        _SESSIONS.pop(session_id, None)
