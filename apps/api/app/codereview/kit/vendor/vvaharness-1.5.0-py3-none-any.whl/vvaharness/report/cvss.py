# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""CVSS 3.1 calculator (FIRST.org spec §7) and the single home for its weights and coefficients."""
from __future__ import annotations

import re

_VECTOR_RE = re.compile(
    r"CVSS:3\.[01]/AV:(?P<AV>[NALP])/AC:(?P<AC>[LH])/PR:(?P<PR>[NLH])/"
    r"UI:(?P<UI>[NR])/S:(?P<S>[UC])/C:(?P<C>[NLH])/I:(?P<I>[NLH])/A:(?P<A>[NLH])"
)

AV = {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.2}
AC = {"L": 0.77, "H": 0.44}
PR_SCOPE_UNCHANGED = {"N": 0.85, "L": 0.62, "H": 0.27}
PR_SCOPE_CHANGED = {"N": 0.85, "L": 0.68, "H": 0.50}
UI = {"N": 0.85, "R": 0.62}
CIA = {"H": 0.56, "L": 0.22, "N": 0.0}
REQ = {"H": 1.5, "L": 0.5}
EXPLOIT_MATURITY = {"U": 0.91, "P": 0.94, "F": 0.97, "H": 1.0}
REMEDIATION_LEVEL = {"O": 0.95, "T": 0.96, "W": 0.97, "U": 1.0}
REPORT_CONFIDENCE = {"U": 0.92, "R": 0.96, "C": 1.0}

NEUTRAL_WEIGHT = 1.0
NO_SCORE = -1.0
MAX_SCORE = 10.0
MISS_CAP = 0.915
SEVERITY_BANDS = ((4.0, "Low"), (7.0, "Medium"), (9.0, "High"))

EXPLOITABILITY_COEFF = 8.22
IMPACT_SCOPE_UNCHANGED_COEFF = 6.42
IMPACT_SCOPE_CHANGED_COEFF = 7.52
IMPACT_OFFSET = 0.029
IMPACT_PENALTY_COEFF = 3.25
IMPACT_PENALTY_OFFSET = 0.02
BASE_IMPACT_EXPONENT = 15
MODIFIED_IMPACT_EXPONENT = 13
MODIFIED_IMPACT_MISS_CORRECTION = 0.9731
SCOPE_CHANGED_COEFF = 1.08
ROUNDUP_SCALE = 100_000
ROUNDUP_STEP = 10_000
ROUNDUP_STEPS_PER_UNIT = 10.0


def roundup1(x: float) -> float:
    """Spec Appendix A Roundup: round the scaled value, never truncate, or it inflates by 0.1."""
    n = round(x * ROUNDUP_SCALE)
    if n % ROUNDUP_STEP == 0:
        return n / ROUNDUP_SCALE
    return (n // ROUNDUP_STEP + 1) / ROUNDUP_STEPS_PER_UNIT


def base_impact(iss: float, scope_changed: bool) -> float:
    """Spec §7.2 impact sub-score, whose exponent differs from the §7.3 modified form."""
    if not scope_changed:
        return IMPACT_SCOPE_UNCHANGED_COEFF * iss
    return (IMPACT_SCOPE_CHANGED_COEFF * (iss - IMPACT_OFFSET)
            - IMPACT_PENALTY_COEFF * (iss - IMPACT_PENALTY_OFFSET) ** BASE_IMPACT_EXPONENT)


def modified_impact(miss: float, scope_changed: bool) -> float:
    """Spec §7.3 modified impact, carrying the MISS correction and exponent the base form lacks."""
    if not scope_changed:
        return IMPACT_SCOPE_UNCHANGED_COEFF * miss
    return (IMPACT_SCOPE_CHANGED_COEFF * (miss - IMPACT_OFFSET)
            - IMPACT_PENALTY_COEFF
            * (miss * MODIFIED_IMPACT_MISS_CORRECTION - IMPACT_PENALTY_OFFSET)
            ** MODIFIED_IMPACT_EXPONENT)


def combine(impact: float, exploitability: float, scope_changed: bool) -> float:
    """Spec §7 final combination, capped at MAX_SCORE and rounded up."""
    raw = impact + exploitability
    if scope_changed:
        raw *= SCOPE_CHANGED_COEFF
    return roundup1(min(raw, MAX_SCORE))


def score(vector: str | None) -> float | None:
    """Compute CVSS 3.1 base score from a vector string. Returns None if unparseable."""
    if not vector:
        return None
    m = _VECTOR_RE.search(vector)
    if not m:
        return None
    g = m.groupdict()
    scope_changed = g["S"] == "C"

    iss = 1 - (1 - CIA[g["C"]]) * (1 - CIA[g["I"]]) * (1 - CIA[g["A"]])
    impact = base_impact(iss, scope_changed)
    if impact <= 0:
        return 0.0

    pr = (PR_SCOPE_CHANGED if scope_changed else PR_SCOPE_UNCHANGED)[g["PR"]]
    exploitability = EXPLOITABILITY_COEFF * AV[g["AV"]] * AC[g["AC"]] * pr * UI[g["UI"]]
    return combine(impact, exploitability, scope_changed)


def score_or_sentinel(vector: str | None) -> float:
    """:func:`score`, with ``None``/unparseable mapped to the ``NO_SCORE`` sentinel renderers expect."""
    s = score(vector)
    return s if s is not None else NO_SCORE


def rating(s: float | None) -> str:
    """Severity label per spec §5; NOT sentinel-safe, so callers guard with ``>= 0`` first."""
    if s is None:
        return "Unknown"
    if s == 0.0:
        return "None"
    for upper, label in SEVERITY_BANDS:
        if s < upper:
            return label
    return "Critical"
