# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Drives remediation from an existing scan report: parses findings and walks them one-by-one via the per-finding loop."""

from __future__ import annotations

from pathlib import Path

from vvaharness.orchestrator.checkpoints import REMEDIATE_PREFIX, prune_stale_steps
from vvaharness.orchestrator.findings_json import InvalidFindingsJSON
from vvaharness.remediation_agent.discovery import (
    load_findings,
    locate_report,
    prepare_layout,
)
from vvaharness.remediation_agent.options import parse_options
from vvaharness.remediation_agent.runner import (
    model_banner,
    process_targets,
    step_key_of,
)
from vvaharness.remediation_agent.select import resolve_top
from vvaharness.util import console


def remediate(repo: str | None, args=None, cfg=None) -> int:
    """Entry point for the ``remediate`` command; returns a process exit code (0 on success)."""
    if not repo:
        console.write("usage: vvaharness remediate --repo <path>")
        return 2
    if cfg is None:
        console.mark("fail", "no config loaded — internal error: remediate() requires cfg.", indent=2)
        return 2

    try:
        opts = parse_options(args or [])
    except ValueError as e:
        console.mark("fail", f"{e}", indent=2)
        return 2

    repo_path = Path(repo)
    if not repo_path.exists():
        console.mark("fail", f"no such path: {repo}", indent=2)
        return 1

    report, rc = locate_report(repo_path)
    if report is None:
        return rc

    # Interactive mode is a manual picker, so a profile cap must not silently pre-truncate the list; an explicit --top N still applies.
    if opts.interactive and opts.top is None:
        top = None
    else:
        top = resolve_top(opts.top, cfg)
    console.write(f"  [Remediation Agent] report: {report}")
    try:
        found = load_findings(repo_path, report, top)
    except InvalidFindingsJSON as e:
        # Corrupt contract file is an error: an MD-parse fallback could remediate other findings
        console.mark("fail", f"{e}", indent=2)
        return 1
    findings = found.selected

    n = len(findings)
    if n == 0:
        console.mark("ok", "identified 0 SAST issue(s) — nothing to remediate.", indent=2)
        return 0

    layout = prepare_layout(repo_path)
    # Drop checkpoint rows no finding in the current report claims; uses discovered, not the --top N subset, so unselected findings still resume correctly.
    prune_stale_steps(layout.run_id, REMEDIATE_PREFIX,
                      [step_key_of(t, cfg) for t in found.discovered])
    console.write(f"  identified {n} SAST issue(s) to remediate")
    console.write(f"  [Remediation Agent] model: {model_banner(cfg)}  mode={opts.mode}")
    console.write(f"  [Remediation Agent] artefacts → {layout.rem_dir}")
    if opts.verbose:
        console.write("  [Remediation Agent] verbose: printing prompt + raw LLM response "
                      "per finding")

    if opts.interactive:
        from vvaharness.remediation_agent.interactive import run_interactive
        return run_interactive(findings, report_path=report,
                               rem_dir=layout.rem_dir, ckpt_dir=layout.ckpt_dir,
                               run_id=layout.run_id, cfg=cfg, mode=opts.mode,
                               verbose=opts.verbose)

    # The report's own ordinals are kept; after a --top N selection they are no longer 1..N.
    return process_targets(findings, layout=layout, cfg=cfg,
                           repo_path=repo_path, opts=opts, report=report)

