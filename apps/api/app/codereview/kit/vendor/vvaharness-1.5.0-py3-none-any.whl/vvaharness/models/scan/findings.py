# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Findings and their post-processing forms: chains, rankings, drops."""
from __future__ import annotations

import logging
import math
import re
from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator

from vvaharness.models.scan._coerce import text as _coerce_text
from vvaharness.models.scan.work import DupLocation
from vvaharness.models.vocab import Severity, VulnClass

log = logging.getLogger(__name__)

class Finding(BaseModel):
    """One vulnerability, as every stage and both subsystems understand it."""

    title: str
    file: str
    line_start: int
    vuln_class: VulnClass
    # The ranking stage fills this from the RankedFinding wrapper at ingest.
    severity: Severity = Severity.MEDIUM
    line_end: int = 0
    cwe: str | None = None           # canonical "CWE-79"; set by s4, carried to MD + SARIF taxa
    vuln_class_label: str = ""       # the caller's own wording, when vuln_class folded to OTHER
    chunk_id: str = ""               # the s3 analysis unit this came from; empty for a
                                     # finding that did not originate in this pipeline
    impact: str = ""                 # 2-3 sentences, plain language, business-facing
    description: str = ""
    exploit_scenario: str = ""       # ≤5 sentences: concrete input → impact
    preconditions: list[str] = []    # what must be true for exploitation
    recommendation: str = ""         # security property + specific code change
    # ── evidence: carried through remediation and validation, not re-derived ──
    code_snippet: str = ""
    source_ref: str | None = None    # "file:line" where untrusted input enters (s4 evidence gate)
    sink_ref: str | None = None      # "file:line" where it is used unsafely
    duplicates: list[DupLocation] = []  # call sites collapsed into this canonical by s7_dedup;
                                        # these are the OTHER SITES a fix must also cover
    backfilled_refs: list[str] = []  # which refs s5's AST backfill synthesized, not s4-derived
    # s4's pre-re-anchor line, so s7 judges proximity on pre-move coords; 0 = unset, s6 resets it
    pre_anchor_line: int = 0
    case_id: str = ""                # stable identity across attempts; minted at ingest when empty
    # s8 chain commentary; duplicated from RankedFinding or a Finding-only engine would lose it
    exploitability_notes: str = ""
    # s8: the model's severity word lost to the CVSS band; kept OUT of the remediation prompt
    severity_prose_mismatch: str = ""
    # Trait stamps from s6, no static CWE lists; posture = build/deploy, skipped by remediation
    channel: str = "main"
    # A missing control, not a value an attacker carries forward; s8 lets it chain nothing onward
    control_absence: bool = False
    # ""=LLM, detector=S5 rulepack, s6_discovered=minted DURING verify, outside the ledger
    origin: str = ""
    # A repeat-site CLONE from s6, never the primary; lets scan.py's ledger stay a real equality
    is_repeat_clone: bool = False

    @field_validator("channel", mode="before")
    @classmethod
    def _v_channel(cls, v):
        """Canonicalize to "main"/"posture" so no consumer needs its own casefold."""
        return "posture" if isinstance(v, str) and v.strip().casefold() == "posture" else "main"

    verdict: Literal["TRUE_POSITIVE", "FALSE_POSITIVE"] | None = None
    verdict_confidence: int | None = None     # 0..10
    verdict_reason: str = ""
    cvss_vector: str | None = None            # CVSS:3.1/AV:_/AC:_/...
    cvss_score: float | None = None           # 0.0-10.0, computed from vector
    cvss_rating: str | None = None            # None/Low/Medium/High/Critical (cvss.rating(), 3.1)

    # EV wire values (CONFIRMED/NOT_CONFIRMED/INCONCLUSIVE/NOT_TESTED); None = EV never ran
    ev_status: str | None = None
    ev_evidence: str = ""                     # concrete tell + offending request (guard-verified)
    # ev_evidence source: rule | triage | judge — so a routing fact reads apart from a model's
    ev_reason_source: str = ""
    ev_repro: str = ""                        # redacted, replayable request line
    ev_method: str = ""                       # "deterministic-backed" (judge + oracle tell) |
                                              # "agent-judged" (judge on reasoning)
    ev_confidence: str = ""                   # "high" | "medium" | "low" (proof tier)
    # EV's 0-10 certainty in the LIVE outcome — a different axis from verdict_confidence
    ev_confidence_score: int | None = None
    # Judge-scored from OBSERVED impact; static cvss_score stays the ranking authority
    ev_cvss_vector: str = ""                  # CVSS 3.1 vector the judge emitted for the exploit
    ev_cvss_score: float | None = None        # 0.0-10.0, computed from ev_cvss_vector
    ev_cvss_rating: str | None = None         # None/Low/Medium/High/Critical
    # Confirming request/response for a replayable repro; a plain dict so this module stays a leaf
    ev_repro_detail: dict = Field(default_factory=dict)

    # ── Post-s7 environmental enrichment (set by pipeline._enrich_findings) ──
    vsvs_vector: str | None = None            # CVSS env vector w/ CR/IR/AR/MAV
    vsvs_score: float | None = None           # 0.0-10.0
    vsvs_rating: str | None = None            # None/Low/Medium/High/Critical
    offensive_priority: str | None = None       # P1..P4
    offensive_reason: str = ""

    def canonical_key(self, line_bucket: int = 10) -> tuple:
        """Identity for intersection; cwe is in the key because VulnClass folds web defects."""
        return (self.file, self.line_start // line_bucket, self.vuln_class, self.cwe)


# ── s8 chain structures ──


# Lazy: "a.py:231:5" splits at the first :LINE, but a :LINE followed by path text ("h:8080/x.py:12",
# "C:\\x\\a.py:40") stays in the path. Never crosses "->" (two citations); ASCII keeps \d to 0-9
_FILE_LINE_RX = re.compile(r"^\s*((?:(?!->)\S)+?):(\d+)(?::\d+)?(?![\w/\\]|\.\w)", re.ASCII)


class LinkEvidence(BaseModel):
    """Why hop N feeds hop N+1: the mechanism, plus the file/line that shows it holds."""
    from_id: str = Field(default="", description="The FINDING id this link starts at (e.g. f3).")
    to_id: str = Field(default="", description="The FINDING id this link leads to (e.g. f7).")
    mechanism: str = Field(default="", description=
        "Concretely, what from_id produces that to_id consumes — a value, a "
        "privilege, a reachable state. Not a restatement of the two titles.")
    file: str = Field(default="", description=
        "Repo-relative path of the code that shows this link holds.")
    line: int = Field(default=0, description=
        "Line in that file which shows it. Must be a real line.")

    # A `file_line` string ("a.py:231 -> b.py:297") fills only what `file`/`line` left empty
    @model_validator(mode="before")
    @classmethod
    def _unpack_file_line(cls, data: object) -> object:
        if not isinstance(data, dict) or not isinstance(data.get("file_line"), str):
            return data
        data = dict(data)
        m = _FILE_LINE_RX.match(data.pop("file_line"))
        if m:
            if not data.get("file"):
                data["file"] = m.group(1)
            # "0", "" and junk read as unset, as the field coerces them
            if not cls._coerce_line(data.get("line")):
                # Kept a string so _coerce_line guards int()'s 4300-digit limit
                data["line"] = m.group(2)
        return data

    # Coerce, never reject: one "line 42" would fail S8's ENTIRE reply and INFO the whole report
    @field_validator("line", mode="before")
    @classmethod
    def _coerce_line(cls, v: object) -> object:
        # `1e400` → inf and int(inf) raises OverflowError, NOT ValueError: it would abort the scan
        try:
            f = float(v)  # type: ignore[arg-type]
        except (TypeError, ValueError):
            return 0
        # Negatives clamp: the citation gate fails line < 1 and the report suppresses line 0
        return max(int(f), 0) if math.isfinite(f) else 0

    @field_validator("from_id", "to_id", "mechanism", "file", mode="before")
    @classmethod
    def _coerce_str(cls, v: object) -> object:
        return _coerce_text(v)


class Chain(BaseModel):
    """Multi-step exploit path that combines several findings."""
    title: str                       # "UAF → arb write → code exec"
    steps: list[int]                 # indices into FinalReport.findings
    severity: Severity
    blocked_by_controls: list[str] = []   # control names that genuinely stop this
    # Kept apart from blocked_by_controls: a precondition under "Blocked by" reads as mitigated
    preconditions: list[str] = []
    # Carried, not validated then dropped: the per-hop mechanism separates a path from a bundle
    link_evidence: list[LinkEvidence] = []
    entry_reachability: str = ""      # how the attacker reaches the FIRST step
    # Two SEPARATE lists: len(quality_notes) prices the split; counting near-dups segregated most
    quality_notes: list[str] = []
    # Informational, not defects: the severity decision's wording, the near-duplicate relation
    disclosures: list[str] = []
    # lift_withheld | self_raise_capped | "": WHY the gate acted; `severity` holds the WHAT
    severity_decision: str = ""
    link_coverage: str = ""           # "N/M": resolved link citations / hops needing one
    narrative: str


# The chain pass's own prompt tells the model to omit a finding it has nothing to add to; this
# is the note that omission ships with, so a reader sees the basis (the carried CVSS/
# environmental band), not a bare "not ranked" that reads as a failure. FinalReport.unranked_split
# (report.py) matches on this exact string to find the findings the chain pass saw and skipped.
NOT_RANKED_NOTE = "(no chain role found by the chaining pass; severity from the CVSS band)"


class RankedFinding(BaseModel):
    finding: Finding
    severity: Severity
    exploitability_notes: str        # chain-pass LLM commentary incl. mitigations


class DroppedFinding(BaseModel):
    """Audit-trail entry for a finding removed before the final report."""
    file: str
    line: int
    vuln_class: VulnClass
    title: str
    chunk_id: str
    reason: Literal["FALSE_POSITIVE", "VERIFY_ERROR", "DUPLICATE",
                    "UNCONFIRMED", "EXCLUDED", "GUARDRAIL_BLOCKED", "INCONCLUSIVE"]
    detail: str = ""                 # verdict_reason / error text / dedup reasoning
    canonical_idx: int | None = None # for DUPLICATE: index into FinalReport.findings
