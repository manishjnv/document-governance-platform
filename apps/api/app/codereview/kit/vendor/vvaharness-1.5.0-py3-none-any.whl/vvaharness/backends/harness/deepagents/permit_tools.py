# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Middleware that refuses execution of any tool call outside a permitted set."""

# ExcludeTools only un-advertises (a forged call still runs); this FAILS CLOSED and logs names only

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from langchain.agents.middleware.types import AgentMiddleware
from langchain_core.messages import ToolMessage

from vvaharness.util import logs
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from langchain.agents.middleware.types import ToolCallRequest
    from langgraph.types import Command


class PermitTools(AgentMiddleware):
    """Refuse any tool call whose name is not in a fixed permitted set."""

    def __init__(self, permitted: frozenset[str]) -> None:
        """Allow only the tool names in *permitted* to execute; refuse the rest."""
        super().__init__()
        self._permitted = permitted

    def _refusal(self, request: ToolCallRequest) -> ToolMessage | None:
        """A synthetic error ToolMessage when the call is not permitted, else None."""
        tool_call = request.tool_call
        name = tool_call.get("name") or ""
        if name in self._permitted:
            return None
        log.warning(Event.TOOL_CALL_REFUSED, tool=name)
        return ToolMessage(
            content=(
                f"Error: tool {name!r} is not permitted in this session "
                f"and was not executed."
            ),
            name=name,
            tool_call_id=tool_call.get("id") or "",
            status="error",
        )

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage | Command[Any]],
    ) -> ToolMessage | Command[Any]:
        """Execute the call only when permitted; otherwise return the refusal."""
        return self._refusal(request) or handler(request)

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command[Any]]],
    ) -> ToolMessage | Command[Any]:
        """Async counterpart of :meth:`wrap_tool_call`."""
        return self._refusal(request) or await handler(request)


__all__ = ["PermitTools"]
