# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Deterministic code and repo-level facts for the chaining pass: shown, never interpreted."""
from __future__ import annotations

import re
from functools import lru_cache
from pathlib import Path
from stat import S_ISREG

from vvaharness.detect.matcher import split_lines
from vvaharness.models import ContextPackage, Finding
from vvaharness.util import net as _net

# Producers already cap snippets (largest observed ≈2k chars).
MAX_SNIPPET_CHARS = 1200

# A registration sits 1-3 lines above the def in every framework shape observed; past that, not one
MAX_DECORATOR_LINES = 4

# Prepended BEFORE the MAX_SNIPPET_CHARS cap, so one long decorator line could evict the CODE block
MAX_PROLOGUE_CHARS = 200

# Whole-line decorator/annotation; anchored at BOTH ends, or a prefix match admits injected prose
_ANNOTATION_RX = re.compile(r"""(?x)
    ^\s*(?:
        @\s*[A-Za-z_][\w.]*(?:\(.*\))?   # decorator / annotation, whole line
      | \#?\[[^\]\s][^\]]*\]             # attribute, alone on its line
    )\s*$""")

# Effective user = LAST USER of the LAST stage: earlier ones are build stages, later USER root wins
_FROM_RX = re.compile(r"^[^\S\n]*FROM[^\S\n]", re.IGNORECASE | re.MULTILINE)
_USER_RX = re.compile(r"^[^\S\n]*USER[^\S\n]+(?P<user>\S+)", re.IGNORECASE | re.MULTILINE)

# name/uid/name:group only: spliced under an OVERRIDE header, so \S+ carries prompt injection
_USER_TOKEN_RX = re.compile(r"^[A-Za-z0-9_.:\-]{1,64}$")


def _is_dockerfile_name(name: str) -> bool:
    """Whether *name* is ``Dockerfile`` or ``Dockerfile.<variant>``."""
    low = name.lower()
    if low == "dockerfile":
        return True
    # A bare startswith("dockerfile") also matched dockerfile_util.py, then stated as deploy fact
    prefix, dot, suffix = low.partition(".")
    return prefix == "dockerfile" and bool(dot) and suffix not in {
        "py", "pyi", "js", "ts", "rb", "go", "java", "cs", "php", "sh",
        "yml", "yaml", "json", "md", "txt", "html"}

# _real_host AND binding context, or SSRF/argv tokens fake "reachable"; localhost needs its own alt
_ADDR = r"\[?[0-9a-fA-F:.]+\]?|(?i:localhost)"
_BIND_RX = re.compile(
    rf"""(?x)
    # a server started with an explicit bind: app.run(host=),
    # uvicorn.run(..., host=), serve(host=)
      (?:\.(?:run|serve|bind|listen|create_server)\s*\(
         [^)\n]{{0,200}}?host\s*=\s*['"](?P<host>{_ADDR})['"])
    # socket-style bind/listen on an ("addr", port) tuple
    | (?:\.(?:bind|listen|create_server)\s*\(\s*\(\s*['"](?P<tuple>{_ADDR})['"])
    # a declared listen address constant, at statement position
    | (?:^[^\S\n]*(?:self\.)?
         (?:LISTEN_ADDRESS|BIND_ADDRESS|BIND_HOST|SERVER_HOST|HOST)\b
         [^=\n]{{0,40}}=\s*['"](?P<const>{_ADDR})['"])
    # compose/K8s published port mapping
    | (?:^\s*-\s*['"]?(?P<port>\d{{2,5}}):\d{{2,5}}['"]?\s*$)
    # a Dockerfile rewriting the bind at build time
    | (?:sed\s+-i\s+['"]?s/(?P<from>[0-9.]+)/(?P<to>[0-9.]+)/)
    """, re.MULTILINE)


def _real_host(host: str) -> bool:
    """Whether *host* is a complete IP literal or a loopback name, so fragments yield no fact."""
    return _net.is_loopback_host(host) or bool(_net.ip_literal(host))


def snippet_for(f: Finding, repo_root: str | Path, *,
                include_decorators: bool = False) -> str:
    """The finding's redacted snippet, or its cited lines read from disk, optionally widened over decorator lines."""
    from vvaharness.pipeline.stages.s4_deepdive import _redact_source
    text = (f.code_snippet or "").strip()
    if text:
        # Redact on BOTH paths: s5 backfills from raw text, and the gateway PII guard rejects it
        text = _redact_source(text, f.file, stage="s8")
    else:
        text = _read_range(repo_root, f.file, f.line_start, f.line_end)
    if include_decorators:
        prologue = _decorator_lines(repo_root, f.file, f.line_start)
        # A producer that cut above the decorator repeats its nearest line, so test only that line
        if prologue and prologue.rsplit("\n", 1)[-1].strip() not in text:
            text = f"{prologue}\n{text}" if text else prologue
    if len(text) > MAX_SNIPPET_CHARS:
        text = text[:MAX_SNIPPET_CHARS] + "\n… (snippet truncated)"
    return text


# s8.validate delegates its _line_text here — keep this signature stable.
def _file_lines(repo_root: str | Path, file: str) -> list[str]:
    """``file``'s lines, or [] when it is unreadable or escapes the repo."""
    try:
        root = Path(repo_root).resolve()
        target = (root / file).resolve()
        target.relative_to(root)
        st = target.stat()
        if not S_ISREG(st.st_mode):
            # A FIFO would BLOCK the read, not fail it.
            return []
        return list(_lines_cached(str(target), st.st_mtime_ns, st.st_size))
    except (OSError, ValueError, RuntimeError):
        return []


# Keying on (mtime, size) re-reads an edited file, so a long-lived process never serves a stale scan
@lru_cache(maxsize=256)
def _lines_cached(path: str, mtime_ns: int, size: int) -> tuple[str, ...]:
    # split_lines, not str.splitlines(): its extra breaks (\f, U+2028) shift ast/git line numbers
    return tuple(split_lines(
        Path(path).read_text(encoding="utf-8", errors="replace")))


def _read_range(repo_root: str | Path, file: str, start: int, end: int) -> str:
    """``file`` lines ``start..end``, redacted, or "" when unreadable."""
    lines = _file_lines(repo_root, file)
    if not lines:
        return ""
    lo = max(start - 1, 0)
    hi = max(end or start, start)
    from vvaharness.pipeline.stages.s4_deepdive import _redact_source
    return _redact_source("\n".join(lines[lo:hi]), file, stage="s8")


def _decorator_lines(repo_root: str | Path, file: str, start: int) -> str:
    """The contiguous whole-line decorator/annotation lines directly above ``start``, redacted."""
    if start <= 1:
        return ""
    lines = _file_lines(repo_root, file)
    if not lines:
        return ""
    picked: list[str] = []
    total = 0
    i = min(start - 1, len(lines)) - 1          # 0-based line above `start`
    while i >= 0 and len(picked) < MAX_DECORATOR_LINES:
        if not _ANNOTATION_RX.match(lines[i]):
            break
        total += len(lines[i]) + 1
        if total > MAX_PROLOGUE_CHARS:
                # Nearest-first, so an oversized outer line drops instead of evicting CODE
            break
        picked.append(lines[i])
        i -= 1
    if not picked:
        return ""
    from vvaharness.pipeline.stages.s4_deepdive import _redact_source
    return _redact_source("\n".join(reversed(picked)), file, stage="s8")


def same_location_groups(findings: list[Finding],
                         labels: list[str]) -> list[str]:
    """Prompt lines naming findings that share a ``file:line``, since one line cannot be its own precondition."""
    groups: dict[tuple[str, int], list[str]] = {}
    for lbl, f in zip(labels, findings):
        groups.setdefault((f.file, f.line_start), []).append(lbl)
    return [f"{', '.join(ids)} are all at {file}:{line} — ONE code fact"
            for (file, line), ids in groups.items() if len(ids) > 1]


def _user_directive_facts(rel: str, text: str) -> list[str]:
    """Prompt lines stating ``rel``'s USER directives as written and where they sit relative to the last ``FROM``."""
    matches = list(_USER_RX.finditer(text))
    # Dropping an unstateable token beats "no USER directive": neither way states a false fact
    users = [m for m in matches if _USER_TOKEN_RX.match(m.group("user"))]
    if matches and not users:
        return []
    if not users:
        return [f"{rel} declares no USER directive"]
    froms = list(_FROM_RX.finditer(text))
    last_from = froms[-1].start() if froms else -1
    final = [m for m in users if m.start() > last_from]
    if final:
        return [f"{rel} final stage runs as USER {final[-1].group('user')} "
                f"(last USER directive after the last FROM)"]
    earlier = ", ".join(dict.fromkeys(m.group("user") for m in users))
    return [f"{rel} declares no USER directive after its last FROM "
            f"(earlier build stage(s) declare: {earlier})"]


def exposure_facts(ctx: ContextPackage, findings: list[Finding], *,
                   user_facts: bool = False) -> list[str]:
    """How this app is reachable — binds, published ports, bind rewrites, and with ``user_facts`` each Dockerfile's USER."""
    root = Path(ctx.repo_root)
    facts: list[str] = []
    # Finding files too (a launcher's bind is in source); _BIND_RX's context, not the name, gates it
    names = ["Dockerfile", "docker-compose.yml", "docker-compose.yaml",
             "compose.yml", "Makefile"]
    names += sorted({f.file for f in findings})[:60]
    for rel in dict.fromkeys(names):
        try:
            target = (root / rel).resolve()
            target.relative_to(root.resolve())
            if not target.is_file():          # a FIFO would block the read
                continue
            text = target.read_text(encoding="utf-8", errors="replace")
        except (OSError, ValueError, RuntimeError):
            continue
        if user_facts and _is_dockerfile_name(Path(rel).name):
            facts += _user_directive_facts(rel, text)
        for m in _BIND_RX.finditer(text):
            host = m.group("host") or m.group("tuple") or m.group("const")
            if host:
                if not _real_host(host):
                    continue
                loop = _net.is_loopback_host(host)
                facts.append(
                    f"{rel} binds {host}"
                    + (" (LOOPBACK — not remotely reachable as written)"
                       if loop else " (all interfaces — remotely reachable)"))
            elif m.group("port"):
                # Only compose maps ports; the same "- 80:80" elsewhere is a prose bullet
                if "compose" in Path(rel).name.lower():
                    facts.append(
                        f"{rel} publishes port {m.group('port')} to the host")
            elif m.group("to"):
                if _real_host(m.group("from")) and _real_host(m.group("to")):
                    facts.append(f"{rel} rewrites the bind "
                                 f"{m.group('from')} -> {m.group('to')}")
    return list(dict.fromkeys(facts))[:12]



