# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 8 — rank verified findings by chaining opportunity and name the chains."""
from __future__ import annotations

from vvaharness.pipeline.stages.s8.outcomes import (
    CVSS_BAND_TO_SEV,
    ChainEntry,
    ChainReport,
    RankedEntry,
    coerce_sev,
    deterministic_report,
    final_severity,
    finding_ids,
    hydrate_report,
    offensive_rank,
    parse_chain_reply,
    ranked_finding,
    sev_from_band,
    severity_prose_mismatch,
    severity_sort_order,
    templated_summary,
)
from vvaharness.pipeline.stages.s8.prompts import (
    SYSTEM,
    build_prompt,
    reachability_for_finding,
)
from vvaharness.pipeline.stages.s8.session import (
    MIN_RESPONSE_CHARS,
    MIN_RESPONSE_TOKENS,
    TAG,
    chain_call,
)

__all__ = [
    "CVSS_BAND_TO_SEV", "MIN_RESPONSE_CHARS", "MIN_RESPONSE_TOKENS", "SYSTEM", "TAG",
    "ChainEntry", "ChainReport", "RankedEntry", "build_prompt", "chain_call",
    "coerce_sev", "deterministic_report", "final_severity", "finding_ids",
    "hydrate_report", "offensive_rank",
    "parse_chain_reply", "ranked_finding", "reachability_for_finding",
    "sev_from_band", "severity_prose_mismatch", "severity_sort_order",
    "templated_summary",
]
