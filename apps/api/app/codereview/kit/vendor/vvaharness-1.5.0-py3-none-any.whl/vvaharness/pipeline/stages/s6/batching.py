# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Group findings into verification sessions, packing each to its full size."""
from __future__ import annotations

from vvaharness.backends.llm.models import (
    ClockKind,
    TIMEOUT_STOP_GRACE_SECONDS,
    effort_scaled_seconds,
)
from vvaharness.models import Finding

Item = tuple[str, Finding]


def label(findings: list[Finding]) -> list[Item]:
    """Pair each finding with the short id the model echoes back in its outcome."""
    return [(f"f{i}", f) for i, f in enumerate(findings)]


def plan_batches(items: list[Item], size: int) -> list[list[Item]]:
    """Pack *size* findings per session, sorted by file so co-located ones share a read."""
    if size <= 1:
        return [[item] for item in items]
    packed = sorted(items, key=lambda it: it[1].file)
    return [packed[i:i + size] for i in range(0, len(packed), size)]


def ceiling_secs(s6) -> int:
    """Return `step6_verify.batch_wall_clock_ceiling` in seconds, <= 0 meaning disabled."""
    # One reader so pool and dispatch agree on <=0 -> off; NOT _cap_int, which maps -1 to 900s
    try:
        return max(0, int(getattr(s6, "batch_wall_clock_ceiling", 900)))
    except (TypeError, ValueError, OverflowError):
        return 900


def sweep_effort(s6, *, via: str | None, cli_effort: str | None) -> str | None:
    """The tier `sweep_ceiling_secs` scales by: `step6_verify.effort`, else cli's global tier on via:cli."""
    return getattr(s6, "effort", None) or (cli_effort if via == "cli" else None)


def sweep_ceiling_secs(s6, *, via: str | None, cli_effort: str | None) -> int:
    """Pool-sweep ceiling: sweep >= any backend clock armed for the same batch."""
    raw = ceiling_secs(s6)
    if raw == 0:
        return 0
    scaled = effort_scaled_seconds(
        raw, sweep_effort(s6, via=via, cli_effort=cli_effort), kind=ClockKind.SESSION)
    return scaled + TIMEOUT_STOP_GRACE_SECONDS


def filed_lines(items: list[Item]) -> dict[str, set[int]]:
    """Every line already filed per file, stage-wide; batch-local double-counts s4's siblings."""
    by_file: dict[str, set[int]] = {}
    for _, f in items:
        by_file.setdefault(f.file, set()).add(f.line_start)
    return by_file
