# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""s5's zero-LLM detector pass — the pipeline consumer of the shared detect/ engine."""
from __future__ import annotations

from pathlib import PurePosixPath

from vvaharness.detect.matcher import Hit, compile_detectors, detector_hits
from vvaharness.detect.patterns import detector_corpus
from vvaharness.lang.detect import EXT_TO_LANG
from vvaharness.models import ContextPackage, Finding, VulnClass
from vvaharness.pipeline.stages.s5.enrich import FileCache
from vvaharness.pipeline.stages.s5.rules import EXCLUDE_PATH_RE
from vvaharness.rules.cwe import weakness_key
from vvaharness.util.counters import COUNTERS

# The only languages the shipped rule corpus is written for; extensions resolve via EXT_TO_LANG.
_DETECTOR_LANGS: frozenset[str] = frozenset(
    {"python", "javascript", "typescript", "web-template"}
)


def _file_lang(rel: str) -> str | None:
    return EXT_TO_LANG.get(PurePosixPath(rel).suffix.lower())


def _in_scope(rel: str, lang: str | None) -> bool:
    """Detector file scope: known language, not test/mock noise, not minified."""
    if lang not in _DETECTOR_LANGS:
        return False
    name = PurePosixPath(rel).name.lower()
    return not (EXCLUDE_PATH_RE.search(rel) or ".min." in name)


def _mint(hit: Hit) -> Finding:
    """Returns a Finding for one detector hit, with the rule id in ``chunk_id``."""
    spec = hit.spec
    xss = spec.cwe == "CWE-79"
    return Finding(
        title=spec.title or spec.rule_id,
        file=hit.file,
        line_start=hit.line,
        line_end=hit.line_end,
        vuln_class=VulnClass.INJECTION if xss else VulnClass.OTHER,
        vuln_class_label="" if xss else spec.kind,
        cwe=spec.cwe,
        origin="detector",
        chunk_id=spec.rule_id,
        description=(f"Deterministic detector match ({spec.rule_id}). "
                     f"{spec.citation} Matched: {hit.snippet}"),
        # code_snippet stays empty: enrich only backfills rows whose snippet is empty.
    )


# Rules describing the same defect; only within a family does span containment mean one call site.
_SPAN_FAMILY = {
    "detector-httpresponse-concat": "html-concat",
    "detector-html-string-concat": "html-concat",
}


def _dedup(rows: list[Finding], kept: list[Finding], tol: int) -> list[Finding]:
    """Self-dedup per rule, then suppress rows at an already-kept finding (same file+weakness)."""
    kept_lines: dict[tuple[str, str], list[int]] = {}
    for f in kept:
        key = weakness_key(f.cwe)
        if key:
            kept_lines.setdefault((f.file, key), []).append(int(f.line_start))
    out: list[Finding] = []
    # Proximity dedup must stay per rule: on (file, cwe) alone it collapses unrelated defects.
    by_rule: dict[tuple[str, str, str], list[int]] = {}
    # Overlap dedup crosses rules only within a _SPAN_FAMILY; the first in corpus order wins.
    by_span: dict[tuple[str, str, str], list[tuple[int, int]]] = {}
    for row in rows:
        line = int(row.line_start)
        end = max(line, int(row.line_end or line))
        rule_key = (row.file, row.cwe or "", row.chunk_id)
        span_key = (row.file, row.cwe or "",
                    _SPAN_FAMILY.get(row.chunk_id, row.chunk_id))
        # Keyed on (file, weakness): one defect s4 filed, whichever rule or sibling id re-found it
        site_key = (row.file, weakness_key(row.cwe) or "")
        if (any(abs(line - n) <= tol for n in by_rule.get(rule_key, []))
                or any(s <= end and line <= e for s, e in by_span.get(span_key, []))
                or any(abs(line - n) <= tol or line <= n <= end
                       for n in kept_lines.get(site_key, []))):
            COUNTERS.bump("s5_det_dup_suppressed")
            continue
        by_rule.setdefault(rule_key, []).append(line)
        by_span.setdefault(span_key, []).append((line, end))
        out.append(row)
    return out


def _cap(survivors: list[Finding], compiled, max_rows: int) -> list[Finding]:
    """At most *max_rows* rows, keeping the highest-priority ones in stable order."""
    if max_rows <= 0 or len(survivors) <= max_rows:
        return survivors
    priority = {d.spec.rule_id: i for i, d in enumerate(compiled)}
    ranked = sorted(range(len(survivors)),
                    key=lambda i: (priority.get(survivors[i].chunk_id,
                                                len(priority)), i))
    keep_idx = frozenset(ranked[:max_rows])
    COUNTERS.bump("s5_det_overflow_suppressed", len(survivors) - max_rows)
    return [row for i, row in enumerate(survivors) if i in keep_idx]


def run(kept: list[Finding], ctx: ContextPackage, cache: FileCache,
        line_tol: int, max_rows: int = 200) -> list[Finding]:
    """Every surviving detector finding for this repo, in deterministic order."""
    compiled = compile_detectors(detector_corpus())
    if not compiled:
        return []
    by_lang = {lang: [d for d in compiled if lang in d.spec.languages]
               for lang in _DETECTOR_LANGS}
    rows: list[Finding] = []
    for rel in sorted(set(ctx.all_files)):
        lang = _file_lang(rel)
        if not _in_scope(rel, lang):
            continue
        live = by_lang.get(lang or "")
        if not live:
            continue
        lines = cache.lines(rel)
        if lines is None:
            continue
        for hit in detector_hits(rel, lines, live):
            rows.append(_mint(hit))
    survivors = _cap(_dedup(rows, kept, line_tol), compiled, max_rows)
    for row in survivors:
        COUNTERS.bump("s5_det_emitted")
        rule = row.chunk_id.removeprefix("detector-").replace("-", "_")
        COUNTERS.bump(f"s5_det_rule_{rule}")
    return survivors
