# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""One compiled pattern a detector treats as a source, sink, or detector rule."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class MatchSpec:
    """One compiled pattern plus the role/CWE it implies when matched."""

    rule_id: str
    role: str  # "source" | "sink" | "detector"
    pattern: str  # regex, matched against one line of source text
    cwe: str
    kind: str
    semantic_family: str = ""
    owasp_top10_2025: frozenset[str] = field(default_factory=frozenset)

    # ── detector-rule fields (role == "detector"); line specs ignore these ──
    enabled: bool = True          # per-rule kill switch, part of the rule DATA
    languages: frozenset[str] = field(default_factory=frozenset)  # EXT_TO_LANG keys
    title: str = ""               # finding title minted for a hit
    citation: str = ""            # one-line public CWE/OWASP citation for the rule
    # Gate scope: "line" | "call" (balanced paren, <= span_max_lines) | "block" (to span_end)
    span: str = "line"
    span_end: str = ""            # regex closing a "block" span (e.g. "</form")
    span_max_lines: int = 1
    present_re: str = ""          # fire only when the span DOES match this
    absent_re: str = ""           # fire only when the span does NOT match this
    # Extra lines the absent_re guard ALSO sees (a wrapping `escape(`); negative gate only
    absent_window: int = 0
    file_re: str = ""             # file-scope gate: the whole file must match somewhere
    near_re: str = ""             # proximity gate: must match within near_window lines
    near_window: int = 0
