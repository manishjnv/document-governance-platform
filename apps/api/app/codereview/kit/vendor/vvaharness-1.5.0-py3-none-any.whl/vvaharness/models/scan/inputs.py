# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Externally injected contracts: CVEs, design controls, the app profile."""
from __future__ import annotations

import logging
from typing import Literal

from pydantic import BaseModel, field_validator

from vvaharness.models.scan._coerce import _coerce_enum

log = logging.getLogger(__name__)



# Injected context (loaded once, threaded through every step)

class CVE(BaseModel):
    id: str                          # CVE-2024-1234
    summary: str
    affected_files: list[str] = []   # if known
    cvss: float | None = None
    patched: bool = False


_CONTROL_KINDS = {"auth", "sandbox", "input-validation", "aslr", "cfi", "other"}
_CONTROL_KIND_ALIAS = {
    "authn": "auth", "authentication": "auth", "authz": "auth",
    "authorization": "auth", "rbac": "auth", "iam": "auth", "sso": "auth",
    "waf": "input-validation", "validation": "input-validation",
    "input_validation": "input-validation", "sanitization": "input-validation",
    "sanitisation": "input-validation", "encoding": "input-validation",
    "seccomp": "sandbox", "container": "sandbox", "isolation": "sandbox",
    "chroot": "sandbox", "jail": "sandbox",
}


class Control(BaseModel):
    """Design-level mitigation the strategist/chain LLM uses to downrank exploitability."""
    name: str                        # "auth-gateway", "wasm-sandbox"
    kind: Literal["auth", "sandbox", "input-validation", "aslr", "cfi", "other"]
    protects: list[str] = []         # file globs or module names behind this control
    notes: str = ""

    @field_validator("kind", mode="before")
    @classmethod
    def _v_kind(cls, v):
        return _coerce_enum(v, _CONTROL_KINDS, _CONTROL_KIND_ALIAS, "other")


class AppProfile(BaseModel):
    """CMDB deployment context shared by s1/s2/s6 so actor choice and CVSS scoring agree."""
    application_id: str
    name: str = ""
    externally_facing: bool = False
    pci_scoped: bool = False
    processes_pan: bool = False
    pii: bool = False
    source: str = ""                 # "application" | "component->parent NNN" | …

    def to_prompt_block(self) -> str:
        sens = []
        if self.pci_scoped:   sens.append("PCI-scoped")
        if self.processes_pan: sens.append("processes PAN")
        if self.pii:          sens.append("handles PII")
        return (
            "CMDB APPLICATION PROFILE:\n"
            f"  - Application ID: {self.application_id}\n"
            f"  - Name: {self.name or '(unnamed)'}\n"
            f"  - Externally facing: {'YES' if self.externally_facing else 'NO'}\n"
            f"  - Data sensitivity: {', '.join(sens) or 'standard'}\n"
            f"  - Source: {self.source}\n"
        )


