# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""One-shot stderr warnings: print a message at most once per key."""
# Each caller owns its `seen` set; `_REGISTRY_SITES` below is the authoritative list

from __future__ import annotations

import sys
import threading

from vvaharness.util import console

__all__ = ["reset_warn_once_registries", "stage_label", "warn_once"]

#: One lock for every *seen* set: callers are plain module-level sets, not thread-local,
#: and several registry sites are now reachable from a ThreadPoolExecutor pool (S4/S6).
_LOCK = threading.Lock()


def warn_once(seen: set[str], key: str, message: str) -> None:
    """Print *message* to stderr the first time *key* appears in *seen*."""
    # Never raises: a diagnostic must not abort a scan.
    with _LOCK:
        if key in seen:
            return
        seen.add(key)
    console.write(message)


def stage_label(counter: str) -> str:
    """The ``[sN]`` stage tag carried by *counter*'s own name, or a generic ``[stage]``."""
    # One leaf for every `s{N}_...` counter name: tool_budget's and evidence_gate's WARN lines
    # key off the counter that already names stage and family, so no caller passes its own tag.
    prefix = counter.split("_", 1)[0]
    return f"[{prefix}]" if prefix[:1] == "s" and prefix[1:].isdigit() else "[stage]"


# sys.modules lookup, NOT an import: importing backends.llm.deepagents would drag langchain in
_REGISTRY_SITES: tuple[tuple[str, str], ...] = (
    ("vvaharness.backends.llm.deepagents", "_NO_USAGE_WARNED_TAGS"),
    ("vvaharness.backends.llm.deepagents", "_WARNED_LEGACY_KW"),
    ("vvaharness.backends.llm.sdk", "_CACHE_ROUTE_NOTED"),
    ("vvaharness.backends.harness.deepagents.tools", "_WARNED_UNKNOWN_TOOLS"),
    ("vvaharness.backends.harness.deepagents.usage", "_EXCLUSIVE_USAGE_WARNED"),
    ("vvaharness.backends.harness.deepagents.client", "_EFFORT_UNSUPPORTED_WARNED"),
    ("vvaharness.backends.harness.deepagents.client", "_TRANSPORT_FALLBACK_WARNED"),
    ("vvaharness.orchestrator.store", "_PERM_WARNED"),
    ("vvaharness.backends.llm.openai", "_WARNED_DROPS"),
    ("vvaharness.backends.llm.sdk", "_WARNED_DROPS"),
    ("vvaharness.backends.llm.tool_adapter", "_WARNED"),
    ("vvaharness.backends.llm.cli_mcp", "_WARNED"),
    ("vvaharness.backends.llm.deepagents", "_WARNED_DROPPED_KNOBS"),
    ("vvaharness.backends.llm.registry", "_WARNED_CLI_DROPPED"),
    ("vvaharness.backends.llm.cli", "_WARNED_CAPS"),
    ("vvaharness.pipeline.stages.s2.session", "_WARNED_NO_GRAPH_TOOLS"),
    ("vvaharness.pipeline.stages.s2.session", "_WARNED_DEGENERATE_GRAPH"),
    ("vvaharness.pipeline.stages.s4.session", "_WARNED_DEGENERATE_GRAPH"),
    ("vvaharness.pipeline.stages.s6.session", "_WARNED_NO_GRAPH"),
    ("vvaharness.pipeline.stages.s6.session", "_WARNED_DEGENERATE_GRAPH"),
    (
        "vvaharness.backends.harness.deepagents.options.model_building",
        "_INFERRED_VENDOR_WARNED",
    ),
    ("vvaharness.remediation_agent.plugin_runner", "_WARNED_CLI_REDACTION"),
    ("vvaharness.pipeline.stages.s4_deepdive", "_WARNED_REDACTED_SOURCE"),
    ("vvaharness.pipeline.stages.s6_verify", "_WARNED_REPLAYED_DISCOVERIES"),
    ("vvaharness.validation.config.validate_role", "_WARNED_VIA_REWRITE"),
    ("vvaharness.backends.harness.deepagents.tool_budget", "_WARNED_EXHAUSTED"),
    ("vvaharness.backends.harness.deepagents.evidence_gate", "_WARNED_RELENTED"),
    ("vvaharness.backends.harness.deepagents.options.response_format", "_WARNED_DROPS"),
)


def reset_warn_once_registries() -> None:
    """Clear every warn-once registry in place (set identity preserved)."""
    for mod_name, attr in _REGISTRY_SITES:
        mod = sys.modules.get(mod_name)
        if mod is None:
            continue  # never imported → never warned → nothing to clear
        reg = getattr(mod, attr, None)
        if isinstance(reg, set):
            reg.clear()
