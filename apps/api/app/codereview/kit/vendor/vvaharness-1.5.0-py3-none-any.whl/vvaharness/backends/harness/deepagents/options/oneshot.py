# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""One-shot (single-turn) graph compilation and its public entry point."""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from langgraph.graph.state import CompiledStateGraph

from vvaharness.backends.harness.deepagents.models import (
    ALL_NATIVE_TOOLS,
    SUBAGENT_DISPATCH_TOOL,
    CompiledGraph,
)
from vvaharness.backends.harness.deepagents.options.filesystem import (
    _filesystem_permissions,
    _session_backend,
    _skill_sources,
)
from vvaharness.backends.harness.deepagents.options.graph_builder import _create_agent
from vvaharness.backends.harness.deepagents.options.graph_config import _make_config
from vvaharness.backends.harness.deepagents.options.response_format import (
    _oneshot_response_format,
)
from vvaharness.backends.harness.deepagents.options.subagents import (
    _build_session_tools,
    _tool_policy,
    get_subagent_specs,
)
from vvaharness.backends.harness.deepagents.tools import session_tool_names
from vvaharness.backends.harness.models import (
    LOGICAL_TO_NATIVE,
    OneShotOptions,
    StreamingOptions,
)

if TYPE_CHECKING:
    from langchain_core.tools import BaseTool


def _granted_natives(options: OneShotOptions) -> frozenset[str]:
    """Native tool names the one-shot policy's allowed logicals map to."""
    if options.tool_policy is None:
        return frozenset()
    return frozenset(
        LOGICAL_TO_NATIVE[logical]
        for logical in options.tool_policy.allowed_tools
        if logical in LOGICAL_TO_NATIVE
    )


def _oneshot_excluded_tools(options: OneShotOptions) -> frozenset[str]:
    """Tools withheld from the model's REQUEST on the one-shot (single-turn) path."""
    # TRAP: an empty ToolPolicy still offers natives, and task too; ADVERTISEMENT only (PermitTools)
    task = frozenset({SUBAGENT_DISPATCH_TOOL})
    if options.tool_policy is None:
        return task
    return (ALL_NATIVE_TOOLS - _granted_natives(options)) | task


def _oneshot_permitted_tools(
    options: OneShotOptions, session_tools: list[BaseTool]
) -> frozenset[str]:
    """Tool names the one-shot EXECUTOR may run; everything else is refused."""
    # Fed to PermitTools (fail closed); task is NEVER permitted here, even under a None policy
    custom = session_tool_names(session_tools)
    if options.tool_policy is None:
        return ALL_NATIVE_TOOLS | custom
    return _granted_natives(options) | custom


def _build_oneshot_graph(options: OneShotOptions) -> CompiledStateGraph:
    """Compile a single-turn parser graph."""
    streaming_view = cast(StreamingOptions, options)
    policy = _tool_policy(options)
    tools = _build_session_tools(streaming_view, tuple(policy.allowed_tools))
    # Our gated general-purpose spec displaces deepagents' ungated, UNREDACTED builtin
    subagents = get_subagent_specs(streaming_view, agents={})
    return _create_agent(
        model_id=options.model,
        env=options.env,
        think_in_prompt=options.think_in_prompt,
        system_prompt=options.system_prompt,
        tools=tools,
        name=f"{options.graph_name}-oneshot",
        # `or None`: an empty list must be OMITTED or SkillsMiddleware adds ~1.9k chars per call
        skills=_skill_sources(options.skill_root, options.cwd) or None,
        permissions=_filesystem_permissions(options),
        model_provider=options.model_provider,
        redact_reads=not options.allow_writes,
        backend=_session_backend(options),
        response_model=options.response_model,
        response_format=_oneshot_response_format(options),
        subagents=subagents,
        extra_excluded_tools=_oneshot_excluded_tools(options),
        # None inherits today's ceiling (64k Anthropic / uncapped OpenAI).
        max_output_tokens=options.max_output_tokens,
        output_cap=options.output_cap,
        # Executor-seam gate: fail closed, since un-advertising alone cannot stop a forged call
        permitted_tool_calls=_oneshot_permitted_tools(options, tools),
        cache_markers=options.cache_markers,
        # Single-call requests: a tail write is never read back (+5.0M dead S4 writes).
        cache_tail=False,
        # Suffix is dead weight on a single turn: measured +23.5% output, ~530 uncached in per call
        strip_harness_suffix=True,
        effort=options.effort,
        use_responses_api=options.use_responses_api,
        parent_middleware=options.parent_middleware,
    )


def build_oneshot_options(options: OneShotOptions) -> CompiledGraph:
    """Return a compiled parser graph and invoke config for a single-turn run."""
    graph = _build_oneshot_graph(options)
    return CompiledGraph(graph=graph, config=_make_config(options, buffer=5))
