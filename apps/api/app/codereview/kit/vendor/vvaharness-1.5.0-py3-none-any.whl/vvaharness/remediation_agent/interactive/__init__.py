# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Arrow-key issue picker for ``vvaharness remediate -i``, with a numbered-prompt fallback off a TTY."""
from __future__ import annotations

from vvaharness.remediation_agent.interactive.keys import (
    DOWN,
    ENTER,
    OTHER,
    QUIT,
    UP,
    decode_key,
)
from vvaharness.remediation_agent.interactive.loop import run_interactive
from vvaharness.remediation_agent.interactive.render import (
    parse_selection,
    render_rows,
)

__all__ = [
    "DOWN",
    "ENTER",
    "OTHER",
    "QUIT",
    "UP",
    "decode_key",
    "parse_selection",
    "render_rows",
    "run_interactive",
]
