# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The threat model s2 produces: assets, boundaries, threats."""
from __future__ import annotations

import logging
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

from vvaharness.models.scan._coerce import _coerce_enum, _coerce_str_list

log = logging.getLogger(__name__)

_SENSITIVITY = {"low", "medium", "high", "critical"}
_SENSITIVITY_ALIAS = {
    "none": "low", "info": "low", "informational": "low", "minor": "low",
    "moderate": "medium", "med": "medium", "normal": "medium",
    "major": "high", "severe": "high", "important": "high",
    "crit": "critical", "blocker": "critical", "extreme": "critical",
}


class Asset(BaseModel):
    name: str
    description: str = ""
    sensitivity: Literal["low", "medium", "high", "critical"] = "medium"

    @field_validator("sensitivity", mode="before")
    @classmethod
    def _v_sensitivity(cls, v):
        return _coerce_enum(v, _SENSITIVITY, _SENSITIVITY_ALIAS, "medium")


class TrustBoundary(BaseModel):
    entry_point: str
    crossing: str                    # e.g. "unauth network → application logic"
    reachable_assets: list[str] = []


_ACTORS = {"remote_unauth", "remote_auth", "adjacent_network",
           "local_user", "local_admin", "supply_chain", "insider"}
_ACTOR_ALIAS = {
    "external": "remote_unauth", "anonymous": "remote_unauth",
    "unauthenticated": "remote_unauth", "internet": "remote_unauth",
    "public": "remote_unauth", "attacker": "remote_unauth",
    "authenticated": "remote_auth", "user": "remote_auth",
    "tenant": "remote_auth", "customer": "remote_auth",
    "internal": "adjacent_network", "network": "adjacent_network",
    "lan": "adjacent_network", "adjacent": "adjacent_network",
    "local": "local_user", "physical": "local_user",
    "admin": "local_admin", "root": "local_admin",
    "operator": "local_admin", "privileged": "local_admin",
    "supply": "supply_chain", "dependency": "supply_chain",
    "third_party": "supply_chain", "vendor": "supply_chain",
    "employee": "insider", "developer": "insider", "malicious_insider": "insider",
}
_IMPACTS = {"low", "medium", "high", "critical", "existential"}
_IMPACT_ALIAS = {**_SENSITIVITY_ALIAS,
                 "catastrophic": "existential", "fatal": "existential"}
_LIKELIHOODS = {"very_rare", "rare", "possible", "likely", "almost_certain"}
_LIKELIHOOD_ALIAS = {
    "very_unlikely": "very_rare", "negligible": "very_rare",
    "remote": "very_rare", "improbable": "very_rare",
    "unlikely": "rare", "low": "rare",
    "moderate": "possible", "medium": "possible", "occasional": "possible",
    "probable": "likely", "high": "likely", "frequent": "likely",
    "very_likely": "almost_certain", "certain": "almost_certain",
    "definite": "almost_certain", "inevitable": "almost_certain",
}


class Threat(BaseModel):
    # Assigned from list position after the model replies: a minted id is checkable against nothing
    id: str = ""
    threat: str
    actor: Literal["remote_unauth", "remote_auth", "adjacent_network",
                   "local_user", "local_admin", "supply_chain", "insider"]
    surface: str                     # entry_point name from trust_boundaries
    surface_files: list[str] = Field(
        description=(
            "Every repo-relative file path (from the FILE INVENTORY / entry "
            "points / modules lists you were given) that implements or is "
            "reachable from this threat's surface. Required whenever the "
            "surface names concrete code, not just a general property of "
            "the system — this is how the threat reaches the files it "
            "affects; an empty list means no downstream stage can act on it."
        ),
    )
    asset: str
    impact: Literal["low", "medium", "high", "critical", "existential"]
    likelihood: Literal["very_rare", "rare", "possible", "likely", "almost_certain"]
    controls: str = ""
    evidence: str = ""

    @field_validator("actor", mode="before")
    @classmethod
    def _v_actor(cls, v):
        return _coerce_enum(v, _ACTORS, _ACTOR_ALIAS, "remote_auth")

    @field_validator("impact", mode="before")
    @classmethod
    def _v_impact(cls, v):
        return _coerce_enum(v, _IMPACTS, _IMPACT_ALIAS, "medium")

    @field_validator("likelihood", mode="before")
    @classmethod
    def _v_likelihood(cls, v):
        return _coerce_enum(v, _LIKELIHOODS, _LIKELIHOOD_ALIAS, "possible")

    @field_validator("surface_files", mode="before")
    @classmethod
    def _v_surface_files(cls, v: Any) -> Any:
        return _coerce_str_list(v, "Threat.surface_files")


class ThreatModel(BaseModel):
    system_context: str = ""
    assets: list[Asset] = []
    trust_boundaries: list[TrustBoundary] = []
    threats: list[Threat] = []
    open_questions: list[str] = []

    def threat_ids(self) -> list[str]:
        """Each threat's id, positional `T<n>` when blank: the key s3 mints units under."""
        return [t.id or f"T{i}" for i, t in enumerate(self.threats, 1)]

    def to_prompt_block(self) -> str:
        lines = ["THREAT MODEL:", "", "System context:", self.system_context, ""]
        if self.assets:
            lines.append(f"Assets ({len(self.assets)}):")
            for a in self.assets:
                lines.append(f"  - [{a.sensitivity}] {a.name} — {a.description}")
            lines.append("")
        if self.trust_boundaries:
            lines.append(f"Trust boundaries ({len(self.trust_boundaries)}):")
            for b in self.trust_boundaries:
                ra = ", ".join(b.reachable_assets) or "-"
                lines.append(f"  - {b.entry_point}: {b.crossing} → assets: {ra}")
            lines.append("")
        if self.threats:
            lines.append(f"Ranked threats ({len(self.threats)}):")
            for t in self.threats:
                lines.append(
                    f"  - {t.id} [{t.impact}/{t.likelihood}] {t.threat} "
                    f"(actor={t.actor}, surface={t.surface}, asset={t.asset}"
                    + (f", controls: {t.controls}" if t.controls and t.controls != "none" else "")
                    + ")"
                )
            lines.append("")
        return "\n".join(lines)

    def to_compact_prompt_block(self, *, max_assets: int = 8,
                                max_boundaries: int = 12,
                                max_threats: int = 12,
                                max_context_chars: int = 2500) -> str:
        lines = [
            "THREAT MODEL:",
            "",
            "System context:",
            self.system_context[:max_context_chars],
            "",
        ]
        if self.assets:
            assets = self.assets[:max_assets]
            lines.append(f"Assets ({len(assets)}/{len(self.assets)}):")
            for a in assets:
                lines.append(f"  - [{a.sensitivity}] {a.name} — {a.description}")
            if len(self.assets) > len(assets):
                lines.append("  …(truncated)")
            lines.append("")
        if self.trust_boundaries:
            bounds = self.trust_boundaries[:max_boundaries]
            lines.append(f"Trust boundaries ({len(bounds)}/{len(self.trust_boundaries)}):")
            for b in bounds:
                ra = ", ".join(b.reachable_assets) or "-"
                lines.append(f"  - {b.entry_point}: {b.crossing} → assets: {ra}")
            if len(self.trust_boundaries) > len(bounds):
                lines.append("  …(truncated)")
            lines.append("")
        if self.threats:
            threats = self.threats[:max_threats]
            lines.append(f"Ranked threats ({len(threats)}/{len(self.threats)}):")
            for t in threats:
                lines.append(
                    f"  - {t.id} [{t.impact}/{t.likelihood}] {t.threat} "
                    f"(actor={t.actor}, surface={t.surface}, asset={t.asset}"
                    + (f", controls: {t.controls}" if t.controls and t.controls != "none" else "")
                    + ")"
                )
            if len(self.threats) > len(threats):
                lines.append("  …(truncated)")
            lines.append("")
        return "\n".join(lines)


_IMPACT_RANK = {"existential": 5, "critical": 4, "high": 3, "medium": 2, "low": 1}
_LIKELIHOOD_RANK = {"almost_certain": 5, "likely": 4, "possible": 3, "rare": 2, "very_rare": 1}
_SENSITIVITY_RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1}
_ACTOR_RANK = {"remote_unauth": 6, "remote_auth": 5, "adjacent_network": 4,
              "local_admin": 3, "local_user": 2, "supply_chain": 1, "insider": 1}


def _sensitivity_of(t: Threat, tm: ThreatModel) -> int:
    key = t.asset.strip().lower()
    a = next((x for x in tm.assets if x.name.strip().lower() == key), None)
    return _SENSITIVITY_RANK.get(a.sensitivity, 0) if a else 0


def _rank_key(t: Threat, tm: ThreatModel) -> tuple:
    """Sort key giving a deterministic total order over threats, most severe first."""
    # No evidence-non-empty term: baseline threats carry evidence too, so it would boost them
    return (-_IMPACT_RANK.get(t.impact, 0),
            -_sensitivity_of(t, tm),
            -_LIKELIHOOD_RANK.get(t.likelihood, 0),
            -_ACTOR_RANK.get(t.actor, 0),
            0 if (not t.controls or t.controls == "none") else 1,
            _id_ordinal(t.id),
            t.id)


def _id_ordinal(threat_id: str) -> int:
    """Numeric part of an id like `T7`, or a large sentinel if it does not parse."""
    # Guarded, not isdigit(): that is true for superscripts int() rejects
    try:
        return int(threat_id[1:])
    except (TypeError, ValueError):
        return 1_000_000


def _covered_boundaries(threats: list[Threat], pool: set[int],
                        boundaries: list[TrustBoundary]) -> set[str]:
    """Entry-point names covered by a threat at one of the positions in `pool`."""
    # Positions, not ids: models reuse one id across threats, which an id-keyed pool collapses
    covered: set[str] = set()
    for b in boundaries:
        bnorm = b.entry_point.strip().casefold()
        for i in pool:
            if threats[i].surface.strip().casefold() == bnorm:
                covered.add(b.entry_point)
                break
    return covered


def _next_covering_candidate(threats: list[Threat], kept: set[int],
                             evicted_idx: list[int], boundary: str) -> int | None:
    bnorm = boundary.strip().casefold()
    return next(
        (i for i in evicted_idx
         if i not in kept and threats[i].surface.strip().casefold() == bnorm),
        None,
    )


def _best_evictable(threats: list[Threat], kept: set[int], kept_order: list[int],
                    boundaries: list[TrustBoundary]) -> int | None:
    """Worst-ranked survivor evictable without a net coverage drop, else None."""
    current_coverage = _covered_boundaries(threats, kept, boundaries)
    for i in reversed(kept_order):  # worst-ranked survivor first
        trial_coverage = _covered_boundaries(threats, kept - {i}, boundaries)
        if len(trial_coverage) >= len(current_coverage):
            return i
    return None


def _promote_for_coverage(threats: list[Threat], kept: set[int],
                          evicted_idx: list[int],
                          boundaries: list[TrustBoundary]) -> tuple[set[int], int]:
    """Restore coverage lost to truncation, returning the mutated `kept` and a count."""
    all_boundary_names = {b.entry_point for b in boundaries}
    uncovered = all_boundary_names - _covered_boundaries(threats, kept, boundaries)
    kept_order = sorted(kept)  # rank order; worst-ranked is last
    promoted = 0
    progressed = True
    while uncovered and progressed:
        progressed = False
        for boundary in list(uncovered):
            candidate = _next_covering_candidate(threats, kept, evicted_idx, boundary)
            if candidate is None:
                continue
            evict_at = _best_evictable(threats, kept, kept_order, boundaries)
            if evict_at is None:
                continue
            kept.discard(evict_at)
            kept_order.remove(evict_at)
            kept.add(candidate)
            kept_order.append(candidate)
            promoted += 1
            uncovered.discard(boundary)
            progressed = True
    return kept, promoted


def _cap_threats(tm: ThreatModel, max_threats: int) -> ThreatModel:
    """Truncate to `max_threats`, preserving every trust boundary's coverage."""
    from vvaharness.util.counters import COUNTERS  # keeps vvaharness.models a leaf

    # Sorting permutes only, `id` is never rewritten; no dedup (a similarity pass lost coverage)
    threats = sorted(tm.threats, key=lambda t: _rank_key(t, tm))
    COUNTERS.bump("s2_threats_raw", len(threats))
    if len(threats) <= max_threats:
        return tm.model_copy(update={"threats": threats})

    # Addressed by POSITION, never `id`: repeated ids would cut a cap of twenty down to one
    kept: set[int] = set(range(min(max_threats, len(threats))))
    evicted_idx = list(range(len(kept), len(threats)))  # rank-ordered, best first
    truncated_n = len(evicted_idx)

    kept, promoted = _promote_for_coverage(threats, kept, evicted_idx, tm.trust_boundaries)

    COUNTERS.bump("s2_threats_truncated", truncated_n)
    COUNTERS.bump("s2_threats_promoted", promoted)
    # Read off `kept`, never `evicted_idx`: promotion swaps, so that list is stale by now
    evicted = [threats[i].id or f"T{i + 1}" for i in range(len(threats)) if i not in kept]
    if evicted:
        COUNTERS.note("s2_threats_evicted_ids", ",".join(evicted))
    final = [threats[i] for i in sorted(kept)]  # already rank-ordered
    return tm.model_copy(update={"threats": final})


def _cap_assets(tm: ThreatModel, max_assets: int) -> ThreatModel:
    if len(tm.assets) <= max_assets:
        return tm
    ranked = sorted(tm.assets,
                    key=lambda a: (-_SENSITIVITY_RANK.get(a.sensitivity, 0), a.name))
    return tm.model_copy(update={"assets": ranked[:max_assets]})


def _cap_boundaries(tm: ThreatModel, max_boundaries: int) -> ThreatModel:
    if len(tm.trust_boundaries) <= max_boundaries:
        return tm
    ranked = sorted(tm.trust_boundaries,
                    key=lambda b: (-len(b.reachable_assets), b.entry_point))
    return tm.model_copy(update={"trust_boundaries": ranked[:max_boundaries]})
