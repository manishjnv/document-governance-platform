# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from __future__ import annotations
from vvaharness.util import logs

"""orchestrator.entry — see package docstring."""
import argparse
import os
import sys
import traceback
from pathlib import Path

from vvaharness import config as config_mod
from vvaharness.backends.harness.models import AuthenticationError, ProxyError
from vvaharness.backends.llm.registry import resolve as resolve_model
from vvaharness.exploit_verification.errors import EVInputError, EVUnreachableError
from vvaharness.exploit_verification.options import (
    collection_path as ev_collection_path,
)
from vvaharness.exploit_verification.options import load_options as ev_load_options
from vvaharness.exploit_verification.options import may_run as ev_may_run
from vvaharness.exploit_verification.options import (
    resolution_error as ev_resolution_error,
)
from vvaharness.orchestrator.batch import run_batch
from vvaharness.orchestrator.cmdb import _cmdb_path, _set_cmdb_path
from vvaharness.orchestrator.config_paths import (
    EV_MODEL_ROLES,
    _default_config,
    _iter_model_roles,
    trusted_config,
)
from vvaharness.orchestrator.preflight import check_backends, configure_backends
from vvaharness.orchestrator.scan import scan_repo
from vvaharness.orchestrator.store import StoreError
from vvaharness.report.redact import redact
from vvaharness.scope import EmptyScopeError
from vvaharness.util import console
from vvaharness.util import errlog as _errlog
from vvaharness.util.events import Event
from vvaharness.util.pricing import load_pricing_cached

log = logs.get_logger(__name__)

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass


def _top_arg(raw: str):
    """argparse ``type`` for ``--top``: a positive integer cap or the ``all``/``*`` wildcard, reusing the same coercion the standalone ``remediate`` command uses."""
    from vvaharness.remediation_agent.select import _coerce_top_value
    try:
        return _coerce_top_value(raw, source="--top")
    except ValueError as e:
        raise argparse.ArgumentTypeError(str(e))


def _ev_gate(args, cfg) -> tuple[int | None, object]:
    """Run the OFFLINE exploit-verification collection gate."""
    # (exit_code_or_None, collection); no network/model; --resume -> (None, None), scan.py re-checks
    path = ev_collection_path(os.environ)
    if not path:
        if (getattr(args, "stop_after", None) == "ev"
                and not getattr(args, "resume", False)):
            log.error("--stop-after ev requires EV_API_COLLECTION to be set "
                  "(or --resume, to re-probe this run's checkpointed collection)")
            return 2, None
        return None, None
    if config_mod.is_network_path(path):
        log.error(Event.EV_COLLECTION_NOT_LOCAL, path=path)
        return 2, None
    if args.repo_file:
        # One EV_TARGET_URL cannot cover a whole batch, so a batch run verifies nothing instead
        log.warning("exploit verification is single-repo only; ignoring "
              "EV_API_COLLECTION for this batch (--repo-file) run.")
        return None, None
    from vvaharness.exploit_verification import gate as ev_gate
    try:
        result = ev_gate.run_gate(ev_load_options(cfg, os.environ))
    except EVInputError as e:
        console.mark("fail", f"exploit verification: {redact(str(e))}", indent=2)
        return 2, None
    if result.enabled:
        console.write("  [exploit-verification] collection gate:")
        console.write(ev_gate.format_checks(result.checks))
    return None, result.collection


def _resolve_auto_step1(flag: bool, cfg,
                        disable: bool = False) -> tuple[bool, str | None]:
    """Resolve whether AI auto-exclude runs for this scan: ``--no-auto-step1`` wins over ``--auto-step1``, which wins over ``step1.auto_exclude`` in config; returns ``(enabled, source-label)``."""
    if disable:
        return False, "--no-auto-step1"
    if flag:
        return True, "--auto-step1"
    step1 = getattr(cfg, "step1", None)
    if bool(getattr(step1, "auto_exclude", False)):
        return True, "step1.auto_exclude"
    return False, None


def _repo_name(repo: Path, explicit: str | None) -> str:
    """Return a non-empty display name for a single-repository scan."""
    if explicit and explicit.strip():
        return explicit.strip()
    return repo.resolve().name or "repo"


def _pricing_note(cfg) -> str | None:
    """One `[pricing] WARNING` line naming role models with no rate — only when pricing.file is set."""
    file = getattr(getattr(cfg, "pricing", None), "file", None)
    if file is None:
        return None
    table = load_pricing_cached(file)
    if table is None:
        # A failed load already wrote the loader's own [pricing] WARNING
        return None
    role_model_ids = {resolve_model(m)[0] for _, m in _iter_model_roles(cfg)}
    missing = set(role_model_ids) - table.models.keys()
    if not missing:
        return None
    return (f"  [pricing] WARNING: no rates for {', '.join(sorted(missing))} "
            f"in {table.path}; their cost reports as null")


def build_parser() -> argparse.ArgumentParser:
    """The `vvaharness scan` parser, extracted so the SDK inherits every CLI default."""
    ap = argparse.ArgumentParser(prog="vvaharness scan", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--repo", help="path to a single local target codebase")
    src.add_argument("--repo-file",
                     help="batch input: either a .txt with one "
                          "'application_id,repository_name,path' per line, "
                          "or a .csv with header columns AppID,RepoName[,Path] "
                          "(Path derived from batch.git_base_url when absent); "
                          "each entry is cloned/scanned in sequence with a "
                          "fresh context")
    ap.add_argument("--config", default=None,
                    help="config profile path (else the auto-detected "
                         "./config.yaml, or the packaged default)")
    ap.add_argument("--repo-name",
                    help="module / repositoryName tag for report filenames and "
                         "SARIF run.properties (single-repo mode only; "
                         "default: dir name)")
    ap.add_argument("--application-id",
                    help="application/asset ID — drives CMDB AppProfile lookup, "
                         "VulContextSeverity scoring, and SARIF run.properties.applicationId")
    ap.add_argument("--workspace", default="./batch-workspace",
                    help="directory to clone remote repos into (batch mode)")
    ap.add_argument("--keep-clones", action="store_true",
                    help="do not delete cloned repos after scanning (batch mode)")
    ap.add_argument("--group-by-app", action="store_true",
                    help="batch mode: clone every repo sharing an AppID under "
                         "{workspace}/{app_id}/ and run ONE scan over that "
                         "directory (one report per application instead of "
                         "one per repo)")
    ap.add_argument("--resume", action="store_true",
                    help="reuse existing checkpoints for completed steps")
    ap.add_argument("--stop-after",
                    choices=["clone", "ev", "s0", "s1", "s2", "s3", "s4", "s5",
                             "s6", "s7", "s8", "s9", "s10", "s11"],
                    help="stop after the named step (for debugging); "
                         "'clone' stops right after acquiring repos in batch "
                         "mode and implies --keep-clones; 'ev' verifies the "
                         "collection named by EV_API_COLLECTION (parse + "
                         "reachability probe) and stops before S1)")
    ap.add_argument("--s6-progress-file", action="store_true",
                    help="write state/s6_progress/<run_id>/s6_progress.json "
                         "after each S6 verification")
    ap.add_argument("--remediate", action="store_true",
                    help="run step 10 in fix mode: the Remediation Agent can "
                         "apply a fix to selected verified findings and writes "
                         "per-finding artefacts under "
                         "<repo>/security-remediation/ (also enabled via "
                         "step_remediate.enabled in config)")
    ap.add_argument("--top", type=_top_arg, default=None, metavar="N|all",
                    help="when step 10 is enabled: override "
                         "step_remediate.top_n_findings "
                         "for this run — remediate only the N highest-CVSS "
                         "findings (limit & reorder, highest score first), or "
                         "pass 'all' / '*' to remediate every finding. The "
                         "profile's top_n_findings is the default cap.")
    ap.add_argument("--force", action="store_true",
                    help="override safety refusals (currently: the s10 "
                         "git-SHA staleness check)")
    ap.add_argument("--skip-preflight", action="store_true",
                    help="skip the startup credential/backend readiness probe "
                         "(does NOT bypass model/API authentication)")
    ap.add_argument("--step1-config",
                    help="explicit step1 overlay YAML (exclude_dirs/exts/"
                         "globs, max_file_kb, config_dedup). Lists APPEND to "
                         "config.yaml's step1. Mutually exclusive with "
                         "--auto-step1 (this wins). No implicit default.")
    auto_grp = ap.add_mutually_exclusive_group()
    auto_grp.add_argument("--auto-step1", action="store_true",
                    help="after clone, AI-survey each target to derive its "
                         "step1 overlay; writes <state>/checkpoints/<run_id>/"
                         "step1.yaml and applies it before s1. Ignored when "
                         "--step1-config is given. Also enabled via "
                        "step1.auto_exclude in config (enabled by default in "
                        "all shipped profiles); this flag forces it on.")
    auto_grp.add_argument("--no-auto-step1", action="store_true",
                    help="hard-disable AI auto-exclude for this run, "
                         "irrespective of step1.auto_exclude in the "
                        "active profile. Wins over --auto-step1 and "
                         "any config default. (To also disable it persistently, "
                         "set step1.auto_exclude: false in your profile.)")
    return ap


def main(argv: list[str] | None = None) -> int:
    ap = build_parser()
    args = ap.parse_args(argv)

    if not args.repo_file:
        from stat import S_ISDIR

        repo = Path(args.repo)
        try:
            if not S_ISDIR(repo.stat().st_mode):
                log.error(Event.REPO_NOT_A_DIRECTORY, path=repo)
                return 2
            repo_name = _repo_name(repo, args.repo_name)
        except (OSError, ValueError):
            log.error(Event.REPO_NOT_A_DIRECTORY, path=repo)
            return 2

    # Trust gate: a config from INSIDE the scan target is attacker-influenced; --repo-file has none
    config_explicit = args.config is not None
    if not config_explicit:
        args.config = str(_default_config())
    boundary = args.repo  # None for --repo-file
    try:
        args.config = trusted_config(args.config, boundary, explicit=config_explicit)
        cfg = config_mod.load(args.config)
    except config_mod.ConfigPolicyError as e:
        log.error(Event.CONFIG_POLICY_REFUSED, detail=str(e))
        return 2
    if args.s6_progress_file:
        cfg.step6_verify.progress_file = True
    cfg_path = Path(args.config)
    cfg_dir = cfg_path.resolve().parent
    cfg_display = "config.yaml" if cfg_path.resolve() == (Path.cwd() / "config.yaml").resolve() else str(cfg_path)
    console.write(f"  config: {cfg_display}")
    _set_cmdb_path(cfg, cfg_dir)

    # --step1-config still wins over an enabled auto-derivation, handled below.
    args.auto_step1, auto_step1_src = _resolve_auto_step1(
        args.auto_step1, cfg, disable=args.no_auto_step1)
    if args.no_auto_step1:
        console.write("  step1 overlay: --no-auto-step1 (AI auto-exclude disabled, "
                      "overriding any config default)")

    if args.step1_config:
        if config_mod.is_network_path(args.step1_config):
            log.error(Event.CONFIG_PATH_NOT_LOCAL, flag="--step1-config", path=args.step1_config)
            return 2
        s1_path = Path(args.step1_config)
        try:
            cfg, s1_applied = config_mod.apply_step1_overlay(cfg, s1_path)
        except (config_mod.ConfigPolicyError, ValueError) as e:
            log.error(Event.STEP1_OVERLAY_REFUSED, path=s1_path, detail=str(e))
            return 2
        if not s1_applied:
            log.error(Event.STEP1_OVERLAY_NOT_FOUND, path=s1_path)
            return 2
        s1 = cfg._data.get("step1", {})
        console.write(f"  step1 overlay: {s1_path}  "
                      f"(exclude_dirs={len(s1.get('exclude_dirs') or [])} "
                      f"exts={len(s1.get('exclude_exts') or [])} "
                      f"globs={len(s1.get('exclude_globs') or [])})")
        if args.auto_step1:
            console.write(f"  step1 overlay: --step1-config given; ignoring "
                          f"{auto_step1_src}")
            args.auto_step1 = False
    elif args.auto_step1:
        console.write(f"  step1 overlay: {auto_step1_src} (per-target "
                      f"checkpoints/step1.yaml will be derived)")

    # CMDB is OPTIONAL: no VulContextSeverity scoring without it; CVSS+OffensivePriority still run
    _cmdb = _cmdb_path()
    if not _cmdb or not os.path.isfile(_cmdb):
        _where = _cmdb or "inject.cmdb_file unset"
        log.warning(Event.CMDB_MISSING, path=_where)

    _pricing_warning = _pricing_note(cfg)
    if _pricing_warning:
        console.write(_pricing_warning)

    configure_backends(cfg, cfg_dir)

    # EV `enabled: true/false` are HARD: a conflicting command line stops the run; `auto` never does
    _ev_err = ev_resolution_error(cfg, args)
    if _ev_err:
        log.error(Event.EV_RESOLUTION_CONFLICT, detail=_ev_err)
        return 2

    # EV OFFLINE collection gate, before any model spend: return 2 if requested but it can't run
    rc, ev_collection_in = _ev_gate(args, cfg)
    if rc is not None:
        return rc

    # 'ev' needs no model backend: skip verification to stay spend-free (probe runs in scan_repo)
    if not args.skip_preflight and args.stop_after not in ("clone", "ev"):
        # A stage this command cannot reach must not demand a credential; EV off with no collection
        _skip: set[str] = set(
            () if (not args.repo_file and ev_may_run(cfg, os.environ)) else EV_MODEL_ROLES)
        # Mirror scan.py's own s10/s11 gates (:917-920, :950-952): an unreachable stage's model
        # must not fail preflight for a run that will never call it.
        _rem_cfg = getattr(cfg, "step_remediate", None)
        _rem_on = bool(getattr(args, "remediate", False) or getattr(_rem_cfg, "enabled", False))
        if not (args.stop_after in (None, "s10", "s11") and _rem_on):
            _skip.add("remediate")
        _val_cfg = getattr(cfg, "step_validate", None)
        _val_on = bool(getattr(_val_cfg, "enabled", False))
        if not (args.stop_after in (None, "s11") and _val_on):
            _skip.add("validate")
        try:
            if not check_backends(cfg, skip_roles=_skip):
                return 1
        except KeyboardInterrupt:
            console.mark("fail", "scan aborted by user (Ctrl-C).", indent=2, lead="\n")
            return 130

    if args.repo_file:
        list_file = Path(args.repo_file)
        if not list_file.is_file():
            log.error(Event.REPO_FILE_NOT_A_FILE, path=list_file)
            return 2
        try:
            return run_batch(list_file, args, cfg)
        except StoreError as e:
            # Same one-line exit 2 as the single-repo path below; run_batch re-raises it.
            console.mark("fail", f"{e}", indent=2, lead="\n")
            return 2

    try:
        outcome = scan_repo(repo, repo_name, args.application_id, args, cfg,
                            ev_collection_in=ev_collection_in)
    except KeyboardInterrupt:
        console.mark("fail", "scan aborted by user (Ctrl-C).", indent=2, lead="\n")
        return 130
    except AuthenticationError as e:
        # VVAH-E001 is not retryable in-process: halt so the operator can re-auth and --resume.
        console.mark("fail", f"{e}", indent=2, lead="\n")
        _errlog.log("auth", repo_name, e,
                    error_code=AuthenticationError.error_code,
                    application_id=getattr(args, "application_id", None))
        console.write("  (use `vvaharness doctor` to verify credentials; "
                      "add --resume to continue from the last checkpoint)")
        return 1
    except ProxyError as e:
        # VVAH-E002 is a configuration fault, not a transient one — no retry can clear it.
        console.mark("fail", f"{e}", indent=2, lead="\n")
        _errlog.log("proxy", repo_name, e,
                    error_code=ProxyError.error_code,
                    application_id=getattr(args, "application_id", None))
        console.write("  (use `vvaharness doctor` to verify network/TLS settings)")
        return 1
    except EVUnreachableError as e:
        # Aborts the run before S2+ model spend — fix connectivity/auth or unset EV_API_COLLECTION.
        console.mark("fail", f"exploit verification: {redact(str(e))}", indent=2)
        return 2
    except EVInputError as e:
        # A resumed run's checkpointed collection failed the offline gate's environment checks.
        console.mark("fail", f"exploit verification: {redact(str(e))}", indent=2)
        return 2
    except StoreError as e:
        # A symlinked state dir/DB is an operator fix, not a scan failure — must precede `except Exception`.
        console.mark("fail", f"{e}", indent=2, lead="\n")
        return 2
    except EmptyScopeError as e:
        # Exit 2 = refused pre-spend, not 1 — must precede `except Exception`.
        console.mark("fail", f"{e}", indent=2, lead="\n")
        _errlog.log("s1", repo_name, e,
                    reason="empty_scope",
                    application_id=getattr(args, "application_id", None))
        return 2
    except Exception as e:
        # A raw traceback tempts an agent to "fix" the source: error log and VVAHARNESS_DEBUG only
        console.mark("fail", f"scan failed: {type(e).__name__}: {redact(str(e))}", indent=2)
        _errlog.log("scan", repo_name, e, application_id=args.application_id)
        if os.environ.get("VVAHARNESS_DEBUG"):
            traceback.print_exc(file=sys.stderr)
        else:
            console.write("  (set VVAHARNESS_DEBUG=1 for the full traceback; details "
                          "in the *_errors.jsonl under security-scan/)")
        return 1
    # Must return outcome.exit_code: discarding remediation's code once masked an s10 failure clean
    return outcome.exit_code
