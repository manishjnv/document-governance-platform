# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""What an outside plugin implements, and how a scan receives it."""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field, replace
from typing import Protocol, runtime_checkable

from context_graph_sdk.plugins import GraphEnricher

from vvaharness.backends.harness import SubagentDefinition
from vvaharness.codegraph.tools import (
    ToolFactory,
    clear_plugin_graph_tools,
    register_graph_tools,
)

MAX_PLUGINS = 16
MAX_PLUGIN_GRAPH_TOOLS = 8
_MAX_NAME_LENGTH = 64


@dataclass(frozen=True)
class PluginInfo:
    """Identity and ordering for one plugin; two plugins may not share a name."""

    name: str
    version: str
    priority: int = 100

    def __post_init__(self) -> None:
        """Rejects an unnamed or unversioned plugin, since the name is its identity."""
        if not self.name or not self.version:
            raise ValueError("plugin name and version are required")
        if len(self.name) > _MAX_NAME_LENGTH:
            raise ValueError(f"plugin name exceeds {_MAX_NAME_LENGTH} characters")

    @property
    def ordering_key(self) -> tuple[int, str]:
        """Priority then name, so a plugin set has one deterministic order."""
        return (self.priority, self.name)


@dataclass(frozen=True)
class Contribution:
    """What one plugin adds to a scan; every field is optional so a plugin fills only its seams."""

    enrichers: tuple[GraphEnricher, ...] = ()
    graph_tools: Mapping[str, ToolFactory] = field(default_factory=dict)
    subagents: tuple[SubagentDefinition, ...] = ()

    def merge(self, other: Contribution) -> Contribution:
        """This contribution followed by *other*; graph-tool name collisions raise."""
        clashes = set(self.graph_tools) & set(other.graph_tools)
        if clashes:
            raise ValueError(f"two plugins register the same graph tool: {sorted(clashes)}")
        return replace(
            self,
            enrichers=self.enrichers + other.enrichers,
            graph_tools={**self.graph_tools, **other.graph_tools},
            subagents=self.subagents + other.subagents,
        )


@runtime_checkable
class VvahPlugin(Protocol):
    """A vvaharness plugin: identity for ordering, and one Contribution."""

    @property
    def info(self) -> PluginInfo:
        """Identity and ordering for this plugin."""
        ...

    def contribute(self) -> Contribution:
        """Everything this plugin adds to a scan."""
        ...


def _validated(plugins: tuple[object, ...]) -> tuple[VvahPlugin, ...]:
    """Conforming, name-unique plugins in deterministic order, or a raised ValueError."""
    if len(plugins) > MAX_PLUGINS:
        raise ValueError(f"at most {MAX_PLUGINS} plugins")
    seen: set[str] = set()
    checked: list[VvahPlugin] = []
    for plugin in plugins:
        if not isinstance(plugin, VvahPlugin):
            raise TypeError(f"not a VvahPlugin: {type(plugin).__name__}")
        name = plugin.info.name
        if name in seen:
            raise ValueError(f"duplicate plugin name: {name}")
        seen.add(name)
        checked.append(plugin)
    return tuple(sorted(checked, key=lambda p: p.info.ordering_key))


class PluginSet:
    """A bounded, ordered set of plugins, merged into the one Contribution a scan consumes."""

    def __init__(self, plugins: Iterable[object] = ()) -> None:
        """Validates, orders and merges *plugins*, raising rather than silently dropping any."""
        self._plugins = _validated(tuple(plugins))
        merged = Contribution()
        for plugin in self._plugins:
            merged = merged.merge(plugin.contribute())
        if len(merged.graph_tools) > MAX_PLUGIN_GRAPH_TOOLS:
            raise ValueError(f"at most {MAX_PLUGIN_GRAPH_TOOLS} plugin graph tools")
        self._contribution = merged

    def __len__(self) -> int:
        """The number of plugins in this set."""
        return len(self._plugins)

    def __bool__(self) -> bool:
        """True when this set contributes anything."""
        return bool(self._plugins)

    @property
    def names(self) -> tuple[str, ...]:
        """Plugin names in the order they contribute."""
        return tuple(p.info.name for p in self._plugins)

    @property
    def contribution(self) -> Contribution:
        """The merged contribution; enrichers run in this order and tools keep these names."""
        return self._contribution

    def install_graph_tools(self) -> tuple[str, ...]:
        """Makes this set the only registered one, so the stages see exactly its tools."""
        clear_plugin_graph_tools()
        register_graph_tools(self._contribution.graph_tools)
        return tuple(self._contribution.graph_tools)


__all__ = [
    "MAX_PLUGINS",
    "MAX_PLUGIN_GRAPH_TOOLS",
    "Contribution",
    "GraphEnricher",
    "PluginInfo",
    "PluginSet",
    "VvahPlugin",
]
