# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Structured error log shared across pipeline stages; one JSON line per record."""
# The orchestrator must call configure() once per scan before any log(), or records land in cwd
from __future__ import annotations
from vvaharness.util import logs

import json
import os
import threading
import traceback
from datetime import UTC, datetime
from pathlib import Path

from vvaharness.report.redact import redact
from vvaharness.util.exceptions import exception_chain
from vvaharness.util.events import Event

_log = logs.get_logger(__name__)

_path: Path = Path("pipeline-errors.jsonl")
_lock = threading.Lock()

#: Stamped on an exception once an UNRECOVERED record exists, so an outer catch skips a duplicate
_LOGGED_ATTR = "_vvah_errlog_recorded"


def configure(path: str | Path) -> None:
    global _path
    _path = Path(path)
    _path.parent.mkdir(parents=True, exist_ok=True)


def current_path() -> Path:
    """The errors-log path currently configured (for a report-time pointer)."""
    return _path


def counts_by_stage(path: str | Path | None = None, *,
                    include_recovered: bool = True) -> dict[str, int]:
    """Re-read the errors JSONL and tally records per `stage`."""
    # Best-effort, never raises; NO lock (callers are single-threaded); COARSE, not per-unit truth
    p = Path(path) if path is not None else _path
    counts: dict[str, int] = {}
    try:
        with p.open("r", encoding="utf-8") as f:
            for ln in f:
                ln = ln.strip()
                if not ln:
                    continue
                try:
                    rec = json.loads(ln)
                except (json.JSONDecodeError, ValueError):
                    continue
                if not include_recovered and rec.get("recovered") is True:
                    continue
                stage = rec.get("stage")
                if isinstance(stage, str):
                    counts[stage] = counts.get(stage, 0) + 1
    except OSError:
        return counts
    return counts


def count_for_stage(stage_id: str, path: str | Path | None = None, *,
                    include_recovered: bool = True) -> int:
    """Total error records attributed to pipeline stage *stage_id*."""
    # Boundary-aware matching: "s1" claims "s1.autoexclude" but never "s10"
    total = 0
    for label, n in counts_by_stage(
            path, include_recovered=include_recovered).items():
        if label == stage_id or (label.startswith(stage_id)
                                 and not label[len(stage_id)].isalnum()):
            total += n
    return total


def last_message_for_stage(stage_id: str, path: str | Path | None = None) -> str | None:
    """The most recent unrecovered ``error`` text logged under *stage_id*, or a sub-label of it."""
    # Skips recovered=True; already redacted by log(), but re-redact before a user-facing field
    p = Path(path) if path is not None else _path
    last: str | None = None
    try:
        with p.open("r", encoding="utf-8") as f:
            for ln in f:
                ln = ln.strip()
                if not ln:
                    continue
                try:
                    rec = json.loads(ln)
                except (json.JSONDecodeError, ValueError):
                    continue
                if rec.get("recovered") is True:
                    continue
                label = rec.get("stage")
                if not isinstance(label, str):
                    continue
                if label == stage_id or (label.startswith(stage_id)
                                         and not label[len(stage_id)].isalnum()):
                    err = rec.get("error")
                    if isinstance(err, str):
                        last = err
    except OSError:
        return None
    return last


def already_logged(error: BaseException) -> bool:
    """True when *error* or a cause in its chain already carries an unrecovered errlog record."""
    # Only UNRECOVERED records suppress a duplicate; blind to WHICH label stamped it (none yet)
    for err in exception_chain(error):
        if getattr(err, _LOGGED_ATTR, False):
            return True
    return False


def _provider_excerpt(error: BaseException) -> str | None:
    """Bounded, redacted excerpt of a provider-side body in *error*'s chain."""
    # `.stderr` is invisible to str(exc)/tracebacks; redacted HERE because the record is on-disk
    for err in exception_chain(error):
        stderr = getattr(err, "stderr", None)
        if isinstance(stderr, str) and stderr.strip():
            return redact(stderr)[-2000:]
    return None


def log(stage: str, unit: str, error: BaseException | str, *,
        recovered: bool = False, **extra) -> None:
    """Append one JSONL record. Never raises."""
    if isinstance(error, BaseException):
        msg = f"{type(error).__name__}: {error}"
        code = None
        for _link in exception_chain(error):
            _code = getattr(_link, "error_code", None)
            if isinstance(_code, str):
                code = _code
                break
        if code is not None and "error_code" not in extra:
            extra["error_code"] = code
        # ModelRefusal.category, read by attribute: this module must not import backends
        category = next((c for c in (getattr(link, "category", None)
                                     for link in exception_chain(error)) if isinstance(c, str)),
                        None)
        if category is not None and "category" not in extra:
            extra["category"] = category
        if "stderr" not in extra:
            excerpt = _provider_excerpt(error)
            if excerpt is not None:
                extra["stderr"] = excerpt
        # Redact BEFORE the -4000 slice, NEVER reorder: slicing first cuts a credential's anchor off
        tb = redact("".join(traceback.format_exception(
            type(error), error, error.__traceback__)))[-4000:]
    else:
        msg, tb = str(error), None

    msg = redact(msg)
    safe_extra = {k: (redact(v) if isinstance(v, str) else v)
                  for k, v in extra.items()}
    rec = {
        "ts": datetime.now(UTC).isoformat(timespec="seconds"),
        # `unit` is repo-derived, so it is redacted too: a path must not bypass the scrub
        "stage": stage,
        "unit": redact(unit) if isinstance(unit, str) else unit,
        "error": msg,
        **safe_extra,
    }
    if recovered:
        # Normalized to the bool literal: the counting side matches `is True` strictly.
        rec["recovered"] = True
    if tb:
        rec["traceback"] = tb
    try:
        with _lock:
            with open(_path, "a", encoding="utf-8",
                      opener=lambda path, flags: os.open(path, flags, 0o600)) as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception as e:  # noqa: BLE001
        _log.warning(Event.ERRLOG_WRITE_FAILED, stage=rec.get("stage"), unit=rec.get("unit"),
                     detail=str(e))
        return
    if isinstance(error, BaseException) and not recovered:
        # Stamp AFTER a successful write, unrecovered only (see already_logged); best effort
        try:
            setattr(error, _LOGGED_ATTR, True)
        except AttributeError:
            pass
