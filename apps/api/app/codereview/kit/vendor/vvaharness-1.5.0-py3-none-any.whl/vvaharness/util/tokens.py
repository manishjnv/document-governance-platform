# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Process-wide token accounting shared by every model backend."""
# Per-phase buckets rely on phases NEVER overlapping (s4/s6 pools sit inside one), hence one global
from __future__ import annotations

import re
import threading
from collections import defaultdict
from contextlib import contextmanager
from typing import NamedTuple, TypedDict

from vvaharness.util.warn_once import warn_once


class TokenUsage(TypedDict, total=False):
    """The usage fields a backend reports, in Anthropic's field names; every reader defaults absent ones to 0."""

    input_tokens: int
    # Pass an explicit null THROUGH, never `or 0`: that pinned completion_absent at 0 on openai
    output_tokens: int | None
    cache_creation_input_tokens: int
    cache_read_input_tokens: int
    # OpenAI-only detail ALREADY inside the billed output_tokens; never add it to a total again
    reasoning_tokens: int


DEFAULT_PHASE = "unscoped"


class Spend(NamedTuple):
    """A cumulative reading of REPORTED cost/turns, with per-axis report counts."""

    usd: float = 0.0
    turns: int = 0
    usd_reports: int = 0
    turn_reports: int = 0


def reported_between(before: Spend, after: Spend) -> tuple[float | None, int | None]:
    """The (usd, turns) reported between two readings, None where nothing was; assumes no overlap."""
    usd = (after.usd - before.usd
           if after.usd_reports > before.usd_reports else None)
    turns = (after.turns - before.turns
             if after.turn_reports > before.turn_reports else None)
    return usd, turns


# The ONE offline estimator; flat chars/4 under-counts dense source ~1.63x, tiktoken ~3.4 vs ~2.45

_CPT_PROSE = 4.4       # chars/token for narrative + schema text
_CPT_DENSE = 2.45      # chars/token for dense numbered source
_DENSE_FRAC_LO = 0.08  # <= this fraction of digits/punctuation reads as prose
_DENSE_FRAC_HI = 0.34  # >= this reads as fully dense numbered source


def estimate_tokens(text: str) -> int:
    """Content-aware token estimate for `text` (see the notes above)."""
    n = len(text)
    if n <= 0:
        return 0
    dense = 0
    for ch in text:
        if not ch.isspace() and not ch.isalpha():
            dense += 1
    frac = dense / n
    if frac <= _DENSE_FRAC_LO:
        cpt = _CPT_PROSE
    elif frac >= _DENSE_FRAC_HI:
        cpt = _CPT_DENSE
    else:
        span = (frac - _DENSE_FRAC_LO) / (_DENSE_FRAC_HI - _DENSE_FRAC_LO)
        cpt = _CPT_PROSE + span * (_CPT_DENSE - _CPT_PROSE)
    return int(n / cpt)


def _bucket() -> dict:
    # cache_unparsed counts CALLS; usd/turns seed None, not 0, so unreported never reads as $0
    return {"prompt": 0, "completion": 0, "cache_read": 0,
            "cache_write": 0, "calls": 0, "cache_unparsed": 0,
            "usd": None, "turns": None, "reasoning": 0}


# SECURITY: KEY NAMES ONLY, never values (hostile gateway); backends must filter RAW usage first

_UNPARSED_CACHE_KEY_RX = re.compile(r"^[A-Za-z0-9_.\-]{1,64}$")
_UNPARSED_CACHE_KEY_CAP = 8


def unparsed_cache_keys(usage, parsed) -> tuple[str, ...]:
    """The cache-ish key names in `usage` that `parsed` does not cover."""
    # Present-as-zero counts; None does not — a typed-model dump fabricates that for absent fields
    if not isinstance(usage, dict):
        return ()
    hits = {
        k for k, v in usage.items()
        if isinstance(k, str) and k not in parsed and v is not None
        and "cache" in k.lower() and _UNPARSED_CACHE_KEY_RX.match(k)
    }
    return tuple(sorted(hits)[:_UNPARSED_CACHE_KEY_CAP])


class _TokenCounter:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._phase = DEFAULT_PHASE
        self.prompt = 0
        self.completion = 0
        self.calls = 0
        self.calls_with_usage = 0
        # Explicit nulls coerced to 0 for the total, counted here so absent ≠ a genuine zero
        self.completion_absent = 0
        self.usd = 0.0
        self.turns = 0
        self.usd_reports = 0
        self.turn_reports = 0
        self.by_phase: dict[str, dict] = defaultdict(_bucket)
        # Distinct (via, key-set) pairs already noted, so each backend logs once per key-set.
        self._cache_unparsed_seen: set[tuple] = set()
        # One stderr note per counter lifetime; noting every short preflight ping would be noise.
        self._completion_absent_noted: set[str] = set()

    @contextmanager
    def phase(self, name: str):
        prev, self._phase = self._phase, name
        try:
            yield
        finally:
            self._phase = prev

    def current_phase(self) -> str:
        with self._lock:
            return self._phase

    def add(self, usage: TokenUsage | None, *,
            usd: float | None = None, turns: int | None = None) -> None:
        """Record one usage record; *usd*/*turns* of None means unreported, not zero (see :class:`Spend`)."""
        with self._lock:
            n_requests = 1
            if isinstance(usage, dict):
                raw_calls = usage.get("calls")
                if (isinstance(raw_calls, int)
                        and not isinstance(raw_calls, bool) and raw_calls > 0):
                    n_requests = raw_calls
            self.calls += n_requests
            b = self.by_phase[self._phase]
            b["calls"] += n_requests
            if usd is not None:
                self.usd_reports += 1
                self.usd += usd
                b["usd"] = (b["usd"] or 0.0) + usd
            if turns is not None:
                self.turn_reports += 1
                self.turns += turns
                b["turns"] = (b["turns"] or 0) + turns
            if not isinstance(usage, dict):
                return
            self.calls_with_usage += n_requests
            fresh = int(usage.get("input_tokens", 0) or 0)
            cw = int(usage.get("cache_creation_input_tokens", 0) or 0)
            cr = int(usage.get("cache_read_input_tokens", 0) or 0)
            out_raw = usage.get("output_tokens", 0)
            if out_raw is None:
                # Coerce to 0 for the totals, but count the coercion so the absence is visible.
                self.completion_absent += 1
                warn_once(
                    self._completion_absent_noted,
                    "null-completion-count",
                    "  [tokens] WARN: a usage record carried a null "
                    "completion count; coerced to 0 (occurrences counted "
                    "under completion_absent)",
                )
            out = int(out_raw or 0)
            # prompt = billable input (fresh + cache-write); cache-read is ~10% cost, tracked apart
            self.prompt += fresh + cw
            self.completion += out
            b["prompt"] += fresh + cw
            b["completion"] += out
            b["cache_read"] += cr
            b["cache_write"] += cw
            # Detail only, already inside `completion` above — never a second addend to a total.
            b["reasoning"] += int(usage.get("reasoning_tokens", 0) or 0)

    def spend(self) -> Spend:
        """A point-in-time reading, for diffing across one engine call."""
        with self._lock:
            return Spend(usd=self.usd, turns=self.turns,
                         usd_reports=self.usd_reports, turn_reports=self.turn_reports)

    def note_cache_unparsed(self, keys: tuple[str, ...], *,
                            via: str = "") -> bool:
        """Count one call whose usage carried cache accounting under key names nothing parses."""
        if not keys:
            return False
        with self._lock:
            self.by_phase[self._phase]["cache_unparsed"] += 1
            marker = (via, keys)
            if marker in self._cache_unparsed_seen:
                return False
            self._cache_unparsed_seen.add(marker)
            return True

    def reset(self) -> None:
        with self._lock:
            self.prompt = self.completion = self.calls = self.calls_with_usage = 0
            self.completion_absent = 0
            self.usd = 0.0
            self.turns = self.usd_reports = self.turn_reports = 0
            self.by_phase = defaultdict(_bucket)
            self._cache_unparsed_seen = set()
            self._completion_absent_noted = set()

    def snapshot(self) -> dict:
        with self._lock:
            return {
                "prompt": self.prompt,
                "completion": self.completion,
                "total": self.prompt + self.completion,
                "calls": self.calls,
                "calls_with_usage": self.calls_with_usage,
                "completion_absent": self.completion_absent,
                "usd": self.usd if self.usd_reports else None,
                "turns": self.turns if self.turn_reports else None,
                "by_phase": {k: dict(v) for k, v in self.by_phase.items()},
            }


TOKENS = _TokenCounter()
