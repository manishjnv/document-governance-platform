# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The retry policy: rate limits, timeouts, auth, proxy, truncation."""
from __future__ import annotations

import json
import re
import subprocess
import time
import uuid

from vvaharness.backends.harness.deepagents.limits import MODEL_MAX_OUTPUT_TOKENS
from vvaharness.backends.harness.models import (
    AuthenticationError,
    ProxyError,
    TruncatedResponseError,
    truncated_below_budget,
)
from vvaharness.backends.llm.cli import cancel as _cancel
from vvaharness.backends.llm.cli import envelope as _envelope
from vvaharness.backends.llm.cli import process as _process
from vvaharness.backends.llm.models import (
    CLI_CONN_TRANSIENT_RX,
    CLI_RETRYABLE_STATUS,
    CLI_STATUS_429_RX,
    CLI_TOKEN_CAP_RX,
    LLM_TRUNCATED_BELOW_BUDGET_COUNTER,
    PROXY_CAUSE_RX,
    RATE_LIMIT_TRANSIENT_RX,
    TIMEOUT_MAX_RETRIES,
    TRUNCATED_REPLIES_COUNTER,
    TRUNCATED_RETRY_ATTEMPTED_COUNTER,
    TRUNCATED_RETRY_RECOVERED_COUNTER,
)
from vvaharness.report.redact import redact
from vvaharness.util import console, logs
from vvaharness.util import errlog as _errlog
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

# Transient classifiers live in models.py; this hard usage-cap reset ("resets ...") won't heal
_RL_HARD_CAP = re.compile(r"hit your (usage )?limit.*resets", re.IGNORECASE)
_RL_MAX_RETRIES = 4
_RL_BACKOFF = (30, 60, 120, 240)
# A subprocess timeout retries at most this many times (may be a genuine hang), capping wall-clock.
_TIMEOUT_MAX_RETRIES = TIMEOUT_MAX_RETRIES

# Claude Code may placeholder while sub-agents run; retry rather than treat it as empty output.
_PENDING_RESULT_RX = re.compile(
    r"__PENDING__"
    r"|still executing"
    r"|(?:task\s+is\s+)?still\s+pending"
    r"|waiting\s+for\s+(?:background\s+)?sub-?agent"
    r"|background\s+sub-?agent",
    re.IGNORECASE,
)
_PENDING_MAX_RETRIES = 3
_PENDING_BACKOFF = (5, 15, 30)


def _is_pending_result(text: str | None) -> bool:
    if not isinstance(text, str):
        return False
    return bool(_PENDING_RESULT_RX.search(text))


# 3 fast retries absorb JWT clock-skew only, then halt for a credential refresh (VVAH-E001)
_AUTH_FAILURE = re.compile(
    r"\b401\b"
    r"|unauthorized"
    r"|invalid[_ ]api[_ ]key"
    r"|invalid.*token|token.*(?:expired|invalid|revoked)"
    r"|authentication[_ ]failed"
    r"|access[_ ]denied",
    re.IGNORECASE,
)
_AUTH_MAX_RETRIES = 3
_AUTH_BACKOFF = (2, 4, 8)

# Proxy/TLS misconfiguration cannot heal on its own, so it is raised immediately (VVAH-E002).
_PROXY_FAILURE = PROXY_CAUSE_RX


def _envelope_fields(env: dict) -> tuple[int | None, str | None, bool]:
    """(api_error_status, result_text, True) off one already-parsed terminal result event."""
    status = env.get("api_error_status")
    text = env.get("result") or env.get("error") or env.get("message")
    return (status if isinstance(status, int) else None,
            text if isinstance(text, str) else None,
            True)


def _last_result_line(stdout: str) -> dict | None:
    """The last `stream-json` (newline-delimited) line that is a terminal `result` event.

    ``agentic()`` always runs with ``--output-format stream-json``, so a multi-event stdout
    is N physical JSON lines, not one document; scan from the end for the terminal one.
    """
    for line in reversed(stdout.splitlines()):
        line = line.strip()
        if not line:
            continue
        try:
            evt = json.loads(line)
        except (json.JSONDecodeError, TypeError):
            continue
        if isinstance(evt, dict) and evt.get("type") == "result":
            return evt
    return None


def _terminal_result_fields(stdout: str | None
                            ) -> tuple[int | None, str | None, bool]:
    """Return (api_error_status, result_text, envelope_found) from the CLI's terminal result event."""
    if not stdout:
        return None, None, False
    s = stdout.strip()
    candidates = [p for p in (s.find("{"), s.find("[")) if p >= 0]
    if not candidates:
        return None, None, False
    try:
        env = json.loads(s[min(candidates):])
    except (json.JSONDecodeError, ValueError, TypeError):
        env = _last_result_line(s)
        return _envelope_fields(env) if env is not None else (None, None, False)
    if isinstance(env, list):
        env = next((e for e in reversed(env)
                    if isinstance(e, dict) and e.get("type") == "result"), None)
        if env is None:
            return None, None, False      # truncated stream: no terminal event
    if not isinstance(env, dict):
        return None, None, False
    return _envelope_fields(env)


def _truncation_cap(result: subprocess.CompletedProcess) -> int | None:
    """The output-token cap a failed run reports hitting, or None if that is not why."""
    # Text, not status: the cap reports ``api_error_status: null``; no backoff, E005 owns the retry
    _status, text, found = _terminal_result_fields(result.stdout)
    blob = text if found and text else f"{result.stdout or ''}\n{result.stderr or ''}"
    m = CLI_TOKEN_CAP_RX.search(blob or "")
    if not m:
        return None
    try:
        return int(m.group(1))
    except (TypeError, ValueError):  # pragma: no cover — \d+ cannot fail to parse
        return None


def _truncation_error(*, requested: int, retried: int, tag: str | None,
                      retry_at: int | None,
                      produced: int | None = None) -> TruncatedResponseError:
    """Build the typed VVAH-E005 failure, with the same three messages sdk.py uses."""
    COUNTERS.bump(TRUNCATED_REPLIES_COUNTER)
    if truncated_below_budget(produced, requested):
        COUNTERS.bump(LLM_TRUNCATED_BELOW_BUDGET_COUNTER)
    if retried:
        msg = "reply still hit the output-token budget after the doubled retry"
    elif retry_at is None:
        msg = (f"max_tokens={requested} is already at the model output cap "
               f"({MODEL_MAX_OUTPUT_TOKENS}); no useful retry")
    else:
        msg = "reply hit the output-token budget with no retry budget left"
    return TruncatedResponseError(msg, stage=tag or "", requested=requested,
                                  retried=retried, produced=produced)


def _log_truncation_retry(*, tag: str | None, requested: int, retry_at: int,
                          label: str) -> None:
    """Announce the one doubled-budget retry as a recovered VVAH-E005 warning."""
    COUNTERS.bump(TRUNCATED_RETRY_ATTEMPTED_COUNTER)
    log.warning(Event.TRUNCATED_RETRY, route=label, budget=requested, retry_at=retry_at)
    _errlog.log(
        tag or label, tag or "truncation",
        f"VVAH-E005 warning: reply truncated at max_tokens={requested}; "
        f"retrying once at {retry_at}",
        error_code=TruncatedResponseError.error_code, recovered=True)


def _accept_reply(text: str, *, trunc_retried: int) -> str:
    """Return *text*, counting it as recovered when it is the doubled-budget retry's reply."""
    if trunc_retried:
        COUNTERS.bump(TRUNCATED_RETRY_RECOVERED_COUNTER)
    return text


def _is_transient_failure(result: subprocess.CompletedProcess) -> bool:
    """Classify a non-zero CLI exit: True only for a genuine transient worth retrying."""
    status, text, found = _terminal_result_fields(result.stdout)
    if found:
        if status in CLI_RETRYABLE_STATUS:
            return True
        # A null-status transient phrase (e.g. "Overloaded") still retries; telemetry is separate.
        if status is None and text and (RATE_LIMIT_TRANSIENT_RX.search(text)
                                        or CLI_STATUS_429_RX.search(text)
                                        or CLI_CONN_TRANSIENT_RX.search(text)):
            return True
        return False
    # No terminal event at all: stdout here is the model's own streamed turns (thinking,
    # tool payloads, prompt/response text), not a diagnostic — scan stderr only. A real
    # transient phrase from the CLI's own HTTP layer surfaces on stderr.
    return bool(RATE_LIMIT_TRANSIENT_RX.search(result.stderr or "")
                or CLI_STATUS_429_RX.search(result.stderr or "")
                or CLI_CONN_TRANSIENT_RX.search(result.stderr or ""))


def _is_auth_failure(result: subprocess.CompletedProcess) -> bool:
    """True when the CLI result indicates an authentication error (VVAH-E001)."""
    status, text, found = _terminal_result_fields(result.stdout)
    if found:
        if status == 401:
            return True
        return bool(text and _AUTH_FAILURE.search(text))
    # No terminal event at all (killed/refused mid-stream): the model's own streamed
    # content lives in stdout and must not be blind-scanned (it routinely contains the
    # substrings this regex matches, with no credential meaning). stderr is the CLI's own
    # diagnostics, where a real 401 from its request plumbing would actually appear.
    return bool(_AUTH_FAILURE.search(result.stderr or ""))


def _proxy_failure_evidence(result: subprocess.CompletedProcess) -> str | None:
    """What made this look like a proxy/TLS error (VVAH-E002), or None if it does not."""
    # EVIDENCE, not a verdict: the first 400 chars are the init event, and `\b407\b` hits any 407
    status, text, found = _terminal_result_fields(result.stdout)
    if found:
        if status == 407:
            return "terminal result reported status 407"
        haystack = text or ""
    else:
        # Unlike auth/transient above, a proxy/TLS failure fires at the CONNECTION, before
        # any model turn starts, so the CLI's own prose for it is observed landing on
        # stdout with no stderr counterpart (see test_a_proxy_classification_names_its_own_
        # evidence) -- a known non-stream case kept working deliberately, not an oversight.
        haystack = f"{result.stdout or ''}\n{result.stderr or ''}"
    m = _PROXY_FAILURE.search(haystack)
    if m is None:
        return None
    lo, hi = max(0, m.start() - 120), min(len(haystack), m.end() + 120)
    return f"matched {m.group(0)!r} in: ...{haystack[lo:hi]}..."


def _is_proxy_failure(result: subprocess.CompletedProcess) -> bool:
    """True when the CLI result indicates a proxy/TLS error (VVAH-E002)."""
    return _proxy_failure_evidence(result) is not None


def _rotate_session_id(cmd: list[str]) -> None:
    """Give a retried attempt a fresh `--session-id`; the CLI rejects a reused one."""
    if "--session-id" in cmd:
        cmd[cmd.index("--session-id") + 1] = str(uuid.uuid4())


def _run_with_retry(cmd: list[str], *, label: str,
                    timeout_retries: int = _TIMEOUT_MAX_RETRIES, **kw
                    ) -> subprocess.CompletedProcess:
    """_run() + exponential backoff on GENUINE transient failures only (see _is_transient_failure)."""
    # timeout_retries is consumed HERE, never forwarded in **kw: _run() has no such parameter.
    attempt = 0
    auth_attempt = 0
    timeout_attempt = 0
    while True:
        try:
            result = _process._run(cmd, **kw)
        except subprocess.TimeoutExpired:
            # A timeout isn't a CompletedProcess; retry once (bounded) before propagating it.
            if _cancel._ABORT.is_set() or timeout_attempt >= timeout_retries:
                raise
            timeout_attempt += 1
            console.write(f"    [cli] {label}: timed out — retrying once "
                          f"({timeout_attempt}/{timeout_retries})")
            continue
        if result.returncode == 0:
            return result
        _, text, _ = _terminal_result_fields(result.stdout)
        err_text = text or f"{result.stdout or ''}\n{result.stderr or ''}"
        # A refusal is a refusal, not an auth/proxy error: classify it BEFORE either, so
        # the stray "token"/"invalid_request" substrings a refusal event carries never
        # reach _is_auth_failure's regex.
        _envelope._raise_if_refused_exit(result.stdout, tag=label)
        proxy_evidence = _proxy_failure_evidence(result)
        if proxy_evidence:
            raise ProxyError(
                # redact() BEFORE [:400] (same trap as sdk.py); evidence appended, not substituted
                f"{redact(err_text)[:400]}\n  classified E002 because: "
                f"{redact(proxy_evidence)[:400]}",
                status_code=407 if re.search(r"\b407\b", err_text) else None,
                backend="cli",
            )
        if _is_auth_failure(result):
            if auth_attempt < _AUTH_MAX_RETRIES:
                wait = _AUTH_BACKOFF[min(auth_attempt, len(_AUTH_BACKOFF) - 1)]
                console.write(f"    [cli] {label}: authentication error (attempt "
                              f"{auth_attempt + 1}/{_AUTH_MAX_RETRIES}); retrying in "
                              f"{wait}s")
                time.sleep(wait)
                auth_attempt += 1
                _rotate_session_id(cmd)
                continue
            raise AuthenticationError(redact(err_text)[:400], status_code=401,
                                      backend="cli")
        if _RL_HARD_CAP.search(err_text):
            console.write(f"    [cli] {label}: hard usage cap reached — not retrying")
            return result
        if attempt >= _RL_MAX_RETRIES or not _is_transient_failure(result):
            return result
        wait = _RL_BACKOFF[min(attempt, len(_RL_BACKOFF) - 1)]
        console.write(f"    [cli] {label}: transient upstream error (attempt "
                      f"{attempt + 1}/{_RL_MAX_RETRIES}); retrying in {wait}s")
        slept = 0
        while slept < wait:
            if _cancel._ABORT.is_set():
                raise RuntimeError("aborted by user (Ctrl-C)")
            time.sleep(min(5, wait - slept))
            slept += 5
        _rotate_session_id(cmd)
        attempt += 1


def _log_usage(usage: dict | None, *, stop_reason: str | None = None,
               model_usage: dict | None = None) -> None:
    """Print the one-line `[cli] usage:` summary; shared by prompt() and agentic()."""
    # stop_reason + modelUsage close the two holes here: a swapped model looked identical in logs
    if not usage:
        return
    _cache_r = int(usage.get("cache_read_input_tokens", 0) or 0)
    _cache_w = int(usage.get("cache_creation_input_tokens", 0) or 0)
    _in = int(usage.get("input_tokens", 0) or 0) + _cache_r + _cache_w
    _out = int(usage.get("output_tokens", 0) or 0)
    cache_info = (f" (cache_read={_cache_r}, cache_write={_cache_w})"
                  if (_cache_r or _cache_w) else "")
    extra = f" stop_reason={stop_reason}" if stop_reason else ""
    if model_usage:
        # One model per call in practice; join defensively so a two-key gateway never KeyErrors
        echoes = []
        for resolved, spend in model_usage.items():
            cost = (spend or {}).get("costUSD") if isinstance(spend, dict) else None
            echoes.append(f"{resolved}" + (f"=${cost}" if cost is not None else ""))
        extra += f" model={','.join(echoes)}"
    console.write(f"    [cli] usage: in={_in}{cache_info} out={_out}{extra}")
