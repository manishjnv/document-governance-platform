# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Markdown-safety helpers shared by the report renderers."""
from __future__ import annotations

import logging
import re

log = logging.getLogger(__name__)

_ATX_HEADING_RX = re.compile(r"^(\s{0,3})#{1,6}[ \t]+(.*)$")
_FENCE_RX = re.compile(r"^\s{0,3}(```|~~~)")
_SETEXT_H1_RX = re.compile(r"^\s{0,3}=+\s*$")

# splitlines() breaks on all of these, so a U+2028 forges a table row past a \r\n filter
_MD_LINEBREAK_RX = re.compile(
    "[\r\n\x0b\x0c\x1c\x1d\x1e\x85\u2028\u2029]")

# The full separator set, not bare \n: splitlines consumers and `Label: value` builders break
_NEWLINE_RUN_RX = re.compile(rf"\s*{_MD_LINEBREAK_RX.pattern}\s*")
# Zero-width/bidi (Trojan-Source) chars can hide or reorder text, e.g. flip a FAILED status
_MD_INVISIBLE_RX = re.compile(
    "[\x00-\x08\x0e-\x1f\x7f"              # C0 minus \t and the breaks above
    "\u00ad\u061c"                         # soft hyphen, Arabic letter mark
    "\u200b-\u200f\u202a-\u202e"           # zero-width chars, bidi embeddings
    "\u2060-\u2064\u2066-\u2069\ufeff]")   # word joiner..isolates, BOM

_ANGLE_ENTITY = str.maketrans({"<": "&lt;", ">": "&gt;"})

# Escaping `<`/`>` inside a span corrupts a quoted code value; duplicates s8's RX, this is a leaf
_INLINE_CODE_SPAN_RX = re.compile(r"(`+[^`]*`+)")


def _demote_md_headings(text, *, escape_angles: bool = False):
    """Demote forged headings in untrusted text, optionally escaping `<`/`>`."""
    # escape_angles is for model prose only; findings.json/SARIF must keep the model's exact bytes
    if not text:
        return text
    lines = str(text).splitlines()
    # ``` and ~~~ are distinct markers, so a snippet quoting the other style cannot flip the state
    fenced = [False] * len(lines)
    open_idx: int | None = None
    marker = ""
    for i, ln in enumerate(lines):
        m = _FENCE_RX.match(ln)
        if not m:
            continue
        if open_idx is None:
            open_idx, marker = i, m.group(1)
        elif m.group(1) == marker:
            for j in range(open_idx, i + 1):
                fenced[j] = True
            open_idx = None
    dangling = lines[open_idx] if open_idx is not None else ""
    out = []
    for i, ln in enumerate(lines):
        if fenced[i]:
            out.append(ln)
            continue
        if escape_angles:
            # Odd indices are the code spans: byte-identical so a copy-pasted value is not corrupted
            parts = _INLINE_CODE_SPAN_RX.split(ln)
            ln = "".join(p.translate(_ANGLE_ENTITY) if i % 2 == 0 else p
                        for i, p in enumerate(parts))
        ln = _ATX_HEADING_RX.sub(
            lambda m: f"{m.group(1)}**{m.group(2).rstrip()}**", ln)
        # `====` after text forges a heading ATX never sees; `----` is left alone (it is a rule)
        if _SETEXT_H1_RX.match(ln) and out and out[-1].strip():
            out.append("")
        out.append(ln)
    if dangling:
        # Close with the opener's own full marker run, so the fence state ends with this block
        m = re.match(r"\s{0,3}(`{3,}|~{3,})", dangling)
        out.append(m.group(1) if m else "```")
    return "\n".join(out)


_TICK_RUN_RX = re.compile(r"`+")


def _escape_angles(text) -> str:
    """Entity-escape ``<``/``>`` everywhere in an already-folded one-line value."""
    # No fence walker: a one-liner starting with ``` would match its fence branch and stop escaping
    return str(text or "").translate(_ANGLE_ENTITY)


def _snippet_fence(code) -> str:
    """Return a fence longer than any backtick run in *code*, so *code* cannot close it."""
    runs = _TICK_RUN_RX.findall(str(code or ""))
    return "`" * max(3, max((len(r) for r in runs), default=0) + 1)


def _code_span(text) -> str:
    """Wrap an untrusted one-line value verbatim in a code span it cannot close."""
    # Pipes/backslashes stay raw: literal inside a span outside tables.
    s = _MD_INVISIBLE_RX.sub("", _MD_LINEBREAK_RX.sub(" ", str(text or ""))).strip()
    runs = _TICK_RUN_RX.findall(s)
    if not runs:
        return f"`{s}`"
    d = "`" * (max(len(r) for r in runs) + 1)
    return f"{d} {s} {d}"


#: A well-formed CVSS 3.x vector -- the only shape rendered in a bare span.
_CVSS_VECTOR_RX = re.compile(r"CVSS:3\.[01]/[A-Za-z:./]+")


def _vector_span(vec) -> str:
    """Render a model-emitted CVSS vector so it cannot close its own span."""
    # Also used by the remediation prompt, where an escaped span lands in file-editing instructions
    v = str(vec or "")
    return f"`{v}`" if _CVSS_VECTOR_RX.fullmatch(v) else _code_span(v)


def _one_line(text) -> str:
    """Fold a value onto one physical line for ``**Label:** value`` fields."""
    # Newline runs only: labels fire at line start; `_md_cell` would mangle legitimate emphasis
    return _NEWLINE_RUN_RX.sub(" ", str(text or "")).strip()


def _confidence_label(confidence: int | None) -> str:
    """Render a 0..10 verdict confidence as ``N/10``, or ``not scored`` when unset."""
    return f"{confidence}/10" if confidence is not None else "not scored"


def _md_cell(text) -> str:
    """Neutralise structure-forging characters in an untrusted value bound for report Markdown."""
    # Inline MD NOT escaped or the `### N. [SEV]` re-parse breaks; span callers must fold backticks
    if text is None:
        return ""
    s = _MD_LINEBREAK_RX.sub(" ", str(text))
    s = _MD_INVISIBLE_RX.sub("", s)
    # "&" BEFORE "<"/">": translating angles first would re-escape the "&" they introduce (CWE-79)
    s = s.replace("&", "&amp;").translate(_ANGLE_ENTITY)
    # Double backslashes BEFORE escaping pipes, or a supplied \ re-exposes the raw delimiter
    return s.replace("\\", "\\\\").replace("|", "\\|").strip()


def _render_repro_block(detail: dict) -> list[str]:
    """Render an exploit-verification repro (curl + observed response), or no block on failure."""
    # Imported lazily to keep this module a leaf (stdlib + pydantic only).
    try:
        from vvaharness.exploit_verification.verify.model import ReproDetail
        from vvaharness.exploit_verification.verify.repro import render_block
        return render_block(ReproDetail.model_validate(detail))
    except Exception:
        return []
