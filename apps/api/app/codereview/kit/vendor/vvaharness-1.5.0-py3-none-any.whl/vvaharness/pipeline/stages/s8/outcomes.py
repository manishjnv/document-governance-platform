# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 8's output contract: a ranking and chains keyed by finding id, plus the reducer onto FinalReport."""
from __future__ import annotations

import itertools
import math
import re
from typing import NamedTuple

from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator
from pydantic.json_schema import SkipJsonSchema

from vvaharness.models import (
    Chain,
    FinalReport,
    Finding,
    LinkEvidence,
    RankedFinding,
    Severity,
)
from vvaharness.models.scan._coerce import text as _coerce_text
from vvaharness.models.scan.findings import NOT_RANKED_NOTE
from vvaharness.models.vocab import SEV_RANK
from vvaharness.pipeline.stages.s8 import validate as _validate
from vvaharness.report import cvss as _cvss
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.json_extract import extract_json


def _str_list(v: object) -> list[str]:
    """A list-of-ids field as list[str]; anything unrecognisable is [], never a validation error."""
    if v is None:
        return []
    if isinstance(v, str):
        return [v]
    if isinstance(v, list):
        return [x if isinstance(x, str) else str(x) for x in v]
    return []


# Plausibility ceiling for the wire-side carrier: a chain entry costs tens of output tokens, so a
# count above this is unprompted model text, not a drop tally
_CHAINS_INVALID_MAX = 1000


def _salvage(items: list, model: type[BaseModel]) -> tuple[list, int]:
    """``(kept, dropped)`` — *items* each validated as *model*, the unreadable ones dropped."""
    kept: list = []
    for item in items:
        try:
            kept.append(model.model_validate(item))
        except ValidationError:
            pass
    return kept, len(items) - len(kept)


class RankedEntry(BaseModel):
    finding_id: str = Field(description="Echo the FINDING id you were given, verbatim.")
    severity: str = Field(default="", description=
        "LEAVE EMPTY unless you are deliberately overriding the severity shown. final_severity "
        "takes the VulContextSeverity or CVSS band ahead of this value, so for any finding that "
        "has one your word here is discarded. One of critical, high, medium, low, info.")
    exploitability_notes: str = Field(default="", description=
        "AT MOST TWO SENTENCES: why this severity differs, naming the control that applies or "
        "fails. Omit entirely when you are only recording `feeds`.")
    feeds: list[str] = Field(default=[], description=
        "Ids of the findings this one SUPPLIES something to — a value, a privilege, a "
        "reachable state or an input the other finding needs — whether or not you can "
        "evidence the link. Record every such id; chain the ones you can evidence with "
        "link_evidence, the rest stay here. Never a finding at the same file:line, and "
        "never a precondition or amplifier (a root container, a missing header): those "
        "stay in exploitability_notes.")

    # Coerce per field, so one malformed scalar costs that entry alone, not the whole reply
    @field_validator("finding_id", "severity", "exploitability_notes",
                     mode="before")
    @classmethod
    def _coerce_str(cls, v: object) -> object:
        return _coerce_text(v)

    @field_validator("feeds", mode="before")
    @classmethod
    def _coerce_feeds(cls, v: object) -> object:
        return _str_list(v)


class ChainEntry(BaseModel):
    title: str = Field(description="The chain in a few words, e.g. 'SSRF -> metadata creds -> S3'.")
    steps: list[str] = Field(description=
        "The FINDING ids in exploitation order, at least two. Ids only, no prose. "
        "Two findings at the SAME file and line are one code fact, never two steps.")
    severity: str = Field(default="", description=
        "LEAVE EMPTY. The host derives a chain's severity from its steps and the lift gate caps "
        "it at the strongest constituent finding, so a value here is discarded.")
    blocked_by_controls: list[str] = Field(default=[], description=
        "Names of design controls that genuinely block this chain, if any.")
    narrative: str = Field(default="", description=
        "ONE sentence naming what the chain achieves that no single step does. The per-hop "
        "mechanism belongs in link_evidence, not here -- do not retell the steps.")
    # Defaulted, not required: schema enforcement would make one absent list a whole-report failure
    link_evidence: list[LinkEvidence] = Field(default=[], description=
        "ONE entry per adjacent pair in `steps`, IN ORDER (so len(steps) - 1 entries). Leave "
        "from_id/to_id EMPTY -- position already says which pair you mean and the host fills "
        "them. Give only `mechanism` and the file/line that shows the link holds. A link you "
        "cannot evidence means the chain is not real: drop the chain, do not invent one.")
    entry_reachability: str = Field(default="", description=
        "How the FIRST step is reached by the attacker you claim — cite the "
        "route/entry point and any binding or exposure fact you were given.")
    preconditions: list[str] = Field(default=[], description=
        "Non-default config or state this chain REQUIRES (e.g. 'requires "
        "--risk>=3, default is 1'). These are surfaced to the report reader, "
        "so a chain that only works off-default must say so here.")

    # Lax mode coerces neither int->str nor str->list, so `"severity": 5` would degrade the report
    @field_validator("title", "severity", "narrative", "entry_reachability",
                     mode="before")
    @classmethod
    def _coerce_str(cls, v: object) -> object:
        return _coerce_text(v)

    @field_validator("steps", "blocked_by_controls", "preconditions",
                     mode="before")
    @classmethod
    def _coerce_str_list(cls, v: object) -> object:
        return _str_list(v)

    @field_validator("link_evidence", mode="before")
    @classmethod
    def _coerce_links(cls, v: object) -> object:
        # Dropping to nothing leaves the chain unevidenced (annotated), not invalid. A bare-string
        # entry (cli free-text shape) is unplaceable, so dropped and counted
        if not isinstance(v, list):
            return []
        kept = [x for x in v if isinstance(x, (dict, LinkEvidence))]
        if len(kept) < len(v):
            COUNTERS.bump("s8_link_evidence_entry_invalid", len(v) - len(kept))
        return kept


# Declaration order is the property order every route sends: chains before the summary that
# describes them
class ChainReport(BaseModel):
    ranked_findings: list[RankedEntry] = Field(default=[], description=
        "SPARSE: an entry ONLY for a finding that feeds another one, or whose severity you are "
        "changing from the CVSS-derived value shown. Omit every other finding -- omitted ones "
        "ship with their CVSS severity, which is already correct. An empty list is a valid "
        "answer. Do NOT echo back findings you have nothing to add to.")
    chains: list[ChainEntry] = Field(default=[], description=
        "Chains of two or more findings. Empty is correct when no finding feeds another — "
        "an invented chain is worse than none.")
    summary: str = Field(description=
        "Executive summary, 2-4 sentences, written LAST: it may describe only the chains "
        "listed in `chains` and the ranking above — a path that is not a chain entry must "
        "not be claimed here.")
    # Harness-only, hidden from the model-facing schema: sdk/deepagents validate and re-dump
    # before the stage parses, so the count must ride in the dump, not on the instance
    chains_invalid: SkipJsonSchema[int] = 0

    @model_validator(mode="before")
    @classmethod
    def _salvage_entries(cls, data: object) -> object:
        # Backstop: an unsalvageable entry drops alone and counted; a non-list stays broken
        # wholesale (pinned degrade)
        if not isinstance(data, dict):
            return data
        data = dict(data)
        if "chains" not in data:
            COUNTERS.bump("s8_chains_key_absent")
        dropped: dict[str, int] = {}
        for field, model in (("ranked_findings", RankedEntry), ("chains", ChainEntry)):
            items = data.get(field)
            if isinstance(items, list):
                data[field], dropped[field] = _salvage(items, model)
        for field, n in dropped.items():
            if n:
                COUNTERS.bump(f"s8_{field}_entry_invalid", n)
        # Accumulated across validations so a backend re-dump keeps it; never schema-named, so
        # anything but an int in [0, _CHAINS_INVALID_MAX] is unprompted model text and reads as 0
        carried = data.get("chains_invalid")
        if type(carried) is not int or not 0 <= carried <= _CHAINS_INVALID_MAX:
            carried = 0
        data["chains_invalid"] = carried + dropped.get("chains", 0)
        return data


def parse_chain_reply(raw: str) -> ChainReport:
    """The reply as a ChainReport, salvaging JSON wrapped in prose; raises on anything else."""
    try:
        return ChainReport.model_validate_json(raw)
    except ValueError:
        return ChainReport.model_validate(extract_json(raw))


def finding_ids(findings: list[Finding]) -> dict[str, int]:
    """{id the model echoes -> index in *findings*}; the one place the mapping is defined."""
    return {f"f{i}": i for i in range(len(findings))}


CVSS_BAND_TO_SEV = {
    "critical": Severity.CRITICAL,
    "high": Severity.HIGH,
    "medium": Severity.MEDIUM,
    "low": Severity.LOW,
}

def _strongest(severities: list[Severity]) -> Severity:
    """The most severe band among *severities* (lower SEV_RANK = stronger)."""
    return min(severities, key=lambda s: SEV_RANK[s])


def _weakest(severities: list[Severity]) -> Severity:
    """The least severe band among *severities* -- the floor a derived chain rating starts from."""
    return max(severities, key=lambda s: SEV_RANK[s])


def _model_or_derived_chain_severity(raw_severity: str,
                                      hop_sevs: list[Severity]) -> tuple[Severity, bool]:
    """(severity, derived) for one chain: the reply's own word when it sent one, else the
    weakest shipped hop -- a blank `severity` is the schema's own instruction ("the host
    derives it"), not an asserted INFO, so it must not read as one."""
    parsed = _coerce_sev_or_none(raw_severity)
    if parsed is not None:
        return parsed, False
    COUNTERS.bump("s8_chain_severity_derived")
    return _weakest(hop_sevs), True


# The only customer-facing sentence the severity rule may add, and only on a granted lift
_LIFT_NOTE = "_Severity aligned to the highest-severity finding in this path._"

# A HELD severity as structured annotation; true of both cases (withheld lift, capped self-raise)
_CAP_ANNOTATION = ("Severity not raised for chain composition: this path's hops "
                   "are not fully evidenced, or a step supplies no attacker "
                   "capability.")


# Boundaries reject buf_f1, utils/f2, f1.py; a run joined by / - – — or .. is ONE token, and the
# tail guard rejects it whole (f1-f2.py, f42-f44x) so a backtrack cannot half-rewrite it
_PROSE_ID_JOIN = r"(?:/|[\-–—]|\.\.)"
_PROSE_ID_RX = re.compile(
    rf"(?<![\w./$-])f\d+(?:{_PROSE_ID_JOIN}f\d+)*\b(?!{_PROSE_ID_JOIN}f\d|\.\w)")
_PROSE_ID_SPLIT_RX = re.compile(rf"({_PROSE_ID_JOIN})")
# Any fence width: an id inside a backtick span is quoted code, not a citation
_CODE_SPAN_RX = re.compile(r"(`+[^`]*`+)")

# Annotated, never deleted: dropping an id naming no finding would hide the reply defect
_PROSE_ID_NOTE = ("This chain's prose cites finding id(s) {ids} that name no "
                  "finding in this report; they are printed as the reply wrote "
                  "them.")


def _remap_prose_ids(text: str, display: dict[str, str]) -> tuple[str, list[str]]:
    """``(rewritten, unresolved)`` — *text* with each prose ``fN`` as its ``#N`` per *display*."""
    if not text:
        return text, []
    unresolved: list[str] = []

    def _one(match: re.Match) -> str:
        """One matched token — a single id or a joined run — resolved as a whole or not at all."""
        # A half-rewritten run ("#1/f42") reads worse than the original, so resolve all or none
        token = match.group(0)
        parts = _PROSE_ID_SPLIT_RX.split(token)
        ids, joins = parts[0::2], parts[1::2]
        missing = [i for i in ids if display.get(i) is None]
        if missing:
            unresolved.extend(missing)
            return token
        nums = [int(i[1:]) for i in ids]
        if len(ids) == 2 and joins[0] != "/" and nums[0] < nums[1]:
            # Two ascending ids joined by a dash or ".." name an inclusive range: every member
            # must exist, or the range stays raw rather than guessing which middle id was meant
            members = [f"f{n}" for n in range(nums[0], nums[1] + 1)]
            gaps = [i for i in members if display.get(i) is None]
            if gaps:
                unresolved.extend(gaps)
                return token
            return "/".join(display[i] for i in members)
        # A list, a descending pair or a mixed run: each listed id in place, joiners kept
        return "".join(display[p] if k % 2 == 0 else p for k, p in enumerate(parts))

    # split() alternates literal text with captured code spans, so only even slots are prose
    parts = _CODE_SPAN_RX.split(text)
    for i in range(0, len(parts), 2):
        parts[i] = _PROSE_ID_RX.sub(_one, parts[i])
    return "".join(parts), list(dict.fromkeys(unresolved))


# Schema keys leak into the summary as jargon; each is reworded in place, never deleted
_SUMMARY_WORDING = (
    (re.compile(r"\b(the )chains (?:array|list)\b", re.IGNORECASE), r"\1chain list"),
    (re.compile(r"\branked_findings\b"), "ranking"),
    (re.compile(r"\blink_evidence\b"), "link evidence"),
)


def _reword_schema_terms(text: str) -> str:
    """*text* with each schema-key phrase outside code spans in plain words."""
    if not text:
        return text
    parts = _CODE_SPAN_RX.split(text)
    for i in range(0, len(parts), 2):
        for rx, repl in _SUMMARY_WORDING:
            parts[i] = rx.sub(repl, parts[i])
    return "".join(parts)


class _ChainProse(NamedTuple):
    """One chain entry's prose surfaces after the id remap, plus every id that resolved to nothing."""
    title: str
    narrative: str
    reachability: str
    blocked: list[str]
    preconditions: list[str]
    mechanisms: list[str]        # aligned with item.link_evidence
    missed: list[str]            # deduplicated, in order seen


def _remap_item_prose(item: ChainEntry, narrative: str,
                      display: dict[str, str]) -> _ChainProse:
    """EVERY prose surface of *item* through the ONE id mapping in one pass, with *narrative* passed in already hedge-annotated."""
    missed: list[str] = []

    def _one(text: str) -> str:
        out, gone = _remap_prose_ids(text, display)
        missed.extend(gone)
        return out

    title = _one(item.title)
    narrative = _one(narrative)
    reachability = _one(item.entry_reachability.strip())
    # Both are MODEL prose rendered verbatim; cleaned before the remap, so a dropped entry costs 0
    blocked = [_one(v) for v in
               _validate.clean_controls(item.blocked_by_controls)]
    preconditions = [_one(v) for v in _validate.clean_preconditions(item)]
    # Mechanisms render beside #N endpoints, so the same mapping, never two schemes in one row
    mechanisms = [_one(ln.mechanism.strip()) for ln in item.link_evidence]
    return _ChainProse(title, narrative, reachability, blocked, preconditions,
                       mechanisms, list(dict.fromkeys(missed)))


def sev_from_band(rating: str | None) -> Severity | None:
    """A CVSS qualitative band as a Severity; None for a missing band, so the caller falls through."""
    return CVSS_BAND_TO_SEV.get((rating or "").strip().lower())


def final_severity(finding, llm_label: Severity) -> Severity:
    """VulContextSeverity (environmental) first, else base CVSS, else the LLM's label; OffensivePriority is never folded in."""
    return (sev_from_band(getattr(finding, "vsvs_rating", None))
            or sev_from_band(getattr(finding, "cvss_rating", None))
            or llm_label)


_SEV_MISMATCH_NOTE = ("Model-assessed severity ({model}) differs from the "
                      "CVSS/VulContextSeverity band ({shipped}) that "
                      "determines the shipped rating.")


def severity_prose_mismatch(model_label: Severity, shipped: Severity) -> str:
    """Flag for a finding whose model severity word lost to the band :func:`final_severity` picked, or "" when they agree."""
    if model_label is shipped:
        return ""
    return _SEV_MISMATCH_NOTE.format(model=model_label.value,
                                     shipped=shipped.value)


def ranked_finding(finding, severity: Severity, notes: str) -> RankedFinding:
    """Wrap *finding* for the report, also stamping severity and notes in place so bare-``Finding`` holders see them."""
    finding.severity = severity
    finding.exploitability_notes = notes
    return RankedFinding(finding=finding, severity=severity,
                         exploitability_notes=notes)


def offensive_rank(finding) -> int:
    """OffensivePriority as a secondary sort key (P1 first, unset last), orthogonal to severity."""
    op = (getattr(finding, "offensive_priority", None) or "").strip().upper()
    return int(op[1]) if len(op) == 2 and op[0] == "P" and op[1].isdigit() else 9


def severity_sort_order(ranked: list[RankedFinding]) -> list[int]:
    """Index permutation by severity band then OffensivePriority (P1 first), shared by the hydrated report and the degraded fallback."""
    return sorted(range(len(ranked)),
                  key=lambda k: (SEV_RANK[ranked[k].severity],
                                 offensive_rank(ranked[k].finding)))


def _coerce_sev_or_none(s) -> Severity | None:
    """:func:`coerce_sev`'s parsing but ``None`` when nothing parses, so a caller can tell "asserted info" from "unreadable"."""
    if not s:
        return None
    key = str(s).strip().lower()
    try:
        return Severity(key)
    except ValueError:
        pass
    # Reuse report.cvss bands, never re-derive; "9.8/10" trims; NaN/inf/out-of-[0,10]/non-str fail
    if not isinstance(s, str):
        return None
    token = key.split("/", 1)[0].strip()
    try:
        score = float(token)
    except ValueError:
        return None
    if not math.isfinite(score) or not (0.0 <= score <= 10.0):
        return None
    return sev_from_band(_cvss.rating(score))


def coerce_sev(s) -> Severity:
    return _coerce_sev_or_none(s) or Severity.INFO


def _sort_and_remap(ranked: list[RankedFinding], ranked_orig_idx: list[int],
                    dropped) -> tuple[list[RankedFinding], dict[int, int], list]:
    """Severity-order *ranked*, remapping dropped ``canonical_idx`` onto fresh copies."""
    order = severity_sort_order(ranked)
    ranked = [ranked[k] for k in order]
    orig_sorted = [ranked_orig_idx[k] for k in order]
    orig_to_sorted = {orig: new_i for new_i, orig in enumerate(orig_sorted)}
    dropped_out = [
        d.model_copy(update={"canonical_idx": orig_to_sorted[d.canonical_idx]})
        if (d.reason == "DUPLICATE" and d.canonical_idx in orig_to_sorted)
        else d
        for d in dropped
    ]
    return ranked, orig_to_sorted, dropped_out


def templated_summary(ranked: list[RankedFinding]) -> str:
    """Deterministic executive summary over severity-band counts, used by the floor and as the suffix on a windowed model summary."""
    if not ranked:
        return "No verified findings."
    counts: dict[Severity, int] = {}
    for r in ranked:
        counts[r.severity] = counts.get(r.severity, 0) + 1
    bands = ", ".join(f"{counts[s]} {s.value}" for s in SEV_RANK
                      if counts.get(s))
    return f"{len(ranked)} verified finding(s): {bands}."


def deterministic_report(ctx, findings, dropped, raw_findings_count, metrics,
                         *, enrichment_failure: str) -> FinalReport:
    """The always-computable floor: a complete, ordered report with deterministic severities, no chains, and a templated summary."""
    # After a partial hydrate, callers must restore detection-time severity: f.severity is trusted
    for f in findings:
        # A partial hydrate may have stamped this; there is no model severity here to disagree
        f.severity_prose_mismatch = ""
    # Third leg is s4's carried label, read before ranked_finding stamps; INFO would discard it
    ranked = [ranked_finding(f, final_severity(f, f.severity),
                      "(enrichment unavailable — severity from CVSS or the "
                      "detection label)")
              for f in findings]
    ranked, _, dropped_out = _sort_and_remap(
        ranked, list(range(len(findings))), dropped)
    return FinalReport(
        repo_root=ctx.repo_root,
        findings=ranked,
        chains=[],
        dropped=dropped_out,
        raw_findings_count=raw_findings_count,
        metrics=metrics,
        summary=templated_summary(ranked),
        degraded=True,
        enrichment_unavailable=True,
        # The stable contract string; later writers append after a semicolon.
        degraded_reason=("chain/narrative enrichment unavailable: "
                         f"{enrichment_failure}"),
    )


def _positionally_filled(item: ChainEntry) -> list[LinkEvidence]:
    """*item*'s links, empty ids filled from adjacent ``steps`` pairs when one link per pair."""
    # Limitation: trusts the model's order; out-of-order empty-id links land on the wrong hop
    links = item.link_evidence
    if not links or len(links) != len(item.steps) - 1 \
            or any(ln.from_id.strip() or ln.to_id.strip() for ln in links):
        return links
    COUNTERS.bump("s8_chain_links_positionally_filled")
    return [ln.model_copy(update={"from_id": item.steps[k], "to_id": item.steps[k + 1]})
            for k, ln in enumerate(links)]


def _build_chain(item: ChainEntry, *, ranked: list[RankedFinding],
                 index_of: dict[str, int], orig_to_sorted: dict[int, int],
                 prose_ids: dict[str, str], repo_root,
                 window: set[int] | None, gate_on: bool,
                 checks_on: bool) -> Chain | None:
    """One ChainEntry hydrated into a report Chain through every deterministic gate, or None when it drops."""
    # Reads MODEL text, so before the pipeline's own notes; unconditional, unlike checks_on
    narrative, hedged = _validate.annotate_hedges(item.narrative)
    # Convention: a one-per-step reply (ids empty) drops entry 0; entry k+1 then describes how
    # step k+1 uses the output of step k, matching the one-per-pair shape _positionally_filled wants
    if (len(item.link_evidence) == len(item.steps) >= 2
            and all(not ln.from_id.strip() and not ln.to_id.strip()
                    for ln in item.link_evidence)):
        item = item.model_copy(update={"link_evidence": item.link_evidence[1:]})
        COUNTERS.bump("s8_chain_links_origin_dropped")
    # MODEL text only: the unresolved-step note quotes raw ids deliberately, so never re-count it
    prose = _remap_item_prose(item, narrative, prose_ids)
    narrative = prose.narrative

    steps = [index_of[s.strip()] for s in item.steps
             if s.strip() in index_of
             and (window is None or index_of[s.strip()] in window)]
    # Counted before the drop gate, so a dropped chain's hallucinated ids still reach telemetry
    unknown = [s for s in item.steps
               if s.strip() not in index_of
               or (window is not None and index_of[s.strip()] not in window)]
    if unknown:
        COUNTERS.bump("s8_chain_step_id_unknown", len(unknown))
    named = [orig_to_sorted[s] for s in steps if s in orig_to_sorted]
    # One file:line is one code fact, so collapse BEFORE the length test or a fake 2-hop survives
    remapped, dupes = _validate.collapse_same_location(named, ranked)
    if dupes:
        COUNTERS.bump("s8_chain_hop_same_location", dupes)
    if len(remapped) < 2:
        # Four causes; unresolved ids beat a collapse, since restoring them could have saved it
        COUNTERS.bump("s8_chain_dropped_unresolved_steps" if unknown
                      or not dupes else "s8_chain_dropped_same_location")
        return None
    # Capped so an oversized steps[] cannot balloon the note.
    if unknown:
        shown = unknown[:20]
        extra = "" if len(unknown) <= 20 else f" (+{len(unknown) - 20} more)"
        # A windowed-out id IS verified, just not shown, so the wording must not claim otherwise
        why = ("outside this pass's view (not in the verified set, or "
               "not sent to the windowed enrichment call)"
               if window is not None else "not in the verified set")
        narrative = (f"{narrative}\n\n_Note: this chain referenced finding "
                     f"ids {shown}{extra} that were {why}; they have "
                     "been omitted from the path above._").strip()

    # Only links evidencing a hop of the PRINTED path ship, ids rewritten to #N; a collapsed
    # step's endpoints are read as the survivor at its location
    filled = _positionally_filled(item)
    path_hops = set(itertools.pairwise(remapped))
    survivor = {_validate.location_key(ranked, s): s for s in remapped}
    alias = {s: survivor[_validate.location_key(ranked, s)] for s in named}
    links: list[LinkEvidence] = []
    for ln, mech in zip(filled, prose.mechanisms):
        src = alias.get(orig_to_sorted.get(index_of.get(ln.from_id.strip(), -1)))
        dst = alias.get(orig_to_sorted.get(index_of.get(ln.to_id.strip(), -1)))
        if (src, dst) in path_hops:
            # resolved_citation, as link_ok's gate reads; an unresolved one ships line 0
            _, cfile, cline = _validate.resolved_citation(
                repo_root, ln.file, ln.line)
            links.append(LinkEvidence(
                from_id=f"#{src + 1}", to_id=f"#{dst + 1}",
                mechanism=mech,
                file=cfile, line=cline))
    # Kept apart from coverage_short: a reply whose links all fail to place ships [] like a bare one
    if len(filled) > len(links):
        COUNTERS.bump("s8_chain_links_unplaced", len(filled) - len(links))

    # ONE verdict for gate+note, priced on the HYDRATED path and the links that SHIP, so the
    # printed coverage can never claim evidence the report does not carry
    links_ok, resolved_links, hops = _validate.link_ok(
        links, remapped, repo_root)
    hardening = _validate.hardening_steps(remapped, ranked)

    # Failed CHECKS only, one per kind: the lower-confidence partition prices len(quality_notes)
    quality_notes: list[str] = []
    disclosures: list[str] = []
    if checks_on:
        quality_notes.extend(_validate.quality_annotations(
            item.model_copy(update={"link_evidence": links}), remapped, ranked,
            repo_root, links_ok=links_ok, resolved=resolved_links, hops=hops,
            hardening=hardening))
    # Minus the ids the STEP note already named, or one doubt reads as two; consumed only here
    prose_missed = [t for t in prose.missed
                    if t not in {s.strip() for s in unknown}]
    if prose_missed:
        COUNTERS.bump("s8_chain_prose_id_unresolved", len(prose_missed))
        quality_notes.append(_PROSE_ID_NOTE.format(ids=prose_missed[:20]))

    # Lift only an UNEXPLAINED under-rating; FLOOR = deterministic vsvs/cvss bands, CAP = effective
    explained = bool(prose.blocked or prose.preconditions)
    hop_sevs = [ranked[st].severity for st in remapped]
    model_sev, derived = _model_or_derived_chain_severity(item.severity, hop_sevs)
    severity = model_sev
    hop_bands = [
        b for st in remapped
        if (b := (sev_from_band(ranked[st].finding.vsvs_rating)
                  or sev_from_band(ranked[st].finding.cvss_rating)))
    ]
    floor = _strongest(hop_bands) if hop_bands else None
    effective = _strongest(hop_sevs)
    # A promotion either way must be earned; OFF restores the ungated severities and counters
    allowed = (not gate_on
               or _validate.lift_allowed(links_ok, hardening, hedged))
    # Stamped by the producer that made the decision, so the renderer never re-derives it
    decision = ""
    # A derived severity has no asserted lower rating to protect, so "explained" cannot hold it
    # below the floor the way an actual model word can
    if floor is not None and SEV_RANK[model_sev] > SEV_RANK[floor] \
            and (derived or not explained):
        if allowed:
            severity = floor
            COUNTERS.bump("s8_chain_severity_lifted")
            narrative = f"{narrative}\n\n{_LIFT_NOTE}".strip()
        else:
            # The chain keeps the reply's rating, disclosed structurally, not in prose
            COUNTERS.bump("s8_chain_lift_suppressed")
            decision = "lift_withheld"
    elif SEV_RANK[severity] > SEV_RANK[effective] and not explained:
        # Under its strongest hop unexplained, but left alone: those bands may be model labels
        COUNTERS.bump("s8_chain_severity_under_hops")
    elif SEV_RANK[model_sev] < SEV_RANK[effective]:
        COUNTERS.bump("s8_chain_severity_raised")
        if not allowed:
            # Hard cap at the strongest hop: an unearned self-raise shipped reports at CRITICAL
            severity = effective
            COUNTERS.bump("s8_chain_severity_capped")
            decision = "self_raise_capped"
    # Not gated on chain_quality_checks: a held severity is a disclosure, not a failed check
    if decision:
        disclosures.append(_CAP_ANNOTATION)

    return Chain(
        title=prose.title or "Unnamed chain",
        steps=remapped,
        severity=severity,
        blocked_by_controls=prose.blocked,
        preconditions=prose.preconditions,
        link_evidence=links,
        entry_reachability=prose.reachability,
        # Each field is populated only by the knob that owns it; OFF leaves the DTO default
        quality_notes=quality_notes,
        disclosures=disclosures,
        severity_decision=decision,
        link_coverage=f"{resolved_links}/{hops}" if checks_on else "",
        narrative=narrative,
    )


def hydrate_report(data: ChainReport, ctx, findings, dropped,
                    raw_findings_count, metrics, *,
                    window: set[int] | None = None, cfg=None,
                    ) -> tuple[FinalReport, set[int]]:
    """``(report, covered)`` — the hydrated FinalReport plus the finding indices the chain pass actually ranked."""
    # window = indices shown (None=all); Finding has value __eq__, so carry the index, never index()
    index_of = finding_ids(findings)
    ranked: list[RankedFinding] = []
    ranked_orig_idx: list[int] = []
    covered: set[int] = set()
    claims: set[tuple[int, int]] = set()   # (owner, target) `feeds` pairs, original indices
    for item in data.ranked_findings:
        idx = index_of.get(item.finding_id.strip())
        if window is not None and idx is not None and idx not in window:
            # A real id the model was never shown — it cannot have judged it.
            idx = None
        if idx is None or idx in covered:
            COUNTERS.bump("s8_ranked_finding_id_unknown" if idx is None
                          else "s8_ranked_finding_id_repeated")
            continue
        covered.add(idx)
        for token in item.feeds:
            t = index_of.get(token.strip())
            if t is None or (window is not None and t not in window):
                # Counted, never echoed: an id naming nothing is untrusted text
                COUNTERS.bump("s8_chain_feeds_id_unknown")
            elif t != idx:
                claims.add((idx, t))
        parsed_sev = _coerce_sev_or_none(item.severity)
        # A blank severity is the schema's own instruction ("LEAVE EMPTY unless overriding"),
        # not an asserted INFO: the fallback is the finding's OWN carried severity, the same
        # third leg the omitted-finding path below uses, so a ranked entry with nothing to say
        # cannot silently downgrade a finding that has no CVSS/VulContextSeverity band
        shipped_sev = final_severity(findings[idx], parsed_sev or findings[idx].severity)
        # Own field, not prose: notes feed the remediation prompt; flagged only if the label parsed
        findings[idx].severity_prose_mismatch = (
            severity_prose_mismatch(parsed_sev, shipped_sev)
            if parsed_sev is not None else "")
        ranked.append(ranked_finding(
            findings[idx], shipped_sev, item.exploitability_notes,
        ))
        ranked_orig_idx.append(idx)

    for i, f in enumerate(findings):
        if i not in covered:
            note = (NOT_RANKED_NOTE
                    if window is None or i in window
                    else "(not sent to the enrichment pass — report windowed)")
            # Own carried severity, not INFO -- read before ranked_finding stamps f.severity
            ranked.append(ranked_finding(f, final_severity(f, f.severity),
                                  note))
            ranked_orig_idx.append(i)

    ranked, orig_to_sorted, dropped_out = _sort_and_remap(
        ranked, ranked_orig_idx, dropped)

    # A missing cfg or key reads as the shipped default (ON), never OFF
    gate_on = knob(cfg, "step8.severity_lift_gate", True)
    checks_on = knob(cfg, "step8.chain_quality_checks", True)
    dedup_on = knob(cfg, "step8.chain_dedup", True)

    # The ONE prose-id mapping; built AFTER the sort, or a #N names a different finding
    prose_ids = {token: f"#{orig_to_sorted[i] + 1}"
                 for token, i in index_of.items() if i in orig_to_sorted}
    # SAME table as the chains, else one id prints "#3" there and "f0" here; stamped on both copies
    for rf in ranked:
        remapped, notes_missed = _remap_prose_ids(rf.exploitability_notes, prose_ids)
        rf.exploitability_notes = remapped
        rf.finding.exploitability_notes = remapped
        if notes_missed:
            COUNTERS.bump("s8_chain_prose_id_unresolved", len(notes_missed))
    # The summary cites the same ids, through the SAME table, or it disagrees with its own chains
    summary, summary_missed = _remap_prose_ids(data.summary, prose_ids)
    if summary_missed:
        COUNTERS.bump("s8_chain_prose_id_unresolved", len(summary_missed))
    summary = _reword_schema_terms(summary)

    chains: list[Chain] = []
    chains_dropped = 0
    for item in data.chains:
        chain = _build_chain(item, ranked=ranked, index_of=index_of,
                             orig_to_sorted=orig_to_sorted,
                             prose_ids=prose_ids, repo_root=ctx.repo_root,
                             window=window, gate_on=gate_on,
                             checks_on=checks_on)
        if chain is None:
            chains_dropped += 1
        else:
            chains.append(chain)

    if chains_dropped:
        COUNTERS.bump("s8_chain_dropped", chains_dropped)

    # Chains built, claims compared: coverage is by step location, so dedup and the sort below
    # cannot change it. Disclosed, never promoted — a claim is not evidence
    unpromoted: list[tuple[int, int]] = []
    if checks_on:
        unpromoted = _validate.unpromoted_links(
            sorted((orig_to_sorted[o], orig_to_sorted[t]) for o, t in claims), chains, ranked)
        if unpromoted:
            COUNTERS.bump("s8_chain_link_unpromoted", len(unpromoted))

    chains_deduped = 0
    if dedup_on:
        chains, chains_deduped, pairs = _validate.dedup_chains(chains)
        if chains_deduped:
            COUNTERS.bump("s8_chain_deduped", chains_deduped)
        if pairs:
            # Counted as PAIRS, the unit the relation was measured in.
            COUNTERS.bump("s8_chain_near_duplicate", len(pairs))
        # Keyed on the TERMINAL step, not a chain ordinal, so it survives the sort; 6 refs, not 15
        siblings: dict[int, int] = {}
        for a, b in pairs:
            siblings[a] = siblings.get(a, 0) + 1
            siblings[b] = siblings.get(b, 0) + 1
        for i, n in siblings.items():
            # A disclosure, never a quality note: the paths are legitimately DISTINCT
            chains[i].disclosures.append(_validate.NEAR_DUPLICATE_NOTE.format(
                n=chains[i].steps[-1] + 1, others=n))

    # Band, then blocked after unblocked (a PRECONDITION is not a block); stable, so ties keep order
    chains.sort(key=lambda c: (SEV_RANK[c.severity], bool(c.blocked_by_controls)))

    return (FinalReport(
        repo_root=ctx.repo_root,
        findings=ranked,
        chains=chains,
        chains_dropped=chains_dropped,
        # Apart from chains_dropped, whose report sentence a merge would falsify
        chains_deduped=chains_deduped,
        chains_invalid=data.chains_invalid,
        unpromoted_links=unpromoted,
        dropped=dropped_out,
        raw_findings_count=raw_findings_count,
        metrics=metrics,
        summary=summary,
    )), covered
