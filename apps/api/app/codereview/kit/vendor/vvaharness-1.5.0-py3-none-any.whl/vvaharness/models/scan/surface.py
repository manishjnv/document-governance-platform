# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Code-location contracts: the surface an external scanner populates."""
from __future__ import annotations

import logging
from typing import Literal

from pydantic import BaseModel, field_validator

from vvaharness.models.scan._coerce import _coerce_enum, _coerce_int

log = logging.getLogger(__name__)

_EP_KINDS = {"network", "ipc", "file", "cli", "deserialization", "framework", "other"}
_EP_KIND_ALIAS = {
    "rpc": "network", "grpc": "network", "http": "network",
    "https": "network", "rest": "network", "api": "network",
    "graphql": "network", "websocket": "network", "ws": "network",
    "soap": "network", "tcp": "network", "udp": "network",
    "socket": "network", "webhook": "network", "endpoint": "network",
    "queue": "ipc", "message": "ipc", "mq": "ipc", "kafka": "ipc",
    "amqp": "ipc", "jms": "ipc", "pubsub": "ipc", "event": "ipc",
    "signal": "ipc", "pipe": "ipc", "bus": "ipc",
    "stdin": "cli", "argv": "cli", "command": "cli", "arg": "cli",
    "config": "file", "env": "file", "filesystem": "file", "fs": "file",
    "deserialize": "deserialization", "serde": "deserialization",
    "unmarshal": "deserialization", "parse": "deserialization",
    "pickle": "deserialization", "json": "deserialization",
    "spring": "framework", "django": "framework", "aspnet": "framework",
}


class EntryPoint(BaseModel):
    file: str
    function: str
    kind: Literal["network", "ipc", "file", "cli", "deserialization", "framework", "other"]
    reachable_from_unauth: bool = False

    @field_validator("kind", mode="before")
    @classmethod
    def _v_kind(cls, v):
        return _coerce_enum(v, _EP_KINDS, _EP_KIND_ALIAS, "other")


class Sink(BaseModel):
    """Unsafe function call site flagged by static grep."""
    file: str
    line: int = 0
    function: str                    # strcat, memcpy, sprintf, system, ...
    snippet: str = ""                # the offending line, ~120 chars max
    # From s0 seed-rule metadata, e.g. ["CWE-89"]; empty for agent-discovered sinks
    cwe: list[str] = []

    @field_validator("line", mode="before")
    @classmethod
    def _v_line(cls, v):
        return _coerce_int(v, 0)


class ModuleInfo(BaseModel):
    name: str
    files: list[str] = []
    loc: int = 0                     # rough lines of code
    purpose: str = ""                # one-line summary from the mapper

    @field_validator("loc", mode="before")
    @classmethod
    def _v_loc(cls, v):
        return _coerce_int(v, 0)
