# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The fields s4 cannot produce, filled from the repo on disk."""
from __future__ import annotations

import stat
from pathlib import Path

from vvaharness.detect.matcher import split_lines
from vvaharness.models import Finding, VulnClass
from vvaharness.pipeline.callgraph_consumer import best_source_from_seed
from vvaharness.util.counters import COUNTERS

# Capped: s4 spans whole handlers, and the snippet rides in the checkpoint and s6's prompt.
MAX_SNIPPET_LINES = 40


def _read_lines(path: Path | None) -> list[str] | None:
    """*path* split into lines, or None if absent or unreadable."""
    if path is None:
        return None
    try:
        return split_lines(path.read_text(errors="replace"))
    # MemoryError: _safe_path's cap is stat-based, so a file growing between stat and read is caught
    except (OSError, ValueError, MemoryError):
        return None


class FileCache:
    """Repo files read at most once each, since many findings share a file."""

    def __init__(self, repo_root: str | Path, max_kb: int = 1024):
        self.root = Path(repo_root)
        self._resolved_root = self.root.resolve()
        self._max_bytes = max(1, int(max_kb)) * 1024
        self._lines: dict[str, list[str] | None] = {}

    def _safe_path(self, rel: str) -> Path | None:
        """*rel* resolved for reading, or None unless it is safely contained."""
        try:
            if Path(rel).is_absolute():
                return None
            target = (self.root / rel).resolve()
            target.relative_to(self._resolved_root)
            st = target.stat()  # stat first: opening a FIFO would block
            if not stat.S_ISREG(st.st_mode) or st.st_size > self._max_bytes:
                return None
            return target
        except (OSError, ValueError, RuntimeError):
            return None

    def lines(self, rel: str) -> list[str] | None:
        """*rel*'s lines, or None when it cannot be read; cached either way."""
        if rel not in self._lines:
            self._lines[rel] = _read_lines(self._safe_path(rel))
        return self._lines[rel]

    def line_count(self, rel: str) -> int | None:
        """*rel*'s line count, or None when it cannot be read (s6's EOF gate)."""
        lines = self.lines(rel)
        return None if lines is None else len(lines)


def snippet(f: Finding, lines: list[str]) -> str:
    """The real text of *f*'s span, capped."""
    start = max(1, int(f.line_start))
    if start > len(lines):
        return ""
    want = max(start, int(f.line_end or start))
    end = min(want, start + MAX_SNIPPET_LINES - 1, len(lines))
    body = "\n".join(lines[start - 1:end])
    return f"{body}\n… (span continues past line {end})" if want > end else body


def _sink_ref(f: Finding) -> str:
    """*f*'s own sink ref, else its reported location."""
    return (f.sink_ref or "").strip() or f"{f.file}:{max(1, int(f.line_start))}"


def _origin_ref(f: Finding, sink: str, anchors: dict[str, list[int]],
                seeds: dict[str, list[list[str]]]) -> str:
    """*f*'s own origin ref, else the nearest entry anchor, else a seed taint path."""
    own = (f.source_ref or "").strip()
    if own:
        return own
    if f.vuln_class == VulnClass.INFO_LEAK:
        return sink
    near = anchors.get(f.file) or ()
    if near:
        return f"{f.file}:{min(near, key=lambda ln: abs(ln - int(f.line_start)))}"
    return best_source_from_seed(seeds.get(f.file, ())) or ""


def refs(f: Finding, anchors: dict[str, list[int]],
         seeds: dict[str, list[list[str]]]) -> dict:
    """The evidence-ref update for *f*, with provenance for whatever was synthesized."""
    sink = _sink_ref(f)
    origin = _origin_ref(f, sink, anchors, seeds)
    empty = [name for name, own in (("sink_ref", f.sink_ref), ("source_ref", f.source_ref))
             if not (own or "").strip()]
    new = {"sink_ref": sink or None, "source_ref": origin or None}
    # Provenance only for synthesized values: a source_ref that STAYS empty is not backfilled
    filled = [name for name in empty if new[name]]
    if not filled:
        return {}
    return {**{name: new[name] for name in empty},
            "backfilled_refs": sorted(set(f.backfilled_refs) | set(filled))}


def enrich(f: Finding, cache: FileCache, anchors: dict[str, list[int]],
           seeds: dict[str, list[list[str]]], reanchorer=None) -> Finding:
    """*f* with its snippet and evidence refs filled in."""
    if reanchorer is not None:
        f = reanchorer.apply(f)
    update: dict = {}
    lines = cache.lines(f.file)
    if lines is not None and not f.code_snippet.strip():
        body = snippet(f, lines)
        if body:
            update["code_snippet"] = body
            COUNTERS.bump("s5_snippet_filled")
    update.update(refs(f, anchors, seeds))
    if "backfilled_refs" in update:
        COUNTERS.bump("s5_refs_backfilled")
    return f.model_copy(update=update) if update else f
