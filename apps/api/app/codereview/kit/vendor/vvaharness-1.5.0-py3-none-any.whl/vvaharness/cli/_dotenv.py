# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Selection and loading of a trusted .env from cwd or home."""
from __future__ import annotations
from vvaharness.util import logs

import os
import stat
from pathlib import Path
from vvaharness.util import console
from vvaharness.util.events import Event

log = logs.get_logger(__name__)


def _dotenv_path_is_trusted(path: Path) -> bool:
    """Reject unsafe POSIX ownership/modes; exact-location checks protect other OSes."""
    try:
        entries = (path.parent.stat(), path.stat())
    except OSError:
        return False
    get_euid = getattr(os, "geteuid", None)
    if get_euid is None:
        return True
    effective_uid = get_euid()
    for entry in entries:
        if entry.st_uid != effective_uid:
            return False
        if entry.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
            return False
    return True

def _dotenv_selection(
    repo: str | None = None, *, warn: bool = False,
) -> tuple[Path | None, str | None, tuple[Path, ...]]:
    """Return the selected dotenv path, its source, and rejected candidates."""
    roots: list[tuple[str, Path]] = []
    for source, get_root in (("cwd", Path.cwd), ("home", Path.home)):
        try:
            roots.append((source, get_root().resolve()))
        except (OSError, RuntimeError):
            continue

    rejected: list[Path] = []
    seen_roots: set[Path] = set()
    for source, root in roots:
        if root in seen_roots:
            continue
        seen_roots.add(root)
        candidate = root / ".env"
        if not candidate.is_file():
            continue
        try:
            path = candidate.resolve(strict=True)
        except OSError:
            continue
        if path.parent != root or not _dotenv_path_is_trusted(path):
            rejected.append(candidate)
            if warn:
                log.warning(Event.DOTENV_UNTRUSTED, path=candidate,
                            override="VVAHARNESS_ALLOW_CWD_CONFIG=1")
            continue
        if repo and not os.environ.get("VVAHARNESS_ALLOW_CWD_CONFIG"):
            from vvaharness.orchestrator.config_paths import _path_within
            if _path_within(path, repo):
                rejected.append(candidate)
                if warn:
                    log.warning(Event.DOTENV_INSIDE_TARGET, path=path,
                                override="VVAHARNESS_ALLOW_CWD_CONFIG=1")
                continue
        return path, source, tuple(rejected)
    return None, None, tuple(rejected)

def _dotenv_path(repo: str | None = None, *, warn: bool = False) -> Path | None:
    """Return the first trusted cwd/home ``.env`` accepted for this invocation."""
    return _dotenv_selection(repo, warn=warn)[0]

def _load_dotenv(repo: str | None = None) -> None:
    """Load a trusted .env from exactly cwd or home, never an arbitrary ancestor."""
    try:
        from dotenv import load_dotenv
    except ImportError:
        return

    path = _dotenv_path(repo, warn=True)
    if path is None:
        return
    load_dotenv(path, override=False)
    console.write(f"  [env] loaded {path}")
