# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""API-contract artefacts: OpenAPI/Swagger/Protobuf/GraphQL/WSDL/META-INF."""
from __future__ import annotations

import fnmatch

_API_SURFACE_GLOBS = (
    "*openapi*.y*ml", "*openapi*.json",
    "*swagger*.y*ml", "*swagger*.json",
    "*.proto", "*.graphql", "*.graphqls",
    "*.avsc", "*.wsdl", "*.thrift",
    "*META-INF/*", "*AndroidManifest.xml",
)


def gather_api_artefacts(full_files: list[str], max_api_artefacts: int) -> list[str]:
    """Files matching an API-contract glob, in file-list order, capped at `max_api_artefacts`."""
    artefacts: list[str] = []
    for rel in full_files:
        for g in _API_SURFACE_GLOBS:
            if fnmatch.fnmatchcase(rel, g) or fnmatch.fnmatchcase(rel.lower(), g):
                artefacts.append(rel)
                break
    return artefacts[:max_api_artefacts]
