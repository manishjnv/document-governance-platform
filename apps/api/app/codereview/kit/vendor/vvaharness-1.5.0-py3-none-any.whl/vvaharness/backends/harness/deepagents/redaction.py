# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Read-only session middleware: redact file content, remove the write tools."""

# No redaction hook on read_file/grep, so mask text AND non-text content here; deny rules
# FAIL OPEN, so also withhold writes

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from langchain.agents.middleware.types import AgentMiddleware
from langchain_core.messages import ToolMessage

from vvaharness.backends.harness.deepagents.exclude_tools import ExcludeTools
from vvaharness.backends.harness.deepagents.models import DELETE_TOOL_NAME
from vvaharness.backends.harness.models import NATIVE_CONTENT_TOOLS, NATIVE_WRITE_TOOLS
from vvaharness.backends.llm.tools import sanitize_packed_text
from vvaharness.report.redact import redact_counts

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from langchain.agents.middleware.types import ToolCallRequest
    from langgraph.types import Command


def _redact_block(block: Any, rel: str) -> Any:
    """A str or {"type": "text"} block, masked; any other block becomes the binary marker."""
    is_text_dict = isinstance(block, dict) and block.get("type") == "text"
    if isinstance(block, str) or is_text_dict:
        text = block if isinstance(block, str) else block.get("text", "")
        masked = redact_counts(sanitize_packed_text(text, rel))[0]
        return masked if isinstance(block, str) else {**block, "text": masked}
    if not isinstance(block, dict):
        return block
    return {"type": "text", "text": f"[binary content elided: {rel or 'file'} is not text]"}


def _redact_message(message: ToolMessage | Command[Any]) -> ToolMessage | Command[Any]:
    """Mask credential material in a ToolMessage's content, in place; elide any non-text block."""
    if not isinstance(message, ToolMessage):
        return message
    rel = message.additional_kwargs.get("read_file_path", "")
    content = message.content
    if isinstance(content, str) and content:
        message.content = redact_counts(sanitize_packed_text(content, rel))[0]
    elif isinstance(content, list):
        message.content = [_redact_block(block, rel) for block in content]
    return message


def _redact_if_content_tool(
    request: ToolCallRequest, result: ToolMessage | Command[Any]
) -> ToolMessage | Command[Any]:
    """Mask *result* when *request* called a content-returning native tool."""
    if request.tool_call.get("name") in NATIVE_CONTENT_TOOLS:
        return _redact_message(result)
    return result


class RedactToolResults(AgentMiddleware):
    """Mask PII/credentials in content-returning native filesystem tool results."""

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage | Command[Any]],
    ) -> ToolMessage | Command[Any]:
        """Run the tool call, masking the result when it carries file content."""
        return _redact_if_content_tool(request, handler(request))

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command[Any]]],
    ) -> ToolMessage | Command[Any]:
        """Async counterpart of :meth:`wrap_tool_call`."""
        return _redact_if_content_tool(request, await handler(request))


def read_only_middleware(
    extra_excluded: frozenset[str] = frozenset(),
) -> list[AgentMiddleware]:
    """Middleware every read-only agent needs, parent and subagents alike."""
    # Parent stack ONLY: subagents need their own copy; delete is separate; never a 2nd ExcludeTools
    excluded = NATIVE_WRITE_TOOLS | frozenset({DELETE_TOOL_NAME}) | extra_excluded
    return [RedactToolResults(), ExcludeTools(excluded)]


__all__ = [
    "RedactToolResults",
    "read_only_middleware",
]
