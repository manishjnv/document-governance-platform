# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared exception-chain walk; belongs in the lowest layer since errlog calls it, below backends."""
from __future__ import annotations


class S2HollowAfterRetry(Exception):
    """Both the primary threat-model call and its tool-free retry produced nothing s3 can mint."""

    reason: str

    def __init__(self, reason: str) -> None:
        super().__init__(
            f"s2 produced no usable threat model ({reason}) and the tool-free retry did not "
            f"either; s3-s8 would run with zero threat units, so the scan stops here")
        self.reason = reason


def exception_chain(exc: BaseException) -> list[BaseException]:
    """The ``__cause__`` chain under *exc*, outermost first; cause-only and cycle-guarded by id."""
    links: list[BaseException] = [exc]
    seen: set[int] = {id(exc)}
    while True:
        cause = links[-1].__cause__
        if cause is None or id(cause) in seen:
            break
        seen.add(id(cause))
        links.append(cause)
    return links
