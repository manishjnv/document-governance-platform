# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Degenerate-response detector for LLM backend return values (VVAH-E003)."""
from __future__ import annotations
from vvaharness.util import logs

import threading
from collections.abc import Callable, Iterator, Mapping, Sequence
from contextlib import contextmanager

from vvaharness.backends.harness.models import (
    AuthenticationError,
    DegenerateResponseError,
    HarnessCLINotFoundError,
    ProxyError,
    ToolStateNotRoundTrippedError,
    TruncatedResponseError,
)

# Cycle-safe: backends/llm/__init__ is import-free and models.py imports only util.exceptions/tokens
from vvaharness.backends.llm.models import (
    REFUSAL_RETRY_ATTEMPTED_COUNTER,
    REFUSAL_RETRY_RECOVERED_COUNTER,
    GuardrailBlocked,
    ModelRefusal,
    finish_truncated,
    reply_finish,
)

# Cycle-safe at module scope: report.redact is stdlib-only and _errlog already imports it
from vvaharness.report.redact import redact, redact_counts
from vvaharness.util import errlog as _errlog
from vvaharness.util.counters import COUNTERS
from vvaharness.util.exceptions import exception_chain
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

# ── Configuration ────────────────────────────────────────────────────────────

_DEFAULT_MIN_CHARS = 150
_DEFAULT_MIN_TOKENS = 30
_DEGENERATE_MAX_CONSECUTIVE = 3
# VVAH-E003 reply head: 55 records from one run were un-root-causable without it; keep it small
_RAW_HEAD_CHARS = 300

# ── State ────────────────────────────────────────────────────────────────────

_lock = threading.Lock()
_consecutive: dict[str, int] = {}
# Per-stage overrides of the _DEFAULT_MIN_* floors; None in either slot keeps that axis' default.
_stage_floors: dict[str, tuple[int | None, int | None]] = {}


def reset_counters() -> None:
    """Reset all consecutive-failure counters (call between repos in batch runs)."""
    with _lock:
        _consecutive.clear()


@contextmanager
def stage_floors(
    stage: str,
    *,
    min_chars: int | None = None,
    min_tokens: int | None = None,
) -> Iterator[None]:
    """Scoped per-stage override of the VVAH-E003 minimum-response floors."""
    with _lock:
        prev = _stage_floors.get(stage)
        _stage_floors[stage] = (
            int(min_chars) if min_chars is not None else None,
            int(min_tokens) if min_tokens is not None else None,
        )
    try:
        yield
    finally:
        with _lock:
            if prev is None:
                _stage_floors.pop(stage, None)
            else:
                _stage_floors[stage] = prev


# ── Public API ───────────────────────────────────────────────────────────────

def output_tokens_for_gate(usage: Mapping[str, object] | None) -> int | None:
    """The ``output_tokens`` value to hand :func:`check_response_quality`."""
    # Absent vs zero: None = not measured, 0 IS degenerate; never `or 0` at a call site
    if usage is None:
        return None
    raw = usage.get("output_tokens")
    if raw is None:
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        # A non-numeric field is not a measurement either; do not let it read as zero output.
        return None


def check_response_quality(
    text: str,
    stage: str = "",
    *,
    min_chars: int | None = None,
    output_tokens: int | None = None,
    expected_markers: Sequence[str] | None = None,
) -> None:
    """Validate that *text* meets the minimum quality bar for *stage*."""
    with _lock:
        ov_chars, ov_tokens = _stage_floors.get(stage, (None, None))
    if min_chars is None:
        min_chars = ov_chars if ov_chars is not None else _DEFAULT_MIN_CHARS
    min_tokens = ov_tokens if ov_tokens is not None else _DEFAULT_MIN_TOKENS
    stripped = (text or "").strip()
    reasons: list[str] = []

    if len(stripped) < min_chars:
        reasons.append(
            f"response too short ({len(stripped)} chars, threshold={min_chars})"
        )

    if output_tokens is not None and output_tokens < min_tokens:
        reasons.append(
            f"output token count too low ({output_tokens} tokens, "
            f"threshold={min_tokens})"
        )

    if expected_markers:
        missing = [m for m in expected_markers if m not in stripped]
        if missing:
            reasons.append(f"expected marker(s) absent: {missing!r}")

    if not reasons:
        with _lock:
            _consecutive.pop(stage, None)
        return

    # ── Degenerate response detected ─────────────────────────────────────────
    with _lock:
        count = _consecutive.get(stage, 0) + 1
        _consecutive[stage] = count

    summary = "; ".join(reasons)

    if count < _DEGENERATE_MAX_CONSECUTIVE:
        log.warning(Event.RESPONSE_DEGENERATE_ACCEPTED, error_code="VVAH-E003", stage=stage,
                    consecutive=f"{count}/{_DEGENERATE_MAX_CONSECUTIVE}", detail=summary)
        _errlog.log(
            stage or "quality",
            stage or "response_quality",
            f"VVAH-E003 warning ({count}/{_DEGENERATE_MAX_CONSECUTIVE}): {summary}",
            error_code=DegenerateResponseError.error_code,
            # redact BEFORE the cap, never after: capping first bisects a credential past a pattern
            raw_head=redact(stripped)[:_RAW_HEAD_CHARS],
            # recovered=True: an intermediate warning still returns the response to the caller.
            recovered=True,
        )
        return

    # Reset to 1 so warnings restart rather than every subsequent call re-raising.
    with _lock:
        _consecutive[stage] = 1

    # `threshold` must name the axis that FAILED; hard-wired min_chars misreported token-only trips
    char_axis_failed = len(stripped) < min_chars
    raise DegenerateResponseError(
        summary,
        stage=stage,
        response_len=len(stripped),
        threshold=min_chars if char_axis_failed else 0,
        consecutive=count,
    )


# Structured-output failure detection: ONE shared predicate, plus the retry-once-unforced wrapper

class StructuredOutputRejected(Exception):
    """Marker: a non-deepagents backend's own forced-tool extraction rejected the reply."""

    # via:sdk re-raises as this class (no langchain names); via:openai re-asks, never raises this

    def __init__(self, message: str, *, finish: str | None = None) -> None:
        super().__init__(message)
        #: The rejected final's end marker (Anthropic ``stop_reason``), read by structured_failure_detail
        self.finish = finish


#: Structured-validation failure names, not transport/auth; matched by NAME to keep langchain out
_STRUCTURED_OUTPUT_FAILURE_NAMES = (
    "StructuredOutputValidationError",
    "OutputParserException",
    "StructuredOutputRejected",
)


def is_structured_output_failure(exc: BaseException) -> bool:
    """True when *exc* is a rejected structured reply, not a transport error."""
    seen: set[int] = set()
    cur: BaseException | None = exc
    while cur is not None and id(cur) not in seen:
        seen.add(id(cur))
        # A refusal/guardrail link is final: a resend repeats the blocked prompt
        if isinstance(cur, GuardrailBlocked):
            return False
        if type(cur).__name__ in _STRUCTURED_OUTPUT_FAILURE_NAMES:
            return True
        if any(n in str(cur) for n in _STRUCTURED_OUTPUT_FAILURE_NAMES):
            return True
        cur = cur.__cause__ or cur.__context__
    return False


def is_truncated_without_retry(exc: BaseException) -> bool:
    """True when *exc* is a VVAH-E005 the route could not retry at a larger budget."""
    return isinstance(exc, TruncatedResponseError) and not exc.retried


#: Run-log caps: the cause is redacted BEFORE the cut; a provider's end marker is untrusted metadata
_FAILURE_DETAIL_CHARS = 300
_FINISH_MARKER_CHARS = 40


def structured_failure_detail(exc: BaseException) -> tuple[str, bool]:
    """(redacted cause plus the rejected final's ``finish=`` marker, whether that final was cut off)."""
    chain = exception_chain(exc)
    # The first structured link names which schema failed; the root adds what it does not say
    link = next((c for c in chain if type(c).__name__ in _STRUCTURED_OUTPUT_FAILURE_NAMES),
                chain[-1])
    root = chain[-1]
    cause = f"{type(link).__name__}: {link}"
    if root is not link and str(root) not in str(link):
        cause += f" <- {type(root).__name__}: {root}"
    # redact_counts, not redact: this seam runs inside the S4/S6 worker pools (redact.last_counts)
    detail = redact_counts(cause)[0][:_FAILURE_DETAIL_CHARS]
    # Any route's marker (stop_reason / finish_reason / incomplete_details.reason): sdk's
    # StructuredOutputRejected.finish, or the rejected final langchain's
    # StructuredOutputValidationError carries as ai_message
    for c in chain:
        meta = getattr(getattr(c, "ai_message", None), "response_metadata", None)
        finish = getattr(c, "finish", None) or (
            reply_finish(meta) if isinstance(meta, Mapping) else None)
        if finish:
            marker = redact_counts(str(finish))[0][:_FINISH_MARKER_CHARS]
            return f"{detail}; finish={marker}", finish_truncated(finish)
    return detail, False


def _resending_refusal_once(dispatch: Callable[..., str], label: str, *, stage: str,
                            allowed: Callable[[], bool] | None = None) -> Callable[..., str]:
    """*dispatch*, with ONE identical resend of the first ModelRefusal across all its sends."""
    left = 1

    def send(*, drop_thinking: bool) -> str:
        nonlocal left
        try:
            return dispatch(drop_thinking=drop_thinking)
        except ModelRefusal as exc:
            # Read at refusal time: an abandoned caller must not pay for a second session
            if left <= 0 or (allowed is not None and not allowed()):
                raise
            left -= 1
            refused = exc
        COUNTERS.bump(REFUSAL_RETRY_ATTEMPTED_COUNTER)
        # redact_counts: runs inside the S4/S6 worker pools
        log.warning(Event.MODEL_REFUSAL_RESEND, stage=stage, label=label,
                    route=refused.route or "-", category=refused.category or "unspecified",
                    detail=redact_counts(str(refused))[0][:_FAILURE_DETAIL_CHARS])
        # recovered=True: records the attempt; a second refusal is the caller's final record
        _errlog.log(stage, label, refused, reason="refusal_retry_attempted",
                    route=refused.route, recovered=True)
        # Outside the except, so a second refusal is raised unchained
        raw = dispatch(drop_thinking=drop_thinking)
        COUNTERS.bump(REFUSAL_RETRY_RECOVERED_COUNTER)
        return raw

    return send


def dispatch_or_retry_unforced(dispatch: Callable[..., str], label: str, *,
                               stage: str,
                               may_retry: Callable[[], bool] | None = None,
                               effort: str | None = None,
                               resend_refusal: bool = False,
                               may_resend_refusal: Callable[[], bool] | None = None) -> str:
    """*dispatch*'s reply; a schema rejection or an at-cap clip gets one resend without the tier."""
    # effort can leave the tool unforced on some routes (a prose end lost 25/25 S4 units), and the
    # tier's thinking is billed inside the same output budget, so a clip the backend could not
    # double (E005, retried=0) has one lever left: the same budget with no tier sent (always-on
    # models then think at their default effort). *effort* is the tier the resend actually
    # removes from the request (deepagents.droppable_effort).
    # *resend_refusal*: the call's first ModelRefusal gets one identical resend, vetoed when
    # *may_resend_refusal* answers False; the only refusal retry (GuardrailBlocked vetoes the rest).
    if resend_refusal:
        dispatch = _resending_refusal_once(dispatch, label, stage=stage,
                                           allowed=may_resend_refusal)
    try:
        return dispatch(drop_thinking=False)
    except Exception as exc:
        clipped = effort is not None and is_truncated_without_retry(exc)
        if not (clipped or is_structured_output_failure(exc)):
            raise
        if may_retry is not None and not may_retry():
            raise
        # The cause is named so a log can tell prose from a cut-off from a validator failure
        detail, cut_off = structured_failure_detail(exc)
    kind = "truncated" if clipped else "structured"
    event = Event.REPLY_CLIPPED_RETRY if clipped else Event.STRUCTURED_REPLY_REJECTED_RETRY
    COUNTERS.bump(f"{stage}_{kind}_retry_attempted")
    if cut_off:
        # The rejected final hit its output budget: the report counts these apart so the
        # operator can shrink what the call packs (or lower effort) until the first call fits
        COUNTERS.bump("llm_structured_retry_truncated")
    log.warning(event, stage=stage, label=label, detail=detail)
    # Outside the except so a failed resend carries no chain to the first failure, which
    # is_structured_output_failure and errlog's error_code walk: a transport error is its own
    raw = dispatch(drop_thinking=True)
    COUNTERS.bump(f"{stage}_{kind}_retry_recovered")
    return raw


# Timeout detection by class NAME, not imported (no anthropic/openai/httpx); walks the cause chain

#: Provider-stack timeout class names, NONE of which subclasses the builtin ``TimeoutError``.
_TIMEOUT_FAILURE_NAMES = frozenset({
    "TimeoutExpired",
    "APITimeoutError",
    "TimeoutException",
    "ConnectTimeout",
    "ReadTimeout",
    "WriteTimeout",
    "PoolTimeout",
})


def is_timeout_failure(exc: BaseException) -> bool:
    """True when *exc* (or anything it wraps) is a call timeout."""
    # Types only, never message text, so an error merely mentioning "timeout" is not reclassified
    seen: set[int] = set()
    cur: BaseException | None = exc
    while cur is not None and id(cur) not in seen:
        seen.add(id(cur))
        # A refusal/guardrail link is final: a timeout split resends the blocked prompt
        if isinstance(cur, GuardrailBlocked):
            return False
        if isinstance(cur, TimeoutError) or type(cur).__name__ in _TIMEOUT_FAILURE_NAMES:
            return True
        cur = cur.__cause__ or cur.__context__
    return False


_CONNECTION_FAILURE_NAMES = frozenset({
    "APIConnectionError",
    "ModelConnectionError",
    "TransportError",
})


def is_connection_failure(exc: BaseException) -> bool:
    """True when *exc* (or anything it wraps) is a dropped connection, never a timeout or a status."""
    if is_timeout_failure(exc):
        return False
    seen: set[int] = set()
    cur: BaseException | None = exc
    connection = False
    while cur is not None and id(cur) not in seen:
        seen.add(id(cur))
        if isinstance(getattr(cur, "status_code", None), int):
            return False
        if {cls.__name__ for cls in type(cur).__mro__} & _CONNECTION_FAILURE_NAMES:
            connection = True
        cur = cur.__cause__ or cur.__context__
    return connection


_DETERMINISTIC_FAILURE_TYPES = (
    AuthenticationError, ProxyError, ToolStateNotRoundTrippedError, HarnessCLINotFoundError,
)


def is_deterministic_failure(exc: BaseException) -> bool:
    """True when *exc* (or anything it wraps) will fail the same way on every retry."""
    return any(isinstance(err, _DETERMINISTIC_FAILURE_TYPES) for err in exception_chain(exc))
