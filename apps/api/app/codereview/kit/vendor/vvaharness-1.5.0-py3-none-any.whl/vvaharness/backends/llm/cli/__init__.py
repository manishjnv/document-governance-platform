# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The `claude` CLI backend: the namespace registry.py resolves."""
from __future__ import annotations

import json
import os
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Final, cast

from vvaharness.backends.harness.deepagents.limits import MODEL_MAX_OUTPUT_TOKENS
from vvaharness.backends.harness.models import (
    AuthenticationError,
    CallTimeoutError,
    EffortLevel,
    ProxyError,
    TruncatedResponseError,
    truncated_below_budget,
)
from vvaharness.backends.llm import cache as _cache
from vvaharness.backends.llm.cli.cancel import (
    _ABORT,
    _ABORT_HOOKS,
    _NEW_GROUP_KW,
    _kill_tree,
    _stop_tree,
    abort,
    aborted,
    register_abort_hook,
    reset_abort,
)
from vvaharness.backends.llm.cli.discovery import (
    _CLAUDE_CMD,
    _caps_cache,
    _cli_capabilities,
    _extract_envelope_error,
    _find_claude_cmd,
    _format_cli_error,
    _safe_permission_mode,
    _short_cmd,
    _tail,
    _which_abs,
)
from vvaharness.backends.llm.cli.env import (
    _NO_REFUSAL_RESEND_ENV,
    _build_tls_env,
    _call_env,
    _cfg,
    _effective_effort,
    _effort_argv,
    _session_pins,
    _tls_extra,
    configure,
)
from vvaharness.backends.llm.cli.envelope import (
    _PARSED_USAGE_CACHE_KEYS,
    _note_unparsed_cache_keys,
    _parse_envelope,
    _raise_if_refused,
    _structured_text,
    parse_json_response,
)
from vvaharness.backends.llm.cli.oneshot import (
    prompt,
)
from vvaharness.backends.llm.cli.process import (
    _WATCHDOG_STOPPED,
    _run,
    _run_streaming,
    _was_stopped,
    stream_trace,
)
from vvaharness.backends.llm.cli.retry import (
    _AUTH_FAILURE,
    _PENDING_MAX_RETRIES,
    _PROXY_FAILURE,
    _is_auth_failure,
    _is_pending_result,
    _is_proxy_failure,
    _is_transient_failure,
    _log_truncation_retry,
    _log_usage,
    _proxy_failure_evidence,
    _run_with_retry,
    _terminal_result_fields,
    _truncation_cap,
    _truncation_error,
)
from vvaharness.backends.llm.cli.session import (
    _AGENTIC_TIMEOUT,
    _READ_DENY_DIRS,
    _WARNED_CAPS,
    _bare_tool_names,
    _finalize_via_resume,
    _recover_timed_out_session,
    _TurnWatchdog,
    agentic,
    log,
    release_pinned_session,
    resume_agentic,
)
from vvaharness.backends.llm.models import (
    ANTHROPIC_STOP_MAX_TOKENS,
    ANTHROPIC_STOP_REFUSAL,
    CLI_CONN_TRANSIENT_RX,
    CLI_CONTINUED_REPLIES_COUNTER,
    CLI_RETRYABLE_STATUS,
    CLI_STATUS_429_RX,
    CLI_TOKEN_CAP_RX,
    LLM_TRUNCATED_BELOW_BUDGET_COUNTER,
    RATE_LIMIT_TRANSIENT_RX,
    TIMEOUT_MAX_RETRIES,
    TIMEOUT_STOP_GRACE_SECONDS,
    TRUNCATED_REPLIES_COUNTER,
    TRUNCATED_RETRY_ATTEMPTED_COUNTER,
    TRUNCATED_RETRY_RECOVERED_COUNTER,
    CliConfig,
    ClockKind,
    EnvelopeResult,
    GuardrailBlocked,
    call_timeout_error,
    effort_scaled_seconds,
    model_refusal,
    note_budget_use,
    truncation_retry_max,
)
from vvaharness.backends.llm.tls import coerce_verify
from vvaharness.report.redact import redact
from vvaharness.util import errlog as _errlog
from vvaharness.util.counters import COUNTERS
from vvaharness.util.json_extract import extract_json
from vvaharness.util.response_quality import check_response_quality, output_tokens_for_gate
from vvaharness.util.tokens import TOKENS, TokenUsage
from vvaharness.util.warn_once import warn_once

__all__ = [
    "ANTHROPIC_STOP_MAX_TOKENS",
    "ANTHROPIC_STOP_REFUSAL",
    "CLI_CONN_TRANSIENT_RX",
    "CLI_CONTINUED_REPLIES_COUNTER",
    "CLI_RETRYABLE_STATUS",
    "CLI_STATUS_429_RX",
    "CLI_TOKEN_CAP_RX",
    "COUNTERS",
    "LLM_TRUNCATED_BELOW_BUDGET_COUNTER",
    "MODEL_MAX_OUTPUT_TOKENS",
    "RATE_LIMIT_TRANSIENT_RX",
    "TIMEOUT_MAX_RETRIES",
    "TIMEOUT_STOP_GRACE_SECONDS",
    "TOKENS",
    "TRUNCATED_REPLIES_COUNTER",
    "TRUNCATED_RETRY_ATTEMPTED_COUNTER",
    "TRUNCATED_RETRY_RECOVERED_COUNTER",
    "_ABORT",
    "_ABORT_HOOKS",
    "_AGENTIC_TIMEOUT",
    "_AUTH_FAILURE",
    "_CLAUDE_CMD",
    "_NEW_GROUP_KW",
    "_NO_REFUSAL_RESEND_ENV",
    "_PARSED_USAGE_CACHE_KEYS",
    "_PENDING_MAX_RETRIES",
    "_PROXY_FAILURE",
    "_READ_DENY_DIRS",
    "_WARNED_CAPS",
    "_WATCHDOG_STOPPED",
    "AuthenticationError",
    "CallTimeoutError",
    "CliConfig",
    "ClockKind",
    "EffortLevel",
    "EnvelopeResult",
    "Final",
    "GuardrailBlocked",
    "Path",
    "ProxyError",
    "TokenUsage",
    "TruncatedResponseError",
    "_TurnWatchdog",
    "_bare_tool_names",
    "_build_tls_env",
    "_cache",
    "_call_env",
    "_caps_cache",
    "_cfg",
    "_cli_capabilities",
    "_effective_effort",
    "_effort_argv",
    "_errlog",
    "_extract_envelope_error",
    "_finalize_via_resume",
    "_find_claude_cmd",
    "_format_cli_error",
    "_is_auth_failure",
    "_is_pending_result",
    "_is_proxy_failure",
    "_is_transient_failure",
    "_kill_tree",
    "_log_truncation_retry",
    "_log_usage",
    "_note_unparsed_cache_keys",
    "_parse_envelope",
    "_proxy_failure_evidence",
    "_raise_if_refused",
    "_recover_timed_out_session",
    "_run",
    "_run_streaming",
    "_run_with_retry",
    "_safe_permission_mode",
    "_session_pins",
    "_short_cmd",
    "_stop_tree",
    "_structured_text",
    "_tail",
    "_terminal_result_fields",
    "_tls_extra",
    "_truncation_cap",
    "_truncation_error",
    "_was_stopped",
    "_which_abs",
    "abort",
    "aborted",
    "agentic",
    "annotations",
    "call_timeout_error",
    "cast",
    "check_response_quality",
    "coerce_verify",
    "configure",
    "effort_scaled_seconds",
    "extract_json",
    "json",
    "log",
    "model_refusal",
    "note_budget_use",
    "os",
    "output_tokens_for_gate",
    "parse_json_response",
    "prompt",
    "re",
    "redact",
    "register_abort_hook",
    "release_pinned_session",
    "reset_abort",
    "resume_agentic",
    "shutil",
    "signal",
    "stream_trace",
    "subprocess",
    "sys",
    "threading",
    "time",
    "truncated_below_budget",
    "truncation_retry_max",
    "uuid",
    "warn_once",
]
