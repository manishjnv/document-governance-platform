# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Append one streaming session's turns and tool calls to a JSONL transcript."""

# Silently inert unless VVAHARNESS_TRANSCRIPT_DIR is set.

from __future__ import annotations

import json
import os
import re
import threading
import time
from dataclasses import asdict, is_dataclass
from pathlib import Path

_ENV_DIR = "VVAHARNESS_TRANSCRIPT_DIR"
_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")
_SEQ = 0
_SEQ_LOCK = threading.Lock()


def transcript_dir() -> Path | None:
    """The configured transcript directory, or None when transcripts are off."""
    raw = os.environ.get(_ENV_DIR, "").strip()
    return Path(raw).expanduser() if raw else None


def _next_seq() -> int:
    """A process-unique sequence number for transcript filenames."""
    global _SEQ
    with _SEQ_LOCK:
        _SEQ += 1
        return _SEQ


def _slug(text: str, *, fallback: str) -> str:
    """Filesystem-safe fragment of *text*, or *fallback* when nothing survives."""
    cleaned = _UNSAFE.sub("-", (text or "").strip()).strip("-")
    return cleaned[:60] or fallback


def _jsonable(message: object) -> dict[str, object]:
    """A dict for *message*, whatever shape it is — never raises on odd payloads."""
    if is_dataclass(message) and not isinstance(message, type):
        return asdict(message)
    return {"kind": type(message).__name__, "repr": repr(message)[:4000]}


class Transcript:
    """A JSONL file recording every HarnessMessage of one streaming session."""

    def __init__(self, path: Path, *, meta: dict[str, object]) -> None:
        """Open *path* for append and write the session's metadata header line."""
        self.path = path
        self._lock = threading.Lock()
        self._start = time.monotonic()
        self._n = 0
        self._write({"kind": "transcript_open", **meta})

    def _write(self, row: dict[str, object]) -> None:
        """Append one JSON row; a transcript failure must never break the scan."""
        try:
            with self._lock, self.path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, default=str) + "\n")
        except (OSError, TypeError, ValueError):
            return

    def add(self, message: object) -> None:
        """Record one streamed HarnessMessage."""
        self._n += 1
        self._write({
            "seq": self._n,
            "t": round(time.monotonic() - self._start, 3),
            **_jsonable(message),
        })

    def close(self) -> None:
        """Write the closing row carrying the message count and elapsed time."""
        self._write({
            "kind": "transcript_close",
            "messages": self._n,
            "elapsed_s": round(time.monotonic() - self._start, 3),
        })


def open_transcript(*, tag: str | None, model: str, graph_name: str = "") -> Transcript | None:
    """A Transcript for this session, or None when transcripts are disabled."""
    root = transcript_dir()
    if root is None:
        return None
    try:
        root.mkdir(parents=True, exist_ok=True)
    except OSError:
        return None
    name = f"{_next_seq():04d}-{_slug(tag or graph_name, fallback='session')}.jsonl"
    return Transcript(root / name, meta={"tag": tag, "model": model,
                                         "graph_name": graph_name})


__all__ = ["Transcript", "open_transcript", "transcript_dir"]
