# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""README/SECURITY/ARCHITECTURE-shaped documents, budgeted breadth-first."""
from __future__ import annotations

import re
from pathlib import Path, PurePosixPath

from vvaharness.evidence.read import _read_capped

# Priority order, not alphabetical: security/architecture docs outrank README, then CHANGELOG.
_DOC_CANDIDATES = (
    "THREAT_MODEL.md", "SECURITY.md", "ARCHITECTURE.md",
    "README.md", "README.rst", "README.txt", "README",
    "CHANGELOG.md", "CHANGELOG",
)

# Non-fixed-name docs (e.g. a migration write-up) matched by basename, case-insensitively.
_DOC_NAME_RX = re.compile(
    r"(analysis|architecture|design|migration|specification|spec|"
    r"threat|security|dataflow|data[_-]?flow|interface)",
    re.IGNORECASE,
)
_DOC_EXTRA_MAX = 8


def _breadth_pass(root: Path, found: list[tuple[str, Path]],
                  doc_cap: int) -> tuple[list[tuple[str, str]], int]:
    """Every present fixed-name document gets a fair (1/3-of-remaining) share first."""
    docs: list[tuple[str, str]] = []
    budget = doc_cap
    for name, p in found:
        if budget <= 0:
            break
        sub_cap = min(doc_cap, max(1000, budget // 3))
        body = _read_capped(root, p, sub_cap)
        if body:
            docs.append((name, body))
            budget -= len(body)
    return docs, budget


def _grow_one(root: Path, name: str, body: str, doc_cap: int, budget: int) -> tuple[str, int]:
    """Re-read one fixed-name doc with more budget; returns its (possibly grown) body and spend."""
    p = root / name
    if not p.is_file():
        return body, 0
    bigger = _read_capped(root, p, min(doc_cap, len(body) + budget))
    grown = len(bigger) - len(body)
    return (bigger, grown) if grown > 0 else (body, 0)


def _grow_round(root: Path, docs: list[tuple[str, str]], budget: int,
                doc_cap: int) -> tuple[int, bool]:
    """One breadth-first round of growth; returns the remaining budget and whether anything grew."""
    grew = False
    for i, (name, body) in enumerate(list(docs)):
        if budget <= 0:
            break
        bigger, spent = _grow_one(root, name, body, doc_cap, budget)
        if spent > 0:
            docs[i] = (name, bigger)
            budget -= spent
            grew = True
    return budget, grew


def _grow_pass(root: Path, docs: list[tuple[str, str]], budget: int,
               doc_cap: int) -> list[tuple[str, str]]:
    """Spend leftover budget growing truncated documents, breadth-first, until none grow."""
    guard = 0
    while budget > 0 and guard < len(docs):
        budget, grew = _grow_round(root, docs, budget, doc_cap)
        if not grew:
            break
        guard += 1
    return docs


def _select_extra_docs(full_files: list[str], seen: set[str]) -> list[str]:
    """Non-fixed-name .md/.rst paths matched by basename, capped at `_DOC_EXTRA_MAX`."""
    return sorted(
        rel for rel in full_files
        if PurePosixPath(rel).suffix.lower() in (".md", ".rst")
        and rel not in seen
        and _DOC_NAME_RX.search(PurePosixPath(rel).stem)
    )[:_DOC_EXTRA_MAX]


def _extra_docs(root: Path, full_files: list[str], seen: set[str],
                budget: int) -> list[tuple[str, str]]:
    """Read the selected extras, budget split evenly across them."""
    extras = _select_extra_docs(full_files, seen)
    per_cap = max(1000, budget // (len(extras) or 1))
    docs: list[tuple[str, str]] = []
    for rel in extras:
        if budget <= 0:
            break
        body = _read_capped(root, root / rel, min(budget, per_cap))
        if body:
            docs.append((rel, body))
            budget -= len(body)
    return docs


def gather_docs(root: Path, full_files: list[str], doc_cap: int) -> list[tuple[str, str]]:
    """Fixed-name documents (breadth, then growth) plus a bounded set of matched extras."""
    found = [(name, root / name) for name in _DOC_CANDIDATES if (root / name).is_file()]
    docs, budget = _breadth_pass(root, found, doc_cap)
    docs = _grow_pass(root, docs, budget, doc_cap)
    budget = doc_cap - sum(len(b) for _, b in docs)
    seen = {n for n, _ in docs}
    return docs + _extra_docs(root, full_files, seen, budget)
