# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The CWE knowledge base as a fact tool, composed via ``compose_tool_builders``."""
from __future__ import annotations

import threading
from collections.abc import Sequence

from langchain_core.tools import BaseTool, tool

from vvaharness.backends.harness import StreamingOptions
from vvaharness.rules import CweKB
from vvaharness.util.counters import COUNTERS

KB_TOOL_NAMES: tuple[str, ...] = ("CweGuidance",)

_unknown_cwe_lock = threading.Lock()
_unknown_cwe_ids: set[str] = set()


def _note_unknown_cwe(cwe_id: str) -> None:
    """Record *cwe_id* among this run's KB misses, as the comma-joined `note` fact."""
    # Sessions share this process's tool instance (possibly concurrently): the id set, not the
    # last single id, is what distinguishes a KB gap from a model inventing ids.
    with _unknown_cwe_lock:
        if cwe_id in _unknown_cwe_ids:
            return
        _unknown_cwe_ids.add(cwe_id)
        ids = ",".join(sorted(_unknown_cwe_ids))
    COUNTERS.note("s4_cwe_guidance_unknown_ids", ids)


@tool
def CweGuidance(cwe_id: str) -> dict:
    """Sanitizers, non-sanitizers and FP checks known for one CWE id, e.g. 'CWE-89'."""
    # Without this counter, a flat FP rate and "never consulted" look the same.
    COUNTERS.bump("s4_cwe_guidance_called")
    entry = CweKB.load().for_cwes([cwe_id])
    # A miss still returns every key, so the dict is truthy either way; only a hit fills `cwe`
    if not entry.get("cwe"):
        COUNTERS.bump("s4_cwe_guidance_unknown_cwe")
        _note_unknown_cwe(cwe_id)
    return entry


def build_kb_tool_builder():
    """Return a ``ToolBuilder`` contributing ``CweGuidance`` when fact-gated in."""

    def _build(options: StreamingOptions, *, allowed_tools: Sequence[str] | None = None) -> list[BaseTool]:
        if "CweGuidance" not in set(getattr(options, "fact_tools", ()) or ()):
            return []
        return [CweGuidance]

    return _build


__all__ = ["KB_TOOL_NAMES", "CweGuidance", "build_kb_tool_builder"]
