# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""The non-scan subcommand handlers: doctor, estimate, gc, validate, remediate, ev-replay."""
from __future__ import annotations
from vvaharness.util import logs

from pathlib import Path

from vvaharness.cli._paths import (
    _config_path_from,
    _config_path_from_explicit,
    _load_and_configure,
    _repo_from,
)
from vvaharness.util import console
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

_ICON = {"ok": "✓", "warn": "⚠", "fail": "✗"}


def _doctor(rest: list[str]) -> int:
    """Read-only diagnostic: static readiness checks, a live backend probe, and opt-in --cache-probe."""
    if "--help" in rest or "-h" in rest:
        # Without this, asking for help RUNS the diagnostic against live backends.
        print(
            "usage: vvaharness doctor [--config PATH] [--cache-probe]\n"
            "\n"
            "Check credentials and live backend connectivity (read-only).\n"
            "Exits non-zero on any blocking issue or probe failure.\n"
            "\n"
            "  --config PATH   config to check (same resolution as `scan`)\n"
            "  --cache-probe   additionally run a prompt-cache diagnostic against\n"
            "                  each configured model route. Spends real tokens;\n"
            "                  prints an estimate first. Never runs during a scan.\n"
        )
        return 0

    from vvaharness.orchestrator import probe_backends
    from vvaharness.util import environment as env
    cfg_path = _config_path_from(rest)
    if not Path(cfg_path).exists():
        console.write(f"doctor: config not found: {cfg_path}")
        return 2
    cfg = _load_and_configure(cfg_path, "doctor")
    if cfg is None:
        return 2

    checks = env.run_checks(cfg_path)
    for c in checks:
        print(f"  {_ICON.get(c.status, '?')} {c.name:<30} {c.detail}")
    n_ok, n_warn, n_blocking = env.summarize(checks)
    print("  " + "─" * 60)
    print(f"  {n_ok} ok · {n_warn} warning(s) · {n_blocking} blocking issue(s)")

    if n_blocking:
        print("  [probe] skipped — fix the blocking item(s) above first")
        return 1
    rc = 0 if probe_backends(cfg) else 1
    # tls_check() cannot see an OS-store CA a via:cli Node child trusts, so reconcile its WARN
    tls = next((c for c in checks if c.name == "TLS / CA cert"), None)
    if rc == 0 and tls is not None and tls.status != env.OK:
        print("  Note: the TLS/CA warning above didn't block anything — the "
              "live probe just reached the configured endpoint successfully "
              "using this run's actual credentials/trust path.")
    if "--cache-probe" in rest:
        if rc != 0:
            console.write("  [cache-probe] skipped — fix the backend probe failure(s) "
                          "above first")
            return rc
        from vvaharness.orchestrator.preflight import run_cache_probe
        rc = 0 if run_cache_probe(cfg) else 1
    return rc

def _estimate(rest: list[str]) -> int:
    from stat import S_ISDIR

    from vvaharness import config as config_mod
    from vvaharness.orchestrator import trusted_config
    from vvaharness.scope import _walk_repo

    if "--help" in rest or "-h" in rest:
        print("usage: vvaharness estimate --repo <path> [--config PATH]\n"
              "Offline S1 scope preview and heuristic S1-S9 token budget.")
        return 0
    repo = _repo_from(rest)
    if not repo:
        console.write("usage: vvaharness estimate --repo <path> [--config PATH]")
        return 2
    root = Path(repo)
    try:
        directory = S_ISDIR(root.stat().st_mode)
    except FileNotFoundError as error:
        if getattr(error, "winerror", None) == 206:
            console.write("estimate: invalid repository path: path is too long")
            return 2
        console.write(f"not a repository directory: {repo}")
        return 1
    except (OSError, ValueError) as error:
        console.write(f"estimate: invalid repository path: {error}")
        return 2
    if not directory:
        console.write(f"not a repository directory: {repo}")
        return 1
    cfg_path, explicit = _config_path_from_explicit(rest)
    try:
        cfg_path = trusted_config(cfg_path, root, explicit=explicit)
        cfg = config_mod.load(cfg_path)
        inventory, _excluded = _walk_repo(str(root), cfg)
    except (OSError, ValueError, config_mod.ConfigPolicyError) as error:
        console.write(f"estimate: {error}")
        return 2
    files = bytes_ = 0
    for relative in inventory:
        try:
            bytes_ += (root / relative).stat().st_size
            files += 1
        except OSError:
            pass
    approx_tokens = bytes_ // 4
    print(f"scope estimate for {repo}")
    print(f"  in-scope files   : {files:,}")
    print(f"  bytes            : {bytes_:,}")
    print(f"  ~source tokens   : {approx_tokens:,} (bytes/4, not pipeline usage)")
    lower = 250_000 + 5 * approx_tokens if files else 0
    upper = 1_000_000 + 20 * approx_tokens if files else 0
    print(f"  S1-S9 input budget: {lower:,}-{upper:,} tokens (heuristic)")
    print("  assumes 250k-1M fixed prompt/tool overhead plus 5-20x source tokens.")
    print("  Not a measured forecast or spend cap; agent turns, findings, retries")
    print("  and cache billing can put actual usage outside this range. S10/S11")
    print("  and exploit verification are extra. No model calls were made.")
    print("  Scope is before config dedup and optional auto-exclusions; use")
    print("  --stop-after s3 for the final inventory. Cost depends on model pricing.")
    return 0

def _gc(rest: list[str]) -> int:
    """Delete old run records from the SQLite state DB and their code-graph workspaces, keeping reports under security-scan/ untouched."""
    import argparse

    from vvaharness.orchestrator.checkpoints import prune_checkpoints, run_id_for
    ap = argparse.ArgumentParser(prog="vvaharness gc")
    ap.add_argument("--keep-runs", type=int, default=100,
                    help="retain the N most-recent run_ids (default: 100)")
    ap.add_argument("--max-age-days", type=int, default=5,
                    help="delete runs older than D days (default: 5)")
    ap.add_argument("--run", metavar="PATH",
                    help="fully evict the run for this repo PATH (its run_id is "
                         "derived from the path) instead of age/count pruning")
    ap.add_argument("--dry-run", action="store_true",
                    help="show what would be deleted; touch nothing")
    a = ap.parse_args(rest)
    from vvaharness.orchestrator import store

    if a.run:
        rid = run_id_for(a.run)
        if a.dry_run:
            try:
                exists = store.run_exists(rid)
            except store.StoreError as error:
                log.error(Event.STORE_UNUSABLE, detail=str(error))
                return 2
            if exists:
                print(f"  [dry-run] gc: would evict run {rid} for {a.run}")
            else:
                print(f"  [dry-run] gc: no run recorded for {a.run} (run_id {rid}); nothing to do")
            return 0
        try:
            ok = store.delete_run(rid)
        except store.StoreError as e:
            log.error(Event.STORE_UNUSABLE, detail=str(e))
            return 2
        print(f"  gc: {'evicted' if ok else 'no run found for'} {a.run} "
              f"(run_id {rid})")
        return 0

    try:
        r = prune_checkpoints(keep_runs=a.keep_runs,
                              max_age_days=a.max_age_days,
                              dry_run=a.dry_run)
    except store.StoreError as e:
        log.error(Event.STORE_UNUSABLE, detail=str(e))
        return 2
    tag = "[dry-run] " if a.dry_run else ""
    if not store.db_location().exists():
        print(f"  gc: no state database at {r['root']}; nothing to do")
    else:
        print(f"  gc: {r['root']}")
    print(f"  {tag}kept {r['kept']} run(s), "
          f"{'would delete' if a.dry_run else 'deleted'} {len(r['deleted'])}")
    for rid in r["deleted"]:
        print(f"    - {rid}")
    return 0

def _validate(rest: list[str]) -> int:
    """Run the s11 agentic validation agent (invocable as `validate` or `s11`)."""
    from vvaharness.validation.cli import main as validate_main
    return validate_main(rest)

def _remediate(rest: list[str]) -> int:
    """Drive remediation from a prior scan's findings, using the configured `models.remediate` role."""
    from vvaharness import config as config_mod
    from vvaharness.orchestrator import trusted_config
    from vvaharness.remediation_agent import remediate
    repo = _repo_from(rest)
    if not repo:
        console.write("usage: vvaharness remediate --repo <path>")
        return 2
    cfg_path, explicit = _config_path_from_explicit(rest)
    try:
        cfg_path = trusted_config(cfg_path, repo, explicit=explicit)
    except config_mod.ConfigPolicyError as e:
        console.write(f"remediate: {e}")
        return 2
    if not Path(cfg_path).exists():
        console.write(f"remediate: config not found: {cfg_path}")
        return 2
    cfg = _load_and_configure(cfg_path, "remediate")
    if cfg is None:
        return 2
    return remediate(repo, rest, cfg)

def _ev_replay(rest: list[str]) -> int:
    """Re-check previously exploit-verified findings against a REDEPLOYED target."""
    from vvaharness import config as config_mod
    from vvaharness.exploit_verification.replay.run import replay_run
    from vvaharness.orchestrator import trusted_config
    repo = _repo_from(rest)
    if not repo:
        console.write("usage: vvaharness ev-replay --repo <path>")
        return 2
    cfg_path, explicit = _config_path_from_explicit(rest)
    try:
        cfg_path = trusted_config(cfg_path, repo, explicit=explicit)
    except config_mod.ConfigPolicyError as e:
        console.write(f"ev-replay: {e}")
        return 2
    cfg = _load_and_configure(cfg_path, "ev-replay")
    if cfg is None:
        return 2
    return replay_run(repo, rest, cfg)
