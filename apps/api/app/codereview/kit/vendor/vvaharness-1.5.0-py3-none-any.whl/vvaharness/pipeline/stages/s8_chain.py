# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Step 8 — deterministic ranking floor plus model-optional chain/narrative enrichment; any enrichment failure still ships the ranked report."""
from __future__ import annotations

from typing import Any

from vvaharness.util import logs

from vvaharness.backends.harness.models import TruncatedResponseError, is_halt_error
from vvaharness.backends.llm.models import ModelRefusal
from vvaharness.models import (
    ContextPackage,
    DroppedFinding,
    FinalReport,
    Finding,
    ScanMetrics,
)
from vvaharness.pipeline.stages.s8.outcomes import (
    ChainReport,
    deterministic_report,
    hydrate_report,
    parse_chain_reply,
    templated_summary,
)
from vvaharness.pipeline.stages.s8.session import (
    chain_call,
    repair_call,
    repair_fits,
    repairable,
)
from vvaharness.pipeline.stages.s8.window import half_window, select_window
from vvaharness.report.redact import redact
from vvaharness.util import console
from vvaharness.util import errlog as _errlog
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event
from vvaharness.util.response_quality import is_truncated_without_retry

log = logs.get_logger(__name__)

_RANKED_INVALID = "s8_ranked_findings_entry_invalid"


def _redacted_err(e: BaseException, cap: int = 400) -> str:
    """Returns exception text for the delivered report, redacting the full text before capping so the cut cannot bisect a secret."""
    return redact(str(e))[:cap]


def _enrichment_failure_text(e: BaseException) -> str:
    """The ``degraded_reason`` clause for a chain call that never returned: a plain sentence for
    a refusal (its exception text already names route/category/stage, which otherwise leaks
    into the shipped report verbatim), the redacted exception text for every other failure."""
    if isinstance(e, ModelRefusal):
        return "no chain analysis: the chain model refused the request"
    return f"chain call failed ({_redacted_err(e)})"


def _chain_call_with_half_window_retry(
        sub: list[Finding], labels: list[str], window: list[int],
        findings: list[Finding], ctx: ContextPackage,
        cfg) -> tuple[str, list[int], list[str], int]:
    """One ``chain_call``; on an at-cap clip (``TruncatedResponseError``, ``retried=0``) halves
    the rank-prefix *window* and resends ONCE with ``allow_resend=False`` -- the resend changes
    the input size, not the effort tier, and vetoes its own drop-tier resend so the stage still
    makes at most one resend of its own. Returns ``(raw, window, labels, invalid0)`` for
    whichever call succeeded, *invalid0* being the salvage counter just before that call;
    re-raises any other failure, including a second clip the halving cannot shrink."""
    # Before each call, not the parse: sdk/deepagents validate the reply inside the backend
    invalid0 = COUNTERS.get(_RANKED_INVALID)
    try:
        return chain_call(sub, ctx, cfg, labels=labels), window, labels, invalid0
    except TruncatedResponseError as e:
        if not is_truncated_without_retry(e):
            raise
        half = half_window(findings, window)
        if half == window:
            # Already down to the smallest window a resend could try: nothing left to shrink.
            raise
        console.write(f"  [s8] clipped at the output cap; retrying once over half the "
                      f"window ({len(half)} of {len(window)} findings)")
        half_sub = [findings[i] for i in half]
        half_labels = [f"f{i}" for i in half]
        invalid0 = COUNTERS.get(_RANKED_INVALID)
        raw = chain_call(half_sub, ctx, cfg, labels=half_labels, allow_resend=False)
        return raw, half, half_labels, invalid0


def _persist_raw(text: str, suffix: str) -> None:
    """Writes *text*, redacted, beside the errlog as ``<stem><suffix>``; a write failure only warns."""
    try:
        errp = _errlog.current_path()
        stem = (errp.name[:-len("_errors.jsonl")]
                if errp.name.endswith("_errors.jsonl") else errp.stem)
        raw_path = errp.parent / f"{stem}{suffix}"
        raw_path.parent.mkdir(parents=True, exist_ok=True)
        raw_path.write_text(redact(text), encoding="utf-8")
    except OSError as e:
        log.warning(Event.S8_RAW_PERSIST_FAILED, detail=redact(str(e)))


def _json_repair(raw: object, err: Exception, ctx: ContextPackage,
                 cfg) -> tuple[ChainReport | None, str | None, dict[str, Any]]:
    """One json-repair re-ask for a reply the gate admits: ``(report, repaired_raw, {})`` on
    success, else ``(None, None, extra)`` where *extra* carries the repair's own failure for the
    ONE errlog row the caller writes about the original error; halt errors re-raise."""
    if not repairable(raw):
        return None, None, {}
    text = str(raw)
    if not repair_fits(text, cfg):
        console.write("  [s8] reply did not parse and is too large to restate under the "
                      "replay cap; no json-repair re-ask")
        COUNTERS.bump("s8_parse_repair_skipped_oversize")
        return None, None, {}
    console.write("  [s8] reply did not parse; one json-repair re-ask")
    COUNTERS.bump("s8_parse_repair_attempted")
    repaired: str | None = None
    try:
        repaired = repair_call(text, err, ctx, cfg)
        data = parse_chain_reply(repaired)
    except Exception as e2:  # provider errors are heterogeneous
        if is_halt_error(e2):
            raise
        extra: dict[str, Any] = {"repair_error": redact(str(e2))[:400]}
        if isinstance(repaired, str):
            # Escaped like raw_head, after redact() and the slice
            extra["repair_head"] = redact(repaired)[:500].replace("\n", "\\n")
        return None, None, extra
    COUNTERS.bump("s8_parse_repair_recovered")
    _persist_raw(repaired, "_s8_raw_repaired.txt")
    return data, repaired, {}


def run(findings: list[Finding], ctx: ContextPackage, cfg, *,
        dropped: list[DroppedFinding] | None = None,
        raw_findings_count: int = 0,
        metrics: ScanMetrics | None = None) -> FinalReport:
    dropped = dropped or []
    if not findings:
        # "read nothing" and "found nothing" must not share a summary.
        empty = metrics is not None and not metrics.total_files_in_scope
        return FinalReport(
            repo_root=ctx.repo_root,
            findings=[],
            chains=[],
            dropped=dropped,
            raw_findings_count=raw_findings_count,
            metrics=metrics,
            summary=("0 files analysed — no conclusion can be drawn about "
                     "this repository; check the S1 file inventory and "
                     "exclusions." if empty else
                     "No findings survived adversarial verification."),
            degraded=empty,
            enrichment_unavailable=empty,
            degraded_reason=("scope was empty: 0 files reached analysis"
                             if empty else ""),
        )

    # Windowing is a guard rail: 0% of the 660-report corpus triggers it at defaults.
    try:
        window = select_window(findings, ctx, cfg)
    except Exception as e:
        # Must never fail the stage: a garbage overlay ("64k") falls back to the un-windowed call
        log.warning(Event.S8_WINDOW_SELECTION_FAILED, detail=redact(str(e)))
        # recovered: nothing is lost, the un-windowed call still proceeds.
        _errlog.log("s8", "chain-window", e, recovered=True)
        window = list(range(len(findings)))
    if not window:
        # A model that saw zero findings must not author the report.
        return deterministic_report(
            ctx, findings, dropped, raw_findings_count, metrics,
            enrichment_failure=("prompt_token_budget admits no findings "
                                "into the enrichment window"),
        )
    sub = [findings[i] for i in window]
    labels = [f"f{i}" for i in window]

    try:
        raw, window, labels, invalid0 = _chain_call_with_half_window_retry(
            sub, labels, window, findings, ctx, cfg)
    except Exception as e:  # provider errors are heterogeneous
        if is_halt_error(e):
            raise
        log.warning(Event.S8_CALL_FAILED, detail=redact(str(e)))
        _errlog.log("s8", "chain", e)
        return deterministic_report(
            ctx, findings, dropped, raw_findings_count, metrics,
            enrichment_failure=_enrichment_failure_text(e),
        )
    windowed = len(window) < len(findings)

    # Persist the raw BEFORE parsing, so a parse failure is salvageable without re-spending the call
    _persist_raw(raw or "", "_s8_raw.txt")

    # ValueError covers no-JSON and off-schema (both subclass it); TypeError is a None/bytes backend
    try:
        data = parse_chain_reply(raw)
    except (ValueError, TypeError) as e:
        # The discarded reply's validation must not count against the repaired one
        invalid0 = COUNTERS.get(_RANKED_INVALID)
        repaired, repaired_raw, repair_extra = _json_repair(raw, e, ctx, cfg)
        if repaired is None:
            # redact() BEFORE the slice: slicing first could bisect a secret past matching.
            safe_raw = redact(raw) if isinstance(raw, str) else ""
            head = safe_raw[:500].replace("\n", "\\n")
            tail = safe_raw[-200:].replace("\n", "\\n")
            log.warning(Event.S8_RESPONSE_UNPARSEABLE, detail=redact(str(e)))
            # ONE row, about the ORIGINAL reply (what _s8_raw.txt holds); a repair annotates it
            _errlog.log("s8", "chain", e, raw_head=head, raw_tail=tail, **repair_extra)
            console.write(f"  [s8] raw[:500]  = {head!r}")
            console.write(f"  [s8] raw[-200:] = {tail!r}")
            return deterministic_report(
                ctx, findings, dropped, raw_findings_count, metrics,
                enrichment_failure=f"reply unparseable ({_redacted_err(e)})",
            )
        data = repaired
        # Later rows quote the reply that shipped, not the one the repair replaced
        raw = repaired_raw

    # ranked_finding stamps severity in place, so restore before the floor; id()-keyed: value __eq__
    original_severity = {id(f): f.severity for f in findings}
    try:
        report, covered = hydrate_report(
            data, ctx, findings, dropped, raw_findings_count, metrics,
            window=set(window) if windowed else None, cfg=cfg)
    except Exception as e:  # hydration touches model-chosen ids
        for f in findings:
            f.severity = original_severity[id(f)]
        log.warning(Event.S8_HYDRATION_FAILED, detail=redact(str(e)))
        _errlog.log("s8", "chain-hydrate", e)
        return deterministic_report(
            ctx, findings, dropped, raw_findings_count, metrics,
            enrichment_failure=f"hydration failed ({_redacted_err(e)})",
        )

    if windowed:
        # A windowed model saw part of the report, so its prose is not executive over all of it
        report.summary = f"{report.summary}\n\n{templated_summary(report.findings)}"

    # degraded stays False here, so only the line or row below shows it; counted against SHOWN
    if len(covered) < len(window):
        head = redact(raw)[:500].replace("\n", "\\n") if isinstance(raw, str) else ""
        missing = len(window) - len(covered)
        msg = (f"chain reply ranked {len(covered)}/{len(window)} "
              f"findings it was shown; {missing} ship unranked")
        # The id filters dropped nothing and no entry was unreadable: the reply follows the
        # schema whatever its length; errlog only when data is lost
        nothing_dropped = (len(data.ranked_findings) == len(covered)
                           and COUNTERS.get(_RANKED_INVALID) == invalid0)
        if nothing_dropped:
            console.counts("s8", "sparse ranking (by design); shipping unranked",
                           ranked=len(covered), shown=len(window), unranked=missing)
            COUNTERS.bump("s8_sparse_ranking_recovered")
        else:
            log.warning(Event.S8_NO_RANKED_FINDINGS, ranked=len(covered), shown=len(window),
                        unranked=missing, raw_head=head)
            _errlog.log("s8", "chain", msg, raw_head=head)

    console.write(f"  [s8] done: {len(report.findings)} ranked findings, "
                  f"{len(report.chains)} chains, "
                  f"{report.chains_dropped} chains_dropped")
    return report
