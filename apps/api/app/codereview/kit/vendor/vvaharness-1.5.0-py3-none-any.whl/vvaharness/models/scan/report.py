# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""The final report and its Markdown rendering."""
from __future__ import annotations

import logging
import re

from pydantic import BaseModel

from vvaharness.models.scan._finding_section import (
    finding_description_lines,
    finding_section_lines,
)
from vvaharness.models.scan._render import (
    _demote_md_headings,
    _md_cell,
)
from vvaharness.models.scan._sections_chain import (
    _app_profile_lines,
    _chain_lines,
    _chain_pass_caveat,
    _chain_removal_leadins,
    _empty_chain_section_copy,
    _render_threat_model,
    _render_unreachable_appendix,
    _summary_reconciliation_note,
    _terminal_diversity_leadin,
    _unpromoted_link_leadin,
)
from vvaharness.models.scan._sections_metrics import (
    _render_metrics,
    _render_scan_health,
    _render_scope_appendix,
    _render_verification,
)
from vvaharness.models.scan.findings import NOT_RANKED_NOTE, Chain, DroppedFinding, RankedFinding
from vvaharness.models.scan.inputs import AppProfile
from vvaharness.models.scan.metrics import ScanMetrics
from vvaharness.models.scan.threat import ThreatModel

__all__ = ["FinalReport", "finding_description_lines", "finding_section_lines"]

log = logging.getLogger(__name__)


class FinalReport(BaseModel):
    # findings.json persisted shape: bump on any breaking change, consumers key on it
    schema_version: str = "1.0"
    repo_root: str
    repo_name: str | None = None     # repository_name from repos.txt/csv — used for the report title
    git_sha: str | None = None       # HEAD at scan time; step 10 refuses on mismatch
    findings: list[RankedFinding]
    chains: list[Chain]
    # Proposed chains resolving to <2 distinct findings; rendered so an empty section can't lie
    chains_dropped: int = 0
    # Byte-identical chains collapsed by s8 dedup: a different claim from chains_dropped
    chains_deduped: int = 0
    # Unreadable at parse time: chains_dropped's sentence ("steps did not resolve") is false of it
    chains_invalid: int = 0
    # (owner, target) indices into `findings` a ranked entry's `feeds` marked and no shipped chain
    # carries in order. Disclosed, never promoted
    unpromoted_links: list[tuple[int, int]] = []
    dropped: list[DroppedFinding] = []
    raw_findings_count: int = 0      # pre-verification count
    metrics: ScanMetrics | None = None
    threat_model: ThreatModel | None = None
    app_profile: AppProfile | None = None
    # No unit named them, so nothing read them; None (not []) = knob off, [] = s3 found zero
    unreachable_files: list[str] | None = None
    # Threat ids whose surface had no validated file, so no unit and no review ever saw them
    threats_without_unit: list[str] | None = None
    summary: str
    degraded: bool = False
    degraded_reason: str = ""
    # Narrower than `degraded`: true only when `chains=[]` is NOT a trustworthy "zero chains found"
    enrichment_unavailable: bool = False

    # The one hollowness predicate: s9/health.py calls it too, so report and SARIF cannot disagree

    def is_hollow(self) -> bool:
        """True when files were in scope, the threat-model pass degraded, and nothing came out."""
        m = self.metrics
        if m is None or self.findings:
            return False
        # Different builders stamp field and snapshot; either can default on an old payload
        raw = max(self.raw_findings_count or 0,
                  getattr(m, "raw_findings_count", 0) or 0)
        return bool(not raw
                    and (getattr(m, "total_files_in_scope", 0) or 0) > 0
                    and getattr(m, "s2_degraded", False))

    def _undetermined_drop_count(self) -> int:
        """Count of dropped findings with no verifier verdict, never an FP or duplicate."""
        return sum(1 for d in self.dropped
                  if d.reason in ("VERIFY_ERROR", "GUARDRAIL_BLOCKED", "INCONCLUSIVE"))

    def unranked_split(self) -> tuple[int, int, int]:
        """``(ranked, by_design, feeder_missed)`` over this report's findings.

        ``ranked``: findings whose ``exploitability_notes`` is not :data:`NOT_RANKED_NOTE` --
        the chain pass gave them an entry (even a sparse one with nothing but a severity change
        or a ``feeds`` link), or they never entered the chain pass's sparse-ranking accounting
        at all (e.g. windowed out of the enrichment call, a separate, already-counted cause).

        Among the rest (the chain pass saw the finding and chose not to add an entry):
        ``feeder_missed`` is a finding that is a NON-TERMINAL step of a shipped chain -- the
        chain prompt's own rule ("an entry for a finding that feeds another") says it should
        have had one, so this is a reply defect; ``by_design`` is every other such finding
        (terminal-only, a ``feeds`` target only, or absent from every chain) -- the sparse-
        ranking contract working as intended.

        ``ranked + by_design + feeder_missed == len(self.findings)`` always.
        """
        feeders = {s for c in self.chains for s in c.steps[:-1]}
        unranked = [i for i, rf in enumerate(self.findings)
                   if rf.exploitability_notes == NOT_RANKED_NOTE]
        feeder_missed = sum(1 for i in unranked if i in feeders)
        by_design = len(unranked) - feeder_missed
        ranked = len(self.findings) - len(unranked)
        return ranked, by_design, feeder_missed

    def _verified_tp_fp(self) -> tuple[int, int]:
        """(true positives, false positives) as the verifier decided them, pre-s7-dedup."""
        # Never raw_findings_count: its pool is not a TP/FP population (s6 rows, s7 dupes)
        m = self.metrics
        if m is not None:
            return m.true_positive_count, m.false_positive_count
        # A hand-built report with no metrics falls back to post-dedup counts.
        return (len(self.findings),
                sum(1 for d in self.dropped if d.reason == "FALSE_POSITIVE"))

    def coverage_degraded(self) -> tuple[str, ...]:
        """The reason codes for lost analysis coverage, empty when a scan is healthy here."""
        # Excludes s3_unreachable_files by design: non-zero in most healthy scans, would always fire
        m = self.metrics
        if m is None:
            return ()
        reasons: list[str] = []
        if self._undetermined_drop_count() > 0:
            reasons.append("s6_undetermined")
        if m.total_files_in_scope > 0 and m.analyzed_files_unique == 0:
            reasons.append("zero_analysis")
        if m.llm_turn_cap_exhausted > 0:
            reasons.append("llm_turn_cap_exhausted")
        return tuple(reasons)

    def to_markdown(self, *, posture_channel: bool = True,
                    unreachable_appendix: bool = True) -> str:
        # `posture_channel` defaults True to match `build_sarif`, so MD and SARIF cannot disagree
        safe_title = re.sub(r"[<>`|\[\]]", "", str(self.repo_name or self.repo_root or ""))
        out = [
            f"# Agentic SAST — {safe_title}",
            "",
            "## Summary",
            _demote_md_headings(self.summary, escape_angles=True),
            "",
            *_summary_reconciliation_note(self),
        ]
        if self.app_profile is None:
            # No CMDB: P1/P2 are structurally unreachable (appcontext needs externally_facing)
            out.extend([
                ("_No CMDB/application context was supplied for this scan — "
                 "OffensivePriority is capped at its lowest reachable tier "
                 "(P3/P4) for every finding below; it is not an individual "
                 "low-priority assessment._"),
                "",
            ])
        if self.metrics:
            out.extend(_render_metrics(self,
                unreachable_appendix=unreachable_appendix))
        out.extend(_render_scan_health(self))
        if self.threat_model:
            out.extend(_render_threat_model(self))
        elif self.app_profile:
            out.extend(["## Threat Model", ""] + _app_profile_lines(self))
        out.extend(_render_verification(self, posture_channel=posture_channel))
        # 1-based positions survive the regroup: chain step indices index this same list
        _main: list[tuple[int, RankedFinding]] = []
        _posture: list[tuple[int, RankedFinding]] = []
        for i, rf in enumerate(self.findings, 1):
            if posture_channel and rf.finding.channel == "posture":
                _posture.append((i, rf))
            else:
                _main.append((i, rf))
        out.extend([
            "",
            f"## Findings ({len(_main)})",
            "",
        ])
        # Disclaimer only when the heading count is NOT the report total
        if _posture:
            out.extend([
                (f"_Application-defect findings only — {len(_posture)} "
                 "posture finding(s) are listed separately under Posture "
                 f"Findings below ({len(self.findings)} in total)._"),
                "",
            ])
        for i, rf in _main:
            out.extend(finding_section_lines(i, rf))
        if _posture:
            out.extend([
                "",
                f"## Posture Findings ({len(_posture)})",
                "",
                ("_Build, deploy, and dependency-posture findings the "
                 "verifier routed out of the application-defect list. They "
                 "keep their original finding numbers (the exploit-chain step "
                 "indices reference them) and their severity; remediation "
                 "skips them by default._"),
                "",
            ])
            for i, rf in _posture:
                out.extend(finding_section_lines(i, rf))
        if self.chains:
            out.extend(["## Exploit Chains", ""])
            out.extend(_chain_removal_leadins(self) + _terminal_diversity_leadin(self))
            out.extend(_unpromoted_link_leadin(self))
            out.extend(_chain_pass_caveat(self))
            # Ordinals span the FULL list so "Chain N" resolves; only quality_notes price the split
            _numbered = list(enumerate(self.chains, 1))
            _lower = [(n, c) for n, c in _numbered
                      if len(c.quality_notes) >= 2]
            _confirmed = [(n, c) for n, c in _numbered
                          if len(c.quality_notes) < 2]
            for n, c in _confirmed:
                out.extend(_chain_lines(self, n, c))
            if _lower:
                out.extend([
                    "### Lower-confidence chains",
                    "",
                    ("_These chains did not clear two or more of the "
                     "deterministic quality checks noted on each; they are "
                     "shown in full and keep their chain numbers, but weigh "
                     "those notes before relying on them._"),
                    "",
                ])
                for n, c in _lower:
                    out.extend(_chain_lines(self, n, c))
        elif not self.enrichment_unavailable:
            out.extend(["## Exploit Chains", ""])
            out.extend(_empty_chain_section_copy(self))
            out.extend(_chain_pass_caveat(self))
        out.extend(["", "## Dropped Findings", ""])
        if self.dropped:
            _tag = {
                "FALSE_POSITIVE":    "FP",
                "UNCONFIRMED":       "UNCONFIRMED",
                "VERIFY_ERROR":      "VERIFY-ERR",
                "EXCLUDED":          "EXCLUDED",
                "GUARDRAIL_BLOCKED": "GUARDRAIL",
                "INCONCLUSIVE":      "INCONCLUSIVE",
            }
            for d in self.dropped:
                if d.reason == "DUPLICATE":
                    tag = (f"DUP of #{d.canonical_idx + 1}"
                           if d.canonical_idx is not None
                           else "DUP (pre-verify)")
                else:
                    tag = _tag.get(d.reason, d.reason)
                out.append(f"- **[{tag}]** `{_md_cell(d.file).replace(chr(96), chr(0x2CB))}:{d.line}` "
                           f"{d.vuln_class.value} ({_md_cell(d.chunk_id)}) — "
                           f"{_md_cell(d.detail)}")
        else:
            out.append("_None._")
        out.append("")
        if self.metrics:
            out.extend(_render_scope_appendix(self))
        if self.unreachable_files and unreachable_appendix:
            out.extend(_render_unreachable_appendix(self))
        return "\n".join(out)
