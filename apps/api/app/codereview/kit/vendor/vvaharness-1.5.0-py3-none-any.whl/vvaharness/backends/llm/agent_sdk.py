# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Claude Agent SDK backend for the Remediation Agent's fix mode (`via: sdk`); sdk.py is read-only."""

# Deny-by-default gate: Read/Glob/Grep OK, Edit/Write cwd-confined, Bash denied (RCE + exfil risk).
from __future__ import annotations

import asyncio
import contextlib
import os
import time
from pathlib import Path
from typing import TYPE_CHECKING, NamedTuple, cast

from vvaharness.backends.llm.cli import _NO_REFUSAL_RESEND_ENV
from vvaharness.backends.llm.models import (
    DEFAULT_READ_TOOLS,
    TIMEOUT_STOP_GRACE_SECONDS,
    ClockKind,
    call_timeout_error,
    effort_scaled_seconds,
    note_budget_use,
)
from vvaharness.report.redact import redact_counts
from vvaharness.util import console
from vvaharness.util.tokens import TOKENS, TokenUsage

if TYPE_CHECKING:
    from claude_agent_sdk import ResultMessage

# Read-only tools are always safe; only file-mutation tools are gated to cwd.
_WRITE_TOOLS = frozenset({"Edit", "Write", "MultiEdit", "NotebookEdit"})
# Read-only inspection tools — always permitted (output is redaction-hooked).
_READ_TOOLS = frozenset({"Read", "Glob", "Grep", "LS", "NotebookRead"})
# Masked by the PostToolUse hook so on-disk secrets/PII aren't egressed unredacted.
_REDACT_TOOLS = _READ_TOOLS | frozenset({"Bash"})


def _resolve_within_root(root: Path, raw: object) -> Path | None:
    """Resolve *raw* to a real path confined to *root*, or None if unresolvable/escaping/a symlink."""
    if not isinstance(raw, str) or not raw:
        return None
    try:
        candidate = Path(raw) if os.path.isabs(raw) else (root / raw)
        # Refuse a symlinked final component without following it — the redirect primitive denied.
        if candidate.is_symlink():
            return None
        target = candidate.resolve()
        target.relative_to(root)
    except (OSError, ValueError):
        return None
    return target


def _within_root(root: Path, raw: object) -> bool:
    """Return True iff *raw* resolves to a non-symlinked path inside (or equal to) *root*."""
    return _resolve_within_root(root, raw) is not None


def _sdk_env() -> dict[str, str]:
    """Inherit the ambient environment, forwarding the SDK-specific key as the standard ANTHROPIC_API_KEY when o..."""
    env = dict(os.environ)
    if not env.get("ANTHROPIC_API_KEY"):
        fallback = (env.get("ANTHROPIC_AUTH_TOKEN")
                    or env.get("ANTHROPIC_SDK_API_KEY"))
        if fallback:
            env["ANTHROPIC_API_KEY"] = fallback
    sdk_base = env.get("ANTHROPIC_SDK_BASE_URL")
    if sdk_base and not env.get("ANTHROPIC_BASE_URL"):
        env["ANTHROPIC_BASE_URL"] = sdk_base
    # Same no-resend env as the CLI route; set last so an ambient "0" cannot win.
    return {**env, **_NO_REFUSAL_RESEND_ENV}


#: Path keys redacted with ``carry=False``; NOT redact's `_NO_CARRY_KEYS` (``file`` holds content)
_TOOL_PATH_KEYS = frozenset({"filePath", "file_path", "filenames", "path"})


def _redact_tool_output(payload: object, *, carry: bool = True) -> object:
    """Mask secret/PII in *payload* (str/list/dict) via redact_counts(); unknown shapes pass."""
    if isinstance(payload, str):
        masked, _ = redact_counts(payload, carry=carry)
        return masked
    if isinstance(payload, list):
        return [_redact_tool_output(item, carry=carry) for item in payload]
    if isinstance(payload, dict):
        return {k: _redact_tool_output(v, carry=carry and k not in _TOOL_PATH_KEYS)
                for k, v in payload.items()}
    return payload


def _build_redaction_hooks():
    """Build a PostToolUse hook masking Read/Grep/Bash; best-effort, None if HookMatcher missing."""
    try:
        from claude_agent_sdk import HookMatcher  # type: ignore  # noqa: PLC0415 — optional SDK
    except Exception:
        return None

    async def _post_tool_use(input_data, tool_use_id, context):  # noqa: ANN001, ARG001
        try:
            tool_name = (input_data or {}).get("tool_name")
            if tool_name not in _REDACT_TOOLS:
                return {}
            response = (input_data or {}).get("tool_response")
            if response is None:
                return {}
            masked = _redact_tool_output(response)
            if masked == response:
                return {}
            # `updatedToolOutput` is the only key the CLI honours; the old name leaked cleartext.
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PostToolUse",
                    "updatedToolOutput": masked,
                }
            }
        except Exception:
            return {}

    try:
        return {"PostToolUse": [HookMatcher(hooks=[_post_tool_use])]}  # type: ignore[list-item]
    except Exception:
        return None


def _build_options(*, model: str, system_prompt: str | None,
                   allowed_tools: list[str], cwd: str,
                   max_budget_usd: float | None, max_turns: int | None):
    """Compose ClaudeAgentOptions with a cwd-confined write gate; lazy import keeps SDK optional."""
    try:
        from claude_agent_sdk import (  # noqa: PLC0415 — lazy: SDK stays optional
            ClaudeAgentOptions,
            HookMatcher,
        )
    except ImportError as e:
        raise RuntimeError(
            "This Claude Agent SDK build has no PreToolUse hook support "
            "(HookMatcher), which is what enforces the cwd-confined write "
            "gate on `via: sdk` (see _pre_tool_use_gate's docstring) — "
            "reinstall vvaharness to pull in a newer SDK release."
        ) from e

    root = Path(cwd).resolve()

    async def _pre_tool_use_gate(input_data, tool_use_id, context):  # noqa: ANN001, ARG001
        """PreToolUse hook enforcing the write-confinement + deny-by-default gate."""
        # Must stay PreToolUse, never can_use_tool (a bare allow entry bypasses it); fail-closed
        def _deny(reason: str) -> dict:
            return {"hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": reason,
            }}

        try:
            tool_name = (input_data or {}).get("tool_name") or ""
            tool_input = (input_data or {}).get("tool_input") or {}

            # File-mutation tools: allow only when the target stays inside the repo.
            if tool_name in _WRITE_TOOLS:
                raw = key_used = None
                for key in ("file_path", "path", "notebook_path"):
                    val = tool_input.get(key)
                    if val:
                        raw, key_used = val, key
                        break
                resolved = _resolve_within_root(root, raw)
                if resolved is None:
                    return _deny(f"{tool_name} target {raw!r} is outside the "
                                 f"repository root, unresolvable, or a symlink — "
                                 f"edits are confined to {root}")
                # Hand the SDK the resolved path, not the raw name, so an alias can't redirect it.
                safe_input = dict(tool_input)
                safe_input[key_used] = str(resolved)
                return {"hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "allow",
                    "updatedInput": safe_input,
                }}
            # Read-only tools need no decision: the bare allow entry below covers them.
            if tool_name in _READ_TOOLS:
                return {}
            # DENY-BY-DEFAULT, esp. Bash: host-shell RCE + credential exfil; re-adding it can't run.
            return _deny(f"{tool_name} is not permitted in remediation fix mode — "
                         f"only Read/Glob/Grep and cwd-confined Edit/Write are "
                         f"allowed (Bash and other tools are denied by default).")
        except Exception as exc:
            return _deny(f"the security gate could not evaluate this call "
                         f"({type(exc).__name__}) and denies it as a precaution.")

    redaction_hooks = _build_redaction_hooks() or {}
    hooks = {**redaction_hooks, "PreToolUse": [HookMatcher(hooks=[_pre_tool_use_gate])]}

    opts = ClaudeAgentOptions(
        model=model,
        cwd=str(root),
        env=_sdk_env(),
        # The PreToolUse hook above is the live gate; permission_mode/allowed_tools set availability
        permission_mode="default",
        setting_sources=None,
        allowed_tools=list(allowed_tools),
        hooks=hooks,
        # Finding text/code snippets reach this prompt; verbatim keeps them from being
        # parsed as an @path expansion or a slash command.
        verbatim_prompts=True,
    )

    if system_prompt is not None:
        opts.system_prompt = system_prompt
    if max_turns is not None:
        opts.max_turns = int(max_turns)
    if max_budget_usd is not None:
        opts.max_budget_usd = float(max_budget_usd)
    return opts


class DrainResult(NamedTuple):
    """One drain pass's outcome: the terminal ResultMessage, if any, and whether it timed out."""

    result: ResultMessage | None
    timed_out: bool


async def _drain(client, on_message) -> ResultMessage | None:  # noqa: ANN001
    """One fresh pass over `client.receive_response()`, returning the terminal ResultMessage."""
    from claude_agent_sdk import ResultMessage  # noqa: PLC0415 — lazy: SDK stays optional

    async for message in client.receive_response():
        on_message(message)
        if isinstance(message, ResultMessage):
            return message
    return None


async def drain_until_result(client, *, on_message, timeout: float | None,
                             grace: float = TIMEOUT_STOP_GRACE_SECONDS) -> DrainResult:
    """Drain *client* to its terminal result, bounded by `timeout`; interrupt-then-regrace on expiry."""
    if timeout is None or timeout <= 0:
        return DrainResult(await _drain(client, on_message), False)
    # .expired() tells OUR deadline apart from a TimeoutError raised inside the drain itself
    deadline = asyncio.timeout(timeout)
    try:
        async with deadline:
            return DrainResult(await _drain(client, on_message), False)
    except TimeoutError:
        if not deadline.expired():
            raise
    with contextlib.suppress(Exception):
        await client.interrupt()
    # The cancelled `async for` above finalized its generator; receive_response() opens a new one
    # (claude_agent_sdk.client.ClaudeSDKClient), so this second _drain is a fresh call, not a resume.
    regrace = asyncio.timeout(grace)
    try:
        async with regrace:
            return DrainResult(await _drain(client, on_message), True)
    except TimeoutError:
        if not regrace.expired():
            raise
        return DrainResult(None, True)


async def _run(*, user_prompt: str, opts, timeout: float | None = None,
               tag: str | None = None, effort: str | None = None) -> str:  # noqa: ANN001
    """Stream one agentic session to completion and return the final text."""
    from claude_agent_sdk import (  # noqa: PLC0415 — lazy: SDK stays optional
        AssistantMessage,
        ClaudeSDKClient,
        TextBlock,
    )

    text_parts: list[str] = []

    def _on_message(message) -> None:  # noqa: ANN001
        if isinstance(message, AssistantMessage):
            for block in message.content:
                if isinstance(block, TextBlock):
                    text_parts.append(block.text)

    # Session clock, scaled the same way every other route scales its own agentic() timeout.
    budget = effort_scaled_seconds(timeout, effort, kind=ClockKind.SESSION)
    # The caller owns no scope around this call: the client's __aexit__ (close()) must run with
    # no cancellation in flight, or the SDK skips its own terminate/kill escalation (subprocess_cli.py).
    _start = time.monotonic()
    async with ClaudeSDKClient(options=opts) as client:
        await client.query(user_prompt)
        drained = await drain_until_result(client, on_message=_on_message, timeout=budget,
                                           grace=TIMEOUT_STOP_GRACE_SECONDS)

    result = drained.result
    if result is not None and result.usage:
        TOKENS.add(cast("TokenUsage", result.usage))
    if drained.timed_out:
        raise call_timeout_error(
            stage=tag or "", route="agent-sdk", budget_s=budget, effort=effort,
            cause_text=f"agent-sdk session exceeded {budget:g}s")
    note_budget_use(time.monotonic() - _start, budget, effort)
    result_text = result.result if result is not None else None
    return (result_text or "".join(text_parts)).strip()


def agentic(
    user_prompt: str,
    *,
    model: str,
    system_prompt: str | None = None,
    allowed_tools: list[str] | None = None,
    cwd: str,
    max_budget_usd: float | None = None,
    permission_mode: str = "auto",   # accepted for parity; gate handles policy
    max_turns: int | None = None,
    tag: str | None = None,
    timeout: float | None = None,
    effort: str | None = None,
) -> str:
    """Run an agentic loop with native Edit/Write/Bash via the Agent SDK; writes cwd-confined."""
    try:
        import claude_agent_sdk  # noqa: F401, PLC0415 — availability probe
    except ImportError as e:
        raise RuntimeError(
            "An agentic role is configured `via: sdk` and requests file-editing "
            "tools (Edit/Write/Bash), which require the Claude Agent SDK. "
            "Reinstall vvaharness to pull it in (pip install .), or "
            "set this role to `via: cli`."
        ) from e
    # `None` = unspecified (read-only default), `[]` = none wanted; same as backends.llm.sdk.agentic
    allowed = list(DEFAULT_READ_TOOLS) if allowed_tools is None else list(allowed_tools)
    tag_sfx = f" [{tag}]" if tag else ""
    console.write(f"    [agent-sdk] agentic -> {model}{tag_sfx} (tools={allowed}, "
                  f"max_turns={max_turns}, cwd={cwd}, timeout={timeout})")

    opts = _build_options(
        model=model, system_prompt=system_prompt, allowed_tools=allowed,
        cwd=cwd, max_budget_usd=max_budget_usd, max_turns=max_turns,
    )
    return asyncio.run(_run(user_prompt=user_prompt, opts=opts, timeout=timeout,
                            tag=tag, effort=effort))
