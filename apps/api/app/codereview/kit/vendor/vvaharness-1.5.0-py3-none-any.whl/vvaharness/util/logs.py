# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Structured logging for the vvaharness package: key-value to a terminal, JSON to a file, always redacted."""
from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import Any

import structlog

from vvaharness.report.redact import redact

__all__ = ["LEVELS", "configure", "get_logger"]

#: The package logger every module's ``getLogger(__name__)`` inherits from.
_ROOT = "vvaharness"

#: Accepted ``--log-level`` values, lowest to highest noise.
LEVELS: tuple[str, ...] = ("critical", "error", "warning", "info", "debug")

_DEFAULT_LEVEL = "warning"

#: True once configure() has run; False routes a call to an embedder's own handlers.
_CLI_MODE = False


def get_logger(name: str) -> Any:
    """A bound structlog logger for *name*, usable as ``log.info("event", key=value)``."""
    return structlog.wrap_logger(
        logging.getLogger(name),
        # filter_by_level first: a filtered-out call must not pay for the processors below it.
        processors=[structlog.stdlib.filter_by_level, *_SHARED, _final],
        wrapper_class=structlog.stdlib.BoundLogger,
    )


def _final(logger: Any, name: str, event: dict[str, Any]) -> Any:
    """Dispatch at call time: our formatter chain once configure() has run, else plain
    kwargs for an embedder's own handlers (record attributes, no process-wide config)."""
    if _CLI_MODE:
        return structlog.stdlib.ProcessorFormatter.wrap_for_formatter(logger, name, event)
    kwargs = structlog.stdlib.render_to_log_kwargs(logger, name, event)
    exc = kwargs["extra"].get("exception")
    if exc:
        # exc_info=True is what a bare .exception() call defaults to; force it off so the
        # embedder's own formatter cannot re-render the raw, unredacted traceback itself.
        kwargs["msg"] = f"{kwargs['msg']}\n{exc}"
        kwargs["exc_info"] = False
    return kwargs


class _StderrHandler(logging.StreamHandler):
    """Looks ``sys.stderr`` up per record like ``print`` does, until a caller assigns a stream of its own."""

    def __init__(self) -> None:
        logging.Handler.__init__(self)
        self._explicit: Any = None

    @property
    def stream(self) -> Any:
        return sys.stderr if self._explicit is None else self._explicit

    @stream.setter
    def stream(self, value: Any) -> None:
        self._explicit = value


def _event_code(_logger: Any, _name: str, event: dict[str, Any]) -> dict[str, Any]:
    """Split a catalogue Event into its stable ``code`` and its human sentence."""
    from vvaharness.util.events import Event
    ev = event.get("event")
    if isinstance(ev, Event):
        event["code"], event["event"] = ev.name, ev.value
    return event


def _redact_value(v: Any) -> Any:
    """Mask secrets in *v* regardless of its container, so a Path, list or exception
    field cannot carry a credential past the ones a plain string field already caught."""
    if isinstance(v, str):
        return redact(v)
    if isinstance(v, (BaseException, os.PathLike)):
        return redact(str(v))
    if isinstance(v, (list, tuple, set, frozenset)):
        items = [_redact_value(x) for x in v]
        # A NamedTuple's own __new__ takes positional fields, not an iterable.
        return type(v)(*items) if hasattr(v, "_fields") else type(v)(items)
    if isinstance(v, dict):
        return {k: _redact_value(x) for k, x in v.items()}
    return v


def _redact_event(_logger: Any, _name: str, event: dict[str, Any]) -> dict[str, Any]:
    """Mask secrets in every field, so no field can leak a credential regardless of its type."""
    return {k: _redact_value(v) for k, v in event.items()}


_TAG = {"critical": "FATAL", "error": "ERROR", "warning": "WARN", "info": "INFO", "debug": "DEBUG"}
_ANSI = {"critical": "1;31", "error": "31", "warning": "33", "info": "36", "debug": "2"}
_RESET = "\x1b[0m"
_SKIP = ("event", "level", "logger", "timestamp", "code", "exc_info", "exception",
         "func_name", "lineno", "stack")


def _abbreviate(dotted: str) -> str:
    """Shorten ``vvaharness.backends.llm.tls`` to ``v.b.llm.tls`` the way enterprise log layouts do."""
    parts = dotted.split(".")
    if len(parts) < 3:
        return dotted
    return ".".join([p[0] for p in parts[:-2]] + parts[-2:])


class _ProductRenderer:
    """One stderr line per record: clock, level, abbreviated class path, message, fields, code."""

    def __init__(self, *, colour: bool) -> None:
        self._colour = colour

    def _paint(self, text: str, level: str) -> str:
        """ANSI-wrap *text* for *level*, or return it unchanged when colour is off."""
        return f"\x1b[{_ANSI.get(level, '0')}m{text}{_RESET}" if self._colour else text

    def __call__(self, _logger: Any, _name: str, event: dict[str, Any]) -> str:
        level = str(event.get("level", "info"))
        clock = str(event.get("timestamp", ""))[11:23]
        fields = " ".join(f"{k}={event[k]}" for k in event if k not in _SKIP)
        code = event.get("code")
        tail = " ".join(x for x in (fields, f"({code})" if code else "") if x)
        line = (f"  {self._paint(clock, 'debug')} "
                f"{self._paint(f'{_TAG.get(level, level.upper()):<5}', level)} "
                f"{_abbreviate(str(event.get('logger', '')))} : {event.get('event', '')}")
        if tail:
            line += "  " + self._paint(tail, "debug")
        exc = event.get("exception")
        return f"{line}\n{exc}" if isinstance(exc, str) and exc else line


def _supports_colour(stream: Any) -> bool:
    """Whether *stream* is a terminal the user has not asked to keep monochrome."""
    if os.environ.get("NO_COLOR") or os.environ.get("TERM", "") == "dumb":
        return False
    isatty = getattr(stream, "isatty", None)
    try:
        return bool(callable(isatty) and isatty())
    except (OSError, ValueError):
        return False


_SHARED: tuple[Any, ...] = (
    structlog.contextvars.merge_contextvars,
    structlog.stdlib.add_log_level,
    structlog.stdlib.add_logger_name,
    structlog.processors.TimeStamper(fmt="iso", utc=True),
    structlog.processors.StackInfoRenderer(),
    structlog.processors.format_exc_info,
    structlog.processors.CallsiteParameterAdder(
        [structlog.processors.CallsiteParameter.FUNC_NAME]),
    structlog.processors.UnicodeDecoder(),
    structlog.stdlib.PositionalArgumentsFormatter(),
    _event_code,
    _redact_event,
)


def configure(level: str | None = None, path: str | Path | None = None) -> bool:
    """Attach our redacting handler(s) to the ``vvaharness`` logger; idempotent, True when a level was asked for."""
    global _CLI_MODE
    asked = (level or os.environ.get("VVAHARNESS_LOG_LEVEL") or "").strip().lower()
    chosen = asked or _DEFAULT_LEVEL
    numeric = getattr(logging, chosen.upper(), None)
    if not isinstance(numeric, int):
        print(f"  WARN: unknown log level {chosen!r}; expected one of {', '.join(LEVELS)}",
              file=sys.stderr)
        numeric, asked = logging.WARNING, ""

    log = logging.getLogger(_ROOT)
    for existing in [h for h in log.handlers if getattr(h, "_vvaharness", False)]:
        log.removeHandler(existing)
        existing.close()
    for handler in _handlers(path or os.environ.get("VVAHARNESS_LOG_FILE")):
        handler.setFormatter(_formatter(handler))
        handler._vvaharness = True  # type: ignore[attr-defined]  # marks OUR handler for replacement
        log.addHandler(handler)
    log.setLevel(numeric)
    # Don't propagate to root, or a library consumer's own root handler would double every line.
    log.propagate = False
    _CLI_MODE = True
    return bool(asked)


def _formatter(handler: logging.Handler) -> logging.Formatter:
    """Product-shaped lines on stderr; one JSON object per line for --log-file."""
    renderer: Any
    if isinstance(handler, logging.FileHandler):
        renderer = structlog.processors.JSONRenderer()
    else:
        renderer = _ProductRenderer(colour=_supports_colour(getattr(handler, "stream", None)))
    return structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=list(_SHARED),
        processors=[structlog.stdlib.ProcessorFormatter.remove_processors_meta, renderer],
    )


def _handlers(path: str | Path | None) -> list[logging.Handler]:
    """Stderr always, plus a file handler when *path* is usable. Stderr is capped at
    WARNING only once a file also tees it, so a default run keeps today's single,
    uncapped handler."""
    stderr = _StderrHandler()
    if not path:
        return [stderr]
    try:
        dest = Path(path)
        dest.parent.mkdir(parents=True, exist_ok=True)
        file_handler: logging.Handler = logging.FileHandler(dest, encoding="utf-8")
    except OSError as exc:
        print(f"  WARN: cannot open log file {path} ({exc}); logging to stderr",
              file=sys.stderr)
        return [stderr]
    stderr.setLevel(logging.WARNING)
    return [stderr, file_handler]
