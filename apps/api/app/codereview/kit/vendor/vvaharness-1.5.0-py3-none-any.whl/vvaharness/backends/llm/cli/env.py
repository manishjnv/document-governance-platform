# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Process-global CLI config and the per-call subprocess environment."""
from __future__ import annotations

import os

from vvaharness.backends.harness.models import (
    EffortLevel,
)
from vvaharness.backends.llm.cli import discovery as _discovery
from vvaharness.backends.llm.models import (
    CliConfig,
)
from vvaharness.backends.llm.tls import coerce_verify
from vvaharness.util import logs
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

# CLI reaches Node via env vars (ca_cert, verify_ssl, no_proxy); mTLS unsupported, no env path.

_cfg: CliConfig = {"verify_ssl": True, "ca_cert": None,
              "client_cert": None, "no_proxy": None, "effort": "high",
              "restricted": True}
_tls_extra: dict = {}


def _build_tls_env() -> dict:
    """Translate the stored TLS/proxy config into subprocess env vars."""
    out: dict = {}
    ca = _cfg["ca_cert"]
    verify = _cfg["verify_ssl"]
    # A CA bundle may arrive as ca_cert or string verify_ssl (mirrors sdk.py precedence).
    bundle = ca or (verify if isinstance(verify, str) else None)
    if bundle:
        if os.path.exists(bundle):
            out["NODE_EXTRA_CA_CERTS"] = bundle
        else:
            log.warning(Event.TLS_CA_NOT_FOUND, path=bundle)
    if verify is False:
        out["NODE_TLS_REJECT_UNAUTHORIZED"] = "0"
        log.warning("TLS verification disabled (verify_ssl=false) for the "
              "claude subprocess")
    np = _cfg["no_proxy"]
    if np:
        out["NO_PROXY"] = np
        out["no_proxy"] = np
    if _cfg["client_cert"]:
        log.warning("client_cert/mTLS is configured but the `claude` CLI "
              "backend cannot present a client certificate (Node exposes no "
              "env-var path for it). Use a `via: sdk` or `via: deepagents` "
              "role for mTLS gateways.")
    return out


def configure(*, verify_ssl: bool | str | None = None,
              ca_cert: str | None = None,
              client_cert: str | tuple | None = None,
              no_proxy: str | None = None,
              effort: str | None = None,
              restricted: bool | None = None) -> None:
    """Push gateway TLS/proxy settings into the `claude` subprocess environment; mTLS is unsupported here."""
    if verify_ssl is not None:
        _cfg["verify_ssl"] = coerce_verify(verify_ssl)
    if ca_cert:
        _cfg["ca_cert"] = ca_cert
    if client_cert:
        _cfg["client_cert"] = client_cert
    if no_proxy:
        _cfg["no_proxy"] = no_proxy
    if effort:
        _cfg["effort"] = effort
    # `is not None`, not truthiness: False is the meaningful value here.
    if restricted is not None:
        _cfg["restricted"] = bool(restricted)
    _tls_extra.clear()
    _tls_extra.update(_build_tls_env())


def _effective_effort(effort: str | None) -> str | None:
    """Per-call *effort* if it parses to a known tier, else the process-global ``cli.effort``."""
    parsed = EffortLevel.parse(effort) if effort is not None else None
    return parsed.value if parsed is not None else _cfg.get("effort")


def _effort_argv(effort: str | None) -> list[str]:
    """The ``--effort <tier>`` argv for one call, or ``[]`` (probe-gated)."""
    tier = _effective_effort(effort)
    if tier and _discovery._cli_capabilities()["effort"]:
        return ["--effort", tier]
    return []


# By default the CLI re-sends a refused turn once and can switch to a fallback model, so flagged
# content would be sent again; set, the refusal ends the turn and ModelRefusal takes over.
_NO_REFUSAL_RESEND_ENV = {
    "CLAUDE_CODE_DISABLE_REFUSAL_RETRY": "1",
    "CLAUDE_CODE_DISABLE_REFUSAL_FALLBACK": "1",
}


def _session_pins(effort: str | None) -> dict[str, str]:
    """Env pinned on every ``claude`` session: the effort tier (or blank), no refusal resend."""
    # An exported CLAUDE_CODE_EFFORT_LEVEL overrides `--effort`, and os.environ is always spread
    # underneath, so an ambient value can only be overridden; blank reads as unset.
    effort_argv = _effort_argv(effort)
    return {"CLAUDE_CODE_EFFORT_LEVEL": effort_argv[1] if effort_argv else "",
            **_NO_REFUSAL_RESEND_ENV}


def _call_env(*, max_tokens: int | None, effort: str | None) -> dict[str, str]:
    """Per-call env overrides for one ``claude`` subprocess: the session pins plus any token cap."""
    env = _session_pins(effort)
    if max_tokens:
        env["CLAUDE_CODE_MAX_OUTPUT_TOKENS"] = str(max_tokens)
    return env
