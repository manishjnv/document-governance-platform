# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Config loader. Reads config.yaml, expands ${ENV:-default} placeholders."""
from __future__ import annotations

import os
import re
import stat
from pathlib import Path, PureWindowsPath
from typing import Final
from urllib.parse import urlsplit

import yaml

from vvaharness.config.constants import (
    CREDENTIAL_DESTINATIONS,
    ENDPOINT_KEYS,
    LOCAL_OVERLAY_NAME,
    NO_LOCAL_CONFIG_ENV,
    TLS_ROUTING_KEYS,
    is_secret_var_name,
)
from vvaharness.util import console

_ENV_PAT = re.compile(r"\$\{([A-Z_][A-Z0-9_]*)(?::-([^}]*))?\}")


class ConfigPolicyError(ValueError):
    """Refusal to load a config that violates the interpolation or overlay-trust policy."""


class ConfigPathError(ConfigPolicyError):
    """The --config path itself is unusable: missing, a directory, or unreadable.

    A subclass of ConfigPolicyError (not a sibling) so every existing
    ``except config_mod.ConfigPolicyError`` catch site starts reporting this
    clearly with no changes of its own — the alternative, YAML's own
    FileNotFoundError/IsADirectoryError/ParserError propagating raw, is the
    reported bug: a confusing downstream traceback instead of a clear
    "config not found" message."""

# Overlay paths already announced this process — load() is called several times
# per run (manifest capture, orchestrator, doctor, …); dedupe so the
# config.local.yaml provenance line is emitted once per unique overlay, not once
# per load() call.
_logged_overlays: set[str] = set()


def _expand_env(m: re.Match[str], path: tuple[str, ...]) -> str:
    name, default = m.group(1), m.group(2)
    key_path = ".".join(path)
    # Refused on the variable NAME alone, set or unset, so a profile fails the
    # same way on every machine instead of only where the secret is present.
    if is_secret_var_name(name) and key_path not in CREDENTIAL_DESTINATIONS:
        allowed = ", ".join(sorted(CREDENTIAL_DESTINATIONS))
        raise ConfigPolicyError(
            f"config key {key_path or '(root)'!r} interpolates environment "
            f"variable {name!r}, whose name matches a secret pattern; "
            f"secret-named variables may expand only into: {allowed}. "
            f"Remedies: move the value to one of those keys, rename the "
            f"variable, or write the value literally instead of interpolating.")
    # POSIX ${VAR:-default}: use the default when VAR is unset OR set-but-empty.
    val = os.environ.get(name)
    if val:
        return val
    return default if default is not None else ""


def _expand(val: object, path: tuple[str, ...] = ()) -> object:
    if isinstance(val, str):
        return _ENV_PAT.sub(lambda m: _expand_env(m, path), val)
    if isinstance(val, dict):
        return {k: _expand(v, (*path, str(k))) for k, v in val.items()}
    if isinstance(val, list):
        return [_expand(v, path) for v in val]
    return val


def _expand_tree(tree: dict, path: tuple[str, ...] = ()) -> dict:
    """Dict-preserving wrapper over _expand for the whole config tree."""
    return {k: _expand(v, (*path, str(k))) for k, v in tree.items()}


class Config:
    """Thin attribute wrapper over the YAML dict. cfg.models.deepdive etc."""
    def __init__(self, data: dict):
        self._data = data

    def __getattr__(self, name):
        # Guard against recursion during copy.deepcopy: _data and dunder probes
        # (__deepcopy__, __setstate__, __getstate__, ...) must NOT re-enter via
        # self._data, which is absent while the object is being reconstructed.
        if (name.startswith("__") and name.endswith("__")) or name == "_data":
            raise AttributeError(name)
        data = self.__dict__.get("_data")
        try:
            v = data[name]
        except (KeyError, TypeError) as e:
            raise AttributeError(name) from e
        return Config(v) if isinstance(v, dict) else v

    def __getitem__(self, k):
        return self._data[k]

    def __repr__(self):
        return f"Config({self._data!r})"


def _deep_merge(base: dict, over: dict) -> dict:
    out = dict(base)
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


# Merged UNDER any loaded config so a partial/hand-written config can never
# crash a stage with KeyError/AttributeError (e.g. a CLI-only config missing
# step4 knobs). User values always win; these only fill gaps. Structural keys
# (lists/dicts like exclude_dirs, specialists, config_dedup, allowed_tools) are
# intentionally omitted — the stages already default those internally and a
# defaults-layer entry would interfere with their append/merge semantics.
#
# Resolution order for any key registered here: profile value > this table >
# the call-site `getattr(cfg.stepN, key, X)` fallback. The last never fires
# through load() for a registered key — the merge guarantees the key exists —
# so an inline fallback that disagrees with this table (e.g. step4's
# `max_findings_per_run` fallback of `None` at the s4/session.py call site vs
# the `10` registered below) is dead code on
# the normal path, not a third effective default. When auditing "what value
# actually runs", read the loaded profile, never a single layer: a reviewer
# who reads a single call-site fallback instead can report a value that
# never actually runs.
_STEP_DEFAULTS: dict = {
    "step0": {
        "callgraph_detection": "rules",
        # Optional static-seed language filter (s0_seed._filter_step0_languages).
        "languages": None,
        # Floor below which a built code graph is treated as degenerate (too
        # few nodes to back a require_graph evidence gate) -- see
        # codegraph.build.graph_is_degenerate.
        "min_graph_nodes_for_gate": 10,
    },
    "step1": {
        "max_file_kb": 1024,
        # DEREGISTERED (2026-09-26), because no stage read any of them: `mode`
        # (full|gap_fill), `call_graph` (regex|tree_sitter),
        # `call_graph_validate`, `call_graph_supplement`, `call_graph_rounds`,
        # `call_graph_max_targets`, `max_turns` and `max_budget_usd`.
        # s1_preprocess.run makes no model call and builds no call graph — the
        # annotator and graph builder those keys configured lived in the
        # deleted call-graph engine package, and the graph
        # later stages query is the S0 entry-point/sink index hydrated from
        # SQLite. The dead regex def-scanner and callee resolver that still
        # named `call_graph_max_targets` in a warning were deleted with them.
        # Config is non-strict, so these keys left in an operator's own config
        # stay harmless and, as before, do nothing. Note the ONE model call that
        # is S1-adjacent: `auto_exclude` below (s1_autoexclude), which runs
        # before s1_preprocess.
        # Opt-in LLM auto-exclusion pass (s1_autoexclude): when enabled, an
        # extra model call proposes scan exclusions from a repo survey.
        # auto_exclude_max_tokens caps that survey prompt.
        "auto_exclude": False, "auto_exclude_max_tokens": 8000,
        # Reasoning tier for that survey call (low|medium|high|xhigh|max).
        # Matches every other stage's default: high. A survey reply clipped at
        # a budget the route could not grow is resent once without the tier
        # where the route drops it (s1_autoexclude, dispatch_or_retry_unforced).
        "auto_exclude_effort": "high",
        # Deterministic veto on MODEL-proposed auto-exclusions that would
        # remove web-template files (a canonical XSS surface) from scope.
        # Built-in excludes and operator overlays are never vetoed.
        "auto_exclude_protect_templates": True,
        # Same veto mechanism, for MODEL-proposed auto-exclusions that would
        # remove private-key / credential-dump files by naming convention
        # (see s1_autoexclude._is_key_material). Built-in excludes and
        # operator overlays are never vetoed.
        "auto_exclude_protect_key_material": True,
        # Same veto mechanism, for MODEL-proposed auto-exclusions that would
        # remove a file whose head content reads as key/secret material
        # (redact_counts finds a SECRET/AWS-KEY/etc. match) rather than one
        # that merely LOOKS like key material by filename convention (see
        # auto_exclude_protect_key_material above). Built-in excludes and
        # operator overlays are never vetoed.
        "auto_exclude_protect_secrets": True,
        # Same veto mechanism, for MODEL-proposed auto-exclusions that would
        # remove a first-party JavaScript/TypeScript file where s5's
        # DOM-sink detector fires (document.write of a URL-derived value).
        # Vendored/build JS is exempt, same as the vetoes above. Built-in
        # excludes and operator overlays are never vetoed.
        "auto_exclude_protect_client_sinks": True,
        # Back-compat symlink toggle: off-root symlink targets are dropped
        # regardless; when set, s1 warns rather than silently honouring it.
        "follow_symlinks": False,
    },
    "step2": {
        "max_tokens": 64000, "max_threats": 50,
        # One bounded re-invocation of the threat-model call when the sole
        # reply is degenerate or parses to zero threats on a non-empty repo,
        # or is rejected by the structured-output validator, or clips at the
        # 64000 cap while `effort` is set on a route that drops the tier (that
        # resend sends no tier) — a one-call stage can never trip the
        # 3-consecutive degenerate gate, so without this a single bad reply
        # silently hollows the whole scan.
        "empty_retry": True,
        "baseline": "auto", "max_doc_chars": 20000, "max_manifest_chars": 4000,
        "max_modules": 100, "max_entry_points": 400, "max_config_reps": 80,
        "max_api_artefacts": 100,
        "max_graph_files": 220, "max_graph_sinks": 80, "max_graph_edges": 100,
        # DEREGISTERED (2026-09-29): `max_function_sites` (alongside the
        # since-removed `max_notes_chars`) configured the deleted call-graph
        # engine's annotator (see step1's DEREGISTERED note above for the
        # same package). evidence/gather.py's `_Caps`/`_resolve_caps` — the
        # only reader of the sibling `max_graph_*` keys above — has no
        # function-sites concept, and nothing else in s2_threatmodel.py reads
        # it either, so there is no live call site to wire it into.
        # Prompt-truncation caps, distinct from the frontier-view caps above
        # (max_modules / max_entry_points).
        "max_prompt_modules": 100, "max_prompt_entry_points": 400,
        "max_inventory_files": 1200,
        # Grants the `execute` native plus an executing backend, for targeted shell
        # reads. Shell commands are NOT path-jailed — the backend's virtual root
        # confines file operations only. Off by default.
        "bash": False,
        # NOTE on `0` semantics, which differ between s2 and s3 and are easy to
        # get wrong: s2's caps go through `_cap_int` (s2_threatmodel.py), where
        # `0` means "emit none of this block" — a legitimate operator choice.
        # The s3 caps below are read as `int(getattr(...) or default)`
        # in the decompose stage, where `0` is falsy and therefore still means
        # "use the stated default". Do not assume one idiom from the other when
        # adding a read site.
        "timeout": 1800, "max_assets": 40, "max_trust_boundaries": 60,
        "max_manifest_depth": 3, "max_manifests": 12,
        "max_manifests_per_kind": 2, "max_manifest_total_chars": 24000,
        # Config-representative CONTENTS: the first max_config_rep_bodies
        # reps are packed as redacted bodies capped at max_config_rep_chars
        # each; the rest of the selection stays path-only.
        "max_config_rep_chars": 2000, "max_config_rep_bodies": 12,
        # Threat modelling is agentic unconditionally (step2.agentic was
        # deregistered — s2 always calls agentic() now). allowed_tools is this
        # read-only allowlist (validated in the stage against {Read, Glob,
        # Grep}; Bash/Edit are rejected) and max_turns is the only real bound
        # (max_budget_usd is a no-op on sdk/openai). allowed_tools is
        # registered here despite the structural-key note above because
        # step2 has no append/merge semantics: a profile value simply
        # replaces this list outright.
        # A tuple, not a list: _deep_merge assigns this default OBJECT into
        # every load()'d config, so a mutable default is shared process-wide and
        # one in-place mutation would poison every later load() in a batch run.
        # Immutable removes the aliasing hazard outright; consumers already
        # normalise with list(...).
        "allowed_tools": ("Read", "Grep"),
        "max_turns": 12,
        # 4 read-only graph-query tools (GraphNeighbors/GraphCommunityOf/
        # GraphImporters/GraphSinksInCommunity), live on both the one-shot and
        # agentic legs whenever ctx.graph_handle is present. graph_tool_budget
        # bounds total graph-tool calls per session (ToolCallBudget).
        "graph_tools": True, "graph_tool_budget": 6, "require_graph": True, "require_graph_rejections": 2, "planning": True, "skills": True, "effort": "high",
        # deadline bounds the agentic leg on EVERY route (the backends drop step*.timeout
        # on sdk/openai); on expiry the captured transcript is replayed, tool-free,
        # under replay_timeout for the structured threat model alone. 0 = no clock.
        "deadline": 400, "replay_timeout": 300, "replay_max_tokens": 16000,
        # resume_timeout bounds the deadline RESUME (live session, stage effort);
        # replay_timeout bounds the tool-free REPLAY. Defaults to replay_timeout. 0 = no clock.
        "resume_timeout": 300,
        # max_model_calls is the IN-SESSION cut: on the last permitted call every
        # tool but ThreatModel is withdrawn and that tool is forced, in the same
        # conversation with the prompt cache intact. 0 = unmetered, and then only
        # the deadline bounds the leg -- which costs a resume.
        "max_model_calls": 0,
    },
    # step3 has zero live keys: the annotating S3 makes no model call and its
    # only sizing logic (_size_for's SMALL/MEDIUM/LARGE thresholds) is module
    # constants, not config. `pack_by`/`chunk_token_budget`/
    # `chunk_overhead_tokens`/`risk_chunk_loc`/`max_files_per_chunk` served the
    # old per-(threat x community) packer and are deregistered along with it.
    "step3": {},
    "step4": {
        # No `timeout` key: it bound only the deleted one-shot leg's plain
        # `via: cli` subprocess. S4 is agentic unconditionally and its session
        # always carries a tool_builder (the graph tools), so `via: cli`
        # always takes the MCP-bridged path (`cli_mcp.agentic_with_tools`,
        # which does accept a session `timeout` but is never given one here)
        # rather than the plain `registry.agentic` path that honours one on
        # `via: cli` directly — S4 is deliberately bounded by `max_turns` and
        # `max_model_calls` instead of a wall clock.
        "parallel": 12,
        "max_turns": 15,
        # Stage-owned wall clock per session; on expiry the captured transcript is
        # replayed tool-free at lowest effort for the outcome alone. 0 = no clock.
        "deadline": 400, "replay_timeout": 60, "replay_max_tokens": 16000,
        # See step2.resume_timeout.
        "resume_timeout": 60,
        "max_model_calls": 0,
        "batch_size": 1,
        # A batch (batch_size > 1) whose shared session errors, omits a member, or fails to
        # parse is retried as one singleton session per lost member instead of leaving every
        # member uninvestigated -- the same findings, smaller sessions, one retry level deep
        # (a failed singleton has nothing left to split). Default ON.
        "split_retry": True,
        # Read-only jail, a tuple as in step2.allowed_tools. On via: cli a shell needs Bash
        # listed here plus step4.bash (the plain cli leg does not forward step4.bash).
        "allowed_tools": ("Read", "Glob", "Grep"),
        # See step2.bash: same grant, same unjailed-shell caveat. Off by default.
        "bash": False,
        # max_findings_per_run: 10 here is what a key-omitting profile runs; every
        # shipped profile raises it (50 in default/sdk/taint, 100 in full.yaml),
        # so this floor applies only to a hand-written config. The s4_deepdive
        # call-site fallback of None (= cap off) is
        # unreachable through load() (resolution-order note above). Over-cap
        # findings are counted as s4_findings_truncated and surfaced in the
        # report's Pipeline Diagnostics.
        "line_bucket": 10, "max_findings_per_run": 10,
        "max_tokens": 64000,
        # Deep-dive is agentic unconditionally (step4.agentic was deregistered
        # — one tool-using session per threat is the only leg left). Its tools (CweGuidance, the graph tools) reach
        # the model on ALL FOUR routes — natively on deepagents, through the
        # in-process tool adapter on sdk/openai, over the in-process MCP bridge
        # on cli when `cli.mcp_tools` is on. The preflight assertion in
        # orchestrator/preflight.py still fails loudly rather than degrade
        # silently, but now only for the one case that really drops them: a route
        # whose tool seam is switched off or unavailable (`cli.mcp_tools: false`,
        # or a missing Claude Agent SDK). Off the deepagents route the evidence
        # gate degrades to telemetry and write_todos/subagents are unavailable;
        # budgets are metered identically.
        "cwe_tools": True, "cwe_tool_budget": 6, "graph_tool_budget": 6,
        "planning": True, "inline_source": False,
        "evidence_gate": True, "evidence_gate_refusals": 3,
        "skills": True, "effort": "high", "require_graph": True,
        # Cap on also_cwes survivors per finding after same_weakness collapse
        # (s4/outcomes.py::_extra_cwes) -- bounds fan-out from one long
        # also_cwes list even after same-family/generic-parent dupes are gone.
        "max_extra_cwes": 2,
        # `frontier_fallback_head_lines` (default 80) and
        # `frontier_max_funcs_per_file` (default 24) were registered here but
        # read nowhere: s4's span fallback deliberately ships fallback files
        # WHOLE (see s4_deepdive) rather than truncated, so neither knob ever
        # had an effect. Deregistered rather than wired — a configured value
        # in an existing profile remains harmless (Config is non-strict) and
        # simply keeps doing nothing.
    },
    # step5_prefilter deliberately does NOT register line_tolerance: its
    # absence falls through to step7_dedup.line_tolerance
    # (s5/__init__._line_tolerance), and a registered default here would sever
    # that fallback. The old gate knobs (min_pre_confidence / require_evidence
    # / ast_backfill_evidence) were deregistered: no confidence signal exists
    # (every s4 finding is 0.5) and the evidence gate cost more true positives
    # than the verifier false positives it avoided. The reanchor keys below are
    # safe to register — they have no fallback-chain semantics.
    "step5_prefilter": {
        # Deterministic AST re-anchor: a finding whose anchor sits on a
        # function/class HEADER moves to the nearest matching sink call in the
        # same scope, so the primary location names the dangerous statement
        # rather than the decorator line. max_move_lines bounds the move to
        # roughly one handler body.
        "sink_reanchor": True, "sink_reanchor_max_move_lines": 40,
    },
    # Zero-LLM deterministic detector pass (s5): declarative rules for
    # mechanical, high-precision weakness shapes (cookie flags, unescaped
    # template sinks, ...). Every emitted row still flows through s6
    # verification — nothing unverified reaches the report.
    # `enabled` is the ONLY config surface, and it is all-or-nothing. Per-rule
    # enable flags are part of the rule DATA (MatchSpec.enabled in
    # detect/patterns.py), which is packaged source, NOT operator-reachable:
    # `detector-form-no-csrf-post` ships `enabled=False` there and cannot be
    # switched on from a profile or an overlay. Re-measure and flip the rule
    # datum if that should change; do not add a knob for it without deciding
    # the whole per-rule surface (see docs/USER_GUIDE.md#5-configuration).
    # max_rows bounds how many detector rows ONE scan may mint (cost guard —
    # every row becomes s6 verification work); <= 0 disables the cap.
    "step5_detectors": {"enabled": True, "max_rows": 200},
    "step6_verify": {
        # 32000, not step2/step4's 64000: below the cap, so BOTH the AGENTIC
        # primary call and the bounded json-repair re-ask that can follow it
        # (dispatch_prompt) get their one doubled-budget retry -- each doubles
        # 32000 to exactly the harness's 64000 ceiling,
        # deepagents.limits.MODEL_MAX_OUTPUT_TOKENS, before raising VVAH-E005
        # (docs/errors.md: "an AGENTIC call gets the same one doubled-budget
        # retry as a one-shot call, on every route that has one"). step2/step4
        # ship AT the 64000 cap, so their primary calls have no headroom to
        # double and raise on the FIRST truncation instead. There, with
        # `effort` set on a route that drops the tier, the stage seam resends
        # once without it (thinking is billed inside the same output budget)
        # — the only lever left at the cap. Any value in [32000, 64000)
        # reaches the same 64000 retry cap on both calls; 64000 itself makes
        # both doubled retries dormant.
        "max_tokens": 32000,
        "parallel": 5, "min_confidence": 7, "max_budget_usd": 10.0,
        # None = vendor default (deepagents' hardcoded 5s glob / 15s grep); see docs/errors.md.
        "tool_timeout_s": None,
        # 20 is what default.yaml and taint.yaml ship; sdk.yaml and full.yaml
        # raise it to 30 for the agentic tool loop their verifier routes
        # through. Registered at the lower value so a hand-written config gets
        # the cheaper bound, not the most expensive one.
        "max_turns": 20,
        # batch_size packs this many findings into one verification session,
        # file-sorted so co-located ones share the reading and the callers traced
        # for it. Every session is full except the last, so the session count
        # tracks the finding count, not the file count. 1 = one session per
        # finding, master's shape. inline_source hands the batch its files whole so
        # the session needs no Read turn; graph_tools composes the 4 read-only graph
        # tools, whose GraphImporters answers the reachability question this stage's
        # decision rule turns on. All three default to master-equivalent behaviour so
        # each is measurable on its own.
        "batch_size": 12, "inline_source": True,
        # graph_tool_budget is a PER-FINDING-IN-THE-BATCH allowance, scaled up
        # to cover the whole session (s6/session.py's _per_item): a batch of
        # `batch_size` findings gets `graph_tool_budget * batch_size` calls,
        # not this flat number -- a session now covers many findings, and a
        # cap sized for one starves the rest. A batch of 1 gets back exactly
        # this value, matching the historical flat-cap behaviour.
        "graph_tools": True, "graph_tool_budget": 4,
        # OFF by default (consolidated-fixlist B2): the verifier had no
        # evidence requirement on any route, but the 2026-09-25 replay that
        # deregistered step5_prefilter's evidence gate (see the block comment
        # above step5_prefilter) found an earlier gate cost more true
        # positives than it saved -- the same risk applies here and must be
        # measured before this flips on, not assumed. When true, mirrors
        # step4's require_graph: a healthy graph demands GRAPH_TOOL_NAMES
        # before a verdict; a degenerate one (graph_is_degenerate) stands
        # that requirement down instead of demanding tools that cannot exist
        # (B3's predicate, reused verbatim -- see s6/session.py).
        "require_graph": False,
        # Re-asks tolerated before the gate relents, once require_graph is
        # on. Same name and historical default as step4's identical knob, but
        # (unlike step4's) scaled PER FINDING IN THE BATCH the same way
        # graph_tool_budget is above -- see s6/session.py's _per_item.
        "evidence_gate_refusals": 3,
        "max_model_calls": 0,
        # Wall-clock ceiling per verification batch, seconds. A multi-finding
        # batch past the deadline is split-retried as singletons when
        # split_retry is on; a singleton (or split_retry off) resolves to the
        # existing VERIFY_ERROR (excluded — undetermined) path. Either way the
        # late result is discarded; on via:cli (plain or MCP-bridged) and
        # via:deepagents the in-flight call is cancelled at the ceiling, on
        # via:sdk/openai it is not (bounded only by max_turns), so this bounds
        # silent stalls without killing healthy long batches on those routes.
        # NOT named "timeout": that key is in the backend's accepted-unused
        # set and would be silently swallowed on the default route. The sweep
        # that enforces this ceiling is itself scaled by step6_verify.effort
        # (or the global cli.effort on via:cli) plus a stop grace, so it
        # never fires before the backend clock it backs up -- a session
        # clock, sized for high: ×1.1 at xhigh, ×1.5 at max.
        "batch_wall_clock_ceiling": 900,
        # Same stage-owned clock as step2.deadline, per batch; 0 = no clock.
        "batch_deadline": 400, "replay_timeout": 60, "replay_max_tokens": 12000,
        # See step2.resume_timeout.
        "resume_timeout": 60,
        # Trait stamps in the verifier's existing structured reply
        # (control_absence / posture channel). No extra model call; a missing
        # stamp defaults to today's behavior.
        "trait_stamps": True,
        # Reframe-not-drop: lets a verifier that refutes only the FRAMING of a
        # claim downgrade+relabel via the existing corrected_cwe path instead
        # of returning FALSE_POSITIVE. OFF until a follow-up verification
        # round tunes the prompt (LLM-behavioral).
        "reframe_enabled": False,
        # A batch (batch_size > 1) that raises VVAH-E005 -- the primary call,
        # or the json-repair re-ask after it -- or that is schema-rejected or
        # times out (raised by the call, or the ceiling above expiring), is
        # re-submitted as N
        # one-finding batches instead of dropping every member as
        # VERIFY_ERROR -- the same findings, smaller sessions, one retry
        # level deep (a truncated singleton has nothing left to split and
        # fails normally). Default ON: it completes the contract a
        # batch_size > 1 config assumes (grouped findings still each get a
        # verdict), at the cost of up to batch_size extra sessions on the
        # rare truncated batch. Fires on sdk/openai/deepagents/plain-cli;
        # cli.mcp_tools's bridge has no truncation detection today, so a
        # truncated bridged session neither retries nor splits.
        "split_retry": True,
        # Reasoning tier for the PRIMARY verification session only
        # (low|medium|high|xhigh|max); the json-repair re-ask never sends it.
        # high, matching every other stage. Thinking can leave the tool
        # unforced (route-dependent) and shares the output budget, so a schema rejection, or
        # a reply clipped at a budget the route could not grow, retries once
        # without it (s6/session.verify_batch, dispatch_or_retry_unforced);
        # via: cli would still send its global tier and never resends.
        "effort": "high",
        # Appends one line per verification session to a progress log as it
        # runs (see s6_verify's progress recorder) instead of only reporting
        # at the end. OFF by default; `--s6-progress-file` (orchestrator CLI)
        # flips it on for a long-running scan.
        "progress_file": False,
    },
    # Exploit verification (S6-EV). Flat for everything that means ONE thing, with a
    # sub-block only where a name would otherwise collide: `parallel` is
    # findings-at-once here but chunk-sessions-in-flight under classify/mapper,
    # `max_turns` is the attacker's loop budget but a mapping session's elsewhere, and
    # the only `max_tokens` is the judge's output cap. Which classify verdicts are
    # tested live is NOT a knob here or in a profile — it is `classify.LIVE_CLASSES`, a code
    # constant, because the set has no meaningful alternative value.
    "step6_exploit_verification": {
        # the pass as a whole
        "enabled": "auto", "on_unreachable": "drop", "ev_overrides_static": False,
        "parallel": 4, "store_probes": False,
        # every sender: transport, safety, budgets
        "timeout_s": 15, "safe_mode": True, "allow_state_changing_methods": False,
        "rate_limit_rps": 0,
        # Capped, not unlimited: every shipped profile chose 8/4, so 0 was a default no
        # profile used — and the one profile that inherited it ran uncapped against the
        # target. 0 still means "no cap" if an operator asks for it explicitly.
        "max_concurrency_target": 8, "max_concurrency_endpoint": 4,
        # ONE budget, shared by the deterministic first set AND the adaptive loop
        "max_requests_per_finding": 20,
        # sizes the DETERMINISTIC set (payloads.builder), which runs before the attacker
        "max_payloads_per_finding": 15,
        "oob": "auto",
        # auth
        "on_auth_failure": "degrade", "auth_expiry_skew_s": 60, "max_reauth": 3,
        # `vvaharness ev-replay`; flat because the name does not collide. Whether the
        # remediation judge runs is NOT a knob: it is the only thing that can turn "the tell
        # stopped firing" into a REMEDIATED verdict, so disabling it left the command able
        # to report still-vulnerable and nothing else. A run with no
        # `models.exploit_verification.judge` node already degrades to inconclusive, with a
        # reason that names the missing model.
        "ev_replay_variants": True,
        # per module
        # `effort` on every role below: the reasoning tier that role's calls send
        # (low|medium|high|xhigh|max); None sends none, the backend default.
        # Read through exploit_verification.settings.ev_effort. The judge's also
        # drives the ev-replay remediation judge; the mapper's covers both
        # endpoint_index and finding_map. A classify reply clipped at a budget
        # the route could not grow (a via: deepagents one-shot runs at the 64k
        # ceiling) is resent once without the tier (classify/llm._call).
        "classify": {"batch": 10, "parallel": 4, "effort": "high"},
        "mapper": {
            # both mapping stages share these; only the chunk size differs, because a
            # finding_map chunk may read code while an endpoint_index chunk lists routes
            "max_turns": 20, "parallel": 4, "effort": "high",
            "endpoint_index": {"chunk": 20},
            "finding_map": {"chunk": 6, "max_endpoints": 5},
        },
        "attacker": {"enabled": True, "max_turns": 15,
                     "max_tool_result_chars": 12000, "effort": "high"},
        # 4000, not 1500: a reply cut off mid-JSON does not parse, so too low a cap
        # costs the whole ruling rather than shortening it — and nothing detects the
        # truncation, so it reads as "the judge gave no verdict". A ruling is short;
        # max_tokens is a ceiling, not a reservation, so the headroom is free.
        "judge": {"max_tokens": 4000, "max_records": 24, "effort": "high"},
    },
    "step7_dedup": {"line_tolerance": 3, "semantic": False, "max_tokens": 64000,
                    # Reasoning tier for the semantic dedup call; high,
                    # matching every other stage. A DedupDecisions schema
                    # rejection, or a reply clipped at the 64000 cap, retries
                    # once without it (not on via: cli, nor on a via: sdk node
                    # with thinking_budget — both would still send reasoning).
                    "effort": "high",
                    # Same-site retention: when the semantic pass judges a
                    # collapse group "independent sink sites" (each needs its
                    # own fix), the distinct sink lines are retained as
                    # locations instead of silently discarded.
                    "per_sink_keep": True},
    # prompt_token_budget: fixed numeric guard rail for the enrichment
    # window. Past ~100k the 64k output cap binds before input does. Operator
    # invariant:
    # 1.25 * prompt_token_budget + max_tokens (+ ~5k ctx) < model context.
    "step8": {"max_tokens": 64000, "timeout": 3600,
              # Reasoning tier for the chaining call; high, matching every
              # other stage. A ChainReport schema rejection, or a reply
              # clipped at the 64000 cap, retries once without it (not on
              # via: cli, nor on a via: sdk node with thinking_budget — both
              # would still send reasoning).
              "effort": "high",
              "prompt_token_budget": 100000,
              # s8 reasons over a finding table it is handed whole, so it has
              # nothing to look up: 1 model call, and max_turns 2 because turn 1
              # is the forced ChainReport call and turn 2 is the tool result it
              # ends on. deadline bounds the session; this one-call stage has no
              # completed turn to resume, so a hit always replays the transcript
              # instead (see pipeline/stages/s8/session.py). 0 means no clock.
              "max_model_calls": 1, "max_turns": 2,
              "deadline": 600, "replay_timeout": 300,
              "replay_max_tokens": 16000,
              # Registered for parity with step2/4/6; s8 never resumes (see
              # above), so this stays unread on this stage.
              "resume_timeout": 300,
              # Adds each finding's scenario/preconditions to the chain prompt; opt-in
              # because the extra text shrinks the window and may shift the refusal rate.
              "hop_text": False,
              # Chain-quality controls (all deterministic; annotate/demote,
              # never drop): severity_lift_gate caps a chain's severity at its
              # strongest constituent unless its links are fully cited and no
              # non-terminal step is a stamped control-absence finding;
              # chain_quality_checks emits the per-chain annotations and the report-level
              # unpromoted-link disclosure;
              # chain_dedup collapses byte-identical chains and annotates
              # near-duplicates; prompt_fact_blocks feeds the chain call the
              # deterministic entry-point/deployment facts blocks.
              "severity_lift_gate": True, "chain_quality_checks": True,
              "chain_dedup": True, "prompt_fact_blocks": True},
    # S9 emission hygiene: skip results byte-identical on the same dedup key
    # typed_sarif.py uses for its severity-ranked survivor (channel/origin
    # included) — not first-in-report-order. Emit-only; findings.json and the
    # audit trail are untouched.
    "step9": {"duplicate_result_guard": True},
    "step_remediate": {"max_budget_usd": 10.0, "max_turns": 40,
                       # Wall clock per finding, seconds. Honoured on via:cli (the
                       # `claude` subprocess is killed at it), on via:sdk fix mode (a
                       # mutating-tool request delegates to the Claude Agent SDK
                       # backend, which enforces it as a session deadline), and on
                       # via:deepagents (its fix session is wrapped in the same
                       # deadline). via:openai's raw loop still only bounds itself by
                       # max_turns and accepts-and-ignores this knob. 3600 because a fix
                       # session reads, edits and re-reads several files and the
                       # budget/turn caps are meant to be what stops it -- this is the
                       # backstop for a session that stops making progress without
                       # spending, which no other bound catches. S10 has no effort knob,
                       # so this clock is not scaled by the request/session factor table.
                       "timeout": 3600,
                       "top_n_findings": 20,
                       # Optional overrides for the remediation policy gate /
                       # playbook (remediation_agent/policy/context.py). Each
                       # resolves relative to the active config; unset, empty,
                       # or unresolved falls back to the installed default.
                       "policy_file": None, "playbook_file": None},
    "step_validate": {"enabled": False, "effort": "high", "max_turns": 50, "max_budget_usd": 15.0, "max_findings": 20},
    "output": {"emit_unreachable_appendix": False,
               # Render posture-channel findings (Finding.channel ==
               # "posture", stamped by the s6 verifier) in their own report
               # subsection instead of interleaved with application defects.
               # They keep their severity and stay in findings.json/SARIF
               # either way.
               "posture_channel": True},
    # The `cli:` gateway block. Its TLS/effort keys are read straight off the
    # profile node by preflight (`cli.configure`) and are deliberately NOT
    # registered here — a missing `cli:` block must stay "no CLI settings", not
    # a synthesized one. `mcp_tools` IS registered, because it gates a
    # capability a stage asks about before dispatching, so it needs a value
    # even when a hand-written config omits the whole block.
    #
    # mcp_tools: on `via: cli`, publish a stage's own tools (S2/S6's six graph
    # tools, S4's CweGuidance) to the `claude` session through an in-process
    # MCP server, so they work on this route instead of silently vanishing.
    # ON by default: the alternative is an agentic session whose system prompt
    # advertises tools it cannot call. Set it false only to run those stages
    # tool-less on purpose (they still work — S2 falls back to reading files,
    # and the prompt then makes no tool claim), or to rule out the extra
    # `claude-agent-sdk` transport while debugging. It has no effect on any
    # other via: `deepagents` composes the same tools natively, and
    # `sdk`/`openai` never had them.
    # restricted: pass `--restricted` on via:cli agentic calls — the only read jail this
    # route has. WITHOUT it a detection session can read any file the operator
    # can; WITH it such a read is refused. That is the cwd-jail the
    # sdk/openai localtools have always had. ON by default, because "detection reads the
    # repository" should mean the repository. Set false only when your gateway auth is an
    # apiKeyHelper in USER settings, which `--restricted` ignores along with project and
    # local settings — that is the one thing it breaks, and it breaks auth outright, so
    # the escape hatch is real. Probe-gated: a build without the flag omits it and WARNs.
    "cli": {"mcp_tools": True, "restricted": True},
    # Top-level rather than per-step, because all three are properties of the
    # model route rather than of any one stage. `cache_min_block_tokens` is an
    # optional GLOBAL override of the per-model minimum cacheable block size
    # the sdk backend looks up for the model in use: providers publish a
    # minimum that varies (non-monotonically) by model, and a marker below it
    # is ignored silently while still consuming one of the few available
    # marker slots. Leave it null to use the published per-model minimums;
    # set it only for a gateway that enforces its own floor.
    # `cache_markers: off` suppresses every marker this tool places on the
    # `cli`, `sdk` and `openai` routes — the escape hatch for an endpoint that
    # rejects the field outright.
    #
    # It does NOT reach `via: deepagents`: that route gates ALL its markers
    # (the middleware's system/tools/tail breakpoints and the `cache_prefix`
    # one) on the `cache_markers` key of the `sdk:` transport block instead —
    # a deliberate reuse of the existing key rather than a third switch. An
    # operator silencing a strict gateway sets both. Documented in
    # docs/USER_GUIDE.md; do not restore the "every route" claim without
    # making it true.
    "cache_min_block_tokens": None,
    "cache_markers": "on",
    # How the sdk backend decides which cache-marker regime the endpoint
    # honours. "auto" (default) detects it from the base_url host, failing
    # closed to no markers on anything unrecognised. "anthropic" / "vertex" /
    # "bedrock" declare the regime for a gateway detection cannot classify —
    # e.g. a corporate proxy that is Anthropic-Messages-compatible and honours
    # cache_control. "none" forces no markers. Quote the value: an unquoted
    # `no`/`off` is a YAML boolean (tolerated, but quoting is clearer).
    "cache_route": "auto",
    # deepagents route only. True moves reasoning into the system prompt (REASON_IN_PROMPT) instead
    # of native reasoning, the only lever on thinking volume (effort tier does not lower it).
    # No-op on models matching model_building._NO_REASON_IN_PROMPT_RX, which reject it.
    "think_in_prompt": True,
    # One identical resend of a refused call, Anthropic routes only: an OpenAI-compatible gateway's
    # cyber filter can revoke the org. 0 also disables the S6 refused-batch split; load() caps at 1.
    "refusal_retries": 1,
    # Operator-supplied model price table (US dollars per million tokens) used
    # to cost the run manifest's per-stage token counts. No table is bundled —
    # rates are account/gateway-specific. VVAHARNESS_PRICING_FILE overrides
    # this key; with neither set every cost_usd is reported as null.
    "pricing": {"file": None},
}


def _local_overlay_trusted(path: Path) -> bool:
    """POSIX trust gate for the overlay: EUID- or root-owned, no group/world write."""
    try:
        st = path.stat()
    except OSError:
        return False
    get_euid = getattr(os, "geteuid", None)
    # File-only, unlike cli._dotenv_path_is_trusted: a file swapped in through a
    # writable parent is attacker-owned and already fails the UID check here.
    if get_euid is not None and st.st_uid not in (get_euid(), 0):
        return False
    return get_euid is None or not st.st_mode & (stat.S_IWGRP | stat.S_IWOTH)


def _require_overlay_trust(local: Path, log_overlay: bool) -> None:
    """Raise unless the overlay passes the POSIX trust gate; non-POSIX logs once instead."""
    if getattr(os, "geteuid", None) is None:
        if log_overlay:
            console.write(f"  config overlay: {local} ownership unverified "
                          f"(non-POSIX platform)")
        return
    if not _local_overlay_trusted(local):
        raise ConfigPolicyError(
            f"config overlay {local} is not trusted: it must be owned "
            f"by the invoking user (or root) and not group/world-"
            f"writable. Fix with `chmod go-w {local}` (and `chown` it "
            f"to yourself if needed), or set {NO_LOCAL_CONFIG_ENV} to "
            f"skip the overlay.")


def _local_overlay(local: Path) -> tuple[dict | None, bool]:
    """Trust-check and read config.local.yaml; (mapping, or None when absent/skipped)."""
    if not local.exists():
        return None, False
    key = str(local.resolve())
    log_overlay = key not in _logged_overlays
    _logged_overlays.add(key)
    if os.environ.get(NO_LOCAL_CONFIG_ENV):
        if log_overlay:
            console.write(f"  config overlay: {local} present but SKIPPED "
                          f"({NO_LOCAL_CONFIG_ENV} set)")
        return None, log_overlay
    _require_overlay_trust(local, log_overlay)
    over = yaml.safe_load(local.read_text(encoding="utf-8")) or {}
    if not isinstance(over, dict):
        # ValueError, not TypeError: the loader's YAML-shape refusal contract.
        raise ValueError(  # noqa: TRY004
            f"config {local} must be a YAML mapping, got {type(over).__name__}")
    return over, log_overlay


def _leaf_paths(tree: dict, prefix: tuple[str, ...] = ()) -> list[str]:
    """Dotted key paths of every leaf (non-dict) value in a nested mapping."""
    out: list[str] = []
    for k, v in tree.items():
        path = (*prefix, str(k))
        if isinstance(v, dict) and v:
            out.extend(_leaf_paths(v, path))
        else:
            out.append(".".join(path))
    return out


def _resolved_leaf(data: dict, path: str) -> object:
    node: object = data
    for seg in path.split("."):
        if not isinstance(node, dict):
            return None
        node = node.get(seg)
    return node


def _endpoint_display(value: object) -> str:
    """``host`` or ``host:port`` of an endpoint value — never its userinfo, never its path.

    SECURITY: the banner prints POST-expansion values on every command, so a
    ``https://user:token@gw.corp/v1`` base URL would otherwise echo the embedded
    credential to stderr and into CI logs. ``urlsplit().netloc`` KEEPS userinfo;
    ``.hostname`` drops it, which is the same host-only reduction
    ``preflight._scheme_host`` applies to this value class. Scheme-less values are
    re-parsed as an authority so ``user:tok@gw.corp/v1`` cannot fall through to a
    raw print.
    """
    raw = str(value or "").strip()
    if not raw:
        return "(unset)"
    try:
        parts = urlsplit(raw if "//" in raw else f"//{raw}")
        host, port = parts.hostname, parts.port
    except ValueError:                       # malformed authority / bad port
        return "(unparseable)"
    if not host:
        return "(unparseable)"
    return f"{host}:{port}" if port else host


def _override_entry(path: str, resolved: dict) -> str:
    """Render one overlay override with the visibility its value class allows."""
    value = _resolved_leaf(resolved, path)
    if path in CREDENTIAL_DESTINATIONS:
        entry = f"{path} ({'set' if value else 'unset'})"
    elif path in ENDPOINT_KEYS:
        # urlsplit locally, not preflight's _scheme_host: config must not import orchestrator.
        entry = f"{path} -> {_endpoint_display(value)}"
    elif path in TLS_ROUTING_KEYS or path.rsplit(".", 1)[-1] in TLS_ROUTING_KEYS:
        entry = f"{path}={value}"
    else:
        entry = path
    return entry


def _overlay_override_entries(leaves: list[str], resolved: dict) -> list[str]:
    """Per-class banner entries for the overlay's leaf key paths, sorted."""
    return [_override_entry(path, resolved) for path in sorted(leaves)]


def _path_context(p: Path) -> str:
    """Extra text naming the directory a relative *p* resolved against; empty for an absolute path."""
    if p.is_absolute():
        return ""
    return f" (resolved: {p.resolve()}, cwd: {Path.cwd()})"


def read_primary(path: str | Path) -> dict:
    """Read the primary configuration without overlays or environment expansion."""
    p = Path(path)
    # Validate the path itself before ever touching its contents, so a bad
    # --config reports clearly here instead of raising FileNotFoundError /
    # IsADirectoryError / a raw yaml.YAMLError from three frames down.
    if not p.exists():
        raise ConfigPathError(f"config not found: {p}{_path_context(p)}")
    if not p.is_file():
        raise ConfigPathError(f"config path is not a file: {p}{_path_context(p)}")
    if not os.access(p, os.R_OK):
        raise ConfigPathError(f"config is not readable: {p}{_path_context(p)}")
    # safe_load returns None for an empty/all-comments/whitespace file; treat
    # that as an empty mapping rather than crashing on later attribute access.
    try:
        raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as e:
        # The reported symptom: --config pointed at an unintended file
        # (right type, wrong content) surfaces the raw parser traceback
        # instead of a message that says WHICH file is the problem.
        raise ConfigPathError(f"config at {p} is not valid YAML: {e}{_path_context(p)}") from e
    except UnicodeDecodeError as e:
        # Same symptom for a binary / non-UTF-8 file: name it, no traceback.
        raise ConfigPathError(f"config at {p} is not valid UTF-8: {e}{_path_context(p)}") from e
    if not isinstance(raw, dict):
        raise ConfigPathError(f"config {p} must be a YAML mapping, got {type(raw).__name__}")
    return raw


def load(path: str | Path = "config.yaml") -> Config:
    p = Path(path)
    raw = read_primary(p)
    # Fill any missing scalar step-knobs from the built-in defaults so partial
    # configs never crash a stage. User-supplied values take precedence.
    raw = _deep_merge(_STEP_DEFAULTS, raw)
    # config.local.yaml (git-ignored, never bundled) deep-merges OVER the chosen
    # config. It can override security-relevant keys (model routing, sdk/openai
    # base_url, TLS ca_cert, tool permissions), so it is honoured only when the
    # file is trusted (see _local_overlay_trusted) and the merge is made VISIBLE
    # rather than silent: log the overlay file and the leaf keys it overrides,
    # with resolved endpoint hosts, on every command (not just scan). Set
    # VVAHARNESS_NO_LOCAL_CONFIG (to any value) to skip the overlay entirely —
    # for a reproducible run that honours only the operator-selected config.
    # The overlay resolves next to the --config path (operator-controlled),
    # never the scanned target.
    local = p.with_name(LOCAL_OVERLAY_NAME)
    over, log_overlay = _local_overlay(local)
    if over is not None:
        raw = _deep_merge(raw, over)
    data = _expand_tree(raw)
    _check_refusal_retries(data.get("refusal_retries"), p)
    # Banner emitted AFTER expansion so endpoint/TLS entries show resolved values.
    if over is not None and log_overlay:
        overrides = ", ".join(_overlay_override_entries(_leaf_paths(over), data)) or "(empty)"
        console.write(f"  config overlay: {local} applied "
                      f"(overrides: {overrides})")
    cfg = Config(data)
    # Record the directory the config was loaded from so input-style paths
    # (e.g. step_remediate.policy_file, TLS cert paths) can be resolved
    # against it, the same anchor scan.py uses for cfg.inject.*.
    cfg._data["_config_dir"] = str(p.resolve().parent)
    return cfg


#: refusal_retries ceiling: each send past one resend repeats content the classifier flagged.
_REFUSAL_RETRIES_MAX: Final = 1


def _check_refusal_retries(value: object, p: Path) -> None:
    """Refuse a ``refusal_retries`` that is not an int in 0..1 (null keeps the default)."""
    # bool is an int subclass: `true` must not read as 1
    if value is None or (isinstance(value, int) and not isinstance(value, bool)
                         and 0 <= value <= _REFUSAL_RETRIES_MAX):
        return
    raise ConfigPolicyError(
        f"config {p}: refusal_retries must be an integer from 0 to {_REFUSAL_RETRIES_MAX} "
        f"(got {value!r}); each extra resend repeats a prompt the model already refused")


def _replace_merge(base: dict, over: dict) -> dict:
    """Deep-merge where dicts recurse and everything else (incl. lists)
    REPLACES. Used for nested step1 sub-blocks like config_dedup so the
    latest overlay's list values win outright instead of accumulating."""
    out = dict(base)
    for k, v in over.items():
        cur = out.get(k)
        if isinstance(v, dict) and isinstance(cur, dict):
            out[k] = _replace_merge(cur, v)
        else:
            out[k] = v
    return out


def _append_merge(base: dict, over: dict) -> dict:
    """step1 overlay merge: top-level lists (exclude_dirs/exts/globs) APPEND
    so per-app files add to the global baseline; nested dicts switch to
    replace-merge so e.g. config_dedup.exts is taken from the latest overlay
    rather than concatenated."""
    out = dict(base)
    for k, v in over.items():
        cur = out.get(k)
        if isinstance(v, dict) and isinstance(cur, dict):
            out[k] = _replace_merge(cur, v)
        elif isinstance(v, list) and isinstance(cur, list):
            out[k] = list(cur) + [x for x in v if x not in cur]
        else:
            out[k] = v
    return out


def is_network_path(path: str | Path) -> bool:
    """True if *path* is a UNC / network location (``\\\\host\\share`` or
    ``//host/share``). Reading such a path on Windows triggers SMB
    authentication, which transmits the caller's NTLMv2 hash to the (possibly
    attacker-controlled) host. Callers must refuse these before any filesystem
    access. Evaluated with PureWindowsPath so the result is identical on every
    OS, not just where the run happens to land."""
    s = str(path).strip()
    if s.startswith("\\\\") or s.startswith("//"):
        return True
    # UNC drives render as '\\host\share'; local drives render as 'C:'.
    return PureWindowsPath(s).drive.startswith("\\\\")


# An operator-specified overlay path is one typo away from pointing at the wrong
# file (a report, a binary, a checked-out repo's own multi-MB YAML); cap the read
# so that mistake is a clear message, not a multi-second hang decoding garbage.
_MAX_STEP1_OVERLAY_BYTES: Final = 1 * 1024 * 1024


def apply_step1_overlay(cfg: Config, path: str | Path, *,
                        expand: bool = True) -> tuple[Config, bool]:
    """Layer a per-scan step1 file on top of cfg.step1. Accepts either a
    bare-key file (exclude_dirs:, exclude_exts:, …) or one wrapped in a
    top-level `step1:` block. Lists append; scalars replace. Returns
    (cfg, applied). expand=False keeps ${...} literal — for the LLM-authored
    auto-step1 overlay, which must never reach the operator's environment."""
    p = Path(path)
    # Refuse network/UNC paths before the first filesystem touch (is_file
    # below) — on Windows that touch would leak the user's NTLM hash via SMB.
    if is_network_path(p):
        raise ValueError(
            f"step1 overlay must be a local path; refusing network/UNC path {p!r} "
            f"(reading it could leak credentials over SMB)")
    if not p.is_file():
        return cfg, False
    size = p.stat().st_size
    if size > _MAX_STEP1_OVERLAY_BYTES:
        raise ValueError(
            f"step1 overlay {p} is {size} bytes, exceeding the "
            f"{_MAX_STEP1_OVERLAY_BYTES}-byte limit; check this is the "
            f"intended overlay file, not a wrong path")
    try:
        text = p.read_text(encoding="utf-8")
    except UnicodeDecodeError as e:
        raise ValueError(
            f"step1 overlay {p} is not valid UTF-8 text ({e}); check this is "
            f"the intended overlay file, not a wrong or binary path") from e
    try:
        over = yaml.safe_load(text) or {}
    except yaml.YAMLError as e:
        raise ValueError(f"step1 overlay {p} is not valid YAML: {e}") from e
    if not isinstance(over, dict):
        raise ValueError(f"step1 overlay {p} must be a YAML mapping")
    if set(over) == {"step1"} and isinstance(over["step1"], dict):
        over = over["step1"]
    over = _expand_tree(over, ("step1",)) if expand else over
    base1 = cfg._data.get("step1") or {}
    cfg._data["step1"] = _append_merge(base1, over)
    return cfg, True
