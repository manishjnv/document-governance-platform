# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""vvaharness CLI entry point — `scan` (default), `doctor`, `estimate`, and the other subcommands."""
from __future__ import annotations
from vvaharness.util import logs

import os
import signal
import sys
import threading
from pathlib import Path

from vvaharness.cli import _app
from vvaharness.cli._commands import (
    _ICON,
    _doctor,
    _estimate,
    _ev_replay,
    _gc,
    _remediate,
    _validate,
)
from vvaharness.cli._dotenv import (
    _dotenv_path,
    _dotenv_path_is_trusted,
    _dotenv_selection,
    _load_dotenv,
)
from vvaharness.cli._paths import (
    _check_python,
    _config_path_from,
    _config_path_from_explicit,
    _config_trust_boundary,
    _load_and_configure,
    _repo_from,
)
from vvaharness.cli._setup import (
    _install_agents,
    _prompt_for_remediation_inputs,
    _setup,
)
from vvaharness.validation.constants.artifacts import VALIDATE_COMMANDS
from vvaharness.util import console
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

__all__ = [
    "VALIDATE_COMMANDS",
    "_app",
    "_with_command",
    "_ICON",
    "Path",
    "_check_python",
    "_config_path_from",
    "_config_path_from_explicit",
    "_config_trust_boundary",
    "_configure_logging",
    "_doctor",
    "_dotenv_path",
    "_dotenv_path_is_trusted",
    "_dispatch",
    "_dotenv_selection",
    "_estimate",
    "_ev_replay",
    "_gc",
    "_install_agents",
    "_load_and_configure",
    "_load_dotenv",
    "_print_help",
    "_prompt_for_remediation_inputs",
    "_remediate",
    "_repo_from",
    "_setup",
    "_validate",
    "_version",
    "main",
    "os",
    "sys",
]


_COMMAND_HELP: tuple[tuple[str, str], ...] = (
    ("setup", "Guided readiness check: AI agents, keys, deps, gateway, config"),
    ("doctor", "Check credentials + live backend connectivity (read-only)"),
    ("estimate", "Print a rough scope/cost preview for a repo (no API spend)"),
    ("gc", "Delete old runs: checkpoints and code-graph workspaces (--keep-runs / --max-age-days / --dry-run)"),
    ("scan", "Scan a repo (or --repo-file batch) for vulnerabilities"),
    ("remediate", "Walk findings from a prior scan and remediate them"),
    ("validate", "Run the s11 agentic validation agent on applied remediations"),
    ("ev-replay", "Re-check exploit-verified findings against a REDEPLOYED target"),
)

_NOTES: tuple[str, ...] = (
    "[heading]Stages[/heading]",
    "  scan: the packaged default skips S10/S11; --remediate enables S10 only and can edit source.",
    "  scan: in-scan S11 needs step_validate.enabled: true, and --stop-after s9 skips both.",
    "  doctor --cache-probe: opt-in live prompt-cache diagnostic. Spends real tokens"
    " (~65-70k/model, printed first); never runs during `scan`.",
    "  remediate: --interactive/-i to pick from a menu; --mode fix|report-only; --top N"
    " overrides step_remediate.top_n_findings (--top all remediates every one); --verbose/-v.",
    "",
    "[heading]Config[/heading]",
    "  ./config.yaml when present, otherwise the packaged default.",
    "  Customise: cp vvaharness/config/profiles/sdk.yaml config.yaml   (see also full.yaml)",
    "  sdk/full profiles enable S10/S11; default/taint disable them. A local overlay can"
    " override these flags.",
    "  Standalone remediate and validate remain available when the scan flags are false.",
    "",
    "[heading]Quick start[/heading]",
    "  vvaharness setup",
    "  vvaharness estimate --repo /path/to/target",
    "  vvaharness scan --repo /path/to/target --application-id 12345",
    "  vvaharness scan --repo /path/to/target --stop-after s9   [dim]# skip S10/S11 on any"
    " profile[/dim]",
    "",
    "[dim]Run `vvaharness <command> --help` for a command's own options.[/dim]",
)


def _print_help() -> None:
    """Render the command table and the stage/config notes to stdout, unwrapped."""
    from rich.console import Console

    from vvaharness import __version__
    from vvaharness.util.console import THEME, banner, status_table

    out = Console(file=sys.stdout, soft_wrap=True, highlight=False, emoji=False,
                  theme=THEME, no_color=bool(os.environ.get("NO_COLOR")))
    if not banner(err=False):
        out.print(f"[heading]vvaharness {__version__}[/heading] — agentic SAST pipeline")
    out.print("\nUsage: vvaharness <command> [options]\n", markup=False)
    table = status_table(title="Commands:", columns=("", "command", "what it does"))
    for name, blurb in _COMMAND_HELP:
        table.add_row("", f"[model]{name}[/model]", blurb)
    table.add_row("", "[model]--version[/model]", "Print the installed version")
    out.print(table)
    out.print("")
    for line in _NOTES:
        out.print(line)

def _configure_logging(args: list[str]) -> list[str]:
    """Honour --log-level / --log-file (stripped, since subcommand parsers don't declare them), returning *args* without them."""
    from vvaharness.util.logs import configure

    level, path, rest = None, None, []
    it = iter(range(len(args)))
    skip = -1
    for i in it:
        if i <= skip:
            continue
        arg = args[i]
        for flag, setter in (("--log-level", "level"), ("--log-file", "path")):
            if arg == flag and i + 1 < len(args):
                value, skip = args[i + 1], i + 1
                break
            if arg.startswith(f"{flag}="):
                value, setter = arg.split("=", 1)[1], setter
                break
        else:
            rest.append(arg)
            continue
        if setter == "level":
            level = value
        else:
            path = value
    configure(level, path)
    return rest

def _with_command(args: list[str]) -> list[str]:
    """Prefix an implicit ``scan`` when the first token names no command, keeping `vvaharness --repo X`."""
    return args if args[0] in _app.COMMANDS else ["scan", *args]


def _version() -> int:
    """Print the package version without loading configuration or environment."""
    from vvaharness import __version__

    print(f"Visa Vulnerability Agentic Harness {__version__}")
    return 0

def _dispatch(args: list[str]) -> int:
    """Run the subcommand named by ``args[0]`` (bare args mean ``scan``)."""
    cmd = args[0]
    if cmd in ("setup", "init"):
        return _setup(args[1:])
    if cmd == "doctor":
        return _doctor(args[1:])
    if cmd == "estimate":
        return _estimate(args[1:])
    if cmd == "gc":
        return _gc(args[1:])
    if cmd == "remediate":
        return _remediate(args[1:])
    if cmd == "ev-replay":
        return _ev_replay(args[1:])
    if cmd in VALIDATE_COMMANDS:
        return _validate(args[1:])
    if cmd == "scan":
        args = args[1:]

    from vvaharness import config as config_mod
    from vvaharness import manifest, orchestrator
    from vvaharness.orchestrator.entry import build_parser

    try:
        build_parser().parse_args(args)
    except SystemExit as result:
        return int(result.code or 0)
    cfg_path, explicit = _config_path_from_explicit(args)
    try:
        # quiet=True: this resolution only feeds the manifest record, but a hard refusal stops here
        cfg_path = orchestrator.trusted_config(
            cfg_path, _config_trust_boundary(args), explicit=explicit, quiet=True)
        config_mod.read_primary(cfg_path)
    except config_mod.ConfigPolicyError as e:
        log.error(Event.CONFIG_POLICY_REFUSED, detail=str(e))
        return 2

    def _raise_terminated(signum, frame):
        raise manifest._Terminated(143)

    # Only the main thread may register a signal handler; a non-default
    # handler already installed is the operator's own and must not be replaced.
    _install_sigterm = (threading.current_thread() is threading.main_thread()
                        and signal.getsignal(signal.SIGTERM) is signal.SIG_DFL)
    _old_sigterm = (signal.signal(signal.SIGTERM, _raise_terminated)
                    if _install_sigterm else None)
    try:
        # Explicit argv avoids global sys.argv mutation, so concurrent in-process main() calls don't collide.
        with manifest.capture(cfg_path, args) as m:
            rc = orchestrator.main(args)
            m["exit_code"] = rc
        return rc
    finally:
        if _install_sigterm:
            signal.signal(signal.SIGTERM, _old_sigterm)


def main(argv: list[str] | None = None) -> int:
    try:
        err = _check_python()
        if err:
            log.error(Event.PYTHON_UNSUPPORTED, detail=err)
            return 2

        args = list(sys.argv[1:] if argv is None else argv)
        if args == ["--version"]:
            return _version()
        _load_dotenv(_repo_from(args))
        # Consumed here (before any command) rather than per-subcommand parser, since three are hand-rolled.
        args = _configure_logging(args)
        # Must not silently default to `scan`, which would write a junk run_manifest.json.
        if not args:
            _print_help()
            return 0
        if args[0] in ("-h", "--help", "help"):
            _print_help()
            return 0
        # Lazy (~1.4s): must stay below the --version/help returns above.
        from vvaharness.orchestrator import store

        try:
            return _app.run(_with_command(args))
        except store.StoreError as e:
            # A symlinked state dir/DB is an operator fix, not a crash: one line, exit 2
            log.error(Event.STORE_UNUSABLE, detail=str(e))
            return 2
    except KeyboardInterrupt:
        console.mark("fail", "command aborted by user (Ctrl-C).", indent=2, lead="\n")
        return 130
