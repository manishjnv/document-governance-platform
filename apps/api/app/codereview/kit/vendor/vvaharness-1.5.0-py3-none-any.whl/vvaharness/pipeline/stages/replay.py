# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Bound a stage at a wall clock, then re-ask for its output from the transcript it got to."""
from __future__ import annotations

import threading
import time
from collections.abc import Callable, Iterator
from concurrent.futures import Future
from contextlib import contextmanager
from typing import Any, TypeVar
from uuid import uuid4

from langchain.agents.middleware.types import AgentMiddleware

from vvaharness.backends.llm import cli as _cli
from vvaharness.backends.llm.deepagents import release_pinned_session
from vvaharness.backends.llm.deepagents import resume_agentic as _resume_agentic
from vvaharness.backends.llm.models import (
    TIMEOUT_STOP_GRACE_SECONDS,
    ClockKind,
    ModelRefusal,
    call_timeout_error,
    effort_scaled_seconds,
)
from vvaharness.util import console, logs
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

__all__ = [
    "S2_REPLAY_INSTRUCTION",
    "S4_REPLAY_INSTRUCTION",
    "S6_REPLAY_INSTRUCTION",
    "S8_REPLAY_INSTRUCTION",
    "RecordTranscript",
    "Transcript",
    "deadline_bound",
    "pinned_session",
    "replay_prompt",
    "resume_or_replay",
    "run_with_deadline",
    "session_id_for",
    "settle_future",
    "start_daemon",
]

_T = TypeVar("_T")

_MAX_ENTRY_CHARS = 4000
_ROLE_OF = {"human": "USER", "ai": "ASSISTANT", "tool": "TOOL RESULT", "system": "SYSTEM"}

_PREAMBLE = (
    "The session below hit its wall-clock deadline before it reported. Every message it "
    "exchanged, every tool it called and every tool result it received is reproduced "
    "verbatim.\n\n"
    "You have no tools and no further turns. Report from this transcript alone, and keep "
    "every conclusion it already establishes — losing them is the only failure mode here.\n"
)

S2_REPLAY_INSTRUCTION = _PREAMBLE + (
    "Report the threat model NOW. Keep every asset, trust boundary and threat the transcript "
    "reached. Where it left a baseline item undisposed, say so in open_questions rather than "
    "omitting it.\n"
)

S4_REPLAY_INSTRUCTION = _PREAMBLE + (
    "Report the investigation outcome NOW, one per unit id you were given. Keep every finding "
    "the transcript already evidenced, with its file and line. A unit the transcript never "
    "reached is `inconclusive`, never a silent omission.\n"
)

S6_REPLAY_INSTRUCTION = _PREAMBLE + (
    "Report the verification outcomes NOW, one per finding id you were given. A finding the "
    "transcript never reached is `inconclusive`, never a silent omission.\n"
)

# s8 is the one stage whose output cannot cost a true positive: hydrate_report ranks the findings it
# was GIVEN, so an empty chain list still ships all of them. So this re-ask asks for less, not more.
S8_REPLAY_INSTRUCTION = _PREAMBLE + (
    "Report the chain analysis NOW. Emit only the chains the transcript already evidenced and the "
    "findings whose severity it already decided to change — an unfinished chain is worth less than "
    "no chain, so drop it rather than guessing the rest of its links.\n"
)


def _text_of(content: Any) -> str:
    """One message's content as text, flattening the block-list shape both routes may use."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = [
            str(b.get("text") or b.get("content") or "") if isinstance(b, dict) else str(b)
            for b in content
        ]
        return "\n".join(p for p in parts if p)
    return "" if content is None else str(content)


def _role_of(message: Any) -> str:
    """A message's display role, from either a langchain object or an API-shaped dict."""
    if isinstance(message, dict):
        raw = str(message.get("role") or message.get("type") or "")
    else:
        raw = str(getattr(message, "type", None) or getattr(message, "role", "") or "")
    return _ROLE_OF.get(raw.lower(), raw.upper() or "MESSAGE")


def _tool_calls_of(message: Any) -> str:
    """The tool calls a message requested, one line each, or empty when it requested none."""
    calls = (message.get("tool_calls") if isinstance(message, dict)
             else getattr(message, "tool_calls", None)) or []
    lines = []
    for call in calls:
        if not isinstance(call, dict):
            continue
        fn = call.get("function") if isinstance(call.get("function"), dict) else {}
        name = call.get("name") or fn.get("name") or "?"
        args = call.get("args") or fn.get("arguments") or ""
        lines.append(f"  -> called {name}({str(args)[:400]})")
    return "\n".join(lines)


class Transcript:
    """The running conversation, captured so a killed session can still be asked for its output."""

    def __init__(self) -> None:
        """Start empty; a route that cannot share its conversation simply never records."""
        self._messages: list[Any] = []
        self._lock = threading.Lock()

    def record(self, messages: Any) -> None:
        """Keep *messages* when it is at least as complete as what is already held."""
        try:
            captured = list(messages or [])
        except TypeError:
            return
        with self._lock:
            if len(captured) >= len(self._messages):
                self._messages = captured

    @property
    def captured(self) -> bool:
        """Whether the route shared any conversation with this sink."""
        with self._lock:
            return bool(self._messages)

    def render(self, *, max_chars: int = 120_000) -> str:
        """The conversation as a prompt block, oldest turns trimmed first when it must shrink."""
        with self._lock:
            held = list(self._messages)
        blocks: list[str] = []
        for message in held:
            raw = (message.get("content") if isinstance(message, dict)
                   else getattr(message, "content", ""))
            body, calls = _text_of(raw), _tool_calls_of(message)
            if not body and not calls:
                continue
            if len(body) > _MAX_ENTRY_CHARS:
                body = (body[:_MAX_ENTRY_CHARS]
                        + f"\n[... {len(body) - _MAX_ENTRY_CHARS} chars cut]")
            blocks.append(f"[{_role_of(message)}]\n{body}" + (f"\n{calls}" if calls else ""))
        out = "\n\n".join(blocks)
        if len(out) <= max_chars:
            return out
        return "[... earlier turns cut to fit the window ...]\n\n" + out[-max_chars:]


class RecordTranscript(AgentMiddleware):
    """Mirror each turn's messages into *sink* so the stage holds them after a kill."""

    def __init__(self, sink: Transcript) -> None:
        """Record into *sink*; this middleware never alters the request."""
        super().__init__()
        self._sink = sink

    @property
    def name(self) -> str:
        """Per-instance name; langchain asserts middleware names are unique per agent."""
        return "RecordTranscript"

    def wrap_model_call(self, request: Any, handler: Callable[[Any], _T]) -> _T:
        """Capture *request*'s messages, then pass it through untouched."""
        self._sink.record(getattr(request, "messages", None))
        return handler(request)

    async def awrap_model_call(self, request: Any, handler: Callable[[Any], Any]) -> Any:
        """Async twin of wrap_model_call, for the streaming route."""
        self._sink.record(getattr(request, "messages", None))
        return await handler(request)


def settle_future(fut: Future[_T], call: Callable[[], _T]) -> None:
    """Run *call* into *fut* unless it was cancelled first, relaying any exception to the waiter."""
    if not fut.set_running_or_notify_cancel():
        return
    try:
        fut.set_result(call())
    except BaseException as exc:  # noqa: BLE001 -- relayed to the waiter, never swallowed
        fut.set_exception(exc)


def start_daemon(call: Callable[[], _T], name: str) -> Future[_T]:
    """Run *call* on a daemon thread named *name*, settling its outcome into the returned Future."""
    fut: Future[_T] = Future()
    threading.Thread(target=settle_future, args=(fut, call), name=name, daemon=True).start()
    return fut


def _orphan_settled(stage: str, started: float) -> Callable[[Future], None]:
    """A done-callback: when an abandoned future later settles, count and log it once."""

    def _on_done(fut: Future) -> None:
        if fut.cancelled():
            return
        outcome = "result" if fut.exception() is None else type(fut.exception()).__name__
        COUNTERS.bump(f"{stage.split()[0]}_orphan_settled")
        log.warning(Event.STAGE_ORPHAN_SETTLED, stage=stage.split()[0], outcome=outcome,
                   elapsed_s=round(time.monotonic() - started, 1))

    return _on_done


def run_with_deadline(call: Callable[[], _T], *, seconds: float | None, stage: str,
                      effort: str | None = None) -> _T:
    """*call*'s result, raising the usual VVAH-E008 once *seconds* elapse; 0/None means no clock."""
    # step*.timeout reaches _run_sync on deepagents and the cli MCP bridge only -- sdk and openai
    # drop it -- so a stage that must be bounded on every route owns its clock here instead.
    if not seconds or seconds <= 0:
        return call()
    # Daemon worker: never joined at exit, so an abandoned call cannot hold the process open. On
    # sdk/openai the loop's own session clock now stops the orphan at the stage deadline instead of
    # letting it bill until max_turns.
    started = time.monotonic()
    fut = start_daemon(call, f"deadline-{stage}")
    try:
        return fut.result(timeout=seconds)
    except TimeoutError as exc:
        # A done future raised the call's own error (a route CallTimeoutError is a TimeoutError):
        # re-raise it unchanged so it is counted once. Only a pending future is a stage expiry.
        if fut.done():
            return fut.result()
        # cancel() is a no-op on a RUNNING future; the orphan's route clock may still count a
        # second llm_call_timeout for this one deadline hit. The callback counts it ONLY if it
        # later settles -- a future still running at process exit never fires it.
        fut.add_done_callback(_orphan_settled(stage, started))
        fut.cancel()
        raise call_timeout_error(
            stage=stage, route="stage", budget_s=seconds, effort=effort,
            cause_text=f"stage deadline exceeded {seconds:g}s",
        ) from exc


def deadline_bound(existing: float | None, deadline: int, effort: str | None, *,
                   via: str) -> float | None:
    """The session timeout to hand a route so its own clock stops before the stage *deadline*."""
    # The route scales its timeout by the SESSION factor and adds the stop grace, so hand it the
    # deadline less the grace, pre-divided by that factor: the resume then continues a stopped
    # session instead of racing an orphan. A deadline within the grace keeps *existing*.
    if not deadline or deadline <= TIMEOUT_STOP_GRACE_SECONDS:
        return existing
    # The cli leg and its MCP bridge fold a None effort to the process-global cli.effort first
    tier = _cli._effective_effort(effort) if via == "cli" else effort
    net = float(deadline - TIMEOUT_STOP_GRACE_SECONDS)
    scaled = effort_scaled_seconds(net, tier, kind=ClockKind.SESSION) or net
    bound = net * (net / scaled)
    return bound if existing is None or existing > bound else existing


def replay_prompt(transcript: Transcript, original_prompt: str, *, instruction: str,
                  stage: str) -> str:
    """The re-ask: the transcript when a route shared one, else the original prompt."""
    if not transcript.captured:
        COUNTERS.bump(f"{stage}_replay_without_transcript")
        return instruction + "\n\nNo transcript was recoverable on this route. The original "\
            "request follows; answer it directly.\n\n" + original_prompt
    COUNTERS.bump(f"{stage}_replay_from_transcript")
    return instruction + "\n\n=== SESSION TRANSCRIPT ===\n\n" + transcript.render()


def session_id_for(stage: str, key: str) -> str:
    """A unique id pinning one dispatch's session, so its deadline can resume that conversation."""
    return f"{stage}-{key}-{uuid4().hex}"


@contextmanager
def pinned_session(stage: str, key: str) -> Iterator[str]:
    """A session id released on EVERY exit — resume_or_replay only covers the timeout path."""
    # Without this the success path never released: _PINNED kept the StreamingOptions and
    # release_session kept the compiled graph and its checkpointed conversation for the whole
    # scan. s4 runs one session per unit and s6 one per batch, so the retention was per-unit.
    session_id = session_id_for(stage, key)
    try:
        yield session_id
    finally:
        release_pinned_session(session_id)


def resume_or_replay(session_id: str, replay: Callable[[], str], *, model: object, cfg: object,
                     instruction: str, stage: str, tag: str, timeout: int) -> str:
    """Continue *session_id*'s own conversation for the output it never reported; else *replay*."""
    # A resume appends ONE user turn to the live thread: every prior message stays in context and
    # prompt-cached. replay() re-sends a rendered copy as a brand-new prompt -- lossy, and a
    # guaranteed cache miss -- so it is only the fallback for a route that cannot be continued.
    COUNTERS.bump(f"{stage}_deadline_resume")
    started = time.monotonic()
    try:
        out = _resume_agentic(session_id, instruction, model=model, cfg=cfg, tag=f"{tag} resume",
                              timeout=timeout)
    # dispatch_or_retry_unforced owns the single refusal resend; a replay here would be a second,
    # uncounted one
    except ModelRefusal:
        raise
    # Deliberately broad otherwise: a resume is an optimisation, so any other failure must degrade
    # to the transcript re-ask.
    except Exception as exc:  # noqa: BLE001
        COUNTERS.bump(f"{stage}_deadline_resume_unavailable")
        log.warning(Event.REPLAY_NO_LIVE_SESSION, stage=stage, tag=tag, detail=str(exc))
        return replay()
    finally:
        release_pinned_session(session_id)
    console.write(f"  [{stage}] {tag}: resume returned in {time.monotonic() - started:.1f}s")
    return out
