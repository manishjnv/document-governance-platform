# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""One agentic session per threat: tool set, dispatch, and reply reduction."""
from __future__ import annotations

from pathlib import Path

from langchain.agents.middleware import AgentMiddleware, TodoListMiddleware

from vvaharness.backends.harness import ToolBuilder, compose_tool_builders
from vvaharness.backends.harness.deepagents.evidence_gate import EvidenceGate
from vvaharness.backends.harness.deepagents.model_call_budget import ModelCallBudget
from vvaharness.backends.harness.deepagents.tool_budget import ToolCallBudget
from vvaharness.backends.harness.models import CallTimeoutError
from vvaharness.backends.llm import cli
from vvaharness.backends.llm import deepagents as _deepagents
from vvaharness.backends.llm.models import (
    RESPONSE_MODEL_VIAS,
    refusal_resend_allowed,
    validate_detection_tools,
)
from vvaharness.backends.llm.registry import resolve
from vvaharness.codegraph.build import graph_is_degenerate
from vvaharness.codegraph.tools import (
    GRAPH_TOOL_NAMES,
    build_graph_tool_builder,
    graph_tool_names,
)
from vvaharness.evidence import _cap_int
from vvaharness.models import ContextPackage, Finding, InvestigationUnit, UnitSize
from vvaharness.pipeline.stages.replay import (
    S4_REPLAY_INSTRUCTION,
    RecordTranscript,
    Transcript,
    deadline_bound,
    pinned_session,
    replay_prompt,
    resume_or_replay,
    run_with_deadline,
)
from vvaharness.pipeline.stages.s4.outcomes import (
    InvestigationOutcome,
    InvestigationOutcomes,
    reduce_outcomes,
    split_batch_reply,
)
from vvaharness.pipeline.stages.s4.prompts import (
    PLAN_TOOL_DESCRIPTION,
    build_batch_prompt,
    build_initial_prompt,
    build_plan_system_prompt,
    build_system_prompt,
)
from vvaharness.rules.kb_tools import KB_TOOL_NAMES, build_kb_tool_builder
from vvaharness.skills import inject_skills
from vvaharness.util import console, logs
from vvaharness.util import errlog as _errlog
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event
from vvaharness.util.response_quality import dispatch_or_retry_unforced
from vvaharness.util.warn_once import warn_once

log = logs.get_logger(__name__)

_STRUCTURED_VIAS = RESPONSE_MODEL_VIAS

_WARNED_DEGENERATE_GRAPH: set[str] = set()


def deepdive_tools(cfg) -> list[str]:
    """The native tool allowlist every S4 session passes to dispatch_agentic."""
    # Without one the cli bridge sends `--tools ""` and the plain cli leg no jail at all
    return validate_detection_tools(
        knob(cfg, "step4.allowed_tools", ("Read", "Glob", "Grep")),
        config_key="step4.allowed_tools", via=resolve(cfg.models.deepdive).via)


def _budget(s4, key: str, names: tuple[str, ...], counter: str) -> ToolCallBudget | None:
    """A budget metering *names*, or None when the configured limit is <= 0 (unmetered)."""
    limit = _cap_int(s4, key, 6)
    if limit <= 0:
        return None
    return ToolCallBudget(frozenset(names), limit=limit, counter=counter)


def _batch_limit(limit: int, members: int) -> int:
    """*limit* grown by one call per extra batch member."""
    return limit + max(0, members - 1)


def _call_budget(s4, outcome: str, members: int = 1, *, tag: str = "") -> ModelCallBudget | None:
    """The session's model-call cap, or None when `step4.max_model_calls` is <= 0 (unmetered)."""
    # VVAH-E007: no raise_when_exhausted loops to max_turns uncaused; *tag* must match the caller's
    limit = _cap_int(s4, "max_model_calls", 0)
    if limit <= 0:
        return None
    return ModelCallBudget(limit=_batch_limit(limit, members),
                           outcome_tools=frozenset({outcome}),
                           counter="s4_model_call_budget_final_turn",
                           raise_when_exhausted=True, stage=tag)


def _graph_tools_registered(ctx: ContextPackage, cfg: object = None) -> bool:
    """Whether this session actually has the six graph tools to call."""
    # The ONE predicate every graph-naming prompt is gated on, computed once so none can disagree
    return ctx.graph_handle is not None and not graph_is_degenerate(ctx, cfg)


def _planner(s4, graph: bool = True) -> TodoListMiddleware | None:
    """The planning middleware, unless `step4.planning` turns it off; `graph` picks the wording."""
    if not getattr(s4, "planning", True):
        return None
    return TodoListMiddleware(system_prompt=build_plan_system_prompt(graph),
                              tool_description=PLAN_TOOL_DESCRIPTION)


def _gate(s4, ctx: ContextPackage, cfg: object = None, *,
         degenerate_stand_down_counted: list[bool] | None = None) -> EvidenceGate | None:
    """The plan-completion gate on the outcome tool, unless config turns it off."""
    # Caller's flag, shared across retries: _tool_setup is per-attempt, so the counter would double
    if not getattr(s4, "planning", True) or not getattr(s4, "evidence_gate", True):
        return None
    declared = bool(getattr(s4, "require_graph", True))
    degenerate = declared and graph_is_degenerate(ctx, cfg)
    if degenerate:
        warn_once(
            _WARNED_DEGENERATE_GRAPH, "s4-require-graph",
            "WARN [s4]: step4.require_graph is on but the code graph is absent "
            "or degenerate (zero edges, or fewer nodes than "
            "step0.min_graph_nodes_for_gate) — standing the graph-tool "
            "requirement down; the todo-list gate still applies.")
        if degenerate_stand_down_counted is None or not degenerate_stand_down_counted[0]:
            if degenerate_stand_down_counted is not None:
                degenerate_stand_down_counted[0] = True
            COUNTERS.bump("evidence_gate_stood_down_degenerate_graph")
    # Degenerate graph = no graph tools registered, so requiring them would reject every verdict
    required = frozenset(GRAPH_TOOL_NAMES) if declared and not degenerate else frozenset()
    return EvidenceGate(max_rejections=_cap_int(s4, "evidence_gate_refusals", 3),
                        counter="s4_evidence_gate_rejected",
                        required_tools=required)


def _tool_setup(ctx: ContextPackage, s4, outcome: str = InvestigationOutcome.__name__,
                members: int = 1, *, cfg: object = None,
                degenerate_stand_down_counted: list[bool] | None = None,
                tag: str = "", graph: bool = True
                ) -> tuple[ToolBuilder, tuple[str, ...], tuple[AgentMiddleware, ...]]:
    """Compose S4's tool builders, fact-tool names, and its per-session middleware."""
    builders = [build_graph_tool_builder(ctx)]
    names = graph_tool_names()
    middleware = [_budget(s4, "graph_tool_budget", graph_tool_names(),
                          "s4_graph_tool_budget_exhausted")]
    if getattr(s4, "cwe_tools", True):
        builders.append(build_kb_tool_builder())
        names += KB_TOOL_NAMES
        middleware.append(_budget(s4, "cwe_tool_budget", KB_TOOL_NAMES,
                                  "s4_cwe_tool_budget_exhausted"))
    middleware.extend([_planner(s4, graph),
                       _gate(s4, ctx, cfg,
                            degenerate_stand_down_counted=degenerate_stand_down_counted),
                       _call_budget(s4, outcome, members, tag=tag)])
    return compose_tool_builders(*builders), names, tuple(m for m in middleware if m)


def _load_code(unit: InvestigationUnit, repo_root: Path, s4) -> str | None:
    """Whole-file source when `step4.inline_source` is on; `None` otherwise and always for LARGE."""
    if unit.size == UnitSize.LARGE or not getattr(s4, "inline_source", False):
        return None
    from vvaharness.pipeline.stages.s4_deepdive import _load_files_full
    return _load_files_full(unit.files, repo_root)


def _repair_prompt(raw: str, unit_id: str) -> str:
    return (
        "REPAIR TASK: the previous reply was supposed to be a JSON object matching "
        "the InvestigationOutcome schema (unit_id, verdict, rationale, findings[]) "
        f"but failed to parse. Return ONLY the corrected JSON object. `unit_id` MUST "
        f"be exactly {unit_id!r}. Preserve every finding and fact already present.\n\n"
        f"--- ORIGINAL REPLY ---\n{raw}"
    )


#: The replay restates a transcript; it needs the smallest reasoning budget, not the stage's.
_REPLAY_EFFORT = "low"


def _deadline_seconds(cfg) -> int:
    """The step4.deadline knob in whole seconds; 0 = no clock."""
    return int(knob(cfg, "step4.deadline", 0) or 0)


def _session_timeout(cfg, effort: str | None) -> float | None:
    """The route session clock, stopping the session before step4.deadline abandons it."""
    # S4 sets no session clock of its own; step4.deadline is the only one it hands the route
    return deadline_bound(None, _deadline_seconds(cfg), effort,
                          via=resolve(cfg.models.deepdive).via)


def _deadline_bounded(call, replay, *, cfg, tag: str, session_id: str) -> str:
    """*call*'s reply, or a resume of its own session once step4.deadline elapses; 0 = no clock."""
    seconds = _deadline_seconds(cfg)
    try:
        return run_with_deadline(call, seconds=seconds, stage=tag, effort=_REPLAY_EFFORT)
    except CallTimeoutError:
        console.write(f"  [s4] {tag}: deadline {seconds}s hit — resuming the session "
                      f"for its outcome")
        return resume_or_replay(session_id, replay, model=cfg.models.deepdive, cfg=cfg,
                                instruction=S4_REPLAY_INSTRUCTION, stage="s4", tag=tag,
                                timeout=_cap_int(cfg.step4, "resume_timeout", 60))


def _replay_call(prompt_text: str, transcript: Transcript, *, cfg, repo_root: Path,
                 tag: str, response_model) -> str:
    """One tool-free, lowest-effort re-ask for the outcome the killed session never reported."""
    COUNTERS.bump("s4_deadline_replay")
    return _deepagents.dispatch_prompt(
        replay_prompt(transcript, prompt_text, instruction=S4_REPLAY_INSTRUCTION, stage="s4"),
        model=cfg.models.deepdive,
        cfg=cfg,
        cwd=str(repo_root),
        graph_name="s4-deepdive",
        tag=f"{tag} replay",
        max_tokens=_cap_int(cfg.step4, "replay_max_tokens", 16000),
        timeout=_cap_int(cfg.step4, "replay_timeout", 60),
        response_model=response_model,
        effort=_REPLAY_EFFORT,
    )


def _investigate_unit_once(unit: InvestigationUnit, ctx: ContextPackage, repo_root: Path,
                           cfg) -> list[Finding]:
    """Run one agentic session for *unit* and return the findings it confirmed."""
    from vvaharness.pipeline.stages.s4_deepdive import _build_shared_context_block

    s4 = cfg.step4
    code = _load_code(unit, repo_root, s4)
    response_model = (InvestigationOutcome
                      if resolve(cfg.models.deepdive).via in _STRUCTURED_VIAS
                      else None)
    # Fresh per unit, not per attempt: the _gate stand-down counter must bump once per unit
    degenerate_stand_down_counted = [False]
    tag = f"s4 {unit.id}"
    # One value for every prompt this session renders (system, first turn, planner).
    graph = _graph_tools_registered(ctx, cfg)
    effort = getattr(s4, "effort", None) or None
    tools = deepdive_tools(cfg)
    def _dispatch(*, drop_thinking: bool) -> str:
        # Rebuilt per attempt: budgets and gate are stateful, so reuse starts with the first spend
        tool_builder, fact_tools, middleware = _tool_setup(
            ctx, s4, cfg=cfg,
            degenerate_stand_down_counted=degenerate_stand_down_counted, tag=tag,
            graph=graph)
        initial = build_initial_prompt(unit, code, _cap_int(s4, "max_model_calls", 0), graph=graph)
        transcript = Transcript()
        middleware = (*middleware, RecordTranscript(transcript))
        with pinned_session("s4", unit.id) as session_id:
            return _deadline_bounded(
                lambda: _agentic(initial, tool_builder, fact_tools, middleware,
                                 session_id=session_id, drop_thinking=drop_thinking),
                lambda: _replay_call(initial, transcript, cfg=cfg, repo_root=repo_root,
                                     tag=tag, response_model=response_model),
                cfg=cfg, tag=tag, session_id=session_id)

    def _agentic(initial: str, tool_builder, fact_tools, middleware, *, session_id: str,
                 drop_thinking: bool) -> str:
        return _deepagents.dispatch_agentic(
            initial,
            model=cfg.models.deepdive,
            cfg=cfg,
            cwd=str(repo_root),
            system_prompt=build_system_prompt(
                shell=bool(getattr(s4, "bash", False)), graph=graph),
            graph_name="s4-deepdive",
            tag=tag,
            tool_builder=tool_builder,
            fact_tools=fact_tools,
            response_model=response_model,
            allowed_tools=tools,
            parent_middleware=middleware,
            max_output_tokens=int(knob(cfg, "step4.max_tokens", 64000)),
            cache_prefix=_build_shared_context_block(ctx) or None,
            skill_root=inject_skills(repo_root) if getattr(s4, "skills", True) else None,
            effort=None if drop_thinking else effort,
            max_turns=_cap_int(s4, "max_turns", 15),
            timeout=_session_timeout(cfg, None if drop_thinking else effort),
            # Shell reads cost a few lines vs a whole file; natives unscoped (_permitted_natives)
            allow_shell=bool(getattr(s4, "bash", False)),
            session_id=session_id,
        )

    raw = dispatch_or_retry_unforced(
        _dispatch, unit.id, stage="s4",
        effort=_deepagents.droppable_effort(cfg.models.deepdive, effort, agentic=True),
        resend_refusal=refusal_resend_allowed(cfg, cfg.models.deepdive))
    findings, by_unit = reduce_outcomes([unit], {unit.id: raw}, cfg,
                                        repo_root=str(repo_root), inventory=set(ctx.all_files))
    if by_unit[unit.id] == "failed":
        # recovered=True records the repair ATTEMPT, not a loss; a permanent failure raises instead
        console.write(f"  [s4] {unit.id}: primary reply did not parse; "
                      f"attempting one bounded repair re-ask")
        _errlog.log("s4", unit.id, "primary reply did not parse as an "
                    "InvestigationOutcome", reason="s4_outcome_repair_attempted",
                    recovered=True)
        COUNTERS.bump("s4_outcome_repaired_attempt")
        repaired = _deepagents.dispatch_prompt(
            _repair_prompt(raw, unit.id),
            model=cfg.models.deepdive,
            cfg=cfg,
            cwd=str(repo_root),
            graph_name="s4-deepdive",
            tag=f"s4 {unit.id} json-repair",
            # A repair re-emits the full outcome, so a smaller budget makes it a real truncation
            max_tokens=int(knob(cfg, "step4.max_tokens", 64000)),
            response_model=response_model,
        )
        findings, by_unit = reduce_outcomes([unit], {unit.id: repaired}, cfg,
                                            repo_root=str(repo_root), inventory=set(ctx.all_files))
        if by_unit[unit.id] != "failed":
            COUNTERS.bump("s4_outcome_repaired_ok")
    if by_unit[unit.id] == "failed":
        raise RuntimeError(f"s4-deepdive: {unit.id}'s session reply did not parse "
                           "as an InvestigationOutcome, even after repair")

    return _cap_findings(unit.id, findings, cfg)


def _cap_findings(unit_id: str, findings: list[Finding], cfg) -> list[Finding]:
    """Keep the first `step4.max_findings_per_run` of *findings*; run on every session, batched or not."""
    cap = getattr(cfg.step4, "max_findings_per_run", None)
    if cap and len(findings) > cap:
        # Caps ONE session. Emission order, not confidence: Finding has no confidence to rank by
        dropped = len(findings) - cap
        COUNTERS.bump("s4_findings_truncated", dropped)
        log.warning(Event.S4_FINDINGS_CAPPED, unit=unit_id, findings=len(findings), cap=cap,
                    dropped=dropped)
        findings = findings[:cap]
    return findings


def _dedup_by_key(findings: list[Finding], line_bucket: int) -> tuple[list[Finding], int]:
    """Collapse same-canonical-key findings; run on every session, batched or not."""
    # First-seen wins: s4 sets no confidence, so all carry Finding's 0.5 default and ties are no-ops
    by_key: dict[tuple, Finding] = {}
    for f in findings:
        by_key.setdefault(f.canonical_key(line_bucket), f)
    # Counted, not silently dropped: the "N findings" line else implies every raw hit was distinct
    merged = len(findings) - len(by_key)
    if merged > 0:
        COUNTERS.bump("s4_unit_key_deduped", merged)
    return list(by_key.values()), merged


def investigate_unit(unit: InvestigationUnit, ctx: ContextPackage, repo_root: Path, cfg,
                     stats: dict | None = None) -> list[Finding]:
    """Run one agentic session for *unit*, collapsing same-site findings by canonical key."""
    if cli.aborted():
        raise RuntimeError("aborted by user (Ctrl-C)")
    line_bucket = getattr(cfg.step4, "line_bucket", 10)
    findings = _investigate_unit_once(unit, ctx, repo_root, cfg)
    deduped, merged = _dedup_by_key(findings, line_bucket)
    if stats is not None:
        stats["merged"] = merged
    return deduped


def _batch_repair_prompt(raw: str, unit_ids: list[str]) -> str:
    return (
        "REPAIR TASK: the previous reply was supposed to be a JSON object "
        '{"outcomes": [...]} holding one InvestigationOutcome (unit_id, verdict, rationale, '
        "findings[]) for EACH of these units, but failed to parse. Return ONLY the corrected "
        f"JSON object. The `unit_id` values MUST be exactly these, one entry each: {unit_ids}. "
        f"Preserve every finding and fact already present.\n\n--- ORIGINAL REPLY ---\n{raw}"
    )


def _batch_reply(batch: list[InvestigationUnit], ctx: ContextPackage, repo_root: Path,
                 cfg) -> str:
    """Run one shared session over *batch* and return its raw reply."""
    from vvaharness.pipeline.stages.s4_deepdive import (
        _build_shared_context_block,
        _load_files_full,
    )

    s4 = cfg.step4
    files = list(dict.fromkeys(f for u in batch for f in u.files))
    code = (_load_files_full(files, repo_root)
            if getattr(s4, "inline_source", False)
            and all(u.size != UnitSize.LARGE for u in batch) else None)
    response_model = (InvestigationOutcomes
                      if resolve(cfg.models.deepdive).via in _STRUCTURED_VIAS
                      else None)
    # Fresh per batch, not per attempt: see _investigate_unit_once's identical guard.
    degenerate_stand_down_counted = [False]
    tag = f"s4 batch[{len(batch)}] {batch[0].id}"
    # One value for every prompt this session renders, as in _investigate_unit_once.
    graph = _graph_tools_registered(ctx, cfg)
    effort = getattr(s4, "effort", None) or None
    tools = deepdive_tools(cfg)
    def _dispatch(*, drop_thinking: bool) -> str:
        # Rebuilt per attempt: stateful budgets and gate, as in _investigate_unit_once.
        tool_builder, fact_tools, middleware = _tool_setup(
            ctx, s4, InvestigationOutcomes.__name__, len(batch), cfg=cfg,
            degenerate_stand_down_counted=degenerate_stand_down_counted, tag=tag,
            graph=graph)
        initial = build_batch_prompt(batch, code, len(files),
                                     _cap_int(s4, "max_model_calls", 0), graph=graph)
        transcript = Transcript()
        middleware = (*middleware, RecordTranscript(transcript))
        with pinned_session("s4", batch[0].id) as session_id:
            return _deadline_bounded(
                lambda: _agentic(initial, tool_builder, fact_tools, middleware,
                                 session_id=session_id, drop_thinking=drop_thinking),
                lambda: _replay_call(initial, transcript, cfg=cfg, repo_root=repo_root,
                                     tag=tag, response_model=response_model),
                cfg=cfg, tag=tag, session_id=session_id)

    def _agentic(initial: str, tool_builder, fact_tools, middleware, *, session_id: str,
                 drop_thinking: bool) -> str:
        return _deepagents.dispatch_agentic(
            initial,
            model=cfg.models.deepdive,
            cfg=cfg,
            cwd=str(repo_root),
            system_prompt=build_system_prompt(
                shell=bool(getattr(s4, "bash", False)), graph=graph),
            graph_name="s4-deepdive",
            tag=tag,
            tool_builder=tool_builder,
            fact_tools=fact_tools,
            response_model=response_model,
            allowed_tools=tools,
            parent_middleware=middleware,
            max_output_tokens=int(knob(cfg, "step4.max_tokens", 64000)),
            cache_prefix=_build_shared_context_block(ctx) or None,
            skill_root=inject_skills(repo_root) if getattr(s4, "skills", True) else None,
            effort=None if drop_thinking else effort,
            max_turns=_cap_int(s4, "max_turns", 15),
            timeout=_session_timeout(cfg, None if drop_thinking else effort),
            allow_shell=bool(getattr(s4, "bash", False)),
            session_id=session_id,
        )

    return dispatch_or_retry_unforced(
        _dispatch, f"batch[{len(batch)}] {batch[0].id}", stage="s4",
        effort=_deepagents.droppable_effort(cfg.models.deepdive, effort, agentic=True),
        resend_refusal=refusal_resend_allowed(cfg, cfg.models.deepdive))


def investigate_batch(batch: list[InvestigationUnit], ctx: ContextPackage, repo_root: Path,
                      cfg, *, stats: dict | None = None
                      ) -> tuple[dict[str, list[Finding]], dict[str, str]]:
    """Run one shared session over *batch*, returning each member's findings and per-unit verdict
    ("uninvestigated"/"failed" for a member the reply omitted or that didn't parse, else the
    model's own verdict) — the caller must not stamp an uninvestigated/failed member "completed"."""
    ids = [u.id for u in batch]
    raw = _batch_reply(batch, ctx, repo_root, cfg)
    per_unit = split_batch_reply(raw, ids)
    if not per_unit:
        console.write(f"  [s4] batch[{len(batch)}] {batch[0].id}: shared session reply "
                      f"did not parse; attempting one bounded repair re-ask")
        _errlog.log("s4", f"batch[{len(batch)}] {batch[0].id}",
                    "shared session reply did not parse as InvestigationOutcomes",
                    reason="s4_batch_repair_attempted", recovered=True)
        COUNTERS.bump("s4_batch_repaired_attempt")
        repaired = _deepagents.dispatch_prompt(
            _batch_repair_prompt(raw, ids),
            model=cfg.models.deepdive,
            cfg=cfg,
            cwd=str(repo_root),
            graph_name="s4-deepdive",
            tag=f"s4 batch[{len(batch)}] {batch[0].id} json-repair",
            # A repair re-emits the full outcomes, so a smaller budget makes it a real truncation
            max_tokens=int(knob(cfg, "step4.max_tokens", 64000)),
            response_model=(InvestigationOutcomes
                            if resolve(cfg.models.deepdive).via in _STRUCTURED_VIAS
                            else None),
        )
        per_unit = split_batch_reply(repaired, ids)
        if per_unit:
            COUNTERS.bump("s4_batch_repaired_ok")
    if not per_unit:
        raise RuntimeError(f"s4-deepdive: the shared session for {ids} returned no parseable "
                           "InvestigationOutcomes, even after repair")
    findings, by_unit = reduce_outcomes(batch, per_unit, cfg,
                                        repo_root=str(repo_root), inventory=set(ctx.all_files))
    out: dict[str, list[Finding]] = {u.id: [] for u in batch}
    for f in findings:
        out.setdefault(f.chunk_id, []).append(f)
    # Same guards as the single-unit path, per member: a batch is otherwise the only
    # s4 leg that ships uncapped, undeduped findings
    line_bucket = getattr(cfg.step4, "line_bucket", 10)
    merged_by_unit: dict[str, int] = {}
    for u in batch:
        capped = _cap_findings(u.id, out[u.id], cfg)
        out[u.id], merged_by_unit[u.id] = _dedup_by_key(capped, line_bucket)
    if stats is not None:
        stats["merged_by_unit"] = merged_by_unit
    for verdict in by_unit.values():
        if verdict in {"uninvestigated", "failed"}:
            COUNTERS.bump(f"s4_batch_member_{verdict}")
    return out, by_unit
