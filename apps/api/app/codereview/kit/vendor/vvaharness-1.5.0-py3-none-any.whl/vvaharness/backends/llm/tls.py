# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared TLS-config coercion and mTLS client-chain handling for the backend clients."""

# Stdlib-only on purpose (callers that must not pull httpx); warnings carry no file contents
from __future__ import annotations

import os
import ssl
from collections.abc import Iterator
from contextlib import contextmanager

from vvaharness.util import logs
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

_TRUE = {"true", "1", "yes", "on"}
_FALSE = {"false", "0", "no", "off"}
_NO_PROXY_KEYS = ("NO_PROXY", "no_proxy")
_OAUTH_TOKEN_PREFIX = "sk-ant-oat"
_OAUTH_BETA_HEADER = "oauth-2025-04-20"


def anthropic_auth_kwargs(token: str | None) -> dict[str, object]:
    """Return Anthropic client authentication kwargs for a static key or OAuth token."""
    token = (token or "").strip()
    if token.startswith(_OAUTH_TOKEN_PREFIX):
        return {
            "auth_token": token,
            "default_headers": {"anthropic-beta": _OAUTH_BETA_HEADER},
        }
    return {"api_key": token} if token else {}


def is_anthropic_oauth_token(token: str | None) -> bool:
    """True when *token* has Anthropic's documented OAuth workspace-token prefix."""
    return (token or "").strip().startswith(_OAUTH_TOKEN_PREFIX)


def coerce_verify(value):
    """Return ``value`` with string booleans mapped to real ``bool``."""
    # Quoted YAML "false" is truthy: un-coerced it leaves verification ON; others are CA paths
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, str):
        low = value.strip().lower()
        if low in _FALSE:
            return False
        if low in _TRUE:
            return True
    return value


def chain_paths(cert: str | tuple[str, ...] | list[str]) -> tuple[str, ...]:
    """Normalise either accepted client-chain shape to a tuple of paths."""
    # YAML gives a list, not a tuple: matching ``tuple`` alone raised TypeError on ``via: sdk``
    return tuple(cert) if isinstance(cert, (tuple, list)) else (cert,)


def resolve_client_chain(
    cert: str | tuple[str, ...] | list[str] | None, *, label: str,
    noun: str = "client_cert",
) -> str | tuple[str, ...] | list[str] | None:
    """Return the configured client chain, or None (warned) when a file is missing."""
    # Deliberate: an absent cert/key warns and disables mTLS; a malformed CA bundle fails closed
    if not cert:
        return None
    paths = chain_paths(cert)
    missing = next((p for p in paths if p and not os.path.exists(p)), None)
    if missing is not None:
        log.warning(Event.TLS_CLIENT_CHAIN_MISSING, route=label, kind=noun, path=missing)
        return None
    return cert


def load_client_chain(
    context: ssl.SSLContext, cert: str | tuple[str, ...] | list[str], *, label: str
) -> bool:
    """Load the client chain onto *context*, warning and returning False on failure."""
    # TRAP (httpx 0.28.1): never pass ``cert=`` alongside a non-True ``verify=`` — silently ignored
    args = chain_paths(cert)
    try:
        context.load_cert_chain(*args)
    except Exception as exc:
        log.warning(Event.TLS_CLIENT_CHAIN_UNLOADABLE, route=label, path=args[0],
                    error=type(exc).__name__)
        return False
    return True


def warn_verify_disabled(base: str | None, *, label: str,
                         default_endpoint: str = "<default endpoint>",
                         ca_hint: str = "ca_cert") -> None:
    """Warn loudly that TLS verification is off, naming the resolved endpoint."""
    # *base* must be the endpoint resolved for this vendor branch, not whatever rides along in env
    log.warning(Event.TLS_VERIFY_DISABLED, route=label,
                base_url=base or default_endpoint, ca_hint=ca_hint)


def _restore_env_value(key: str, value: str | None) -> None:
    """Restore *key* to *value*, or delete it entirely when *value* is None."""
    if value is None:
        os.environ.pop(key, None)
    else:
        os.environ[key] = value


@contextmanager
def scoped_no_proxy_env(no_proxy: str | None) -> Iterator[None]:
    """Set NO_PROXY/no_proxy only for httpx's one-time env read at client construction."""
    if not no_proxy:
        yield
        return
    prior = {key: os.environ.get(key) for key in _NO_PROXY_KEYS}
    try:
        os.environ.update(dict.fromkeys(_NO_PROXY_KEYS, no_proxy))
        yield
    finally:
        for key, value in prior.items():
            _restore_env_value(key, value)
