# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deterministic sink-line re-anchor for header-anchored findings."""
from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field

from vvaharness.detect.patterns import default_corpus
from vvaharness.models import Finding
from vvaharness.pipeline.stages.s5.enrich import FileCache, snippet
from vvaharness.rules.cwe import weakness_key
from vvaharness.util.counters import COUNTERS


def sink_patterns_by_cwe() -> dict[str, list[re.Pattern[str]]]:
    """The detect/ sink corpus, compiled and keyed by weakness (see rules.cwe.weakness_key)."""
    by_cwe: dict[str, list[re.Pattern[str]]] = {}
    for spec in default_corpus():
        if spec.role != "sink":
            continue
        cwe = weakness_key(spec.cwe)
        if cwe:
            by_cwe.setdefault(cwe, []).append(re.compile(spec.pattern))
    return by_cwe


def _header_start(node: ast.AST) -> int:
    """The scope's first header line — its earliest decorator, else its keyword line."""
    decorators = getattr(node, "decorator_list", [])
    linenos = [d.lineno for d in decorators] + [node.lineno]
    return min(linenos)


def _first_body_line(scope: ast.AST) -> int:
    """The first line of *scope*'s body — its first statement's own header."""
    return _header_start(scope.body[0])


_SCOPE_NODES = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
# Lambda prunes the walk but is never a re-anchor target: no body statement list to gate against.
_NESTED_SCOPE_NODES = (*_SCOPE_NODES, ast.Lambda)


def _innermost_scope(scopes: list[tuple[int, int, ast.AST]],
                     line: int) -> tuple[ast.AST | None, int]:
    """The innermost scope whose header..end range contains *line*, plus its header."""
    best: ast.AST | None = None
    best_header = 0
    for header, end, node in scopes:
        if header <= line <= end and (best is None or header >= best_header):
            best, best_header = node, header
    return best, best_header


def _own_nodes(scope: ast.AST):
    """Every node belonging to *scope*'s own BODY, pruned at each nested scope."""
    stack: list[ast.AST] = list(scope.body)
    if isinstance(scope, ast.ClassDef):
        for node in scope.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                stack.extend(node.body)
    while stack:
        node = stack.pop()
        yield node
        if isinstance(node, _NESTED_SCOPE_NODES):
            continue
        stack.extend(ast.iter_child_nodes(node))


def _callee_text(node: ast.Call) -> str:
    """The call's own callee, rendered for the sink patterns — never the raw line."""
    try:
        return f"{ast.unparse(node.func)}("
    # unparse is documented to raise on a node it cannot render; an unnamed callee matches nothing.
    except (AttributeError, ValueError, RecursionError):
        return ""


def _scope_calls(scope: ast.AST) -> list[tuple[int, str]]:
    """(lineno, rendered callee) for every Call in *scope*'s OWN body."""
    return [(node.lineno, _callee_text(node)) for node in _own_nodes(scope)
            if isinstance(node, ast.Call)]


def _sink_lines(calls: list[tuple[int, str]],
                patterns: list[re.Pattern[str]]) -> list[int]:
    """Every distinct call line whose callee matches a sink pattern."""
    return sorted({ln for ln, callee in calls
                   if callee and any(rx.search(callee) for rx in patterns)})


# Findings arrive grouped by file, so a small window keeps the hit rate while capping live trees.
_MAX_PARSED_FILES = 16


@dataclass
class _ParsedFile:
    """One file's scope index plus per-scope call memos, evicted as a unit."""

    # (header_start, end_lineno, node) per scope.
    scopes: list[tuple[int, int, ast.AST]]
    # id(scope) -> its own calls; the ids are only valid while this entry is cached.
    calls: dict[int, list[tuple[int, str]]] = field(default_factory=dict)


class Reanchorer:
    """Applies the re-anchor rule to one finding at a time; all state is per-run caches."""

    def __init__(self, cache: FileCache, by_cwe: dict[str, list[re.Pattern[str]]],
                 max_move: int):
        self._cache = cache
        self._by_cwe = by_cwe
        self._max_move = max_move
        # LRU-bounded; a failure caches None so a bad file is parsed once, not once per finding.
        self._parsed: dict[str, _ParsedFile | None] = {}

    def _file(self, rel: str) -> _ParsedFile | None:
        """*rel*'s scope index, or None when unreadable, non-Python, or pathological."""
        if rel in self._parsed:
            self._parsed[rel] = parsed = self._parsed.pop(rel)  # LRU touch
            return parsed
        lines = self._cache.lines(rel)
        parsed = None
        if lines is not None:
            try:
                tree = ast.parse("\n".join(lines))
                parsed = _ParsedFile(scopes=[
                    (_header_start(node),
                     getattr(node, "end_lineno", None) or node.lineno, node)
                    for node in ast.walk(tree)
                    if isinstance(node, _SCOPE_NODES)])
            # SyntaxError covers python2-only files; the rest are ast.parse's hostile-input modes
            except (SyntaxError, ValueError, MemoryError, RecursionError):
                parsed = None
        self._parsed[rel] = parsed
        if len(self._parsed) > _MAX_PARSED_FILES:
            del self._parsed[next(iter(self._parsed))]
        return parsed

    def _calls(self, parsed: _ParsedFile, scope: ast.AST) -> list[tuple[int, str]]:
        """*scope*'s own calls, memoized: siblings sharing a scope re-unparse nothing."""
        key = id(scope)
        if key not in parsed.calls:
            parsed.calls[key] = _scope_calls(scope)
        return parsed.calls[key]

    def _own_sink_line(self, f: Finding) -> int | None:
        """The line of *f*'s s4-provided same-file sink_ref, or None (use the patterns)."""
        path, _, ln = (f.sink_ref or "").strip().rpartition(":")
        if path != f.file or not ln.isdigit():
            return None
        line = int(ln)
        lines = self._cache.lines(f.file)
        if lines is None or not 1 <= line <= len(lines):
            return None
        return line

    def apply(self, f: Finding) -> Finding:
        """*f* re-anchored to its nearest in-scope sink call, or *f* unchanged."""
        # A same-file sink_ref is a CANDIDATE, never a veto: header gate and move cap still bound it
        own_sink = self._own_sink_line(f)
        patterns = None
        if own_sink is None:
            patterns = self._by_cwe.get(weakness_key(f.cwe) or "")
            if not patterns:
                COUNTERS.bump("s5_reanchor_no_pattern")
                return f
        parsed = self._file(f.file) if f.file.endswith(".py") else None
        if parsed is None:
            COUNTERS.bump("s5_reanchor_unparsed")
            return f
        line = max(1, int(f.line_start))
        scope, header = _innermost_scope(parsed.scopes, line)
        if scope is None:
            COUNTERS.bump("s5_reanchor_no_scope")
            return f
        # Upper bound EXCLUSIVE (first body stmt is deliberate); max(header+1) keeps one-line suites
        if not header <= line < max(_first_body_line(scope), header + 1):
            COUNTERS.bump("s5_reanchor_body_anchored")
            return f
        # own_sink on a header IS the mis-anchor to fix; `<` exempts a one-line suite (header=body)
        if own_sink is not None and own_sink == line and line < _first_body_line(scope):
            COUNTERS.bump("s5_reanchor_own_sink_is_header")
            own_sink = None
            patterns = self._by_cwe.get(weakness_key(f.cwe) or "")
            if not patterns:
                COUNTERS.bump("s5_reanchor_no_pattern")
                return f
        if own_sink is not None:
            COUNTERS.bump("s5_reanchor_own_sink_ref")
            candidates = [own_sink]
        else:
            candidates = _sink_lines(self._calls(parsed, scope), patterns)
        if not candidates:
            COUNTERS.bump("s5_reanchor_no_sink")
            return f
        sink = min(candidates, key=lambda ln: (abs(ln - line), ln))
        if sink == line:
            COUNTERS.bump("s5_reanchor_already_at_sink")
            return f
        if abs(sink - line) > self._max_move:
            COUNTERS.bump("s5_reanchor_capped")
            return f
        update: dict = {"line_start": sink, "line_end": max(int(f.line_end), sink)}
        if not (f.sink_ref or "").strip():
            # Marked backfilled to carry the same provenance enrich's own ref fill mints.
            update["sink_ref"] = f"{f.file}:{sink}"
            update["backfilled_refs"] = sorted(set(f.backfilled_refs) | {"sink_ref"})
        moved = f.model_copy(update=update)
        # Recenter the snippet so s6 reads the sink statement, not the header.
        moved.code_snippet = snippet(moved, self._cache.lines(f.file) or [])
        COUNTERS.bump("s5_sink_reanchored")
        return moved
