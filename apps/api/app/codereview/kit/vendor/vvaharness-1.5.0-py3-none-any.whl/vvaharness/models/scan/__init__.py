# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Data contracts passed between pipeline steps; no raw dicts cross step boundaries."""

from vvaharness.models.scan._coerce import (
    _coerce_enum,
    _coerce_int,
    _coerce_scalar_str,
    _coerce_str_list,
    _norm,
)
from vvaharness.models.scan._render import (
    _ATX_HEADING_RX,
    _FENCE_RX,
    _MD_INVISIBLE_RX,
    _MD_LINEBREAK_RX,
    _demote_md_headings,
    _md_cell,
    _render_repro_block,
    _snippet_fence,
    _vector_span,
)
from vvaharness.models.scan.context import ContextPackage
from vvaharness.models.scan.findings import (
    Chain,
    DroppedFinding,
    Finding,
    LinkEvidence,
    RankedFinding,
)
from vvaharness.models.scan.inputs import CVE, AppProfile, Control
from vvaharness.models.scan.metrics import ScanMetrics, ScopeEntry
from vvaharness.models.scan.report import FinalReport
from vvaharness.models.scan.seed import SeedPackage
from vvaharness.models.scan.surface import EntryPoint, ModuleInfo, Sink
from vvaharness.models.scan.threat import (
    Asset,
    Threat,
    ThreatModel,
    TrustBoundary,
    _cap_assets,
    _cap_boundaries,
    _cap_threats,
)
from vvaharness.models.scan.work import DupLocation, InvestigationUnit, TaskManifest, UnitSize
from vvaharness.models.vocab import OFFENSIVE_LABELS, Severity, VulnClass

__all__ = [
    "CVE",
    "OFFENSIVE_LABELS",
    "_ATX_HEADING_RX",
    "_FENCE_RX",
    "_MD_INVISIBLE_RX",
    "_MD_LINEBREAK_RX",
    "AppProfile",
    "Asset",
    "Chain",
    "ContextPackage",
    "Control",
    "DroppedFinding",
    "DupLocation",
    "EntryPoint",
    "FinalReport",
    "Finding",
    "InvestigationUnit",
    "LinkEvidence",
    "ModuleInfo",
    "RankedFinding",
    "ScanMetrics",
    "ScopeEntry",
    "SeedPackage",
    "Severity",
    "Sink",
    "TaskManifest",
    "Threat",
    "ThreatModel",
    "TrustBoundary",
    "UnitSize",
    "VulnClass",
    "_cap_assets",
    "_cap_boundaries",
    "_cap_threats",
    "_coerce_enum",
    "_coerce_int",
    "_coerce_scalar_str",
    "_coerce_str_list",
    "_demote_md_headings",
    "_md_cell",
    "_norm",
    "_render_repro_block",
    "_snippet_fence",
    "_vector_span",
]
