# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Wire the deterministic gate + playbook into the agent: a pre-gate before the LLM, a post-gate after."""
from __future__ import annotations

from vvaharness.remediation_agent.policy.context import (  # noqa: F401
    PolicyContext,
    _resolve_input,
    _sr,
    build_context,
    policy_enabled,
)
from vvaharness.remediation_agent.policy.decide import (
    PreResult,
    guidance_verdict,
    pre_decision,
)
from vvaharness.remediation_agent.policy.postgate import (
    PostResult,
    enforce_post,
    worktree_forbidden_matches,
)
from vvaharness.remediation_agent.policy.revert import revert_files
from vvaharness.remediation_agent.policy.workflow_refs import (
    introduced_unsafe_workflow_refs,
    workflow_snapshot_paths,
)

__all__ = [
    "PolicyContext",
    "PostResult",
    "PreResult",
    "build_context",
    "enforce_post",
    "guidance_verdict",
    "introduced_unsafe_workflow_refs",
    "policy_enabled",
    "pre_decision",
    "revert_files",
    "workflow_snapshot_paths",
    "worktree_forbidden_matches",
]
