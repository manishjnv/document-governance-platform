# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deterministic ContextPackage field producers over the built graph."""
from __future__ import annotations

from vvaharness.codegraph.handle import GraphHandle
from vvaharness.util import logs

log = logs.get_logger(__name__)

_COMMUNITY_FILES_QUERY = """
MATCH (fn)-[:MEMBER_OF]->(c:Community)
MATCH (file:File)-[:DEFINES]->(fn)
RETURN c.name AS community, file.filePath AS path
"""

_LANGUAGE_COUNTS_QUERY = """
MATCH (f:File)
WHERE f.language IS NOT NULL AND f.language <> ''
RETURN f.language AS language, count(*) AS n
ORDER BY n DESC
"""

_COUNT_QUERIES = {
    "files": "MATCH (f:File) RETURN count(f) AS n",
    "functions": "MATCH (fn:Function) RETURN count(fn) AS n",
    "communities": "MATCH (c:Community) RETURN count(c) AS n",
}


def communities_as_modules(handle: GraphHandle) -> dict[str, list[str]]:
    """Community name -> its member functions' file paths (graph-relative, deduped)."""
    modules: dict[str, list[str]] = {}
    for row in handle.graph.cypher(_COMMUNITY_FILES_QUERY).rows:
        values = row.to_dict()
        name, path = values.get("community"), values.get("path")
        if not isinstance(name, str) or not isinstance(path, str):
            continue
        modules.setdefault(name, [])
        if path not in modules[name]:
            modules[name].append(path)
    return modules


def primary_language(handle: GraphHandle) -> str | None:
    """The most common non-empty ``File.language`` value, or ``None`` on an empty graph."""
    rows = handle.graph.cypher(_LANGUAGE_COUNTS_QUERY).rows
    if not rows:
        return None
    language = rows[0].to_dict().get("language")
    return language if isinstance(language, str) else None


def _int_count(handle: GraphHandle, query: str) -> int:
    rows = handle.graph.cypher(query).rows
    if not rows:
        return 0
    n = rows[0].to_dict().get("n")
    return n if isinstance(n, int) else 0


def system_context_notes(handle: GraphHandle) -> str:
    """One-line, deterministic summary of the graph's shape — the v1.5 ``system_context`` trick."""
    counts = {key: _int_count(handle, query) for key, query in _COUNT_QUERIES.items()}
    languages = [
        lang for r in handle.graph.cypher(_LANGUAGE_COUNTS_QUERY).rows
        if isinstance(lang := r.to_dict().get("language"), str)
    ]
    lang_str = ", ".join(languages[:5]) or "unknown"
    return (f"{counts['files']} files ({lang_str}), "
            f"{counts['functions']} functions, "
            f"{counts['communities']} communities.")
