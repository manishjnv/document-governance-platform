# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""ThreatEvidence -> prompt-ready text blocks."""
from __future__ import annotations

from vvaharness.evidence.gather import ThreatEvidence


def render_language_block(ev: ThreatEvidence) -> str:
    """Language -> file-count breakdown."""
    return "\n".join(f"  - {lang}: {n} files" for lang, n in ev.languages) or "  (none detected)"


def render_components_block(ev: ThreatEvidence) -> str:
    """Top-level directory names."""
    return "\n".join(f"  - {d}/" for d in ev.top_dirs) or "  (flat repo)"


def render_inventory_block(ev: ThreatEvidence) -> str:
    """Every in-scope path, grouped by directory."""
    by_dir: dict[str, list[str]] = {}
    for rel in ev.inventory:
        head, _, tail = rel.rpartition("/")
        by_dir.setdefault(head or ".", []).append(tail)
    block = "\n".join(
        f"  {d + '/' if d != '.' else '(repo root)':<30} " + "  ".join(sorted(names))
        for d, names in sorted(by_dir.items())
    ) or "  (no files in scope)"
    if ev.inventory_truncated:
        block += "\n  …(truncated)"
    return block


def render_modules_block(ev: ThreatEvidence) -> str:
    """s1-mapped modules as asset candidates."""
    block = "\n".join(
        f"  - {name}  ({loc} LOC) — {purpose}" for name, purpose, loc in ev.modules
    ) or "  (s1 emitted no modules)"
    if ev.modules_truncated:
        block += "\n  …(truncated)"
    return block


def render_entry_points_block(ev: ThreatEvidence, stride_by_kind: dict[str, str]) -> str:
    """s1-mapped entry points as trust boundaries, with a caller-supplied STRIDE hint per kind."""
    block = "\n".join(
        f"  - [{kind:<14}] {'UNAUTH' if unauth else 'auth  '}  "
        f"STRIDE:{stride_by_kind.get(kind, 'T I')}  {file}::{func}"
        for kind, unauth, file, func in ev.entry_points
    ) or "  (s1 emitted no entry points)"
    if ev.entry_points_truncated:
        block += "\n  …(truncated)"
    return block


def render_config_reps_block(ev: ThreatEvidence) -> str:
    """Config reps with a body get a header block; the rest render as a bare path."""
    return "\n".join(
        f"  === {rel} ===\n{body}" if body else f"  - {rel}" for rel, body in ev.config_reps
    ) or "  (none)"


def render_api_artefacts_block(ev: ThreatEvidence) -> str:
    """API-contract artefact paths."""
    return "\n".join(f"  - {p}" for p in ev.api_artefacts) or "  (none)"


def render_docs_block(ev: ThreatEvidence) -> str:
    """README/SECURITY/ARCHITECTURE-shaped documents."""
    return "\n\n".join(
        f"=== {name} ===\n{body}" for name, body in ev.docs
    ) or "(no README / SECURITY / ARCHITECTURE docs found)"


def render_manifests_block(ev: ThreatEvidence) -> str:
    """Build/dependency manifests."""
    return "\n\n".join(
        f"=== {name} ===\n{body}" for name, body in ev.manifests
    ) or "(no build/dependency manifests found)"
