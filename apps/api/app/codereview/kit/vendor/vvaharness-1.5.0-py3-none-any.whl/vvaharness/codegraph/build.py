# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Builds the one code graph a scan analyzes and queries."""
from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path

from context_graph_sdk.api import Workspace
from context_graph_sdk.backends.arcadedb import ArcadeDBBackendFactory
from context_graph_sdk.code_graph import CodeGraph
from context_graph_sdk.plugins import GraphEnricher

from vvaharness.codegraph.handle import GraphHandle
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS

#: `step0.min_graph_nodes_for_gate`: below 10 nodes a graph cannot answer GraphContext usefully
_MIN_GRAPH_NODES_FOR_GATE = 10


def _analyze(workspace: Workspace, repo_root: str, project_id: str,
             enrichers: tuple[GraphEnricher, ...]) -> CodeGraph:
    try:
        return workspace.analyze(repo_root, project_id, enrichers)
    except Exception:
        workspace.close()
        raise


def _enricher_names(plugins: tuple[object, ...]) -> tuple[str, ...]:
    """Plugin names, for logging only; one too malformed to name is reported as ``?``."""
    try:
        return tuple(str(getattr(p.metadata, "name", "?")) for p in plugins)
    except Exception:
        return tuple("?" for _ in plugins)


def build_graph(repo_root: str, project_id: str, workspace_dir: Path,
                enrichers: Iterable[GraphEnricher] = ()) -> GraphHandle:
    """Analyze ``repo_root`` into a fresh workspace at ``workspace_dir``, running *enrichers*."""
    # Any backend or plugin failure propagates: S2/S4/S6 ground their verdicts in this graph, so a
    # scan without one is a different product, and the failure is cheapest before any model spend.
    plugins = tuple(enrichers)
    names = _enricher_names(plugins)
    workspace = Workspace(workspace_dir, ArcadeDBBackendFactory())
    graph = _analyze(workspace, repo_root, project_id, plugins)
    for name in names:
        COUNTERS.bump(f"s0_graph_enricher_ran:{name}")
    info = graph.info()
    return GraphHandle(
        workspace=workspace, graph=graph, project_id=project_id,
        node_count=info.node_count,
        edge_count=info.edge_count,
        enrichers=tuple(names),
    )


def graph_is_degenerate(ctx: object, cfg: object = None) -> bool:
    """True when *ctx*'s graph cannot back a `require_graph` evidence demand."""
    # No handle, zero edges, or under min_graph_nodes_for_gate; UNMEASURED is NOT degenerate
    handle = getattr(ctx, "graph_handle", None)
    if handle is None:
        return True
    if getattr(handle, "edge_count", None) == 0:
        return True
    nodes = getattr(handle, "node_count", None)
    if nodes is None:
        return False
    min_nodes = int(knob(cfg, "step0.min_graph_nodes_for_gate", _MIN_GRAPH_NODES_FOR_GATE))
    return nodes < min_nodes
