# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Classify a repo's files by language, and tell source apart from config and templates."""
from __future__ import annotations

import re
from pathlib import Path, PurePosixPath

# Extension → language key

EXT_TO_LANG: dict[str, str] = {
    ".c": "c-cpp", ".cc": "c-cpp", ".cpp": "c-cpp", ".cxx": "c-cpp",
    ".h": "c-cpp", ".hpp": "c-cpp",
    ".rs": "rust",
    ".go": "go",
    ".py": "python",
    ".java": "java",
    ".js": "javascript", ".jsx": "javascript", ".mjs": "javascript",
    ".cjs": "javascript",
    ".ts": "typescript", ".tsx": "typescript",
    ".mts": "typescript", ".cts": "typescript",
    ".php": "php",
    ".rb": "ruby",
    ".m": "objective-c", ".mm": "objective-c",
    ".kt": "kotlin", ".kts": "kotlin",
    ".cs": "csharp",
    ".pl": "perl", ".pm": "perl",
    ".swift": "swift",
    ".scala": "scala", ".sc": "scala",
    ".cbl": "cobol", ".cob": "cobol", ".cpy": "cobol",
    ".jcl": "jcl",
    ".dart": "dart",
    ".ex": "elixir", ".exs": "elixir",
    ".erl": "erlang", ".hrl": "erlang",
    ".groovy": "groovy", ".gvy": "groovy", ".gy": "groovy", ".gsh": "groovy",
    ".lua": "lua",
    ".r": "r",
    ".ps1": "powershell", ".psm1": "powershell", ".psd1": "powershell",
    ".sh": "shell", ".bash": "shell", ".zsh": "shell",
    ".cmd": "batch", ".bat": "batch",
    # SQL / PL-SQL (Oracle) / T-SQL (SQL Server) — stored procs, packages, dynamic SQL
    ".sql": "sql", ".ddl": "sql", ".dml": "sql", ".tsql": "sql", ".plsql": "sql",
    ".pks": "sql", ".pkb": "sql", ".pls": "sql", ".plb": "sql",
    ".prc": "sql", ".fnc": "sql", ".trg": "sql", ".vw": "sql",
    # Visual Basic / VB.NET / VBA / VBScript (enterprise/finance)
    ".vb": "vbnet", ".bas": "vbnet", ".cls": "vbnet", ".frm": "vbnet", ".vbs": "vbnet",
    # ABAP (SAP)
    ".abap": "abap", ".aba": "abap",
    # Clojure
    ".clj": "clojure", ".cljs": "clojure", ".cljc": "clojure", ".edn": "clojure",
    # Haskell
    ".hs": "haskell", ".lhs": "haskell",
    # OCaml
    ".ml": "ocaml", ".mli": "ocaml",
    # F#
    ".fs": "fsharp", ".fsi": "fsharp", ".fsx": "fsharp",
    # Julia
    ".jl": "julia",
    # Solidity (EVM smart contracts)
    ".sol": "solidity",
    # Assembly (x86/x64/ARM — GAS/NASM)
    ".asm": "assembly", ".s": "assembly",
    # Zig
    ".zig": "zig",
    # Nim
    ".nim": "nim", ".nims": "nim",
    # Crystal
    ".cr": "crystal",
    # infrastructure-as-code (the `iac` skill lens sweeps these)
    ".tf": "terraform", ".tfvars": "terraform", ".hcl": "terraform",
    ".bicep": "bicep",
    # web/server templates — XSS / SSTI surface
    ".html": "web-template", ".htm": "web-template",
    ".jsp": "web-template", ".jspx": "web-template", ".jspf": "web-template",
    ".tag": "web-template", ".tagx": "web-template",
    ".aspx": "web-template", ".ascx": "web-template", ".master": "web-template",
    ".cshtml": "web-template", ".vbhtml": "web-template",
    ".phtml": "web-template",
    ".erb": "web-template", ".rhtml": "web-template",
    ".ejs": "web-template",
    ".hbs": "web-template", ".handlebars": "web-template",
    ".mustache": "web-template",
    ".twig": "web-template",
    ".pug": "web-template", ".jade": "web-template",
    ".ftl": "web-template", ".ftlh": "web-template",
    ".vm": "web-template", ".vtl": "web-template",
    ".mako": "web-template",
    ".j2": "web-template", ".jinja": "web-template", ".jinja2": "web-template",
    ".vue": "web-template", ".svelte": "web-template",
    ".liquid": "web-template", ".njk": "web-template",
    ".slim": "web-template", ".haml": "web-template",
    ".tpl": "web-template", ".xhtml": "web-template",
}

#: COMPOUND suffixes Path.suffix cannot name (x.blade.php reads .php); use is_web_template()
TEMPLATE_COMPOUND_SUFFIXES: tuple[str, ...] = (".blade.php",)


def is_web_template(path: str) -> bool:
    """Whether *path* names a server-side template (the XSS/SSTI surface)."""
    # EXT_TO_LANG web-template plus TEMPLATE_COMPOUND_SUFFIXES; case-insensitive, any path form
    low = path.lower()
    if low.endswith(TEMPLATE_COMPOUND_SUFFIXES):
        return True
    _, dot, ext = low.rpartition(".")
    return bool(dot) and EXT_TO_LANG.get(f".{ext}") == "web-template"

LANG_DISPLAY: dict[str, str] = {
    "c-cpp": "C/C++", "rust": "Rust", "go": "Go", "python": "Python",
    "java": "Java", "javascript": "JavaScript", "php": "PHP",
    "ruby": "Ruby", "objective-c": "Objective-C", "kotlin": "Kotlin",
    "csharp": "C#/.NET", "perl": "Perl", "swift": "Swift",
    "scala": "Scala", "cobol": "COBOL", "jcl": "JCL (z/OS)",
    "dart": "Dart/Flutter", "elixir": "Elixir", "erlang": "Erlang",
    "groovy": "Groovy", "lua": "Lua", "r": "R",
    "powershell": "PowerShell", "shell": "Shell (bash/sh)",
    "batch": "Windows Batch (.cmd/.bat)",
    "web-template": "Web Templates",
    "ansible": "Ansible",
    "terraform": "Terraform / HCL",
    "bicep": "Azure Bicep",
    "dockerfile": "Dockerfile",
    "jenkins": "Jenkinsfile",
    "github-actions": "GitHub Actions",
    "kubernetes": "Kubernetes / Helm",
    "typescript": "TypeScript",
    "sql": "SQL / PL-SQL / T-SQL",
    "vbnet": "Visual Basic / VB.NET",
    "abap": "ABAP (SAP)",
    "clojure": "Clojure",
    "haskell": "Haskell",
    "ocaml": "OCaml",
    "fsharp": "F#",
    "julia": "Julia",
    "solidity": "Solidity",
    "assembly": "Assembly",
    "zig": "Zig",
    "nim": "Nim",
    "crystal": "Crystal",
}


# Path / content sniffing for files the extension map can't classify

_ANSIBLE_PATH_RX = re.compile(
    r"(?:^|/)(?:ansible|playbooks?|roles|inventories|group_vars|host_vars)(?:/|$)",
    re.IGNORECASE,
)
_ANSIBLE_BODY_RX = re.compile(
    r"^\s*-?\s*(hosts|tasks|handlers|become|gather_facts|ansible\.[\w.]+)\s*:",
    re.MULTILINE,
)
_COBOL_BODY_RX = re.compile(
    r"IDENTIFICATION\s+DIVISION|PROCEDURE\s+DIVISION|WORKING-STORAGE\s+SECTION"
    r"|^.{0,7}\d{2}\s+\S+.*\bPIC(?:TURE)?\s+[X9SVA]"
    r"|^.{0,7}\d{2}\s+FILLER\b"
  r"|^.{0,7}\s+COPY\s+\w+\s*\.",
    re.IGNORECASE | re.MULTILINE,
)
_JCL_BODY_RX = re.compile(
    r"^//\S*\s+(JOB|EXEC|DD|PROC)\b|^//\s*SYSIN\b", re.MULTILINE,
)
_MAINFRAME_PATH_RX = re.compile(
    r"(?:^|/)(?:mvs[_-]?code|jcl|cntl|proclib|cobol|copybooks?|jobs)(?:/|$)",
    re.IGNORECASE,
)

# IaC/CI/container by filename, no I/O, so _is_source and the s3 `iac` gate can both call it
_DOCKERFILE_NAME_RX = re.compile(
    r"(?:^|/)(?:Dockerfile|Containerfile)(?:\.[\w.-]+)?$", re.IGNORECASE,
)
_JENKINSFILE_NAME_RX = re.compile(
    r"(?:^|/)Jenkinsfile(?:\.[\w.-]+)?$", re.IGNORECASE,
)
_GHACTIONS_PATH_RX = re.compile(
    r"(?:^|/)\.github/workflows/[^/]+\.ya?ml$",
)
_K8S_PATH_RX = re.compile(
    r"(?:^|/)(?:k8s|kubernetes|helm|charts?|manifests?|deploy(?:ments?)?)/.+\.(?:ya?ml|tpl)$",
    re.IGNORECASE,
)
_K8S_BODY_RX = re.compile(r"^apiVersion:\s+\S+", re.MULTILINE)
_IAC_PATH_RX = re.compile(
    r"(?:^|/)(?:Dockerfile|Containerfile|Jenkinsfile)(?:\.[\w.-]+)?$"
    r"|(?:^|/)(?:docker-compose(?:[\w.-]*)?|Chart|kustomization"
    r"|\.gitlab-ci|cloudbuild|azure-pipelines|buildspec|appspec|serverless"
    r")\.ya?ml$"
    r"|\.(?:tf|tfvars|hcl|bicep)$"
    r"|(?:^|/)\.github/workflows/[^/]+\.ya?ml$"
    r"|(?:^|/)(?:k8s|kubernetes|helm|charts?|manifests?|deploy(?:ments?)?"
    r"|cloudformation|cfn)/.+\.(?:ya?ml|tpl|json)$"
    r"|(?:^|/)(?:ansible|playbooks?|roles|group_vars|host_vars)/.+\.ya?ml$",
    re.IGNORECASE,
)


def is_iac_file(rel: str) -> bool:
    """Path/filename-only check for Infrastructure-as-Code, CI, and container config."""
    return bool(_IAC_PATH_RX.search(rel))


SECURITY_CONFIG_NAMES = {
    "web.xml", "struts.xml", "struts-config.xml", "applicationcontext.xml",
    "spring-security.xml", "beans.xml", "faces-config.xml", "shiro.ini",
    "security.xml", "ejb-jar.xml", "jboss-web.xml", "weblogic.xml",
    "androidmanifest.xml", "info.plist",
    "application.properties", "application.yml", "application.yaml",
    "appsettings.json", "web.config", "app.config",
}
SECURITY_CONFIG_EXTS = {".xml", ".properties"}




def _read_head(repo_root: Path, rel: str, n: int = 4096) -> str:
    try:
        with open(repo_root / rel, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read(n)
    except OSError:
        return ""


def _sniff_lang(rel: str, repo_root: Path | None) -> str | None:
    """Classify files the extension map missed (or mis-bucketed as plain config)."""
    # IaC by filename: Dockerfile/Jenkinsfile have no extension, Actions live in .github/workflows
    if _DOCKERFILE_NAME_RX.search(rel):
        return "dockerfile"
    if _JENKINSFILE_NAME_RX.search(rel):
        return "jenkins"
    if _GHACTIONS_PATH_RX.search(rel):
        return "github-actions"

    suffix = PurePosixPath(rel).suffix.lower()

    if suffix in (".yml", ".yaml"):
        if _ANSIBLE_PATH_RX.search(rel):
            return "ansible"
        if _K8S_PATH_RX.search(rel):
            return "kubernetes"
        if repo_root:
            head = _read_head(repo_root, rel)
            if _ANSIBLE_BODY_RX.search(head):
                return "ansible"
            if _K8S_BODY_RX.search(head):
                return "kubernetes"
        return None

    if suffix:
        return None

    # extension-less: mainframe sources commonly ship as PDS-member dumps
    if _MAINFRAME_PATH_RX.search(rel) and repo_root:
        head = _read_head(repo_root, rel)
        if _JCL_BODY_RX.search(head):
            return "jcl"
        if _COBOL_BODY_RX.search(head):
            return "cobol"
    elif repo_root:
        head = _read_head(repo_root, rel, 1024)
        if _JCL_BODY_RX.search(head):
            return "jcl"
        if _COBOL_BODY_RX.search(head):
            return "cobol"
    return None


def detect_languages(files: list[str],
                     repo_root: Path | str | None = None) -> list[str]:
    """Return ordered list of language keys present in `files`, most common first."""
    root = Path(repo_root) if repo_root else None
    counts: dict[str, int] = {}
    for f in files:
        suffix = PurePosixPath(f).suffix.lower()
        lang = EXT_TO_LANG.get(suffix)
        if lang is None or suffix in (".yml", ".yaml"):
            lang = _sniff_lang(f, root) or lang
        if lang:
            counts[lang] = counts.get(lang, 0) + 1
    return [k for k, _ in sorted(counts.items(), key=lambda kv: -kv[1])]


VVAH_LANGUAGES: frozenset[str] = frozenset({
    "python",
    "java",
    "javascript",
    "typescript",
    "go",
    "csharp",
})

_LANG_ALIASES: dict[str, str] = {
    "python": "python", "py": "python", "python3": "python",
    "java": "java",
    "javascript": "javascript", "js": "javascript", "node": "javascript",
    "typescript": "typescript", "ts": "typescript",
    "go": "go", "golang": "go",
    "csharp": "csharp", "c#": "csharp", "cs": "csharp", "dotnet": "csharp",
    "kotlin": "kotlin", "kt": "kotlin",
    "scala": "scala",
    "ruby": "ruby", "rb": "ruby",
    "php": "php",
    "c": "c-cpp", "cpp": "c-cpp", "c++": "c-cpp", "cxx": "c-cpp",
}

def canonical_lang(value: object) -> str:
    """Normalize a language spelling to its vvaharness key."""
    # Unknown spellings return lowercased, never defaulted: rewriting a typo would narrow scope
    key = str(value or "").strip().lower()
    return _LANG_ALIASES.get(key, key)
