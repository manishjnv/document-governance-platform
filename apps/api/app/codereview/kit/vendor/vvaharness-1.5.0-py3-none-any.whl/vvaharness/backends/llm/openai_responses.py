# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Pure Chat <-> Responses API translation for the openai route.

No I/O, no client, no logging: every function here is a plain dict-in,
dict-out mapping so the openai route can replay the same Chat-shaped
transcript over either wire. Private keys on the canonical transcript
(`_reasoning_items` on an assistant entry, `_item_id` inside a tool call)
carry Responses-only replay state and never reach the Chat wire.
"""
from __future__ import annotations

from typing import Any, Final

from vvaharness.backends.llm.models import REASONING_OFF

__all__ = [
    "INCLUDE_ENCRYPTED_REASONING",
    "ITEM_ID_KEY",
    "REASONING_ITEMS_KEY",
    "finish_of",
    "from_response",
    "to_chat_messages",
    "to_responses_input",
    "to_responses_request",
    "to_responses_tool_choice",
    "to_responses_tools",
    "usage_as_chat",
]

#: Carries the Responses `reasoning` items (encrypted_content kept, OUTPUT-only fields
#: dropped -- see _REASONING_INPUT_FIELDS) on an assistant transcript entry, for next-turn
#: replay. Stripped before the Chat wire.
REASONING_ITEMS_KEY = "_reasoning_items"

#: Carries a tool call's Responses `function_call` item id, for next-turn replay.
#: Stripped before the Chat wire.
ITEM_ID_KEY = "_item_id"

#: With `store=False` the endpoint keeps no per-turn state; encrypted reasoning replays it.
INCLUDE_ENCRYPTED_REASONING: Final[tuple[str, ...]] = ("reasoning.encrypted_content",)

#: A stored reasoning item is replayed as an INPUT item, which accepts only these fields.
#: A gateway's own OUTPUT item (what a reasoning item's model_dump() actually returns) also
#: carries OUTPUT-only fields such as `status`; replaying one of those back verbatim is
#: rejected as an unknown input parameter, so only this allowlist is ever stored or replayed.
_REASONING_INPUT_FIELDS: Final[tuple[str, ...]] = ("type", "id", "encrypted_content", "summary")


def _get(obj: Any, key: str, default: Any = None) -> Any:
    """Read *key* from a dict, a SimpleNamespace fake, or an SDK model alike."""
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _as_dict(obj: Any) -> dict:
    """Best-effort mapping view of *obj*, for dicts, SDK models and namespace fakes."""
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return dict(obj)
    return obj.model_dump() if hasattr(obj, "model_dump") else dict(vars(obj))


def to_responses_tools(tools: list[dict] | None) -> list[dict]:
    """Flatten Chat `function` tool entries to the Responses tool shape."""
    if not tools:
        return []
    flattened = []
    for tool in tools:
        fn = tool["function"]
        flattened.append({
            "type": "function",
            "name": fn["name"],
            "description": fn.get("description"),
            "parameters": fn.get("parameters"),
            # Explicit: the Responses API attempts strict mode when this is omitted.
            "strict": False,
        })
    return flattened


def _is_forced_function_choice(tool_choice: Any) -> bool:
    return (
        isinstance(tool_choice, dict)
        and tool_choice.get("type") == "function"
        and "function" in tool_choice
    )


def to_responses_tool_choice(tool_choice: Any) -> Any:
    """Convert a forced Chat `tool_choice` to its Responses shape; strings pass through."""
    if _is_forced_function_choice(tool_choice):
        return {"type": "function", "name": tool_choice["function"]["name"]}
    return tool_choice


def _input_content(content: Any) -> Any:
    if isinstance(content, list):
        return [
            {"type": "input_text", "text": block.get("text", "")}
            if isinstance(block, dict) and block.get("type") == "text"
            else block
            for block in content
        ]
    return content


def _reasoning_input_items(entry: dict) -> list[dict]:
    # A plain copy, not a re-filter: _encrypted_reasoning_items() already stored each item
    # allowlisted to _REASONING_INPUT_FIELDS, so there is nothing OUTPUT-only left to drop here.
    return [
        dict(item) for item in entry.get(REASONING_ITEMS_KEY) or []
        if item.get("encrypted_content")
    ]


def _text_input_item(entry: dict) -> dict | None:
    content = entry.get("content")
    if not content:
        return None
    return {
        "type": "message",
        "role": "assistant",
        "content": [{"type": "output_text", "text": content, "annotations": []}],
    }


def _function_call_items(entry: dict) -> list[dict]:
    # Allowlist by construction: only id/function.name/function.arguments/the replay item id
    # are ever read off *tool_call*, so an OUTPUT-only field such as `status` never reaches
    # this item either, the same discipline _encrypted_reasoning_items() applies.
    items = []
    for tool_call in entry.get("tool_calls") or []:
        fn = tool_call.get("function") or {}
        call_item = {
            "type": "function_call",
            "call_id": tool_call.get("id"),
            "name": fn.get("name"),
            "arguments": fn.get("arguments"),
        }
        item_id = tool_call.get(ITEM_ID_KEY)
        if item_id is not None:
            call_item["id"] = item_id
        items.append(call_item)
    return items


def _assistant_items(entry: dict) -> list[dict]:
    items = _reasoning_input_items(entry)
    text_item = _text_input_item(entry)
    if text_item is not None:
        items.append(text_item)
    items.extend(_function_call_items(entry))
    return items


def to_responses_input(messages: list[dict]) -> list[dict]:
    """Map a Chat-shaped transcript to Responses `input` items."""
    items: list[dict] = []
    for entry in messages:
        role = entry.get("role")
        if role == "assistant":
            items.extend(_assistant_items(entry))
        elif role == "tool":
            items.append({
                "type": "function_call_output",
                "call_id": entry.get("tool_call_id"),
                "output": entry.get("content"),
            })
        else:
            items.append({"role": role, "content": _input_content(entry.get("content"))})
    return items


def _tool_kwargs(base_kw: dict) -> dict:
    kwargs: dict = {}
    tools = to_responses_tools(base_kw.get("tools"))
    if tools:
        kwargs["tools"] = tools
    tool_choice = base_kw.get("tool_choice")
    if tool_choice is not None:
        kwargs["tool_choice"] = to_responses_tool_choice(tool_choice)
    return kwargs


def _responses_only_kwargs(base_kw: dict, *, include_encrypted: bool) -> dict:
    # `store=False`: no per-turn server state, so encrypted reasoning does the replay.
    kwargs: dict = {"store": False}
    max_tokens = base_kw.get("max_completion_tokens", base_kw.get("max_tokens"))
    if max_tokens is not None:
        kwargs["max_output_tokens"] = max_tokens
    effort = base_kw.get("reasoning_effort")
    # Never 'none' on the wire here: a gateway that reasons on Responses must stay silenced-off
    # by OMITTING the field (its own default), not by this route muting it the Chat way.
    if effort is not None and effort != REASONING_OFF:
        kwargs["reasoning"] = {"effort": effort}
    cache_key = base_kw.get("prompt_cache_key")
    if cache_key is not None:
        kwargs["prompt_cache_key"] = cache_key
    if include_encrypted:
        kwargs["include"] = list(INCLUDE_ENCRYPTED_REASONING)
    return kwargs


def to_responses_request(
    messages: list[dict], base_kw: dict, *, include_encrypted: bool,
) -> dict:
    """Map a Chat `base_kw` call (plus its transcript) to a Responses `create` payload.

    Reads only the keys Responses understands, so Chat-only keys (`stream`,
    `stream_options`, `messages`, `response_format`, `temperature`) are dropped
    by omission rather than by an explicit pop.
    """
    request: dict = {"model": base_kw["model"], "input": to_responses_input(messages)}
    request.update(_tool_kwargs(base_kw))
    request.update(_responses_only_kwargs(base_kw, include_encrypted=include_encrypted))
    return request


def to_chat_messages(messages: list[dict]) -> list[dict]:
    """Copy a transcript with the Responses-only replay keys stripped, for the Chat wire."""
    out = []
    for entry in messages:
        copy = {k: v for k, v in entry.items() if k != REASONING_ITEMS_KEY}
        tool_calls = copy.get("tool_calls")
        if tool_calls:
            copy["tool_calls"] = [
                {k: v for k, v in tc.items() if k != ITEM_ID_KEY} for tc in tool_calls
            ]
        out.append(copy)
    return out


def usage_as_chat(usage: Any) -> dict | None:
    """Convert a Responses `usage` (object or dict) to the Chat usage field names."""
    if usage is None:
        return None
    input_tokens = _get(usage, "input_tokens") or 0
    output_tokens = _get(usage, "output_tokens") or 0
    total_tokens = _get(usage, "total_tokens")
    if total_tokens is None:
        total_tokens = input_tokens + output_tokens

    prompt_details = _as_dict(_get(usage, "input_tokens_details"))
    prompt_details.setdefault("cached_tokens", 0)
    prompt_details.setdefault("cache_write_tokens", 0)

    completion_details = _as_dict(_get(usage, "output_tokens_details"))
    completion_details.setdefault("reasoning_tokens", 0)

    return {
        "prompt_tokens": input_tokens,
        "completion_tokens": output_tokens,
        "total_tokens": total_tokens,
        "prompt_tokens_details": prompt_details,
        "completion_tokens_details": completion_details,
    }


def finish_of(resp: Any, has_tool_calls: bool) -> str:
    """Map a Responses `status`/`incomplete_details` to a Chat `finish_reason`."""
    status = _get(resp, "status")
    incomplete = _get(resp, "incomplete_details")
    reason = _get(incomplete, "reason") if incomplete is not None else None
    if status == "incomplete" and reason == "max_output_tokens":
        return "length"
    if reason == "content_filter":
        return "content_filter"
    return "tool_calls" if has_tool_calls else "stop"


class _Function:
    __slots__ = ("arguments", "name")

    def __init__(self, name: str | None, arguments: str | None) -> None:
        self.name = name
        self.arguments = arguments


class _ToolCall:
    __slots__ = ("_item_id", "function", "id", "type")

    def __init__(self, call_id: str | None, name: str | None, arguments: str | None,
                 item_id: str | None) -> None:
        self.id = call_id
        self.type = "function"
        self.function = _Function(name, arguments)
        self._item_id = item_id

    def model_dump(self) -> dict:
        dumped = {
            "id": self.id,
            "type": "function",
            "function": {"name": self.function.name, "arguments": self.function.arguments},
        }
        if self._item_id is not None:
            dumped[ITEM_ID_KEY] = self._item_id
        return dumped


class _Message:
    __slots__ = ("content", "reasoning_items", "refusal", "tool_calls")

    def __init__(self, content: str | None, tool_calls: list[_ToolCall],
                 refusal: str | None, reasoning_items: list[dict]) -> None:
        self.content = content
        self.tool_calls = tool_calls
        self.refusal = refusal
        self.reasoning_items = reasoning_items


class _Choice:
    __slots__ = ("finish_reason", "message")

    def __init__(self, message: _Message, finish_reason: str) -> None:
        self.message = message
        self.finish_reason = finish_reason


class _ResponsesReply:
    __slots__ = ("choices", "usage")

    def __init__(self, choices: list[_Choice], usage: dict | None) -> None:
        self.choices = choices
        self.usage = usage


def _raise_for_error(resp: Any) -> None:
    error = _get(resp, "error")
    status = _get(resp, "status")
    if not error and status != "failed":
        return
    if error:
        message = error if isinstance(error, str) else (_get(error, "message") or str(error))
    else:
        # A failed call with no error body is still a failure: nothing downstream must read
        # it as a normal, empty "stop" the way Chat Completions can never shape a reply.
        message = f"Responses call ended with status={status!r} and no error body"
    raise RuntimeError(message)


def _message_content(item: Any) -> tuple[list[str], str | None]:
    text_parts: list[str] = []
    refusal: str | None = None
    for block in _get(item, "content") or []:
        block_type = _get(block, "type")
        if block_type == "output_text":
            text_parts.append(_get(block, "text") or "")
        elif block_type == "refusal" and refusal is None:
            refusal = _get(block, "refusal")
    return text_parts, refusal


def _tool_call_from_item(item: Any) -> _ToolCall:
    # Allowlist by construction: only call_id/name/arguments/id are ever read off *item*, so an
    # OUTPUT-only field such as `status` never reaches the stored tool call or its replay.
    return _ToolCall(
        _get(item, "call_id"), _get(item, "name"), _get(item, "arguments"), _get(item, "id"),
    )


def _encrypted_reasoning_items(items: list) -> list[dict]:
    return [
        {field: _get(item, field) for field in _REASONING_INPUT_FIELDS
         if _get(item, field) is not None}
        for item in items
        if _get(item, "type") == "reasoning" and _get(item, "encrypted_content")
    ]


def from_response(resp: Any) -> _ResponsesReply:
    """Build a Chat-like reply (`.choices[0].message`, `.usage`) from a Responses object."""
    _raise_for_error(resp)

    output_items = _get(resp, "output") or []
    output_text_parts: list[str] = []
    refusal_text: str | None = None
    tool_calls: list[_ToolCall] = []
    for item in output_items:
        item_type = _get(item, "type")
        if item_type == "message":
            text_parts, refusal = _message_content(item)
            output_text_parts.extend(text_parts)
            if refusal_text is None:
                refusal_text = refusal
        elif item_type == "function_call":
            tool_calls.append(_tool_call_from_item(item))

    content = "".join(output_text_parts) if output_text_parts else None
    message = _Message(content, tool_calls, refusal_text, _encrypted_reasoning_items(output_items))
    choice = _Choice(message, finish_of(resp, has_tool_calls=bool(tool_calls)))
    return _ResponsesReply([choice], usage_as_chat(_get(resp, "usage")))
