# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Scan-level counters and the scope report."""
from __future__ import annotations

import logging
from typing import Literal

from pydantic import BaseModel

log = logging.getLogger(__name__)

class ScopeEntry(BaseModel):
    """One analysis unit (chunk) in the scope appendix."""
    name: str
    kind: Literal["risk", "catchall", "specialist", "taint", "threat", "other"]
    files: list[str]


class ScanMetrics(BaseModel):
    """Coverage + verification stats rendered at the top of the report."""
    scan_id: str = ""
    module_name: str = ""
    start_ts: str = ""               # ISO 8601
    end_ts: str = ""
    duration_sec: float = 0.0
    total_files_in_scope: int = 0
    analyzed_files_unique: int = 0
    chunks_total: int = 0
    chunks_risk: int = 0
    chunks_catchall: int = 0
    chunks_specialist: int = 0
    # Default 0 keeps payloads serialized before these fields valid.
    chunks_attempted: int = 0
    chunks_failed: int = 0           # failed / timed-out / guardrail-blocked
    deepdive_skipped: bool = False
    errors_by_stage: dict[str, int] = {}
    errors_log_path: str = ""              # per-run errors.jsonl
    loc_in_scope_by_language: dict[str, int] = {}
    loc_scanned_by_language: dict[str, int] = {}
    raw_findings_count: int = 0
    true_positive_count: int = 0
    false_positive_count: int = 0
    duplicate_count: int = 0
    # The report's reconciling terms: the verifier-minted partition of true_positive_count and
    # the EV-rescued rows kept without a TRUE_POSITIVE verdict. Default 0 keeps old payloads valid.
    discovered_true_positive_count: int = 0
    repeat_clone_true_positive_count: int = 0
    ev_rescued_count: int = 0
    # None renders as "unavailable".
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None
    tokens_by_phase: dict[str, dict] | None = None
    # Null, never 0. reported_cost_usd = backend billing (cli/cli_mcp only); priced = tokens × list
    reported_cost_usd: float | None = None
    priced_cost_usd: float | None = None
    folders_scanned: list[str] = []
    scope: list[ScopeEntry] = []
    excluded: dict = {}

    # COUNTERS snapshot, read once by the metrics builder; all defaulted so old payloads validate
    s2_degraded: bool = False
    s2_threats_raw: int = 0
    s2_threats_truncated: int = 0
    s2_threats_promoted: int = 0
    # step2 caps: frontier items kept out of the S2 evidence, and output items cut after it
    s2_frontier_files_excluded: int = 0
    s2_frontier_entry_points_excluded: int = 0
    s2_frontier_sinks_excluded: int = 0
    s2_frontier_modules_excluded: int = 0
    s2_assets_truncated: int = 0
    s2_trust_boundaries_truncated: int = 0
    # step2 prompt caps applied after the frontier; the prompt itself only says "…(truncated)"
    s2_prompt_modules_truncated: int = 0
    s2_prompt_entry_points_truncated: int = 0
    s2_inventory_files_truncated: int = 0
    s2_baseline_undisposed: list[str] = []
    # D7 downgrade: every undisposed id had a same-OWASP threat elsewhere, so recovered=True
    s2_baseline_undisposed_recovered: int = 0
    s2_repo_kinds: list[str] = []
    # surface_files entries s2 resolved to no in-scope file (fresh S2 runs only; 0 on --resume)
    s2_surface_files_dropped: int = 0
    # step2 EvidenceGate: deepagents refused a verdict until a tool call/the todo plan completed
    s2_evidence_gate_rejected: int = 0
    s2_evidence_gate_rejected_relented: int = 0
    s3_unknown_file_ids: int = 0
    s3_dropped_paths: int = 0
    s3_relocated_paths: int = 0
    # In-scope files no unit names (s3 coverage gap); recorded even if the appendix is off
    s3_unreachable_files: int = 0
    # Threats with no validated surface file minted no unit, so nothing ever reviewed them
    s3_threats_without_unit: int = 0
    s4_findings_truncated: int = 0
    # also_cwes entry rules.families.same_weakness matched the primary (CWE-20/74 parent): dropped
    s4_finding_extra_cwe_collapsed: int = 0
    # s4/session.py::investigate_unit's within-unit canonical_key dedup collapsed a repeated site
    s4_unit_key_deduped: int = 0
    # reduce_outcomes: a batch member the shared reply never mentioned (not clean — unreviewed)
    s4_unit_no_outcome: int = 0
    # Same member, split by cause: omitted from the reply vs. present but unparseable
    s4_batch_member_uninvestigated: int = 0
    s4_batch_member_failed: int = 0
    # A batch member retried alone after its shared session errored, omitted or failed to parse it
    s4_batch_member_resubmitted: int = 0
    s4_batch_member_recovered: int = 0
    # step4 EvidenceGate rejected a premature verdict; the pair counts refusals and relents
    s4_evidence_gate_rejected: int = 0
    s4_evidence_gate_rejected_relented: int = 0
    # VVAH-E004: deepagents-route calls refused pre-dispatch as over-ceiling.
    deepagents_oversize_prompts: int = 0
    # VVAH-E006: deepagents tool replay rejected for missing per-turn state (thought_signature)
    deepagents_tool_state_not_roundtripped: int = 0
    # The jail's _resolve_path override refused a traversal/escape attempt
    deepagents_path_jail_refused: int = 0
    # VVAH-E005: sdk/openai replies confirmed cut off by the output-token budget.
    llm_truncated_replies: int = 0
    # Subset stopping below HALF the requested budget: a gateway cap or hidden reasoning spend
    llm_truncated_below_budget: int = 0
    # require_graph session never called a graph tool; sdk/openai and cli legs have no in-loop gate
    llm_adapter_evidence_gate_unenforced: int = 0
    cli_mcp_evidence_gate_unenforced: int = 0
    # Stood down for an absent/degenerate graph (step0.min_graph_nodes_for_gate); s6 has no todos
    evidence_gate_stood_down_degenerate_graph: int = 0
    # step6_verify EvidenceGate rejected a premature verdict; the pair counts refusals and relents
    s6_evidence_gate_rejected: int = 0
    s6_evidence_gate_rejected_relented: int = 0
    # max_turns exhausted and forced to a final turn: not an error, and not a truncated budget
    llm_turn_cap_exhausted: int = 0
    # Provider refused the request, counted per call; route + category live in the errors log
    llm_model_refusals: int = 0
    # A refused call re-sent once unchanged (refusal_retries, Anthropic routes); attempted/recovered
    llm_refusal_retry_attempted: int = 0
    llm_refusal_retry_recovered: int = 0
    # A truncated reply resent once with the doubled output budget; the pair is attempted/recovered
    llm_truncated_retry_attempted: int = 0
    llm_truncated_retry_recovered: int = 0
    # TRUE_POSITIVE with no CVSS vector: the prompt's own rule, so s8 floors on the detection label
    s6_confirmed_without_vector: int = 0
    # TRUE_POSITIVE whose vector scored 0.0 impact: withheld, so SARIF ranks it by severity band
    s6_cvss_zero_impact_on_tp: int = 0
    # s6/outcomes._clamp_confidence rewrote a verifier score (95 -> 10, 0.9 -> 0), once per event
    s6_confidence_clamped: int = 0
    # Every judged S6 verdict (>= 12) carried one confidence; read with s6_confidence_clamped
    s6_confidence_uniform: int = 0
    # Verifier tried to undo s5's re-anchor (pre_anchor_line); refused, see s6/outcomes.py
    s6_finding_line_correction_reverted_reanchor: int = 0
    # Batch-shape structured failure took the singleton-split retry; ≠ s6_batch_truncated_split
    s6_batch_structured_split: int = 0
    # A guardrail-blocked batch, or a generic (unrecognised) failure, took the same split retry
    s6_batch_guardrail_split: int = 0
    s6_batch_generic_split: int = 0
    # Mirrors s2's attempted/recovered naming; effort's retry-without-thinking feeds the same pair
    s6_structured_retry_attempted: int = 0
    s6_structured_retry_recovered: int = 0
    # A reply clipped at a budget the route could not grow (a 64000 override) was resent once
    # without the stage's effort tier (s6/session.verify_batch)
    s6_truncated_retry_attempted: int = 0
    s6_truncated_retry_recovered: int = 0
    # A replayed FALSE_POSITIVE below min_confidence held as INCONCLUSIVE (undetermined, not FP)
    s6_replayed_fp_held: int = 0
    # A FALSE_POSITIVE whose own file contradicts its reason, held INCONCLUSIVE instead of deleted
    s6_fp_premise_contradicted: int = 0
    # A replayed TRUE_POSITIVE that shipped, its verdict_reason prefixed "[replayed] "
    s6_replayed_tp_shipped: int = 0
    # Batch members the verifier omitted, resubmitted one per call; those that then resolved
    s6_outcome_members_resubmitted: int = 0
    s6_outcome_members_recovered: int = 0
    # An orphaned stage call (past the stage deadline) that still settled in the background
    s2_orphan_settled: int = 0
    s4_orphan_settled: int = 0
    s6_orphan_settled: int = 0
    s8_orphan_settled: int = 0
    # sdk.py/openai.py: a forced submit-tool payload failed validation; re-ask STRUCTURED_REASK_MAX
    llm_structured_submit_rejected: int = 0
    # sdk.py/openai.py: a prose reply instead of the submit-tool call, re-asked once in-session
    llm_structured_prose_reask: int = 0
    # s1_autoexclude.vet_overlay dropped an entry that would erase a whole language from scope
    s1_autoexclude_language_veto: int = 0
    # A5: via:sdk drops the FORCING only for a model memoised as rejecting it, or under manual
    # thinking (adaptive thinking otherwise keeps forcing; tool stays advertised, asked by name, validated)
    sdk_tool_choice_dropped_for_thinking: int = 0
    # A5: via:deepagents drops the FORCING under thinking on every effort-bearing Anthropic call
    # (the ToolStrategy seam, options/response_format.py); a submit instruction compensates for it
    deepagents_tool_choice_dropped: int = 0
    # dispatch_or_retry_unforced on the other stages it wraps (s6's pairs are above): one whole
    # primary call re-dispatched without the tier after a rejected structured reply / a clip
    s1_truncated_retry_attempted: int = 0
    s1_truncated_retry_recovered: int = 0
    s2_structured_retry_attempted: int = 0
    s2_structured_retry_recovered: int = 0
    s2_truncated_retry_attempted: int = 0
    s2_truncated_retry_recovered: int = 0
    s4_structured_retry_attempted: int = 0
    s4_structured_retry_recovered: int = 0
    s4_truncated_retry_attempted: int = 0
    s4_truncated_retry_recovered: int = 0
    s7_structured_retry_attempted: int = 0
    s7_structured_retry_recovered: int = 0
    s7_truncated_retry_attempted: int = 0
    s7_truncated_retry_recovered: int = 0
    s8_structured_retry_attempted: int = 0
    s8_structured_retry_recovered: int = 0
    s8_truncated_retry_attempted: int = 0
    s8_truncated_retry_recovered: int = 0
    ev_classify_truncated_retry_attempted: int = 0
    ev_classify_truncated_retry_recovered: int = 0
    # dispatch_or_retry_unforced: the rejected final had hit its output budget (any route's marker)
    llm_structured_retry_truncated: int = 0
    # s2's hollow re-sample (step2.empty_retry) and the stages' json-repair re-asks: one extra
    # effort-less call per attempt
    s2_empty_retry_attempted: int = 0
    s2_empty_retry_recovered: int = 0
    s2_parse_repair_attempted: int = 0
    s2_parse_repair_recovered: int = 0
    s4_outcome_repaired_attempt: int = 0
    s4_outcome_repaired_ok: int = 0
    s4_batch_repaired_attempt: int = 0
    s4_batch_repaired_ok: int = 0
    s6_outcome_repaired_attempt: int = 0
    s6_outcome_repaired_ok: int = 0
    # VVAH-E008: any route's model call exceeded its effort-scaled wall-clock budget.
    llm_call_timeouts: int = 0
    # Healthy-call telemetry: a COMPLETED xhigh/max call ran at/above 0.75x its budget --
    # evidence for retuning EFFORT_TIME_FACTOR, not a failure signal.
    llm_call_budget_near: int = 0
    # Per-kind tally over all ScopeEntry.kind; superset of chunks_risk/catchall/specialist (kept)
    chunks_by_kind: dict[str, int] = {}

    @property
    def coverage_pct(self) -> float:
        """Returns analyzed unique files as a percentage of files in scope."""
        if not self.total_files_in_scope:
            return 0.0
        return self.analyzed_files_unique / self.total_files_in_scope * 100
