# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Build ScanMetrics from pipeline state, kept out of the orchestrator."""
from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path

from vvaharness.lang.detect import EXT_TO_LANG
from vvaharness.models import (
    ContextPackage,
    InvestigationUnit,
    ScanMetrics,
    ScopeEntry,
    TaskManifest,
)
from vvaharness.util import errlog, stage_telemetry
from vvaharness.util.counters import COUNTERS
from vvaharness.util.pricing import PricingTable
from vvaharness.util.tokens import TOKENS


def _priced_cost_usd(tok: dict, role_models: Mapping[str, str] | None,
                     pricing: PricingTable | None) -> float | None:
    """The run's token counts costed against *pricing*, or None when either input is missing."""
    # Reuses compose_stage_section's per-role costing, so this and the manifest's cost cannot drift
    if not pricing or not role_models:
        return None
    section = stage_telemetry.compose_stage_section({}, tok, role_models, pricing)
    return section["totals"]["cost_usd"]


# Most-specific-prefix-first; only `threat-` has a producer, the rest keep --resume classifying
_KIND_PREFIXES = (
    ("taint-", "taint"),
    ("catchall-", "catchall"),
    ("spec-", "specialist"),
    ("threat-", "threat"),
    ("chunk-", "risk"),
)

# Must stay a subset of ScanMetrics.model_fields (a test pins it): an unmatched name drops silently
_INT_COUNTER_NAMES = (
    "s2_threats_raw", "s2_threats_truncated", "s2_threats_promoted",
    # step2 caps: frontier items kept out of the S2 evidence, and output items cut after it
    "s2_frontier_files_excluded", "s2_frontier_entry_points_excluded",
    "s2_frontier_sinks_excluded", "s2_frontier_modules_excluded",
    "s2_assets_truncated", "s2_trust_boundaries_truncated",
    "s2_prompt_modules_truncated", "s2_prompt_entry_points_truncated",
    "s2_inventory_files_truncated",
    "s2_baseline_undisposed_recovered",
    # s2 surface_files entries that resolved to no in-scope file (fresh S2 runs only)
    "s2_surface_files_dropped",
    "s2_evidence_gate_rejected",
    "s2_evidence_gate_rejected_relented",
    "s3_unknown_file_ids", "s3_dropped_paths", "s3_relocated_paths",
    # s3_unreachable_files NOT here: COUNTERS reads 0 on a --resume past s3; use the manifest
    "s4_findings_truncated",
    "s4_finding_extra_cwe_collapsed",
    "s4_unit_key_deduped",
    "s4_unit_no_outcome", "s4_batch_member_uninvestigated", "s4_batch_member_failed",
    # A batch member retried alone after its shared session errored, omitted or failed to parse it
    "s4_batch_member_resubmitted", "s4_batch_member_recovered",
    # step4 EvidenceGate rejected a premature verdict; the pair counts refusals and relents
    "s4_evidence_gate_rejected", "s4_evidence_gate_rejected_relented",
    "deepagents_oversize_prompts",
    "deepagents_tool_state_not_roundtripped",
    "deepagents_path_jail_refused",
    "llm_truncated_replies",
    "llm_truncated_below_budget",
    "llm_adapter_evidence_gate_unenforced",
    "cli_mcp_evidence_gate_unenforced",
    "evidence_gate_stood_down_degenerate_graph",
    "s6_evidence_gate_rejected",
    "s6_evidence_gate_rejected_relented",
    "llm_turn_cap_exhausted",
    "s6_confirmed_without_vector",
    # TRUE_POSITIVE whose vector scored 0.0 impact; withheld so it does not rank last by that 0.0
    "s6_cvss_zero_impact_on_tp",
    "s6_confidence_clamped", "s6_confidence_uniform",
    "s6_finding_line_correction_reverted_reanchor",
    "s6_batch_structured_split",
    "s6_batch_guardrail_split", "s6_batch_generic_split",
    "s6_structured_retry_attempted",
    "s6_structured_retry_recovered",
    "s6_truncated_retry_attempted",
    "s6_truncated_retry_recovered",
    "llm_structured_submit_rejected",
    "llm_structured_prose_reask",
    # s1_autoexclude.vet_overlay: a model-proposed exts/globs entry erasing a whole known language.
    "s1_autoexclude_language_veto",
    # via:sdk withholds the FORCING under manual (non-adaptive) thinking, or for a memoised model
    "sdk_tool_choice_dropped_for_thinking",
    # via:deepagents: langchain-anthropic drops the FORCING under thinking on every effort-bearing
    # Anthropic call; a submit instruction is appended to compensate (options/response_format.py)
    "deepagents_tool_choice_dropped",
    # dispatch_or_retry_unforced on every stage it wraps (the s6 pairs are above): one whole
    # primary call re-dispatched without the tier, after a rejected structured reply or a clip
    "s1_truncated_retry_attempted", "s1_truncated_retry_recovered",
    "s2_structured_retry_attempted", "s2_structured_retry_recovered",
    "s2_truncated_retry_attempted", "s2_truncated_retry_recovered",
    "s4_structured_retry_attempted", "s4_structured_retry_recovered",
    "s4_truncated_retry_attempted", "s4_truncated_retry_recovered",
    "s7_structured_retry_attempted", "s7_structured_retry_recovered",
    "s7_truncated_retry_attempted", "s7_truncated_retry_recovered",
    "s8_structured_retry_attempted", "s8_structured_retry_recovered",
    "s8_truncated_retry_attempted", "s8_truncated_retry_recovered",
    "ev_classify_truncated_retry_attempted", "ev_classify_truncated_retry_recovered",
    # The rejected final had hit its output budget (any route's marker)
    "llm_structured_retry_truncated",
    # s2's hollow re-sample and the stages' json-repair re-asks (one extra effort-less call each)
    "s2_empty_retry_attempted", "s2_empty_retry_recovered",
    "s2_parse_repair_attempted", "s2_parse_repair_recovered",
    "s4_outcome_repaired_attempt", "s4_outcome_repaired_ok",
    "s4_batch_repaired_attempt", "s4_batch_repaired_ok",
    "s6_outcome_repaired_attempt", "s6_outcome_repaired_ok",
    # VVAH-E008: any route's model call exceeded its effort-scaled wall-clock budget.
    "llm_call_timeouts",
    # Healthy-call telemetry: a COMPLETED xhigh/max call ran at/above 0.75x its budget.
    "llm_call_budget_near",
    # Any route's model call refused by the provider (per call; route + category in the errors log)
    "llm_model_refusals",
    # A refused call re-sent once unchanged (refusal_retries, Anthropic routes), and those answered
    "llm_refusal_retry_attempted", "llm_refusal_retry_recovered",
    # A truncated reply resent once with the doubled output budget, and the resends it rescued
    "llm_truncated_retry_attempted", "llm_truncated_retry_recovered",
    # s6 replayed verdicts: a below-gate FALSE_POSITIVE held as INCONCLUSIVE; a shipped TRUE_POSITIVE
    "s6_replayed_fp_held", "s6_replayed_tp_shipped",
    # A FALSE_POSITIVE whose own reason the finding's file contradicts; held INCONCLUSIVE, not deleted
    "s6_fp_premise_contradicted",
    # s6 batch members the verifier omitted, resubmitted as singletons, and those that then resolved
    "s6_outcome_members_resubmitted", "s6_outcome_members_recovered",
    # An orphaned stage call (past the stage deadline) that still settled in the background
    "s2_orphan_settled", "s4_orphan_settled", "s6_orphan_settled", "s8_orphan_settled",
)


def _classify_unit_kind(u: InvestigationUnit) -> str:
    """Classify a unit's analysis kind from its id prefix."""
    uid = u.id
    for prefix, kind in _KIND_PREFIXES:
        if uid.startswith(prefix):
            return kind
    return "other"


def now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _elapsed_sec(start_ts: str, end_ts: str) -> float:
    try:
        s = datetime.fromisoformat(start_ts.replace("Z", "+00:00"))
        e = datetime.fromisoformat(end_ts.replace("Z", "+00:00"))
        return (e - s).total_seconds()
    except Exception:
        return 0.0


def refresh_tokens(metrics: ScanMetrics | None, *,
                   end_ts: str | None = None,
                   role_models: Mapping[str, str] | None = None,
                   pricing: PricingTable | None = None) -> None:
    """Re-snapshot TOKENS, the error log and the int counters into a built ScanMetrics, in place."""
    # build() runs BEFORE s8, so it is blind to s8 spend; None token fields must not become 0
    if metrics is None:
        return
    if end_ts:
        metrics.end_ts = end_ts
        metrics.duration_sec = _elapsed_sec(metrics.start_ts, end_ts)
    # Unconditional: an s8 failure can log with no model call, so no token-usage gate here
    metrics.errors_by_stage = errlog.counts_by_stage()
    metrics.errors_log_path = (str(errlog.current_path())
                               if errlog.current_path().exists() else "")
    counters = COUNTERS.snapshot()
    for name in _INT_COUNTER_NAMES:
        # Kept at its build() value: the only counter-backed coverage_degraded() reason, and
        # an s8 forced final bumps it on sdk/openai, which would flag a healthy scan degraded
        if name in counters and name != "llm_turn_cap_exhausted":
            setattr(metrics, name, counters[name])
    tok = TOKENS.snapshot()
    if tok["calls_with_usage"] <= 0:
        return
    metrics.prompt_tokens = tok["prompt"]
    metrics.completion_tokens = tok["completion"]
    metrics.total_tokens = tok["total"]
    metrics.tokens_by_phase = tok.get("by_phase")
    metrics.reported_cost_usd = tok.get("usd")
    metrics.priced_cost_usd = _priced_cost_usd(tok, role_models, pricing)


def build(ctx: ContextPackage, manifest: TaskManifest, *,
          repo_name: str, start_ts: str, end_ts: str,
          raw_findings: int, true_pos: int, false_pos: int,
          duplicates: int, discovered_tp: int = 0, clone_tp: int = 0,
          ev_rescued: int = 0,
          unit_outcomes: dict[str, str] | None = None,
          external_input: bool = False,
          role_models: Mapping[str, str] | None = None,
          pricing: PricingTable | None = None) -> ScanMetrics:
    repo_root = Path(ctx.repo_root)

    # Only COMPLETED units' files count as analyzed, or coverage overstates; no outcome = clean
    outcomes = unit_outcomes or {}
    external_only = external_input and all(
        outcome in ("injected", "confirmed") for outcome in outcomes.values())
    analyzed: set[str] = set()
    scope: list[ScopeEntry] = []
    kind_counts: dict[str, int] = defaultdict(int)
    for u in manifest.units:
        if not external_only and outcomes.get(
            u.id, "uninvestigated" if external_input else "completed") == "completed":
            analyzed.update(u.files)
        kind = _classify_unit_kind(u)
        kind_counts[kind] += 1
        scope.append(ScopeEntry(name=u.id, kind=kind, files=sorted(u.files)))
    # Back-compat tallies: each counts ONLY its own bucket, so all three read 0 today.
    n_spec = kind_counts.get("specialist", 0)
    n_catch = kind_counts.get("catchall", 0)
    n_risk = kind_counts.get("risk", 0)

    folders = sorted({str(Path(f).parent).replace("\\", "/")
                      for f in analyzed if "/" in f or "\\" in f} | {"."})

    loc_scope: dict[str, int] = defaultdict(int)
    loc_scan: dict[str, int] = defaultdict(int)
    for f in ctx.all_files:
        lang = EXT_TO_LANG.get(Path(f).suffix.lower(), "other")
        loc = _loc(repo_root / f)
        loc_scope[lang] += loc
        if f in analyzed:
            loc_scan[lang] += loc

    dur = _elapsed_sec(start_ts, end_ts)

    tok = TOKENS.snapshot()
    tok_avail = tok["calls_with_usage"] > 0

    # Authoritative failure count, not the coarse per-stage error log.
    chunks_attempted = 0 if external_only else len(manifest.units)
    # "skipped" is a DESIGNED outcome, not a failure; counting it cried failure on healthy runs
    non_failures = (("completed", "skipped", "injected", "confirmed")
                    if external_input else ("completed", "skipped"))
    chunks_failed = sum(1 for outcome in outcomes.values() if outcome not in non_failures)

    # Present keys only; the defaults still hide "never ran" from zero, but build() invents nothing
    counters = COUNTERS.snapshot()
    counter_fields: dict[str, object] = {}

    for name in _INT_COUNTER_NAMES:
        if name in counters:
            counter_fields[name] = counters[name]

    # s2_degraded is bool on ScanMetrics but a COUNT here: any nonzero value means degraded.
    if "s2_degraded" in counters:
        counter_fields["s2_degraded"] = bool(counters["s2_degraded"])

    # Comma-joined COUNTERS.note -> list[str]; an empty note stays [], never [""]
    for name in ("s2_baseline_undisposed", "s2_repo_kinds"):
        if name in counters:
            raw = counters[name]
            counter_fields[name] = raw.split(",") if raw else []

    return ScanMetrics(
        scan_id=f"{start_ts}__{repo_name}",
        module_name=repo_name,
        start_ts=start_ts,
        end_ts=end_ts,
        duration_sec=dur,
        total_files_in_scope=len(ctx.all_files),
        analyzed_files_unique=len(analyzed & set(ctx.all_files)),
        # Checkpointed, not a COUNTERS snapshot: on a --resume past s3 COUNTERS would read 0
        s3_unreachable_files=len(manifest.unreachable_files),
        # Same resume-safety reasoning as s3_unreachable_files above, reconciled against the
        # threat model the report carries (a re-run s2 can pair with a cached s3 on --resume)
        s3_threats_without_unit=len(manifest.threats_without_unit_for(ctx.threat_model)),
        chunks_total=len(manifest.units),
        chunks_risk=n_risk,
        chunks_catchall=n_catch,
        chunks_specialist=n_spec,
        chunks_attempted=chunks_attempted,
        chunks_failed=chunks_failed,
        deepdive_skipped=external_only,
        errors_by_stage=errlog.counts_by_stage(),
        # current_path() returns the path even if log() never wrote, so "" avoids a dead link
        errors_log_path=(str(errlog.current_path())
                          if errlog.current_path().exists() else ""),
        loc_in_scope_by_language=dict(loc_scope),
        loc_scanned_by_language=dict(loc_scan),
        raw_findings_count=raw_findings,
        true_positive_count=true_pos,
        false_positive_count=false_pos,
        duplicate_count=duplicates,
        discovered_true_positive_count=discovered_tp,
        repeat_clone_true_positive_count=clone_tp,
        ev_rescued_count=ev_rescued,
        prompt_tokens=tok["prompt"] if tok_avail else None,
        completion_tokens=tok["completion"] if tok_avail else None,
        total_tokens=tok["total"] if tok_avail else None,
        tokens_by_phase=tok.get("by_phase") if tok_avail else None,
        reported_cost_usd=tok.get("usd"),
        priced_cost_usd=(_priced_cost_usd(tok, role_models, pricing)
                        if tok_avail else None),
        folders_scanned=folders,
        scope=scope,
        excluded=ctx.excluded or {},
        # Computed here, not read from COUNTERS: it is a property of the manifest, not an event.
        chunks_by_kind=dict(kind_counts),
        **counter_fields,
    )


def _loc(p: Path) -> int:
    try:
        return sum(1 for ln in p.open("r", encoding="utf-8", errors="replace")
                   if ln.strip())
    except OSError:
        return 0
