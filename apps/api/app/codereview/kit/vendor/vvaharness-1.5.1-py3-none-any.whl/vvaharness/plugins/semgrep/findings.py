# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Turning `semgrep --json` output into vvaharness Findings, so S5 onward can run on them."""
from __future__ import annotations

import json
import re
from pathlib import Path, PurePosixPath

from vvaharness.models import Finding, VulnClass
from vvaharness.report.cwe import cwe_name
from vvaharness.util import logs
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

MAX_FINDINGS = 2_000
MAX_JSON_BYTES = 64 * 1024 * 1024
_MAX_SNIPPET_CHARS = 2_000
_MAX_TITLE_CHARS = 200
_MAX_LABEL_CHARS = 120

_CWE_RE = re.compile(r"CWE-(\d{1,5})")

#: CWE to the 12-member VulnClass enum. Anything unmapped becomes `other` rather than being
#: dropped, because a finding vvaharness cannot classify is still a finding it must carry.
_CWE_TO_CLASS: dict[int, VulnClass] = {
    77: VulnClass.INJECTION, 78: VulnClass.INJECTION, 79: VulnClass.INJECTION,
    89: VulnClass.INJECTION, 90: VulnClass.INJECTION, 91: VulnClass.INJECTION,
    94: VulnClass.INJECTION, 95: VulnClass.INJECTION, 611: VulnClass.INJECTION,
    643: VulnClass.INJECTION, 917: VulnClass.INJECTION,
    502: VulnClass.DESERIALIZATION,
    190: VulnClass.INT_OVERFLOW, 191: VulnClass.INT_OVERFLOW,
    362: VulnClass.RACE, 367: VulnClass.RACE,
    134: VulnClass.FMT_STRING,
    416: VulnClass.UAF,
    121: VulnClass.STACK_OVERFLOW,
    122: VulnClass.HEAP_OVERFLOW, 787: VulnClass.HEAP_OVERFLOW,
    843: VulnClass.TYPE_CONFUSION,
    200: VulnClass.INFO_LEAK, 209: VulnClass.INFO_LEAK, 532: VulnClass.INFO_LEAK,
    22: VulnClass.LOGIC, 287: VulnClass.LOGIC, 306: VulnClass.LOGIC,
    352: VulnClass.LOGIC, 862: VulnClass.LOGIC, 863: VulnClass.LOGIC,
    # Widened so common Semgrep CWEs map to a class instead of folding to OTHER.
    # Only added where the CWE *is* the class; a CWE the 12-member enum genuinely cannot
    # express keeps OTHER and carries vuln_class_label.
    88: VulnClass.INJECTION, 117: VulnClass.INJECTION, 470: VulnClass.INJECTION,
    943: VulnClass.INJECTION, 1336: VulnClass.INJECTION,
    704: VulnClass.TYPE_CONFUSION,
    215: VulnClass.INFO_LEAK, 311: VulnClass.INFO_LEAK, 312: VulnClass.INFO_LEAK,
    313: VulnClass.INFO_LEAK, 315: VulnClass.INFO_LEAK, 319: VulnClass.INFO_LEAK,
    359: VulnClass.INFO_LEAK, 497: VulnClass.INFO_LEAK, 522: VulnClass.INFO_LEAK,
    614: VulnClass.INFO_LEAK, 798: VulnClass.INFO_LEAK,
}

_SEVERITY = {"ERROR": "high", "WARNING": "medium", "INFO": "low"}


class SemgrepFindingsError(ValueError):
    """Raised when Semgrep JSON cannot be read as a finding set."""


def _posix(value: str) -> PurePosixPath:
    """*value* as a POSIX pure path, so a Windows separator keys the same as a POSIX one."""
    return PurePosixPath(value.replace("\\", "/"))


def _under(base: PurePosixPath, candidate: PurePosixPath) -> str:
    """*candidate* as a path relative to *base*, or empty when it does not sit under it."""
    return str(candidate.relative_to(base)) if candidate.is_relative_to(base) else ""


def relative_path(path: str, root: str) -> str:
    """A Semgrep path as vvaharness keys findings: repo-relative, POSIX, no leading ``./``."""
    candidate = _posix(path)
    if not root or not candidate.is_absolute():
        return str(candidate) if str(candidate) not in (".", "") else path
    base = _posix(str(Path(root).resolve()))
    under = _under(base, candidate) or _under(base, _posix(str(Path(path).resolve())))
    if under:
        return under
    COUNTERS.bump("semgrep_path_outside_repo")
    log.warning(Event.SEMGREP_PATH_NOT_RELATIVE, path=str(candidate), repo_root=str(base),
                detail="this finding keeps an absolute path, so S5 drops it as a file that is "
                       "not in the repo inventory")
    return str(candidate)


def _cwe_ids(metadata: dict) -> list[str]:
    """Every ``CWE-n`` mentioned in a rule's cwe metadata, in first-seen order."""
    raw = metadata.get("cwe") or []
    values = [raw] if isinstance(raw, str) else [v for v in raw if isinstance(v, str)]
    seen: dict[str, None] = {}
    for value in values:
        for match in _CWE_RE.finditer(value):
            seen.setdefault(f"CWE-{int(match.group(1))}", None)
    return list(seen)


def _vuln_class(cwes: list[str]) -> VulnClass:
    """The first mapped CWE's class, else ``other``; never raises on an unknown CWE."""
    for cwe in cwes:
        mapped = _CWE_TO_CLASS.get(int(cwe.removeprefix("CWE-")))
        if mapped is not None:
            return mapped
    return VulnClass.OTHER


def _label(metadata: dict, cwes: list[str]) -> str:
    """The caller's own wording for a class VulnClass cannot express; s8 reads it for coverage."""
    raw = metadata.get("vulnerability_class") or []
    values = [raw] if isinstance(raw, str) else [v for v in raw if isinstance(v, str)]
    authored = next((v.strip() for v in values if v.strip()), "")
    return authored or next((cwe_name(c) for c in cwes if cwe_name(c)), "")


def _finding(result: dict, root: str) -> Finding | None:
    """One Semgrep result as a Finding, or None when it carries no usable location."""
    raw_path = result.get("path")
    start = (result.get("start") or {}).get("line")
    if not isinstance(raw_path, str) or not isinstance(start, int):
        return None
    path = relative_path(raw_path, root)
    extra = result.get("extra") or {}
    metadata = extra.get("metadata") or {}
    cwes = _cwe_ids(metadata)
    vuln_class = _vuln_class(cwes)
    rule_id = str(result.get("check_id") or "semgrep")
    message = str(extra.get("message") or rule_id)
    optional = {
        "line_end": (result.get("end") or {}).get("line"),
        "cwe": cwes[0] if cwes else None,
        "severity": _SEVERITY.get(str(extra.get("severity", "")).upper()),
        "code_snippet": str(extra.get("lines") or "")[:_MAX_SNIPPET_CHARS] or None,
        "vuln_class_label": (_label(metadata, cwes)[:_MAX_LABEL_CHARS]
                             if vuln_class is VulnClass.OTHER else None),
    }
    return Finding(
        title=message.strip().splitlines()[0][:_MAX_TITLE_CHARS] or rule_id,
        file=path,
        line_start=start,
        vuln_class=vuln_class,
        description=message,
        origin=f"semgrep:{rule_id}",
        **{k: v for k, v in optional.items() if v is not None},
    )


def findings_from_semgrep(payload: Path | str | dict, *,
                         repo: Path | str | None = None) -> list[Finding]:
    """Findings from a ``semgrep --json`` document, given as a path or an already-parsed dict."""
    # Pass repo= whenever semgrep was given an absolute target: it then reports absolute paths,
    # vvaharness keys findings on repo-relative ones, and every unresolvable file is DROPPED by S5.
    document = payload if isinstance(payload, dict) else read_semgrep_json(Path(payload))
    root = "" if repo is None else str(repo)
    results = document.get("results")
    if not isinstance(results, list):
        raise SemgrepFindingsError("semgrep JSON has no 'results' list")
    if len(results) > MAX_FINDINGS:
        raise SemgrepFindingsError(f"{len(results)} results exceeds MAX_FINDINGS={MAX_FINDINGS}")
    return [f for r in results if isinstance(r, dict) and (f := _finding(r, root)) is not None]


def read_semgrep_json(path: Path) -> dict:
    """A bounded JSON read, so an oversized or malformed report fails before parsing costs."""
    try:
        if path.stat().st_size > MAX_JSON_BYTES:
            raise SemgrepFindingsError(f"{path} exceeds MAX_JSON_BYTES={MAX_JSON_BYTES}")
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise SemgrepFindingsError(f"cannot read semgrep JSON at {path}: {exc}") from exc
    if not isinstance(document, dict):
        raise SemgrepFindingsError(f"semgrep JSON at {path} is not an object")
    return document


__all__ = [
    "MAX_FINDINGS",
    "MAX_JSON_BYTES",
    "SemgrepFindingsError",
    "findings_from_semgrep",
    "read_semgrep_json",
    "relative_path",
]
