# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Step 0 — deterministic source/sink text matching that seeds entry points and sinks."""
from __future__ import annotations

from pathlib import Path

from vvaharness.lang.detect import VVAH_LANGUAGES, canonical_lang, detect_languages
from vvaharness.models.scan import SeedPackage
from vvaharness.scope import _walk_repo
from vvaharness.util import console, logs

log = logs.get_logger(__name__)

# ruleId/message tokens -> EntryPoint.kind; unmatched -> "other", then _EP_KIND_ALIAS normalises
_KIND_HINTS: dict[str, str] = {
    "http": "network", "request": "network", "route": "network",
    "controller": "network", "servlet": "network", "handler": "network",
    "graphql": "network", "grpc": "network", "websocket": "network",
    "queue": "ipc", "kafka": "ipc", "jms": "ipc", "amqp": "ipc",
    "argv": "cli", "stdin": "cli", "flag": "cli",
    "env": "file", "config": "file", "fileread": "file",
    "deseriali": "deserialization", "unmarshal": "deserialization",
    "pickle": "deserialization", "yaml-load": "deserialization",
}


def _filter_step0_languages(langs: list[str], cfg) -> list[str]:
    """Returns langs narrowed to the canonicalised ``step0.languages`` allowlist, or unchanged if unset."""
    step0 = getattr(cfg, "step0", None)
    raw = getattr(step0, "languages", None) if step0 is not None else None
    if not raw:
        return langs
    allow: set[str] = set()
    for x in raw:
        if not str(x).strip():
            continue
        canon = canonical_lang(x)
        allow.add(canon)
        # docs/security.md:188 forbids silent scope narrowing, so a no-match typo must be surfaced
        if canon not in VVAH_LANGUAGES:
            console.write(f"  [s0] WARNING: step0.languages entry {x!r} is not a "
                          f"recognized language or alias; it will not match any file")
    return [l for l in langs if l in allow]


def run(repo_root: str, cfg, ckpt_dir: Path | None = None) -> SeedPackage:
    """Execute the static seed: walk the repo, then match sources/sinks against source text."""
    log.info("s0/seed: starting AST-based seed generation for %s", repo_root)
    all_files, excluded = _walk_repo(repo_root, cfg)
    in_scope = set(all_files)
    langs = _filter_step0_languages(detect_languages(all_files), cfg)
    log.info("s0/seed: file walk complete - total=%d excluded=%d in_scope=%d langs=%s",
             len(all_files) + len(excluded), len(excluded), len(in_scope), langs)
    # Match on source TEXT: graph-node sink matching misses library calls
    from vvaharness.detect import scan as _detect_scan
    result = _detect_scan(Path(repo_root), sorted(in_scope))
    seed = SeedPackage(
        entry_points=result.entry_points,
        unsafe_sinks=result.unsafe_sinks,
        languages=langs,
        all_files=all_files,
        excluded=excluded,
    )
    log.info("s0/seed: seed generation complete - entry_points=%d sinks=%d paths=%d",
             len(seed.entry_points), len(seed.unsafe_sinks), len(seed.taint_paths))
    return seed




