# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""`agentic()` — a tool-using session, with its watchdog and confinement argv."""
from __future__ import annotations

import json
import subprocess
import threading
import time
import uuid
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Final

from vvaharness.backends.harness.deepagents.limits import MODEL_MAX_OUTPUT_TOKENS
from vvaharness.backends.harness.models import (
    CallTimeoutError,
    SessionNotResumableError,
)
from vvaharness.backends.llm.cli import cancel as _cancel
from vvaharness.backends.llm.cli import discovery as _discovery
from vvaharness.backends.llm.cli import env as _env
from vvaharness.backends.llm.cli import envelope as _envelope
from vvaharness.backends.llm.cli import process as _process
from vvaharness.backends.llm.cli import retry as _retry
from vvaharness.backends.llm.models import (
    ClockKind,
    call_timeout_error,
    effort_scaled_seconds,
    note_budget_use,
    truncation_retry_max,
)
from vvaharness.report.redact import redact
from vvaharness.util import console, logs
from vvaharness.util import errlog as _errlog
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event
from vvaharness.util.git_paths import git_dir_spellings
from vvaharness.util.tokens import TOKENS
from vvaharness.util.warn_once import warn_once

log = logs.get_logger(__name__)

#: Degradations already announced, so an old binary warns once, not once per call.
_WARNED_CAPS: set[str] = set()


@dataclass
class _CliPin:
    """One stage session's live cli attempt, so the stage can resume it after its deadline."""

    cmd: list[str]
    model: str
    cwd: str
    env: dict | None
    json_schema: dict | None
    tier: str | None
    exited: threading.Event


#: stage session id -> its live cli attempt; written once per agentic() loop iteration.
_PINNED_CLI: dict[str, _CliPin] = {}
_PINNED_CLI_LOCK = threading.Lock()

#: How long resume_agentic waits for the SIGINT-stopped process to actually exit.
_RESUME_EXIT_GRACE_S: Final = 5

#: Never-read dirs; a deliberate literal copy of tools._ALWAYS_EXCLUDED_DIRS, pinned by test
_READ_DENY_DIRS: Final[tuple[str, ...]] = (".git", ".hg", ".svn",
                                          "checkpoints", "security-scan")

#: A .git/config write is RCE; the CLI's rule matcher is case-sensitive, so list every spelling
_GIT_WRITE_DENY_RULES: Final[tuple[str, ...]] = tuple(
    f"{tool}({where}{d}{tail})"
    for d in git_dir_spellings()
    for tool in ("Edit", "Write")
    for where in ("./", "**/")
    for tail in ("", "/**"))

#: Fallback wall clock only: hardcoding it made `step2.timeout` never apply on this branch
_AGENTIC_TIMEOUT: Final = 3600


class _TurnWatchdog:
    """Cap an agentic loop by counting assistant turns, for a binary without --max-turns."""
    # Armed only when the CLI rejects ``--max-turns`` or the capability probe fails. Counting
    # every assistant event over-counts on purpose (safe side); a zero-tool session counts by
    # message.id instead, so the cap still grants that many full turns.

    def __init__(self, cap: int, *, by_message: bool = False) -> None:
        self.cap = cap
        self.by_message = by_message
        self.seen = 0
        self.tripped = False
        self._trip_at = cap + 1 if by_message else cap
        self._ids: set[str] = set()

    def _counts(self, evt: dict) -> bool:
        """Whether *evt* counts: every event, or only a new message.id when *by_message*."""
        msg = evt.get("message")
        msg_id = msg.get("id") if self.by_message and isinstance(msg, dict) else None
        if not isinstance(msg_id, str):
            return True
        if msg_id in self._ids:
            return False
        self._ids.add(msg_id)
        return True

    def describe(self) -> str:
        """The count that tripped, in the unit and comparison this watchdog uses."""
        unit, op = ("messages", ">") if self.by_message else ("events", ">=")
        return f"{self.seen} assistant {unit} {op} max_turns={self.cap}"

    def __call__(self, line: str) -> bool:
        """Consume one stdout line; True when the cap is reached and the run must stop."""
        if self.tripped:
            return False
        try:
            evt = json.loads(line)
        except (json.JSONDecodeError, TypeError):
            return False
        if not isinstance(evt, dict) or evt.get("type") != "assistant" or not self._counts(evt):
            return False
        self.seen += 1
        if self.seen >= self._trip_at:
            self.tripped = True
            return True
        return False


#: Default instruction for the two best-effort callers (turn watchdog, wall-clock salvage);
#: a stage-deadline resume passes its own instruction instead.
_FINAL_ANSWER_INSTRUCTION = (
    "Your turn limit was reached. Give your final answer now, in the exact "
    "format the original instructions asked for, using only what you already "
    "have. Do not use any tool."
)


def _finalize_via_resume(session_id: str, *, model: str, cwd: str,
                         timeout: int, tag: str | None,
                         env: dict | None = None,
                         json_schema: dict | None = None,
                         instruction: str = _FINAL_ANSWER_INSTRUCTION,
                         fail_detail: dict | None = None) -> str | None:
    """Ask the killed session for its final answer, or None when that is not possible.

    *fail_detail*, when given, is filled in with the failure cause (rc/stderr, or the
    exception type) so a caller's diagnostic can say why the resume did not work.
    """
    if fail_detail is None:
        fail_detail = {}
    cmd = [*_discovery._CLAUDE_CMD, "-p", "--resume", session_id, "--model", model,
           "--tools", "", "--output-format", "json"]
    # Without --json-schema a resume answers in free text; `--tools ""` does not prevent it.
    if json_schema and _discovery._cli_capabilities()["json_schema"]:
        cmd += ["--json-schema", json.dumps(json_schema)]
    cmd += _confinement_argv(allowed_tools=None, disallowed_tools=None,
                             permission_prompts=None)
    try:
        result = _process._run(cmd, input=instruction, cwd=cwd, timeout=timeout, env=env)
    except Exception as exc:
        fail_detail["cause"] = type(exc).__name__
        return None
    if result.returncode != 0:
        # Mirror agentic()'s own non-zero-exit branch (_raise_if_refused_exit, above
        # in this call chain): a refused resume must raise, never degrade to "resume
        # failed" and fall back to the killed session's partial streamed text.
        _envelope._raise_if_refused_exit(result.stdout, tag=tag)
        fail_detail["rc"] = result.returncode
        fail_detail["stderr"] = result.stderr
        return None
    text = _envelope._parse_envelope(result.stdout)
    _envelope._note_unparsed_cache_keys(text.usage)
    TOKENS.add(text.usage, usd=text.usd, turns=text.turns)
    # Raise, never None: a refused salvage must not fall back to the streamed partial text
    _envelope._raise_if_refused(text.stop_reason, tag=tag, stdout=result.stdout)
    return text.text or None


def _recover_timed_out_session(*, session_id: str, model: str, cwd: str,
                               wall_clock: int, tag: str | None,
                               env: dict | None = None,
                               json_schema: dict | None = None) -> str | None:
    """Ask a wall-clock-killed session for its final answer; None when the resume failed too."""
    tag_sfx = f" [{tag}]" if tag else ""
    console.write(f"    [cli] turn deadline reached ({wall_clock}s){tag_sfx} — asking the "
                  f"session for a final answer")
    final = _finalize_via_resume(session_id, model=model, cwd=cwd,
                                 timeout=min(300, wall_clock), tag=tag, env=env,
                                 json_schema=json_schema)
    if final is None:
        return None
    COUNTERS.bump("cli_timeout_finalized")
    _errlog.log(
        tag or "cli", tag or "timeout",
        f"VVAH-E008 warning: session exceeded {wall_clock}s; final answer "
        "recovered by resuming the session",
        error_code=CallTimeoutError.error_code, recovered=True)
    return final


def release_pinned_session(stage_id: str) -> None:
    """Forget *stage_id*'s pinned cli attempt; a late `exited` set then finds no entry."""
    with _PINNED_CLI_LOCK:
        _PINNED_CLI.pop(stage_id, None)


def _resume_fail_detail(fail_detail: dict) -> str:
    """A short, redacted diagnostic suffix: the rc/stderr tail, or the exception type."""
    if "rc" in fail_detail:
        return (f" (rc={fail_detail['rc']}, stderr: "
                f"{_discovery._tail(redact(fail_detail.get('stderr')))})")
    if "cause" in fail_detail:
        return f" ({fail_detail['cause']})"
    return ""


def resume_agentic(session_id: str, instruction: str, *, timeout: float | None,
                   tag: str | None) -> str:
    """Continue *session_id*'s stopped cli attempt with *instruction*; the stage's own resume."""
    with _PINNED_CLI_LOCK:
        pin = _PINNED_CLI.get(session_id)
    if pin is None:
        raise SessionNotResumableError(
            f"cli session {session_id!r} was never pinned or has been released")
    # Free and memoised: check it before paying the exit-wait grace below.
    if not _discovery._cli_capabilities().get("resume", False):
        raise SessionNotResumableError(
            f"cli session {session_id!r}: this claude build does not support --resume")
    # The wait prevents a silent interleave of two processes writing one transcript.
    if not pin.exited.wait(_RESUME_EXIT_GRACE_S):
        raise SessionNotResumableError(
            f"cli session {session_id!r} has not exited yet; refusing to resume it")
    # 0/None is "no clock"; unlike effort_scaled_seconds(0), the fallback is not an instant kill.
    raw = timeout if (timeout is not None and timeout > 0) else _AGENTIC_TIMEOUT
    budget = effort_scaled_seconds(raw, pin.tier, kind=ClockKind.SESSION)
    live_id = pin.cmd[pin.cmd.index("--session-id") + 1]
    fail_detail: dict = {}
    final = _finalize_via_resume(live_id, model=pin.model, cwd=pin.cwd, timeout=budget,
                                 tag=tag, env=pin.env, json_schema=pin.json_schema,
                                 instruction=instruction, fail_detail=fail_detail)
    if final is None:
        raise SessionNotResumableError(
            f"cli session {live_id} could not be resumed{_resume_fail_detail(fail_detail)}")
    return final


def _bare_tool_names(allowed_tools: Sequence[str] | None) -> list[str]:
    """Strip `Name(spec)` scoping so a permission RULE can be reused as an availability name."""
    out: list[str] = []
    for raw in allowed_tools or ():
        bare = str(raw).split("(", 1)[0].strip()
        if bare and bare not in out:
            out.append(bare)
    return out


def _confinement_argv(*, allowed_tools, disallowed_tools,
                      permission_prompts: str | None) -> list[str]:
    """Flags that keep a `claude` loop from being steered by the repo it is scanning."""
    # Probe-gated; `--allowedTools` alone left 28 tools incl Bash on 2.1.270 — `--tools` is the jail
    caps = _discovery._cli_capabilities()
    argv: list[str] = []

    def _gate(cap: str, flags: list[str], lost: str) -> None:
        if caps.get(cap):
            argv.extend(flags)
            return
        warn_once(_WARNED_CAPS, cap,
                  f"  [cli] WARN: this `claude` build does not advertise "
                  f"--{cap.replace('_', '-')}; {lost}")

    native = _bare_tool_names(allowed_tools)
    if native:
        _gate("tools", ["--tools", ",".join(native)],
              "tool availability is NOT restricted to the allowlist — the session "
              "keeps the CLI's full default toolset (Bash/Edit/Write included) and "
              "the permission classifier may approve them. Upgrade the CLI.")
    elif allowed_tools is not None:
        # An explicit empty allowlist means zero tools, not "no restriction requested".
        _gate("tools", ["--tools", ""],
              "tool availability is NOT confined to zero tools — the session keeps "
              "the CLI's full default toolset (Bash/Edit/Write included) instead of "
              "running with none. Upgrade the CLI.")
    # `--restricted` cannot exclude in-repo `.git`; Read() rules only, so Grep can still match there
    deny = [*(str(t) for t in (disallowed_tools or ())),
            *(f"Read(./{d}/**)" for d in _READ_DENY_DIRS),
            *_GIT_WRITE_DENY_RULES]
    if deny:
        _gate("disallowed_tools", ["--disallowedTools", *deny],
              f"cannot deny {deny} explicitly.")
    if permission_prompts:
        _gate("permission_prompts", ["--permission-prompts", permission_prompts],
              "an action that would raise a permission prompt is not auto-denied.")
    if _env._cfg.get("restricted", True):
        _gate("restricted", ["--restricted"],
              "the file tools are NOT confined to the working directory — this "
              "session can read any file the operator can, anywhere on the host. "
              "Upgrade the CLI (or accept the exposure knowingly).")
    _gate("setting_sources", ["--setting-sources", "user"],
          "the SCANNED repository's .claude/settings.json and .claude/commands are "
          "loaded into this session.")
    _gate("strict_mcp_config", ["--strict-mcp-config"],
          "the SCANNED repository's .mcp.json servers can be started on this host.")
    _gate("disable_slash_commands", ["--disable-slash-commands"],
          "skills and slash commands remain loaded as prompt-injection surface.")
    return argv


def agentic(
    user_prompt: str,
    *,
    model: str,
    system_prompt: str | None = None,
    allowed_tools: list[str] | None = None,
    cwd: str,
    max_budget_usd: float | None = None,
    max_tokens: int | None = None,
    permission_mode: str = "auto",
    max_turns: int | None = None,  # native flag if advertised, else the turn watchdog.
    timeout: int | None = None,    # wall clock for the whole loop; None => _AGENTIC_TIMEOUT.
    tag: str | None = None,
    stream_cb=None,                # optional: raw stream-json callback, live (--verbose trace).
    json_schema: dict | None = None,   # force schema-valid JSON (probe-gated), as prompt() does
    disallowed_tools=None,             # explicit deny rules; deny beats allow
    permission_prompts: str | None = None,  # "none" => anything that would prompt is denied
    extra_tools=None,              # accepted for signature parity with the sdk /
    extra_dispatch=None,           # openai loops; the CLI cannot carry them (see
    # the guard below) and rejects them loudly.
    effort: str | None = None,     # per-call tier; None => the global cli.effort
    session_id: str = "",          # the STAGE's session id; "" => no stage owns the resume
) -> str:
    """Agentic mode — Claude gets tools to explore the repo (reads files, greps, etc.)."""
    # Confinement flags are HARD-ON by design; no caller tool can ride this route, so fail early
    if extra_tools:
        raise NotImplementedError(
            "claude_cli.agentic cannot carry a caller-supplied tool; the CLI "
            "subprocess only exposes its own built-in tools. Route to via: sdk "
            "or via: openai for a loop that accepts extra_tools/extra_dispatch.")

    if _cancel._ABORT.is_set():
        raise RuntimeError("aborted by user (Ctrl-C)")
    cmd = [*_discovery._CLAUDE_CMD, "-p", "--model", model, *_env._effort_argv(effort)]

    if system_prompt:
        # REPLACES, not --append-system-prompt: deliberate, so output cannot drift with the binary
        cmd += ["--system-prompt", system_prompt]
    if allowed_tools:
        # Honour the allowlist as-given; Bash is never force-added (repos could prompt-inject RCE).
        cmd += ["--allowedTools"] + list(allowed_tools)
    if json_schema:
        if _discovery._cli_capabilities()["json_schema"]:
            # Verified: the CLI ADDS StructuredOutput to `--tools`, it does not replace the set
            cmd += ["--json-schema", json.dumps(json_schema)]
        else:
            warn_once(_WARNED_CAPS, "json_schema_agentic",
                      "  [cli] WARN: this `claude` build does not advertise "
                      "--json-schema; the agentic reply is not schema-validated "
                      "and the caller must salvage it from free text.")
    cmd += _confinement_argv(allowed_tools=allowed_tools,
                             disallowed_tools=disallowed_tools,
                             permission_prompts=permission_prompts)
    # Forward the spend cap only when the CLI advertises --max-budget-usd (probe-gated).
    if max_budget_usd and _discovery._cli_capabilities().get("max_budget"):
        cmd += ["--max-budget-usd", str(max_budget_usd)]
    native_turn_cap = bool(max_turns) and bool(_discovery._cli_capabilities().get("max_turns"))
    if native_turn_cap:
        cmd += ["--max-turns", str(int(max_turns))]

    cmd += ["--permission-mode", _discovery._safe_permission_mode(permission_mode)]
    cmd += ["--output-format", "stream-json", "--verbose"]

    tier = _env._effective_effort(effort)
    raw_wall_clock = int(timeout) if timeout else _AGENTIC_TIMEOUT
    wall_clock = effort_scaled_seconds(raw_wall_clock, tier, kind=ClockKind.SESSION)
    # Armed only when a cap was asked for and the binary cannot enforce it
    watchdog_cap = int(max_turns) if (max_turns and not native_turn_cap) else None
    # None is unrestricted; only an explicit zero-tool session counts turns by message.id
    by_message = allowed_tools is not None and not _bare_tool_names(allowed_tools)

    _factor = wall_clock / raw_wall_clock
    _factor_sfx = f" (effort={tier} ×{_factor:g})" if _factor != 1.0 else ""

    tag_sfx = f" [{tag}]" if tag else ""
    console.write(f"    [cli] agentic mode -> {model}{tag_sfx}, cwd={cwd}, "
                  f"timeout={wall_clock}s{_factor_sfx}"
                  f"{f', turn watchdog at {watchdog_cap}' if watchdog_cap else ''}"
                  f"{f', max_tokens={max_tokens}' if max_tokens else ''}")

    # When streaming the live trace, the callback shows progress, so the heartbeat is suppressed.
    pending_attempt = 0
    # VVAH-E005, same as prompt()
    trunc_retried = 0
    env = _env._call_env(max_tokens=max_tokens, effort=effort)
    timeout_retried = False
    # Once the stage has released the pin, a late trunc/pending retry must never re-create it.
    pin_released = False
    while True:
        # A FRESH uuid every attempt; a retry inside _run_with_retry may rotate it again in
        # place, so session_id_live below reads back whichever id actually ran.
        cli_session_id = str(uuid.uuid4())
        attempt_cmd = [*cmd, "--session-id", cli_session_id]
        watchdog = (_TurnWatchdog(watchdog_cap, by_message=by_message)
                    if watchdog_cap else None)

        if session_id and not pin_released:
            # Keyed by the stage session id; cmd is the live list, so a mid-retry rotation
            # of the --session-id value is visible to a concurrent resume with no second write.
            with _PINNED_CLI_LOCK:
                _PINNED_CLI[session_id] = _CliPin(
                    cmd=attempt_cmd, model=model, cwd=cwd, env=env,
                    json_schema=json_schema, tier=tier, exited=threading.Event())

        _attempt_start = time.monotonic()
        timed_out: subprocess.TimeoutExpired | None = None
        try:
            result = _retry._run_with_retry(
                attempt_cmd,
                label=f"agentic({model}){tag_sfx}",
                input=user_prompt,
                cwd=cwd,
                timeout=wall_clock,
                timeout_retries=0,
                env=env,
                heartbeat_label=(None if (stream_cb or watchdog)
                                 else f"agentic mode ({model}){tag_sfx}"),
                stream_cb=stream_cb,
                should_stop=watchdog,
            )
        except subprocess.TimeoutExpired as e:
            timed_out = e
        finally:
            # Only on an entry that still exists: a stage that already released the pin
            # (resume_or_replay's finally) must never have it re-created here.
            if session_id:
                with _PINNED_CLI_LOCK:
                    pin = _PINNED_CLI.get(session_id)
                if pin is None:
                    pin_released = True
                else:
                    pin.exited.set()
        session_id_live = attempt_cmd[attempt_cmd.index("--session-id") + 1]
        if timed_out is not None:
            if session_id:
                # With a stage session id, the stage owns the resume: no in-route salvage
                # and no second attempt here, so two processes never write one transcript.
                raise call_timeout_error(
                    stage=tag or "", route="cli", budget_s=wall_clock, effort=tier,
                    cause_text=f"claude subprocess exceeded {wall_clock}s") from timed_out
            # Without a stage session id: _run_with_retry's own retry is off here
            # (timeout_retries=0), so try the cheap resume salvage before paying for a second
            # full session. Outside the except block: a refusal with TimeoutExpired as
            # __context__ would read as a timeout to is_timeout_failure.
            salvaged = _recover_timed_out_session(
                session_id=session_id_live, model=model, cwd=cwd,
                wall_clock=wall_clock, tag=tag, env=env, json_schema=json_schema)
            if salvaged is not None:
                return _retry._accept_reply(salvaged, trunc_retried=trunc_retried)
            if not timeout_retried:
                timeout_retried = True
                continue
            raise call_timeout_error(
                stage=tag or "", route="cli", budget_s=wall_clock, effort=tier,
                cause_text=f"claude subprocess exceeded {wall_clock}s") from timed_out
        note_budget_use(time.monotonic() - _attempt_start, wall_clock, tier)

        # BEFORE the returncode check: the watchdog's kill is a deliberate cap, not a failure
        if watchdog is not None and _process._was_stopped(result):
            console.write(f"    [cli] turn limit reached ({watchdog.describe()}){tag_sfx} — "
                          f"asking the session for a final answer")
            COUNTERS.bump("cli_turn_watchdog_stops")
            # This resume is a SECOND process on session_id_live; re-clear exited for its
            # own duration, so a concurrent stage resume cannot start a third one on it.
            if session_id:
                with _PINNED_CLI_LOCK:
                    pin = _PINNED_CLI.get(session_id)
                if pin is not None:
                    pin.exited.clear()
            try:
                final = _finalize_via_resume(session_id_live, model=model, cwd=cwd,
                                             timeout=min(300, wall_clock), tag=tag,
                                             env=env, json_schema=json_schema)
            finally:
                if session_id:
                    with _PINNED_CLI_LOCK:
                        pin = _PINNED_CLI.get(session_id)
                    if pin is not None:
                        pin.exited.set()
            if final:
                return _retry._accept_reply(final, trunc_retried=trunc_retried)
            # Resume failed (a kill mid-write orphans the tail): fall back to streamed text
            streamed = _envelope._parse_envelope(result.stdout).text
            log.warning(Event.CLI_RESUME_FAILED)
            return _retry._accept_reply(streamed, trunc_retried=trunc_retried)

        if result.returncode != 0:
            _envelope._raise_if_refused_exit(result.stdout, tag=tag)
            cap = _retry._truncation_cap(result)
            if cap is None:
                raise RuntimeError(
                    _discovery._format_cli_error("claude CLI agentic failed", attempt_cmd,
                                      result))
            requested = trunc_retried or max_tokens or cap
            retry_at = (None if trunc_retried else
                        truncation_retry_max(requested, cap=MODEL_MAX_OUTPUT_TOKENS))
            if retry_at is not None:
                _retry._log_truncation_retry(tag=tag, requested=requested, retry_at=retry_at,
                                      label="cli")
                env = dict(env or {})
                env["CLAUDE_CODE_MAX_OUTPUT_TOKENS"] = str(retry_at)
                trunc_retried = retry_at
                continue
            raise _retry._truncation_error(requested=requested, retried=trunc_retried,
                                    tag=tag, retry_at=retry_at)

        # No stitching here, deliberately: it would concatenate the whole transcript into `result`
        stdout = result.stdout
        text, usage, turns, usd, stop_reason, model_usage = _envelope._parse_envelope(stdout)
        _envelope._note_unparsed_cache_keys(usage)
        TOKENS.add(usage, usd=usd, turns=turns)
        _retry._log_usage(usage, stop_reason=stop_reason, model_usage=model_usage)
        _envelope._raise_if_refused(stop_reason, tag=tag, stdout=stdout)

        if not _retry._is_pending_result(text):
            # Counted here, not at the parse: a pending-output resend keeps trunc_retried set
            return _retry._accept_reply(text, trunc_retried=trunc_retried)

        pending_attempt += 1
        snippet = redact((text or "").strip().replace("\n", " "))[:200]
        if pending_attempt > _retry._PENDING_MAX_RETRIES:
            raise RuntimeError(
                "claude CLI agentic returned an unfinished background-subagent "
                f"state after {_retry._PENDING_MAX_RETRIES} retries; refusing to "
                f"continue with partial output. last_result={snippet!r}"
            )
        wait = _retry._PENDING_BACKOFF[min(pending_attempt - 1,
                                    len(_retry._PENDING_BACKOFF) - 1)]
        console.write(
            f"    [cli] agentic returned pending output; retrying in {wait}s "
            f"({pending_attempt}/{_retry._PENDING_MAX_RETRIES})"
        )
        slept = 0
        while slept < wait:
            if _cancel._ABORT.is_set():
                raise RuntimeError("aborted by user (Ctrl-C)")
            step = min(5, wait - slept)
            time.sleep(step)
            slept += step
