# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""The state DB's SQL: the full schema, and the two migrations onto it."""
from __future__ import annotations

# auto_vacuum MUST precede the first CREATE TABLE or it is silently ignored; journal_mode=WAL persists once set.
_DDL = """
PRAGMA auto_vacuum  = INCREMENTAL;
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS runs (
  run_id     TEXT PRIMARY KEY,
  repo_root  TEXT NOT NULL,
  repo_name  TEXT,
  app_id     TEXT,
  started_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS checkpoints (
  run_id     TEXT    NOT NULL REFERENCES runs(run_id) ON DELETE CASCADE,
  step       TEXT    NOT NULL,
  payload    BLOB    NOT NULL,
  size       INTEGER NOT NULL CHECK (size <= 104857600),
  created_at TEXT    NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (run_id, step)
);

-- Exploit-verification replay bundles: the confirming exchange for each exploit-verified
-- finding, kept so a later `ev-replay` (a SEPARATE invocation, after the fix is
-- deployed) can re-send it and re-decide. Deliberately NOT a `checkpoints` row: unlike
-- resume state, these must SURVIVE a fresh rescan's reset_run() so replay works after a
-- remediate+rescan cycle. They are still reaped by delete_run()/prune (FK cascade).
CREATE TABLE IF NOT EXISTS ev_replays (
  run_id      TEXT    NOT NULL REFERENCES runs(run_id) ON DELETE CASCADE,
  finding_key TEXT    NOT NULL,
  payload     BLOB    NOT NULL,
  size        INTEGER NOT NULL CHECK (size <= 1048576),
  created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (run_id, finding_key)
);

-- Exploit-verification probe log: EVERY payload EV sent this run (confirmed or not),
-- one row per request, tagged with the finding it came from and the endpoint it hit.
-- Distinct from ev_replays (which keeps only the single CONFIRMING exchange per verified
-- finding): this is the broad corpus for replay/analysis, written only when the profile
-- opts in (step6_exploit_verification.store_probes). The caller redacts credential
-- material (JWTs and credential-named values) from the request/response fields before
-- insert; auth_applied holds channel NAMES only, never a token.
CREATE TABLE IF NOT EXISTS ev_probes (
  id              INTEGER PRIMARY KEY,
  run_id          TEXT    NOT NULL REFERENCES runs(run_id) ON DELETE CASCADE,
  finding_key     TEXT    NOT NULL,
  finding_title   TEXT,
  file            TEXT,
  line_start      INTEGER,
  line_end        INTEGER,
  cwe             TEXT,
  vuln_class      TEXT,
  ev_class        TEXT,
  ev_subtype      TEXT,
  ev_verdict      TEXT,
  endpoint_method TEXT,
  endpoint_path   TEXT,
  payload_label   TEXT,
  injection_point TEXT,
  req_method      TEXT,
  req_url         TEXT,
  req_query       TEXT,
  req_body        TEXT,
  authed          INTEGER,
  auth_applied    TEXT,
  resp_status     INTEGER,
  resp_ms         INTEGER,
  resp_snippet    TEXT,
  created_at      TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_ev_probes_run ON ev_probes(run_id);
CREATE INDEX IF NOT EXISTS ix_ev_probes_finding ON ev_probes(run_id, finding_key);

CREATE TABLE IF NOT EXISTS callgraph_snapshots (
    run_id            TEXT    NOT NULL REFERENCES runs(run_id) ON DELETE CASCADE,
    graph_id          TEXT    NOT NULL,
    node_count        INTEGER NOT NULL DEFAULT 0,
    edge_count        INTEGER NOT NULL DEFAULT 0,
    entry_point_count INTEGER NOT NULL DEFAULT 0,
    sink_count        INTEGER NOT NULL DEFAULT 0,
    created_at        TEXT    NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (run_id, graph_id)
);

CREATE TABLE IF NOT EXISTS callgraph_nodes (
    run_id                 TEXT    NOT NULL,
    graph_id               TEXT    NOT NULL,
    qnode                  TEXT    NOT NULL,
    file_path              TEXT    NOT NULL DEFAULT '',
    function_name          TEXT    NOT NULL DEFAULT '',
    start_line             INTEGER NOT NULL DEFAULT 0,
    end_line               INTEGER NOT NULL DEFAULT 0,
    is_entry_point         INTEGER NOT NULL DEFAULT 0,
    entry_kind             TEXT    NOT NULL DEFAULT '',
    reachable_from_unauth  INTEGER NOT NULL DEFAULT 0,
    is_sink                INTEGER NOT NULL DEFAULT 0,
    sink_line              INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (run_id, graph_id, qnode),
    FOREIGN KEY (run_id, graph_id)
        REFERENCES callgraph_snapshots(run_id, graph_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS callgraph_edges (
    run_id        TEXT NOT NULL,
    graph_id      TEXT NOT NULL,
    caller_qnode  TEXT NOT NULL,
    callee_qnode  TEXT NOT NULL,
    PRIMARY KEY (run_id, graph_id, caller_qnode, callee_qnode),
    FOREIGN KEY (run_id, graph_id)
        REFERENCES callgraph_snapshots(run_id, graph_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS callgraph_stage_refs (
    run_id      TEXT NOT NULL REFERENCES runs(run_id) ON DELETE CASCADE,
    step        TEXT NOT NULL,
    graph_id    TEXT NOT NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (run_id, step),
    FOREIGN KEY (run_id, graph_id)
        REFERENCES callgraph_snapshots(run_id, graph_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS ix_runs_updated ON runs(updated_at);
CREATE INDEX IF NOT EXISTS ix_callgraph_stage_refs_graph
    ON callgraph_stage_refs(run_id, graph_id);
CREATE INDEX IF NOT EXISTS ix_callgraph_nodes_file
    ON callgraph_nodes(run_id, file_path, function_name);
CREATE INDEX IF NOT EXISTS ix_callgraph_edges_caller
    ON callgraph_edges(run_id, caller_qnode);
CREATE INDEX IF NOT EXISTS ix_callgraph_edges_callee
    ON callgraph_edges(run_id, callee_qnode);
"""

_DDL_V2 = """
CREATE TABLE IF NOT EXISTS callgraph_snapshots (
    run_id            TEXT    NOT NULL REFERENCES runs(run_id) ON DELETE CASCADE,
    graph_id          TEXT    NOT NULL,
    node_count        INTEGER NOT NULL DEFAULT 0,
    edge_count        INTEGER NOT NULL DEFAULT 0,
    entry_point_count INTEGER NOT NULL DEFAULT 0,
    sink_count        INTEGER NOT NULL DEFAULT 0,
    created_at        TEXT    NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (run_id, graph_id)
);

CREATE TABLE IF NOT EXISTS callgraph_nodes (
    run_id                 TEXT    NOT NULL,
    graph_id               TEXT    NOT NULL,
    qnode                  TEXT    NOT NULL,
    file_path              TEXT    NOT NULL DEFAULT '',
    function_name          TEXT    NOT NULL DEFAULT '',
    start_line             INTEGER NOT NULL DEFAULT 0,
    end_line               INTEGER NOT NULL DEFAULT 0,
    is_entry_point         INTEGER NOT NULL DEFAULT 0,
    entry_kind             TEXT    NOT NULL DEFAULT '',
    reachable_from_unauth  INTEGER NOT NULL DEFAULT 0,
    is_sink                INTEGER NOT NULL DEFAULT 0,
    sink_line              INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (run_id, graph_id, qnode),
    FOREIGN KEY (run_id, graph_id)
        REFERENCES callgraph_snapshots(run_id, graph_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS callgraph_edges (
    run_id        TEXT NOT NULL,
    graph_id      TEXT NOT NULL,
    caller_qnode  TEXT NOT NULL,
    callee_qnode  TEXT NOT NULL,
    PRIMARY KEY (run_id, graph_id, caller_qnode, callee_qnode),
    FOREIGN KEY (run_id, graph_id)
        REFERENCES callgraph_snapshots(run_id, graph_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS callgraph_stage_refs (
    run_id      TEXT NOT NULL REFERENCES runs(run_id) ON DELETE CASCADE,
    step        TEXT NOT NULL,
    graph_id    TEXT NOT NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    PRIMARY KEY (run_id, step),
    FOREIGN KEY (run_id, graph_id)
        REFERENCES callgraph_snapshots(run_id, graph_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS ix_callgraph_stage_refs_graph
    ON callgraph_stage_refs(run_id, graph_id);
CREATE INDEX IF NOT EXISTS ix_callgraph_nodes_file
    ON callgraph_nodes(run_id, file_path, function_name);
CREATE INDEX IF NOT EXISTS ix_callgraph_edges_caller
    ON callgraph_edges(run_id, caller_qnode);
CREATE INDEX IF NOT EXISTS ix_callgraph_edges_callee
    ON callgraph_edges(run_id, callee_qnode);
"""

# v2->v3: adds ev_replays + ev_probes; idempotent; one migration, not two, as neither has shipped
_DDL_V3 = """
CREATE TABLE IF NOT EXISTS ev_replays (
  run_id      TEXT    NOT NULL REFERENCES runs(run_id) ON DELETE CASCADE,
  finding_key TEXT    NOT NULL,
  payload     BLOB    NOT NULL,
  size        INTEGER NOT NULL CHECK (size <= 1048576),
  created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
  PRIMARY KEY (run_id, finding_key)
);
    
CREATE TABLE IF NOT EXISTS ev_probes (
  id              INTEGER PRIMARY KEY,
  run_id          TEXT    NOT NULL REFERENCES runs(run_id) ON DELETE CASCADE,
  finding_key     TEXT    NOT NULL,
  finding_title   TEXT,
  file            TEXT,
  line_start      INTEGER,
  line_end        INTEGER,
  cwe             TEXT,
  vuln_class      TEXT,
  ev_class        TEXT,
  ev_subtype      TEXT,
  ev_verdict      TEXT,
  endpoint_method TEXT,
  endpoint_path   TEXT,
  payload_label   TEXT,
  injection_point TEXT,
  req_method      TEXT,
  req_url         TEXT,
  req_query       TEXT,
  req_body        TEXT,
  authed          INTEGER,
  auth_applied    TEXT,
  resp_status     INTEGER,
  resp_ms         INTEGER,
  resp_snippet    TEXT,
  created_at      TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_ev_probes_run ON ev_probes(run_id);
CREATE INDEX IF NOT EXISTS ix_ev_probes_finding ON ev_probes(run_id, finding_key);
"""
