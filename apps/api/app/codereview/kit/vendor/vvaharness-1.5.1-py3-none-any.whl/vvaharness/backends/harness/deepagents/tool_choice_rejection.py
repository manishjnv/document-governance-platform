# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Anthropic models that reject a forced tool_choice with a 400: classified, learned, seeded.

Free of ``options.*`` imports, so ForceVerdictOnly (which options/streaming.py imports) can
use it as well as the client.
"""

from __future__ import annotations

import json

from vvaharness.util.counters import COUNTERS
from vvaharness.util.exceptions import exception_chain
from vvaharness.util.warn_once import warn_once

_HTTP_BAD_REQUEST = 400

#: Marker for the API rejecting a forced tool_choice outright, unlike forcing.py's client-side drop.
_MARKERS = ("tool_choice", "not supported for this model")

#: Known rejecters, seeded so neither S10 nor S11 pays for the first failed call.
KNOWN_UNSUPPORTED: frozenset[str] = frozenset({"claude-opus-5-5"})

#: Learned at runtime (process-wide), seeded with KNOWN_UNSUPPORTED.
UNSUPPORTED_MODELS: set[str] = set(KNOWN_UNSUPPORTED)

_WARNED: set[str] = set()


def is_tool_choice_unsupported_rejection(exc: BaseException) -> bool:
    """Whether *exc* is the API rejecting a forced tool_choice outright for this model."""
    for link in exception_chain(exc):
        status = getattr(link, "status_code", None)
        body = str(getattr(link, "message", link)).lower()
        if status == _HTTP_BAD_REQUEST and all(m in body for m in _MARKERS):
            return True
    stderr = str(getattr(exc, "stderr", "") or "").lower()
    return "400" in stderr and all(m in stderr for m in _MARKERS)


def rejected_model(exc: BaseException) -> str | None:
    """The ``model`` of the request *exc* rejected, when the SDK error still carries it."""
    # anthropic's APIStatusError keeps the httpx request; its JSON body names the model sent
    for link in exception_chain(exc):
        body = getattr(getattr(link, "request", None), "content", None)
        if not isinstance(body, (bytes, str)) or not body:
            continue
        try:
            model = json.loads(body).get("model")
        except (ValueError, AttributeError):
            continue
        if isinstance(model, str) and model:
            return model
    return None


def learn_tool_choice_unsupported(*model_ids: str) -> None:
    """Record each of *model_ids* as rejecting forced tool_choice, count it, and warn once."""
    for model_id in model_ids:
        UNSUPPORTED_MODELS.add(model_id)
        COUNTERS.bump("deepagents_tool_choice_unsupported_fallback")
        warn_once(
            _WARNED,
            model_id,
            f"WARN [deepagents]: model '{model_id}' rejected a forced tool_choice "
            f"(\"tool\"/\"any\") outright — retrying without forcing",
        )
