# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared contract for the prompt/agentic backends."""

# cli/sdk/openai/agent_sdk implement both; the deepagents adapter has prompt() but NOT agentic()

from __future__ import annotations

import random
import re
import threading
import time
from collections.abc import Mapping, Sequence
from enum import StrEnum
from math import ceil
from typing import Any, Final, NamedTuple, NewType, Protocol, TypedDict, runtime_checkable

from vvaharness.backends.harness.models import CallTimeoutError, EffortLevel, ProxyError
from vvaharness.backends.harness.provider_routing import (
    TRANSPORT_CHAT_COMPLETIONS,
    TRANSPORT_RESPONSES,
)
from vvaharness.report.redact import redact
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.exceptions import exception_chain
from vvaharness.util.tokens import TokenUsage

#: A backend module's import path, e.g. ``"vvaharness.backends.llm.cli"``.
ModulePath = NewType("ModulePath", str)

#: Statuses worth retrying on every route that owns its HTTP transport (all but `cli`).
RETRYABLE_STATUS: Final[frozenset[int]] = frozenset({429, 500, 502, 503, 504, 529})

#: Narrower for `cli`: the binary already retried 500/504. See test_run_with_retry_500_not_retried.
CLI_RETRYABLE_STATUS: Final[frozenset[int]] = RETRYABLE_STATUS - {500, 504}

#: The server-error probe's own gate: 5xx only. 429 is a rate limit, not a server fault, and a
#: lower reasoning tier cannot make a rate limit clear — it would just retire a healthy tier.
SERVER_ERROR_STATUS: Final[frozenset[int]] = RETRYABLE_STATUS - {429}

#: 400/422: statuses a gateway rejects a request PARAMETER with; disjoint from retryable (auth is
#: decided by prose, so a dead credential reported under one is still VVAH-E001)
PARAM_REJECTION_STATUS: Final[frozenset[int]] = frozenset({400, 422})


def rejection_text(exc: BaseException) -> str:
    """The rejection body to match parameter names against, minus any echoed request."""
    body = getattr(exc, "body", None)
    detail = body.get("detail") if isinstance(body, dict) else None
    if not isinstance(detail, list):
        return str(getattr(exc, "message", None) or exc)
    # pydantic `input` echoes the whole request: drop only that key; dot `loc` to match API spelling
    parts: list[str] = []
    for entry in detail:
        if isinstance(entry, dict):
            entry = {k: v for k, v in entry.items() if k != "input"}
            if isinstance(entry.get("loc"), list):
                entry["loc"] = ".".join(map(str, entry["loc"]))
        parts.append(str(entry))
    return "; ".join(parts)


def is_param_rejection(exc: BaseException, *names: str) -> bool:
    """Whether a cause-chain link is a PARAM_REJECTION_STATUS whose body names one of *names*."""
    for link in exception_chain(exc):
        if getattr(link, "status_code", None) in PARAM_REJECTION_STATUS:
            low = rejection_text(link).lower()
            if any(name in low for name in names):
                return True
    return False


#: `invalid_request_error` is Anthropic's documented type; a gateway has been observed to
#: relabel the identical mid-stream rejection `bad_request_error` instead.
PARAM_REJECTION_ERROR_TYPES: Final[frozenset[str]] = frozenset(
    {"invalid_request_error", "bad_request_error"})


def is_gateway_wrapped_param_rejection(exc: BaseException) -> bool:
    """True for a 200-status stream whose body is itself a parameter-rejection error.

    A streamed call can still deliver an error mid-stream after a 200 handshake (an SSE `error`
    event); `exc.type` is the SDK's own parse of that body, so a 200-wrapped transient
    (overloaded/rate-limit) never matches this.
    """
    return (getattr(exc, "status_code", None) == 200
            and getattr(exc, "type", None) in PARAM_REJECTION_ERROR_TYPES)


#: Transient prose inside an HTTP 200; NO bare \b429\b — a "req-429-" id promotes
RATE_LIMIT_TRANSIENT_RX: Final[re.Pattern[str]] = re.compile(
    r"rate.?limit|too many requests|overloaded|temporarily unavailable",
    re.IGNORECASE,
)

#: `cli` only: with no envelope status parsed, the bare number is the only rate-limit signal left
CLI_STATUS_429_RX: Final[re.Pattern[str]] = re.compile(r"\b429\b")

#: Every route but `cli` (its 500/504 carve-out stands); NOT \b50\d\b — that hits "504 tokens"
SERVER_ERROR_TRANSIENT_RX: Final[re.Pattern[str]] = re.compile(
    r"server_error|overloaded|service unavailable"
    r"|internal server error|bad gateway"
    # A gateway rejecting its UPSTREAM reply, sent as HTTP 400; \b keeps ...Request terminal
    r"|validation errors? for ChatCompletion(?:Chunk)?\b", re.I)

#: `cli` only: sdk/openai raise APIConnectionError, so matching this prose there would be dead code
CLI_CONN_TRANSIENT_RX: Final[re.Pattern[str]] = re.compile(
    r"socket connection was closed|connection (?:reset|closed|aborted)"
    r"|ECONNRESET|EPIPE|broken pipe|incomplete(?:ly)? read"
    r"|premature(?:ly)? closed|EOF occurred",
    re.IGNORECASE,
)

#: Tools an agentic call gets when the caller names none. Read-only: `llm.tools` has no shell.
DEFAULT_READ_TOOLS: Final[tuple[str, ...]] = ("Read", "Glob", "Grep")

#: Output cap for one agentic turn.
AGENTIC_MAX_TOKENS: Final = 16_000

#: All four routes, three mechanisms; ONE definition (s2/s4/s6 drifted). GAP: `cli` cannot re-ask
RESPONSE_MODEL_VIAS: Final[frozenset[str]] = frozenset(
    {"deepagents", "sdk", "openai", "cli"})

#: One name so `sdk` and `openai` match; a per-backend spelling breaks the other's extractor
RESPONSE_MODEL_TOOL_NAME: Final = "emit_structured_response"

#: Repair re-asks per turn; shared by sdk/openai so one bad submit cannot eat the turn budget
STRUCTURED_REASK_MAX: Final = 2

#: CLI-published for json_schema output; cli_mcp's gate must allow it — never in allowed_tools
CLI_STRUCTURED_OUTPUT_TOOL: Final = "StructuredOutput"


def response_model_tool(response_model: type) -> dict:
    """The Anthropic-shape tool that carries *response_model* as its input schema."""
    schema = response_model.model_json_schema()
    schema.pop("title", None)
    return {
        "name": RESPONSE_MODEL_TOOL_NAME,
        "description": f"Submit the final {response_model.__name__}.",
        "input_schema": schema,
    }


#: The once-only in-loop re-ask both raw loops (sdk, openai) send when a structured reply came
#: back as prose
STRUCTURED_PROSE_REASK: Final = (
    f"Call the `{RESPONSE_MODEL_TOOL_NAME}` tool now with your findings as its arguments. "
    "Do not reply with prose; the result is only accepted through that tool.")


def with_submit_instruction(system_prompt: str | None, response_model: type, *,
                            tool_name: str = RESPONSE_MODEL_TOOL_NAME) -> str:
    """*system_prompt* plus the line naming the structured tool as the only accepted reply."""
    # For requests that cannot FORCE the tool: a model memoised as rejecting it or manual thinking
    # (sdk, tool_name defaults to RESPONSE_MODEL_TOOL_NAME), or a deepagents graph whose client
    # drops the forcing under thinking (langchain-anthropic's ToolStrategy names its own tool
    # after the response_model class, so that caller passes it explicitly).
    line = (f"When you have your final {response_model.__name__}, call the "
            f"`{tool_name}` tool with it; a plain-text reply is not accepted.")
    return f"{system_prompt}\n\n{line}" if system_prompt else line


#: Raises VVAH-E004 BEFORE dispatch, not after paying for it; no config surface by design
DEEPAGENTS_MAX_PROMPT_TOKENS: Final = 150_000

#: Truncation-retry factor (VVAH-E005): a dimensionless ratio, never an endpoint token ceiling.
TRUNCATION_RETRY_MULTIPLIER: Final = 2

#: COUNTERS key for confirmed truncations (VVAH-E005), shared by the sdk/openai backends.
TRUNCATED_REPLIES_COUNTER: Final = "llm_truncated_replies"

#: Stopped below HALF the budget (gateway cap/hidden reasoning); distinct from TRUNCATED_REPLIES
LLM_TRUNCATED_BELOW_BUDGET_COUNTER: Final = "llm_truncated_below_budget"

#: The one doubled-budget resend per route, and those whose reply came back un-clipped.
TRUNCATED_RETRY_ATTEMPTED_COUNTER: Final = "llm_truncated_retry_attempted"
TRUNCATED_RETRY_RECOVERED_COUNTER: Final = "llm_truncated_retry_recovered"

#: OpenAI ``finish_reason`` value marking an output-budget cutoff.
OPENAI_FINISH_LENGTH: Final = "length"

#: Anthropic ``stop_reason`` value marking an output-budget cutoff.
ANTHROPIC_STOP_MAX_TOKENS: Final = "max_tokens"

#: Anthropic ``stop_reason`` on 4.5+ models when generation reaches the context window (not a 400).
ANTHROPIC_STOP_CONTEXT_WINDOW: Final = "model_context_window_exceeded"

#: Anthropic ``stop_reason`` value for a refused reply: not prose a re-ask can turn into a submit.
ANTHROPIC_STOP_REFUSAL: Final = "refusal"

#: OpenAI Responses cutoff: no ``finish_reason`` at all; the signal is ``incomplete_details.reason``
RESPONSES_INCOMPLETE_MAX_OUTPUT: Final = "max_output_tokens"

_TRUNCATED_FINISHES: Final = frozenset({
    ANTHROPIC_STOP_MAX_TOKENS, ANTHROPIC_STOP_CONTEXT_WINDOW, OPENAI_FINISH_LENGTH,
    RESPONSES_INCOMPLETE_MAX_OUTPUT})


def reply_finish(meta: Mapping[str, Any]) -> str | None:
    """The end-of-reply marker in a reply's response metadata, whichever provider shape it uses."""
    details = meta.get("incomplete_details")
    return (meta.get("stop_reason") or meta.get("finish_reason")
            or (details.get("reason") if isinstance(details, Mapping) else None))


def finish_truncated(finish: object | None) -> bool:
    """Whether *finish* (see :func:`reply_finish`) marks an output-budget cutoff on any route."""
    # isinstance first: neither SDK validates this field, and a dict/list is unhashable
    return isinstance(finish, str) and finish in _TRUNCATED_FINISHES

#: Prose because the CLI reports `api_error_status: null` + `stop_reason: stop_sequence` here
CLI_TOKEN_CAP_RX: Final[re.Pattern[str]] = re.compile(
    r"exceeded the (\d+) output token maximum", re.IGNORECASE)

#: CLI split the reply across turns; unlike TRUNCATED_REPLIES nothing was lost, budget was small
CLI_CONTINUED_REPLIES_COUNTER: Final = "cli_continued_replies"


def truncation_retry_max(requested: int, cap: int | None = None) -> int | None:
    """Output budget for the one truncation retry; None when a request at *cap* makes it useless."""
    if cap is not None and requested >= cap:
        return None
    doubled = requested * TRUNCATION_RETRY_MULTIPLIER
    return doubled if cap is None else min(doubled, cap)


#: Wide enough to break lockstep in a parallel batch, narrow enough to honour `retry-after`
RETRY_JITTER_SPREAD: Final = 0.2


def jittered_delay(seconds: float, *, spread: float = RETRY_JITTER_SPREAD,
                    rng: random.Random | None = None) -> float:
    """*seconds* scaled by a uniform random factor in ``[1 - spread, 1 + spread]``."""
    # Without jitter S4/S6 pool workers wake together and recreate the burst; centred on 1.0
    r = rng if rng is not None else random
    factor = 1.0 + r.uniform(-spread, spread)
    return max(0.0, seconds * factor)


class ClockKind(StrEnum):
    """Which duration a timeout bounds: one request, or a whole agentic session/batch."""

    REQUEST = "request"
    SESSION = "session"


#: Per-tier multiplier on a ceiling sized for `high`; REQUEST is output-cap-bounded so grows less
#: than SESSION, where effort raises both turn count and per-turn time with no product cap.
EFFORT_TIME_FACTOR: Final[dict[ClockKind, dict[EffortLevel, float]]] = {
    ClockKind.REQUEST: {
        EffortLevel.LOW: 1.0, EffortLevel.MEDIUM: 1.0, EffortLevel.HIGH: 1.0,
        EffortLevel.XHIGH: 1.1, EffortLevel.MAX: 1.2,
    },
    ClockKind.SESSION: {
        EffortLevel.LOW: 1.0, EffortLevel.MEDIUM: 1.0, EffortLevel.HIGH: 1.0,
        EffortLevel.XHIGH: 1.1, EffortLevel.MAX: 1.5,
    },
}


def effort_scaled_seconds(seconds: int | float | None, effort: str | None, *,
                          kind: ClockKind) -> int | float | None:
    """*seconds* scaled by EFFORT_TIME_FACTOR[kind]; unchanged when disabled or unscalable."""
    # `kind` is keyword-only and required so no seam can silently pick the wrong table.
    if seconds is None or seconds <= 0:
        return seconds
    tier = EffortLevel.parse(effort)
    if tier is None:
        return seconds
    scaled = seconds * EFFORT_TIME_FACTOR[kind][tier]
    return ceil(scaled) if isinstance(seconds, int) else scaled


#: Per-HTTP-request hang-stop sdk.py/openai.py use when no stage timeout was threaded.
DEFAULT_REQUEST_TIMEOUT_SECONDS: Final = 900

#: How long a graceful stop (SIGINT / `interrupt()`) may run before the hard kill.
TIMEOUT_STOP_GRACE_SECONDS: Final = 20

#: A timed-out call is re-sent at most this many times by the harness.
TIMEOUT_MAX_RETRIES: Final = 1

#: Fraction of budget_s at/above which a COMPLETED xhigh/max call counts as "near the ceiling".
BUDGET_NEAR_RATIO: Final = 0.75

#: COUNTERS key bumped once per CallTimeoutError, only from call_timeout_error -- never drifts.
LLM_CALL_TIMEOUTS_COUNTER: Final = "llm_call_timeouts"

#: COUNTERS key: a completed xhigh/max call ran close to its budget (EFFORT_TIME_FACTOR evidence).
LLM_CALL_BUDGET_NEAR_COUNTER: Final = "llm_call_budget_near"

#: Tiers worth the healthy-call telemetry: low/medium/high never raise a ceiling above `high`.
_BUDGET_NEAR_TIERS: Final[frozenset[EffortLevel]] = frozenset({EffortLevel.XHIGH, EffortLevel.MAX})


#: A proxy/TLS root cause: misconfiguration that no retry can heal (VVAH-E002). CONNECT is the
#: case-sensitive proxy method: a plain-HTTP "All connection attempts failed" must stay retryable.
PROXY_CAUSE_RX: Final = re.compile(
    r"\b407\b|proxy[_ ]auth|tunnel[_ ](?:connection[_ ])?(?:failed|error)|(?-i:\bCONNECT\b).*failed"
    r"|SSL.*CERTIFICATE|CERTIFICATE.*VERIFY.*FAILED|CERT_VERIFY_FAILED"
    r"|certificate[_ ]verify[_ ]failed",
    re.IGNORECASE,
)


def cause_chain(e: BaseException) -> str:
    """Flatten an exception's __cause__ chain, where a proxy/TLS root cause actually surfaces."""
    return " <- ".join(f"{type(c).__name__}: {c}" for c in exception_chain(e)[1:])


def proxy_detail(e: BaseException) -> str | None:
    """The cause detail when *e* carries a proxy/TLS signature, else None."""
    detail = cause_chain(e)
    if PROXY_CAUSE_RX.search(detail) or PROXY_CAUSE_RX.search(str(e)):
        return detail or str(e)
    return None


def proxy_error(e: BaseException, *, backend: str) -> ProxyError | None:
    """The VVAH-E002 failure when *e* carries a proxy/TLS signature, else None."""
    detail = proxy_detail(e)
    if detail is None:
        return None
    return ProxyError(redact(detail)[:400],
                      status_code=407 if re.search(r"\b407\b", detail) else None, backend=backend)


def call_timeout_error(*, stage: str, route: str, budget_s: float | None, effort: str | None,
                       cause_text: str) -> CallTimeoutError:
    """Build the typed VVAH-E008 failure and bump its counter; callers do `raise ... from exc`."""
    COUNTERS.bump(LLM_CALL_TIMEOUTS_COUNTER)
    return CallTimeoutError(cause_text, stage=stage, route=route, budget_s=budget_s, effort=effort)


def note_budget_use(elapsed: float, budget_s: float | None, effort: str | None) -> None:
    """Bump the near-budget counter for a COMPLETED xhigh/max call that used most of its budget."""
    if not budget_s or budget_s <= 0:
        return
    if EffortLevel.parse(effort) not in _BUDGET_NEAR_TIERS:
        return
    if elapsed >= BUDGET_NEAR_RATIO * budget_s:
        COUNTERS.bump(LLM_CALL_BUDGET_NEAR_COUNTER)


def _named_tools(tools: Sequence[str] | None, *, config_key: str) -> list[str]:
    """Normalise a configured allowlist, rejecting the YAML shapes that misbehave downstream."""
    # Bare scalar iterates per char; `[]` omits --allowedTools (broader default); None falls back
    if tools is None:
        return list(DEFAULT_READ_TOOLS)
    if isinstance(tools, str):
        # ValueError, not TypeError: one catchable type for every bad profile value
        raise ValueError(  # noqa: TRY004 — deliberate single config-error type
            f"{config_key} must be a YAML list of tool names, got the bare "
            f"string {tools!r} — write it as `allowed_tools: [{tools}]`")
    named = list(tools)
    if not named:
        raise ValueError(
            f"{config_key} is an empty list, which would silently grant a "
            f"default toolset instead of none — name the tools explicitly, "
            f"or remove the key to get {sorted(DEFAULT_READ_TOOLS)}")
    if any(not isinstance(t, str) for t in named):
        raise ValueError(
            f"{config_key} must contain only strings, got "
            f"{[t for t in named if not isinstance(t, str)]!r}")
    return named


def validate_detection_tools(
    tools: Sequence[str] | None, *, config_key: str, via: str | None = None,
) -> list[str]:
    """Validate a detection stage's agentic tool allowlist for the backend it targets."""
    # TRAP: a mutating tool on `via: sdk` delegates to the Agent SDK, which can write the repo
    named = _named_tools(tools, config_key=config_key)
    if via == "cli":  # the only via whose agentic() honours the allowlist itself
        return named
    bad = sorted(t for t in named if t not in DEFAULT_READ_TOOLS)
    if bad:
        raise ValueError(
            f"{config_key} contains disallowed tool(s) {bad}: this is a "
            f"detection stage and only read-only tools "
            f"{sorted(DEFAULT_READ_TOOLS)} are permitted on "
            f"`via: {via or 'sdk/openai'}` (on `via: sdk` an unsupported or "
            f"mutating tool delegates to the Agent SDK backend, which could "
            f"modify the scanned repository; only `via: cli` honours a wider "
            f"allowlist itself)")
    return named


class ModelExtras(TypedDict, total=False):
    """Optional per-model tunables a profile may set; only `sdk` reads all three."""

    temperature: float
    thinking_budget: int
    betas: list[str]


class ResolvedModel(NamedTuple):
    """What a profile's model node resolves to. A tuple, so existing unpacking still works."""

    model_id: str
    via: str
    extras: ModelExtras


class EnvelopeResult(NamedTuple):
    """One `claude -p` JSON envelope; *turns*/*usd* are None, not zero, when absent."""
    # CLI summary fields, not the wire response; append new fields WITH defaults (2-/4-tuple uses)

    text: str
    usage: TokenUsage | None
    turns: int | None = None
    usd: float | None = None
    stop_reason: str | None = None
    #: The CLI's per-model spend block — the only per-request model echo outside the subprocess
    model_usage: dict | None = None


#: Tri-state by design: True verifies, False disables, a str is a CA-bundle path.
VerifySsl = bool | str


class CliConfig(TypedDict):
    """Gateway settings `cli.configure()` stores for the subprocess env."""

    verify_ssl: VerifySsl
    ca_cert: str | None
    client_cert: str | tuple[str, str] | None
    no_proxy: str | None
    effort: str
    #: `--restricted` is this route's only read jail; False only for apiKeyHelper gateway auth
    restricted: bool


class SdkConfig(TypedDict):
    """Gateway settings `sdk.configure()` stores for the Anthropic client."""

    api_key: str | None
    base_url: str | None
    verify_ssl: VerifySsl
    ca_cert: str | None
    client_cert: str | tuple[str, str] | None
    no_proxy: str | None
    allow_api_key_fallback: bool
    # `str | bool` because PyYAML makes unquoted `off` False; cache_route normalised by configure()
    cache_min_block_tokens: int | None
    cache_route: str
    cache_markers: str | bool


class OpenAiConfig(TypedDict):
    """Gateway settings `openai.configure()` stores for the OpenAI client."""

    api_key: str | None
    base_url: str | None
    verify_ssl: VerifySsl
    ca_cert: str | None
    #: `via: openai` ONLY: `via: deepagents` sends no org header — export OPENAI_ORG_ID instead
    organization: str | None
    no_proxy: str | None
    # See SdkConfig.cache_markers for why this is `str | bool`.
    cache_markers: str | bool


class GuardrailBlocked(RuntimeError):
    """A provider guardrail declined the request, so retrying the same prompt cannot help."""


class ModelRefusal(GuardrailBlocked):
    """The model or its provider refused this content (a refusal stop or a policy block)."""

    # Subclassed so every GuardrailBlocked arm still applies; keyword defaults keep copy/pickle.
    def __init__(self, message: str = "", *, route: str = "",
                 category: str | None = None) -> None:
        """*category* is the provider's own refusal label, or None."""
        super().__init__(message)
        self.route = route
        self.category = category


def guardrail_gate_hit(e: GuardrailBlocked, hits: int, gate: int) -> tuple[int, str]:
    """(gate hits after *e*, its GUARDRAIL-BLOCKED log label) for the S4/S6 abort gate."""
    # Only guardrail blocks count: fast refusals of a few units would trip it before any success.
    if isinstance(e, ModelRefusal):
        return hits, "model refusal, not gated"
    return hits + 1, f"{hits + 1}/{gate}"


#: Bumped once per refused call, only from model_refusal.
LLM_MODEL_REFUSALS_COUNTER: Final = "llm_model_refusals"

#: The one identical resend of a refused call, and the resends that got a reply.
REFUSAL_RETRY_ATTEMPTED_COUNTER: Final = "llm_refusal_retry_attempted"
REFUSAL_RETRY_RECOVERED_COUNTER: Final = "llm_refusal_retry_recovered"


def refusal_resend_allowed(cfg: object, model_cfg: object) -> bool:
    """Whether a refused call on *model_cfg* may be re-sent: ``refusal_retries`` on, Anthropic."""
    # Anthropic only: an OpenAI-compatible gateway's cyber filter can revoke the whole org's
    # access, so flagged content is never re-sent there.
    if int(knob(cfg, "refusal_retries", 1)) <= 0:
        return False
    from vvaharness.backends.llm.registry import (  # noqa: PLC0415 — lazy: registry imports us
        provider_of,
        resolve,
    )
    from vvaharness.manifest import _resolved_route  # noqa: PLC0415 — lazy: manifest is a leaf

    model_id, via, _ = resolve(model_cfg)
    return _resolved_route(via, model_id, provider_of(model_cfg)) == "anthropic"


#: An OpenAI-compatible gateway's cyber block: code `cyber_policy` or its prose message.
_CYBER_POLICY_REJECTION_RX: Final[re.Pattern[str]] = re.compile(
    r"\bcyber_policy\b|flagged for possible cybersecurity risk", re.IGNORECASE)

#: The category a _CYBER_POLICY_REJECTION_RX match carries (the body has no category field).
_CYBER_POLICY_CATEGORY: Final = "cyber"


def model_refusal(*, route: str, stage: str, category: str | None,
                  detail: str = "") -> ModelRefusal:
    """Build the typed refusal and bump its counter; callers do `raise ... [from exc]`."""
    COUNTERS.bump(LLM_MODEL_REFUSALS_COUNTER)
    where = f", stage={stage}" if stage else ""
    # redact() BEFORE [:200]: truncating first can bisect a credential past its pattern
    tail = f": {redact(detail)[:200]}" if detail else ""
    return ModelRefusal(
        f"model refused the request (route={route}, category={category or 'unspecified'}"
        f"{where}){tail}", route=route, category=category)


def _get(obj: object, key: str) -> object:
    """*key* off a mapping or an attribute-bearing object; None when absent."""
    return obj.get(key) if isinstance(obj, Mapping) else getattr(obj, key, None)


def refusal_category(meta: Mapping[str, Any]) -> str | None:
    """``stop_details.category`` off a refused message's metadata; None when absent."""
    # stop_details may be a dict or an object.
    category = _get(meta.get("stop_details"), "category")
    return category if isinstance(category, str) else None


def ai_message_refused(message: object) -> tuple[bool, str | None]:
    """``(refused, category)`` for one langchain AIMessage-shaped object; ``(False, None)`` else."""
    # Duck-typed: no langchain import.
    meta = getattr(message, "response_metadata", None)
    if isinstance(meta, Mapping) and meta.get("stop_reason") == ANTHROPIC_STOP_REFUSAL:
        return True, refusal_category(meta)
    return _openai_refused(message), None


def _openai_refused(message: object) -> bool:
    """The two OpenAI refusal shapes, neither of which carries a category."""
    extra = getattr(message, "additional_kwargs", None)
    content = getattr(message, "content", None)
    return bool(
        (isinstance(extra, Mapping) and extra.get("refusal"))
        or (isinstance(content, list) and any(
            isinstance(b, Mapping) and b.get("type") == "refusal" for b in content)))


def _refusal_link(exc: BaseException) -> tuple[BaseException, str | None] | None:
    """``(link, category)`` for the first refusal in *exc*'s cause chain, or None."""
    for link in exception_chain(exc):
        # API error links only: scanned code echoed in an output failure may contain the marker.
        api_link = (getattr(link, "status_code", None) is not None
                    or getattr(link, "body", None) is not None)
        if api_link and _CYBER_POLICY_REJECTION_RX.search(rejection_text(link)):
            return link, _CYBER_POLICY_CATEGORY
        refused, category = ai_message_refused(getattr(link, "ai_message", None))
        if refused:
            return link, category
    return None


def is_model_refusal_rejection(exc: BaseException) -> bool:
    """Whether *exc*'s cause chain carries a provider policy block or a refused AI message."""
    return _refusal_link(exc) is not None


def model_refusal_from(exc: BaseException, *, route: str, stage: str) -> ModelRefusal | None:
    """The typed refusal for an exception :func:`is_model_refusal_rejection` accepts, else None."""
    found = _refusal_link(exc)
    if found is None:
        return None
    link, category = found
    return model_refusal(route=route, stage=stage, category=category,
                         detail=rejection_text(link))


#: Compound token for reasoning_effort / reasoning.effort / reasoning effort / reasoning-effort /
#: reasoningeffort. A bare "reasoning" is phrase-bound below: our own response schema can carry a
#: property named `reasoning` that an endpoint may reject by name for an unrelated reason.
_REASONING_EFFORT_RX: Final[re.Pattern[str]] = re.compile(r"reasoning[\s_.\-]?effort")

#: A gateway can instead reject the Responses container by its bare name ("Unsupported
#: parameter: 'reasoning'"), which the compound regex above cannot see; unmatched, that leaves a
#: stage with no evidence and the scan reports no findings. Quoted, so a schema property named
#: `reasoning` is never swept in by a plain substring.
_REASONING_CONTAINER_MARKERS: Final[tuple[str, ...]] = (
    "unsupported parameter: 'reasoning'", "unknown parameter: 'reasoning'")

#: The parameter itself is rejected outright, with no named value and no value list: the
#: endpoint does not support reasoning effort at all, so stepping down a tier cannot help.
_FIELD_UNSUPPORTED_MARKERS: Final[tuple[str, ...]] = (
    "unknown parameter", "unsupported parameter", "unrecognized request argument")


def _is_effort_rejection_subject(text: str) -> bool:
    """Whether lowercased *text* names reasoning_effort as its subject, not a stray mention."""
    return bool(_REASONING_EFFORT_RX.search(text)
                or any(marker in text for marker in _REASONING_CONTAINER_MARKERS))


def _effort_rejection_text(exc: BaseException) -> str | None:
    """Lowercased text of the first link whose status and subject confirm an effort rejection."""
    for link in exception_chain(exc):
        status = getattr(link, "status_code", None)
        if status not in PARAM_REJECTION_STATUS and not is_gateway_wrapped_param_rejection(link):
            continue
        text = rejection_text(link).lower()
        if _is_effort_rejection_subject(text):
            return text
    return None


#: A specific rejected tier value quoted in the body (for example "'high'" or "'xhigh'").
_TIER_VALUE_RX: Final[re.Pattern[str]] = re.compile(
    r"['\"](?:none|low|medium|high|xhigh|max)['\"]")


def _is_value_list_rejection_text(text: str) -> bool:
    """Whether *text* enumerates a value list, or names an invalid/unsupported value."""
    return bool("supported values" in text or "invalid value" in text
                or "unsupported value" in text)


def _is_tier_rejection_text(text: str) -> bool:
    """Whether *text* names a value list, an invalid/unsupported value, or a quoted tier."""
    return _is_value_list_rejection_text(text) or bool(_TIER_VALUE_RX.search(text))


def _effort_rejection_class(text: str) -> str:
    """Sort an already-confirmed effort-rejection *text* into its class.

    Order matters: a genuine value list, or an invalid/unsupported value, is tested FIRST,
    because the endpoint naming one means it supports reasoning and only rejected this value —
    the ladder applies even when the same body also mentions "tools" in passing (seen when
    tools narrow which values are legal). A bare "tools" mention is tested next: its body also
    contains "not supported", which the field arm below would otherwise swallow as a drop — and
    the dropped request is the one that keeps failing. Only once BOTH of those fail does a
    quoted tier with no value list behind it (the gateway's own suggested value, named without
    enumerating the rest) mean "tier" too. A bare field-rejection phrase with none of those means
    the endpoint rejects the parameter itself, so stepping down cannot help. Anything matching
    none of those is ambiguous and defaults to the tier ladder, never a field-wide drop.
    """
    if _is_value_list_rejection_text(text):
        return "tier"
    if re.search(r"\btools?\b", text):
        return "tools_conflict"
    # A quoted tier with no value list behind it (c) outranks a field marker (d): the gateway
    # named a value, so the parameter itself is not what it rejected.
    is_field = (not _TIER_VALUE_RX.search(text)
                and (any(marker in text for marker in _FIELD_UNSUPPORTED_MARKERS)
                     or "not supported" in text))
    return "field" if is_field else "tier"


def classify_effort_rejection(exc: BaseException) -> str | None:
    """Sort a reasoning_effort rejection into ``"tools_conflict"``, ``"field"`` or ``"tier"``.

    None when *exc* is not a reasoning_effort rejection at all.
    """
    # A refusal never earns a resend: it would re-send the refused content.
    if is_model_refusal_rejection(exc):
        return None
    text = _effort_rejection_text(exc)
    return None if text is None else _effort_rejection_class(text)


def is_reasoning_effort_rejection(exc: BaseException) -> bool:
    """Whether *exc* is a reasoning_effort rejection of any class."""
    return classify_effort_rejection(exc) is not None


#: A rejected tier steps down to the next rung; an off-ladder tier enters below it.
REASONING_EFFORT_LADDER: Final[tuple[str, ...]] = ("max", "high", "low")

_LADDER_NEXT: Final[dict[str, str | None]] = {
    "max": "high", "xhigh": "high", "high": "low", "medium": "low", "none": "low", "low": None,
}


def next_effort_tier(tier: str | None) -> str | None:
    """The next rung below *tier* on REASONING_EFFORT_LADDER; None once the field itself drops."""
    return _LADDER_NEXT.get(tier) if tier is not None else None


#: One shared transport vocabulary for every route: the same VALUES provider_routing's
#: manifest/telemetry names already use, so a transport string produced here, by openai.py, or by
#: the deepagents client always compares equal across the whole codebase. The default transport
#: key for every pre-existing EFFORT_REJECTIONS.tiers caller: unchanged so a bare ``(model, tier)``
#: pair still means "rejected on Chat" the way it always has.
TRANSPORT_CHAT: Final = TRANSPORT_CHAT_COMPLETIONS

#: Full wire vocabulary a gateway's value list may enumerate, ranked low to high. "minimal" and
#: "none" are wire-only: this route never SENDS them from its own configured tiers, but a gateway
#: can still LIST them, and the highest-listed-value rule needs their rank to compare correctly.
_TIER_RANK: Final[dict[str, int]] = {
    tier: rank for rank, tier in
    enumerate(("none", "minimal", "low", "medium", "high", "xhigh", "max"))
}

#: A quoted (or truncated-quoted, e.g. pydantic's "'me...") run of letters inside a rejection body.
_QUOTED_TOKEN_RX: Final[re.Pattern[str]] = re.compile(r"['\"]([a-zA-Z]+)")


def _listed_tiers(text: str) -> list[str]:
    """Known tier names quoted in *text*; a truncated prefix counts only inside a genuine list.

    An exact quoted tier name always counts. A truncated prefix (pydantic's "'me...") counts
    only when *text* itself enumerates a value list or names an invalid value — otherwise an
    unrelated quoted token (a param name, a truncated id) that happens to uniquely prefix a tier
    name would read as a gateway-offered value it never actually listed.
    """
    found = []
    allow_prefix = _is_value_list_rejection_text(text)
    for token in _QUOTED_TOKEN_RX.findall(text.lower()):
        if token in _TIER_RANK:
            found.append(token)
            continue
        if not allow_prefix:
            continue
        prefix_matches = [tier for tier in _TIER_RANK if tier.startswith(token)]
        if len(prefix_matches) == 1:
            found.append(prefix_matches[0])
    return found


def _tiers_key(model: str, tier: str, transport: str) -> tuple:
    """EFFORT_REJECTIONS.tiers key for *tier* on *transport*: 2-tuple for Chat, 3-tuple else."""
    return (model, tier) if transport == TRANSPORT_CHAT else (model, tier, transport)


def step_down(
    model: str, sent: str, exc: BaseException, transport: str = TRANSPORT_CHAT,
) -> str | None:
    """The highest value in *exc*'s list below *sent*, else the next ladder rung.

    Records the rejection (and, when a value is found, the direct step) in EFFORT_REJECTIONS so a
    later call for the same (model, tier, transport) jumps straight there instead of re-deriving
    it. Remembered per *transport*: a tier rejected on Responses must not retire it on Chat.
    'none' never reaches the Responses leg: a gateway that reasons there must stay silenced-off,
    so a listed 'none' is skipped on that transport and the ladder (never 'none') decides instead.
    """
    EFFORT_REJECTIONS.tiers.add(_tiers_key(model, sent, transport))
    text = _effort_rejection_text(exc) or ""
    sent_rank = _TIER_RANK.get(sent, -1)
    listed_below = [t for t in _listed_tiers(text) if _TIER_RANK.get(t, -1) < sent_rank]
    if transport != TRANSPORT_CHAT:
        listed_below = [t for t in listed_below if t != REASONING_OFF]
    nxt = max(listed_below, key=_TIER_RANK.get) if listed_below else next_effort_tier(sent)
    if nxt is not None:
        EFFORT_REJECTIONS.step_to[(model, transport, sent)] = nxt
    return nxt


def effort_after_rejections(
    model: str, tier: str | None, transport: str = TRANSPORT_CHAT,
) -> str | None:
    """*tier* stepped down past every rejection already learned for *model* on *transport*.

    A learned ``step_to`` entry (the highest listed value) is taken directly, in one hop; absent
    one, a plain ``.tiers`` membership falls back to the blunt ladder, exactly as before.
    """
    while tier is not None:
        learned = EFFORT_REJECTIONS.step_to.get((model, transport, tier))
        if learned is not None:
            tier = learned
            continue
        if _tiers_key(model, tier, transport) not in EFFORT_REJECTIONS.tiers:
            break
        tier = next_effort_tier(tier)
    return tier


#: The OpenAI-compatible value that turns reasoning off.
REASONING_OFF: Final = "none"


class _EffortRejections:
    """Process memory of effort rejections, shared by the openai route and the deepagents client."""

    def __init__(self) -> None:
        #: (model, tier) for Chat; (model, tier, transport) for every other transport.
        self.tiers: set[tuple] = set()
        self.field: set[str] = set()
        self.tools_off: set[str] = set()
        #: (model, transport, sent_tier) -> the highest listed value below it (step_down).
        self.step_to: dict[tuple[str, str, str], str] = {}
        #: _tiers_key()-shaped keys already given one extra send after a persistent server
        #: error; a failed probe is never retried, and only a first recovery frees the claim.
        #: Per transport, like .tiers: a probe spent on Responses must not retire the same
        #: tier's Chat-side probe.
        self.server_error_probed: set[tuple] = set()
        #: Probe keys already recovered once at the lower tier; the second recovery learns it.
        self.server_error_recovered: set[tuple] = set()
        #: Guards server_error_probed's check-and-add: s4/s6 run worker threads, so two of them
        #: hitting the same key at once must not both claim the one extra send.
        self._probe_lock = threading.Lock()

    def probe_once(self, key: tuple) -> bool:
        """Atomically claim *key* for one server-error probe; False when already claimed."""
        with self._probe_lock:
            if key in self.server_error_probed:
                return False
            self.server_error_probed.add(key)
            return True

    def recovered_twice(self, key: tuple) -> bool:
        """Record a lower-tier recovery for *key*; True on the second, else free its probe."""
        with self._probe_lock:
            if key in self.server_error_recovered:
                return True
            self.server_error_recovered.add(key)
            self.server_error_probed.discard(key)
            return False

    def clear(self) -> None:
        """Reset every set in place; tests clear through this, never by re-binding the names."""
        self.tiers.clear()
        self.field.clear()
        self.tools_off.clear()
        self.step_to.clear()
        self.server_error_probed.clear()
        self.server_error_recovered.clear()


#: One shared memory for every route: rejected (model, tier) pairs, model-wide field drops,
#: models that need reasoning_effort='none' on tool-carrying calls, and tiers already given one
#: extra send after a persistent server error.
EFFORT_REJECTIONS: Final = _EffortRejections()


class _TransportMemory:
    """Process memory of which transport a model's calls use, shared by openai and deepagents."""

    def __init__(self) -> None:
        #: Models learned Chat-only (a Responses call failed, or it is pinned/measured broken).
        self.chat_only: set[str] = set()
        #: Models that completed at least one Responses API call this process.
        self.responses_proven: set[str] = set()
        #: Models whose gateway rejected the `include` parameter (reasoning restarts each turn).
        self.no_include: set[str] = set()

    def clear(self) -> None:
        """Reset every set in place; tests clear through this, never by re-binding the names."""
        self.chat_only.clear()
        self.responses_proven.clear()
        self.no_include.clear()


#: Shared by the openai route (`backends/llm/openai.py`) and the deepagents client, whose own
#: `_CHAT_COMPLETIONS_ONLY_MODELS` / `_RESPONSES_PROVEN_MODELS` names are kept as aliases of
#: `.chat_only` / `.responses_proven` (same set objects, so every existing `.add`/`in` still works).
TRANSPORT_MEMORY: Final = _TransportMemory()


def turn_timeout(session_t0: float, session_budget: float | None,
                 request_timeout: float) -> float:
    """Per-send timeout bounded by the session clock: never past what the session has left.

    `request_timeout` alone (today's behaviour) when no session budget is set; otherwise the
    smaller of that and the remaining session time, floored at 1.0s so a send already past
    its session deadline still gets one short-lived try instead of a non-positive timeout.
    """
    if session_budget is None:
        return request_timeout
    remaining = session_budget - (time.monotonic() - session_t0)
    return min(request_timeout, max(1.0, remaining))


def turn_options(session_t0: float, session_budget: float | None,
                 request_timeout: float) -> dict:
    """`with_options` kwargs for one send; a clock-clamped send gets no SDK retries."""
    clocked = turn_timeout(session_t0, session_budget, request_timeout)
    options: dict = {"timeout": clocked}
    if session_budget is not None and request_timeout - clocked >= 1.0:
        options["max_retries"] = 0
    return options


def wait_overrun(  # noqa: PLR0913 -- the keywords are call_timeout_error's fields
    wait: float, session_t0: float, session_budget: float | None, *,
    stage: str, route: str, effort: str | None,
) -> CallTimeoutError | None:
    """The VVAH-E008 failure when a retry wait would land past the session clock, else None."""
    if session_budget is None or time.monotonic() - session_t0 + wait < session_budget:
        return None
    return call_timeout_error(
        stage=stage, route=route, budget_s=session_budget, effort=effort,
        cause_text=f"retry wait of {wait:.1f}s would cross the {session_budget:g}s session clock")


#: A Responses-shape rejection body names one of these; a reasoning_effort-field body also can
#: ("unsupported parameter: 'reasoning_effort'"), which is why `is_responses_shape_rejection`
#: excludes anything `classify_effort_rejection` already claims.
_SHAPE_REJECTION_MARKERS: Final[tuple[str, ...]] = ("unsupported parameter", "unknown parameter")

#: Responses-only 404: the gateway has no `/v1/responses` route at all.
_NOT_FOUND_STATUS: Final = 404


def is_responses_shape_rejection(exc: BaseException) -> bool:
    """A 404 (no Responses route), or an unsupported-parameter body with no effort subject."""
    if any(getattr(link, "status_code", None) == _NOT_FOUND_STATUS
           for link in exception_chain(exc)):
        return True
    if classify_effort_rejection(exc) is not None:
        return False
    return is_param_rejection(exc, *_SHAPE_REJECTION_MARKERS)


@runtime_checkable
class LlmBackend(Protocol):
    """A module serving this family's two calls, so a mis-registered one fails at selection."""

    def prompt(self, user_prompt: str, *, model: str, **kwargs: Any) -> str:
        """Run a single-turn completion and return its text."""
        ...

    def agentic(self, user_prompt: str, *, model: str, **kwargs: Any) -> str:
        """Run a tool-using loop to completion and return its final text."""
        ...


__all__ = [
    "AGENTIC_MAX_TOKENS",
    "ANTHROPIC_STOP_CONTEXT_WINDOW",
    "ANTHROPIC_STOP_MAX_TOKENS",
    "ANTHROPIC_STOP_REFUSAL",
    "BUDGET_NEAR_RATIO",
    "CLI_CONN_TRANSIENT_RX",
    "CLI_CONTINUED_REPLIES_COUNTER",
    "CLI_RETRYABLE_STATUS",
    "CLI_STATUS_429_RX",
    "CLI_STRUCTURED_OUTPUT_TOOL",
    "CLI_TOKEN_CAP_RX",
    "DEEPAGENTS_MAX_PROMPT_TOKENS",
    "DEFAULT_READ_TOOLS",
    "DEFAULT_REQUEST_TIMEOUT_SECONDS",
    "EFFORT_REJECTIONS",
    "EFFORT_TIME_FACTOR",
    "LLM_CALL_BUDGET_NEAR_COUNTER",
    "LLM_CALL_TIMEOUTS_COUNTER",
    "LLM_MODEL_REFUSALS_COUNTER",
    "LLM_TRUNCATED_BELOW_BUDGET_COUNTER",
    "OPENAI_FINISH_LENGTH",
    "PARAM_REJECTION_ERROR_TYPES",
    "PARAM_REJECTION_STATUS",
    "PROXY_CAUSE_RX",
    "RATE_LIMIT_TRANSIENT_RX",
    "REASONING_EFFORT_LADDER",
    "REASONING_OFF",
    "REFUSAL_RETRY_ATTEMPTED_COUNTER",
    "REFUSAL_RETRY_RECOVERED_COUNTER",
    "RESPONSES_INCOMPLETE_MAX_OUTPUT",
    "RESPONSE_MODEL_TOOL_NAME",
    "RESPONSE_MODEL_VIAS",
    "RETRYABLE_STATUS",
    "RETRY_JITTER_SPREAD",
    "SERVER_ERROR_STATUS",
    "SERVER_ERROR_TRANSIENT_RX",
    "STRUCTURED_PROSE_REASK",
    "STRUCTURED_REASK_MAX",
    "TIMEOUT_MAX_RETRIES",
    "TIMEOUT_STOP_GRACE_SECONDS",
    "TRANSPORT_CHAT",
    "TRANSPORT_MEMORY",
    "TRANSPORT_RESPONSES",
    "TRUNCATED_REPLIES_COUNTER",
    "TRUNCATED_RETRY_ATTEMPTED_COUNTER",
    "TRUNCATED_RETRY_RECOVERED_COUNTER",
    "TRUNCATION_RETRY_MULTIPLIER",
    "ClockKind",
    "GuardrailBlocked",
    "LlmBackend",
    "ModelExtras",
    "ModelRefusal",
    "ModulePath",
    "ResolvedModel",
    "ai_message_refused",
    "call_timeout_error",
    "cause_chain",
    "classify_effort_rejection",
    "effort_after_rejections",
    "effort_scaled_seconds",
    "finish_truncated",
    "guardrail_gate_hit",
    "is_gateway_wrapped_param_rejection",
    "is_model_refusal_rejection",
    "is_param_rejection",
    "is_reasoning_effort_rejection",
    "is_responses_shape_rejection",
    "jittered_delay",
    "model_refusal",
    "model_refusal_from",
    "next_effort_tier",
    "note_budget_use",
    "proxy_detail",
    "proxy_error",
    "refusal_category",
    "refusal_resend_allowed",
    "rejection_text",
    "reply_finish",
    "response_model_tool",
    "step_down",
    "truncation_retry_max",
    "turn_options",
    "turn_timeout",
    "validate_detection_tools",
    "wait_overrun",
    "with_submit_instruction",
]
