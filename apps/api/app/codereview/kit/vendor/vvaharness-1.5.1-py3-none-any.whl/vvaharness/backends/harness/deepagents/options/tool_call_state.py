# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Send back per-tool-call fields the endpoint put outside the OpenAI schema (Chat Completions)."""
from __future__ import annotations

from collections.abc import Iterable
from typing import Any, Final

from langchain_core.messages import AIMessage, BaseMessage
from langchain_core.outputs import ChatResult
from langchain_openai import ChatOpenAI

from vvaharness.util.counters import COUNTERS

__all__ = [
    "TOOL_CALL_STATE_KEY",
    "TOOL_STATE_CAPTURED_COUNTER",
    "ToolCallStateChatOpenAI",
]

#: Namespaced so a future upstream capture key cannot collide; never sent on the wire.
TOOL_CALL_STATE_KEY: Final = "__vvaharness_tool_call_state__"
TOOL_STATE_CAPTURED_COUNTER: Final = "deepagents_tool_state_captured"

#: Keys langchain-openai already round-trips, plus `index`, which is never echoed.
_WIRE_TOOL_CALL_KEYS: Final = frozenset({"id", "type", "function", "custom", "index"})


def _state_by_id(tool_calls: Iterable[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    state: dict[str, dict[str, Any]] = {}
    for call in tool_calls:
        fields = {k: v for k, v in call.items() if k not in _WIRE_TOOL_CALL_KEYS and v is not None}
        if call.get("id") and fields:
            state[call["id"]] = fields
    return state


def _choice_tool_calls(choice: Any) -> list[dict[str, Any]]:
    if isinstance(choice, dict):
        return (choice.get("message") or {}).get("tool_calls") or []
    return [{"id": call.id, **(call.model_extra or {})} for call in choice.message.tool_calls or ()]


def _replay(state: dict[str, dict[str, Any]], sent: dict[str, Any]) -> None:
    for call in sent.get("tool_calls") or ():
        for key, value in state.get(call.get("id"), {}).items():
            call.setdefault(key, value)


def _replay_all(messages: list[BaseMessage], wire: list[dict[str, Any]]) -> None:
    if len(messages) != len(wire):
        return
    for message, sent in zip(messages, wire, strict=True):
        state = message.additional_kwargs.get(TOOL_CALL_STATE_KEY)
        if state:
            _replay(state, sent)


class ToolCallStateChatOpenAI(ChatOpenAI):
    """ChatOpenAI that sends the extra fields the endpoint put on a tool call back on that call."""

    # Non-stream only: the route never streams, and merge_dicts would corrupt this dict.
    def _create_chat_result(
        self, response: Any, generation_info: dict | None = None,
    ) -> ChatResult:
        result = super()._create_chat_result(response, generation_info)
        choices = (
            response.get("choices") if isinstance(response, dict) else response.choices
        ) or ()
        for generation, choice in zip(result.generations, choices, strict=False):
            state = _state_by_id(_choice_tool_calls(choice))
            if state and isinstance(generation.message, AIMessage):
                generation.message.additional_kwargs[TOOL_CALL_STATE_KEY] = state
                COUNTERS.bump(TOOL_STATE_CAPTURED_COUNTER)
        return result

    def _get_request_payload(
        self, input_: Any, *, stop: list[str] | None = None, **kwargs: Any,
    ) -> dict:
        payload = super()._get_request_payload(input_, stop=stop, **kwargs)
        wire = payload.get("messages")
        if isinstance(wire, list):
            _replay_all(self._convert_input(input_).to_messages(), wire)
        return payload
