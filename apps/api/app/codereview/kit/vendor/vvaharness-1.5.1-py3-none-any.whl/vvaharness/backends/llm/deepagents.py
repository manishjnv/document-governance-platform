# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""DeepAgents route for the legacy stage call sites."""

# Deliberately NOT registered in ``registry._BACKENDS``: stages branch on the resolved ``via``
# explicitly, so the registry never dispatches here.
# INVARIANT 1: ``cwd`` is the HOST repo root and the harness roots its virtual filesystem there,
# so an agent can emit a virtual absolute path (``/src/app.py``) for a host file.
# ``scope.resolve_inventory_path`` resolves such spellings against the inventory at every
# model-path entry point (s1 seed paths via ``scope._resolve_scope_path``,
# ``s2._finalize_threats``, ``s4/outcomes.fan_out`` for S4 findings and S6
# discoveries); a new agentic stage emitting paths must do the same BEFORE any inventory check.
# INVARIANT 2: ``TOKENS`` phase bucketing is correct ONLY because callers block — ``_run_sync``
# waits, so the caller's ``TOKENS.phase(...)`` window is still open when the translate layer
# records usage. Concurrent calls across DIFFERENT phases would cross-contaminate buckets.
# Top-level imports must stay langchain-free; the harness pulls its SDK in lazily.

from __future__ import annotations

import asyncio
import atexit
import os
import re
import threading
import time
from collections.abc import Callable, Coroutine, Sequence
from pathlib import Path
from typing import TYPE_CHECKING, Final, TypeVar

from vvaharness.util import logs

if TYPE_CHECKING:
    from langchain.agents.middleware.types import AgentMiddleware

from vvaharness.backends.harness import (
    READ_TOOLS,
    HarnessProcessError,
    HarnessResult,
    OneShotOptions,
    OneShotResult,
    StreamingOptions,
    ToolPolicy,
    get_harness,
)
from vvaharness.backends.harness.deepagents.limits import MODEL_MAX_OUTPUT_TOKENS
from vvaharness.backends.harness.models import (
    DEFAULT_GRAPH_NAME,
    LOGICAL_TO_NATIVE,
    NATIVE_IMPLIED_READS,
    NATIVE_SHELL_TOOL,
    AuthenticationError,
    OversizePromptError,
    ProxyError,
    SessionNotResumableError,
    ToolBuilder,
    ToolStateNotRoundTrippedError,
    TruncatedResponseError,
)
from vvaharness.backends.harness.provider_routing import (
    credential_env_overrides,
    routes_to_anthropic,
)
from vvaharness.backends.harness.transcript import Transcript, open_transcript
from vvaharness.backends.llm import cli as _cli
from vvaharness.backends.llm import registry
from vvaharness.backends.llm.cache import markers_enabled

# Reused, not re-grown: VVAH-E005 messages + errors.jsonl bookkeeping are generic on cli
from vvaharness.backends.llm.cli import _truncation_error
from vvaharness.backends.llm.models import (
    AGENTIC_MAX_TOKENS,
    DEEPAGENTS_MAX_PROMPT_TOKENS,
    RATE_LIMIT_TRANSIENT_RX,
    RETRYABLE_STATUS,
    SERVER_ERROR_TRANSIENT_RX,
    TRUNCATED_REPLIES_COUNTER,
    ClockKind,
    ModelRefusal,
    call_timeout_error,
    effort_scaled_seconds,
    jittered_delay,
    model_refusal,
    model_refusal_from,
    note_budget_use,
    proxy_detail,
    truncation_retry_max,
    turn_timeout,
    wait_overrun,
)
from vvaharness.backends.llm.registry import (
    _flatten_blocks,
    clamp_output_tokens,
    output_cap_of,
    resolve,
)

# The sdk backend is the single home of the auth/proxy failure signatures; import, never copy.
from vvaharness.backends.llm.sdk import _AUTH_STATUS_RX
from vvaharness.report.redact import redact
from vvaharness.util import console
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event
from vvaharness.util.exceptions import exception_chain
from vvaharness.util.response_quality import (
    check_response_quality,
    output_tokens_for_gate,
)
from vvaharness.util.scan_progress import get_active_tracker
from vvaharness.util.tokens import TOKENS, TokenUsage, estimate_tokens
from vvaharness.util.warn_once import warn_once

log = logs.get_logger(__name__)

__all__ = [
    "agentic",
    "build_harness_env",
    "dispatch_agentic",
    "dispatch_prompt",
    "drain_classified",
    "drain_streaming",
    "droppable_effort",
    "map_allowed_tools",
    "prompt",
    "raise_if_refused",
    "route_carries_tools",
    "run_oneshot",
    "terminal_text",
    "think_in_prompt_enabled",
]

_T = TypeVar("_T")


def _permitted_natives(granted: Sequence[str], allow_shell: bool = False) -> frozenset[str]:
    """Native names for *granted*, plus the implied reads and, opted in, the shell."""
    natives = {LOGICAL_TO_NATIVE[t] for t in granted if t in LOGICAL_TO_NATIVE}
    if natives & {LOGICAL_TO_NATIVE[r] for r in READ_TOOLS}:
        natives |= NATIVE_IMPLIED_READS
    if allow_shell:
        natives.add(NATIVE_SHELL_TOOL)
    return frozenset(natives)

#: Granted when a caller passes no tool list, matching the harness read set.
_DEFAULT_TOOLS: tuple[str, ...] = ("Read", "Glob", "Grep")

# `timeout` is NOT here: both dispatch_prompt and dispatch_agentic pop and bind it themselves
#: Silently ignored (announced by _warn_dropped_model_knobs); anything else still warns once
_ACCEPTED_UNUSED_KW: frozenset[str] = frozenset({
    "betas",
    "json_schema",
    "max_budget_usd",
    "output_format",
    "permission_mode",
    "stream_cb",
    "temperature",
    "thinking_budget",
})

#: Kwarg names already warned about, so each fires at most once per process.
_WARNED_LEGACY_KW: set[str] = set()


#: Guards lazy start of the persistent harness loop below.
_LOOP_LOCK = threading.Lock()
_loop: asyncio.AbstractEventLoop | None = None
_loop_thread: threading.Thread | None = None


def _shutdown_loop() -> None:
    """Stop the harness loop at interpreter exit and join its thread."""
    with _LOOP_LOCK:
        loop, thread = _loop, _loop_thread
    if loop is None or thread is None:
        return
    loop.call_soon_threadsafe(loop.stop)
    thread.join(timeout=5.0)


def _harness_loop() -> asyncio.AbstractEventLoop:
    """Return the module's persistent event loop, starting its daemon thread on first use."""
    global _loop, _loop_thread
    with _LOOP_LOCK:
        if _loop is not None:
            return _loop
        loop = asyncio.new_event_loop()
        thread = threading.Thread(
            target=loop.run_forever, name="vvaharness-llm-deepagents", daemon=True
        )
        thread.start()
        atexit.register(_shutdown_loop)
        _loop, _loop_thread = loop, thread
        return loop


def _run_sync(
    awaitable: Coroutine[None, None, _T], *, timeout: float | None = None,
    tag: str | None = None, effort: str | None = None,
) -> _T:
    """Run a coroutine on the persistent harness loop, blocking until it completes."""
    # Blocking is load-bearing for TOKENS bucketing (invariant 2); *timeout* is preflight's probe
    loop = _harness_loop()
    if threading.current_thread() is _loop_thread:
        awaitable.close()
        raise RuntimeError(
            "_run_sync called from the harness loop thread — this would deadlock"
        )
    future = asyncio.run_coroutine_threadsafe(awaitable, loop)
    _start = time.monotonic()
    try:
        result = future.result(timeout=timeout)
    except BaseException as exc:
        # On Ctrl-C or a timeout the harness call must stop billing, not run on in the background
        cancelled = future.cancel()
        # concurrent.futures.TimeoutError IS builtins.TimeoutError on 3.11: cancelled=True is the
        # only way to tell "the deadline was hit" apart from "the coroutine itself raised this".
        # A sub-millisecond window exists where the coroutine finishes between result()'s
        # raise and this cancel() call, making a genuine deadline-expiry look like cancelled=False
        # too — accepted; the call still fails loudly (bare TimeoutError), just without VVAH-E008.
        if isinstance(exc, TimeoutError) and cancelled:
            raise call_timeout_error(
                stage=tag or "", route="deepagents", budget_s=timeout, effort=effort,
                cause_text=f"deepagents session exceeded {timeout:g}s",
            ) from exc
        raise
    note_budget_use(time.monotonic() - _start, timeout, effort)
    return result


_provider_of = registry.provider_of
_use_responses_api_of = registry.use_responses_api_of


# ── failure classification (VVAH-E001 / VVAH-E002 / VVAH-E006) ──────────────

_HTTP_UNAUTHORIZED: int = 401
_HTTP_PROXY_AUTH: int = 407
_PROXY_407_RX = re.compile(r"\b407\b")

#: Stage tags already warned for missing token usage, so each fires once per process.
_NO_USAGE_WARNED_TAGS: set[str] = set()

#: Counter for VVAH-E004 pre-dispatch refusals; rendered as a Pipeline Diagnostics row.
_OVERSIZE_PROMPT_COUNTER = "deepagents_oversize_prompts"

#: VVAH-E006: tool replay rejected for missing per-turn state (Gemini ``thought_signature``)
_TOOL_STATE_NOT_ROUNDTRIPPED_COUNTER = "deepagents_tool_state_not_roundtripped"


def _check_prompt_ceiling(text: str, *, tag: str | None) -> None:
    """Refuse a prompt whose estimate exceeds the route ceiling, before dispatch."""
    estimated = estimate_tokens(text)
    if estimated <= DEEPAGENTS_MAX_PROMPT_TOKENS:
        return
    COUNTERS.bump(_OVERSIZE_PROMPT_COUNTER)
    raise OversizePromptError(
        "refused before dispatch; reduce what this call packs "
        "(chunk sizing / per-call caps) and re-run",
        stage=tag or "",
        estimated_tokens=estimated,
        limit=DEEPAGENTS_MAX_PROMPT_TOKENS,
    )


# exception_chain lives in util.exceptions (layering); failures arrive WRAPPED, so walk the chain


def _auth_failure(exc: BaseException) -> tuple[int, str] | None:
    """Return ``(status, body)`` when the chain carries a provider auth failure."""
    # APIStatusError carries ``.status_code``, APIConnectionError does not: no auth misread
    for err in exception_chain(exc):
        status = getattr(err, "status_code", None)
        if not isinstance(status, int):
            continue
        body = str(getattr(err, "message", err))
        if status == _HTTP_UNAUTHORIZED or _AUTH_STATUS_RX.search(body):
            return status, body
    return None


def _proxy_failure(exc: BaseException) -> str | None:
    """Return the cause detail when the chain carries a proxy/TLS connection failure."""
    for err in exception_chain(exc):
        if type(err).__name__ == "APIConnectionError" and (detail := proxy_detail(err)):
            return detail
    return None


def _classify_failure(
    exc: BaseException, *, model_id: str, tag: str | None
) -> AuthenticationError | ProxyError | ToolStateNotRoundTrippedError | ModelRefusal | None:
    """Map a provider failure onto the VVAH taxonomy, or None when unrecognised."""
    # TRAP: redact BEFORE truncating (a bisected JWT stops matching); VVAH-E006 arm must come LAST
    # Refusal FIRST, before any arm that could re-send it; the one permitted resend belongs to
    # dispatch_or_retry_unforced
    refusal = model_refusal_from(exc, route="deepagents", stage=tag or "")
    if refusal is not None:
        return refusal
    context = f"model={model_id}" + (f", stage={tag}" if tag else "")
    auth = _auth_failure(exc)
    if auth is not None:
        status, body = auth
        return AuthenticationError(
            f"{redact(body)[:400]} ({context})",
            status_code=status,
            backend="deepagents",
        )
    detail = _proxy_failure(exc)
    if detail is not None:
        return ProxyError(
            f"{redact(detail)[:400]} ({context})",
            status_code=_HTTP_PROXY_AUTH if _PROXY_407_RX.search(detail) else None,
            backend="deepagents",
        )
    from vvaharness.backends.harness.deepagents.client import (  # noqa: PLC0415
        _is_missing_thought_signature,
    )
    if _is_missing_thought_signature(exc):
        COUNTERS.bump(_TOOL_STATE_NOT_ROUNDTRIPPED_COUNTER)
        return ToolStateNotRoundTrippedError(
            f"provider rejected a replayed tool call ({context})",
            stage=tag or "",
            model_id=model_id,
        )
    return None


#: Same rule as ``sdk._is_transient_sdk``: a 401/403 block page often says "Service Unavailable"
_UNHEALABLE_STATUS: Final[frozenset[int]] = frozenset({_HTTP_UNAUTHORIZED, 403})

#: Wrapper-level attempts and wait, matching ``sdk.prompt``'s ``attempts, retry_wait = 3, 60``
_TRANSIENT_ATTEMPTS: Final = 3
_TRANSIENT_WAIT_SECONDS: Final = 60

#: Ceiling on ``retry-after``: a gateway advertising 86400s must not park a scan for a day
_RETRY_AFTER_MAX_SECONDS: Final = 300.0


def _transient_failure(exc: BaseException) -> bool:
    """Whether the chain carries a transient worth one more send."""
    # An unhealable status ANYWHERE in the chain vetoes, not just on the link with the signal
    transient = False
    for err in exception_chain(exc):
        status = getattr(err, "status_code", None)
        if isinstance(status, int) and status in _UNHEALABLE_STATUS:
            return False
        body = str(getattr(err, "message", None) or err)
        transient = transient or bool(
            (isinstance(status, int) and status in RETRYABLE_STATUS)
            or RATE_LIMIT_TRANSIENT_RX.search(body)
            or SERVER_ERROR_TRANSIENT_RX.search(body)
        )
    return transient


def _retry_after_seconds(exc: BaseException) -> float | None:
    """The chain's advertised ``retry-after`` in seconds, when it carries a usable one."""
    for err in exception_chain(exc):
        headers = getattr(getattr(err, "response", None), "headers", None)
        raw = headers.get("retry-after") if hasattr(headers, "get") else None
        if raw is None:
            continue
        try:
            seconds = float(raw)
        except (TypeError, ValueError):
            continue
        if seconds > 0:
            return min(seconds, _RETRY_AFTER_MAX_SECONDS)
    return None


def _refusal_or_raise(mapped: Exception, exc: BaseException) -> ModelRefusal:
    """*mapped* when it is a refusal (raised later, unchained); otherwise raise it from *exc*."""
    if not isinstance(mapped, ModelRefusal):
        raise mapped from exc
    return mapped


def _transient_wait(exc: Exception, *, session_t0: float, budget: float | None,
                    tag: str | None) -> float:
    """The wait before the next transient retry; VVAH-E008 when it would cross the clock."""
    # retry-after honoured un-jittered; the flat fallback is jittered or S4/S6 workers sync
    retry_after = _retry_after_seconds(exc)
    wait = retry_after if retry_after is not None else jittered_delay(_TRANSIENT_WAIT_SECONDS)
    if overrun := wait_overrun(wait, session_t0, budget,
                               stage=tag or "", route="deepagents", effort=None):
        raise overrun from exc
    return wait


def _call_classified(call: Callable[[float | None], _T], *, model_id: str, tag: str | None,
                     budget: float | None = None) -> _T:
    """Run a harness call, retrying transients and re-raising the rest under the VVAH taxonomy."""
    # THE retry ladder: stacks on each SDK's 2 retries, so worst case 3x3 = 9 sends (x2 on fallback)
    attempt = 0
    session_t0 = time.monotonic()
    remaining = budget
    while True:
        attempt += 1
        try:
            return call(remaining)
        except Exception as exc:
            mapped = _classify_failure(exc, model_id=model_id, tag=tag)
            if mapped is not None:
                refusal = _refusal_or_raise(mapped, exc)
                break
            if attempt >= _TRANSIENT_ATTEMPTS or not _transient_failure(exc):
                raise
            wait = _transient_wait(exc, session_t0=session_t0, budget=budget, tag=tag)
            console.write(
                f"    [deepagents] transient error (attempt {attempt}/"
                f"{_TRANSIENT_ATTEMPTS}, model={model_id}"
                f"{f', stage={tag}' if tag else ''}); retrying in {wait:g}s"
            )
            time.sleep(wait)
            remaining = None if budget is None else turn_timeout(session_t0, budget, budget)
    # Raised outside the except, unchained: is_timeout_failure would read a TimeoutError link in
    # the chain as a timeout. The message keeps the redacted provider detail.
    raise refusal


def _warn_no_usage(usage: object, *, model_id: str, tag: str | None) -> None:
    """WARN once per stage when a call finishes with no token usage recorded."""
    if usage is not None:
        return
    tag_text = tag or ""
    stage_key = tag_text.split(maxsplit=1)[0] if tag_text.strip() else ""
    warn_once(
        _NO_USAGE_WARNED_TAGS,
        stage_key,
        f"  [deepagents] WARN: no token usage recorded for stage "
        f"'{tag_text or 'untagged'}' (model={model_id}) — token accounting is "
        f"unavailable for this stage",
    )


#: ``deepagents:<knob>`` pairs already reported, so each fires once per process.
_WARNED_DROPPED_KNOBS: set[str] = set()


def _warn_dropped_model_knobs(model_id: str, extras: object) -> None:
    """One-time WARN naming every model-node tunable this route cannot send."""
    if not isinstance(extras, dict):
        return
    for name in sorted(extras):
        warn_once(
            _WARNED_DROPPED_KNOBS,
            f"deepagents:{name}",
            f"WARN [deepagents]: models entry {model_id!r} sets {name}, which the "
            f"deepagents route never sends — ignored. Route this role via: sdk "
            f"(or via: openai) to have it honoured.",
        )


def _warn_max_budget_unenforced(max_budget_usd: float | None) -> None:
    """One-time WARN that ``max_budget_usd`` is accepted but never enforced here."""
    # Forwarded but unenforced here; only the Claude-side transports (cli, Agent SDK, cli_mcp) cap
    if max_budget_usd is None:
        return
    warn_once(
        _WARNED_DROPPED_KNOBS,
        "deepagents:max_budget_usd",
        f"WARN [deepagents]: max_budget_usd={max_budget_usd} is accepted but "
        f"not enforced on the deepagents route — no spend cap is applied "
        f"here. Route this role via: cli for an enforced budget.",
    )


def _output_tokens(usage: TokenUsage | None) -> int | None:
    """``output_tokens`` for the quality gate. Delegates so all four routes agree."""
    return output_tokens_for_gate(usage)


def _usage_of(result: object) -> TokenUsage | None:
    """The result's ``usage`` field, or None when absent."""
    usage = getattr(result, "usage", None)
    return usage if isinstance(usage, dict) else None


def build_harness_env(
    model_id: str,
    provider: str | None,
    *,
    sdk_cfg: object,
    openai_cfg: object,
    cfg_dir: str | Path | None = None,
) -> dict[str, str]:
    """Process env plus the credential AND TLS overrides the resolved route needs."""
    # DETECTION only: plugin_runner._invoke_deepagents deliberately folds no TLS (test-pinned)
    from vvaharness.backends.harness.deepagents.options.model_building import (  # noqa: PLC0415 — lazy: model_building imports langchain; `import vvaharness.cli` must stay langchain-free
        tls_carriers_for,
    )

    return {
        **os.environ,
        **credential_env_overrides(
            model_id, provider, sdk_cfg=sdk_cfg, openai_cfg=openai_cfg
        ),
        **tls_carriers_for(
            model_id, provider, sdk_cfg=sdk_cfg, openai_cfg=openai_cfg, cfg_dir=cfg_dir
        ),
    }


def map_allowed_tools(
    allowed_tools: Sequence[str] | None,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Split a legacy tool list into (granted, stripped) against ``READ_TOOLS``."""
    # ``None`` grants the default read set; a stripped name is never an error here — caller warns
    if allowed_tools is None:
        return _DEFAULT_TOOLS, ()
    names = tuple(dict.fromkeys(allowed_tools))
    granted = tuple(n for n in names if n in READ_TOOLS)
    stripped = tuple(n for n in names if n not in READ_TOOLS)
    return granted, stripped


async def _consume(
    user_prompt: str, options: StreamingOptions,
    transcript: Transcript | None, seen: list[HarnessResult],
) -> None:
    """Stream the session, appending terminals to *seen* and every message to *transcript*."""
    # Caller-owned list, not a return: the GraphRecursionError path needs the pre-raise snapshot
    async for message in get_harness("deepagents").run_streaming(user_prompt, options):
        if transcript is not None:
            transcript.add(message)
        if isinstance(message, HarnessResult):
            seen.append(message)


#: session_id -> the StreamingOptions it was armed with, so a resume re-enters the same session.
_PINNED: dict[str, StreamingOptions] = {}
_PINNED_LOCK = threading.Lock()


def _pin_session(options: StreamingOptions) -> None:
    """Remember *options* under its session_id so resume_agentic can find the live session."""
    if options.session_id:
        with _PINNED_LOCK:
            _PINNED[options.session_id] = options


def _streaming_options_of(session_id: str) -> StreamingOptions | None:
    """The options a pinned session was armed with, or None when it was never pinned."""
    with _PINNED_LOCK:
        return _PINNED.get(session_id)


def release_pinned_session(session_id: str) -> None:
    """Forget *session_id* on every route's side, freeing its checkpointed conversation."""
    # Lazy, as at build_model: options/ imports langchain and `import vvaharness.cli` stays free of it
    from vvaharness.backends.harness.deepagents.options import release_session  # noqa: PLC0415

    with _PINNED_LOCK:
        _PINNED.pop(session_id, None)
    release_session(session_id)
    _cli.session.release_pinned_session(session_id)


async def _consume_resume(
    instruction: str, options: StreamingOptions,
    transcript: Transcript | None, seen: list[HarnessResult],
) -> None:
    """Resume twin of :func:`_consume`: one more turn on the SAME thread, same bookkeeping."""
    async for message in get_harness("deepagents").resume_streaming(instruction, options):
        if transcript is not None:
            transcript.add(message)
        if isinstance(message, HarnessResult):
            seen.append(message)


async def _drain_resume(
    instruction: str, options: StreamingOptions, *, tag: str | None = None
) -> HarnessResult | None:
    """Drain a resumed session to its terminal result."""
    seen: list[HarnessResult] = []
    transcript = open_transcript(tag=tag, model=options.model,
                                 graph_name=options.graph_name)
    try:
        await _consume_resume(instruction, options, transcript, seen)
    finally:
        if transcript is not None:
            transcript.close()
    return seen[-1] if seen else None


def drain_resume(instruction: str, options: StreamingOptions, *,
                 tag: str | None = None, timeout: float | None = None) -> HarnessResult:
    """Run one resumed turn to completion and return its terminal result."""
    terminal = _run_sync(_drain_resume(instruction, options, tag=tag), timeout=timeout,
                         tag=tag, effort=options.effort)
    if terminal is None:
        raise RuntimeError("DeepAgents resume ended without a terminal result")
    return terminal


async def _drain(
    user_prompt: str, options: StreamingOptions, *, tag: str | None = None
) -> tuple[HarnessResult | None, HarnessProcessError | None]:
    """Drain a streaming session to (terminal, recursion error or None)."""
    seen: list[HarnessResult] = []
    # _consume sees every HarnessMessage (subagents too), so only here can a transcript be whole
    transcript = open_transcript(tag=tag, model=options.model,
                                 graph_name=options.graph_name)
    try:
        await _consume(user_prompt, options, transcript, seen)
    except HarnessProcessError as exc:
        # GraphRecursionError salvage = legacy force-finalize; typed flag leads, name match is belt
        if not (getattr(exc, "recursion_limited", False)
                or "GraphRecursionError" in str(exc)) or not seen:
            raise
        return seen[-1], exc
    finally:
        # In the finally so a session that dies mid-stream still leaves a transcript
        if transcript is not None:
            transcript.close()
    return (seen[-1] if seen else None), None


def drain_streaming(user_prompt: str, options: StreamingOptions, *,
                    tag: str | None = None,
                    timeout: float | None = None) -> HarnessResult:
    """Run a streaming session to completion and return its terminal result."""
    terminal, recursion_error = _run_sync(
        _drain(user_prompt, options, tag=tag), timeout=timeout,
        tag=tag, effort=options.effort,
    )
    if terminal is None:
        raise RuntimeError("DeepAgents session ended without a terminal result")
    if terminal.is_error and recursion_error is None:
        raise RuntimeError(
            f"DeepAgents session failed: {terminal.subtype or 'unknown error'}"
        )
    if recursion_error is not None:
        # Pre-raise snapshot: same shape as sdk/openai's max-turns WARN, so the same counter
        log.warning(Event.AGENTIC_TURN_LIMIT, model=options.model, tag=tag)
        COUNTERS.bump("llm_turn_cap_exhausted")
    return terminal


def run_oneshot(
    user_prompt: str, options: OneShotOptions, *,
    tag: str | None = None, timeout: float | None = None,
) -> OneShotResult:
    """Run a single-turn parser-only invocation synchronously."""
    return _run_sync(
        get_harness("deepagents").run_oneshot(user_prompt, options), timeout=timeout,
        tag=tag, effort=options.effort,
    )


def _run_oneshot_with_truncation_retry(
    user_prompt: str, options: OneShotOptions, *, model_id: str, tag: str | None,
    timeout: float | None = None,
) -> OneShotResult:
    """Run the one-shot call once; raise the typed VVAH-E005 if the reply the provider returned is still cut off..."""
    requested = options.max_output_tokens or MODEL_MAX_OUTPUT_TOKENS
    cap_ceiling = options.output_cap if options.output_cap is not None else MODEL_MAX_OUTPUT_TOKENS
    retry_at = truncation_retry_max(requested, cap=cap_ceiling)
    result = _call_classified(
        lambda remaining: run_oneshot(user_prompt, options, tag=tag, timeout=remaining),
        model_id=model_id, tag=tag, budget=timeout
    )
    raise_if_refused(result, tag=tag)
    # getattr because test doubles use plain namespaces: "no field" means "not observed"
    if not getattr(result, "truncated", False):
        return result
    # retry_at, not 0: the middleware already spent the doubling before this saw the truncation
    raise _truncation_error(
        requested=requested, retried=(retry_at or 0), tag=tag, retry_at=retry_at,
        produced=_output_tokens(result.usage),
    )


def raise_if_refused(result: object, *, tag: str | None) -> None:
    """Raise the typed refusal when the terminal result marks a refused turn; usage is banked."""
    # getattr: test doubles use plain namespaces
    if getattr(result, "refused", False):
        raise model_refusal(route="deepagents", stage=tag or "",
                            category=getattr(result, "refusal_category", None))


def drain_classified(user_prompt: str, options: StreamingOptions, *, model_id: str,
                     tag: str | None, timeout: float | None = None) -> HarnessResult:
    """:func:`drain_streaming` under the VVAH failure taxonomy; a refused terminal raises."""
    terminal = _call_classified(
        lambda remaining: drain_streaming(user_prompt, options, tag=tag, timeout=remaining),
        model_id=model_id, tag=tag, budget=timeout
    )
    raise_if_refused(terminal, tag=tag)
    return terminal


def terminal_text(result: HarnessResult) -> str:
    """Final assistant text; IS the structured channel (JSON) when response_model was set."""
    return result.result_text or ""


def agentic(
    user_prompt: str,
    *,
    model: object,
    system_prompt: str | None = None,
    allowed_tools: Sequence[str] | None = None,
    cwd: str,
    max_budget_usd: float | None = None,
    permission_mode: str = "auto",
    max_turns: int | None = None,
    tag: str | None = None,
    graph_name: str = DEFAULT_GRAPH_NAME,
    sdk_cfg: object = None,
    openai_cfg: object = None,
    cfg_dir: str | None = None,
    tool_builder: ToolBuilder | None = None,
    fact_tools: Sequence[str] = (),
    response_model: type | None = None,
    parent_middleware: tuple[AgentMiddleware, ...] = (),
    skill_root: Path | None = None,
    cache_prefix: str | None = None,
    max_output_tokens: int | None = None,
    effort: str | None = None,
    agents: dict[str, object] | None = None,
    allow_shell: bool = False,
    timeout: float | None = None,
    session_id: str = "",
    think_in_prompt: bool = False,
) -> str:
    """Tool-using loop on the DeepAgents harness, legacy ``registry.agentic`` shape."""
    # max_turns is the LangGraph recursion limit +900 here: 40 ≈ 470 turns; a HARD cap on sdk/cli
    model_id, _via, extras = resolve(model)
    _warn_dropped_model_knobs(model_id, extras)
    _warn_max_budget_unenforced(max_budget_usd)
    provider = _provider_of(model)
    output_cap = output_cap_of(model)
    effective_max_output_tokens = max_output_tokens or AGENTIC_MAX_TOKENS
    if output_cap is not None:
        effective_max_output_tokens = clamp_output_tokens(
            effective_max_output_tokens, model, tag=tag)
    prefix = cache_prefix or ""
    if prefix and not (routes_to_anthropic(model_id, provider) and markers_on(sdk_cfg)):
        # Content is never dropped: an unmarkable prefix folds into the turn.
        user_prompt = prefix + user_prompt
        prefix = ""
    _check_prompt_ceiling(prefix + user_prompt, tag=tag)
    granted, stripped = map_allowed_tools(allowed_tools)
    if stripped:
        log.warning(Event.TOOLS_UNSUPPORTED_ON_ROUTE, stripped=sorted(stripped))
    # response_model/allow_writes defaults keep the read-only redaction stack.
    options = StreamingOptions(
        model=model_id,
        model_provider=provider,
        use_responses_api=_use_responses_api_of(model),
        cwd=Path(cwd),
        env=build_harness_env(
            model_id, provider, sdk_cfg=sdk_cfg, openai_cfg=openai_cfg, cfg_dir=cfg_dir
        ),
        max_turns=max_turns,
        max_budget_usd=max_budget_usd,
        system_prompt=system_prompt,
        tool_policy=ToolPolicy(allowed_tools=granted, disallowed_tools=stripped),
        graph_name=graph_name,
        skill_root=skill_root,
        effort=effort,
        agents=agents or {},
        # PermitTools gate: only granted read natives run, `task` excluded; TRAP: allow_shell is
        permitted_tool_calls=_permitted_natives(granted, allow_shell),
        allow_shell=allow_shell,
        # Per-turn ceiling, 16k parity with sdk/openai; otherwise this route inherits 64k
        max_output_tokens=effective_max_output_tokens,
        output_cap=output_cap,
        cache_markers=markers_on(sdk_cfg),
        # The 4th and LAST Anthropic breakpoint: the middleware already spends system/tools/tail
        cache_prefix=prefix or None,
        tool_builder=tool_builder,
        fact_tools=tuple(fact_tools),
        response_model=response_model,
        parent_middleware=parent_middleware,
        # Pinned so resume_agentic can continue THIS conversation after a deadline kill
        session_id=session_id,
        # Reasoning asked for in the prompt instead of an API thinking block: faster at the same
        # depth, and langchain then keeps the forced tool_choice natively. Callers pass the knob.
        think_in_prompt=think_in_prompt,
    )
    _pin_session(options)
    # Scaled here, not in dispatch_agentic: the single-scaling rule, kept at the arming seam
    # (resume_agentic scales its own clock the same way)
    session_timeout = effort_scaled_seconds(timeout, effort, kind=ClockKind.SESSION)
    terminal = drain_classified(user_prompt, options, model_id=model_id, tag=tag,
                                timeout=session_timeout)
    usage = _usage_of(terminal)
    if getattr(terminal, "truncated", False):
        # CapOutputTokens already retried; `usage` is session-cumulative — never pass as produced=
        COUNTERS.bump(TRUNCATED_REPLIES_COUNTER)
        # retried= mirrors the one-shot sibling: the middleware spent the doubling, or had none
        cap_ceiling = output_cap if output_cap is not None else MODEL_MAX_OUTPUT_TOKENS
        raise TruncatedResponseError(
            "final assistant turn hit the per-turn output budget; the "
            "one doubled-budget retry (CapOutputTokens) also came back "
            "truncated, or there was no useful doubling left",
            stage=tag or "",
            requested=effective_max_output_tokens,
            retried=truncation_retry_max(effective_max_output_tokens, cap=cap_ceiling) or 0,
        )
    _warn_no_usage(usage, model_id=model_id, tag=tag)
    text = terminal_text(terminal)
    check_response_quality(
        text.strip(), stage=tag or "", output_tokens=_output_tokens(usage)
    )
    return text


def markers_on(sdk_cfg: object) -> bool:
    """Whether the sdk block's `cache_markers` kill switch permits markers here too."""
    value = getattr(sdk_cfg, "cache_markers", None)
    return markers_enabled({} if value is None else {"cache_markers": value})


# Alias kept for the callers that predate the public promotion.
_markers_on = markers_on


def prompt(
    user_prompt: str | list[dict[str, object]],
    *,
    model: object,
    system_prompt: str | None = None,
    max_tokens: int | None = None,
    cwd: str,
    tag: str | None = None,
    graph_name: str = DEFAULT_GRAPH_NAME,
    sdk_cfg: object = None,
    openai_cfg: object = None,
    cfg_dir: str | None = None,
    cache_prefix: str | None = None,
    response_model: type | None = None,
    tool_builder: ToolBuilder | None = None,
    fact_tools: Sequence[str] = (),
    parent_middleware: tuple[AgentMiddleware, ...] = (),
    max_turns: int | None = None,
    effort: str | None = None,
    timeout: float | None = None,
    think_in_prompt: bool = False,
) -> str:
    """Single-turn completion on the DeepAgents harness, legacy ``registry.prompt`` shape."""
    # ``max_tokens=None``: 64k Anthropic, UNCAPPED on OpenAI gateways; TOKENS relies on invariant 2
    model_id, _via, extras = resolve(model)
    _warn_dropped_model_knobs(model_id, extras)
    if max_tokens is not None:
        max_tokens = clamp_output_tokens(int(max_tokens), model, tag=tag)
    provider = _provider_of(model)
    flat = _flatten_blocks(user_prompt)
    prefix = cache_prefix or ""
    if prefix and not (routes_to_anthropic(model_id, provider)
                       and _markers_on(sdk_cfg)):
        # Content is never dropped: an unmarkable prefix folds into the turn.
        flat = prefix + flat
        prefix = ""
    # Ceiling over the FULL user-turn content: a marked prefix is still sent.
    _check_prompt_ceiling(prefix + flat, tag=tag)
    tracker = get_active_tracker()
    if tracker is not None:
        tracker.llm_payload(
            phase=TOKENS.current_phase(),
            backend="deepagents",
            model_id=model_id,
            tag=tag or "",
            user_prompt=prefix + flat,
            system_prompt=system_prompt or "",
        )
    # The explicit empty ToolPolicy excludes the native filesystem tools.
    options = OneShotOptions(
        model=model_id,
        model_provider=provider,
        use_responses_api=_use_responses_api_of(model),
        cwd=Path(cwd),
        env=build_harness_env(
            model_id, provider, sdk_cfg=sdk_cfg, openai_cfg=openai_cfg, cfg_dir=cfg_dir
        ),
        system_prompt=system_prompt,
        tool_policy=ToolPolicy(),
        graph_name=graph_name,
        max_output_tokens=max_tokens,
        output_cap=output_cap_of(model),
        cache_prefix=prefix or None,
        cache_markers=markers_on(sdk_cfg),
        response_model=response_model,
        tool_builder=tool_builder,
        fact_tools=tuple(fact_tools),
        parent_middleware=parent_middleware,
        max_turns=15 if max_turns is None else max_turns,
        effort=effort,
        think_in_prompt=think_in_prompt,
    )
    # A one-shot has no tool loop: REQUEST, not SESSION, mirrors build_model's per-request clock
    request_timeout = effort_scaled_seconds(timeout, effort, kind=ClockKind.REQUEST)
    result = _run_oneshot_with_truncation_retry(
        flat, options, model_id=model_id, tag=tag, timeout=request_timeout
    )
    usage = _usage_of(result)
    _warn_no_usage(usage, model_id=model_id, tag=tag)
    text = result.result_text or ""
    check_response_quality(
        text.strip(), stage=tag or "", output_tokens=_output_tokens(usage)
    )
    return text


# ── the dispatch seam ─────────────────────────────────────────────────────────


def _screen_legacy_kwargs(legacy_kw: dict[str, object], *, route: str = "deepagents") -> str:
    """Vet legacy-route kwargs for *route*; return any ``cache_prefix`` text."""
    # Never silently drop a request-changing kwarg: cache_prefix carries CONTENT, so it is returned
    prefix = legacy_kw.pop("cache_prefix", None)
    for name in legacy_kw:
        if name not in _ACCEPTED_UNUSED_KW:
            warn_once(
                _WARNED_LEGACY_KW,
                name,
                f"WARN [{route}]: legacy kwarg `{name}` is not supported on "
                f"the {route} route — ignored",
            )
    if not prefix:
        return ""
    # A multi-block prefix arrives as a list/tuple; str() would embed a Python repr in the prompt
    if isinstance(prefix, (list, tuple)):
        return "\n\n".join(str(p) for p in prefix if p)
    return str(prefix)


def _cfg_blocks(cfg: object) -> tuple[object, object, str | None]:
    """Return ``(sdk_cfg, openai_cfg, cfg_dir)`` off a profile node, all optional."""
    data = getattr(cfg, "_data", None)
    cfg_dir = data.get("_config_dir") if isinstance(data, dict) else None
    return getattr(cfg, "sdk", None), getattr(cfg, "openai", None), cfg_dir


def think_in_prompt_enabled(cfg: object) -> bool:
    """The ``think_in_prompt`` knob, defaulting on."""
    return bool(knob(cfg, "think_in_prompt", True))


def _json_schema_of(response_model: type) -> dict[str, object]:
    """Lower a pydantic ``response_model`` to a plain schema dict for a ``json_schema`` kwarg."""
    # ``$schema`` goes: CLI rejects newer dialects at STARTUP; inlined so cli never pulls the SDK
    schema = dict(response_model.model_json_schema())
    schema.pop("title", None)
    schema.pop("$schema", None)
    return schema


def dispatch_prompt(
    user_prompt: str | list[dict[str, object]],
    *,
    model: object,
    cfg: object,
    cwd: str,
    system_prompt: str | None = None,
    max_tokens: int | None = None,
    tag: str | None = None,
    graph_name: str = DEFAULT_GRAPH_NAME,
    response_model: type | None = None,
    tool_builder: ToolBuilder | None = None,
    fact_tools: Sequence[str] = (),
    parent_middleware: tuple[AgentMiddleware, ...] = (),
    max_turns: int | None = None,
    effort: str | None = None,
    **legacy_kw: object,
) -> str:
    """Route a single-turn completion by the model's resolved ``via``."""
    # deepagents-only kwargs TypeError on registry.prompt; thinking → dispatch_or_retry_unforced
    via = resolve(model).via
    if via != "deepagents":
        if tool_builder is not None or fact_tools or parent_middleware:
            warn_once(
                _WARNED_LEGACY_KW, f"prompt_no_tools:{via}",
                f"WARN [{via}]: dispatch_prompt has no tool seam on this route — "
                f"tool_builder/fact_tools/parent_middleware are accepted but ignored.")
        if effort is not None:
            legacy_kw["effort"] = effort
        if response_model is not None:
            if via in ("cli", "openai"):
                # Raising here made S7/S8 fall back to free text or lose the unit
                legacy_kw["json_schema"] = _json_schema_of(response_model)
            elif via == "sdk":
                legacy_kw["response_model"] = response_model
            else:
                raise ValueError(
                    f"dispatch_prompt: response_model is not supported on "
                    f"via={via!r} (only deepagents/sdk/cli/openai)"
                )
        return registry.prompt(
            user_prompt, model=model, system_prompt=system_prompt,
            max_tokens=max_tokens, tag=tag, **legacy_kw,
        )
    # `timeout` binds on this leg too: prompt() threads it to _run_sync. 0/negative means "no
    # timeout", not "abort immediately" — same convention as dispatch_agentic's deepagents leg.
    timeout = legacy_kw.pop("timeout", None)
    timeout = timeout if (timeout is not None and timeout > 0) else None
    prefix = _screen_legacy_kwargs(legacy_kw)
    sdk_cfg, openai_cfg, cfg_dir = _cfg_blocks(cfg)
    return prompt(
        user_prompt, model=model, system_prompt=system_prompt,
        max_tokens=max_tokens, cwd=cwd, tag=tag, graph_name=graph_name,
        sdk_cfg=sdk_cfg, openai_cfg=openai_cfg, cfg_dir=cfg_dir,
        cache_prefix=prefix or None, response_model=response_model,
        tool_builder=tool_builder, fact_tools=fact_tools,
        parent_middleware=parent_middleware, max_turns=max_turns, effort=effort,
        timeout=timeout,
        # Without this, a one-shot leg still thinks adaptively and spends most of its output
        # budget on reasoning; dispatch_agentic reads the same knob.
        think_in_prompt=think_in_prompt_enabled(cfg),
    )


def route_carries_tools(cfg: object, via: str, *,
                        agentic: bool = True) -> tuple[bool, str]:
    """Whether :func:`dispatch_agentic`/:func:`dispatch_prompt` will actually DELIVER a caller ``tool_builder``..."""
    # The single truth table for every stage's tool gate (preflight/s2/s6 each had a drifting copy)
    if not agentic and via != "deepagents":
        # dispatch_prompt's one-shot leg has no tool seam on any route but deepagents (see its WARN)
        return False, "dispatch_prompt has no tool seam on this route"
    if via == "deepagents":
        return True, ""
    if via in ("sdk", "openai"):
        return True, ""
    if via == "cli":
        if not knob(cfg, "cli.mcp_tools", True):
            return False, "cli.mcp_tools is off"
        from vvaharness.backends.llm import cli_mcp  # noqa: PLC0415 — lazy: optional SDK
        if not cli_mcp.available():
            return False, ("the Claude Agent SDK the via: cli tool bridge needs is "
                           "not importable")
        return True, ""
    return False, f"via: {via} has no tool seam"


def droppable_effort(model: object, effort: str | None, *, agentic: bool) -> str | None:
    """*effort* when a ``drop_thinking`` resend on *model*'s route sends no effort/thinking."""
    # The wire then carries no tier: always-on models still think at their default effort (high;
    # medium on Opus 5.5), models that are off by default stop thinking (digest 4.3).
    if effort is None:
        return None
    _model_id, via, extras = resolve(model)
    # via: cli folds a None per-call effort back to the process-global cli.effort (never None), and
    # registry.prompt merges a node's thinking_budget into a one-shot sdk call, which keeps a
    # thinking field on without a tier -- either way the resend would still carry a thinking/effort
    # field, so there is nothing to drop.
    if via == "cli" or (via == "sdk" and not agentic and "thinking_budget" in extras):
        return None
    return effort


#: Per-class truth about what a drop actually costs; keeps both WARN sites in one place.
_MODEL_CALL_BUDGET_CLAUSE: Final = (
    "`max_model_calls` does not bound this session on this route — `max_turns` does")
_EVIDENCE_GATE_NO_STACK_CLAUSE: Final = (
    "the evidence gate's tool-call requirement cannot apply with no tool stack")
_DROP_CLAUSES: Final = {
    "ModelCallBudget": _MODEL_CALL_BUDGET_CLAUSE,
    "EvidenceGate": _EVIDENCE_GATE_NO_STACK_CLAUSE,
}


def _stage_of(tag: str | None) -> str:
    """The stage name a WARN key is scoped to, from the caller's own tag convention."""
    return (tag or "").split()[0] if tag else ""


def _warn_dropped_middleware(parent_middleware: tuple[AgentMiddleware, ...], *,
                             via: str, tag: str | None) -> None:
    """Name a dropped ModelCallBudget/EvidenceGate; a lone RecordTranscript stays silent."""
    if not parent_middleware:
        return
    from vvaharness.backends.harness.deepagents.evidence_gate import (  # noqa: PLC0415 — lazy: pulls langchain
        EvidenceGate,
    )
    from vvaharness.backends.harness.deepagents.model_call_budget import (  # noqa: PLC0415 — lazy: pulls langchain
        ModelCallBudget,
    )

    gated = [mw for mw in parent_middleware if isinstance(mw, (ModelCallBudget, EvidenceGate))]
    if not gated:
        return
    classes = sorted({type(mw).__name__ for mw in gated})
    names = ", ".join(classes)
    tail = "; ".join(_DROP_CLAUSES[c] for c in classes)
    warn_once(
        _WARNED_LEGACY_KW, f"middleware_dropped:{via}:{_stage_of(tag)}",
        f"WARN [deepagents]: via={via} drops {names} (no tool stack on this "
        f"leg); {tail}.")


def _warn_model_call_budget_not_metered(parent_middleware: tuple[AgentMiddleware, ...], *,
                                        via: str, tag: str | None) -> None:
    """Once per (via, stage): a tool stack meters EvidenceGate but never ModelCallBudget."""
    from vvaharness.backends.harness.deepagents.model_call_budget import (  # noqa: PLC0415 — lazy: pulls langchain
        ModelCallBudget,
    )

    if not any(isinstance(mw, ModelCallBudget) for mw in parent_middleware):
        return
    warn_once(
        _WARNED_LEGACY_KW, f"middleware_dropped_with_stack:{via}:{_stage_of(tag)}",
        f"WARN [deepagents]: via={via} does not meter ModelCallBudget on this "
        f"leg; {_MODEL_CALL_BUDGET_CLAUSE}.")


def _adapt_tools(tool_builder: ToolBuilder | None, *, model_id: str, cwd: str,
                 fact_tools: Sequence[str],
                 parent_middleware: tuple[AgentMiddleware, ...],
                 legacy_kw: dict[str, object], tag: str | None, via: str):
    """Materialise the caller's fact tools into ``sdk``/``openai`` agentic kwargs."""
    # None warns, never silent; extra_tools/extra_dispatch must be CHAINED — exploit verif uses them
    if tool_builder is None or not fact_tools:
        _warn_dropped_middleware(parent_middleware, via=via, tag=tag)
        return None
    from vvaharness.backends.llm import tool_adapter  # noqa: PLC0415 — lazy: pulls langchain

    stack = tool_adapter.build(tool_builder, model=model_id, cwd=cwd,
                               fact_tools=fact_tools,
                               parent_middleware=parent_middleware)
    if stack is None:
        warn_once(
            _WARNED_LEGACY_KW, f"adapter_no_tools:{via}:{tag or ''}",
            f"WARN [{via}]: {tag or 'this stage'} supplied a tool_builder for "
            f"{sorted(fact_tools)} but it produced no tools (the fact they read is "
            f"absent — e.g. no code graph was built) — running without them.")
        return None
    _warn_model_call_budget_not_metered(parent_middleware, via=via, tag=tag)
    caller_tools = list(legacy_kw.get("extra_tools") or [])
    caller_dispatch = legacy_kw.get("extra_dispatch")
    legacy_kw["extra_tools"] = [*stack.schemas, *caller_tools]

    def _dispatch(name: str, args: dict):
        out = stack.dispatch(name, args, tag=tag)
        if out is not None:
            return out
        return caller_dispatch(name, args) if caller_dispatch is not None else None

    legacy_kw["extra_dispatch"] = _dispatch
    # The guard delegates to the caller's own EvidenceGate, so limits/counters are shared
    legacy_kw["submit_guard"] = stack.submit_guard
    # Withdraws an exhausted tool from `tools`: a bare refusal had models re-asking for turns
    legacy_kw["exhausted_tools"] = stack.exhausted_tools
    return stack


def _resume_agentic_deepagents(session_id: str, instruction: str, *, model: object,
                               tag: str | None, timeout: float | None) -> str:
    """The deepagents leg of resume_agentic: APPEND one more turn to the checkpointed thread."""
    # The whole point: LangGraph reloads this thread's checkpointed messages and APPENDS, so the
    # prior turns are in context and still prompt-cached. dispatch_prompt cannot express this --
    # _flatten_blocks collapses any message list into a single new user turn.
    held = _streaming_options_of(session_id)
    if held is None:
        raise SessionNotResumableError(
            f"session {session_id!r} was never pinned or has been released")
    # <= 0 is no clock: a 0 reaching _run_sync is an instant VVAH-E008
    timeout = timeout if (timeout is not None and timeout > 0) else None
    session_timeout = effort_scaled_seconds(timeout, held.effort, kind=ClockKind.SESSION)
    # A raising budget is already past its forced final turn; ungranted, the resume hits VVAH-E007
    for mw in held.parent_middleware:
        grant = getattr(mw, "grant_resume_turn", None)
        if grant is not None:
            grant()
    terminal = _call_classified(
        lambda remaining: drain_resume(instruction, held, tag=tag, timeout=remaining),
        model_id=resolve(model).model_id, tag=tag, budget=session_timeout)
    raise_if_refused(terminal, tag=tag)
    return terminal_text(terminal)


def resume_agentic(session_id: str, instruction: str, *, model: object, cfg: object,
                   tag: str | None = None, timeout: float | None = None) -> str:
    """Continue *session_id*'s stopped session with *instruction*, on whichever route owns it.

    The route stops its own session before the stage deadline (deadline_bound); this is the
    stage's one resume of it, dispatched by the model's resolved via. A route with no resume
    yet raises SessionNotResumableError, so resume_or_replay falls back to a transcript replay.
    """
    via = resolve(model).via
    if via == "cli":
        return _cli.session.resume_agentic(session_id, instruction, timeout=timeout, tag=tag)
    if via == "deepagents":
        return _resume_agentic_deepagents(session_id, instruction, model=model, tag=tag,
                                          timeout=timeout)
    raise SessionNotResumableError(f"resume_agentic: no session to resume on via={via!r}")


def dispatch_agentic(
    user_prompt: str,
    *,
    model: object,
    cfg: object,
    cwd: str,
    system_prompt: str | None = None,
    allowed_tools: Sequence[str] | None = None,
    max_turns: int | None = None,
    max_budget_usd: float | None = None,
    tag: str | None = None,
    graph_name: str = DEFAULT_GRAPH_NAME,
    tool_builder: ToolBuilder | None = None,
    fact_tools: Sequence[str] = (),
    response_model: type | None = None,
    parent_middleware: tuple[AgentMiddleware, ...] = (),
    max_output_tokens: int | None = None,
    skill_root: Path | None = None,
    effort: str | None = None,
    agents: dict[str, object] | None = None,
    allow_shell: bool = False,
    session_id: str = "",
    **legacy_kw: object,
) -> str:
    """Route a tool-using loop by the model's resolved ``via``."""
    # Middleware approximated off-loop (todos/subagents deepagents-only); max_turns 40 ≈ 470 here
    via = resolve(model).via
    if via != "deepagents":
        mcp_bridged = (via == "cli" and tool_builder is not None and fact_tools
                       and knob(cfg, "cli.mcp_tools", True))
        tokens = int(max_output_tokens) if max_output_tokens else None
        if tokens:
            tokens = clamp_output_tokens(tokens, model, tag=tag)
        if response_model is not None:
            if via == "cli":
                legacy_kw["json_schema"] = _json_schema_of(response_model)
            elif via in ("sdk", "openai"):
                # Raising here would lose S4 units as unparseable prose
                legacy_kw["response_model"] = response_model
            else:
                raise ValueError(
                    f"dispatch_agentic: response_model is not supported on "
                    f"via={via!r} (only deepagents/sdk/openai/cli)"
                )
        if mcp_bridged:
            from vvaharness.backends.llm import cli_mcp  # noqa: PLC0415 — lazy: needs the Agent SDK

            # `timeout` isn't in _ACCEPTED_UNUSED_KW (every route pops/binds it itself), so it
            # must come out BEFORE _screen_legacy_kwargs below, or the screen spuriously warns
            # it unsupported even though it's bound into the call two lines down.
            timeout = legacy_kw.pop("timeout", None)
            # cache_prefix carries real prompt content (app profile/threat-model context) —
            # recover it before the explicit pops below, or it is silently dropped on this leg
            bridge_prefix = _screen_legacy_kwargs(legacy_kw, route="cli")
            if bridge_prefix:
                # No cache-marker concept on this leg: always fold in, never a separate block
                user_prompt = bridge_prefix + user_prompt
            # `stream_cb` is cli.py's raw stream-json sink; the bridge's typed events break it
            legacy_kw.pop("stream_cb", None)
            legacy_kw.pop("permission_mode", None)   # the bridge's gate owns policy
            # The bridge re-lowers it itself (cli_mcp._schema_for), so drop the precomputed dict
            legacy_kw.pop("json_schema", None)
            return cli_mcp.agentic_with_tools(
                user_prompt, model=resolve(model).model_id,
                system_prompt=system_prompt, allowed_tools=allowed_tools,
                cwd=cwd, tool_builder=tool_builder, fact_tools=fact_tools,
                parent_middleware=parent_middleware, max_turns=max_turns,
                max_budget_usd=max_budget_usd, max_tokens=tokens, effort=effort,
                allow_shell=allow_shell,
                response_model=response_model, tag=tag,
                timeout=timeout,
            )
        if via == "cli" and (skill_root is not None or allow_shell):
            # Reached only on the plain leg: the cli_mcp bridge above already returned
            warn_once(
                _WARNED_LEGACY_KW, "cli_skill_root_allow_shell",
                f"WARN [cli]: {tag or 'this stage'} configured skill_root/allow_shell, "
                f"but the plain via: cli leg forwards neither — not enforced on this route.")
        if via == "cli" and effort is not None:
            # Plain cli leg only: per-call `effort` overrides the process-global `cli.effort`
            legacy_kw["effort"] = effort
        if via == "cli" and tokens:
            legacy_kw["max_tokens"] = tokens
        if via == "cli" and session_id:
            # Only the plain leg's cli.agentic takes session_id; sdk/openai agentic do not
            legacy_kw["session_id"] = session_id
        if via == "cli":
            # The plain leg carries no tool stack, so parent_middleware never reaches a model call.
            _warn_dropped_middleware(parent_middleware, via=via, tag=tag)
        stack = None
        if via in ("sdk", "openai"):
            if tokens:
                legacy_kw["max_output_tokens"] = tokens
            # Re-add to `legacy_kw`: as a named param, `step*.effort` looked applied and was not
            legacy_kw["effort"] = effort
            stack = _adapt_tools(
                tool_builder, model_id=resolve(model).model_id, cwd=cwd,
                fact_tools=fact_tools, parent_middleware=parent_middleware,
                legacy_kw=legacy_kw, tag=tag, via=via)
        text = registry.agentic(
            user_prompt, model=model, system_prompt=system_prompt,
            allowed_tools=allowed_tools, cwd=cwd, max_budget_usd=max_budget_usd,
            max_turns=max_turns, tag=tag, **legacy_kw,
        )
        if stack is not None:
            stack.report_evidence_degradation(tag=tag or "", label=via)
        return text
    # `timeout` binds here too: agentic() threads it to drain_streaming -> _run_sync ->
    # future.result. 0/negative means "no timeout", not "abort immediately" — same convention as
    # step6_verify.batch_wall_clock_ceiling.
    timeout = legacy_kw.pop("timeout", None)
    timeout = timeout if (timeout is not None and timeout > 0) else None
    prefix = _screen_legacy_kwargs(legacy_kw)
    sdk_cfg, openai_cfg, cfg_dir = _cfg_blocks(cfg)
    return agentic(
        user_prompt,
        model=model, system_prompt=system_prompt,
        allowed_tools=allowed_tools, cwd=cwd, max_budget_usd=max_budget_usd,
        max_turns=max_turns, tag=tag, graph_name=graph_name,
        sdk_cfg=sdk_cfg, openai_cfg=openai_cfg, cfg_dir=cfg_dir,
        tool_builder=tool_builder, fact_tools=fact_tools, response_model=response_model,
        parent_middleware=parent_middleware,
        # Its own block, not prepended: the marker seam is what makes a sibling prefix cacheable
        cache_prefix=prefix or None,
        max_output_tokens=max_output_tokens,
        skill_root=skill_root,
        effort=effort,
        agents=agents,
        allow_shell=allow_shell,
        timeout=timeout,
        session_id=session_id,
        think_in_prompt=think_in_prompt_enabled(cfg),
    )
