# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Pre-dispatch detection of symlinks escaping the scanned repo (CWE-59).

S10's write confinement is a permission-engine scope, not a path jail. An edit
THROUGH an escaping link never modifies the link object, so ``git status`` and
``changed_files_whole_tree`` see nothing and ``revert_files`` has no baseline —
the one S10 hazard no post-gate can observe, hence caught before the model is
handed a writer. Read-only and total: this reports, the caller refuses.
"""
from __future__ import annotations

import os
from pathlib import Path

#: Bounded like the post-gate's own worktree scan, so a huge tree cannot pin the pre-dispatch check
_SCAN_FILE_MAX = 20000
_SCAN_DIR_MAX = 20000

#: Skipped: vendored trees hold thousands of legitimate links and S10 never patches them
_SKIP_DIRS = frozenset({
    ".git", "node_modules", ".venv", "venv", "__pycache__",
    ".mypy_cache", ".pytest_cache", ".ruff_cache", ".tox",
})


def escaping_symlinks(repo: Path) -> dict[str, str]:
    """Map repo-relative symlink path -> its out-of-tree resolved target.

    Reported: any link resolving OUTSIDE *repo*, plus any link that cannot be
    shown to point at a real path inside it (dangling target, resolution loop).
    A link to an existing in-tree path is normal and is not reported.

    Never raises — an unreadable subtree yields whatever was found so far.
    """
    repo = Path(repo)
    try:
        root = repo.resolve()
    except OSError:
        return {}
    found: dict[str, str] = {}
    files_seen = 0
    dirs_seen = 0
    try:
        # followlinks=False: never descend THROUGH a link while looking for links.
        for dirpath, dirnames, filenames in os.walk(repo, followlinks=False):
            dirs_seen += 1
            if dirs_seen > _SCAN_DIR_MAX:
                break
            # A symlinked dir is itself a candidate; followlinks=False lists it without descending
            for name in list(dirnames):
                if name in _SKIP_DIRS:
                    dirnames.remove(name)
                    continue
                _record(root, repo, Path(dirpath) / name, found)
            for name in filenames:
                files_seen += 1
                if files_seen > _SCAN_FILE_MAX:
                    return found
                _record(root, repo, Path(dirpath) / name, found)
    except Exception:  # noqa: BLE001 — a best-effort scan must never break a run
        return found
    return found


def _record(root: Path, repo: Path, path: Path, out: dict[str, str]) -> None:
    """Add *path* to *out* when it is a symlink not proven to resolve inside *root*.

    ``resolve()`` is non-strict, so a dangling link yields a path that does not
    exist and looks confined. An in-tree one is still recorded: the link is
    attacker-controlled, a write would create its target, and the link can be
    swapped between this check and that write (TOCTOU).
    """
    try:
        if not path.is_symlink():
            return
    except OSError:
        return
    try:
        rel = path.relative_to(repo).as_posix()
    except ValueError:
        return
    try:
        target = path.resolve()
    except (OSError, RuntimeError):
        # A resolution loop (ELOOP) raises; it cannot be proven in-tree.
        out[rel] = _raw_target(path)
        return
    try:
        target.relative_to(root)
    except ValueError:
        out[rel] = str(target)
        return
    if not target.exists():
        out[rel] = f"{_raw_target(path)} (dangling)"


def _raw_target(path: Path) -> str:
    """The link's literal target text, for a link we could not resolve to a real path."""
    try:
        return os.readlink(path)
    except OSError:
        return "<unreadable>"


def describe_escapes(escapes: dict[str, str], limit: int = 5) -> str:
    """A bounded, single-line rendering of *escapes* for an operator message."""
    items = sorted(escapes.items())
    shown = ", ".join(f"{link} -> {target}" for link, target in items[:limit])
    if len(items) > limit:
        shown += f", … (+{len(items) - limit} more)"
    return shown


__all__ = ["describe_escapes", "escaping_symlinks"]
