# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Locates the scan report and selects findings for the ``remediate`` command."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from vvaharness.models import FinalReport
from vvaharness.models.case import FindingCase
from vvaharness.models.vocab import CaseState
from vvaharness.orchestrator.artifacts import artifact_dir
from vvaharness.orchestrator.checkpoints import run_id_for
from vvaharness.orchestrator.findings_json import (
    findings_json_path,
    read_findings_json,
)
from vvaharness.remediation_agent.report_parser import (
    REMEDIATION_DIR_NAME,
    SCAN_DIR_NAME,
    find_scan_dir,
    latest_report,
    parse_findings,
)
from vvaharness.remediation_agent.select import (
    drop_non_main_channel,
    select_top_logged,
)
from vvaharness.remediation_agent.target import RemediationTarget
from vvaharness.util import console

__all__ = ["Findings", "Layout", "completed_case_ids", "cvss_score_of",
           "load_findings", "locate_report", "prepare_layout"]

CHECKPOINTS_DIR_NAME = "checkpoints"


def _mtime(path: Path) -> float | None:
    """The artifact's mtime, or None (no cutoff) when it cannot be read."""
    try:
        return path.stat().st_mtime
    except OSError:
        return None


def locate_report(repo_path: Path) -> tuple[Path | None, int]:
    """Find the newest scan report under ``<repo>/security-scan/``, returning ``(None, exit_code)`` with the error already printed on failure."""
    scan_dir = find_scan_dir(repo_path)
    if scan_dir is None:
        console.mark("fail", f"no '{SCAN_DIR_NAME}' folder found under {repo_path} — run "
              f"`vvaharness scan --repo {repo_path}` first.", indent=2)
        return None, 1

    report = latest_report(scan_dir)
    if report is None:
        console.mark("fail", f"no scan report (*_report.md) found in {scan_dir} — run "
              f"`vvaharness scan --repo {repo_path}` first.", indent=2)
        return None, 1
    return report, 0


def cvss_score_of(target: RemediationTarget) -> float | None:
    """Numeric CVSS base score accessor for ``--top N`` selection, or ``None`` when the report carried only a vector / bare severity band."""
    return target.finding.cvss_score


@dataclass(frozen=True)
class Findings:
    """What a report yielded: the findings this run will work on (``selected``), and every one it had (``discovered``, still needed for checkpoint pruning)."""

    selected: list[RemediationTarget]
    discovered: list[RemediationTarget]


def completed_case_ids(repo_path: Path, *,
                       since: float | None = None) -> set[str]:
    """Case ids under ``<repo>/security-remediation/`` whose fix currently stands (remediated/validated)."""
    done: set[str] = set()
    for case_path in sorted(
            (repo_path / REMEDIATION_DIR_NAME).glob("*/finding_case.json")):
        try:
            if since is not None and case_path.stat().st_mtime < since:
                continue
            case = FindingCase.model_validate_json(
                case_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if case.state in (CaseState.REMEDIATED, CaseState.VALIDATED):
            done.add(case.case_id)
    done.discard("")
    return done


def _targets_from_typed(report: FinalReport,
                        done: set[str]) -> list[RemediationTarget]:
    """Adapter: the typed report's findings as remediation targets."""
    # Ordinals precede the posture drop, matching to_markdown ### N.; posture leaves discovered too
    targets = []
    for i, rf in enumerate(report.findings, 1):
        f = rf.finding
        f.severity = rf.severity
        t = RemediationTarget(finding=f, index=i)
        t.done = t.case_id in done
        targets.append(t)
    return drop_non_main_channel(targets, log_prefix="[Remediation Agent]")


def load_findings(repo_path: Path, report: Path, top: int | None) -> Findings:
    """Targets for *repo_path*, narrowed to the N highest-CVSS when ``top`` is set."""
    # Invalid findings.json raises InvalidFindingsJSON, no silent MD fallback; mtime gates done
    typed = read_findings_json(repo_path)
    done = completed_case_ids(
        repo_path,
        since=_mtime(findings_json_path(repo_path) if typed is not None
                     else report))
    if typed is not None:
        console.write("  [Remediation Agent] source: findings.json (typed scan result)")
        discovered = _targets_from_typed(typed, done)
    else:
        console.write("  [Remediation Agent] source: legacy Markdown parse "
                      "(this checkout has no findings.json — older scan)")
        discovered = parse_findings(report.read_text(encoding="utf-8"))
        for t in discovered:
            t.done = t.done or t.case_id in done
    selected = select_top_logged(discovered, top, score_of=cvss_score_of,
                                 log_prefix="[Remediation Agent]")
    return Findings(selected=selected, discovered=discovered)


@dataclass(frozen=True)
class Layout:
    """Resolved per-repo output + checkpoint locations for one remediation run."""
    rem_dir: Path
    ckpt_dir: Path
    run_id: str


def prepare_layout(repo_path: Path) -> Layout:
    """Resolve (and create) the per-repo remediation output dir, reusing the scan pipeline's ``<repo>/checkpoints`` folder rather than a private one.

    Raises ``UnsafeArtifactDir`` (via ``artifact_dir``) rather than following a
    committed symlink that would redirect remediation artefacts outside the repo.
    """
    rem_dir = artifact_dir(repo_path, REMEDIATION_DIR_NAME)
    rem_dir.mkdir(exist_ok=True)
    return Layout(
        rem_dir=rem_dir,
        ckpt_dir=repo_path / CHECKPOINTS_DIR_NAME,
        run_id=run_id_for(repo_path),
    )
