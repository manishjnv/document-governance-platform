# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Limits the step 8 enrichment call to a deterministic rank prefix of findings plus a same-file pull-in."""
from __future__ import annotations
from vvaharness.util import logs

import json

from vvaharness.models import ContextPackage, Finding, Severity
from vvaharness.models.vocab import SEV_RANK
from vvaharness.pipeline.stages.s8.outcomes import (
    ChainReport,
    final_severity,
    offensive_rank,
)
from vvaharness.pipeline.stages.s8.prompts import (
    SYSTEM,
    build_prompt,
    facts_enabled,
    finding_block,
    hop_text_enabled,
    repo_fact_blocks,
)
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.tokens import estimate_tokens
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

# 100 tok/entry over-prices a typical entry against mid-JSON truncation; the reserve covers rest
_OUT_RESERVE = 1500
_TOKENS_PER_ENTRY = 100
# Schema is outside build_prompt, so an under-estimate over-admits findings; +250 for provider wrap
_SCHEMA_TOKENS = estimate_tokens(
    json.dumps(ChainReport.model_json_schema())) + 250
# The ceiling sits above the typical pull-in overshoot.
_PULLIN_CEILING = 1.25

_PULLIN_BANDS = (Severity.MEDIUM, Severity.LOW, Severity.INFO)


def _floor_order(findings: list[Finding]) -> list[int]:
    """Returns finding indices ordered by the floor pass's (severity band, OffensivePriority) key, without mutating findings."""
    # Windowing precedes enrichment, so the carried s4 severity is the fallback; INFO would discard
    return sorted(
        range(len(findings)),
        key=lambda i: (SEV_RANK[final_severity(findings[i], findings[i].severity)],
                       offensive_rank(findings[i])))


def half_window(findings: list[Finding], window: list[int]) -> list[int]:
    """The stronger half of *window*, by the floor pass's rank-prefix order; original indices,
    sorted. Used for the one resend after an at-cap clip: a smaller input, not a dropped tier."""
    sub = [findings[i] for i in window]
    order = _floor_order(sub)
    half_n = max(1, len(order) // 2)
    return sorted(window[k] for k in order[:half_n])


def select_window(findings: list[Finding], ctx: ContextPackage,
                  cfg) -> list[int]:
    """Returns the original indices to send to the enrichment call, in original order: all of them unless the prompt or output budget forces a rank prefix."""
    n = len(findings)
    budget = int(knob(cfg, "step8.prompt_token_budget", 100000) or 100000)
    max_out = int(knob(cfg, "step8.max_tokens", 64000) or 64000)
    k_out = max((max_out - _OUT_RESERVE) // _TOKENS_PER_ENTRY, 1)

    # Resolved as build_prompt does, or the estimate prices a different prompt than session.py sends
    facts_on = facts_enabled(cfg)
    hop_text = hop_text_enabled(cfg)
    block_costs = [
        estimate_tokens(finding_block(f"f{i}", findings[i], ctx, facts_on,
                                      hop_text))
        for i in range(n)]
    scaffold = build_prompt([], ctx, labels=[], cfg=cfg)
    # Priced over all n on purpose: repo facts only shrink, so overshooting just sends less
    repo_facts = repo_fact_blocks(findings, ctx, [f"f{i}" for i in range(n)],
                                  facts_on)
    fixed = (estimate_tokens(SYSTEM) + estimate_tokens(scaffold)
             + estimate_tokens(repo_facts) + _SCHEMA_TOKENS)

    if fixed + sum(block_costs) <= budget and n <= k_out:
        return list(range(n))

    order = _floor_order(findings)
    included: list[int] = []
    total = fixed
    for i in order:
        # Break, not skip: the window must stay a strict rank prefix so chains cite in-window ids
        if len(included) >= k_out or total + block_costs[i] > budget:
            break
        included.append(i)
        total += block_costs[i]

    # One pass (no transitive closure); recovers same-file MEDIUM hops that chains often depend on
    included_set = set(included)
    seed_files = {findings[i].file for i in included}
    pullins = 0
    for i in order:
        if i in included_set or len(included) >= k_out:
            continue
        f = findings[i]
        if (final_severity(f, f.severity) in _PULLIN_BANDS
                and f.file in seed_files
                and total + block_costs[i] <= budget * _PULLIN_CEILING):
            included.append(i)
            included_set.add(i)
            total += block_costs[i]
            pullins += 1

    excluded = n - len(included)
    if not excluded:
        # The model sees the full report, so this is no windowing event: no counters, no warning
        return sorted(included)
    COUNTERS.bump("s8_findings_windowed", excluded)
    if pullins:
        COUNTERS.bump("s8_windowed_pullins", pullins)

    by_band: dict[str, list[int]] = {}
    for i in range(n):
        band = final_severity(findings[i], findings[i].severity).value
        by_band.setdefault(band, [0, 0])[0 if i in included_set else 1] += 1
    bands = "  ".join(f"{b}:{inc}/{inc + exc}"
                      for b, (inc, exc) in sorted(by_band.items()))
    log.warning(Event.S8_ENRICHMENT_WINDOWED, sent=len(included), findings=n, pullins=pullins,
                est_tokens=total, budget=budget, pullin_ceiling=_PULLIN_CEILING, k_out=k_out,
                bands=bands)

    return sorted(included)
