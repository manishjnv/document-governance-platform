#!/usr/bin/env python3
# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Application context → contextual severity: CMDB lookup, environmental CVSS 3.1, OffensivePriority."""
from __future__ import annotations
from vvaharness.util import logs

import csv
import os
import re
from dataclasses import dataclass

from vvaharness.report import cvss
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

csv.field_size_limit(2**31 - 1)


# SAST temporal preset: E=Proof-of-Concept, RL=Official-fix, RC=Confirmed.
SAST_E, SAST_RL, SAST_RC = "P", "O", "C"

KW_CODE_KNOWLEDGE = (
    "source code is accessible", "access to the source", "access to the repo",
    "read access to the repo", "decompil", "reverse engineer",
    "if the attacker knows", "knowing the function", "knowledge of the source",
    "internal function name", "would need to know",
    "hardcoded credential", "hardcoded password", "hardcoded secret",
    "hardcoded token", "hard-coded credential", "hard-coded password",
    "hard-coded secret", "credential in source", "secret in source",
    "test credential", "qa credential", "qa password", "test password",
    "encryption key in source", "key hardcoded",
)
KW_INTERNAL = (
    "internal network", "intranet", "corporate network", "internal-only",
    "internal only", "back-office", "corporate sso", "enterprise sso",
    "enterprise idp", "behind sso", "behind the idp",
    "loopback", "127.0.0.1", "localhost", "local listener", "local user",
    "local access", "same host", "on the host",
    "service-to-service", "mtls", "behind api gateway", "behind the gateway",
    "vpn", "external partner", "third-party provisioned", 
    "log access", "db access", "database access",
    "mitm", "man-in-the-middle", "man in the middle",
    "compromised server", "compromise of", "control of the",
    "physical access", "adjacent network",
)
KW_HIGH_PRIV = (
    "super_admin", "super admin", "system_admin", "dist_admin",
    "with admin", "as an admin", "an admin user", "admin role",
    "privileged user", "privileged account",
    "requires admin", "admin-only", "admin privileges",
)
KW_OBTAINABLE_AUTH = (
    "self-registration", "self-registered", "self registration",
    "free signup", "sign up for", "any registered user",
    "any authenticated user", "any user account", "any valid user",
    "developer account", "portal user", "merchant account",
    "low-privilege user", "low privilege user", "lowest role",
)
KW_NO_AUTH = (
    "unauthenticated", "no authentication", "without authentication",
    "no auth required", "without auth", "pre-auth", "anonymous",
    "no credentials", "without credentials", "[allowanonymous]",
    "allowanonymous", "publicly accessible", "public endpoint",
)


# CMDB
@dataclass
class AppInfo:
    id: str = ""
    name: str = ""
    externally_facing: bool = False
    pci_scoped: bool = False
    processes_pan: bool = False
    pii: bool = False
    ext_raw: str | None = None
    pci_raw: str | None = None
    pan_raw: str | None = None
    pii_raw: str | None = None
    parent_app_id: str | None = None
    source: str = "application"

    def cr(self) -> str:
        return "H" if (self.pci_scoped or self.processes_pan or self.pii) else "M"

    def ir(self) -> str:
        return "H" if (self.pci_scoped or self.processes_pan) else "M"

    def ar(self) -> str:
        return "M"

    def mav(self, base_av: str) -> str:
        return "A" if (not self.externally_facing and base_av == "N") else base_av

    def env_summary(self) -> str:
        return f"CR:{self.cr()}/IR:{self.ir()}/AR:{self.ar()} extFacing={self.externally_facing}"


def _yes(v: str | None) -> bool:
    return v is not None and v.strip().lower() == "yes"


def _nz(v: str | None) -> str | None:
    if v is None:
        return None
    v = v.strip()
    return v or None


def normalize_app_id(app_id: str | None) -> str | None:
    if app_id is None:
        return None
    s = re.sub(r"^0+", "", app_id.strip())
    return s or "0"


def _csv_col(hdr: dict, *names: str) -> int:
    for n in names:
        i = hdr.get(n.lower())
        if i is not None:
            return i
    return -1


def _cmdb_enrichment_differs(x: AppInfo, y: AppInfo) -> bool:
    """True when two CMDB rows colliding on ``normalize_app_id`` carry different enrichment signal."""
    for f in ("externally_facing", "pci_scoped", "processes_pan", "pii"):
        if getattr(x, f) != getattr(y, f):
            return True
    return normalize_app_id(x.parent_app_id) != normalize_app_id(y.parent_app_id)


def load_cmdb_csv(path: str) -> dict[str, AppInfo]:
    out: dict[str, AppInfo] = {}
    if not path or not os.path.isfile(path):
        return out
    with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
        reader = csv.reader(fh)
        # cmdb.csv carries an Apache-2.0 block, so skip comments before the first DATA row
        header = None
        for row in reader:
            if not row:
                continue
            first = (row[0] or "").lstrip()
            if first.startswith("#") or not any((c or "").strip() for c in row):
                continue
            header = row
            break
        if header is None:
            return out
        hdr = {h.strip().lower(): i for i, h in enumerate(header)}
        i_id = _csv_col(hdr, "id")
        i_name = _csv_col(hdr, "name")
        i_ext = _csv_col(hdr, "externally_facing")
        i_pci = _csv_col(hdr, "pci")
        i_pan = _csv_col(hdr, "pan")
        i_pii = _csv_col(hdr, "pii")
        i_par = _csv_col(hdr, "parent_id")
        if i_id < 0:
            raise ValueError(f"CMDB CSV missing 'id' column: {path}")

        def at(row, i):
            return row[i] if 0 <= i < len(row) else None

        for row in reader:
            rid = at(row, i_id)
            if not rid or not rid.strip():
                continue
            a = AppInfo()
            a.id = rid.strip()
            a.name = at(row, i_name) or ""
            # Blank must stay None, not False: that is what lets a child inherit via parent_id
            a.ext_raw = _nz(at(row, i_ext))
            a.pci_raw = _nz(at(row, i_pci))
            a.pan_raw = _nz(at(row, i_pan))
            a.pii_raw = _nz(at(row, i_pii))
            a.externally_facing = _yes(a.ext_raw)
            a.pci_scoped = _yes(a.pci_raw)
            a.processes_pan = _yes(a.pan_raw)
            a.pii = _yes(a.pii_raw)
            a.parent_app_id = _nz(at(row, i_par))
            key = normalize_app_id(a.id)
            prior = out.get(key)
            if prior is not None and _cmdb_enrichment_differs(prior, a):
                # Last-wins is deliberate; '042' vs '42' collide, so warn with BOTH raw ids
                log.warning(Event.APPCONTEXT_KEY_COLLISION, app_id=a.id, key=key, prior_id=prior.id,
                            prior=prior.env_summary(), current=a.env_summary(),
                            remedy="disambiguate the CMDB to avoid severity-enrichment drift")
            out[key] = a
    return out


def _pick(own: AppInfo | None, parent: AppInfo | None,
          raw: str, val: str) -> bool:
    if own is not None and getattr(own, raw) is not None:
        return getattr(own, val)
    if parent is not None:
        return getattr(parent, val)
    return own is not None and getattr(own, val)


def _merge_with_parent(base: AppInfo, own: AppInfo | None,
                       parent: AppInfo | None, source: str) -> AppInfo:
    r = AppInfo()
    r.id = base.id
    r.name = base.name
    r.parent_app_id = own.parent_app_id if own else base.parent_app_id
    r.source = source
    r.externally_facing = _pick(own, parent, "ext_raw", "externally_facing")
    r.pci_scoped = _pick(own, parent, "pci_raw", "pci_scoped")
    r.processes_pan = _pick(own, parent, "pan_raw", "processes_pan")
    r.pii = _pick(own, parent, "pii_raw", "pii")
    return r


def lookup_app(app_id: str, cmdb: dict[str, AppInfo],
               cmdb_comp: dict[str, AppInfo]) -> AppInfo | None:
    if not app_id:
        return None
    key = normalize_app_id(app_id)
    a = cmdb.get(key)
    c = cmdb_comp.get(key)

    if a is not None:
        any_blank = (a.pci_raw is None or a.pan_raw is None
                     or a.pii_raw is None or a.ext_raw is None)
        parent_id = a.parent_app_id or (c.parent_app_id if c else None)
        if any_blank and parent_id:
            p = cmdb.get(normalize_app_id(parent_id))
            if p and normalize_app_id(p.id) != key:
                return _merge_with_parent(a, a, p, f"application->parent {p.id}")
        a.source = "application"
        return a

    if c is None:
        return None
    p = cmdb.get(normalize_app_id(c.parent_app_id)) if c.parent_app_id else None
    return _merge_with_parent(
        c, c, p, f"component->parent {p.id}" if p else "component"
    )


# CVSS 3.1 environmental scoring; every metric weight comes from report/cvss.py, never redeclared here
def parse_vector(vector: str) -> dict[str, str]:
    m: dict[str, str] = {}
    for part in vector.split("/"):
        if ":" in part:
            k, v = part.split(":", 1)
            m[k.strip().upper()] = v.strip().upper()
    return m


@dataclass
class VsvsResult:
    vector: str
    score: float
    rating: str


def _env_vector(base: str, mav: str, app: AppInfo) -> str:
    prefix = base if base.startswith("CVSS:") else f"CVSS:3.1/{base}"
    return (f"{prefix}/E:{SAST_E}/RL:{SAST_RL}/RC:{SAST_RC}"
            f"/CR:{app.cr()}/IR:{app.ir()}/AR:{app.ar()}/MAV:{mav}")


def vsvs_score(base_vector: str | None, app: AppInfo | None) -> VsvsResult | None:
    if not base_vector or app is None:
        return None
    m = parse_vector(base_vector)
    av, ac, pr, ui = m.get("AV"), m.get("AC"), m.get("PR"), m.get("UI")
    s, c, i, a = m.get("S"), m.get("C"), m.get("I"), m.get("A")
    if None in (av, ac, pr, ui, s, c, i, a):
        return None
    mav = app.mav(av)
    scope_changed = s == "C"
    mav_v = cvss.AV.get(mav, cvss.NO_SCORE)
    ac_v = cvss.AC.get(ac, cvss.NO_SCORE)
    pr_v = (cvss.PR_SCOPE_CHANGED if scope_changed
            else cvss.PR_SCOPE_UNCHANGED).get(pr, cvss.NO_SCORE)
    ui_v = cvss.UI.get(ui, cvss.NO_SCORE)
    c_v, i_v, a_v = (cvss.CIA.get(x, cvss.NO_SCORE) for x in (c, i, a))
    cr_v, ir_v, ar_v = (cvss.REQ.get(x, cvss.NEUTRAL_WEIGHT)
                        for x in (app.cr(), app.ir(), app.ar()))
    if min(mav_v, ac_v, pr_v, ui_v, c_v, i_v, a_v) < 0:
        return None
    e_v = cvss.EXPLOIT_MATURITY.get(SAST_E, cvss.NEUTRAL_WEIGHT)
    rl_v = cvss.REMEDIATION_LEVEL.get(SAST_RL, cvss.NEUTRAL_WEIGHT)
    rc_v = cvss.REPORT_CONFIDENCE.get(SAST_RC, cvss.NEUTRAL_WEIGHT)
    miss = min(1 - (1 - cr_v * c_v) * (1 - ir_v * i_v) * (1 - ar_v * a_v), cvss.MISS_CAP)
    m_impact = cvss.modified_impact(miss, scope_changed)
    if m_impact <= 0:
        return VsvsResult(_env_vector(base_vector, mav, app), 0.0, "None")
    m_exploit = cvss.EXPLOITABILITY_COEFF * mav_v * ac_v * pr_v * ui_v
    mod_base = cvss.combine(m_impact, m_exploit, scope_changed)
    env = cvss.roundup1(mod_base * e_v * rl_v * rc_v)
    return VsvsResult(_env_vector(base_vector, mav, app), env, cvss.rating(env))


# OffensivePriority
def _contains_any(haystack: str, needles) -> bool:
    return any(n in haystack for n in needles)


def offensive_priority_for(title: str, category: str | None,
                         description: str, cvss_vector: str | None,
                         app: AppInfo | None) -> tuple[str, str]:
    """Pure (priority, reason) — model-agnostic, called by pipeline._enrich_findings (post-s7)."""
    body = " ".join(x or "" for x in (title, category, description)).lower()
    v = parse_vector(cvss_vector) if cvss_vector else {}
    av = v.get("AV", "N")
    pr = v.get("PR", "L")
    pr_explicit = "PR" in v
    ac = v.get("AC", "L")

    cmdb_external = app is not None and app.externally_facing
    cmdb_internal = app is not None and not app.externally_facing

    code_knowledge = (_contains_any(body, KW_CODE_KNOWLEDGE)
                      or (category and "hardcoded" in category.lower()))
    internal_net = (cmdb_internal or av in ("A", "L", "P")
                    or _contains_any(body, KW_INTERNAL))
    high_priv = pr == "H" or _contains_any(body, KW_HIGH_PRIV)
    obtainable_auth = pr == "L" or _contains_any(body, KW_OBTAINABLE_AUTH)
    # An explicit PR:L/PR:H vetoes a stray "unauthenticated" in prose, so PR:L never reaches P1
    pr_requires_auth = pr_explicit and pr in ("L", "H")
    no_auth = (not pr_requires_auth) and (
        _contains_any(body, KW_NO_AUTH)
        or (pr == "N" and not obtainable_auth and not high_priv))
    internet_reachable = (av == "N" and not internal_net and cmdb_external)
    exposure_unknown = app is None and av == "N" and not internal_net

    why: list[str] = []
    if code_knowledge:
        prio = "P4"
        why.append("requires source-code / insider knowledge")
        if cmdb_internal:
            why.append("app not externally facing (CMDB)")
        elif av != "N":
            why.append(f"AV:{av}")
    elif exposure_unknown and not high_priv:
        prio = "P3"
        why.append("exposure unverified — no CMDB context")
        why.append(f"AV:{av} (network-routable; internet exposure unconfirmed)")
    elif not internet_reachable or high_priv:
        prio = "P3"
        if cmdb_internal:
            why.append("app not externally facing (CMDB)")
        elif av != "N":
            why.append(f"AV:{av} (non-network)")
        elif internal_net:
            why.append("internal-network position required")
        if high_priv:
            why.append("PR:H - high-privilege auth required" if pr == "H"
                       else "admin/privileged role required")
        if not why:
            why.append("internal network / privileged position required")
    elif no_auth:
        prio = "P1"
        why.append("internet-facing" + (" (CMDB)" if cmdb_external else ""))
        why.append(f"AV:{av} - unauthenticated"
                   + (f" (PR:{pr})" if pr_explicit else ""))
    else:
        prio = "P2"
        why.append("internet-facing" + (" (CMDB)" if cmdb_external else ""))
        why.append(f"PR:{pr} - auth required but obtainable")

    if ac == "H" and prio in ("P1", "P2"):
        why.append("AC:H - complex preconditions")

    return prio, "; ".join(why)


