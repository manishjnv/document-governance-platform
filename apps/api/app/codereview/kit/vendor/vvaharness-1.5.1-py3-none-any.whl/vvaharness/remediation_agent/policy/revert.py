# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Roll back forbidden-path edits on disk, confined to the repo and restored from snapshot or git."""
from __future__ import annotations

import subprocess
from pathlib import Path

from vvaharness.remediation_agent.artifacts.diff import _norm_path, _safe_repo_path
from vvaharness.util import logs
from vvaharness.util.git_paths import is_git_metadata

log = logs.get_logger(__name__)


def _is_git_worktree(repo: Path) -> bool:
    try:
        r = subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, timeout=15)
        return r.returncode == 0 and r.stdout.strip() == "true"
    except Exception:                                  # noqa: BLE001
        return False


def _is_tracked(repo: Path, rel: str) -> bool:
    try:
        r = subprocess.run(
            ["git", "-C", str(repo), "ls-files", "--error-unmatch", "--", rel],
            capture_output=True, text=True, timeout=15)
        return r.returncode == 0
    except Exception:                                  # noqa: BLE001
        return False


def revert_files(repo: Path, files: list[str],
                 before_snapshot: dict[str, str | None] | None = None) -> list[str]:
    """Roll back *files* (repo-relative) to their pre-edit state. Best-effort and never raises."""
    # Order: pre-edit snapshot, then git checkout (tracked) / delete (untracked), else leave alone
    repo = Path(repo)
    snap = before_snapshot or {}
    is_git = _is_git_worktree(repo)
    reverted: list[str] = []
    for raw in files or []:
        rel = _norm_path(raw)
        if not rel:
            continue
        # Fail closed on abs/../symlink escapes (CWE-22): LLM refs would unlink host files
        if _safe_repo_path(repo, raw) is None:
            log.warning("refusing to revert out-of-repo path %r (escapes %s)",
                        raw, repo)
            continue
        # Repository metadata is never deleted or rewritten, whatever the baseline or verdict says
        if is_git_metadata(rel):
            log.warning("refusing to revert .git-owned path %r", rel)
            continue
        p = repo / rel
        try:
            if rel in snap:
                old = snap[rel]
                if old is None:
                    if p.exists():
                        p.unlink()
                else:
                    p.write_text(old, encoding="utf-8")
                reverted.append(rel)
                continue
            if is_git:
                if _is_tracked(repo, rel):
                    subprocess.run(
                        ["git", "-C", str(repo), "checkout", "--", rel],
                        capture_output=True, text=True, timeout=30)
                elif p.exists():
                    # untracked (agent-created) → remove
                    p.unlink()
                reverted.append(rel)
        except Exception as e:                         # noqa: BLE001
            log.warning("failed to revert %s: %s", rel, e)
    return reverted
