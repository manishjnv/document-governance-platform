# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The catalogue of logged events: the member name is the stable code, the value is the sentence."""
from __future__ import annotations

from enum import StrEnum

__all__ = ["Event"]


class Event(StrEnum):
    """One member per thing worth logging; values carry no interpolation, so data goes in kwargs."""

    # ── s1: scope and the auto-exclude overlay ──────────────────────────────
    S1_OVERLAY_EMPTIES_SCOPE = "overlay would empty the scope"
    S1_OVERLAY_AGGRESSIVE = "overlay is aggressive"
    S1_OVERLAY_VETOED = "vetoed an overlay entry"
    S1_OVERLAY_VETOED_LANGUAGE = "vetoed language-wide exclusions"
    S1_CONFIG_DEDUP_VETOED = "vetoed a config_dedup setting"
    S1_MODEL_YAML_UNPARSEABLE = "model YAML did not parse; empty overlay"
    S1_AUTOEXCLUDE_FAILED = "deriving the step1 overlay failed; continuing with global step1 only"
    S1_AMBIGUOUS_PATHS_DROPPED = ("dropped unprefixed path(s) matching two or more top-level "
                                  "directories")
    S1_FRAMEWORK_ENTRY_UNRESOLVED = ("framework entry point(s) could not be resolved to in-scope "
                                     "inventory")

    # ── s2: threat model ────────────────────────────────────────────────────
    S2_CALL_FAILED = "threat-model call failed"
    S2_RESPONSE_UNPARSEABLE = "threat-model response did not parse"
    S2_RETRY_RECOVERED = "retry recovered a threat model"
    S2_BASELINE_UNDISPOSED = "baseline item(s) undisposed"
    S2_STEP_FAILED = "the threat-model step failed; continuing without it"
    S2_HOLLOW_RETRY_FAILED = "the hollow-model retry failed; keeping the first reply"
    S2_HOLLOW_RETRY_ATTEMPTED = ("hollow threat model: zero threats on a non-empty repo; "
                                 "re-asking once from the snapshot with no tools")
    S2_PARSE_REPAIR_RECOVERED = "the repair retry recovered a valid threat model"
    S2_HOLLOW_RETRY_EMPTY = ("the retry also produced nothing s3 can mint a unit from; "
                             "failing s2 rather than running s3-s8 on zero threats")
    S2_SURFACE_FILES_DROPPED = "dropped surface_files naming no in-scope file"
    S2_CAP_TRUNCATED = ("a step2 cap truncated threat-model coverage; raise the named cap in the "
                        "profile to widen it")
    S4_FINDINGS_CAPPED = "capping a unit's findings by emission order"

    # ── s6/s7/s8: verification, dedup, chain ────────────────────────────────
    S6_UNIFORM_CONFIDENCE = "every verdict shares one confidence"
    S8_CALL_FAILED = "chain LLM call failed"
    S8_NO_RANKED_FINDINGS = "reply ranked only part of the findings it was shown; shipping unranked"
    S8_WINDOW_SELECTION_FAILED = "window selection failed; sending all findings"
    S8_ENRICHMENT_WINDOWED = "enrichment windowed to fit the token budget"
    S8_RAW_PERSIST_FAILED = "could not persist the raw chain response"
    S8_RESPONSE_UNPARSEABLE = "chain response did not parse; shipping the deterministic report"
    S7_DEDUP_UNPARSEABLE = "dedup reply did not parse; keeping every finding (fail-open)"
    S7_CWE_CONFLICT_BLOCKED = "blocked cross-CWE collapse(s)"
    S8_HYDRATION_FAILED = "chain hydration failed; shipping the deterministic report"

    # ── backends: transport, TLS, capabilities ──────────────────────────────
    TLS_VERIFY_DISABLED = ("TLS verification DISABLED (verify_ssl=false) -- prompts, source "
                           "snippets, outputs and the auth header are interceptable by an active "
                           "MITM; set a CA bundle to verify a private-CA gateway instead")
    TLS_CA_NOT_FOUND = "ca_cert not found; not setting NODE_EXTRA_CA_CERTS"
    TLS_CLIENT_CERT_UNSUPPORTED = ("client_cert/mTLS is configured but this backend cannot present "
                                   "one")
    TLS_CLIENT_CHAIN_MISSING = "client chain file not found; disabling mTLS"
    TLS_CLIENT_CHAIN_UNLOADABLE = ("client_cert could not be loaded; mTLS is NOT active, continuing "
                                   "with server-authenticated TLS only")
    TLS_CA_FALLBACK = "ca_cert not found; falling back to the configured verify_ssl"
    CLI_BINARY_NOT_FOUND = "claude not found on PATH; using the bare name"
    CLI_BINARY_OVERRIDE_MISSING = "VVAHARNESS_CLAUDE_BINARY not found; falling back to PATH"
    CLI_NO_PERMISSION_MODE = "this claude build advertises no known --permission-mode value"
    CLI_PERMISSION_MODE_UNAVAILABLE = ("the requested --permission-mode is not advertised by this "
                                       "claude build")
    CLI_NO_JSON_SCHEMA = "this claude build does not advertise --json-schema"
    CLI_RESUME_FAILED = "could not resume the capped session; returning the last streamed text"
    CLI_TRANSIENT_RETRY = "transient upstream error; retrying"
    OUTPUT_CAP_LEARNED = "learned the gateway's output ceiling from its own refusal"
    OUTPUT_TOKENS_CLAMPED = "requested output tokens exceed the model's declared cap; clamped"
    TOOL_CALL_REFUSED = "refused a tool call outside this session's permitted set"
    TOOLS_UNSUPPORTED_ON_ROUTE = "tool(s) not supported on this route"
    AMBIENT_ENV_IGNORED = "ignoring an ambient env carrier; set it in the profile config instead"
    CACHE_ROUTE_UNKNOWN = "cache_route is not a known value; using auto (host detection)"
    LLM_TURN_CAP_EXHAUSTED = "agentic hit its turn cap without a final answer"
    AGENTIC_TURN_LIMIT = ("session hit its turn/recursion limit before a final answer; using the "
                          "salvaged snapshot")
    RESPONSE_MODEL_RETRY_INVALID = ("the retried structured-output call did not validate; "
                                    "deferring to the forced-final fallback")
    RESPONSE_MODEL_FORCED_FINAL_INVALID = ("the forced-final structured-output call did not "
                                           "validate; returning raw text")
    TRUNCATED_RETRY = "reply truncated at its output cap; retrying once at a higher cap"
    TOOL_ARGS_INVALID_JSON = "tool arguments were not valid JSON; the tool was not executed"
    STRUCTURED_PROSE_REASK = ("the model answered without calling the structured-output tool; "
                              "asking once more")
    STRUCTURED_SUBMIT_REJECTED = ("the structured-output submit was rejected; abandoning the "
                                  "re-ask ladder and returning the raw submit for the stage's "
                                  "own parser")
    CLI_REPLY_SPLIT_ACROSS_TURNS = ("the CLI split this reply across turns because the output "
                                    "budget was too small; the full text came from the stream, "
                                    "so raise this stage's max_tokens")
    REPLY_CLIPPED_RETRY = ("reply clipped at an output budget the route could not grow; retrying "
                           "once without the effort tier, which shares that budget")
    STRUCTURED_REPLY_REJECTED_RETRY = ("structured reply rejected; retrying once without the "
                                       "effort tier")
    MODEL_REFUSAL_RESEND = "the model refused; re-sending the identical request once"

    # ── orchestration: config, environment, checkpoints ─────────────────────
    CONFIG_POLICY_REFUSED = "configuration refused by policy"
    CONFIG_PATH_NOT_LOCAL = "path must be local; refusing network fetch"
    CONFIG_INSIDE_TARGET = "ignoring config inside the scan target; using the packaged default"
    DOTENV_UNTRUSTED = ("ignoring an untrusted .env; it must be a user-owned, "
                        "non-group/world-writable file")
    DOTENV_INSIDE_TARGET = "ignoring a .env inside the scan target"
    PYTHON_UNSUPPORTED = "this Python runtime cannot run vvaharness"
    STEP1_OVERLAY_REFUSED = "the --step1-config overlay was refused"
    STEP1_OVERLAY_NOT_FOUND = "--step1-config not found"
    REPO_NOT_A_DIRECTORY = "--repo is not a directory"
    REPO_FILE_NOT_A_FILE = "--repo-file is not a file"
    CMDB_MISSING = ("no CMDB file; VulContextSeverity environmental scoring skipped, CVSS and "
                    "OffensivePriority still computed")
    STORE_UNUSABLE = "the checkpoint store could not be used"
    STATE_DIR_REFUSED = "refusing to use state directory"
    CKPT_TOO_LARGE = "checkpoint payload exceeds the cap; not persisted"
    CKPT_STORED_TOO_LARGE = ("the stored checkpoint exceeds the cap; ignoring it and re-running "
                             "the step")
    CKPT_TARGET_CHANGED = "the target at this path changed since the checkpoint"
    CKPT_UNREADABLE = ("checkpoint payload is not valid JSON (corrupt or untrusted); re-running "
                       "the step")
    CKPT_SCHEMA_MISMATCH = ("checkpoint schema mismatch, likely an incompatible tool version; "
                            "re-running the step")
    CKPT_STAGE_DEGRADED = ("a cached stage checkpoint recorded unresolved unit failure(s); "
                           "re-running the step instead of resuming a degraded result")
    REPLAY_TOO_LARGE = "replay bundle exceeds the cap; not persisted"
    REPLAY_STORED_TOO_LARGE = "the stored replay bundle exceeds the cap; ignoring it"
    REPLAY_PRUNE_FAILED = "could not prune replay bundles"
    PURGE_LEFTOVER = "item(s) survived the purge"

    # ── orchestration: preflight, batch, scan ───────────────────────────────
    PREFLIGHT_ROUTE_UNSUPPORTED = "this route is supported only for some roles"
    PREFLIGHT_BACKENDS_UNREACHABLE = "one or more model backends unreachable; fix before scanning"
    PREFLIGHT_PROBE_FAILED = "a backend probe failed"
    PREFLIGHT_CREDENTIAL_GAP = "a credential this config needs is missing"
    PREFLIGHT_DEEPDIVE_ROUTE_TOOLLESS = ("models.deepdive routes somewhere its tools cannot "
                                         "reach, so they would silently vanish")
    PREFLIGHT_GATEWAY_UNUSABLE = "the configured gateway is not usable"
    PREFLIGHT_CACHE_PROBE_SLOW = "the prompt-cache follow-up call took longer than the target"
    PREFLIGHT_MAX_TURNS_HARD_CAPPED = ("a stage's max_turns is a HARD cap on its role's route but "
                                       "carries a deepagents-tuned value, which starves the stage")
    SEMGREP_PATH_NOT_RELATIVE = ("a Semgrep finding's path could not be made repo-relative, so the "
                                 "finding will be dropped as a file outside the repo inventory")
    SEMGREP_SCAN_DEGRADED = ("the Semgrep scan produced no report; its graph tools will answer "
                             "from an absent scan rather than from evidence")
    INVESTIGATION_STAGE_FAILED = ("a required investigation stage failed; the findings count is "
                                  "not a trustworthy result for this repo")
    MODEL_KEY_UNRECOGNIZED = "unrecognized model key(s) ignored"
    TRACING_UPLOADS_PROMPTS = "tracing is on; it uploads every prompt, repo source included"
    BATCH_ROW_INVALID = "batch row is not usable"
    BATCH_ALL_ROWS_SKIPPED = "every row was excluded by batch.skip_repo_patterns"
    BATCH_REPO_SKIPPED = "skipping a repo"
    BATCH_MARKER_WRITE_FAILED = "could not write the stage marker"
    CASE_PATH_OUTSIDE_ROOT = "case path resolves outside the case root; ignoring it"
    CASE_RECORD_UNREADABLE = "not a readable case record; ignoring it"
    CASE_ROOT_UNSAFE = ("the remediation case directory is a symlink or not a directory; "
                        "skipping the rollup")
    CVE_FEED_UNREADABLE = "could not load the CVE feed; continuing with no injected CVEs"
    CVE_FEED_RECORDS_SKIPPED = "skipped malformed CVE record(s)"
    DESIGN_CONTROLS_UNREADABLE = ("could not load the controls file; continuing with no injected "
                                  "controls")
    INGEST_CA_MISSING = "ingest CA bundle not found; skipping upload"
    EV_COLLECTION_REQUIRED = "this stage needs EV_API_COLLECTION to be set"
    EV_COLLECTION_NOT_LOCAL = "EV_API_COLLECTION must be a local path; refusing a network path"
    EV_RESOLUTION_CONFLICT = ("the command line conflicts with the configured exploit-verification "
                              "mode")
    LEDGER_IMBALANCE = "the finding ledger does not balance"
    VALIDATION_NONZERO_EXIT = "validation exited non-zero; the scan's exit code reflects it"
    REMEDIATION_INCOMPLETE = ("remediation did not process every finding; the scan's exit code "
                              "reflects it")
    REMEDIATION_FINDING_FAILED = "remediation failed for a finding; continuing"
    FIXER_DISPATCH_REFUSED = "fixer dispatch refused"
    FIXER_STATUS_NO_RETRY = "the fixer finished with a status that permits no retry"

    # ── cross-cutting ───────────────────────────────────────────────────────
    APPCONTEXT_KEY_COLLISION = ("two application ids normalise to one key but describe different "
                                "exposure; last-wins")
    RULEPACK_LOAD_FAILED = "failed to load a rule pack"
    ERRLOG_WRITE_FAILED = "failed to write the error log entry"
    JSON_SALVAGE_FAILED = "could not salvage JSON from the reply"
    JSON_INPUT_TRUNCATED = "input exceeds the JSON scan cap; scanning the head only"
    RESPONSE_QUALITY_FLOOR = "reply fell below the stage response-quality floor"
    REPLAY_NO_LIVE_SESSION = "no live session to resume; re-asking from the transcript"
    STAGE_ORPHAN_SETTLED = "an abandoned call settled after its stage deadline"
    RESPONSE_DEGENERATE_ACCEPTED = ("degenerate response accepted and used; it raises only after "
                                    "more repeats")
