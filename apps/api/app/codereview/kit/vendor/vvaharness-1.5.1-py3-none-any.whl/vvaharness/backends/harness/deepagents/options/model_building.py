# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Chat-model resolution: TLS-aware httpx clients (CA/mTLS), model construction, a cache."""

from __future__ import annotations

import asyncio
import itertools
import os
import re
import ssl
import threading
import weakref
from pathlib import Path
from typing import Any, Final

import anthropic
import httpx2
import langchain_anthropic
import openai
from langchain_anthropic import ChatAnthropic
from langchain_core.language_models import BaseChatModel

from vvaharness.backends.harness.deepagents import tool_choice_rejection
from vvaharness.backends.harness.deepagents.limits import (
    MODEL_MAX_OUTPUT_TOKENS,
    MODEL_MAX_RETRIES,
    MODEL_TIMEOUT_SECONDS,
)
from vvaharness.backends.harness.deepagents.models import (
    SSL_CERT_DIR_VAR,
    SSL_CERT_FILE_VAR,
    TLS_CLIENT_CERT_VAR,
    TLS_CLIENT_KEY_VAR,
    TLS_VERIFY_VAR,
    ModelKey,
    anthropic_base,
    anthropic_key,
    openai_base,
    openai_key,
)
from vvaharness.backends.harness.deepagents.options.forcing import ForcingChatAnthropic
from vvaharness.backends.harness.deepagents.options.tool_call_state import ToolCallStateChatOpenAI
from vvaharness.backends.harness.models import EffortLevel
from vvaharness.backends.harness.provider_routing import (
    TRANSPORT_CHAT_COMPLETIONS,
    TRANSPORT_RESPONSES,
    routes_to_anthropic,
)
from vvaharness.backends.llm.models import (
    EFFORT_REJECTIONS,
    REASONING_OFF,
    TRANSPORT_MEMORY,
    ClockKind,
    effort_after_rejections,
    effort_scaled_seconds,
)

# Reused, not re-derived, so verify_ssl/cert semantics match via: sdk/openai; stdlib-only import
from vvaharness.backends.llm.tls import (
    anthropic_auth_kwargs,
    chain_paths,
    coerce_verify,
    is_anthropic_oauth_token,
    load_client_chain,
    resolve_client_chain,
    scoped_no_proxy_env,
    warn_verify_disabled,
)
from vvaharness.orchestrator.config_paths import _resolve_against
from vvaharness.util import logs
from vvaharness.util.events import Event
from vvaharness.util.warn_once import warn_once

log = logs.get_logger(__name__)

#: Stamp on TLS_VERIFY_VAR/NO_PROXY_VAR so the reader can tell a config carrier from an ambient one
_TLS_VERIFY_STAMP = "vvaharness-config:"

#: INTERNAL no_proxy carrier: detection seams and preflight only, never the frozen S10/S11 invoker
NO_PROXY_VAR = "VVAHARNESS_NO_PROXY"


def _ca_bundle(env: dict[str, str], *, allow_ambient: bool) -> str | None:
    """Return the configured CA bundle path, mirroring httpx's own env lookup order."""
    # Ambient CA vars are ADDITIVE, httpx verify EXCLUSIVE (breaks api.anthropic.com); absent RAISES
    if allow_ambient:
        ca_file = (
            env.get(SSL_CERT_FILE_VAR)
            or env.get("REQUESTS_CA_BUNDLE")
            or env.get("NODE_EXTRA_CA_CERTS")
            or os.environ.get(SSL_CERT_FILE_VAR)
            or os.environ.get("REQUESTS_CA_BUNDLE")
            or os.environ.get("NODE_EXTRA_CA_CERTS")
        )
    else:
        ca_file = env.get(SSL_CERT_FILE_VAR)
    if ca_file and not Path(ca_file).is_file():
        raise FileNotFoundError(
            f"DeepAgents CA bundle not found or not a file: {ca_file}"
        )
    ca_dir = env.get(SSL_CERT_DIR_VAR) or (
        os.environ.get(SSL_CERT_DIR_VAR) if allow_ambient else None
    )
    if ca_dir and not Path(ca_dir).is_dir():
        raise FileNotFoundError(
            f"DeepAgents CA directory not found or not a directory: {ca_dir}"
        )
    return ca_file or ca_dir


def _config_verify(env: dict[str, str]) -> str | bool | None:
    """Return the config-level ``verify_ssl`` tri-state, ignoring an ambient carrier."""
    # Envs inherit os.environ, so only _TLS_VERIFY_STAMP-stamped values disable TLS verification
    raw = env.get(TLS_VERIFY_VAR)
    if raw is None:
        return None
    if not raw.startswith(_TLS_VERIFY_STAMP):
        log.warning(Event.AMBIENT_ENV_IGNORED, var=TLS_VERIFY_VAR, value=raw, knob="verify_ssl")
        return None
    return coerce_verify(raw.removeprefix(_TLS_VERIFY_STAMP))


def _config_no_proxy(env: dict[str, str]) -> str | None:
    """Return the config-level ``no_proxy`` hosts, ignoring an ambient carrier."""
    # Stamped like _config_verify, so no ambient re-route; plain NO_PROXY still works via trust_env
    raw = env.get(NO_PROXY_VAR)
    if raw is None:
        return None
    if not raw.startswith(_TLS_VERIFY_STAMP):
        log.warning(Event.AMBIENT_ENV_IGNORED, var=NO_PROXY_VAR, value=raw, knob="no_proxy")
        return None
    return raw.removeprefix(_TLS_VERIFY_STAMP) or None


def _resolve_verify(env: dict[str, str], *, allow_ambient: bool) -> str | bool | None:
    """Return the effective httpx ``verify=`` value, or None when only defaults apply."""
    verify = _ca_bundle(env, allow_ambient=allow_ambient) or _config_verify(env)
    if verify is False:
        warn_verify_disabled(
            openai_base(env) if allow_ambient else anthropic_base(env),
            label="deepagents",
        )
        return False
    # Per coerce_verify, a non-boolean string is a CA-bundle path; True/None are defaults.
    return verify if isinstance(verify, str) else None


def _client_cert(env: dict[str, str]) -> str | tuple[str, ...] | None:
    """Resolve the mTLS client certificate, disabling mTLS when a file is missing."""
    cert = env.get(TLS_CLIENT_CERT_VAR) or os.environ.get(TLS_CLIENT_CERT_VAR)
    if not cert:
        return None
    key = env.get(TLS_CLIENT_KEY_VAR) or os.environ.get(TLS_CLIENT_KEY_VAR)
    return resolve_client_chain(
        (cert, key) if key else cert, label="deepagents", noun="client_cert/key"
    )


def _resolve_cert_path(path: str, cfg_dir: Path | None) -> str:
    """Resolve a profile cert *path* against *cfg_dir*, when one is known."""
    # Must use _resolve_against for its UNC refusal, or a planted config leaks creds over SMB
    if cfg_dir is None:
        return path
    return _resolve_against(cfg_dir, path)


def tls_carriers_for(
    model_id: str,
    provider: str | None,
    *,
    sdk_cfg: object | None,
    openai_cfg: object | None,
    cfg_dir: Path | str | None = None,
) -> dict[str, str]:
    """Build the TLS env carriers :func:`build_model` reads, for the resolved vendor."""
    # DETECTION seam only: an mTLS/private-CA profile never reaches via: deepagents S10/S11
    block = sdk_cfg if routes_to_anthropic(model_id, provider) else openai_cfg
    if block is None:
        return {}
    directory = Path(cfg_dir) if cfg_dir else None
    carriers: dict[str, str] = {}
    ca = getattr(block, "ca_cert", None)
    if ca:
        carriers[SSL_CERT_FILE_VAR] = _resolve_cert_path(ca, directory)
    cert = getattr(block, "client_cert", None)
    pair = chain_paths(cert) if cert else ()
    for var, path in zip((TLS_CLIENT_CERT_VAR, TLS_CLIENT_KEY_VAR), pair, strict=False):
        carriers[var] = _resolve_cert_path(path, directory)
    verify = coerce_verify(getattr(block, "verify_ssl", None))
    if verify is not None and verify is not True:
        value = "false" if verify is False else _resolve_cert_path(verify, directory)
        carriers[TLS_VERIFY_VAR] = _TLS_VERIFY_STAMP + value
    no_proxy = getattr(block, "no_proxy", None)
    if no_proxy:
        carriers[NO_PROXY_VAR] = _TLS_VERIFY_STAMP + no_proxy
    return carriers


def _ssl_context(
    env: dict[str, str], *, allow_ambient_ca: bool = True
) -> ssl.SSLContext | None:
    """Return an SSL context for the configured TLS material, or None when there is none."""
    # Bad CA RAISES, bad chain warns; never pass cert= to create_ssl_context (httpx2 2.13.1)
    verify = _resolve_verify(env, allow_ambient=allow_ambient_ca)
    cert = _client_cert(env)
    if verify is None and cert is None:
        return None
    context = httpx2.create_ssl_context(
        verify=True if verify is None else verify, trust_env=True
    )
    if (cert is not None
            and not load_client_chain(context, cert, label="deepagents")
            and verify is None):
        return None  # the chain was the only configured material: stay stock
    return context


def _inject_anthropic_clients(chat: ChatAnthropic, ssl_context: ssl.SSLContext | None,
                              token: str, *, timeout: float = MODEL_TIMEOUT_SECONDS) -> None:
    """Pre-seed *chat*'s anthropic clients with TLS-configured httpx clients."""
    # No http_client field: a kwarg breaks every call, so seed __dict__; fail CLOSED, not unpinned
    sync_http = None
    try:
        params = dict(chat._client_params)
        if is_anthropic_oauth_token(token):
            # auth_token and api_key are mutually exclusive on anthropic.Client; OAuth
            # replaces api_key, so it must go. Otherwise keep the explicit api_key —
            # dropping it unconditionally let a blank token fall through to anthropic's
            # own on-disk/env credential discovery instead of failing closed.
            params.pop("api_key", None)
        http_kwargs: dict[str, object] = {"timeout": timeout}
        if ssl_context is not None:
            http_kwargs["verify"] = ssl_context
        sync_http = anthropic.DefaultHttpxClient(**http_kwargs)
        chat.__dict__["_client"] = anthropic.Client(
            **{**params, **anthropic_auth_kwargs(token), "http_client": sync_http}
        )
        chat.__dict__["_async_client"] = anthropic.AsyncClient(
            **{
                **params,
                **anthropic_auth_kwargs(token),
                "http_client": anthropic.DefaultAsyncHttpxClient(**http_kwargs),
            }
        )
    except Exception as exc:
        # Undo a partial seed and close the already-built sync pool rather than leak it
        chat.__dict__.pop("_client", None)
        chat.__dict__.pop("_async_client", None)
        if sync_http is not None:
            sync_http.close()
        version = getattr(langchain_anthropic, "__version__", "unknown")
        raise RuntimeError(
            f"TLS client injection into ChatAnthropic failed "
            f"(langchain-anthropic {version}): {type(exc).__name__}. Refusing to "
            f"continue on SYSTEM TRUST — the configured ca_cert pin would not be "
            f"enforced and any client_cert would not be presented. Remove the "
            f"TLS material from the profile to run unpinned deliberately, or "
            f"pin a langchain-anthropic version this build supports."
        ) from exc


_OPENAI_EFFORT_MAP: dict[EffortLevel, str] = {
    EffortLevel.LOW: "low",
    EffortLevel.MEDIUM: "medium",
    EffortLevel.HIGH: "high",
    EffortLevel.XHIGH: "xhigh",
    EffortLevel.MAX: "max",
}


def _to_openai_reasoning_effort(effort: str | None) -> str | None:
    """Map our ``EffortLevel`` vocabulary to OpenAI's ``reasoning_effort`` literal, or ``None``."""
    parsed = EffortLevel.parse(effort)
    return _OPENAI_EFFORT_MAP.get(parsed) if parsed is not None else None


#: Same object as EFFORT_REJECTIONS.tiers: openai and deepagents share one memory.
_NO_REASONING_EFFORT: set[tuple[str, str]] = EFFORT_REJECTIONS.tiers

#: Models learned at runtime to reject their first Responses API call. Alias of
#: TRANSPORT_MEMORY.chat_only (same set object) so the openai route and this client share one
#: memory; the name stays so every existing `.add`/`in`/`.discard` reference keeps working.
_CHAT_COMPLETIONS_ONLY_MODELS: set[str] = TRANSPORT_MEMORY.chat_only

#: Anthropic ids that reject a forced tool_choice with a 400. Alias of tool_choice_rejection's
#: set (same object), which ForceVerdictOnly and the client learn into.
_FORCED_TOOL_CHOICE_UNSUPPORTED_MODELS: set[str] = tool_choice_rejection.UNSUPPORTED_MODELS

_RESPONSES_BROKEN_MODELS: frozenset[str] = frozenset({
    "kimi-k2.6",
    "kimi-k2.7-code",
    "glm-5.2",
})


def _needs_chat_completions(model_id: str) -> bool:
    """True when *model_id*'s Responses leg caps output at 4096 and drops the tool call."""
    return model_id.rsplit(_GATEWAY_NAMESPACE, 1)[-1].lower() in _RESPONSES_BROKEN_MODELS

#: With ``store=False`` the endpoint keeps no per-turn state; encrypted reasoning replays it.
RESPONSES_INCLUDE_ENCRYPTED_REASONING: Final[tuple[str, ...]] = (
    "reasoning.encrypted_content",
)


def _effort_kwargs(
    model_id: str, effort: str | None, transport: str = TRANSPORT_CHAT_COMPLETIONS,
) -> dict[str, Any]:
    """Return the ``reasoning_effort=`` kwarg to splice in, or ``{}`` when inapplicable.

    *transport* must match the one the caller actually builds for: a tier learned on
    Responses is invisible under the Chat key (and vice versa) -- the rejection is keyed per
    transport in `EFFORT_REJECTIONS.tiers`/`.step_to`.
    """
    if model_id in EFFORT_REJECTIONS.field:
        return {}
    mapped = effort_after_rejections(model_id, _to_openai_reasoning_effort(effort), transport)
    return {} if mapped is None else {"reasoning_effort": mapped}


#: An absent reasoning_effort leaves the model at its own default: kimi-k2.6 then spent 23,665 of
#: 27,113 output tokens reasoning and truncated s2 against its 32,768 cap. grok-4.5 rejects `none`.
_REASONING_OFF_MODELS: frozenset[str] = frozenset({
    "kimi-k2.6",
    "kimi-k2.7-code",
    "glm-5.2",
})


def _reasoning_off_kwargs(model_id: str) -> dict[str, Any]:
    """``{"reasoning_effort": "none"}`` for a model that must not reason natively, else ``{}``."""
    if model_id not in _REASONING_OFF_MODELS or model_id in EFFORT_REJECTIONS.field:
        return {}
    # Keyed exactly as a mapped tier is, so one 400 retires the field for this model too.
    if (model_id, REASONING_OFF) in _NO_REASONING_EFFORT:
        return {}
    return {"reasoning_effort": REASONING_OFF}


_ANTHROPIC_EFFORT_MAP: dict[EffortLevel, str] = {
    EffortLevel.LOW: "low",
    EffortLevel.MEDIUM: "medium",
    EffortLevel.HIGH: "high",
    EffortLevel.XHIGH: "xhigh",
    EffortLevel.MAX: "max",
}


#: Appended to the system prompt in place of native reasoning (see `reasons_in_prompt`), so the
#: reasoning still happens in writing, inside the answer, where it is bounded and far cheaper.
REASON_IN_PROMPT = (
    "\n\nREASONING: think it through in writing before you answer. Name each candidate, the "
    "control or framework default that would refute it, and discard what does not hold. Keep it "
    "compact -- no restating the input, no recap of your own steps."
)

#: Anthropic ids on which `think_in_prompt` is a no-op: thinking cannot be disabled and
#: REASON_IN_PROMPT is refused as reasoning extraction.
#: Limitation: an id list, so a new model that refuses must be added here.
_NO_REASON_IN_PROMPT_RX: Final[re.Pattern[str]] = re.compile(
    r"claude-(?:sonnet-5-5|opus-5|fable-5)(?!\d)", re.IGNORECASE
)


def reasons_in_prompt(model_id: str, provider: str | None) -> bool:
    """True when ``think_in_prompt`` applies: every route but Anthropic models that refuse it."""
    if not routes_to_anthropic(model_id, provider):
        return True
    return _NO_REASON_IN_PROMPT_RX.search(model_id) is None


def _anthropic_thinking_kwargs(effort: str | None, *, in_prompt: bool = False) -> dict[str, Any]:
    """Return the thinking kwargs for *effort*; *in_prompt* disables thinking and keeps the tier."""
    parsed = EffortLevel.parse(effort)
    mapped = _ANTHROPIC_EFFORT_MAP.get(parsed) if parsed is not None else None
    if mapped is None:
        return {"thinking": {"type": "disabled"}} if in_prompt else {}
    # Thinking volume is FLAT across effort tiers, so the tier is not a latency dial -- only
    # disabling is. Keeping output_config.effort is what preserves depth.
    if in_prompt:
        return {"thinking": {"type": "disabled"}, "output_config": {"effort": mapped}}
    return {"thinking": {"type": "adaptive"}, "output_config": {"effort": mapped}}


def resolve_use_responses_api(
    model_id: str, provider: str | None, override: bool | None
) -> bool | None:
    """Resolve the transport: override, then learned rejection, then Responses; Anthropic → None."""
    if routes_to_anthropic(model_id, provider):
        return None
    if override is not None:
        return override
    if _needs_chat_completions(model_id):
        return False
    return model_id not in _CHAT_COMPLETIONS_ONLY_MODELS


#: Model ids whose inferred vendor was already reported, so each warns once.
_INFERRED_VENDOR_WARNED: set[str] = set()

#: Gateway vendor-namespace separator; only "/" deliberately, since real ids carry dots and colons
_GATEWAY_NAMESPACE = "/"


def _warn_if_vendor_inferred(model_id: str, provider: str | None) -> None:
    """WARN once when a namespaced id's vendor had to be guessed from its name."""
    # A "claude" id routes to the Anthropic block even on OpenAI gateways; NOT changed by design
    if provider or _GATEWAY_NAMESPACE not in model_id:
        return
    vendor = "anthropic" if routes_to_anthropic(model_id, provider) else "openai"
    warn_once(
        _INFERRED_VENDOR_WARNED, model_id,
        f"WARN [deepagents]: model id {model_id!r} looks gateway-namespaced and "
        f"declares no `provider:`, so its vendor was INFERRED as {vendor!r} from "
        f"the name — that picks both the client shape and the credential/base-url "
        f"block ({vendor.upper()}_API_KEY / {vendor.upper()}_BASE_URL). Set "
        f"`provider: anthropic` or `provider: openai` on this models entry to pin it.")


def _transport_kwargs(resolved: bool) -> dict[str, Any]:
    """ChatOpenAI kwargs for the resolved transport, mirroring ``_effort_kwargs``."""
    if not resolved:
        return {"use_responses_api": False}
    return {
        "use_responses_api": True,
        "store": False,
        "include": list(RESPONSES_INCLUDE_ENCRYPTED_REASONING),
    }


def _openai_effort_kwargs(
    model_id: str, effort: str | None, *, think_in_prompt: bool, resolved_transport: bool,
) -> dict[str, Any]:
    """The ``reasoning_effort=`` kwarg for an OpenAI-compatible build."""
    # Forcing it off wins on Chat Completions: every call on this leg carries tools (ChatOpenAI
    # kwargs apply to the whole model object), and this model rejects reasoning_effort alongside
    # them.
    if model_id in EFFORT_REJECTIONS.tools_off and not resolved_transport:
        return {"reasoning_effort": REASONING_OFF}
    # Dropping the tier is not reasoning off: _REASONING_OFF_MODELS need `none` sent explicitly.
    transport = TRANSPORT_RESPONSES if resolved_transport else TRANSPORT_CHAT_COMPLETIONS
    return (_reasoning_off_kwargs(model_id) if think_in_prompt
            else _effort_kwargs(model_id, effort, transport))


def build_model(
    model_id: str,
    env: dict[str, str],
    provider: str | None = None,
    effort: str | None = None,
    use_responses_api: bool | None = None,
    think_in_prompt: bool = False,
) -> BaseChatModel:
    """Resolve a model id to a chat model, per :func:`routes_to_anthropic`."""
    _warn_if_vendor_inferred(model_id, provider)
    # Same predicate gates the instruction in graph_builder
    think_in_prompt = think_in_prompt and reasons_in_prompt(model_id, provider)
    anthropic_route = routes_to_anthropic(model_id, provider)
    ssl_context = _ssl_context(env, allow_ambient_ca=not anthropic_route)
    no_proxy = _config_no_proxy(env)
    # MODEL_TIMEOUT_SECONDS is the high-tier anchor; scaled once here for every client below.
    request_timeout = effort_scaled_seconds(
        MODEL_TIMEOUT_SECONDS, effort, kind=ClockKind.REQUEST
    )
    if anthropic_route:
        token = anthropic_key(env)
        chat = ForcingChatAnthropic(
            model_name=model_id,
            api_key=token,  # type: ignore[arg-type]
            base_url=anthropic_base(env),
            timeout=request_timeout,
            max_retries=MODEL_MAX_RETRIES,  # 429/5xx ladder — bound in limits.py
            # Passed under the field's declared alias; only that alias is visible to a type checker.
            max_tokens_to_sample=MODEL_MAX_OUTPUT_TOKENS,
            **_anthropic_thinking_kwargs(effort, in_prompt=think_in_prompt),
        )
        if ssl_context is not None or is_anthropic_oauth_token(token):
            with scoped_no_proxy_env(no_proxy):
                _inject_anthropic_clients(chat, ssl_context, token or "", timeout=request_timeout)
        return chat
    # OpenAI-compatible endpoints; transport per resolve_use_responses_api.
    # Always inject our own clients: langchain_openai's shared client cache is not event-loop safe.
    client_kwargs: dict[str, Any] = {"timeout": request_timeout}
    if ssl_context is not None:
        client_kwargs["verify"] = ssl_context
    with scoped_no_proxy_env(no_proxy):
        http_client = openai.DefaultHttpxClient(**client_kwargs)
        http_async_client = openai.DefaultAsyncHttpxClient(**client_kwargs)
    # () silences a spurious proxy-shadow warning; our explicit clients never apply socket options.
    socket_options_kwargs: dict[str, Any] = {}
    if "http_socket_options" in ToolCallStateChatOpenAI.model_fields:
        socket_options_kwargs["http_socket_options"] = ()
    resolved_transport = bool(resolve_use_responses_api(model_id, provider, use_responses_api))
    effort_kwargs = _openai_effort_kwargs(
        model_id, effort, think_in_prompt=think_in_prompt, resolved_transport=resolved_transport)
    transport_kwargs = _transport_kwargs(resolved_transport)
    return ToolCallStateChatOpenAI(
        model=model_id,
        api_key=openai_key(env),  # type: ignore[arg-type]
        base_url=openai_base(env),
        timeout=request_timeout,
        max_retries=MODEL_MAX_RETRIES,  # 429/5xx ladder — parity with the Anthropic arm above
        http_client=http_client,
        http_async_client=http_async_client,
        **socket_options_kwargs,
        **effort_kwargs,
        **transport_kwargs,
    )


#: TLS/no_proxy env names in the cache key, so unlike envs never share a model; a superset is safe
_TLS_ENV_VARS: tuple[str, ...] = (
    TLS_CLIENT_CERT_VAR,
    TLS_CLIENT_KEY_VAR,
    TLS_VERIFY_VAR,
    NO_PROXY_VAR,
    SSL_CERT_FILE_VAR,
    SSL_CERT_DIR_VAR,
    "REQUESTS_CA_BUNDLE",
    "NODE_EXTRA_CA_CERTS",
)

_model_cache: dict[tuple[Any, ...], BaseChatModel] = {}

#: Serializes cache misses so concurrent first calls (S4's pool) share one build, leaking no pools
_model_cache_lock = threading.Lock()

#: Per-loop identity for the cache key (see ``_loop_token``). Weak-keyed so a closed, collected
#: loop's token is dropped instead of risking a later loop reusing its freed id().
_loop_tokens: "weakref.WeakKeyDictionary[Any, int]" = weakref.WeakKeyDictionary()
_loop_token_counter = itertools.count()
_loop_token_lock = threading.Lock()


def _tls_fingerprint(env: dict[str, str]) -> tuple[str, ...]:
    """Fingerprint the TLS material *env* resolves, mirroring the env-then-ambient lookup."""
    return tuple(env.get(v) or os.environ.get(v) or "" for v in _TLS_ENV_VARS)


def _loop_token() -> int | None:
    """A collision-safe identity for the running event loop, or ``None`` outside one.

    A cached ``BaseChatModel`` on the OpenAI-compatible arm carries a bound
    ``http_async_client`` (``openai.DefaultAsyncHttpxClient``) whose connection pool lazily
    binds its async primitives to whichever event loop is running the first time it is used.
    ``plugin_runner._run_sync`` (S10) and ``validation.session.launcher`` (S11) each give every
    finding/session its own ``asyncio.run()`` call, closing that loop when it returns; a model
    cached under a prior, now-closed loop and reused under the next one raises
    ``RuntimeError: Event loop is closed`` the moment the stale pool touches I/O — reproduced
    identically across GLM-5.2, Kimi K2.7-code and GPT-5.5 on exactly every other call
    (see docs/investigations/glm-kimi-s10-s11-benchmark.md).

    ``id(loop)`` is not a safe key on its own: CPython reliably reuses a freed loop's address for
    the very next loop object in a tight per-finding ``asyncio.run()`` sequence, so two genuinely
    different loops could collide on the same raw id. Assigning each *live* loop object a
    monotonically increasing token via a ``WeakKeyDictionary`` sidesteps that: the entry is
    dropped (by the weakref callback) as soon as the loop itself is garbage collected, so a later,
    unrelated loop can never inherit a stale token.

    Callers with no running loop (e.g. a plain synchronous test or detection-stage call sharing
    one long-lived loop outside S10/S11) all key on ``None``, so the one-build-per-loop split
    introduced here never changes cache behaviour for anything that was already loop-stable.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return None
    token = _loop_tokens.get(loop)
    if token is not None:
        return token
    with _loop_token_lock:
        token = _loop_tokens.get(loop)
        if token is None:
            token = next(_loop_token_counter)
            _loop_tokens[loop] = token
        return token


def build_model_cached(
    model_id: str,
    env: dict[str, str],
    provider: str | None = None,
    effort: str | None = None,
    use_responses_api: bool | None = None,
    think_in_prompt: bool = False,
) -> BaseChatModel:
    """Return a model instance, reusing a cached instance when inputs match."""
    # Keyed on the FIELD ACTUALLY SENT (none, a stepped-down tier, forced REASONING_OFF after a
    # tools-conflict, or None), never the raw effort or the walked tier alone -- a tools-conflict
    # step adds to .tools_off, not .tiers, so a key that ignored it would serve the retry its own
    # stale rejected instance back and recurse forever.
    resolved_transport = resolve_use_responses_api(model_id, provider, use_responses_api)
    cache_effort = _openai_effort_kwargs(
        model_id, effort, think_in_prompt=think_in_prompt,
        resolved_transport=bool(resolved_transport),
    ).get("reasoning_effort")
    key = (
        ModelKey.of(model_id, env, provider, cache_effort, resolved_transport),
        _tls_fingerprint(env),
        think_in_prompt,
        _loop_token(),
    )
    cached = _model_cache.get(key)
    if cached is not None:
        return cached
    # Double-checked: the unlocked read above stays the steady-state fast path.
    with _model_cache_lock:
        cached = _model_cache.get(key)
        if cached is not None:
            return cached
        model = build_model(model_id, env, provider, effort, resolved_transport,
                            think_in_prompt=think_in_prompt)
        _model_cache[key] = model
        return model
