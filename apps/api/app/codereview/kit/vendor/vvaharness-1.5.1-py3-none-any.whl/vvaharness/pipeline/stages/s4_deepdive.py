# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Step 4 — deep-dive each unit in its own agentic session."""
from __future__ import annotations

import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from vvaharness.util import logs

log = logs.get_logger(__name__)

from vvaharness.backends.harness.models import is_halt_error
from vvaharness.backends.llm import cli
from vvaharness.backends.llm.cli import GuardrailBlocked
from vvaharness.backends.llm.models import guardrail_gate_hit
from vvaharness.backends.llm.tools import sanitize_packed_text
from vvaharness.evidence import _cap_int
from vvaharness.models import ContextPackage, Finding, InvestigationUnit
from vvaharness.pipeline.stages.s4.batching import plan_batches
from vvaharness.report.redact import _luhn, redact, redact_counts
from vvaharness.util import console
from vvaharness.util import errlog as _errlog
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.response_quality import is_deterministic_failure
from vvaharness.util.warn_once import warn_once


def run(units: list[InvestigationUnit], ctx: ContextPackage, cfg
        ) -> tuple[list[Finding], dict[str, str]]:
    """Process every unit, returning ``(findings, outcomes)`` so a failed or blocked unit stays distinguishable from a clean one."""
    log.info("s4/deepdive: starting deep-dive analysis - units=%d", len(units))
    tracker = getattr(cfg, "_scan_progress", None)
    repo_root = Path(ctx.repo_root)
    units = sorted(units, key=lambda c: c.risk_rank)
    parallel = getattr(cfg.step4, "parallel", 12)
    from vvaharness.pipeline.stages.s4.session import deepdive_tools, investigate_unit
    # Fail closed pre-pool: a bad step4.allowed_tools would otherwise fail every unit separately
    deepdive_tools(cfg)
    investigate = investigate_unit

    def _label(unit: InvestigationUnit) -> None:
        lens = "+".join(unit.languages[:3]) or "generic"
        h = unit.threat
        console.write(f"  [s4] unit {unit.id} ({unit.size.value}, rank {unit.risk_rank}, "
                      f"lens={lens}): {h[:120]}{'…' if len(h) > 120 else ''}")

    guardrail_hits = 0
    guardrail_gate = max(3, parallel)
    successes = 0
    outcomes: dict[str, str] = {}   # unit id -> "completed"|"error"|"guardrail"|"skipped"|"uninvestigated"|"failed"|"halted"

    # s3_decompose already drops file-less units; this is a second, independent layer.
    non_empty_units: list[InvestigationUnit] = []
    for unit in units:
        if unit.files:
            non_empty_units.append(unit)
            continue
        console.write(f"  [s4] unit {unit.id}: SKIPPED — no files to analyze")
        _errlog.log("s4", unit.id,
                    "unit carries no files after upstream normalisation; "
                    "skipped before any model call", scope="unit",
                    # Not recovered=True: nothing else records it; "skipped" is out of chunks_failed
                    reason="empty_chunk_skipped")
        outcomes[unit.id] = "skipped"
        if tracker is not None:
            tracker.scanned(unit, outcome="skipped", n_findings=0)
    units = non_empty_units

    # Only a content-guardrail block counts toward this gate, never a ModelRefusal: refusals return
    # fast, so they would dominate the first completions and abort units that would succeed.
    def _guardrail_fail_fast(e: GuardrailBlocked) -> None:
        raise RuntimeError(
            f"s4-deepdive: {guardrail_hits} content-guardrail blocks on the CLI/OAuth "
            "path with zero successful units — aborting run. A content classifier on this "
            "path rejects the prompts; switch models.deepdive.via to 'sdk' or "
            "'deepagents'.") from e

    if parallel <= 1:
        all_findings: list[Finding] = []
        for i, unit in enumerate(units):
            _label(unit)
            if tracker is not None:
                tracker.scanning(unit)
            unit_stats: dict = {}
            try:
                findings = investigate(unit, ctx, repo_root, cfg, stats=unit_stats)
            except GuardrailBlocked as e:
                guardrail_hits, gate_label = guardrail_gate_hit(e, guardrail_hits, guardrail_gate)
                console.write(f"  [s4] unit {unit.id} GUARDRAIL-BLOCKED ({gate_label})")
                _errlog.log("s4", f"guardrail:{unit.id}", e, scope="unit",
                            files=len(unit.files))
                outcomes[unit.id] = "guardrail"
                if tracker is not None:
                    tracker.scanned(unit, outcome="guardrail", n_findings=0)
                if guardrail_hits >= guardrail_gate and successes == 0:
                    _guardrail_fail_fast(e)
                continue
            except Exception as e:
                if cli.aborted():
                    raise
                if is_halt_error(e):
                    # Every remaining unit would fail identically -- stop dispatching.
                    remaining = units[i:]
                    console.write(f"  [s4] unit {unit.id} HALTED ({type(e).__name__}) "
                                  f"— stopping s4 early; {len(remaining)} unit(s) "
                                  "will not be analyzed")
                    _errlog.log("s4", unit.id, e, scope="unit", files=len(unit.files))
                    COUNTERS.bump("s4_units_halted", len(remaining))
                    for skipped in remaining:
                        outcomes[skipped.id] = "halted"
                        if tracker is not None:
                            tracker.scanned(skipped, outcome="halted", n_findings=0)
                    break
                # Every retry failed; record it so the report discloses the coverage gap
                console.write(f"  [s4] unit {unit.id} ERROR: {redact(str(e))}")
                _errlog.log("s4", unit.id, e, scope="unit",
                            files=len(unit.files))
                outcomes[unit.id] = "error"
                if tracker is not None:
                    tracker.scanned(unit, outcome="error", n_findings=0)
                continue
            successes += 1
            outcomes[unit.id] = "completed"
            all_findings.extend(findings)
            if tracker is not None:
                tracker.scanned(unit, outcome="completed", n_findings=len(findings))
            merged = unit_stats.get("merged", 0)
            suffix = f" ({merged} merged, same site)" if merged else ""
            console.write(f"  [s4] unit {unit.id}: {len(findings)} findings{suffix}")
        error_count = sum(1 for v in outcomes.values() if v == "error")
        guardrail_count = sum(1 for v in outcomes.values() if v == "guardrail")
        halted_count = sum(1 for v in outcomes.values() if v == "halted")
        log.info("s4/deepdive: serial processing complete - units=%d findings=%d errors=%d guardrails=%d halted=%d",
                 len(units), len(all_findings), error_count, guardrail_count, halted_count)
        if tracker is not None:
            tracker.print_summary()
        return all_findings, outcomes

    console.write(f"  [s4] processing {len(units)} units ({parallel} parallel)...")
    results: dict[str, list[Finding]] = {}
    batches = plan_batches(units, _batch_size(cfg))
    split_retry = bool(knob(cfg, "step4.split_retry", True))
    if any(len(b) > 1 for b in batches):
        console.write(f"  [s4] batched {len(units)} units into {len(batches)} sessions")
    ex = ThreadPoolExecutor(max_workers=parallel)
    futs = {}
    retry_futs: dict = {}

    def _resubmit(unit: InvestigationUnit) -> None:
        fut = _submit_batch(ex, [unit], investigate, ctx, repo_root, cfg)
        futs[fut] = [unit]
        retry_futs[fut] = [unit]
        COUNTERS.bump("s4_batch_member_resubmitted")

    def _mark_halted(batches_to_mark: list[list[InvestigationUnit]]) -> int:
        """Tag every not-yet-recorded unit in *batches_to_mark* "halted" (never
        dispatched again, on a split retry or otherwise). Returns the count tagged."""
        n = 0
        for b in batches_to_mark:
            for unit in b:
                if unit.id in outcomes:
                    continue
                outcomes[unit.id] = "halted"
                results[unit.id] = []
                n += 1
                if tracker is not None:
                    tracker.scanned(unit, outcome="halted", n_findings=0)
        return n

    for batch in batches:
        for unit in batch:
            _label(unit)
            if tracker is not None:
                tracker.scanning(unit)
        futs[_submit_batch(ex, batch, investigate, ctx, repo_root, cfg)] = batch
    halted = False
    try:
        for fut in as_completed(futs):
            batch = futs[fut]
            try:
                found, merged_by_unit, verdict_by_unit = fut.result()
            except GuardrailBlocked as e:
                guardrail_hits, gate_label = guardrail_gate_hit(e, guardrail_hits, guardrail_gate)
                for unit in batch:
                    console.write(f"  [s4] unit {unit.id} GUARDRAIL-BLOCKED ({gate_label})")
                    _errlog.log("s4", f"guardrail:{unit.id}", e, scope="unit",
                                files=len(unit.files))
                    results[unit.id] = []
                    outcomes[unit.id] = "guardrail"
                    if tracker is not None:
                        tracker.scanned(unit, outcome="guardrail", n_findings=0)
                if guardrail_hits >= guardrail_gate and successes == 0:
                    cli.abort()
                    ex.shutdown(wait=False, cancel_futures=True)
                    _guardrail_fail_fast(e)
                continue
            except Exception as e:
                if is_halt_error(e):
                    # Every remaining/in-flight unit would fail identically -- stop dispatching.
                    pending_batches = [b for f, b in futs.items() if not f.done()]
                    n_pending = sum(len(b) for b in pending_batches)
                    _mark_halted([batch, *pending_batches])
                    console.write(f"  [s4] unit {batch[0].id} HALTED "
                                  f"({type(e).__name__}) — cancelling {n_pending} "
                                  "pending unit(s); s4 stops early")
                    for unit in batch:
                        _errlog.log("s4", unit.id, e, scope="unit", files=len(unit.files))
                    COUNTERS.bump("s4_units_halted", len(batch) + n_pending)
                    cli.abort()
                    ex.shutdown(wait=False, cancel_futures=True)
                    halted = True
                    break
                retryable = (split_retry and len(batch) > 1
                            and not is_deterministic_failure(e) and not cli.aborted())
                for unit in batch:
                    outcomes[unit.id] = "error"
                    if retryable:
                        console.write(f"  [s4] unit {unit.id}: ERROR — retrying alone")
                        # recovered=True: the unit runs again alone; a failed retry logs its own row
                        _errlog.log("s4", unit.id, e, scope="unit",
                                    files=len(unit.files), recovered=True)
                        _resubmit(unit)
                        continue
                    console.write(f"  [s4] unit {unit.id} ERROR: {redact(str(e))}")
                    _errlog.log("s4", unit.id, e, scope="unit",
                                files=len(unit.files))
                    results[unit.id] = []
                    if tracker is not None:
                        tracker.scanned(unit, outcome="error", n_findings=0)
                continue
            successes += 1
            for unit in batch:
                findings = found.get(unit.id, [])
                verdict = verdict_by_unit.get(unit.id)
                if verdict in ("uninvestigated", "failed"):
                    outcomes[unit.id] = verdict
                    retryable = split_retry and len(batch) > 1 and not cli.aborted()
                    msg = ("model omitted this unit from the shared batch reply"
                          if verdict == "uninvestigated" else
                          "this unit's entry in the shared batch reply did not parse")
                    if retryable:
                        console.write(f"  [s4] unit {unit.id}: {verdict.upper()} — "
                                      f"retrying alone")
                        # recovered=True: the unit runs again alone; a failed retry logs its own row
                        _errlog.log("s4", unit.id, msg, scope="unit",
                                    files=len(unit.files), recovered=True)
                        _resubmit(unit)
                        continue
                    _errlog.log("s4", unit.id, msg, scope="unit",
                                files=len(unit.files),
                                reason=f"s4_batch_member_{verdict}")
                    console.write(f"  [s4] unit {unit.id}: {verdict.upper()} — "
                                  f"no findings recorded")
                    results[unit.id] = []
                    if tracker is not None:
                        tracker.scanned(unit, outcome=verdict, n_findings=0)
                    continue
                results[unit.id] = findings
                outcomes[unit.id] = "completed"
                if tracker is not None:
                    tracker.scanned(unit, outcome="completed", n_findings=len(findings))
                merged = merged_by_unit.get(unit.id, 0)
                suffix = f" ({merged} merged, same site)" if merged else ""
                console.write(f"  [s4] unit {unit.id}: {len(findings)} findings{suffix}")

        # A halt-class error fails every resubmit identically too; nothing left to wait on.
        for fut in (as_completed(retry_futs) if not halted else ()):
            batch = retry_futs[fut]
            try:
                found, merged_by_unit, verdict_by_unit = fut.result()
            except GuardrailBlocked as e:
                guardrail_hits, gate_label = guardrail_gate_hit(e, guardrail_hits, guardrail_gate)
                for unit in batch:
                    console.write(f"  [s4] unit {unit.id} GUARDRAIL-BLOCKED ({gate_label})")
                    _errlog.log("s4", f"guardrail:{unit.id}", e, scope="unit",
                                files=len(unit.files))
                    results[unit.id] = []
                    outcomes[unit.id] = "guardrail"
                    if tracker is not None:
                        tracker.scanned(unit, outcome="guardrail", n_findings=0)
                if guardrail_hits >= guardrail_gate and successes == 0:
                    cli.abort()
                    ex.shutdown(wait=False, cancel_futures=True)
                    _guardrail_fail_fast(e)
                continue
            except Exception as e:
                if is_halt_error(e):
                    pending_batches = ([b for f, b in futs.items() if not f.done()]
                                      + [b for f, b in retry_futs.items() if not f.done()])
                    n_pending = sum(len(b) for b in pending_batches)
                    _mark_halted([batch, *pending_batches])
                    console.write(f"  [s4] unit {batch[0].id} HALTED "
                                  f"({type(e).__name__}) — cancelling {n_pending} "
                                  "pending unit(s); s4 stops early")
                    for unit in batch:
                        _errlog.log("s4", unit.id, e, scope="unit", files=len(unit.files))
                    COUNTERS.bump("s4_units_halted", len(batch) + n_pending)
                    cli.abort()
                    ex.shutdown(wait=False, cancel_futures=True)
                    halted = True
                    break
                for unit in batch:
                    console.write(f"  [s4] unit {unit.id} ERROR: {redact(str(e))}")
                    _errlog.log("s4", unit.id, e, scope="unit",
                                files=len(unit.files))
                    results[unit.id] = []
                    outcomes[unit.id] = "error"
                    if tracker is not None:
                        tracker.scanned(unit, outcome="error", n_findings=0)
                continue
            successes += 1
            for unit in batch:
                findings = found.get(unit.id, [])
                results[unit.id] = findings
                outcomes[unit.id] = "completed"
                COUNTERS.bump("s4_batch_member_recovered")
                if tracker is not None:
                    tracker.scanned(unit, outcome="completed", n_findings=len(findings))
                merged = merged_by_unit.get(unit.id, 0)
                suffix = f" ({merged} merged, same site)" if merged else ""
                console.write(f"  [s4] unit {unit.id}: {len(findings)} findings{suffix}")
    except (KeyboardInterrupt, SystemExit):
        n = cli.abort()
        console.write(f"  [s4] interrupted — killed {n} running subprocess(es), "
                      f"cancelling {sum(1 for f in futs if not f.done())} pending sessions")
        ex.shutdown(wait=False, cancel_futures=True)
        raise
    finally:
        ex.shutdown(wait=True)

    # Reassemble in risk-rank order so downstream ordering is stable.
    all_findings: list[Finding] = []
    for unit in units:
        all_findings.extend(results.get(unit.id, []))
    completed_count = sum(1 for v in outcomes.values() if v == "completed")
    error_count = sum(1 for v in outcomes.values() if v == "error")
    guardrail_count = sum(1 for v in outcomes.values() if v == "guardrail")
    uninvestigated_count = sum(1 for v in outcomes.values() if v == "uninvestigated")
    failed_count = sum(1 for v in outcomes.values() if v == "failed")
    halted_count = sum(1 for v in outcomes.values() if v == "halted")
    log.info("s4/deepdive: parallel processing complete - units=%d (completed=%d errors=%d "
             "guardrails=%d uninvestigated=%d failed=%d halted=%d) findings=%d",
             len(units), completed_count, error_count, guardrail_count,
             uninvestigated_count, failed_count, halted_count, len(all_findings))
    if tracker is not None:
        tracker.print_summary()
    return all_findings, outcomes


def _batch_size(cfg) -> int:
    """Units per shared session."""
    return _cap_int(cfg.step4, "batch_size", 1)


def _submit_batch(ex: ThreadPoolExecutor, batch: list[InvestigationUnit],
                  investigate, ctx: ContextPackage, repo_root: Path, cfg):
    """Submit one work item, returning a future that resolves to
    ``(findings_by_unit, merged_by_unit, verdict_by_unit)`` — *verdict_by_unit* carries
    "uninvestigated"/"failed" for a batch member the shared reply omitted or that didn't
    parse, so the caller never mistakes that member for a clean "completed" unit."""
    if len(batch) == 1:
        unit = batch[0]
        def _run_one():
            stats: dict = {}
            findings = investigate(unit, ctx, repo_root, cfg, stats=stats)
            return {unit.id: findings}, {unit.id: stats.get("merged", 0)}, {}
        return ex.submit(_run_one)
    # investigate_batch caps and dedups per member like the single-unit path, and
    # reports its merge counts through stats["merged_by_unit"]
    from vvaharness.pipeline.stages.s4.session import investigate_batch
    def _run_batch():
        stats: dict = {}
        out, verdict_by_unit = investigate_batch(batch, ctx, repo_root, cfg, stats=stats)
        return out, stats.get("merged_by_unit", {}), verdict_by_unit
    return ex.submit(_run_batch)


# Sized so the shared prefix clears Anthropic's 1024-token cache minimum even on a small repo
_SHARED_CTX_MAX_SYSTEM_CHARS = 4000   # threat-model system_context
_SHARED_CTX_MAX_THREATS      = 25
_SHARED_CTX_MAX_BOUNDARIES   = 15
_SHARED_CTX_MAX_ASSETS       = 10
_SHARED_CTX_MAX_EPS          = 60    # entry points included in inventory


def _build_shared_context_block(ctx: ContextPackage) -> str:
    """Build the never-empty, cache-marked context prefix that is byte-identical for every unit of the scan."""
    parts: list[str] = []

    if ctx.app_profile:
        parts.append(ctx.app_profile.to_prompt_block())

    if ctx.threat_model:
        parts.append(ctx.threat_model.to_compact_prompt_block(
            max_context_chars=_SHARED_CTX_MAX_SYSTEM_CHARS,
            max_assets=_SHARED_CTX_MAX_ASSETS,
            max_boundaries=_SHARED_CTX_MAX_BOUNDARIES,
            max_threats=_SHARED_CTX_MAX_THREATS,
        ))

    # Sorted for byte-identical output on every call, or the cache prefix misses.
    if ctx.entry_points:
        eps = sorted(ctx.entry_points,
                     key=lambda e: (e.file, e.function))[:_SHARED_CTX_MAX_EPS]
        ep_lines = [
            f"ENTRY POINT INVENTORY ({len(eps)}/{len(ctx.entry_points)} total):"
        ]
        for ep in eps:
            auth_tag = "[unauth]" if ep.reachable_from_unauth else "[auth]"
            ep_lines.append(f"  {auth_tag} [{ep.kind}] {ep.file}::{ep.function}")
        if len(ctx.entry_points) > _SHARED_CTX_MAX_EPS:
            ep_lines.append(
                f"  …({len(ctx.entry_points) - _SHARED_CTX_MAX_EPS} more omitted)"
            )
        parts.append("\n".join(ep_lines))

    parts.append(
        "TRUST RULE: Operator argv/env on the operator's OWN host is TRUSTED.\n"
        "CI job parameters, scheduler args, shared config/CSV/test-data files "
        "editable by other principals, and framework-overridable variables ARE "
        "attack surface even on an internal app — report those (typically LOW). "
        "See OUT-OF-SCOPE rule A."
    )

    return "\n\n".join(p for p in parts if p)


# s4/session.py inlines this loading path for units small enough for step4.inline_source.

_PAN_RX = re.compile(r"\b(?:\d[\s\-]?){13,19}\b")

# Card keyword just before the digit run, so a labelled non-Luhn test PAN is caught too.
_CARD_CTX = re.compile(
    r"(?i)\b(pan|card(?:[\s_-]*(?:no|num|number))?"
    r"|cc(?:[\s_-]*(?:no|num|number))?|credit[\s_-]*card"
    r"|acct|account(?:[\s_-]*(?:no|num|number))?)\b")


def _mask_pan(m: re.Match) -> str:
    s = m.group(0)
    digits = re.sub(r"\D", "", s)
    if len(digits) < 13:
        return s
    # Luhn-or-keyword gate (length-only mangles timestamps/ids): CWE-201 egress; BIN+layout survive
    window = m.string[max(0, m.start() - 48): m.start()]
    if not (_luhn(digits) or _CARD_CTX.search(window)):
        return s
    kept = 0
    out = []
    for c in s:
        if c.isdigit():
            out.append(c if kept < 4 else "X")
            kept += 1
        else:
            out.append(c)
    return "".join(out)


# Keyed "{stage}:{rel}" so s4 and s8 warn separately; in _REGISTRY_SITES so batch runs reset it
_WARNED_REDACTED_SOURCE: set[str] = set()


def _redact_source(text: str, rel: str, *, stage: str = "s4") -> str:
    """Return source with PANs and other sensitive tokens masked, for s4/s6/s8 prompt packing."""
    # Masking makes the call succeed, not just privacy: an endpoint can reject an embedded data: URI
    text = sanitize_packed_text(text, rel)
    # Count only runs actually masked: _mask_pan leaves non-card runs, so subn would over-report
    n_pan = 0
    def _count_mask(m: re.Match) -> str:
        nonlocal n_pan
        repl = _mask_pan(m)
        if repl != m.group(0):
            n_pan += 1
        return repl
    # Both layers add and remove no newlines, so finding line numbers stay accurate.
    masked = _PAN_RX.sub(_count_mask, text)
    # redact_counts, not redact: s4 runs concurrently and must not race redact's shared counts
    masked, counts = redact_counts(masked)
    n_other = sum(counts.values())
    if n_pan or n_other:
        detail = (" [" + ", ".join(f"{k}:{v}" for k, v in sorted(counts.items())) + "]"
                  if counts else "")
        warn_once(_WARNED_REDACTED_SOURCE, f"{stage}:{rel}",
                  f"    [{stage}] redacted {n_pan} PAN-prefix + {n_other} sensitive "
                  f"token(s) in {rel}{detail}")
    return masked


# Per-line cap: a minified one-line file would otherwise become one enormous "line".
MAX_LINE_CHARS = 8000


def _load_files_full(files: list[str], repo_root: Path, *, stage: str = "s4") -> str:
    """Return a whole-file, line-numbered, redacted dump of *files* for inline-source prompts."""
    parts = []
    for rel in files:
        p = repo_root / rel
        if not p.is_file():
            parts.append(f"=== {rel} ===\n[FILE NOT FOUND]\n")
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            parts.append(f"=== {rel} ===\n[READ ERROR: {e}]\n")
            continue
        text = _redact_source(text, rel, stage=stage)
        numbered = "\n".join(f"{i+1:5d}| {ln[:MAX_LINE_CHARS]}"
                             for i, ln in enumerate(text.splitlines()))
        parts.append(f"=== {rel} ===\n{numbered}\n")
    return "\n".join(parts)


