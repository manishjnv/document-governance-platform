# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Dedupe near-identical config files the walk would otherwise keep twice."""
from __future__ import annotations

import configparser
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path

from vvaharness.scope.walk import _DEDUP_DEFAULTS, _INSECURE_RX, _SECRET_RX
from vvaharness.util import console, logs

log = logs.get_logger(__name__)

def _flatten_keys(obj, prefix: str = "") -> list[str]:
    if isinstance(obj, dict):
        out: list[str] = []
        for k in obj:
            out.extend(_flatten_keys(obj[k], f"{prefix}.{k}" if prefix else str(k)))
        return out or [prefix]
    if isinstance(obj, list):
        out = []
        for it in obj:
            out.extend(_flatten_keys(it, f"{prefix}[]"))
        return out or [prefix]
    return [prefix]


_KV_LINE_RX = re.compile(r"^\s*([A-Za-z0-9_.\-]+)\s*[:=]")
_YAML_KEY_RX = re.compile(r"^( *)(?:- +)?([\w.\-]+)\s*:")


def _shape_hash(text: str, ext: str) -> str | None:
    """Hash of the sorted key-path set (values stripped)."""
    keys: list[str] = []
    try:
        if ext in (".yml", ".yaml"):
            stack: list[tuple[int, str]] = []
            for ln in text.splitlines():
                if not ln or ln.lstrip().startswith("#"):
                    continue
                m = _YAML_KEY_RX.match(ln)
                if not m:
                    continue
                indent, name = len(m.group(1)), m.group(2)
                while stack and stack[-1][0] >= indent:
                    stack.pop()
                stack.append((indent, name))
                keys.append(".".join(n for _, n in stack))
        elif ext == ".json":
            keys = _flatten_keys(json.loads(text))
        elif ext in (".ini", ".cfg", ".conf"):
            cp = configparser.ConfigParser(strict=False, allow_no_value=True)
            cp.read_string(text)
            for sec in cp.sections():
                for opt in cp.options(sec):
                    keys.append(f"{sec}.{opt}")
        else:
            for ln in text.splitlines():
                m = _KV_LINE_RX.match(ln)
                if m:
                    keys.append(m.group(1))
    except Exception:
        return None
    if not keys:
        return None
    return hashlib.sha1("\n".join(sorted(set(keys))).encode()).hexdigest()


def _suspicious_set(text: str, want_secret: bool, want_insecure: bool) -> set[str]:
    """Normalized set of suspicious-pattern hits — used to diff a candidate against its cluster representative s..."""
    out: set[str] = set()
    if want_secret:
        for m in _SECRET_RX.finditer(text):
            out.add("secret:" + re.sub(r"\s+", " ", m.group(0))[:80])
    if want_insecure:
        for m in _INSECURE_RX.finditer(text):
            out.add("insecure:" + re.sub(r"\s+", " ", m.group(0))[:80])
    return out


_REASON_KEY_RX = re.compile(r"[A-Za-z0-9_.\-]+(?=[ \t]*[:=])")


def _promotion_reason(entry: str) -> str:
    """The human "promoted because" reason for one `_suspicious_set` entry."""
    # The entry embeds raw matched text incl. the secret VALUE, so name only the KEY here
    label, _, hit = entry.partition(":")
    m = _REASON_KEY_RX.match(hit)
    if m:
        return f"{label} key: {m.group(0)}"
    if hit.startswith("-----BEGIN"):
        return f"{label}: private-key block"
    if hit.startswith(("AKIA", "eyJ")):
        return f"{label}: bare credential token"
    return label


def _rep_score(rel: str, size: int) -> tuple:
    """Pick the most production-relevant variant as the cluster representative."""
    low = rel.lower()
    env = (0 if "/prod" in low else
           1 if any(e in low for e in ("/cert", "/stag", "/stg")) else
           2 if any(e in low for e in ("/perf", "/qa")) else
           3)
    return (env, -size, rel)


def _dedup_configs(files: list[str], repo_root: Path, cfg) -> tuple[list[str], dict]:
    dd = dict(_DEDUP_DEFAULTS)
    user = getattr(getattr(cfg, "step1", None), "config_dedup", None)
    if user is not None:
        raw = (user if isinstance(user, dict)
               else getattr(user, "_data", None) or vars(user))
        dd.update({k: v for k, v in raw.items() if v is not None})
    if not dd["enabled"]:
        return files, {"enabled": False}

    exts = {e.lower() for e in dd["exts"]}
    min_cluster = int(dd["min_cluster_size"])
    max_bytes = int(dd["max_file_kb"]) * 1024

    candidates: list[str] = []
    passthrough: list[str] = []
    for rel in files:
        if Path(rel).suffix.lower() in exts:
            candidates.append(rel)
        else:
            passthrough.append(rel)

    if len(candidates) < min_cluster:
        return files, {"enabled": True, "candidates": len(candidates),
                       "clusters": 0, "dropped": 0, "promoted": 0}

    want_sec = dd["promote_on_secret_hit"]
    want_ins = dd["promote_on_insecure_value"]

    # Pass 1 DISCARDS bodies after hashing (RAM must not scale with count); parallel: I/O-bound, a large win on Windows
    def _hash(rel: str):
        p = repo_root / rel
        try:
            sz = p.stat().st_size
            if sz > max_bytes:
                return rel, sz, None
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return rel, 0, None
        return rel, sz, _shape_hash(text, p.suffix.lower())

    clusters: dict[str, list[tuple[str, int]]] = defaultdict(list)
    unclustered: list[str] = []
    from concurrent.futures import ThreadPoolExecutor
    workers = int(dd.get("io_workers", 16))
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for rel, sz, h in ex.map(_hash, candidates):
            if h is None:
                unclustered.append(rel)
            else:
                clusters[h].append((rel, sz))

    keep: list[str] = list(passthrough) + unclustered
    promoted: list[tuple[str, str]] = []
    dropped: list[str] = []
    cluster_report: list[dict] = []

    # Only large clusters need a body; re-read that bounded subset, retain the suspicious-SET only
    need_sus = [rel for members in clusters.values()
                if len(members) >= min_cluster for rel, _ in members]

    def _susload(rel: str):
        p = repo_root / rel
        try:
            if p.stat().st_size > max_bytes:
                return rel, None
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return rel, None
        return rel, _suspicious_set(text, want_sec, want_ins)

    sus_by_rel: dict[str, set[str]] = {}
    if need_sus:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            for rel, sus in ex.map(_susload, need_sus):
                if sus is not None:
                    sus_by_rel[rel] = sus

    # Pass 2 — only large clusters need the (expensive) suspicious-set diff.
    for h, members in clusters.items():
        if len(members) < min_cluster:
            keep.extend(r for r, _ in members)
            continue
        members.sort(key=lambda m: _rep_score(m[0], m[1]))
        reps: dict[str, str] = {}
        if dd["keep_per_top_dir"]:
            for rel, _ in members:
                reps.setdefault(rel.split("/", 1)[0], rel)
        else:
            reps["*"] = members[0][0]
        rep_set = set(reps.values())
        rep_sus: set[str] = set()
        for r in rep_set:
            rep_sus |= sus_by_rel.get(r, set())
        keep.extend(rep_set)

        c_dropped: list[str] = []
        for rel, _ in members:
            if rel in rep_set:
                continue
            if rel not in sus_by_rel:
                # Body unreadable on re-read (TOCTOU): cannot prove a pure duplicate, so keep it
                keep.append(rel)
                continue
            sus = sus_by_rel[rel]
            extra = sus - rep_sus
            if extra:
                keep.append(rel)
                promoted.append((rel, _promotion_reason(sorted(extra)[0])))
                rep_sus |= sus
            else:
                c_dropped.append(rel)
        dropped.extend(c_dropped)
        cluster_report.append({
            "shape": h[:12],
            "size": len(members),
            "reps": sorted(rep_set),
            "dropped": len(c_dropped),
            "sample": members[0][0],
        })

    cluster_report.sort(key=lambda c: -c["size"])
    report = {
        "enabled": True,
        "candidates": len(candidates),
        "unparseable_kept": len(unclustered),
        "clusters": len([c for c in cluster_report if c["size"] >= min_cluster]),
        "kept_reps": sum(len(c["reps"]) for c in cluster_report),
        "promoted": len(promoted),
        "promoted_files": promoted[:50],
        "dropped": len(dropped),
        "dropped_files": dropped,
        "top_clusters": cluster_report[:10],
    }

    if dropped:
        top = ", ".join(f"{c['sample']} x{c['size']}"
                        for c in cluster_report[:3])
        console.write(f"  [s1] config-dedup: {len(candidates)} config files -> "
                      f"{report['clusters']} shape-clusters; "
                      f"kept {report['kept_reps']} reps + {len(promoted)} promoted, "
                      f"dropped {len(dropped)} near-duplicates")
        console.write(f"  [s1]   largest: {top}")
        if promoted:
            console.write(f"  [s1]   promoted (suspicious value not in rep): "
                          f"{', '.join(p for p, _ in promoted[:5])}"
                          + (f" ... +{len(promoted)-5} more" if len(promoted) > 5 else ""))
    return sorted(keep), report
