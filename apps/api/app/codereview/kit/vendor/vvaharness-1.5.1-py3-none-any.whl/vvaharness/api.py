# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The embeddable surface: remediate a finding, validate a remediation."""

from __future__ import annotations

from pathlib import Path

from vvaharness.models import (
    Finding,
    MergeReadiness,
    Remediation,
    ScoringPolicy,
    Verdict,
    merge_readiness_for,
    state_of,
)

__all__ = [
    "Finding",
    "MergeReadiness",
    "Remediation",
    "ScoringPolicy",
    "Verdict",
    "merge_readiness_for",
    "remediate",
    "state_of",
    "validate",
]


def remediate(finding: Finding, *, repo: Path, mode: str = "fix",
              config: Path | None = None, verbose: bool = False) -> Remediation:
    """Attempt a fix for *finding* in *repo* and return what the harness can prove was done."""
    from vvaharness import __version__
    from vvaharness.orchestrator.artifacts import artifact_dir
    from vvaharness.orchestrator.checkpoints import REMEDIATE_PREFIX, save_ckpt, step_key_for
    from vvaharness.remediation_agent.discovery import prepare_layout
    from vvaharness.remediation_agent.plugin_runner import (
        ENGINE_ID,
        apply_plugin,
        checkpoint_record,
        engine_model,
    )
    from vvaharness.remediation_agent.target import RemediationTarget

    repo = Path(repo)
    cfg = _config(config)
    layout = prepare_layout(repo)
    target = RemediationTarget(finding=finding, index=1)
    out_dir = artifact_dir(layout.rem_dir, target.slug)
    remediation = apply_plugin(target, out_dir, cfg=cfg, repo=repo, mode=mode, verbose=verbose)
    # Save the same remediate_<digest> provenance row the CLI/in-scan paths save, so a case
    # created through this programmatic API is also trusted by S11 discovery
    # (vvaharness.remediation_agent.provenance.owned_cases) if the caller later runs
    # `vvaharness validate`/`s11` against the same repo instead of pairing it in-memory.
    model, backend = engine_model(cfg)
    step = step_key_for(REMEDIATE_PREFIX, engine_id=ENGINE_ID, engine_version=__version__,
                        case_id=target.case_id, model=model, backend=backend)
    record = {**checkpoint_record(target, out_dir, remediation), "finding_id": target.case_id}
    save_ckpt(layout.ckpt_dir, layout.run_id, step, record)
    return remediation


def validate(finding: Finding, remediation: Remediation, *, repo: Path,
             config: Path | None = None) -> Verdict:
    """Judge whether *remediation* fixes *finding* in *repo*; stages a copy, writes nothing back."""
    from vvaharness.validation.case_api import validate_case

    return validate_case(finding, remediation, repo=Path(repo),
                         config=_validation_config(config))


def _validation_config(config: Path | None) -> object:
    """The validation config tree; `None` lets ``validate_case`` default it against the repo."""
    if config is None:
        return None
    from vvaharness.validation.config import load_config

    return load_config(project_root=Path(config).parent)


def _config(config: Path | None) -> object:
    """Load *config*, or the packaged default profile when none is given."""
    from vvaharness import config as config_mod
    from vvaharness.orchestrator import _default_config

    return config_mod.load(str(config if config is not None else _default_config()))
