# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The default source/sink corpus, plus the declarative detector rules."""
from __future__ import annotations

from vvaharness.detect.spec import MatchSpec
from vvaharness.rules.cwe import OWASP_2025_BY_SEMANTIC

# Every callee must be a public, documented API defensible from CWE semantics; never benchmark-led


def _owasp(family: str) -> frozenset[str]:
    return frozenset(OWASP_2025_BY_SEMANTIC.get(family, ("A03:2025-Injection",)))


def _bare_call(name: str) -> str:
    return rf"(?<![\w.]){name}\s*\("


def _method_call(name: str) -> str:
    return rf"\.{name}\s*\("


def _qualified_call(module: str, name: str) -> str:
    return rf"\b{module}\.{name}\s*\("


# WHATWG markup subset; lower or ALL-CAPS only — a blanket (?i) reopens the `"<Data %s>"` repr idiom
_HTML_ELEMENTS = "|".join(f"{name}|{name.upper()}" for name in (
    "a", "abbr", "address", "area", "article", "aside", "audio",
    "b", "base", "bdi", "bdo", "blockquote", "body", "br", "button",
    "canvas", "caption", "cite", "code", "col", "colgroup",
    "data", "datalist", "dd", "del", "details", "dfn", "dialog", "div", "dl", "dt",
    "em", "embed", "fieldset", "figcaption", "figure", "footer", "form",
    "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html",
    "i", "iframe", "img", "input", "ins", "kbd", "label", "legend", "li", "link",
    "main", "map", "mark", "menu", "meta", "meter", "nav", "noscript",
    "object", "ol", "optgroup", "option", "output",
    "p", "param", "picture", "pre", "progress",
    "q", "rp", "rt", "ruby", "s", "samp", "script", "search", "section",
    "select", "slot", "small", "source", "span", "strong", "style", "sub",
    "summary", "sup", "svg",
    "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead",
    "time", "title", "tr", "track", "u", "ul", "var", "video", "wbr",
))

_COMMAND_METHODS = ("system", "popen", "spawn", "exec", "eval")
# `_bare_call` rejects dot-qualified receivers by design, so `os.system(` needs its own entry
_COMMAND_QUALIFIED = {
    "os": ("system",),
    "subprocess": ("run", "call", "check_output", "check_call", "Popen"),
}
_SQL_METHODS = ("execute", "executemany", "raw", "query")
_DESERIALIZE_METHODS = ("loads", "load", "deserialize", "unmarshal")
_DESERIALIZE_MODULE_METHODS = {
    "pickle": ("loads", "load"),
    "yaml": ("load",),
}

_SOURCE_ACCESSORS = {
    "request.args": "network",
    "request.form": "network",
    "request.json": "network",
    "request.data": "network",
    "request.headers": "network",
    "request.cookies": "network",
    "request.get_json": "network",
    # Django's HttpRequest is upper-case (plus `body`), so no Flask accessor above matches it
    "request.GET": "network",
    "request.POST": "network",
    "request.META": "network",
    "request.FILES": "network",
    "request.COOKIES": "network",
    "request.body": "network",
    "os.environ": "file",
    "os.getenv": "file",
    "sys.argv": "cli",
    "sys.stdin": "cli",
    # Base class names, NOT `self.path`/`self.headers`: a stdlib do_GET server read as non-web
    "BaseHTTPRequestHandler": "network",
    "SimpleHTTPRequestHandler": "network",
}


def _command_specs() -> list[MatchSpec]:
    specs = [
        MatchSpec(
            rule_id=f"detect-sink-command-{name}",
            role="sink",
            pattern=_bare_call(name),
            cwe="CWE-78",
            kind="command_injection",
            semantic_family="command-exec",
            owasp_top10_2025=_owasp("command-exec"),
        )
        for name in _COMMAND_METHODS
    ]
    specs.extend(
        MatchSpec(
            rule_id=f"detect-sink-command-{module}-{name}",
            role="sink",
            pattern=_qualified_call(module, name),
            cwe="CWE-78",
            kind="command_injection",
            semantic_family="command-exec",
            owasp_top10_2025=_owasp("command-exec"),
        )
        for module, names in _COMMAND_QUALIFIED.items()
        for name in names
    )
    return specs


def _template_specs() -> list[MatchSpec]:
    return [
        MatchSpec(
            rule_id="detect-sink-template-render_template_string",
            role="sink",
            pattern=_bare_call("render_template_string"),
            cwe="CWE-79",
            kind="xss",
            semantic_family="html-response",
            owasp_top10_2025=_owasp("html-response"),
        ),
    ]


def _cookie_specs() -> list[MatchSpec]:
    # Two specs because a MatchSpec holds one CWE; both ids MUST share the trailing segment (s0)
    return [
        MatchSpec(
            rule_id=f"detect-sink-cookie-{flag}-set_cookie",
            role="sink",
            pattern=_method_call("set_cookie"),
            cwe=cwe,
            kind="cookie_flag",
        )
        for flag, cwe in (("httponly", "CWE-1004"), ("secure", "CWE-614"))
    ]


def _sql_specs() -> list[MatchSpec]:
    return [
        MatchSpec(
            rule_id=f"detect-sink-sql-{name}",
            role="sink",
            pattern=_method_call(name),
            cwe="CWE-89",
            kind="sql_injection",
            semantic_family="sql-exec",
            owasp_top10_2025=_owasp("sql-exec"),
        )
        for name in _SQL_METHODS
    ]


def _deserialize_specs() -> list[MatchSpec]:
    specs = [
        MatchSpec(
            rule_id=f"detect-sink-deser-{name}",
            role="sink",
            pattern=_bare_call(name),
            cwe="CWE-502",
            kind="unsafe_deserialization",
            semantic_family="deserialization",
            owasp_top10_2025=_owasp("deserialization"),
        )
        for name in _DESERIALIZE_METHODS
    ]
    specs.extend(
        MatchSpec(
            rule_id=f"detect-sink-deser-{module}-{name}",
            role="sink",
            pattern=_qualified_call(module, name),
            cwe="CWE-502",
            kind="unsafe_deserialization",
            semantic_family="deserialization",
            owasp_top10_2025=_owasp("deserialization"),
        )
        for module, names in _DESERIALIZE_MODULE_METHODS.items()
        for name in names
    )
    return specs


def _source_specs() -> list[MatchSpec]:
    return [
        MatchSpec(
            rule_id=f"detect-source-{accessor}",
            role="source",
            pattern=rf"\b{accessor}\b",
            cwe="CWE-20",
            kind=kind,
            semantic_family="untrusted-input",
            owasp_top10_2025=_owasp("untrusted-input"),
        )
        for accessor, kind in _SOURCE_ACCESSORS.items()
    ]


def default_corpus() -> list[MatchSpec]:
    """Return the built-in source/sink patterns."""
    return [*_command_specs(), *_sql_specs(), *_deserialize_specs(),
            *_template_specs(), *_cookie_specs(), *_source_specs()]


# s5 detector rules: role="detector" keeps them out of s0's source/sink view; all go through s6

def detector_corpus() -> list[MatchSpec]:
    """Return the built-in s5 detector rules."""
    return [
        MatchSpec(
            rule_id="detector-cookie-httponly",
            role="detector",
            pattern=r"\.set_cookie\s*\(",
            cwe="CWE-1004",
            kind="cookie-flag",
            languages=frozenset({"python"}),
            title="Cookie set without the HttpOnly flag",
            citation="CWE-1004: Sensitive Cookie Without 'HttpOnly' Flag "
                     "(https://cwe.mitre.org/data/definitions/1004.html)",
            span="call",
            span_max_lines=20,
            # Truthy only; `httponly=flag` is a deliberate false negative, not a miss
            absent_re=r"(?i)\bhttponly\s*=\s*(?!false\b|none\b|0\b)",
        ),
        MatchSpec(
            rule_id="detector-cookie-secure",
            role="detector",
            pattern=r"\.set_cookie\s*\(",
            cwe="CWE-614",
            kind="cookie-flag",
            languages=frozenset({"python"}),
            title="Cookie set without the Secure flag",
            citation="CWE-614: Sensitive Cookie in HTTPS Session Without 'Secure' "
                     "Attribute (https://cwe.mitre.org/data/definitions/614.html)",
            span="call",
            span_max_lines=20,
            # `\bsecure\s*=`, not a bare word: that matched `path="/secure/area"`.
            absent_re=r"(?i)\bsecure\s*=\s*(?!false\b|none\b|0\b)",
        ),
        MatchSpec(
            rule_id="detector-autoescape-off-code",
            role="detector",
            pattern=r"\bautoescape\s*=\s*False\b",
            cwe="CWE-79",
            kind="xss",
            semantic_family="html-response",
            languages=frozenset({"python"}),
            title="Template auto-escaping explicitly disabled",
            citation="CWE-79: Improper Neutralization of Input During Web Page "
                     "Generation (https://cwe.mitre.org/data/definitions/79.html)",
        ),
        MatchSpec(
            rule_id="detector-autoescape-off-template",
            role="detector",
            pattern=r"\{%-?\s*autoescape\s+(?:false|off)\b",
            cwe="CWE-79",
            kind="xss",
            semantic_family="html-response",
            languages=frozenset({"web-template"}),
            title="Template block disables auto-escaping",
            citation="CWE-79: Improper Neutralization of Input During Web Page "
                     "Generation (https://cwe.mitre.org/data/definitions/79.html)",
        ),
        MatchSpec(
            rule_id="detector-jinja-env-noescape",
            role="detector",
            pattern=r"\bEnvironment\s*\(",
            cwe="CWE-79",
            kind="xss",
            semantic_family="html-response",
            languages=frozenset({"python"}),
            title="Jinja2 Environment constructed without autoescape",
            citation="CWE-79 via jinja2.Environment(autoescape=False is the "
                     "default) (https://cwe.mitre.org/data/definitions/79.html)",
            span="call",
            span_max_lines=20,
            absent_re=r"autoescape",
            # File-scope import; `[^\S\n]*` not `\s*`: `\s*` here costs minutes
            file_re=r"(?m)^[^\S\n]*(?:import\s+jinja2\b|from\s+jinja2(?:\.\w+)*\s+import\b)",
        ),
        MatchSpec(
            rule_id="detector-template-safe",
            role="detector",
            pattern=r"\{\{[^{}]*\|\s*safe\b",
            cwe="CWE-79",
            kind="xss",
            semantic_family="html-response",
            languages=frozenset({"web-template"}),
            title="Template output piped through |safe",
            citation="CWE-79: the |safe filter marks a value exempt from output "
                     "escaping (https://cwe.mitre.org/data/definitions/79.html)",
        ),
        MatchSpec(
            rule_id="detector-docwrite-location",
            role="detector",
            pattern=r"document\.write(?:ln)?\s*\(",
            cwe="CWE-79",
            kind="xss",
            semantic_family="html-response",
            languages=frozenset({"javascript", "typescript", "web-template"}),
            title="document.write near a URL-derived value",
            citation="CWE-79 DOM-based XSS via document.write of location data "
                     "(https://owasp.org/www-community/attacks/DOM_Based_XSS)",
            # Proximity gate: a bare document.write("static") is not a finding.
            near_re=r"(?:\blocation\.|\bdocument\.URL\b|\bdecodeURIComponent\s*\()",
            near_window=3,
        ),
        MatchSpec(
            rule_id="detector-form-no-csrf-post",
            role="detector",
            # Default OFF: low precision, blind to global CSRF middleware
            enabled=False,
            pattern=r"<form\b",
            cwe="CWE-352",
            kind="csrf",
            languages=frozenset({"web-template"}),
            title="POST form without a CSRF token",
            citation="CWE-352: Cross-Site Request Forgery "
                     "(https://cwe.mitre.org/data/definitions/352.html)",
            span="block",
            span_end=r"</form",
            span_max_lines=120,
            present_re=r"(?is)method\s*=\s*[\"']?post",
            absent_re=r"(?i)csrf|hidden_tag\s*\(|authenticity_token|__RequestVerificationToken",
        ),
        MatchSpec(
            rule_id="detector-form-get-password",
            role="detector",
            # Default OFF: precision not established
            enabled=False,
            pattern=r"<form\b",
            cwe="CWE-598",
            kind="sensitive-data",
            languages=frozenset({"web-template"}),
            title="Password form submits with GET",
            citation="CWE-598: Use of GET Request Method With Sensitive Query Strings "
                     "(https://cwe.mitre.org/data/definitions/598.html)",
            span="block",
            span_end=r"</form",
            span_max_lines=120,
            present_re=r"(?is)type\s*=\s*[\"']?password",
            absent_re=r"(?i)method\s*=\s*[\"']?post",
        ),
        MatchSpec(
            rule_id="detector-httpresponse-concat",
            role="detector",
            pattern=r"\bHttpResponse\s*\(",
            cwe="CWE-79",
            kind="xss",
            semantic_family="html-response",
            languages=frozenset({"python"}),
            title="HttpResponse built from string interpolation",
            citation="CWE-79: response body assembled by concatenation/format "
                     "bypasses template escaping "
                     "(https://cwe.mitre.org/data/definitions/79.html)",
            span="call",
            span_max_lines=20,
            # `+` needs a STRING-ish operand: bare `\+` fired on arithmetic; `%20` excluded
            present_re=r"(?:[\"']\s*\+|\+\s*[\"']|[\"'\s]%[\s_a-zA-Z(\"']"
                       r"|%\s*\(|\.format\s*\(|\bf[\"'])",
        ),
        MatchSpec(
            rule_id="detector-html-string-concat",
            role="detector",
            # Real element name required; `[^<>]` must admit BOTH quotes or attributed tags are lost
            pattern=(r"[\"']<(?:!--|/?(?:" + _HTML_ELEMENTS
                     + r")\b[^<>]{0,160}?>)"),
            cwe="CWE-79",
            kind="xss",
            semantic_family="html-response",
            languages=frozenset({"python"}),
            title="HTML assembled by string concatenation",
            citation="CWE-79: HTML built from values without output encoding "
                     "(https://cwe.mitre.org/data/definitions/79.html)",
            # No brace required before the first quote; the `<` bounds the loosening to ONE literal
            present_re=r"(?:\+\s*[A-Za-z_(]|[\"'\s]%[\s_a-zA-Z(\"']|%\s*\("
                       r"|\.format\s*\(|\bf[\"']<[^\n]{0,200}\{)",
            # Already-encoded output is not this defect; `struct`/`repr` mimic markup, never respond
            absent_re=r"(?:\b(?:escape|quote|quoteattr|sanitize|bleach|Markup)\s*\(|"
                      r"\bstruct\.\w+\s*\(|\b__repr__\b)",
            # A line-wrapped `escape(...)` fired while the one-liner was clean; widens the guard
            absent_window=2,
        ),
    ]
