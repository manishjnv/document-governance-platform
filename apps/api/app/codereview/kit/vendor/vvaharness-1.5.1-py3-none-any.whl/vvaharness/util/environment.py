# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Environment readiness engine shared by ``vvaharness setup`` and ``vvaharness doctor``."""
# NEVER print or return credential material here — only presence (set / unset); the CLI renders.
from __future__ import annotations

import importlib.metadata
import importlib.util
import os
import shutil
import socket
import ssl
import sys
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

import yaml

from vvaharness import config as config_mod
from vvaharness.backends.harness.provider_routing import routes_to_anthropic
from vvaharness.backends.llm.registry import (
    DEEPAGENTS_ROLES,
    POST_SCAN_ROLES,
    unrecognized_model_keys,
)
from vvaharness.config.constants import LOCAL_OVERLAY_NAME, NO_LOCAL_CONFIG_ENV
from vvaharness.orchestrator.config_paths import _iter_model_roles
from vvaharness.validation.config.validate_role import (
    normalize_validate_backend,
    validate_model_spec,
)

OK = "ok"
WARN = "warn"
FAIL = "fail"


@dataclass(frozen=True)
class Check:
    name: str
    status: str            # OK | WARN | FAIL
    detail: str
    # A FAIL blocks setup/doctor (exit non-zero) but NOT `scan`: nothing there calls run_checks
    required: bool = False


def _is_set(env: str) -> bool:
    return bool(os.environ.get(env))


def _looks_like_jwt(v: str | None) -> bool:
    """Whether *value* has a JWT prefix shape ('eyJ...') rather than an 'sk-ant-' API key."""
    if not v:
        return False
    if v.startswith("eyJ"):
        return True
    # Some gateways issue opaque JWT-like session tokens that don't begin with eyJ.
    parts = v.split(".")
    if len(parts) == 3 and v.startswith("ey"):
        return all(bool(p) for p in parts)
    return False


def python_check() -> Check:
    """Interpreter floor, read from installed package metadata."""
    # Fallback for a source tree; a sub-3.11 interpreter can't even import us (vocab.py StrEnum)
    floor = (3, 10)
    try:
        import re
        from importlib.metadata import metadata
        req = metadata("vvaharness").get("Requires-Python") or ""
        m = re.search(r">=\s*(\d+)\.(\d+)", req)
        if m:
            floor = (int(m.group(1)), int(m.group(2)))
    except Exception:
        pass
    cur = ".".join(str(v) for v in sys.version_info[:3])
    if sys.version_info[:2] >= floor:
        return Check("Python", OK, f"{cur} (≥ {floor[0]}.{floor[1]})")
    return Check("Python", FAIL,
                 f"{cur} — requires ≥ {floor[0]}.{floor[1]}", required=True)


def tool_check(cmd: str, why: str, *, required: bool = False) -> Check:
    path = shutil.which(cmd)
    if path:
        return Check(cmd, OK, path)
    return Check(cmd, FAIL if required else WARN, f"not on PATH ({why})",
                 required=required)


# AI coding agents the harness can drive: (display, command, env keys, backend it maps to)
_AGENTS = [
    ("Claude Code", "claude", ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN",
                               "CLAUDE_CODE_OAUTH_TOKEN"), "via:cli"),
    ("OpenAI Codex", "codex", ("OPENAI_API_KEY",), "via:openai"),
    ("Gemini CLI", "gemini", ("GEMINI_API_KEY", "GOOGLE_API_KEY"), "—"),
    ("Cursor Agent", "cursor-agent", (), "—"),
    ("GitHub Copilot CLI", "copilot", (), "via:cli"),
]


def _claude_code_login_present() -> bool:
    """Whether a Claude Code login is detectable on disk."""
    # FALSE NEGATIVE BY DESIGN: macOS Keychain-only OAuth is invisible here; never make this a gate
    if (Path.home() / ".claude" / ".credentials.json").exists():
        return True
    state = Path.home() / ".claude.json"
    if not state.exists():
        return False
    try:
        import json
        data = json.loads(state.read_text(encoding="utf-8"))
    except Exception:
        return False
    return bool(data.get("oauthAccount"))


def agent_checks() -> list[Check]:
    """Detect installed AI agents and whether they are ready; presence only, never the key value."""
    out: list[Check] = []
    oauth = _claude_code_login_present()
    for display, cmd, keys, backend in _AGENTS:
        path = shutil.which(cmd)
        if not path:
            out.append(Check(f"agent: {display}", WARN, "not installed"))
            continue
        has_auth = (not keys) or any(_is_set(k) for k in keys) or (cmd == "claude" and oauth)
        if not keys:
            keyinfo = "installed"
        else:
            # "not detected", never "not logged in": a Keychain-only login is invisible here
            keyinfo = ("installed and logged in" if has_auth
                       else "installed; login not detected"
                            + (" (a macOS Keychain-only `claude` login is not "
                               "visible here — try `claude` once to confirm)"
                               if cmd == "claude" else ""))
        status = OK if has_auth else WARN
        out.append(Check(f"agent: {display}", status,
                         f"{cmd} ✓ ({backend}) — {keyinfo}"))
    return out


# (module import name, required for baseline runtime)
_DEPS = [
    ("pydantic", True),
    ("yaml", True),
    ("anthropic", True),
    ("tree_sitter", False),
    ("tree_sitter_language_pack", False),
    ("openai", False),
]


def dep_checks() -> list[Check]:
    out: list[Check] = []
    for mod, required in _DEPS:
        present = importlib.util.find_spec(mod) is not None
        label = {
            "yaml": "PyYAML",
            "tree_sitter": "tree-sitter",
            "tree_sitter_language_pack": "tree-sitter-language-pack",
        }.get(mod, mod)
        if present:
            out.append(Check(f"dep: {label}", OK, "importable"))
        elif required:
            out.append(Check(f"dep: {label}", FAIL, "missing", required=True))
        elif mod == "tree_sitter":
            out.append(Check(
                f"dep: {label}",
                WARN,
                "NOT INSTALLED — call graph falls back to regex (degraded taint coverage)",
            ))
        elif mod == "tree_sitter_language_pack":
            out.append(Check(
                f"dep: {label}",
                WARN,
                "NOT INSTALLED — tree-sitter AST plugins unavailable; call graph degrades",
            ))
        else:
            out.append(Check(f"dep: {label}", WARN,
                             "missing (optional — needed only for via:openai)"))
    out.append(graph_sdk_check())
    return out


_SDK_VENDOR_PARTS = ("vendor", "context_graph_sdk", "src", "context_graph_sdk")


def _module_dir(name: str) -> Path | None:
    """The directory *name* resolves to, or None when it cannot be imported at all."""
    try:
        spec = importlib.util.find_spec(name)
    except (ImportError, ValueError):
        return None
    origin = getattr(spec, "origin", None) if spec else None
    return Path(origin).resolve().parent if origin else None


def _separately_installed_sdk() -> str:
    """The version of a standalone context-graph-sdk distribution, or "" when correctly bundled."""
    try:
        return importlib.metadata.version("context-graph-sdk")
    except importlib.metadata.PackageNotFoundError:
        return ""


def graph_sdk_check() -> Check:
    """Confirm context_graph_sdk resolves inside this install, not a stray external checkout."""
    sdk = _module_dir("context_graph_sdk")
    if sdk is None:
        return Check("dep: context-graph-sdk", FAIL,
                     "not importable — S0/S1 cannot build the code graph", required=True)
    stray = _separately_installed_sdk()
    if stray:
        return Check("dep: context-graph-sdk", FAIL,
                     f"a standalone context-graph-sdk {stray} is installed at {sdk}. The copy "
                     f"vvaharness needs is bundled inside its own distribution and is NOT a "
                     f"separate package, so this one shadows it and fails S0/S1. "
                     f"Uninstall it: pip uninstall context-graph-sdk", required=True)
    own = _module_dir("vvaharness")
    if own is None or sdk.parent == own.parent or sdk == own.parent / Path(*_SDK_VENDOR_PARTS):
        return Check("dep: context-graph-sdk", OK, f"bundled ({sdk})")
    return Check("dep: context-graph-sdk", FAIL,
                 f"SHADOWED by an external install at {sdk} — the bundled copy under "
                 f"{own.parent} is being ignored, which fails S0/S1 with "
                 f"SnapshotLifecycleError. Uninstall it: pip uninstall context-graph-sdk",
                 required=True)


def _release(version: str) -> tuple[int, ...]:
    """The numeric release segment of *version*, for ordering comparisons."""
    # Not a full PEP 440 implementation -- `packaging` is not a declared dependency.
    import re

    core = version.split("!")[-1].split("+")[0]
    return tuple(int(n) for n in re.findall(r"\d+", core))


def anthropic_version_check() -> Check:
    """The installed ``anthropic`` against the ceiling vvaharness declares."""
    # Bound from Requires-Dist: catches an environment resolved past the range this
    # release was tested against -- a fresh install can drift past the declared cap.
    import re

    try:
        installed = importlib.metadata.version("anthropic")
    except importlib.metadata.PackageNotFoundError:
        # Deliberately not a FAIL: `dep: anthropic` already blocks; a vendored copy has no metadata
        return Check("anthropic version", OK,
                     "no version metadata found (see dep: anthropic)")
    try:
        reqs = importlib.metadata.requires("vvaharness") or []
    except importlib.metadata.PackageNotFoundError:
        reqs = []  # running from a source tree, with no distribution metadata
    # `[` so a future extra ("anthropic[vertex]<1.0") still matches instead of disabling the check
    spec = next((r for r in reqs if re.match(r"anthropic\s*[\[<>=!~]", r)), "")
    # packaging emits the upper bound FIRST ("anthropic<1.0,>=0.125.0"), so assume no clause order
    ceiling = re.search(r"<\s*(\d[^,\s]*)", spec)
    if not ceiling:
        return Check("anthropic version", OK,
                     f"{installed} (no declared ceiling to check against)")
    if _release(installed) < _release(ceiling.group(1)):
        return Check("anthropic version", OK,
                     f"{installed} (supported: <{ceiling.group(1)})")
    return Check(
        "anthropic version", FAIL,
        f"{installed} is out of the supported range — run "
        f"`pip install 'anthropic<{ceiling.group(1)}'`. This release was only "
        f"tested below that ceiling; a newer major can remove or change "
        f"parameters this harness depends on.",
        required=True)


# Credential env vars we report presence for (NEVER the value).
_CRED_ENVS = [
    "ANTHROPIC_SDK_API_KEY", "ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN",
    "CLAUDE_CODE_OAUTH_TOKEN", "OPENAI_API_KEY", "GEMINI_API_KEY",
    "GITHUB_TOKEN",
]


def credential_checks() -> list[Check]:
    out: list[Check] = []
    for env in _CRED_ENVS:
        out.append(Check(f"cred: {env}", OK if _is_set(env) else WARN,
                         "set" if _is_set(env) else "unset"))
    return out


# LangSmith tracing = undocumented egress; 0.11.1: on iff value == "true"; EARLIEST set var wins
_TRACING_GATE_ENVS = (
    ("LANGSMITH_TRACING_V2", "LANGCHAIN_TRACING_V2"),   # TRACING_V2 lookup
    ("LANGSMITH_TRACING", "LANGCHAIN_TRACING"),         # its TRACING fallback
)
# Presence only, never the value; without it the service 401s but the prompt bytes still leave
_TRACING_KEY_ENVS = ("LANGSMITH_API_KEY", "LANGCHAIN_API_KEY")


def _langsmith_tracing_gate() -> str | None:
    """The env var that switches LangChain/LangSmith tracing ON, or None."""
    # Replicated, not called: langsmith lru_caches its env reads and would be a doctor-load dep
    for group in _TRACING_GATE_ENVS:
        for name in group:
            v = os.environ.get(name)
            if v is not None and v.strip() != "":
                # First non-empty value in the group wins; only exact "true" enables tracing.
                return name if v == "true" else None
    return None


def langsmith_tracing_check() -> Check:
    """Warn when LangSmith tracing would exfiltrate prompt payloads."""
    # WARN, never FAIL: an operator may be deliberately tracing in a lab.
    gate = _langsmith_tracing_gate()
    if gate is None:
        return Check("LangSmith tracing", OK,
                     "disabled (no LANGSMITH_TRACING* / LANGCHAIN_TRACING* "
                     "gate variable is \"true\")")
    if importlib.util.find_spec("langsmith") is None:
        return Check("LangSmith tracing", OK,
                     f"{gate}=true is set, but the langsmith package is not "
                     "installed — no tracing can occur")
    key = next((k for k in _TRACING_KEY_ENVS if _is_set(k)), None)
    key_note = (f" {key} is also set, so the upload will be accepted."
                if key else
                " No LANGSMITH_API_KEY/LANGCHAIN_API_KEY is set, so the "
                "service will reject the upload — but the payload is still "
                "transmitted.")
    return Check(
        "LangSmith tracing", WARN,
        f"{gate}=true — every model prompt (which contains scanned "
        "repository source) and every completion will be sent to the "
        "LangSmith service, a third-party egress channel this tool does not "
        f"otherwise use.{key_note} Unset {gate} unless you are deliberately "
        "tracing in an isolated lab.")


def _gateway_check() -> Check:
    """Flag a JWT-shaped ANTHROPIC_API_KEY with no ANTHROPIC_BASE_URL, which 401s against public Anthropic."""
    base = os.environ.get("ANTHROPIC_BASE_URL")
    key = os.environ.get("ANTHROPIC_API_KEY")
    if base:
        # Strip the query string: a token embedded as a query parameter must not be echoed.
        return Check("via:sdk endpoint", OK,
                     f"ANTHROPIC_BASE_URL={base.split('?', 1)[0]}")
    if _looks_like_jwt(key):
        return Check("via:sdk endpoint", FAIL,
                     "ANTHROPIC_API_KEY looks like a gateway/Claude-Code token "
                     "(eyJ…) but ANTHROPIC_BASE_URL is unset — it will 401 "
                     "against the public API. Set ANTHROPIC_BASE_URL to your "
                     "gateway (and SSL_CERT_FILE — or sdk.ca_cert in the "
                     "profile — if it needs a private CA).",
                     required=True)
    return Check("via:sdk endpoint", OK, "public api.anthropic.com (default)")


_RC_FILES = (".zshrc", ".zprofile", ".bashrc", ".bash_profile", ".profile")
_BASE_URL_RX = None  # compiled lazily


def detect_gateway() -> tuple[str | None, str | None]:
    """Find a usable ANTHROPIC_BASE_URL from the env or the shell rc files; reads only, never writes."""
    import re
    live = os.environ.get("ANTHROPIC_BASE_URL")
    if live:
        return live, "environment"
    rx = re.compile(r'ANTHROPIC_BASE_URL\s*=\s*["\']?(https?://[^"\'\s]+)')
    for name in _RC_FILES:
        p = Path.home() / name
        if not p.is_file():
            continue
        try:
            for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
                m = rx.search(line)
                if m:
                    return m.group(1), f"~/{name}"
                    # (commented lines match too — that's the point: surface it)
        except OSError:
            continue
    return None, None


def detect_ca_cert() -> str | None:
    """A private-CA bundle the gateway may need (NODE_EXTRA_CA_CERTS), else ~/cacerts.pem if present."""
    env_cert = os.environ.get("NODE_EXTRA_CA_CERTS")
    if env_cert and Path(env_cert).is_file():
        return env_cert
    default = Path.home() / "cacerts.pem"
    return str(default) if default.is_file() else None


def recommend_profile() -> tuple[str | None, str]:
    """Suggest the shipped profile matching the credentials actually available, as (name, reason)."""
    # A starting recommendation only -- config_check reports the exact per-route gaps.
    cli_auth = shutil.which("claude") and (
        _looks_like_jwt(os.environ.get("ANTHROPIC_API_KEY"))
        or _is_set("ANTHROPIC_AUTH_TOKEN")
        or _is_set("CLAUDE_CODE_OAUTH_TOKEN")
        or _claude_code_login_present())
    if cli_auth and _is_set("ANTHROPIC_SDK_API_KEY"):
        return "default", ("Claude Code auth and ANTHROPIC_SDK_API_KEY both "
                           "present — default.yaml routes through "
                           "deepagents/Anthropic and setup checks any "
                           "remaining provider gaps separately")
    if cli_auth:
        return "default", ("Claude Code auth detected — default.yaml uses "
                           "deepagents/Anthropic; set ANTHROPIC_API_KEY, "
                           "ANTHROPIC_AUTH_TOKEN, or ANTHROPIC_SDK_API_KEY "
                           "before scanning")
    if _is_set("ANTHROPIC_SDK_API_KEY"):
        return "sdk", ("ANTHROPIC_SDK_API_KEY is set — sdk.yaml routes model "
                       "roles via sdk; setup checks the S11 credential separately")
    if _is_set("OPENAI_API_KEY"):
        return "full", ("OPENAI_API_KEY is set — full.yaml includes OpenAI "
                        "roles; setup checks its other backends separately")
    return None, "no usable credential detected yet"


def dotenv_check() -> Check:
    """Report the trusted cwd/home .env selected by CLI startup, if present."""
    from vvaharness.cli import _dotenv_selection

    path, source, rejected = _dotenv_selection()
    ignored = ", ".join(str(p) for p in rejected)
    if path is None:
        if rejected:
            return Check(".env", WARN, f"ignored untrusted file(s): {ignored}")
        return Check(".env", OK, "not found (optional; use setup --write-env)")
    detail = ".env found" if source == "cwd" else f"{path} found"
    if rejected:
        return Check(".env", WARN, f"{detail}; ignored untrusted file(s): {ignored}")
    return Check(".env", OK, detail)


def _applied_overlay_check(name: str, local: Path, cfg_path: str | Path) -> Check:
    """Render a trusted overlay's overridden leaf keys with resolved values."""
    try:
        over = yaml.safe_load(local.read_text(encoding="utf-8")) or {}
        cfg = config_mod.load(cfg_path)
    except (OSError, ValueError, yaml.YAMLError) as e:
        return Check(name, FAIL, f"{local} failed to load: {e}", required=True)
    if not isinstance(over, dict):
        return Check(name, FAIL, f"{local} must be a YAML mapping", required=True)
    detail = ", ".join(config_mod._overlay_override_entries(
        config_mod._leaf_paths(over), cfg._data)) or "(empty)"
    return Check(name, OK, f"{local} applied (overrides: {detail})")


def overlay_check(cfg_path: str | Path) -> Check:
    """config.local.yaml status: absent, skipped, untrusted, or the applied overrides."""
    name = "config overlay"
    local = Path(cfg_path).with_name(LOCAL_OVERLAY_NAME)
    if not local.exists():
        check = Check(name, OK, f"{LOCAL_OVERLAY_NAME} not found (optional)")
    elif os.environ.get(NO_LOCAL_CONFIG_ENV):
        check = Check(name, OK,
                      f"{local} present but skipped ({NO_LOCAL_CONFIG_ENV} set)")
    elif (getattr(os, "geteuid", None) is not None
            and not config_mod._local_overlay_trusted(local)):
        check = Check(
            name, FAIL,
            f"{local} untrusted — must be owned by the invoking user (or "
            f"root) and not group/world-writable; `chmod go-w` / `chown` it, "
            f"or set {NO_LOCAL_CONFIG_ENV} to skip it",
            required=True)
    else:
        check = _applied_overlay_check(name, local, cfg_path)
    return check


def _via_gap_check(name: str, gap: str, roles: set[str], *,
                   hint: str = "") -> Check:
    """Grade a backend credential/tool gap the way preflight does."""
    # Mirrors preflight._report_credential_gap: detection FAILs, post-scan S10/S11 is advisory
    if not (roles <= POST_SCAN_ROLES):
        return Check(name, FAIL, f"{gap} (required by this profile){hint}",
                     required=True)
    return Check(name, WARN,
                 f"{gap} (required only by {', '.join(sorted(roles))} — "
                 "that stage will be skipped)")


def config_check(cfg_path: str | Path) -> list[Check]:
    """Confirm the active profile loads, and report its backends and whether each credential is present."""
    p = Path(cfg_path)
    if not p.exists():
        return [Check("config", FAIL, f"not found: {p}", required=True)]
    try:
        from vvaharness import config as config_mod
        cfg = config_mod.load(p)
    except Exception as e:  # noqa: BLE001
        return [Check("config", FAIL, f"failed to load {p}: {e}", required=True)]
    cwd_cfg = Path.cwd() / "config.yaml"
    if p.resolve() == cwd_cfg.resolve():
        detail = "config.yaml loads"
    elif not cwd_cfg.exists():
        detail = (f"{p.name} loads — create ./config.yaml for local defaults "
                  f"(config.yml is not auto-loaded)")
    else:
        detail = f"{p.name} loads"
    out = [Check("config", OK, detail)]
    # MUST use _iter_model_roles: a hand-rolled walk injected a phantom `cli` backend (no .via)
    nodes: dict[str, object] = dict(_iter_model_roles(cfg))
    roles_by_via: dict[str, set[str]] = {}
    for r, node in nodes.items():
        roles_by_via.setdefault((getattr(node, "via", None) or "cli"), set()).add(r)
    vias = set(roles_by_via)
    out.append(Check("active backends", OK, ", ".join(sorted(vias)) or "(none)"))
    invalid_deepagents = sorted(
        r for r, node in nodes.items()
        if (getattr(node, "via", None) or "cli") == "deepagents"
        and r not in DEEPAGENTS_ROLES
    )
    if invalid_deepagents:
        # Derived from the frozenset so this text cannot drift from the gate's membership.
        supported = ", ".join(f"models.{r}" for r in sorted(DEEPAGENTS_ROLES))
        out.append(Check(
            "via:deepagents roles",
            FAIL,
            f"supported only for {supported}; invalid "
            f"role(s): {', '.join(invalid_deepagents)}",
            required=True,
        ))
    # An unknown key is read by no consumer, so a typo silently changes nothing — never fatal.
    unknown_keys = [
        f"models.{r}.{key}"
        for r, node in nodes.items()
        for key in unrecognized_model_keys(node)
    ]
    if unknown_keys:
        out.append(Check(
            "model config keys",
            WARN,
            f"unrecognized model key(s) ignored: {', '.join(unknown_keys)}",
        ))
    if "sdk" in vias:
        out.append(_gateway_check())
        sdk_cfg = getattr(cfg, "sdk", None)
        has_sdk_key = (_is_set("ANTHROPIC_SDK_API_KEY")
                       or bool(getattr(sdk_cfg, "api_key", None)))
        # Same sdk_sole predicate as preflight.configure_backends(), where its rationale lives.
        sdk_sole = vias <= {"sdk", "deepagents"}
        fallback = sdk_sole and (_is_set("ANTHROPIC_API_KEY")
                                 or _is_set("ANTHROPIC_AUTH_TOKEN"))
        if has_sdk_key:
            pass  # SDK-specific key present — nothing to flag
        elif fallback:
            out.append(Check("via:sdk credential", OK,
                             "ANTHROPIC_SDK_API_KEY unset — using "
                             "ANTHROPIC_API_KEY/ANTHROPIC_AUTH_TOKEN fallback "
                             "(no via:cli role in this profile)"))
        else:
            hint = (" — or set ANTHROPIC_API_KEY (accepted as a fallback)"
                    if sdk_sole else "")
            out.append(_via_gap_check("via:sdk credential",
                                      "ANTHROPIC_SDK_API_KEY not set",
                                      roles_by_via["sdk"], hint=hint))
        # Three OPTIONAL knobs: unset is valid, never blocking; surfaced so levers are visible
        for env_name, attr, note in (
            ("ANTHROPIC_SDK_BASE_URL", "base_url",
             "gateway endpoint — defaults to public api.anthropic.com"),
            ("ANTHROPIC_SDK_CA_CERT", "ca_cert",
             "gateway CA bundle — only for a private-CA gateway"),
            ("ANTHROPIC_SDK_CLIENT_CERT", "client_cert",
             "client cert for mTLS — off when unset"),
        ):
            present = _is_set(env_name) or bool(getattr(sdk_cfg, attr, None))
            out.append(Check(f"via:sdk {env_name}", OK if present else WARN,
                             "set" if present else f"unset (optional: {note})"))
    if "openai" in vias and not _is_set("OPENAI_API_KEY"):
        out.append(_via_gap_check("via:openai credential",
                                  "OPENAI_API_KEY not set",
                                  roles_by_via["openai"]))
    if "cli" in vias and not shutil.which("claude"):
        out.append(_via_gap_check("via:cli backend",
                                  "`claude` CLI not on PATH",
                                  roles_by_via["cli"]))
    out += _deepagents_checks(nodes, cfg=cfg, gateway_done="sdk" in vias)
    # s10/s11 never block the core scan (a bad step is just disabled), so their checks are WARN
    out += _remediate_checks(cfg)
    out += _validate_checks(cfg)
    return out


def remediation_inputs_check() -> Check:
    """Ensure fail-closed remediation defaults are available."""
    from vvaharness.remediation_agent import rule_paths
    missing = rule_paths.missing_rules(rule_paths.__file__)
    configured = rule_paths.configured_inputs_dir()
    if not missing:
        detail = (f"using {configured}" if configured else
                  "bundled policy and playbook available")
        return Check("remediation inputs", OK, detail)
    return Check(
        "remediation inputs", FAIL,
        f"missing {', '.join(missing)}; run interactive `vvaharness setup` "
        "to select the inputs directory", required=True)


def _backend_credential_ok(
    via: str, model_id: str = "", provider: str | None = None,
    *, cfg: object | None = None,
) -> tuple[bool, str]:
    """(ready, detail) for a model role's backend; presence only, never the value."""
    # *cfg* lets deepagents accept a profile-bound sdk/openai api_key; cfg=None stays env-only
    if via == "cli":
        if shutil.which("claude"):
            return True, "`claude` CLI on PATH"
        return False, "`claude` CLI not on PATH"
    if via == "sdk":
        if (_is_set("ANTHROPIC_SDK_API_KEY") or _is_set("ANTHROPIC_API_KEY")
                or _is_set("ANTHROPIC_AUTH_TOKEN")):
            return True, "Anthropic SDK credential present"
        return False, ("ANTHROPIC_SDK_API_KEY not set "
                       "(or ANTHROPIC_API_KEY/ANTHROPIC_AUTH_TOKEN)")
    if via == "openai":
        if _is_set("OPENAI_API_KEY"):
            return True, "OPENAI_API_KEY set"
        return False, "OPENAI_API_KEY not set"
    if via == "deepagents":
        return _deepagents_credential_ok(model_id, provider, cfg)
    return True, f"via:{via}"


def _cfg_api_key_present(cfg: object | None, block: str) -> bool:
    """Whether the profile itself binds an ``api_key`` under *block*; presence only."""
    return bool(getattr(getattr(cfg, block, None), "api_key", None))


def _deepagents_credential_ok(
    model_id: str, provider: str | None, cfg: object | None
) -> tuple[bool, str]:
    """Deepagents credential presence for the resolved vendor route."""
    # A profile-bound api_key counts: credential_env_overrides exports it before the model is built.
    if not routes_to_anthropic(model_id, provider):
        if _cfg_api_key_present(cfg, "openai") or _is_set("OPENAI_API_KEY"):
            return True, "OpenAI-compatible DeepAgents credential present"
        return False, ("OPENAI_API_KEY not set "
                       "(set OPENAI_BASE_URL for a custom endpoint)")
    if (_cfg_api_key_present(cfg, "sdk") or _is_set("ANTHROPIC_API_KEY")
            or _is_set("ANTHROPIC_AUTH_TOKEN")):
        return True, "Anthropic-compatible DeepAgents credential present"
    return False, "ANTHROPIC_API_KEY or ANTHROPIC_AUTH_TOKEN not set"


def _deepagents_targets(
    nodes: dict[str, object],
) -> dict[tuple[str, str | None], set[str]]:
    """(model_id, provider) -> roles, for every active via:deepagents role."""
    # Credentials are per target, not per via: one profile may route roles to different vendors
    targets: dict[tuple[str, str | None], set[str]] = {}
    for role, node in nodes.items():
        if (getattr(node, "via", None) or "cli") != "deepagents":
            continue
        key = (str(getattr(node, "id", "") or ""), getattr(node, "provider", None))
        targets.setdefault(key, set()).add(role)
    return targets


def _deepagents_checks(nodes: dict[str, object], *, cfg: object | None,
                       gateway_done: bool) -> list[Check]:
    """Doctor's static credential pass for ``via: deepagents`` roles."""
    # A gap touching any detection role blocks; one confined to post-scan roles is advisory.
    out: list[Check] = []
    anthropic_route = False
    targets = _deepagents_targets(nodes)
    # Total order needed: provider is None for name-inferred targets, so bare tuple sort raises
    for (model_id, provider), roles in sorted(
            targets.items(), key=lambda kv: (kv[0][0], kv[0][1] or "")):
        anthropic_route = anthropic_route or routes_to_anthropic(model_id, provider)
        ready, detail = _backend_credential_ok("deepagents", model_id, provider,
                                               cfg=cfg)
        blocking = not (roles <= POST_SCAN_ROLES)
        status = OK if ready else (FAIL if blocking else WARN)
        out.append(Check(
            f"via:deepagents {model_id}", status,
            detail + ("" if ready else f" (role(s): {', '.join(sorted(roles))})"),
            required=blocking and not ready,
        ))
    if anthropic_route and not gateway_done:
        # Same trap as via:sdk: a JWT-shaped ANTHROPIC_API_KEY with no BASE_URL 401s publicly
        gw = _gateway_check()
        out.append(Check("via:deepagents endpoint", gw.status, gw.detail,
                         required=gw.required))
    return out


def _remediate_checks(cfg) -> list[Check]:
    """Step-10 readiness; empty unless ``step_remediate.enabled``."""
    # Mirrors orchestrator.scan._remediate_preflight.
    if not getattr(getattr(cfg, "step_remediate", None), "enabled", False):
        return []
    rem = getattr(getattr(cfg, "models", None), "remediate", None)
    if rem is None:
        return [Check("step10: remediate", WARN,
                      "step_remediate.enabled but models.remediate is unset "
                      "— remediation will be skipped")]
    via = getattr(rem, "via", "cli")
    ready, detail = _backend_credential_ok(via, getattr(rem, "id", ""),
                                           getattr(rem, "provider", None), cfg=cfg)
    return [Check("step10: remediate", OK if ready else WARN,
                  f"via:{via} — {detail}"
                  + ("" if ready else " — remediation will be skipped"))]


def _validate_checks(cfg) -> list[Check]:
    """Step-11 readiness; empty unless ``step_validate.enabled``."""
    # Mirrors the s11 preflight: legacy via:openai routes to DeepAgents, so the credential matches
    if not getattr(getattr(cfg, "step_validate", None), "enabled", False):
        return []
    out: list[Check] = []
    val = validate_model_spec(cfg)
    if val is None:
        out.append(Check("step11: validate", WARN,
                         "step_validate.enabled but models.validate.orchestrator is unset "
                         "— validation will be skipped"))
    else:
        raw_via = getattr(val, "via", "cli")
        via, provider = normalize_validate_backend(raw_via, getattr(val, "provider", None))
        ready, detail = _backend_credential_ok(via, getattr(val, "id", ""),
                                               provider, cfg=cfg)
        routed = f" (via:{raw_via} routed to {via})" if via != raw_via else ""
        out.append(Check("step11: validate", OK if ready else WARN,
                         f"via:{via} — {detail}{routed}"
                         + ("" if ready else " — validation will be skipped")))
    if importlib.util.find_spec("claude_agent_sdk") is not None:
        out.append(Check("step11: claude_agent_sdk", OK,
                         "claude_agent_sdk importable"))
    else:
        out.append(Check("step11: claude_agent_sdk", WARN,
                         "claude_agent_sdk missing — reinstall vvaharness (pip install .)"))
    return out


def tls_check() -> Check:
    """Handshake the active Anthropic endpoint to decide whether a private CA bundle is needed."""
    # No tokens, just a handshake; network/DNS/timeout stays WARN, the live probe decides
    base = os.environ.get("ANTHROPIC_BASE_URL") or "https://api.anthropic.com"
    u = urlparse(base if "://" in base else f"https://{base}")
    host, port = u.hostname or "api.anthropic.com", u.port or 443
    cafile = os.environ.get("NODE_EXTRA_CA_CERTS")
    use_bundle = bool(cafile and Path(cafile).is_file())
    try:
        ctx = ssl.create_default_context(cafile=cafile if use_bundle else None)
        with socket.create_connection((host, port), timeout=8) as sock:
            with ctx.wrap_socket(sock, server_hostname=host):
                pass
        # NODE_EXTRA_CA_CERTS is the Node trust (via:cli); client_tls_check() probes the other routes
        src = (" via NODE_EXTRA_CA_CERTS (the trust via:cli reads) — note: via:sdk and "
               "deepagents-Anthropic do not read that variable; they use the OS trust "
               "store, or SSL_CERT_FILE / sdk.ca_cert when set"
               if use_bundle else " (system trust store)")
        return Check("TLS / CA cert", OK,
                     f"{host}:{port} verified{src} — no extra CA bundle needed"
                     if not use_bundle else f"{host}:{port} verified{src}")
    except ssl.SSLCertVerificationError:
        # SSL_CERT_FILE covers via:sdk and via:deepagents; only via:cli reads NODE_EXTRA_CA_CERTS
        ca = detect_ca_cert()
        hint = ((f" A bundle was detected — run: export SSL_CERT_FILE={ca} "
                 f"(covers via:sdk and via:deepagents; via:cli reads "
                 f"NODE_EXTRA_CA_CERTS={ca} instead).")
                if ca else
                " Point SSL_CERT_FILE at your org's CA bundle (covers "
                "via:sdk and via:deepagents; via:cli reads "
                "NODE_EXTRA_CA_CERTS instead).")
        return Check("TLS / CA cert", WARN,
                     f"{host} presents a certificate the system trust store does "
                     f"not accept — this machine reaches it through a private CA "
                     f"(a TLS-intercepting proxy or a private endpoint), so you "
                     f"need your org's CA bundle.{hint}")
    except Exception as e:  # noqa: BLE001 — DNS/timeout/proxy: can't decide here
        return Check("TLS / CA cert", WARN,
                     f"could not verify {host}:{port} ({type(e).__name__}) — "
                     f"skipping CA determination; the live probe will confirm")


def _handshake(ctx: ssl.SSLContext, host: str, port: int) -> None:
    with socket.create_connection((host, port), timeout=8) as sock:
        with ctx.wrap_socket(sock, server_hostname=host):
            pass


def _client_trust(sdk_cfg: object | None, cfg_path: str | Path) -> tuple[ssl.SSLContext, str]:
    """The SSL context via:sdk / deepagents-Anthropic build for a plain endpoint, and its source."""
    # Mirrors sdk.py: sdk.ca_cert wins; else httpx2 reads SSL_CERT_FILE/DIR, else the OS store
    ca = getattr(sdk_cfg, "ca_cert", None)
    if ca:
        from vvaharness.orchestrator.config_paths import _resolve_against
        path = _resolve_against(Path(cfg_path).resolve().parent, str(ca))
        if Path(path).is_file():
            return ssl.create_default_context(cafile=path), "sdk.ca_cert"
    try:
        import httpx2
        ctx = httpx2.create_ssl_context(verify=True, trust_env=True)
    except ImportError:
        ctx = ssl.create_default_context(cafile=os.environ.get("SSL_CERT_FILE") or None)
    if os.environ.get("SSL_CERT_FILE"):
        return ctx, "SSL_CERT_FILE"
    if os.environ.get("SSL_CERT_DIR"):
        return ctx, "SSL_CERT_DIR"
    return ctx, "the OS trust store"


def client_tls_check(cfg_path: str | Path) -> Check | None:
    """Handshake with the trust the profile's via:sdk / deepagents-Anthropic clients actually use."""
    # None when nothing here can decide: no such role, an unreadable config, or a network error
    try:
        cfg = config_mod.load(Path(cfg_path))
        nodes = dict(_iter_model_roles(cfg))
    except Exception:  # noqa: BLE001 -- config_check reports it
        return None
    roles = {role for role, node in nodes.items()
             if (getattr(node, "via", None) or "cli") == "sdk"
             or ((getattr(node, "via", None) or "cli") == "deepagents"
                 and routes_to_anthropic(str(getattr(node, "id", "") or ""),
                                         getattr(node, "provider", None)))}
    if not roles:
        return None
    sdk_cfg = getattr(cfg, "sdk", None)
    base = (getattr(sdk_cfg, "base_url", None) or os.environ.get("ANTHROPIC_BASE_URL")
            or "https://api.anthropic.com")
    u = urlparse(str(base) if "://" in str(base) else f"https://{base}")
    host, port = u.hostname or "api.anthropic.com", u.port or 443
    try:
        ctx, source = _client_trust(sdk_cfg, cfg_path)
        _handshake(ctx, host, port)
        return Check("TLS / client trust", OK,
                     f"{host}:{port} verified with the trust via:sdk and "
                     f"deepagents-Anthropic use ({source})")
    except ssl.SSLCertVerificationError:
        pass
    except Exception:  # noqa: BLE001 -- DNS/timeout/proxy: tls_check already reports it
        return None
    # Blocks only when a detection role needs it, like the credential checks
    blocking = not (roles <= POST_SCAN_ROLES)
    node_ca = os.environ.get("NODE_EXTRA_CA_CERTS")
    try:
        if not (node_ca and Path(node_ca).is_file()):
            raise ssl.SSLError("no NODE_EXTRA_CA_CERTS bundle")
        _handshake(ssl.create_default_context(cafile=node_ca), host, port)
    except Exception:  # noqa: BLE001 -- the bundle does not explain it either
        return Check("TLS / client trust", WARN,
                     f"{host}:{port} is rejected by the trust via:sdk and deepagents-Anthropic "
                     f"use ({source}); set SSL_CERT_FILE (or sdk.ca_cert) to your org's CA "
                     f"bundle — scan preflight will fail with a certificate-verification "
                     f"error until then")
    return Check(
        "TLS / client trust", FAIL if blocking else WARN,
        f"{host}:{port} is rejected by the trust via:sdk and deepagents-Anthropic use "
        f"({source}) but accepted with NODE_EXTRA_CA_CERTS, which only via:cli reads — scan "
        f"preflight will fail with a certificate-verification error. Fix: export "
        f"SSL_CERT_FILE={node_ca} (or set sdk.ca_cert / ANTHROPIC_SDK_CA_CERT). "
        f"SSL_CERT_FILE replaces the default trust, so the bundle must hold every root you need.",
        required=blocking)


def run_checks(cfg_path: str | Path) -> list[Check]:
    """The full readiness report, in display order."""
    checks: list[Check] = [python_check(),
                           tool_check("git", "batch --repo-file cloning"),
                           tool_check("pip3", "installing optional extras")]
    checks += agent_checks()
    checks += credential_checks()
    # Advisory egress guard: fires when langchain-core could upload scanned source to LangSmith
    checks.append(langsmith_tracing_check())
    checks += dep_checks()
    checks.append(anthropic_version_check())
    checks.append(tls_check())
    client_tls = client_tls_check(cfg_path)
    if client_tls is not None:
        checks.append(client_tls)
    checks.append(remediation_inputs_check())
    cfg_checks = config_check(cfg_path)
    if cfg_checks:
        checks.append(cfg_checks[0])
        checks.append(dotenv_check())
        checks.append(overlay_check(cfg_path))
        checks += cfg_checks[1:]
    return checks


def summarize(checks: list[Check]) -> tuple[int, int, int]:
    """(#ok, #warn, #fail-required) — required fails are what block a scan."""
    n_ok = sum(1 for c in checks if c.status == OK)
    n_warn = sum(1 for c in checks if c.status == WARN)
    n_blocking = sum(1 for c in checks if c.status == FAIL and c.required)
    return n_ok, n_warn, n_blocking
