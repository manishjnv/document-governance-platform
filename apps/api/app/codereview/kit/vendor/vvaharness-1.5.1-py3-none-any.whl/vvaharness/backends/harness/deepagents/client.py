# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""DeepAgents implementation of the validation Harness contract."""

from __future__ import annotations

import asyncio
import dataclasses
from collections.abc import AsyncIterator
from typing import NamedTuple, cast
from uuid import uuid4

from langchain_core.messages import HumanMessage
from langchain_core.runnables import RunnableConfig

# Import the real class, never its name: a rename must break force-finalize loudly, not silently
from langgraph.errors import GraphRecursionError
from langgraph.graph.state import CompiledStateGraph

from vvaharness.backends.harness.deepagents.models import DeepAgentsGraphState
from vvaharness.backends.harness.deepagents.options import (
    build_oneshot_options,
    build_streaming_agent,
    resumable,
)
from vvaharness.backends.harness.deepagents.options.model_building import (
    _CHAT_COMPLETIONS_ONLY_MODELS,
    _FORCED_TOOL_CHOICE_UNSUPPORTED_MODELS,
    _openai_effort_kwargs,
    resolve_use_responses_api,
)
from vvaharness.backends.harness.deepagents.tool_choice_rejection import (
    is_tool_choice_unsupported_rejection,
    learn_tool_choice_unsupported,
    rejected_model,
)
from vvaharness.backends.harness.deepagents.translate import (
    make_terminal_result,
    translate_final_state,
    translate_stream_events,
)
from vvaharness.backends.harness.deepagents.usage import UsageAccumulator
from vvaharness.backends.harness.harness import Harness
from vvaharness.backends.harness.models import (
    HarnessError,
    HarnessMessage,
    HarnessProcessError,
    HarnessSessionInit,
    OneShotOptions,
    OneShotResult,
    SessionNotResumableError,
    SessionOptions,
    StreamingOptions,
)
from vvaharness.backends.harness.provider_routing import (
    TRANSPORT_CHAT_COMPLETIONS,
    TRANSPORT_RESPONSES,
    routes_to_anthropic,
)
from vvaharness.backends.llm.models import (
    EFFORT_REJECTIONS,
    REASONING_OFF,
    SERVER_ERROR_STATUS,
    TRANSPORT_MEMORY,
    _tiers_key,
    call_timeout_error,
    classify_effort_rejection,
    is_model_refusal_rejection,
    is_responses_shape_rejection,
    next_effort_tier,
    step_down,
)
from vvaharness.util.counters import COUNTERS
from vvaharness.util.exceptions import exception_chain
from vvaharness.util.response_quality import is_connection_failure
from vvaharness.util.tokens import TOKENS
from vvaharness.util.warn_once import warn_once

#: 5m-TTL marker shape, matching every other marker this codebase places.
_EPHEMERAL_CACHE_CONTROL: dict[str, str] = {"type": "ephemeral"}

_HTTP_BAD_REQUEST = 400

#: Models that completed at least one call on the Responses API this process. Alias of
#: TRANSPORT_MEMORY.responses_proven (same set object, shared with the openai route); the name
#: stays so every existing `.add`/`in` reference keeps working.
_RESPONSES_PROVEN_MODELS: set[str] = TRANSPORT_MEMORY.responses_proven

_EFFORT_UNSUPPORTED_WARNED: set[str] = set()
_TRANSPORT_FALLBACK_WARNED: set[str] = set()

#: Counter surfaced in the manifest's unfiltered counters dump.
_RESPONSES_FALLBACK_COUNTER = "deepagents_responses_fallback"

#: Gemini 400 marker for a replay missing thought_signature; classified in llm.deepagents, not here
_THOUGHT_SIGNATURE_MARKER = "thought_signature"


def _is_reasoning_effort_rejection(exc: Exception) -> bool:
    """Whether *exc* is the gateway rejecting the effort field or tier."""
    return classify_effort_rejection(exc) is not None


async def _bounded_astream_events(
    stream: AsyncIterator[object], timeout: float | None, graph_name: str, effort: str | None,
) -> AsyncIterator[object]:
    """Yield *stream*'s events, bounded by *timeout* seconds; raise CallTimeoutError on expiry.

    ``timeout`` falsy (None or <=0) is unbounded -- the original, unchanged code path. When
    bounded, a fresh ``timeout_at`` cm per anext() shares one deadline instant but bounds only
    the await (never a yield to the caller), and DeepAgents has no subprocess, so cancelling it
    from outside is safe -- raise straight away, no interrupt/grace drain (contrast ClaudeHarness).
    """
    if not timeout:
        async for event in stream:
            yield event
        return
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout
    iterator = stream.__aiter__()
    while True:
        cm = asyncio.timeout_at(deadline)
        try:
            async with cm:
                event = await anext(iterator)
        except StopAsyncIteration:
            return
        except TimeoutError:
            # .expired() tells OUR deadline apart from a TimeoutError raised inside the session.
            if not cm.expired():
                raise
            raise call_timeout_error(
                stage=graph_name, route="deepagents", budget_s=timeout, effort=effort,
                cause_text=f"deepagents session exceeded {timeout:g}s",
            ) from None
        yield event


def _sent_effort_tier(options: SessionOptions) -> str | None:
    """The reasoning_effort value this call actually sends, or None.

    None on the route routes_to_anthropic() selects: that leg sends its own effort field
    through _anthropic_thinking_kwargs, which never reads EFFORT_REJECTIONS.
    """
    if routes_to_anthropic(options.model, options.model_provider):
        return None
    resolved_transport = resolve_use_responses_api(
        options.model, options.model_provider, options.use_responses_api)
    kw = _openai_effort_kwargs(
        options.model, options.effort, think_in_prompt=options.think_in_prompt,
        resolved_transport=bool(resolved_transport))
    return kw.get("reasoning_effort")


def _tools_off_exhausted(model_id: str, sent_tier: str, cls: str) -> bool:
    """True once a model already forced to reasoning_effort='none' is rejected again.

    Mirrors the openai route's fail-fast: once 'none' itself is rejected, or tools are
    rejected again after the forced 'none', no further resend can help.
    """
    return model_id in EFFORT_REJECTIONS.tools_off and (
        cls == "tools_conflict" or sent_tier == REASONING_OFF)


def _step_down_reasoning_effort(
    model_id: str, sent_tier: str, cls: str, exc: BaseException, *, transport: str,
) -> None:
    """Remember *model_id*'s rejection by *cls* and warn once, naming the value sent next.

    The tier arm uses the shared `step_down`, keyed per *transport*: a value rejected on the
    Responses leg must not retire it on Chat.
    """
    if cls == "field":
        EFFORT_REJECTIONS.field.add(model_id)
        COUNTERS.bump("llm_effort_field_dropped")
        next_value = "no field"
    elif cls == "tools_conflict":
        EFFORT_REJECTIONS.tools_off.add(model_id)
        COUNTERS.bump("llm_effort_tools_off")
        next_value = f"{REASONING_OFF!r}"
    else:
        stepped = step_down(model_id, sent_tier, exc, transport)
        COUNTERS.bump("llm_effort_tier_stepped_down")
        next_value = f"{stepped!r}" if stepped is not None else "no field"
    warn_once(
        _EFFORT_UNSUPPORTED_WARNED,
        f"{model_id}:{sent_tier}",
        f"WARN [deepagents]: model '{model_id}' rejected reasoning_effort={sent_tier!r} "
        f"— retrying at {next_value}",
    )


def _is_persistent_server_error(exc: BaseException) -> bool:
    """Whether *exc* carries a persistent 5xx HTTP status (the client's own retries exhausted).

    429 is a rate limit, not a server fault; a lower reasoning tier cannot clear it, so the
    probe is scoped to SERVER_ERROR_STATUS, not the wider RETRYABLE_STATUS.
    """
    return any(getattr(link, "status_code", None) in SERVER_ERROR_STATUS
               for link in exception_chain(exc))


def _effort_transport(options: SessionOptions) -> str:
    """The active transport for *options*: TRANSPORT_RESPONSES or TRANSPORT_CHAT_COMPLETIONS.

    Deliberately NOT `_responses_active`: that predicate reads False for a PINNED Responses
    call, which would mislabel a tier this call actually sent on Responses as a Chat rejection.
    """
    resolved = resolve_use_responses_api(
        options.model, options.model_provider, options.use_responses_api)
    return TRANSPORT_RESPONSES if resolved else TRANSPORT_CHAT_COMPLETIONS


def _probe_lower_tier_once(model_id: str, sent_tier: str) -> str | None:
    """Mark ``(model_id, sent_tier)`` probed and return the next rung, or None if ineligible."""
    # REASONING_OFF has no lower reasoning rung; next_effort_tier's "none" -> "low" entry
    # exists only for the 400 ladder, where turning reasoning back on is the point.
    if sent_tier == REASONING_OFF:
        return None
    nxt = next_effort_tier(sent_tier)
    if nxt is None or not EFFORT_REJECTIONS.probe_once((model_id, sent_tier)):
        return None
    return nxt


def _responses_active(options: SessionOptions) -> bool:
    """Whether this call resolved to the Responses API by DEFAULT, not by config pin."""
    resolved = resolve_use_responses_api(
        options.model, options.model_provider, options.use_responses_api
    )
    return resolved is True and options.use_responses_api is None


def _record_server_error_recovery(
    options: SessionOptions, sent_tier: str, probed: str, probed_options: SessionOptions,
) -> None:
    """Bookkeeping after a lower-tier resend recovered a persistent server error."""
    if learned := EFFORT_REJECTIONS.recovered_twice((options.model, sent_tier)):
        EFFORT_REJECTIONS.tiers.add(
            _tiers_key(options.model, sent_tier, _effort_transport(options)))
    COUNTERS.bump("llm_effort_tier_stepped_down_on_server_error")
    warn_once(
        _EFFORT_UNSUPPORTED_WARNED, f"server_error:{options.model}:{sent_tier}:{learned}",
        f"WARN [deepagents]: model '{options.model}' returned a server error "
        f"at reasoning_effort={sent_tier!r}; resent at {probed!r} "
        f"{'for the rest of this run' if learned else 'for this session'}.")
    if _responses_active(probed_options):
        _RESPONSES_PROVEN_MODELS.add(options.model)


async def _probe_server_error_oneshot(
    options: OneShotOptions, content: str | list[str | dict[str, object]],
    sent_tier: str, exc: Exception,
) -> OneShotResult | None:
    """One direct resend at the next tier after a persistent server error, or None if ineligible.

    A direct resend, not a recursive ``run_oneshot``: the retry decision must not re-enter and
    probe a second rung if this one also fails.
    """
    probed = _probe_lower_tier_once(options.model, sent_tier)
    if probed is None:
        return None
    probed_options = dataclasses.replace(options, effort=probed)
    probed_graph, probed_config = build_oneshot_options(probed_options)
    try:
        probed_state = await probed_graph.ainvoke(
            {"messages": [HumanMessage(content=content)]},
            config=cast(RunnableConfig, probed_config),
        )
    except Exception:
        # An outage, not a tier problem: raise the first error, record nothing.
        raise exc from None
    _record_server_error_recovery(options, sent_tier, probed, probed_options)
    return translate_final_state(cast("DeepAgentsGraphState", probed_state), oneshot=True)


async def _recover_oneshot_exception(
    harness: DeepAgentHarness, prompt: str, options: OneShotOptions,
    sent_tier: str | None, exc: Exception,
) -> OneShotResult:
    """Handle a run_oneshot failure that is not an effort rejection.

    Tries the forced-tool_choice fallback, then the server-error probe, then the
    Responses-shape fallback to Chat Completions.
    """
    if unforced := _rejecting_models(exc, options):
        # Bounded: learning flips _strategy_for's choice, so the re-entry cannot come back here
        learn_tool_choice_unsupported(*unforced)
        return await harness.run_oneshot(prompt, options)
    if sent_tier is not None and _is_persistent_server_error(exc):
        content = _marked_content(prompt, options.cache_prefix)
        probed_result = await _probe_server_error_oneshot(options, content, sent_tier, exc)
        if probed_result is not None:
            return probed_result
    if not _should_fall_back(exc, options):
        raise exc
    # Bounded: learning flips the transport, so the re-entry cannot take this branch
    _learn_chat_completions_only(options.model)
    try:
        return await harness.run_oneshot(prompt, options)
    except Exception as second_exc:
        # Unlearn (an outage must not mislabel); raise the ORIGINAL unless the 2nd is richer
        _CHAT_COMPLETIONS_ONLY_MODELS.discard(options.model)
        if _is_missing_thought_signature(second_exc):
            raise second_exc from exc
        raise exc from None


class _StreamProbeContext(NamedTuple):
    """State the streaming probe resend needs beyond *options* and the next tier to send."""

    sent_tier: str
    error: Exception
    session_id: str
    seen_tool_ids: set[str]
    ns_to_agent: dict[tuple[str, ...], str]


async def _probe_server_error_streaming(
    prompt: str, options: StreamingOptions, probed: str, ctx: _StreamProbeContext,
) -> AsyncIterator[HarnessMessage]:
    """One direct resend at the next tier after a persistent server error.

    A direct resend, not a recursive ``run_streaming``: the retry decision must not re-enter
    and probe a second rung if this one also fails. *probed* is the next tier to send.
    """
    probed_options = dataclasses.replace(options, effort=probed)
    probed_graph, probed_config = build_streaming_agent(probed_options)
    probed_runnable_config = cast(RunnableConfig, probed_config)
    probed_usage_acc = UsageAccumulator()
    try:
        async for event in probed_graph.astream(
            {"messages": [HumanMessage(
                content=_marked_content(prompt, probed_options.cache_prefix))]},
            config=probed_runnable_config,
            stream_mode="updates",
            subgraphs=True,
        ):
            probed_usage_acc.add_event(event)
            async for message in translate_stream_events(
                event, ctx.seen_tool_ids, ctx.ns_to_agent
            ):
                yield message
        probed_state = await _final_state(probed_graph, probed_runnable_config)
    except Exception:
        # An outage, not a tier problem: raise the first error, record nothing.
        raise ctx.error from None
    _record_server_error_recovery(options, ctx.sent_tier, probed, probed_options)
    yield make_terminal_result(
        probed_state, session_id=ctx.session_id, stream_usage=probed_usage_acc.snapshot())


def _is_missing_thought_signature(exc: Exception) -> bool:
    """Whether *exc* is a provider 400 rejecting a tool-call replay for missing state."""
    # Cause-only chain (no __context__ false match); .stderr holds the body; SHAPE, never model_id
    for link in exception_chain(exc):
        status = getattr(link, "status_code", None)
        body = str(getattr(link, "message", link)).lower()
        if status == _HTTP_BAD_REQUEST and _THOUGHT_SIGNATURE_MARKER in body:
            return True
    stderr = str(getattr(exc, "stderr", "") or "")
    return "400" in stderr and _THOUGHT_SIGNATURE_MARKER in stderr.lower()


def _forcing_candidates(options: SessionOptions) -> tuple[str, ...]:
    """The parent's and every subagent's model that is still sent a forced tool_choice."""
    agents = getattr(options, "agents", None) or {}
    ids = [options.model, *(getattr(a, "model", None) or options.model for a in agents.values())]
    return tuple(dict.fromkeys(
        m for m in ids
        if m and m not in _FORCED_TOOL_CHOICE_UNSUPPORTED_MODELS
        and routes_to_anthropic(m, options.model_provider)))


def _rejecting_models(exc: Exception, options: SessionOptions) -> tuple[str, ...]:
    """The models to learn from a forced-tool_choice 400 in *exc*; () when it is not one."""
    if not (candidates := _forcing_candidates(options)):
        return ()
    if not is_tool_choice_unsupported_rejection(exc):
        return ()
    # The request names the rejecting model; only when it is lost is every candidate learned
    model = rejected_model(exc)
    return (model,) if model in candidates else candidates


def _relearned_for_rerun(error: Exception, options: StreamingOptions, sent_tier: str | None,
                         usage_acc: UsageAccumulator) -> bool:
    """Learn a tool_choice or effort rejection from a streaming *error*; True to re-run once."""
    if unforced := _rejecting_models(error, options):
        learn_tool_choice_unsupported(*unforced)
        return True
    if sent_tier is None or (effort_cls := classify_effort_rejection(error)) is None:
        return False
    if _tools_off_exhausted(options.model, sent_tier, effort_cls):
        EFFORT_REJECTIONS.tiers.add(
            _tiers_key(options.model, REASONING_OFF, _effort_transport(options)))
        _bank_partial_usage(usage_acc)
        raise HarnessProcessError(
            f"DeepAgents stream failed: model {options.model!r} rejects "
            f"reasoning_effort alongside tools at every value, including "
            f"'none'.",
            exit_code=1,
            stderr=str(error),
        ) from error
    _step_down_reasoning_effort(
        options.model, sent_tier, effort_cls, error, transport=_effort_transport(options))
    return True


def _should_fall_back(exc: Exception, options: SessionOptions) -> bool:
    """Whether a failed call warrants one retry on Chat Completions."""
    # Unproven models fall back on any error, proven ones only on shape, so a 5xx cannot flip
    # them. A refusal never falls back: that would re-send the flagged content to the gateway.
    if (is_model_refusal_rejection(exc) or is_connection_failure(exc)
            or not _responses_active(options)):
        return False
    if options.model not in _RESPONSES_PROVEN_MODELS:
        return True
    return is_responses_shape_rejection(exc)


def _learn_chat_completions_only(model_id: str) -> None:
    """Record *model_id* as Chat-Completions-only, count it, and warn once."""
    _CHAT_COMPLETIONS_ONLY_MODELS.add(model_id)
    COUNTERS.bump(_RESPONSES_FALLBACK_COUNTER)
    warn_once(
        _TRANSPORT_FALLBACK_WARNED,
        model_id,
        f"WARN [deepagents]: model '{model_id}' failed its first Responses API "
        f"call — retrying on Chat Completions",
    )


def _bank_partial_usage(usage_acc: UsageAccumulator) -> None:
    """Record a failed attempt's streamed usage before the retry re-delegates."""
    # Retries never reach make_terminal_result; no double-count, the retry is a FRESH session
    snapshot = usage_acc.snapshot()
    if snapshot is not None:
        TOKENS.add(snapshot, turns=snapshot.get("turns"))


def _marked_content(
    prompt: str, cache_prefix: str | None
) -> str | list[str | dict[str, object]]:
    """User-turn content; a vetted cache_prefix becomes a cache_control-marked leading block."""
    if not cache_prefix:
        return prompt
    # 4th of Anthropic's 4 breakpoints (middleware spends system, tools, tail); never add a 5th.
    blocks: list[str | dict[str, object]] = [
        {"type": "text", "text": cache_prefix,
         "cache_control": dict(_EPHEMERAL_CACHE_CONTROL)},
        {"type": "text", "text": prompt},
    ]
    return blocks


async def _final_state(
    graph: CompiledStateGraph, config: RunnableConfig
) -> DeepAgentsGraphState:
    """Return the graph's terminal state values, or {} if it has no initialised state."""
    try:
        snapshot = await graph.aget_state(config)
    except ValueError:
        return {}
    return cast("DeepAgentsGraphState", getattr(snapshot, "values", None) or {})


class DeepAgentHarness(Harness):
    """Validation harness backed by the DeepAgents / LangGraph runtime."""

    async def run_oneshot(
        self, prompt: str, options: OneShotOptions
    ) -> OneShotResult:
        """Run a single-turn parser-only invocation and return the result."""
        # The field actually sent: bounds the effort retry to one re-entry per rejection.
        sent_tier = _sent_effort_tier(options)
        graph, config = build_oneshot_options(options)
        content = _marked_content(prompt, options.cache_prefix)
        responses_active = _responses_active(options)
        try:
            state = await graph.ainvoke(
                {"messages": [HumanMessage(content=content)]},
                config=cast(RunnableConfig, config),
            )
        except Exception as exc:
            if (sent_tier is not None
                    and (effort_cls := classify_effort_rejection(exc)) is not None):
                if _tools_off_exhausted(options.model, sent_tier, effort_cls):
                    EFFORT_REJECTIONS.tiers.add(
                        _tiers_key(options.model, REASONING_OFF, _effort_transport(options)))
                    raise RuntimeError(
                        f"DeepAgents call failed: model {options.model!r} rejects "
                        f"reasoning_effort alongside tools at every value, including "
                        f"'none'."
                    ) from exc
                _step_down_reasoning_effort(
                    options.model, sent_tier, effort_cls, exc,
                    transport=_effort_transport(options))
                return await self.run_oneshot(prompt, options)
            return await _recover_oneshot_exception(self, prompt, options, sent_tier, exc)
        if responses_active:
            _RESPONSES_PROVEN_MODELS.add(options.model)
        return translate_final_state(cast("DeepAgentsGraphState", state), oneshot=True)

    def resume_streaming(
        self, instruction: str, options: StreamingOptions
    ) -> AsyncIterator[HarnessMessage]:
        """Continue options.session_id's existing conversation with one more user turn."""
        # NOT a re-ask: LangGraph loads the checkpointed messages for this thread_id and appends,
        # so every prior turn is already in context and still prompt-cached. The caller withdraws
        # the tools by passing permitted_tool_calls, so the only move left is the outcome report.
        held = resumable(options.session_id)
        if held is None:
            raise SessionNotResumableError(
                f"session {options.session_id!r} is no longer resumable: its compiled graph, "
                f"and with it the checkpointed conversation, has been released")
        graph, config = held
        runnable_config = cast(RunnableConfig, config)

        async def _gen() -> AsyncIterator[HarnessMessage]:
            seen_tool_ids: set[str] = set()
            ns_to_agent: dict[tuple[str, ...], str] = {}
            usage_acc = UsageAccumulator()
            async for event in graph.astream(
                {"messages": [HumanMessage(content=instruction)]},
                config=runnable_config,
                stream_mode="updates",
                subgraphs=True,
            ):
                usage_acc.add_event(event)
                async for message in translate_stream_events(event, seen_tool_ids, ns_to_agent):
                    yield message
            state = await _final_state(graph, runnable_config)
            yield make_terminal_result(
                state, session_id=options.session_id, stream_usage=usage_acc.snapshot()
            )

        return _gen()

    def run_streaming(
        self, prompt: str, options: StreamingOptions
    ) -> AsyncIterator[HarnessMessage]:
        """Return an async iterator of typed messages for a streaming session."""
        sent_tier = _sent_effort_tier(options)
        graph, config = build_streaming_agent(options)
        runnable_config = cast(RunnableConfig, config)

        async def _gen() -> AsyncIterator[HarnessMessage]:
            # The caller's id when pinned: the id a stage reports must BE the resumable thread
            session_id = options.session_id or uuid4().hex
            seen_tool_ids: set[str] = set()
            # Subgraph namespace -> persona name, so subagent steps are tagged.
            ns_to_agent: dict[tuple[str, ...], str] = {}
            # Usage lives on streamed AIMessages, not graph state; subagent turns show only here
            usage_acc = UsageAccumulator()
            responses_active = _responses_active(options)
            try:
                yield HarnessSessionInit(session_id=session_id)
                # subgraphs=True surfaces each persona's steps as (namespace, payload) tuples.
                stream = graph.astream(
                    {"messages": [HumanMessage(
                        content=_marked_content(prompt, options.cache_prefix))]},
                    config=runnable_config,
                    stream_mode="updates",
                    subgraphs=True,
                )
                bounded_stream = _bounded_astream_events(
                    stream, options.timeout, options.graph_name, options.effort
                )
                async for event in bounded_stream:
                    usage_acc.add_event(event)
                    async for message in translate_stream_events(
                        event, seen_tool_ids, ns_to_agent
                    ):
                        yield message
                if responses_active:
                    _RESPONSES_PROVEN_MODELS.add(options.model)
                state = await _final_state(graph, runnable_config)
                yield make_terminal_result(
                    state, session_id=session_id, stream_usage=usage_acc.snapshot()
                )
            except HarnessError:
                raise
            except Exception as error:
                if _relearned_for_rerun(error, options, sent_tier, usage_acc):
                    _bank_partial_usage(usage_acc)
                    async for message in self.run_streaming(prompt, options):
                        yield message
                    return
                probed = (_probe_lower_tier_once(options.model, sent_tier)
                          if sent_tier is not None and _is_persistent_server_error(error)
                          else None)
                if probed is not None and sent_tier is not None:
                    _bank_partial_usage(usage_acc)
                    ctx = _StreamProbeContext(
                        sent_tier, error, session_id, seen_tool_ids, ns_to_agent)
                    async for message in _probe_server_error_streaming(
                        prompt, options, probed, ctx
                    ):
                        yield message
                    return
                if _should_fall_back(error, options):
                    # Bounded: learning flips the transport, so the re-delegation cannot re-enter
                    _learn_chat_completions_only(options.model)
                    _bank_partial_usage(usage_acc)
                    try:
                        async for message in self.run_streaming(prompt, options):
                            yield message
                    except Exception as second_error:
                        # Unlearn; raise the ORIGINAL unless the 2nd holds the thought_signature
                        _CHAT_COMPLETIONS_ONLY_MODELS.discard(options.model)
                        if _is_missing_thought_signature(second_error):
                            # A HarnessProcessError's body is in .stderr, not str()
                            detail = getattr(second_error, "stderr", None) or str(
                                second_error
                            )
                            raise HarnessProcessError(
                                f"DeepAgents stream failed: {type(second_error).__name__}",
                                exit_code=1,
                                stderr=detail,
                                recursion_limited=isinstance(
                                    second_error, GraphRecursionError
                                ),
                            ) from second_error
                        raise HarnessProcessError(
                            f"DeepAgents stream failed: {type(error).__name__}",
                            exit_code=1,
                            stderr=str(error),
                            recursion_limited=isinstance(error, GraphRecursionError),
                        ) from error
                    return
                # On recursion-limit errors, snapshot state so consumers can retry extraction.
                recursion_limited = isinstance(error, GraphRecursionError)
                if recursion_limited:
                    state = await _final_state(graph, runnable_config)
                    yield make_terminal_result(
                        state, session_id=session_id, stream_usage=usage_acc.snapshot()
                    )
                else:
                    # The one arm reaching neither a retry nor make_terminal_result (both bank)
                    _bank_partial_usage(usage_acc)
                # Class name is only a fallback signal: consumers check recursion_limited FIRST
                raise HarnessProcessError(
                    f"DeepAgents stream failed: {type(error).__name__}",
                    exit_code=1,
                    stderr=str(error),
                    recursion_limited=recursion_limited,
                ) from error

        return _gen()
