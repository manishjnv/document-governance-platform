# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""orchestrator.preflight — see package docstring."""
from __future__ import annotations
from vvaharness.util import logs

import os
import re
import shutil
import tempfile
import time
from collections.abc import Iterable
from pathlib import Path
from urllib.parse import urlsplit


from vvaharness.backends.harness.models import (
    DegenerateResponseError,
    HarnessJSONDecodeError,
    HarnessMessageParseError,
    TruncatedResponseError,
)
from vvaharness.backends.llm import cli, sdk
from vvaharness.backends.llm import openai as oai
from vvaharness.backends.llm.models import (
    ClockKind,
    effort_scaled_seconds,
    rejection_text,
    validate_detection_tools,
)
from vvaharness.backends.llm.registry import (
    DEEPAGENTS_ROLES,
    POST_SCAN_ROLES,
    unrecognized_model_keys,
    use_responses_api_of,
)
from vvaharness.backends.llm.registry import resolve as resolve_model
from vvaharness.backends.llm.tls import coerce_verify
from vvaharness.orchestrator.config_paths import (
    _iter_model_roles,
    _resolve_against,
    highest_effort,
    role_effort,
)
from vvaharness.report.redact import redact
from vvaharness.util import console
from vvaharness.util.events import Event
from vvaharness.util.exceptions import exception_chain
from vvaharness.util.response_quality import stage_floors
from vvaharness.util.tokens import TOKENS
from vvaharness.util.tokens import (
    estimate_tokens as estimate_tokens,
)

log = logs.get_logger(__name__)


def _resolve_verify_path(cfg_dir: Path, value: object) -> object:
    """Anchor a CA-bundle path supplied via ``verify_ssl`` at the profile dir."""
    # PATH form only: "false" -> <cfg_dir>/false, "" -> Path(".") = profile dir as CA; UNC refused
    coerced = coerce_verify(value)
    if isinstance(coerced, str) and coerced.strip():
        return _resolve_against(cfg_dir, coerced)
    return value


def _resolve_cert_chain(cfg_dir: Path, cert: object) -> object:
    """Anchor a client chain at the profile dir, for both accepted shapes."""
    # Only the first 2 members are paths (3rd is the key PASSWORD); positional, NEVER filtered
    if isinstance(cert, str):
        return _resolve_against(cfg_dir, cert)
    if isinstance(cert, (tuple, list)):
        return tuple(
            _resolve_against(cfg_dir, m)
            if i < 2 and isinstance(m, str) and m.strip() else m
            for i, m in enumerate(cert)
        )
    return cert


def _mask(v: str | None) -> str:
    """Credential PRESENCE only — never emit key material, a prefix, or the length."""
    return "set ✓" if v else "<unset>"


def configure_backends(cfg, cfg_dir: Path) -> None:
    """Apply cfg.sdk / cfg.openai / cfg.cli (api_key, base_url, TLS/proxy) to the backend clients."""
    # One credential serves sdk+deepagents; only `cli` (gateway JWT) keeps its own
    vias = {resolve_model(m).via for _, m in _iter_model_roles(cfg)}
    sdk_sole = vias <= {"sdk", "deepagents"}

    # Pushed UNCONDITIONALLY: gating on an `sdk:`/`openai:` section hides the marker kill switch
    _cache_markers = getattr(cfg, "cache_markers", None)
    _cache_min_block = getattr(cfg, "cache_min_block_tokens", None)
    # Forwarded RAW: an `or None` would erase the meaningful False; None = default "auto"; sdk only
    _cache_route = getattr(cfg, "cache_route", None)
    sdk.configure(cache_markers=_cache_markers,
                  cache_min_block_tokens=_cache_min_block,
                  cache_route=_cache_route)
    oai.configure(cache_markers=_cache_markers)

    sdk_cfg = getattr(cfg, "sdk", None)
    if sdk_cfg is not None:
        ca_cert = getattr(sdk_cfg, "ca_cert", None) or None
        client_cert = getattr(sdk_cfg, "client_cert", None) or None
        sdk.configure(
            api_key=getattr(sdk_cfg, "api_key", None),
            base_url=getattr(sdk_cfg, "base_url", None),
            verify_ssl=_resolve_verify_path(cfg_dir, getattr(sdk_cfg, "verify_ssl", True)),
            ca_cert=_resolve_against(cfg_dir, ca_cert) if ca_cert else None,
            client_cert=_resolve_cert_chain(cfg_dir, client_cert),
            no_proxy=getattr(sdk_cfg, "no_proxy", None) or None,
            allow_api_key_fallback=sdk_sole,
        )
    oai_cfg = getattr(cfg, "openai", None)
    if oai_cfg is not None:
        ca_cert = getattr(oai_cfg, "ca_cert", None) or None
        oai.configure(
            api_key=getattr(oai_cfg, "api_key", None),
            base_url=getattr(oai_cfg, "base_url", None),
            verify_ssl=_resolve_verify_path(cfg_dir, getattr(oai_cfg, "verify_ssl", True)),
            ca_cert=_resolve_against(cfg_dir, ca_cert) if ca_cert else None,
            # Forwarded UNRESOLVED so the backend can warn: no mTLS here, never opened as a file
            client_cert=getattr(oai_cfg, "client_cert", None) or None,
            organization=getattr(oai_cfg, "organization", None) or None,
            no_proxy=getattr(oai_cfg, "no_proxy", None) or None,
        )
    # via:cli shells out to `claude`: push gateway TLS/proxy into its env (auth stays with the CLI)
    cli_cfg = getattr(cfg, "cli", None)
    if cli_cfg is not None:
        ca_cert = getattr(cli_cfg, "ca_cert", None) or None
        client_cert = getattr(cli_cfg, "client_cert", None) or None
        cli.configure(
            verify_ssl=_resolve_verify_path(cfg_dir, getattr(cli_cfg, "verify_ssl", True)),
            ca_cert=_resolve_against(cfg_dir, ca_cert) if ca_cert else None,
            client_cert=_resolve_cert_chain(cfg_dir, client_cert),
            no_proxy=getattr(cli_cfg, "no_proxy", None) or None,
            effort=getattr(cli_cfg, "effort", None) or None,
            # getattr(..., True) not `or None`: an omitted key must get the jail, not lose it
            restricted=bool(getattr(cli_cfg, "restricted", True)),
        )
    # No deepagents branch: that route holds no process-global config (build_harness_env, per call)


def _reachable_despite_degenerate_reply(e: BaseException) -> bool:
    """A terse probe reply proves reachability; it must not fail preflight."""
    return isinstance(e, DegenerateResponseError)


def _reachable_despite_truncated_reply(e: BaseException) -> bool:
    """A reply cut off by the probe's own output budget proves reachability."""
    # Backstop to _PROBE_PING_MAX_TOKENS: thinking counts against max_tokens, so no budget is safe
    return isinstance(e, TruncatedResponseError)


def _reachable_despite_token_cap(err_msg: str) -> bool:
    """LEGACY BACKSTOP: a probe error string that still proves the model is reachable."""
    # Legacy: VVAH-E005 typed path is primary; covers a `claude` cap message CLI_TOKEN_CAP_RX misses
    low = (err_msg or "").lower()
    return "exceeded" in low and "output token" in low


def _post_scan_only(roles: Iterable[str]) -> bool:
    """True when every role in *roles* runs after detection (S10/S11)."""
    # Empty is False: an unattributed gap is never assumed harmless.
    return bool(roles) and set(roles) <= POST_SCAN_ROLES


def _report_credential_gap(message: str, roles: Iterable[str], *remedies: str) -> bool:
    """Print a credential gap; return True when it must abort the run."""
    # Post-scan-only gap is a WARN (S10/S11 gates self-disable); any detection role makes it fatal
    if _post_scan_only(roles):
        log.warning(Event.PREFLIGHT_CREDENTIAL_GAP, detail=message, roles=sorted(roles))
        console.write(f"    required only by {', '.join(sorted(roles))} — that stage "
                      f"will be skipped")
        return False
    log.error(Event.PREFLIGHT_CREDENTIAL_GAP, detail=message)
    for line in remedies:
        console.write(f"  {line}")
    return True


_HARD_TURN_CAP_VIAS: frozenset[str] = frozenset({"sdk", "cli", "openai"})

_TURN_CAPPED_STAGES: tuple[tuple[str, str], ...] = (
    ("step2", "threatmodel"), ("step4", "deepdive"), ("step6_verify", "verify"),
)

_STARVED_TURN_CEILING: int = 20


def _warn_deepagents_tuned_max_turns(cfg) -> None:
    """Warn per stage whose max_turns hard-caps its route yet carries a deepagents-tuned value."""
    for stage_key, role in _TURN_CAPPED_STAGES:
        block = getattr(cfg, stage_key, None)
        model = getattr(getattr(cfg, "models", None), role, None)
        turns = getattr(block, "max_turns", None)
        if block is None or model is None or not isinstance(turns, int) or turns <= 0:
            continue
        via = resolve_model(model).via
        if via not in _HARD_TURN_CAP_VIAS or turns > _STARVED_TURN_CEILING:
            continue
        log.warning(Event.PREFLIGHT_MAX_TURNS_HARD_CAPPED,
                    stage=stage_key, role=role, via=via, max_turns=turns,
                    detail=(f"{stage_key}.max_turns={turns} is a HARD per-session cap on "
                            f"via:{via} (models.{role}). Values at or below "
                            f"{_STARVED_TURN_CEILING} starved S2 on repos of real size; the "
                            f"stage can exhaust its budget, fail, and leave the scan reporting "
                            f"success with near-zero findings."),
                    remedy=(f"raise {stage_key}.max_turns (for example to 60), or "
                            f"route models.{role} via deepagents where max_turns does not bind"))


def check_backends(cfg, *, skip_roles: Iterable[str] = ()) -> bool:
    """Verify whichever backend(s) the config actually uses: - any role with via:cli  → `claude` must be on PATH..."""
    # ``skip_roles`` drops roles this invocation cannot reach; EV needs it (no collection, no EV)
    skip = set(skip_roles)
    model_roles = [(r, m) for r, m in _iter_model_roles(cfg) if r not in skip]
    vias = {resolve_model(m).via for _, m in model_roles}

    # s4 tools must REACH the model or sessions run tool-less; route_carries_tools owns the table
    deepdive_model = getattr(getattr(cfg, "models", None), "deepdive", None)
    if deepdive_model is not None:
        deepdive_via = resolve_model(deepdive_model).via
        # Lazy like every deepagents import here: it pulls langchain; this file must stay importable
        from vvaharness.backends.llm import (
            deepagents as _da_routes,
        )
        carries, why = _da_routes.route_carries_tools(cfg, deepdive_via)
        if not carries:
            log.error(Event.PREFLIGHT_DEEPDIVE_ROUTE_TOOLLESS, via=deepdive_via, reason=why,
                      remedy="route models.deepdive via deepagents/sdk/openai, or via cli with cli.mcp_tools on and the Claude Agent SDK installed")
            return False
    # Which roles depend on each backend: decides fatal (a detection role) vs skip-stage WARN
    roles_by_via: dict[str, set[str]] = {}
    for _role, _model in model_roles:
        roles_by_via.setdefault(resolve_model(_model).via, set()).add(_role)

    # An unknown model-node key is read by no consumer, so a typo changes nothing — warn, never fail
    unknown_keys = [
        f"models.{role}.{key}"
        for role, model in model_roles
        for key in unrecognized_model_keys(model)
    ]
    if unknown_keys:
        log.warning(Event.MODEL_KEY_UNRECOGNIZED, keys=unknown_keys)

    _warn_deepagents_tuned_max_turns(cfg)

    console.write(f"  [auth] active backends: {', '.join(sorted(vias)) or '(none)'}")

    # WARN-only: LangSmith tracing uploads every prompt (repo source); never mutates os.environ
    from vvaharness.util.environment import WARN as _WARN
    from vvaharness.util.environment import langsmith_tracing_check
    _tracing = langsmith_tracing_check()
    if _tracing.status == _WARN:
        log.warning(Event.TRACING_UPLOADS_PROMPTS, detail=_tracing.detail)

    # CLI auth is validated by the live probe, not env presence: Claude Code can use its keychain
    if "cli" in vias:
        console.write("  [auth] cli: delegated to configured CLI; live probe verifies login")
        if os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"):
            console.write("    NOTE: ANTHROPIC_API_KEY / ANTHROPIC_AUTH_TOKEN is set and is "
                          "passed through to the `claude` CLI — it will use that "
                          "credential per its native precedence (API key → auth token "
                          "→ OAuth on disk).")
        if os.environ.get("CLAUDE_CODE_OAUTH_TOKEN"):
            console.mark("ok", "CLAUDE_CODE_OAUTH_TOKEN present for unattended CLI auth",
                         indent=4)

    # Presence dump only, for credentials the active API backends require (via:sdk needs SDK/API)
    if "sdk" in vias:
        sdk_cfg = getattr(cfg, "sdk", None)
        console.write("  [auth] sdk credential sources (presence only — secrets never printed):")
        console.write("    env  ANTHROPIC_SDK_API_KEY     = "
                      f"{_mask(os.environ.get('ANTHROPIC_SDK_API_KEY'))}")
        console.write("    cfg  sdk.api_key               = "
                      f"{_mask(getattr(sdk_cfg, 'api_key', None))}")
        console.write("    cfg  sdk.base_url              = "
                      f"{_mask(getattr(sdk_cfg, 'base_url', None))}")

    if "openai" in vias:
        openai_cfg = getattr(cfg, "openai", None)
        console.write("  [auth] openai credential sources (presence only — secrets never "
                      "printed):")
        console.write("    env  OPENAI_API_KEY            = "
                      f"{_mask(os.environ.get('OPENAI_API_KEY'))}")
        console.write("    cfg  openai.api_key            = "
                      f"{_mask(getattr(openai_cfg, 'api_key', None))}")
        console.write("    cfg  openai.base_url           = "
                      f"{_mask(getattr(openai_cfg, 'base_url', None))}")

    ok = True
    invalid_deepagents = sorted(
        role for role, model in model_roles
        if resolve_model(model).via == "deepagents" and role not in DEEPAGENTS_ROLES
    )
    if invalid_deepagents:
        # Supported-role list derived from the frozenset so the message cannot drift from it.
        supported = ", ".join(f"models.{r}" for r in sorted(DEEPAGENTS_ROLES))
        log.error(Event.PREFLIGHT_ROUTE_UNSUPPORTED, route="deepagents", supported=supported,
                  invalid=sorted(invalid_deepagents))
        ok = False
    if "cli" in vias:
        if not (shutil.which("claude") or shutil.which("claude.cmd")):
            if _report_credential_gap(
                    "`claude` CLI not found on PATH (required by via:cli roles).",
                    roles_by_via["cli"],
                    "Install: https://docs.anthropic.com/en/docs/claude-code"):
                ok = False
        else:
            console.mark("ok", "[cli] claude found on PATH")

    if "sdk" in vias:
        key = getattr(getattr(cfg, "sdk", None), "api_key", None) \
              or os.environ.get("ANTHROPIC_SDK_API_KEY")
        # Same sdk_sole predicate as configure_backends(); the rationale lives there
        sdk_sole = vias <= {"sdk", "deepagents"}
        used_fallback = False
        if not key and sdk_sole:
            key = os.environ.get("ANTHROPIC_API_KEY") \
                  or os.environ.get("ANTHROPIC_AUTH_TOKEN")
            used_fallback = bool(key)
        if not key:
            remedies = ["export ANTHROPIC_SDK_API_KEY=sk-ant-..."]
            if sdk_sole:
                remedies.append("(or set ANTHROPIC_API_KEY — accepted as a fallback "
                                "because no via:cli role shares this run)")
            if _report_credential_gap(
                    "ANTHROPIC_SDK_API_KEY not set (required by via:sdk roles).",
                    roles_by_via["sdk"], *remedies):
                ok = False
        elif used_fallback:
            console.mark("ok", "[sdk] ANTHROPIC_SDK_API_KEY unset — using "
                               "ANTHROPIC_API_KEY/ANTHROPIC_AUTH_TOKEN fallback "
                               "(no via:cli role shares this run)")
        else:
            console.mark("ok", "[sdk] ANTHROPIC_SDK_API_KEY present")

    if "openai" in vias:
        key = getattr(getattr(cfg, "openai", None), "api_key", None) \
              or os.environ.get("OPENAI_API_KEY")
        if not key:
            if _report_credential_gap(
                    "OPENAI_API_KEY not set (required by via:openai roles).",
                    roles_by_via["openai"], "export OPENAI_API_KEY=sk-..."):
                ok = False
        else:
            console.mark("ok", "[openai] OPENAI_API_KEY present")

    if "deepagents" in vias:
        from vvaharness.util.environment import _backend_credential_ok

        # Creds are per (model_id, provider), not per via, so fatal/WARN needs per-target roles
        deep_specs: dict[tuple[str, str | None], set[str]] = {}
        for role, model in model_roles:
            if resolve_model(model).via != "deepagents":
                continue
            spec = (resolve_model(model).model_id, getattr(model, "provider", None))
            deep_specs.setdefault(spec, set()).add(role)
        # Total order: provider is None for inferred targets and would raise compared against a str
        for (model_id, provider), roles in sorted(
                deep_specs.items(), key=lambda kv: (kv[0][0], kv[0][1] or "")):
            # cfg travels so a profile-bound api_key satisfies preflight as it does doctor/runtime
            ready, detail = _backend_credential_ok("deepagents", model_id,
                                                   provider, cfg=cfg)
            if ready:
                console.mark("ok", f"[deepagents] {model_id}: {detail}")
            elif _report_credential_gap(f"DeepAgents {model_id}: {detail}", roles):
                ok = False

    # Skipped when credential checks already failed (nothing to probe).
    if not ok:
        console.write("  [probe] skipped — fix credential errors above first")
        return ok
    # JWT ANTHROPIC_API_KEY with no BASE_URL, caught pre-probe (else 60s+ proxy hang); route-gated
    from vvaharness.backends.harness.provider_routing import routes_to_anthropic
    anthropic_route = vias & {"sdk", "cli"} or any(
        routes_to_anthropic(resolve_model(model).model_id, getattr(model, "provider", None))
        for _role, model in model_roles
        if resolve_model(model).via == "deepagents"
    )
    if anthropic_route:
        from vvaharness.util.environment import FAIL as _FAIL
        from vvaharness.util.environment import _gateway_check
        gw = _gateway_check()
        if gw.status == _FAIL:
            log.error(Event.PREFLIGHT_GATEWAY_UNUSABLE, detail=gw.detail)
            return False
    return probe_backends(cfg, skip_roles=skip)


#: Roles driving agentic(); `deepdive` (S4) is NOT here: no `step4.allowed_tools` key to resolve
_AGENTIC_ROLES = ("preprocess", "verify", "threatmodel")


def _agentic_roles(cfg) -> tuple[str, ...]:
    """The roles this config will actually call agentic() for."""
    return _AGENTIC_ROLES


def _agentic_role_tools(cfg, role: str, via: str | None = None) -> list[str]:
    """The allowed_tools each agentic role passes to llm.agentic(), computed by the SAME `validate_detection_too..."""
    if role == "preprocess":
        return validate_detection_tools(
            getattr(getattr(cfg, "step1", None), "allowed_tools", None),
            config_key="step1.allowed_tools", via=via)
    if role == "verify":
        return validate_detection_tools(
            getattr(getattr(cfg, "step6_verify", None), "allowed_tools", None),
            config_key="step6_verify.allowed_tools", via=via)
    if role == "threatmodel":
        return validate_detection_tools(
            getattr(getattr(cfg, "step2", None), "allowed_tools", None),
            config_key="step2.allowed_tools", via=via)
    return []


# VVAH-E003 floors: NEVER lower to 0 -- min_chars/min_tokens of 0 are unsatisfiable, disabling it
_PROBE_PING_MIN_CHARS = 1
_PROBE_PING_MIN_TOKENS = 1

# Must clear a one-word reply plus preamble; at 4 every sdk/openai probe truncated (VVAH-E005)
_PROBE_PING_MAX_TOKENS = 256
_PROBE_PING_TIMEOUT_S = 120
#: Wall clock for one agentic smoke probe: wider than the prompt probe, far below stage timeouts
_PROBE_AGENTIC_TIMEOUT_S = 300


#: Turn budget for the forced tool round-trip: a hard cap on sdk/openai/cli, so 1 would truncate it
_PROBE_ROUNDTRIP_TURNS = 2

#: Marker file the probe reads and the CLI bridge tool name; named so a stray file reads as itself
_PROBE_MARKER_FILENAME = "vva_preflight_probe_marker.txt"
_PROBE_BRIDGE_TOOL_NAME = "PreflightProbeEcho"


def _probe_roundtrip_nonce() -> str:
    """A short, unguessable token proving a reply came from the ACTUAL round trip, not a lucky guess or a halluc..."""
    import secrets
    return secrets.token_hex(8)


def _write_probe_marker(workdir: str, nonce: str) -> str:
    """Write the nonce marker file the round-trip prompt asks the model to read."""
    path = Path(workdir) / _PROBE_MARKER_FILENAME
    path.write_text(nonce, encoding="utf-8")
    return _PROBE_MARKER_FILENAME


def _native_roundtrip_prompt(marker_name: str) -> str:
    """Prompt forcing a genuine tool call (Read) followed by a final answer turn."""
    return (
        f"Use your file-reading tool to read the file '{marker_name}' in the "
        "current directory, then reply with exactly its contents and nothing else."
    )


def _cli_bridge_enabled(cfg) -> bool:
    """Whether `via: cli` sessions in this config would route tools through the in-process MCP bridge — deferrin..."""
    from vvaharness.backends.llm.deepagents import route_carries_tools
    carries, _reason = route_carries_tools(cfg, "cli")
    return carries


def _reachable_despite_tool_dispatch_error(e: BaseException) -> bool:
    """A forced tool round-trip stumbled on tool MECHANICS, not connectivity."""
    # A malformed tool_use proves the endpoint answered; narrow by design: NotImplementedError fatal
    return isinstance(e, (HarnessJSONDecodeError, HarnessMessageParseError))


#: The gateway's own wrapper text around the real rejection; stripped so the cause line is useful.
_GATEWAY_WRAPPER_RX = re.compile(
    r"^Could not process the query for model \S+\. Error: Error code: \d+ - ?")


def _upstream_message(e: BaseException) -> str:
    """The unwrapped upstream rejection text, plus our own wrapper line when it adds a hint.

    `body` first: openai 3.22.1's `.message` re-wraps `.body`, so an anchored strip on `.message`
    never matches — `rejection_text` falls back to `.message` when there is no body. A wrapper
    exception (e.g. the openai route's fail-fast, which names the Responses/deepagents remedy)
    carries routing information the upstream body never does; that text is kept, not discarded,
    whenever it says more than the bare upstream line.
    """
    link = next(
        (lk for lk in exception_chain(e) if getattr(lk, "status_code", None) is not None), e)
    raw_body = getattr(link, "body", None)
    body = raw_body if isinstance(raw_body, str) and raw_body else rejection_text(link)
    body = _GATEWAY_WRAPPER_RX.sub("", body)
    lines = body.splitlines()
    upstream = (lines[0] if lines else "").strip() or "(no message)"
    if link is e:
        return upstream
    wrapper = " ".join(str(e).split())
    return upstream if not wrapper or wrapper == upstream else f"{wrapper} | upstream: {upstream}"


def _probe_agentic_roles(cfg) -> bool:
    """Smoke-probe the agentic() backend path for the preprocess + verify roles."""
    # Covers agentic() (VVAH-E006 et al): nonce marker + REAL tool set; unconfirmed round trip WARNs
    from vvaharness.backends.harness.models import ToolStateNotRoundTrippedError
    from vvaharness.backends.llm import deepagents as _deepagents
    from vvaharness.backends.llm.registry import agentic as _probe_agentic
    # provider is in the key so two providers sharing a model id are both tested, not collapsed
    targets: dict[tuple, tuple] = {}
    agentic_roles = _agentic_roles(cfg)
    ok = True
    for role, m in _iter_model_roles(cfg):
        if role not in agentic_roles:
            continue
        mid, via, _ = resolve_model(m)
        try:
            tools = _agentic_role_tools(cfg, role, via)
        except ValueError as e:
            # validate_detection_tools: a doomed config fails HERE, not after S1-S5 spend
            if _report_credential_gap(str(e), {role}):
                ok = False
            continue
        if not tools:
            # No tool offered: cannot hit a tool-replay failure, and nothing to round-trip with
            console.write(f"  [probe] {role}: no tools configured — skipping the "
                          f"agentic round-trip probe (nothing to round-trip)")
            continue
        key = (mid, via, getattr(m, "provider", None), frozenset(tools))
        _node, _t, roles = targets.setdefault(key, (m, tools, []))
        roles.append(role)

    if not targets:
        return ok

    console.write(f"  [probe] agentic backend path ({len(targets)} agentic "
                  f"role/backend pair(s)):")
    for (mid, via, _provider, _tk), (mcfg, tools, roles) in targets.items():
        role_list = ",".join(roles)
        effort = highest_effort(role_effort(cfg, r) for r in roles)
        t0 = time.time()
        workdir = tempfile.mkdtemp(prefix="vva-preflight-")
        roles_set = set(roles)
        try:
            nonce = _probe_roundtrip_nonce()
            marker_name = _write_probe_marker(workdir, nonce)
            prompt = _native_roundtrip_prompt(marker_name)
            # ONE scope per tag (overlapping ones corrupt); keep both _reachable_despite_* helpers
            with stage_floors("preflight-agentic",
                              min_chars=_PROBE_PING_MIN_CHARS,
                              min_tokens=_PROBE_PING_MIN_TOKENS):
                if via == "deepagents":
                    reply = _deepagents.agentic(
                        prompt, model=mcfg, system_prompt=None,
                        allowed_tools=list(tools), cwd=workdir,
                        max_turns=_PROBE_ROUNDTRIP_TURNS, tag="preflight-agentic",
                        graph_name="preflight-agentic",
                        sdk_cfg=getattr(cfg, "sdk", None),
                        openai_cfg=getattr(cfg, "openai", None),
                        timeout=_PROBE_AGENTIC_TIMEOUT_S,
                        effort=effort,
                        think_in_prompt=_deepagents.think_in_prompt_enabled(cfg))
                else:
                    # Plain path ALWAYS runs for via: cli: it caught the stream-json argv regression
                    reply = _probe_agentic(
                        prompt, model=mcfg, system_prompt=None,
                        allowed_tools=list(tools), cwd=workdir,
                        max_turns=_PROBE_ROUNDTRIP_TURNS, tag="preflight-agentic",
                        # A smoke test must not hold a scan for an hour; sdk/openai drop the kwarg
                        timeout=_PROBE_AGENTIC_TIMEOUT_S,
                        # cli.agentic's own effort= replaces the global cli.effort; leave it alone
                        **({"effort": effort} if via != "cli" else {}))
                    if via == "cli" and _cli_bridge_enabled(cfg):
                        # ADDITIONALLY, not instead: swapping would drop argv-regression coverage
                        _probe_agentic_via_cli_bridge(
                            prompt, nonce=nonce, model=mid,
                            allowed_tools=tools, cwd=workdir)
            confirmed = nonce in (reply or "")
            # Nonce never echoed: the model answered without the tool, so reachability only
            console.mark(
                "ok" if confirmed else "warn",
                "  ".join((via, mid, f"{time.time()-t0:.1f}s", role_list,
                           "" if confirmed else "round-trip unconfirmed (reply never echoed the "
                                                "marker) — tool state was reachable but not "
                                                "proven round-tripped")))
        except Exception as e:
            if isinstance(e, ToolStateNotRoundTrippedError):
                # Deterministic: the real session fails identically, so fatal for a detection role
                if _report_credential_gap(str(e), roles_set):
                    ok = False
                continue
            if _reachable_despite_token_cap(str(e)) or \
                    _reachable_despite_degenerate_reply(e) or \
                    _reachable_despite_truncated_reply(e) or \
                    _reachable_despite_tool_dispatch_error(e):
                note = ("reachable; terse, token-capped, or "
                       "tool-mechanics reply")
                console.mark("ok", "  ".join(
                    (via, mid, f"{time.time()-t0:.1f}s", role_list, note)))
                continue
            note = f"FAILED (agentic): {type(e).__name__}"
            console.mark("fail", "  ".join((via, mid, f"{time.time()-t0:.1f}s", role_list, note)))
            log.error(Event.PREFLIGHT_PROBE_FAILED, model=mid, route=via,
                      effort=effort, cause=_upstream_message(e))
            ok = False
        finally:
            shutil.rmtree(workdir, ignore_errors=True)
    return ok


def _probe_agentic_via_cli_bridge(
    prompt: str, *, nonce: str, model: str, allowed_tools: list[str], cwd: str
) -> str:
    """Round-trip ONE synthetic tool call through the in-process CLI MCP bridge."""
    # Public `agentic_with_tools` only; it takes no timeout, so bounded on a thread we cannot kill
    from langchain_core.tools import tool as _lc_tool

    from vvaharness.pipeline.stages.replay import start_daemon

    @_lc_tool(_PROBE_BRIDGE_TOOL_NAME)
    def _echo(marker: str) -> str:
        """Echo the given marker back verbatim."""
        return marker

    def _tool_builder(_options, allowed_tools=()):
        return [_echo]

    from vvaharness.backends.llm import cli_mcp

    def _call() -> str:
        return cli_mcp.agentic_with_tools(
            f"Call the {_PROBE_BRIDGE_TOOL_NAME} tool with marker='{nonce}', then "
            "reply with exactly what it returns and nothing else.",
            model=model, system_prompt=None, allowed_tools=allowed_tools, cwd=cwd,
            tool_builder=_tool_builder, fact_tools=(_PROBE_BRIDGE_TOOL_NAME,),
            max_turns=_PROBE_ROUNDTRIP_TURNS, tag="preflight-agentic",
        )

    # Daemon worker: not joined at exit, so a hung probe cannot hold the process open
    future = start_daemon(_call, "preflight-bridge-probe")
    try:
        return future.result(timeout=_PROBE_AGENTIC_TIMEOUT_S)
    except TimeoutError as exc:
        # A done future raised its own TimeoutError (the futures one is the builtin) or just
        # finished: hand it back unchanged; only a pending one timed out
        if future.done():
            return future.result()
        future.cancel()
        raise TimeoutError(
            f"cli MCP bridge probe for {model!r} did not respond within "
            f"{_PROBE_AGENTIC_TIMEOUT_S}s"
        ) from exc


def _probe_targets(cfg, *, skip_roles: Iterable[str] = ()) -> dict[tuple[str, str, str | None],
                                tuple[object, list[str]]]:
    """Unique probe targets: (model_id, via, provider) -> (node, roles), minus *skip_roles*."""
    # cfg node kept for llm.resolve(); provider in the key so neither provider goes untested
    skip = set(skip_roles)
    targets: dict[tuple[str, str, str | None], tuple[object, list[str]]] = {}
    for role, m in _iter_model_roles(cfg):
        if role in skip:
            continue
        mid, via, _ = resolve_model(m)
        key = (mid, via, getattr(m, "provider", None))
        _node, roles = targets.setdefault(key, (m, []))
        roles.append(role)
    return targets


def _probe_deepagents_harness(cfg, model_id: str, provider: str | None,
                              *, include_tls: bool = True,
                              use_responses_api: bool | None = None,
                              effort: str | None = None) -> None:
    """One bounded one-shot through the deepagents harness — the ONLY deepagents route since the registry adapte..."""

    from vvaharness.backends.harness import OneShotOptions
    from vvaharness.backends.harness.provider_routing import (
        credential_env_overrides,
    )
    from vvaharness.backends.llm.deepagents import (
        build_harness_env,
        markers_on,
        run_oneshot,
        think_in_prompt_enabled,
    )

    sdk_cfg = getattr(cfg, "sdk", None)
    openai_cfg = getattr(cfg, "openai", None)
    if include_tls:
        env = build_harness_env(
            model_id, provider, sdk_cfg=sdk_cfg, openai_cfg=openai_cfg,
            cfg_dir=getattr(cfg, "_data", {}).get("_config_dir"),
        )
    else:
        # Byte-identical to plugin_runner._invoke_deepagents's env build.
        env = {
            **os.environ,
            **credential_env_overrides(
                model_id, provider, sdk_cfg=sdk_cfg, openai_cfg=openai_cfg,
            ),
        }
    with tempfile.TemporaryDirectory(
            prefix="vva-preflight-deepagents-") as workdir:
        # Through llm.deepagents so the probe primes _model_cache on the scan's persistent loop
        result = run_oneshot(
            "reply with the single word ok",
            OneShotOptions(
                model=model_id,
                cwd=Path(workdir),
                env=env,
                model_provider=provider,
                use_responses_api=use_responses_api,
                max_turns=2,
                graph_name="preflight",
                # A marker-rejecting gateway must stay reachable with the kill switch set
                cache_markers=markers_on(sdk_cfg),
                effort=effort,
                # So this probe sends the same field the scan sends (`none` for models that think in the prompt)
                think_in_prompt=think_in_prompt_enabled(cfg),
            ),
            # Same effort-scaled bound sdk/openai put on their ping; None would block forever
            tag="preflight",
            timeout=effort_scaled_seconds(_PROBE_PING_TIMEOUT_S, effort, kind=ClockKind.REQUEST),
        )
    if result.is_error:
        raise RuntimeError(
            f"DeepAgents preflight failed: {result.subtype or 'unknown error'}")


def probe_backends(cfg, *, skip_roles: Iterable[str] = ()) -> bool:
    """Live connectivity probe: one minimal request per unique (model_id, via, provider) so bad credentials, an..."""
    from vvaharness.backends.llm.registry import prompt as _probe
    skip = set(skip_roles)
    invalid_deepagents = sorted(
        role for role, model in _iter_model_roles(cfg)
        if role not in skip and resolve_model(model).via == "deepagents"
        and role not in DEEPAGENTS_ROLES
    )
    if invalid_deepagents:
        # Supported-role list derived from the frozenset — see check_backends().
        console.write(
            "ERROR: refusing DeepAgents probe for unsupported role(s): "
            + ", ".join(invalid_deepagents)
            + f" (via:deepagents role(s): {', '.join(sorted(DEEPAGENTS_ROLES))})"
        )
        return False
    targets = _probe_targets(cfg, skip_roles=skip)

    console.write(f"  [probe] live model connectivity ({len(targets)} unique "
                  f"model/backend pair(s)):")
    ok = True
    # Post-scan roles whose model is unreachable, so the summary cannot claim "all reachable"
    skipped: set[str] = set()
    for (mid, via, provider), (mcfg, roles) in targets.items():
        role_list = ",".join(roles)
        effort = highest_effort(role_effort(cfg, r) for r in roles)
        t0 = time.time()
        try:
            if via == "deepagents":
                # Harness one-shot is the seam for all via:deepagents; TLS only if detection shares
                _probe_deepagents_harness(
                    cfg, mid, provider,
                    include_tls=not _post_scan_only(roles),
                    use_responses_api=use_responses_api_of(mcfg),
                    effort=effort)
            else:
                # 150-char/30-token VVAH-E003 floors misfire on a one-word pong; counters per-tag
                with stage_floors("preflight",
                                  min_chars=_PROBE_PING_MIN_CHARS,
                                  min_tokens=_PROBE_PING_MIN_TOKENS):
                    _probe("ping", model=mcfg,
                           max_tokens=_PROBE_PING_MAX_TOKENS,
                           timeout=_PROBE_PING_TIMEOUT_S, tag="preflight",
                           # cli.prompt's own effort= would replace the global cli.effort
                           **({"effort": effort} if via != "cli" else {}))
            console.mark("ok", "  ".join((via, mid, f"{time.time()-t0:.1f}s", role_list, "")))
        except Exception as e:
            if _reachable_despite_token_cap(str(e)) or \
                    _reachable_despite_degenerate_reply(e) or \
                    _reachable_despite_truncated_reply(e):
                console.mark("ok", "  ".join((via, mid, f"{time.time()-t0:.1f}s",
                                              role_list, "reachable; terse or token-capped reply")))
                continue
            # A model only S10/S11 use degrades that stage, not the scan; those gates skip it
            if _post_scan_only(roles):
                note = f"unreachable — that stage will be skipped; {type(e).__name__}"
                console.mark("warn", "  ".join((via, mid, f"{time.time()-t0:.1f}s",
                                                role_list, note)))
                log.warning(Event.PREFLIGHT_PROBE_FAILED, model=mid, route=via,
                            effort=effort, cause=_upstream_message(e))
                skipped.update(roles)
                continue
            note = f"FAILED: {type(e).__name__}"
            console.mark("fail", "  ".join((via, mid, f"{time.time()-t0:.1f}s", role_list, note)))
            log.error(Event.PREFLIGHT_PROBE_FAILED, model=mid, route=via,
                      effort=effort, cause=_upstream_message(e))
            ok = False

    # Runs even when a prompt probe already failed: more complete diagnostics in one pass
    ok = _probe_agentic_roles(cfg) and ok

    if ok and skipped:
        console.mark("ok", f"[probe] detection backends reachable — "
                           f"{', '.join(sorted(skipped))} unreachable, so that stage is "
                           f"skipped (see the WARN row above)")
    elif ok:
        console.mark("ok", "[probe] all model backends reachable")
    else:
        log.error(Event.PREFLIGHT_BACKENDS_UNREACHABLE)
    return ok


# doctor --cache-probe: spends real tokens, never in a scan; usage ONLY via TOKENS, never own client

# The `prompt()` arm's vias; deepagents has its own (_probe_deepagents_cache). Do NOT widen this set
_PROMPT_VIAS = frozenset({"sdk", "openai", "cli"})

_FILLER_MIN_TOKENS = 8192
_FILLER_CHARS_PER_TOKEN = 4      # same rough heuristic as cli._estimate (bytes // 4)
_FILLER_MARGIN = 1.25            # build past the floor, not at it — see cache_probe_filler()

# Budget must clear a real reply: no VVAH-E005 exemption here, so truncation is a hard FAILED
_PROBE_MAX_TOKENS = 256
_PROBE_TIMEOUT_S = 120
_CALL_B_DEADLINE_S = 5.0         # well under any provider's cache TTL, so a slow run is not expiry
# Probe-only: no shipped profile sets thinking_budget, so the probe supplies one to force thinking
_PROBE_THINKING_BUDGET = 1024

# Distinct ~50-token A/B turns: they must differ so a hit on B can only come from the shared prefix
_USER_MSG_A = (
    "Reply with the single word PONG. cache-probe call A deterministic marker "
    "sequence diagnostic token filler padding text alpha bravo charlie delta "
    "echo foxtrot golf hotel india juliet kilo lima mike november oscar"
)
_USER_MSG_B = (
    "Reply with the single word PONG. cache-probe call B deterministic marker "
    "sequence diagnostic token filler padding text papa quebec romeo sierra "
    "tango uniform victor whiskey xray yankee zulu alpha bravo charlie"
)

# Verdict codes; ANTHROPIC/OPENAI name the cache-accounting SHAPE observed, not the transport
V_ANTHROPIC_WORKS = "anthropic_works"
V_ANTHROPIC_ROUTING_GAP = "anthropic_write_ok_read_fails"
V_ANTHROPIC_NOT_HONOURED = "anthropic_marker_not_honoured"
V_ANTHROPIC_ALREADY_WARM = "anthropic_works_prefix_already_cached"
V_OPENAI_WORKING = "openai_implicit_working"
V_OPENAI_BELOW_MIN = "openai_below_minimum_or_unstable"
V_NO_CACHE_FIELDS = "no_cache_fields_treat_as_implicit"
# Not one of classify_cache_verdict()'s six rows: set only when _marker_would_be_placed says False
V_MARKER_WITHHELD = "anthropic_marker_withheld_by_gate"

_VERDICT_TEXT = {
    V_ANTHROPIC_WORKS: (
        "cache markers are honoured on this route; explicit breakpoints are "
        "an optimisation here, not a fix."),
    V_ANTHROPIC_ROUTING_GAP: (
        "writes succeed but reads do not — investigate request routing or "
        "cache-key affinity, not marker placement."),
    V_ANTHROPIC_NOT_HONOURED: (
        "the marker is not taking effect at all — check whether base_url "
        "points at a gateway that strips it, whether the block is below this "
        "model's minimum cacheable size, retest with thinking disabled, and "
        "retest against the vendor endpoint directly."),
    V_ANTHROPIC_ALREADY_WARM: (
        "caching is working; nothing new was written because this prefix was "
        "already cached from an earlier call, and it was read back. Re-run "
        "after the cache lifetime has elapsed if you want to observe a write."),
    V_OPENAI_WORKING: (
        "the implicit prefix cache is working normally; no explicit marker "
        "is needed or available on this route."),
    V_OPENAI_BELOW_MIN: (
        "no cache read observed — the prompt may be below this route's "
        "minimum cacheable size, or its prefix is unstable across calls; "
        "re-probe with a larger filler to tell which."),
    V_NO_CACHE_FIELDS: (
        "this route reports no cache accounting at all — treat caching as "
        "implicit and unmeasurable here; rely on keeping the prompt prefix "
        "stable rather than on any marker."),
    V_MARKER_WITHHELD: (
        "this tool's own gate never placed a cache_control marker on this "
        "call (unrecognised route, cache markers switched off, or the prompt "
        "is below this model's estimated minimum cacheable size) — the "
        "gateway was never asked to cache anything, so there is nothing to "
        "investigate there. Re-probe with a larger prompt shape, or set "
        "cache_route / cache_min_block_tokens to change the gate's decision."),
}

def cache_probe_filler(min_tokens: int = _FILLER_MIN_TOKENS) -> str:
    """Deterministic filler of at least `min_tokens` ESTIMATED tokens for the cache probe's synthetic system prompt."""
    # Deterministic, built well PAST min_tokens: 8192 nominal can really be ~3,900 (min block 4096)
    target_chars = int(min_tokens * _FILLER_CHARS_PER_TOKEN * _FILLER_MARGIN)
    words = ["alpha", "bravo", "charlie", "delta", "echo", "foxtrot", "golf", "hotel", "india", "juliet", "kilo", "lima", "mike", "november", "oscar", "papa", "quebec", "romeo", "sierra", "tango", "uniform", "victor", "whiskey", "xray", "yankee", "zulu"]
    lines: list[str] = []
    total = 0
    i = 0
    while total < target_chars:
        line = f"CACHE-PROBE-FILLER-LINE-{i:06d} " + " ".join(words) + f" {i}\n"
        lines.append(line)
        total += len(line)
        i += 1
    return "".join(lines)


def _scheme_host(url: str | None) -> str:
    """Reduce a URL to `scheme://host[:port]` only — never a path, query string, or userinfo, any of which can c..."""
    if not url:
        return "(default)"
    try:
        parts = urlsplit(url)
        host = parts.hostname or ""
        # `hostname` strips IPv6 brackets; without them the port looks like another address group
        if ":" in host:
            host = f"[{host}]"
        if parts.port:
            host = f"{host}:{parts.port}"
        if parts.scheme and host:
            out = f"{parts.scheme}://{host}"
        else:
            out = host or "(unparseable)"
    except Exception:
        out = "(unparseable)"
    return redact(out)


def _resolved_base_url_scheme_host(via: str) -> str:
    """The base_url actually in force for `via`, scheme+host only, read from the backend's own already-configure..."""
    # `_get_client()` is called as the first real call would, never modified by this diagnostic
    try:
        if via == "sdk":
            raw = str(sdk._get_client().base_url)
        elif via == "openai":
            raw = str(oai._get_client().base_url)
        else:
            return "(cli subprocess — no base_url)"
    except Exception:
        return "(unresolved)"
    return _scheme_host(raw)


def _thinking_actually_sent(model_id: str, requested_budget: int | None) -> bool:
    """Ground truth for whether the FINAL successful request carried `thinking`, checked AFTER the call returns."""
    # sdk._NO_THINK_MODELS is populated at RUNTIME by the retry-and-drop handler, so answer post-hoc
    if not requested_budget:
        return False
    return model_id not in sdk._NO_THINK_MODELS


def _marker_would_be_placed(via: str, system_prompt: str,
                            model_id: str) -> bool | None:
    """Whether the sdk backend's OWN gate would place a `cache_control` marker on this probe call's system block..."""
    # None when unknowable (cli builds in-subprocess, openai places none); any failure is None too
    if via != "sdk":
        return None
    try:
        if not sdk._cache_markers_enabled():
            return False
        if sdk._cache_route(sdk._get_client()) not in sdk._CACHE_CONTROL_ROUTES:
            return False
        return bool(sdk._cache_prefix_meets_minimum(system_prompt, model_id))
    except Exception:  # noqa: BLE001 — diagnostic-only; never break the probe
        return None


def usage_dict_for_classifier(*, cache_write: int, cache_read: int,
                              write_present: bool,
                              read_present: bool) -> tuple[dict, dict]:
    """Build the (usage_a, usage_b) dicts classify_cache_verdict() expects from ONE probe pair's measurements: t..."""
    # Presence is OBSERVED at TOKENS.add(), never inferred from `via`: openai.py can set write too
    usage_a: dict = {}
    usage_b: dict = {}
    if write_present:
        usage_a["cache_creation_input_tokens"] = cache_write
    if read_present:
        usage_b["cache_read_input_tokens"] = cache_read
    return usage_a, usage_b


def classify_cache_verdict(usage_a: dict, usage_b: dict) -> str:
    """Pure classifier that turns two calls' cache usage into one of six verdicts, split by which usage fields t..."""
    # Field PRESENCE, not value, selects the row: checked with `in`, so "never reported" != "0"
    creation_present = "cache_creation_input_tokens" in usage_a
    read_present = "cache_read_input_tokens" in usage_b
    if not creation_present and not read_present:
        return V_NO_CACHE_FIELDS
    read = int(usage_b.get("cache_read_input_tokens", 0) or 0)
    if creation_present:
        creation = int(usage_a.get("cache_creation_input_tokens", 0) or 0)
        if creation > 0 and read > 0:
            return V_ANTHROPIC_WORKS
        if creation > 0 and read == 0:
            return V_ANTHROPIC_ROUTING_GAP
        if creation == 0 and read > 0:
            # Nothing written: the prefix was ALREADY cached and read back — working, not broken
            return V_ANTHROPIC_ALREADY_WARM
        return V_ANTHROPIC_NOT_HONOURED
    return V_OPENAI_WORKING if read > 0 else V_OPENAI_BELOW_MIN


def _deepdive_system_prompt() -> str:
    """The real system prompt the deep-dive stage sends on every call, imported read-only rather than copied, so..."""
    from vvaharness.pipeline.stages.s4.prompts import build_system_prompt
    return build_system_prompt()


def _cache_probe_targets(cfg) -> dict[tuple[str, str], object]:
    """Unique (model_id, via) -> model config node, restricted to the vias `backends.llm.prompt()` actually disp..."""
    targets: dict[tuple[str, str], object] = {}
    for _role, m in _iter_model_roles(cfg):
        mid, via, _extras = resolve_model(m)
        if via not in _PROMPT_VIAS:
            continue
        targets.setdefault((mid, via), m)
    return targets


def _observe_call(phase_label: str, invoke) -> dict:
    """Run ONE backend call via *invoke* and return its cache usage: token VALUES by snapshot-diffing the global..."""
    # Counter diff cannot show PRESENCE (`or 0` coercion), so TOKENS.add is wrapped; one real call
    observed: list[dict] = []
    _sentinel = object()
    prev_add = TOKENS.__dict__.get("add", _sentinel)
    real_add = TOKENS.add

    def _observing_add(usage, **kw):
        if isinstance(usage, dict) and TOKENS.current_phase() == phase_label:
            observed.append(dict(usage))
        return real_add(usage, **kw)

    with TOKENS.phase(phase_label):
        before = dict(TOKENS.snapshot()["by_phase"].get(phase_label, {}))
        TOKENS.add = _observing_add
        try:
            invoke()
        finally:
            if prev_add is _sentinel:
                TOKENS.__dict__.pop("add", None)   # back to the class method
            else:
                TOKENS.add = prev_add
        after = dict(TOKENS.snapshot()["by_phase"].get(phase_label, {}))
    return {
        "cache_read": after.get("cache_read", 0) - before.get("cache_read", 0),
        "cache_write": after.get("cache_write", 0) - before.get("cache_write", 0),
        # Observed, per-call: did any usage carry the field at all (present-at-zero counts)?
        "cache_read_present": any("cache_read_input_tokens" in u
                                  for u in observed),
        "cache_write_present": any("cache_creation_input_tokens" in u
                                   for u in observed),
    }


def _call_and_diff(*, model, system_prompt: str, user_prompt: str,
                    thinking_budget: int | None, phase_label: str) -> dict:
    """One `backends.llm.prompt()` call observed through _observe_call, so the request is built by sdk.py's/oai...."""
    from vvaharness.backends.llm.registry import prompt as _prompt

    def _invoke():
        # The point is `usage`, not the reply: report-prose floors (150/30) flag a correct "PONG"
        with stage_floors("cache-probe",
                          min_chars=_PROBE_PING_MIN_CHARS,
                          min_tokens=_PROBE_PING_MIN_TOKENS):
            _prompt(user_prompt, model=model, system_prompt=system_prompt,
                    thinking_budget=thinking_budget,
                    max_tokens=_PROBE_MAX_TOKENS,
                    timeout=_PROBE_TIMEOUT_S, tag="cache-probe")

    return _observe_call(phase_label, _invoke)


def _deepagents_cache_probe_targets(cfg) -> dict[tuple[str, str], object]:
    """Unique (model_id, "deepagents") -> model config node — the roles the prompt-route probe skips."""
    targets: dict[tuple[str, str], object] = {}
    for _role, m in _iter_model_roles(cfg):
        mid, via, _extras = resolve_model(m)
        if via != "deepagents":
            continue
        targets.setdefault((mid, via), m)
    return targets


def _deepagents_marker_would_be_placed(cfg, model_id: str,
                                       provider: str | None) -> bool:
    """Whether the deepagents route's OWN gate places block markers on this call — asked of the same two predica..."""
    from vvaharness.backends.harness.provider_routing import routes_to_anthropic
    from vvaharness.backends.llm.deepagents import markers_on
    return (markers_on(getattr(cfg, "sdk", None))
            and routes_to_anthropic(model_id, provider))


def _deepagents_base_url(cfg, model_id: str, provider: str | None) -> str:
    """Scheme+host of the base URL the deepagents route will actually use, read from the same env build the disp..."""
    from vvaharness.backends.harness.deepagents.models import (
        anthropic_base,
        openai_base,
    )
    from vvaharness.backends.harness.provider_routing import routes_to_anthropic
    from vvaharness.backends.llm.deepagents import build_harness_env
    try:
        env = build_harness_env(
            model_id, provider,
            sdk_cfg=getattr(cfg, "sdk", None),
            openai_cfg=getattr(cfg, "openai", None),
            cfg_dir=getattr(cfg, "_data", {}).get("_config_dir"),
        )
        raw = (anthropic_base(env) if routes_to_anthropic(model_id, provider)
               else openai_base(env))
    except Exception:  # noqa: BLE001 — diagnostic label only; never break the probe
        return "(unresolved)"
    return _scheme_host(raw)


def _probe_deepagents_cache(cfg, model_node, *, label_base: str) -> tuple[dict, dict]:
    """Two dispatch_prompt calls (A then B) sharing one filler system prompt."""
    from vvaharness.backends.llm.deepagents import dispatch_prompt
    system_prompt = cache_probe_filler()

    def _call(user_prompt: str, phase_label: str, workdir: str) -> dict:
        def _invoke():
            # Same PONG-sized reply and per-tag floors as _call_and_diff.
            with stage_floors("cache-probe",
                              min_chars=_PROBE_PING_MIN_CHARS,
                              min_tokens=_PROBE_PING_MIN_TOKENS):
                dispatch_prompt(user_prompt, model=model_node, cfg=cfg,
                                cwd=workdir, system_prompt=system_prompt,
                                max_tokens=_PROBE_MAX_TOKENS, tag="cache-probe")

        return _observe_call(phase_label, _invoke)

    with tempfile.TemporaryDirectory(prefix="vva-cache-probe-deepagents-") as workdir:
        write = _call(_USER_MSG_A, f"{label_base}::A", workdir)
        read = _call(_USER_MSG_B, f"{label_base}::B", workdir)
    return write, read


def run_cache_probe(cfg) -> bool:
    """The live diagnostic behind `vvaharness doctor --cache-probe`."""
    # Per (model_id, via): 2 prompt shapes x 2 thinking arms, A and B within _CALL_B_DEADLINE_S
    targets = _cache_probe_targets(cfg)
    deepagents_targets = _deepagents_cache_probe_targets(cfg)
    shapes = (("synthetic", cache_probe_filler()),
             ("deepdive-system", _deepdive_system_prompt()))
    n_models = len(targets)
    n_deepagents = len(deepagents_targets)
    # prompt routes: shapes x thinking-arms x (A, B); deepagents: (A, B) only.
    n_calls = n_models * len(shapes) * 2 * 2 + n_deepagents * 2
    if not n_calls:
        console.write("  [cache-probe] no sdk/openai/cli/deepagents model roles "
                      "configured — nothing to probe")
        return True
    console.write(f"  [cache-probe] {n_models} prompt-route pair(s) x {len(shapes)} filler "
                  f"shape(s) x 2 thinking arm(s) x 2 calls + {n_deepagents} deepagents "
                  f"pair(s) x 2 calls = {n_calls} call(s), "
                  f"~8.2k tokens/call -> ~{n_calls * 8200:,} tokens total")

    ok = True
    rows: list[dict] = []
    measured = console.status_table(
        title="  [cache-probe] measurements:",
        columns=("", "via", "model", "filler", "thinking_sent", "base_url",
                 "creation", "read", "verdict"))
    for (model_id, via), model_node in sorted(targets.items()):
        base_url = _resolved_base_url_scheme_host(via)
        for shape_name, system_prompt in shapes:
            for think_label, budget in (("on", _PROBE_THINKING_BUDGET), ("off", None)):
                label_base = f"cache_probe::{model_id}::{via}::{shape_name}::{think_label}"
                try:
                    t0 = time.time()
                    write = _call_and_diff(
                        model=model_node, system_prompt=system_prompt,
                        user_prompt=_USER_MSG_A, thinking_budget=budget,
                        phase_label=f"{label_base}::A")
                    read = _call_and_diff(
                        model=model_node, system_prompt=system_prompt,
                        user_prompt=_USER_MSG_B, thinking_budget=budget,
                        phase_label=f"{label_base}::B")
                    elapsed = time.time() - t0
                except Exception as e:  # noqa: BLE001 — report and keep probing
                    console.status_row(
                        measured, "fail", via, model_id, shape_name, "—", "", "", "",
                        f"FAILED (thinking={think_label}): {type(e).__name__}: "
                        f"{redact(str(e))[:200]}")
                    ok = False
                    continue
                if elapsed > _CALL_B_DEADLINE_S:
                    log.warning(Event.PREFLIGHT_CACHE_PROBE_SLOW, via=via, model=model_id,
                                filler=shape_name, thinking=think_label, elapsed=f"{elapsed:.1f}s",
                                target=f"{_CALL_B_DEADLINE_S:.0f}s")
                thinking_sent = _thinking_actually_sent(model_id, budget)
                usage_a, usage_b = usage_dict_for_classifier(
                    cache_write=write["cache_write"],
                    cache_read=read["cache_read"],
                    write_present=write["cache_write_present"],
                    read_present=read["cache_read_present"])
                verdict = classify_cache_verdict(usage_a, usage_b)
                if (verdict == V_ANTHROPIC_NOT_HONOURED
                        and _marker_would_be_placed(
                            via, system_prompt, model_id) is False):
                    # Only a definite False (never None) moves blame off the gateway to our own gate
                    verdict = V_MARKER_WITHHELD
                rows.append({
                    "model_id": model_id, "via": via, "filler": shape_name,
                    "thinking_requested": think_label, "thinking_sent": thinking_sent,
                    "base_url": base_url, "cache_creation": write["cache_write"],
                    "cache_read": read["cache_read"], "verdict": verdict,
                })
                console.status_row(
                    measured, "ok", via, model_id, shape_name,
                    "yes" if thinking_sent else "no", base_url,
                    write["cache_write"], read["cache_read"], verdict)

    for (model_id, via), model_node in sorted(deepagents_targets.items()):
        provider = getattr(model_node, "provider", None)
        base_url = _deepagents_base_url(cfg, model_id, provider)
        label_base = f"cache_probe::{model_id}::{via}::synthetic::off"
        try:
            t0 = time.time()
            write, read = _probe_deepagents_cache(cfg, model_node,
                                                  label_base=label_base)
            elapsed = time.time() - t0
        except Exception as e:  # noqa: BLE001 — report and keep probing
            console.status_row(
                measured, "fail", via, model_id, "synthetic", "—", "", "", "",
                f"FAILED: {type(e).__name__}: {redact(str(e))[:200]}")
            ok = False
            continue
        if elapsed > _CALL_B_DEADLINE_S:
            # Expected on this route: graph build dominates the first call.
            log.warning(Event.PREFLIGHT_CACHE_PROBE_SLOW, via=via, model=model_id,
                        filler="synthetic", elapsed=f"{elapsed:.1f}s",
                        target=f"{_CALL_B_DEADLINE_S:.0f}s")
        usage_a, usage_b = usage_dict_for_classifier(
            cache_write=write["cache_write"],
            cache_read=read["cache_read"],
            write_present=write["cache_write_present"],
            read_present=read["cache_read_present"])
        verdict = classify_cache_verdict(usage_a, usage_b)
        if (verdict == V_ANTHROPIC_NOT_HONOURED
                and not _deepagents_marker_would_be_placed(cfg, model_id, provider)):
            # Same as the prompt arm: only our own gate may move blame off the gateway
            verdict = V_MARKER_WITHHELD
        rows.append({
            "model_id": model_id, "via": via, "filler": "synthetic",
            "thinking_requested": "off", "thinking_sent": False,
            "base_url": base_url, "cache_creation": write["cache_write"],
            "cache_read": read["cache_read"], "verdict": verdict,
        })
        console.status_row(
            measured, "ok", via, model_id, "synthetic", "no", base_url,
            write["cache_write"], read["cache_read"], verdict)

    console.console().print(measured)
    console.write("\n  [cache-probe] verdicts:")
    for r in rows:
        console.write(f"    {r['model_id']} / via={r['via']} / filler={r['filler']} / "
                      f"thinking_requested={r['thinking_requested']}: "
                      f"{_VERDICT_TEXT[r['verdict']]}")
    if not rows:
        console.write("    (no successful calls — see the FAILED rows above)")
    return ok
