# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


from __future__ import annotations
from vvaharness.util import logs

"""Checkpoint/resume key derivation and JSON-backed storage in the SQLite state store."""
import hashlib
import json
from collections.abc import Iterable, Mapping
from pathlib import Path

from pydantic import TypeAdapter, ValidationError
from typing import Literal
from typing_extensions import NotRequired, TypedDict

from vvaharness.models import (
    ContextPackage,
    DroppedFinding,
    FinalReport,
    Finding,
    TaskManifest,
    ThreatModel,
)
from vvaharness.models.scan import SeedPackage
from vvaharness.orchestrator import store
from vvaharness.util import console
from vvaharness.util.events import Event

log = logs.get_logger(__name__)


# TypeAdapter both serialises (dump_json) and validates on load (validate_json), rejecting a tampered value instead of smuggling it into the pipeline.
class _S4Ckpt(TypedDict):
    findings: list[Finding]
    outcomes: dict[str, str]
    input_kind: NotRequired[Literal["deepdive", "external"]]


def s4_input_kind(checkpoint: dict) -> str:
    if "input_kind" in checkpoint:
        return checkpoint["input_kind"]
    findings = checkpoint.get("findings", [])
    outcomes = checkpoint.get("outcomes", {})
    origins = {str(getattr(finding, "origin", None) or "external") for finding in findings}
    if findings and outcomes == dict.fromkeys(origins, "confirmed"):
        return "external"
    return "deepdive"


#: Per-unit outcomes meaning no trustworthy result — "guardrail"/"skipped" are excluded since they're deterministic for a given config, so retrying them on --resume alone wouldn't heal them.
_S4_UNTRUSTED_OUTCOMES = frozenset({"error", "halted", "uninvestigated", "failed"})


def s4_stage_complete(checkpoint: dict) -> bool:
    """Whether an S4 checkpoint has no unit left in an unresolved failure state; False means --resume must not reuse it."""
    outcomes = checkpoint.get("outcomes", {})
    return not any(outcome in _S4_UNTRUSTED_OUTCOMES for outcome in outcomes.values())


class _S5Ckpt(TypedDict):
    findings: list[Finding]
    pre_dropped: list[DroppedFinding]


class _S6Ckpt(TypedDict):
    verified: list[Finding]
    dropped: list[DroppedFinding]


# 6-tuple current (trailing int = post-s5 count for --resume); 5-tuple stays for scan.py legacy arm
_S7Ckpt = (
    tuple[list[DroppedFinding],   # pre_dropped
         list[Finding],          # verified
         list[DroppedFinding],   # dropped
         list[Finding],          # canonical
         list[DroppedFinding],   # dup_dropped
         int]                    # s5_out_count
    | tuple[list[DroppedFinding], list[Finding], list[DroppedFinding],
           list[Finding], list[DroppedFinding]]
)


#: Step key holding the scanned tree's git HEAD at scan start; identifies the TARGET, not a stage.
REPO_IDENTITY_STEP = "repo_identity"


class StageProvenance(TypedDict):
    """The model/via/config a detection stage's checkpoint was ACTUALLY produced
    under, plus that stage's own token bucket.

    Checkpoints are keyed ``(run_id, step)`` with no model/via/config column
    (``store.py``'s ``checkpoints`` table), so resuming stage N under a
    DIFFERENT ``--config`` than produced it left the manifest attributing N's
    model/tokens to whatever the CURRENT config's role_models/TOKENS say —
    misattributing route and dropping the original spend. Saved as a SECOND
    checkpoint row per stage (``<step>_prov``, via ``save_ckpt``/``load_ckpt``
    themselves — same pattern as :data:`REPO_IDENTITY_STEP`, no new storage
    mechanism and no ``store.py`` schema change) so a cached stage's manifest
    row can report the truth it was actually computed under. A stage with no
    ``_prov`` row (written before this existed) has no envelope to read and
    falls back to today's behaviour — see ``load_stage_provenance``.
    """

    model: str | None
    via: str | None
    config_sha256: str | None
    tokens: dict[str, int | float | None]


#: Provenance-envelope row suffix (``"s2_prov"``); NOT a ``_DYNAMIC_PREFIXES`` family, an extra row
_PROVENANCE_SUFFIX = "_prov"

_PROVENANCE_SCHEMA: TypeAdapter = TypeAdapter(StageProvenance)


def _provenance_step(step: str) -> str:
    return f"{step}{_PROVENANCE_SUFFIX}"


_STEP_SCHEMA: dict[str, TypeAdapter] = {
    # s0 is a plain @dataclass; TypeAdapter serialises/rebuilds it too, Path field included.
    "s0": TypeAdapter(SeedPackage),
    "s1": TypeAdapter(ContextPackage),
    "s2": TypeAdapter(ThreatModel),
    "s3": TypeAdapter(TaskManifest),
    "s4": TypeAdapter(_S4Ckpt),
    "s5": TypeAdapter(_S5Ckpt),
    "s6": TypeAdapter(_S6Ckpt),
    "s7": TypeAdapter(_S7Ckpt),
    "s8": TypeAdapter(FinalReport),
    "s9": TypeAdapter(str),
    # Not a pipeline stage: records that the S9 artifacts were uploaded, so --resume never re-uploads.
    "ingest": TypeAdapter(bool),
    # Not a stage: git HEAD at start; run_id keys on PATH alone, so a re-clone publishes stale rows
    REPO_IDENTITY_STEP: TypeAdapter(str),
}

# Step 10 checkpoints one dict per finding under a dynamic remediate_<digest> key, so it can't live in the fixed table above.
_REMEDIATE_STEP_SCHEMA: TypeAdapter = TypeAdapter(dict)

#: The two dynamic step families; the prefix stays in plaintext so ``_schema_for`` can sniff it after the rest is hashed.
REMEDIATE_PREFIX = "remediate_"
VALIDATE_PREFIX = "validate_"

_DYNAMIC_PREFIXES: tuple[str, ...] = (REMEDIATE_PREFIX, VALIDATE_PREFIX)

#: 96 bits of digest; names a checkpoint row, not a directory, so it only needs collision-freedom within one run's finding set.
_STEP_DIGEST_CHARS = 24

# Built lazily: ValidationResult lives in vvaharness.validation, which already imports this package, so a module-level import here would cycle.
_VALIDATE_STEP_SCHEMA: TypeAdapter | None = None


def _validate_schema() -> TypeAdapter:
    """Lazily build and cache the TypeAdapter for ``validate_<id>`` checkpoint steps."""
    global _VALIDATE_STEP_SCHEMA
    if _VALIDATE_STEP_SCHEMA is None:
        from vvaharness.validation.models import ValidationResult
        _VALIDATE_STEP_SCHEMA = TypeAdapter(ValidationResult)
    return _VALIDATE_STEP_SCHEMA


#: Normalized EV collection; --resume needs no ``EV_API_COLLECTION`` (set, it wins); named: S6 input
EV_COLLECTION_STEP = "ev_collection"

_EV_COLLECTION_SCHEMA: TypeAdapter | None = None


def _ev_collection_schema() -> TypeAdapter:
    """Lazily build and cache the TypeAdapter for the ``ev_collection`` step."""
    global _EV_COLLECTION_SCHEMA
    if _EV_COLLECTION_SCHEMA is None:
        from vvaharness.exploit_verification.collection.model import (
            NormalizedCollection,
        )
        _EV_COLLECTION_SCHEMA = TypeAdapter(NormalizedCollection)
    return _EV_COLLECTION_SCHEMA


def _schema_for(step: str) -> TypeAdapter:
    """Resolve the TypeAdapter for a checkpoint step, fixed or dynamic."""
    if step in _STEP_SCHEMA:
        return _STEP_SCHEMA[step]
    if (step.endswith(_PROVENANCE_SUFFIX)
            and step[: -len(_PROVENANCE_SUFFIX)] in _STEP_SCHEMA):
        return _PROVENANCE_SCHEMA
    if step == EV_COLLECTION_STEP:
        return _ev_collection_schema()
    if step.startswith(REMEDIATE_PREFIX):
        return _REMEDIATE_STEP_SCHEMA
    if step.startswith(VALIDATE_PREFIX):
        return _validate_schema()
    return _STEP_SCHEMA[step]   # unknown step → KeyError (caller bug, fail loud)


def step_key_for(prefix: str, *, engine_id: str, engine_version: str,
                 case_id: str, model: str = "", backend: str = "") -> str:
    """Build the dynamic checkpoint step key for one case under one engine, so ``--resume`` cannot republish another producer's result as this run's."""
    if prefix not in _DYNAMIC_PREFIXES:
        msg = (f"unknown dynamic checkpoint prefix {prefix!r}; expected one of "
               f"{_DYNAMIC_PREFIXES} so _schema_for can still route the key")
        raise ValueError(msg)
    material = "\n".join((engine_id, engine_version, case_id, model, backend)).encode()
    return prefix + hashlib.sha256(material).hexdigest()[:_STEP_DIGEST_CHARS]


# One prune per (run_id, prefix) per process: the standalone remediate/validate commands never call reset_run, so without this their rows accumulate forever.
_PRUNED: set[tuple[str, str]] = set()


def prune_stale_steps(run_id: str, prefix: str, live_keys: Iterable[str]) -> list[str]:
    """Delete this run's *prefix* rows that no live case claims, at most once per ``(run_id, prefix)`` per process. Returns the keys removed."""
    once = (run_id, prefix)
    if once in _PRUNED:
        return []
    _PRUNED.add(once)
    removed = store.delete_steps(run_id, prefix, set(live_keys))
    if removed:
        console.write(f"  [ckpt] pruned {len(removed)} stale {prefix}* checkpoint row(s) "
                      f"for {run_id[:12]}… — written by an earlier engine or finding set")
    return removed


# Oversized payload is corruption or a resource-exhaustion attempt; enforced here AND by a CHECK constraint on checkpoints.size so a direct INSERT can't bypass it.
_CKPT_MAX_BYTES = 100 * 1024 * 1024


def save_ckpt(ckpt_dir: Path, run_id: str, step: str, obj) -> None:
    """Persist ``obj`` for ``(run_id, step)`` to the SQLite state store; ``ckpt_dir`` is kept only for call-site compatibility."""
    del ckpt_dir
    blob = _schema_for(step).dump_json(obj)  # JSON, never pickle — avoids CWE-502 RCE on a hostile checkpoint
    if len(blob) > _CKPT_MAX_BYTES:
        log.warning(Event.CKPT_TOO_LARGE, step=step, size=len(blob), cap=_CKPT_MAX_BYTES)
        return
    con = store.connect()
    try:
        with con:   # one transaction == atomic
            # Ensure a parent runs row exists even when register_run() was skipped (tests, ad-hoc callers), so the FK + ON DELETE CASCADE hold.
            con.execute("INSERT OR IGNORE INTO runs(run_id, repo_root) "
                        "VALUES (?, '')", (run_id,))
            con.execute("UPDATE runs SET updated_at = datetime('now') "
                        "WHERE run_id = ?", (run_id,))
            con.execute(
                "INSERT OR REPLACE INTO checkpoints"
                "(run_id, step, payload, size) VALUES (?, ?, ?, ?)",
                (run_id, step, blob, len(blob)),
            )
    finally:
        con.close()
    console.write(f"  [ckpt] saved {step}")


def load_ckpt(ckpt_dir: Path, run_id: str, step: str):
    """Return the rehydrated checkpoint for ``(run_id, step)``, or ``None`` if absent, oversized, or schema-invalid — the caller re-runs the step."""
    del ckpt_dir
    con = store.connect()
    try:
        row = con.execute(
            "SELECT payload, size FROM checkpoints WHERE run_id=? AND step=?",
            (run_id, step),
        ).fetchone()
    finally:
        con.close()
    if row is None:
        if step == "s1":
            console.write(f"  [ckpt] no checkpoints for {run_id[:12]}… in "
                          f"{store.db_path()} — if you expected resume, check "
                          f"$VVAHARNESS_STATE_DIR")
        return None
    payload, size = row
    if size > _CKPT_MAX_BYTES:   # belt-and-braces; CHECK already enforces
        log.warning(Event.CKPT_STORED_TOO_LARGE, step=step, cap=_CKPT_MAX_BYTES)
        return None
    try:
        obj = _schema_for(step).validate_json(payload)
    except (ValidationError, ValueError) as e:
        # Both branches re-run the step; the only distinction the bytes support is "valid JSON?".
        try:
            json.loads(payload)
        except (ValueError, TypeError):
            # Not even well-formed JSON: truncated, corrupt, or a substituted non-checkpoint blob.
            log.warning(Event.CKPT_UNREADABLE, step=step, detail=str(e))
        else:
            # Well-formed JSON failing the schema is usually a different tool version, not tampering.
            log.warning(Event.CKPT_SCHEMA_MISMATCH, step=step, detail=str(e))
        return None
    console.write(f"  [ckpt] resumed {step} from db")
    return obj


def save_stage_provenance(ckpt_dir: Path, run_id: str, step: str, *,
                          model: str | None, via: str | None,
                          config_sha256: str | None,
                          tokens: Mapping[str, object]) -> None:
    """Save *step*'s :class:`StageProvenance` envelope alongside its normal checkpoint row — a second ``sav..."""
    save_ckpt(ckpt_dir, run_id, _provenance_step(step), StageProvenance(
        model=model, via=via, config_sha256=config_sha256,
        tokens=dict(tokens)))


def load_stage_provenance(ckpt_dir: Path, run_id: str, step: str) -> StageProvenance | None:
    """Load *step*'s provenance envelope, or ``None`` when absent — either it was never saved (a legacy checkpoi..."""
    return load_ckpt(ckpt_dir, run_id, _provenance_step(step))


def run_id_for(repo: str | Path) -> str:
    """Stable, non-reversible SHA-256 run id per repo path, so the checkpoint filename leaks nothing about the host's directory layout."""
    return hashlib.sha256(str(Path(repo).resolve()).encode()).hexdigest()[:32]


def prune_checkpoints(*, keep_runs: int = 100, max_age_days: int = 5,
                      dry_run: bool = False) -> dict:
    """Delete ``runs`` rows (and their checkpoints, via ON DELETE CASCADE) and code-graph workspaces older than ``max_age_days`` or beyond the ``keep_runs`` most-recent; ``dry_run`` reports without touching anything."""
    # No DB = nothing to prune, BOTH modes: `store.connect()` would CREATE it, `db_location()` won't
    db = store.db_location()
    if not db.exists():
        return {"root": str(db), "kept": 0, "deleted": []}
    con = store.connect()
    try:
        total = con.execute("SELECT COUNT(*) FROM runs").fetchone()[0]
        victims = [r[0] for r in con.execute(
            """SELECT run_id FROM runs
               WHERE updated_at < datetime('now', ?)
                  OR run_id NOT IN (
                       SELECT run_id FROM runs
                       ORDER BY updated_at DESC LIMIT ?)
               ORDER BY updated_at""",
            (f"-{max_age_days} days", keep_runs),
        )]
        if not dry_run and victims:
            with con:
                con.executemany("DELETE FROM runs WHERE run_id = ?",
                                [(v,) for v in victims])
            # Truncate the -wal file too, or it can sit at the high-water-mark of the largest deleted blob.
            # incremental_vacuum frees one page per fetched row: unfetched, it frees one page
            con.execute("PRAGMA incremental_vacuum").fetchall()
            con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            for v in victims:
                store.delete_run_graphs(v)
    finally:
        con.close()
    # `db`, not `db_path()`: re-resolving would run the state-dir mode check and creation again.
    return {"root": str(db),
            "kept": total - len(victims), "deleted": victims}
