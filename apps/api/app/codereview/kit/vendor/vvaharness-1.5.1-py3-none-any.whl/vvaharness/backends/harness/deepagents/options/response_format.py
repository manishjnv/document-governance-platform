# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Structured-output strategy selection: schema construction and per-provider overrides."""

from __future__ import annotations

from typing import Any

from langchain.agents.structured_output import ToolStrategy
from pydantic import BaseModel, Field, create_model

from vvaharness.backends.harness.deepagents.options.model_building import (
    _FORCED_TOOL_CHOICE_UNSUPPORTED_MODELS,
)
from vvaharness.backends.harness.models import OneShotOptions
from vvaharness.backends.harness.provider_routing import routes_to_anthropic
from vvaharness.backends.llm.models import with_submit_instruction
from vvaharness.util.counters import COUNTERS
from vvaharness.util.warn_once import warn_once

_WARNED_DROPS: set[str] = set()
_WARNED_UNSUPPORTED: set[str] = set()


def _pydantic_response_format(schema: dict[str, Any]) -> type[BaseModel]:
    """Build an anonymous Pydantic model suitable for ToolStrategy."""
    type_map: dict[str, type] = {
        "string": str,
        "integer": int,
        "number": float,
        "boolean": bool,
        "array": list,
        "object": dict,
    }
    required = set(schema.get("required", ()))
    fields: dict[str, tuple[type, Any]] = {}
    for name, prop in schema.get("properties", {}).items():
        base = type_map.get(prop.get("type"), str)
        default = Field(...) if name in required else Field(default=None)
        fields[name] = (base, default)
    return create_model("HarnessResponse", **fields)  # type: ignore[arg-type]


def _strategy_for(schema: type, model_id: str, provider: str | None) -> ToolStrategy | type:
    """Force tool-calling on Anthropic unless the model rejects it; else the bare schema."""
    if (routes_to_anthropic(model_id, provider)
            and model_id not in _FORCED_TOOL_CHOICE_UNSUPPORTED_MODELS):
        return ToolStrategy(schema=schema)
    return schema


def forcing_dropped_under_thinking(model: object, response_format: object) -> bool:
    """True when langchain-anthropic will silently drop this build's forced ``tool_choice``.

    ``ChatAnthropic.bind_tools`` deletes a forced ``any``/``tool`` choice whenever
    ``self.thinking.type`` is ``enabled``/``adaptive`` — client-side, before the request, on
    every effort-bearing Anthropic call, not just a particular tier. Reading ``model.thinking``
    (what langchain itself consults) rather than re-deriving from an effort string tracks
    whatever `build_model` actually set; a non-Anthropic model has no such attribute.
    """
    if not isinstance(response_format, ToolStrategy):
        return False
    thinking = getattr(model, "thinking", None) or {}
    return thinking.get("type") in ("enabled", "adaptive")


def _model_tag(model: object) -> str:
    """A model identifier for the WARN line, duck-typed like `forcing_dropped_under_thinking`."""
    return str(getattr(model, "model", None) or getattr(model, "model_name", None) or "unknown")


def _warn_tool_choice_dropped(model: object) -> None:
    """Name, once per model, that manual thinking cost deepagents a forced tool_choice.

    Mirrors `sdk._warn_tool_choice_dropped_for_thinking`: that route's equivalent drop already
    prints this once per model; this hook had the counter with no console line.
    """
    tag = _model_tag(model)
    warn_once(
        _WARNED_DROPS, tag,
        f"WARN [deepagents]: {tag} has manual (`enabled`) thinking, so langchain drops the "
        "forced tool_choice for this build's structured output -- the session falls back to "
        "a textual submit instruction in the system prompt instead of a forced tool call. "
        "The structured-output tool is still advertised and validated when called; a reply "
        "that skips it is re-asked in-session by the stage's own evidence or plan gate, not "
        "by this hook.")


def _forcing_unsupported(model: object) -> bool:
    """True when this model is known (seeded, or learned this process) to reject forcing."""
    return _model_tag(model) in _FORCED_TOOL_CHOICE_UNSUPPORTED_MODELS


def _warn_tool_choice_unsupported(model: object) -> None:
    """Name, once per model, that it is not sent a forced tool_choice."""
    tag = _model_tag(model)
    warn_once(
        _WARNED_UNSUPPORTED, tag,
        f"WARN [deepagents]: {tag} rejects a forced tool_choice (\"tool\"/\"any\") with a 400 "
        "on this gateway, so for the rest of this process it gets the bare response schema "
        "(langchain then uses the provider's native structured output where the model "
        "supports it) plus a textual submit instruction in the system prompt, instead of a "
        "forced tool call. A reply that skips the outcome is re-asked in-session by the "
        "stage's own evidence or plan gate, not by this hook.")


def _tool_name_for(response_model: type) -> str:
    """The tool name `ToolStrategy` would use for *response_model*, even if downgraded to bare."""
    return ToolStrategy(schema=response_model).schema_specs[0].name


def submit_instructed_prompt(
    system_prompt: str | None, model: object, response_model: type | None,
    response_format: object,
) -> str | None:
    """*system_prompt*, with the submit instruction appended when forcing is dropped.

    Forcing is dropped client-side under manual thinking, or server-side as a learned rejection.
    """
    if response_model is None:
        return system_prompt
    if forcing_dropped_under_thinking(model, response_format):
        COUNTERS.bump("deepagents_tool_choice_dropped")
        _warn_tool_choice_dropped(model)
    elif _forcing_unsupported(model):
        COUNTERS.bump("deepagents_tool_choice_unsupported")
        _warn_tool_choice_unsupported(model)
    else:
        return system_prompt
    tool_name = _tool_name_for(response_model)
    return with_submit_instruction(system_prompt, response_model, tool_name=tool_name)


def _response_format(
    response_model: type | None, model_id: str, provider: str | None,
) -> ToolStrategy | type | None:
    """Wrap an injected Pydantic model class as a strategy (None when unset)."""
    if response_model is None:
        return None
    return _strategy_for(response_model, model_id, provider)


def _oneshot_response_format(
    options: OneShotOptions,
) -> ToolStrategy | type | None:
    """Prefer an injected Pydantic model; else derive one from a JSON output schema."""
    if options.response_model is not None:
        return _strategy_for(options.response_model, options.model, options.model_provider)
    if options.output_schema is not None:
        derived = _pydantic_response_format(dict(options.output_schema))
        return _strategy_for(derived, options.model, options.model_provider)
    return None
