# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Auto-derive a per-target step1 exclusion overlay from a deterministic repo survey."""
from __future__ import annotations
from vvaharness.util import logs

import os
import re
from collections import Counter
from pathlib import Path, PurePosixPath

import yaml

# Module import keeps the monkeypatch seam for tests.
from vvaharness.backends.llm import deepagents as _deepagents
from vvaharness.backends.llm.models import refusal_resend_allowed
from vvaharness.detect.matcher import compile_detectors, detector_hits
from vvaharness.detect.patterns import detector_corpus
from vvaharness.lang.detect import EXT_TO_LANG, is_web_template
from vvaharness.pipeline.stages.s5.enrich import FileCache
from vvaharness.report.redact import redact, redact_counts
from vvaharness.scope import (
    _DEDUP_DEFAULTS,
    _exclusion_sets,
    glob_hit,
    scope_after,
)
from vvaharness.util import console
from vvaharness.util import errlog as _errlog
from vvaharness.util.config import knob
from vvaharness.util.counters import COUNTERS
from vvaharness.util.response_quality import dispatch_or_retry_unforced, stage_floors
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

_SYSTEM = """You are a build/scan triage agent. You will be shown a deterministic survey of
a source tree (directory layout, file counts, extension histogram, and excerpts
from build/README files). Decide which parts are NOT production code so a
security scanner can skip them.

EXCLUDE these categories:
- Generated/auto-generated code: protobuf stubs, OpenAPI clients, code-gen
  output, compiled assets, *.pb.go, *.generated.*, *_pb2.py
- Vendored/third-party copies: vendor/, third_party/, node_modules/ (if checked
  in), bower_components/, external/
- Test-only trees: test fixtures, sample data, mock servers, e2e test suites,
  cypress/fixtures, __snapshots__
- IDE/editor metadata: .idea/, .vscode/ (except shared settings), .vs/,
  *.swp, *~
- Build/CI output: dist/, build/, out/, target/, bin/ (compiled output),
  .cache/, coverage/
- Documentation-only trees: docs/, documentation/, wiki/, man/, guides/
- Demo/example apps: examples/, samples/, demo/, playground/, tutorial/
- Data dumps: fixtures with large data files, seed data, database backups
  (NOT migration scripts — those are NEVER EXCLUDE, below)
- Localisation bundles: locale/, i18n/, l10n/, translations/ (unless they
  contain code)
- Lock files and manifests that are not source: package-lock.json, yarn.lock,
  Gemfile.lock, poetry.lock, go.sum, Cargo.lock

NEVER EXCLUDE — these are in scope even if they look non-functional:
- Application source code in ANY language
- Configuration files that affect runtime behavior (nginx.conf, app.yaml,
  settings.py, application.properties, .env.example)
- Infrastructure-as-code that provisions production (Terraform, CloudFormation,
  Helm charts, Kubernetes manifests, Ansible playbooks, Dockerfiles)
- Database migration scripts (they modify production schema)
- API schema definitions (OpenAPI/Swagger YAML, GraphQL SDL, protobuf .proto
  source files — NOT generated stubs)
- Security-related files (auth middleware, RBAC config, certificate handling)
- Shared libraries or internal packages (even if they look like vendor code,
  if they are maintained in this repo they are production)
- Server-side template directories (Django/Jinja/ERB/JSP templates —
  .html/.j2/.erb files rendered by the app are XSS/SSTI attack surface, even
  in dirs named template/, templates/, views/, static/)

When unsure whether something is production code, do NOT exclude it. A false
negative (scanning non-production code) wastes time; a false positive
(excluding production code) misses vulnerabilities.

You MUST reply with a single fenced ```yaml block and nothing else."""


# Build/manifest names whose head helps the model tell prod from demo.
_EXCERPT_NAMES = re.compile(
    r"^(readme(\..*)?|package\.json|pom\.xml|build\.gradle(\.kts)?|"
    r"setup\.(py|cfg)|pyproject\.toml|cargo\.toml|go\.mod|makefile|"
    r"dockerfile|composer\.json|gemfile|.*\.csproj|.*\.sln|angular\.json|"
    r"lerna\.json|nx\.json|turbo\.json)$",
    re.IGNORECASE,
)
_EXCERPT_CHARS = 1500
_EXCERPT_MAX = 12
_TREE_DEPTH = 2
_TREE_MAX_CHILDREN = 60
_EXT_TOP_N = 40
_LARGEST_N = 15

_DEDUP_KEYS = {"enabled": bool, "exts": list, "min_cluster_size": int,
               "keep_per_top_dir": bool, "promote_on_secret_hit": bool,
               "promote_on_insecure_value": bool, "max_file_kb": int}

# 40/10 not global 150/30: a valid overlay can be a few dozen tokens and 3 false trips drop it; a degenerate reply is under 10
_MIN_RESPONSE_CHARS = 40
_MIN_RESPONSE_TOKENS = 10
_TAG = "s1 autoexclude"

# Reporting threshold only, never a rejection bar.
_AGGRESSIVE_KEEP_RATIO = 0.10


def _survey(repo_root: Path, base_dirs: set[str], base_exts: set[str],
            base_globs: list[str]) -> tuple[str, int]:
    """Return the rendered survey blocks and the file count that survives the current exclusions."""
    def globbed(rel: str) -> bool:
        # Shared helper, so the survey can't disagree with what s1 excludes.
        return glob_hit(rel, base_globs) is not None

    # rel-posix-dir → (subdirs:set[str], file_count:int, depth:int)
    tree: dict[str, list] = {"": [set(), 0, 0]}
    ext_hist: Counter[str] = Counter()
    excerpts: list[tuple[str, str]] = []
    largest: list[tuple[int, str]] = []
    n_files = 0
    root_resolved = Path(repo_root).resolve()

    for dirpath, dirnames, filenames in os.walk(repo_root):
        rel_dir = str(PurePosixPath(Path(dirpath).relative_to(repo_root)))
        rel_dir = "" if rel_dir == "." else rel_dir
        depth = 0 if not rel_dir else rel_dir.count("/") + 1
        dirnames[:] = sorted(
            d for d in dirnames
            if d.lower() not in base_dirs
            and not globbed(f"{rel_dir}/{d}" if rel_dir else d)
        )
        if depth <= _TREE_DEPTH:
            node = tree.setdefault(rel_dir, [set(), 0, depth])
            node[0].update(dirnames)
        for fn in filenames:
            rel = f"{rel_dir}/{fn}" if rel_dir else fn
            # Mirror _walk_repo exactly (suffix OR full-name endswith) so counts match the walk
            name = fn.lower()
            suffix = Path(fn).suffix.lower()
            if any(suffix == e or name.endswith(e) for e in base_exts) or globbed(rel):
                continue
            ext = suffix or "(none)"
            n_files += 1
            ext_hist[ext] += 1
            try:
                sz = (Path(dirpath) / fn).stat().st_size
            except OSError:
                sz = 0
            if len(largest) < _LARGEST_N or sz > largest[-1][0]:
                largest.append((sz, rel))
                largest.sort(reverse=True)
                del largest[_LARGEST_N:]
            anc = rel_dir
            while True:
                if anc in tree:
                    tree[anc][1] += 1
                if not anc:
                    break
                anc = anc.rpartition("/")[0]
            if (depth <= _TREE_DEPTH and len(excerpts) < _EXCERPT_MAX
                    and sz <= 5_000_000 and _EXCERPT_NAMES.match(fn)):
                # Size cap: no multi-GB README in memory; int compare short-circuits the regex
                fp = Path(dirpath) / fn
                # A symlink out of the repo would embed off-host content in the prompt
                if fp.is_symlink():
                    try:
                        if not fp.resolve(strict=False).is_relative_to(
                                root_resolved):
                            continue
                    except OSError:
                        continue
                try:
                    txt = fp.read_text(
                        encoding="utf-8", errors="replace")[:_EXCERPT_CHARS]
                    excerpts.append((rel, txt.rstrip()))
                except OSError:
                    pass

    def render_tree() -> str:
        lines = [f"./    ({tree[''][1]} files)"]
        for rel, (subs, cnt, depth) in sorted(tree.items()):
            if not rel:
                continue
            indent = "  " * depth
            lines.append(f"{indent}{PurePosixPath(rel).name}/    ({cnt} files)")
            if depth == _TREE_DEPTH and subs:
                kids = sorted(subs)
                shown = kids[:_TREE_MAX_CHILDREN]
                lines.extend(f"{indent}  {k}/" for k in shown)
                if len(kids) > _TREE_MAX_CHILDREN:
                    lines.append(f"{indent}  … (+{len(kids) - _TREE_MAX_CHILDREN} more)")
        return "\n".join(lines)

    ext_block = "\n".join(
        f"  {ext:<16} {n:>7}" for ext, n in ext_hist.most_common(_EXT_TOP_N)
    ) or "  (none)"
    if len(ext_hist) > _EXT_TOP_N:
        ext_block += f"\n  … (+{len(ext_hist) - _EXT_TOP_N} more extensions)"

    exc_block = "\n\n".join(
        f"### {rel}\n```\n{txt}\n```" for rel, txt in excerpts
    ) or "(no README/build files found at depth ≤2)"

    large_block = "\n".join(
        f"  {sz / 1024:8.1f} KB  {rel}" for sz, rel in largest
    ) or "  (none)"

    survey = (
        f"## Directory tree (depth ≤{_TREE_DEPTH + 1}, already-excluded dirs hidden, "
        f"counts = files that survive current exclusions)\n"
        f"```\n{render_tree()}\n```\n\n"
        f"## Extension histogram (top {_EXT_TOP_N})\n"
        f"```\n{ext_block}\n```\n\n"
        f"## Largest {_LARGEST_N} files (after current exclusions)\n"
        f"```\n{large_block}\n```\n\n"
        f"## Build / README excerpts\n{exc_block}"
    )
    return survey, n_files


# Every fenced block, labelled or not; \Z closes on EOT so a truncated block still yields its YAML
_FENCE_RX = re.compile(r"```(?P<lang>[A-Za-z0-9_+.-]*)[^\S\n]*\n(?P<body>.*?)(?:\n```|\Z)",
                       re.DOTALL)

#: The keys run() consumes; picks the right fenced block when a reply carries several
_OVERLAY_KEYS = frozenset({"exclude_dirs", "exclude_exts", "exclude_globs",
                           "max_file_kb", "config_dedup"})


def _yaml_candidates(text: str) -> list[str]:
    """Plausible YAML payloads in a model reply, best-first: yaml-labelled fences, unlabelled, other labels, then the whole reply."""
    blocks = [(m.group("lang").lower(), m.group("body"))
              for m in _FENCE_RX.finditer(text)]
    labelled = [b for lang, b in blocks if lang in ("yaml", "yml")]
    unlabelled = [b for lang, b in blocks if not lang]
    other = [b for lang, b in blocks if lang and lang not in ("yaml", "yml")]
    return [*labelled, *unlabelled, *other, text]


def _extract_yaml(text: str) -> dict:
    """The step1 overlay mapping a model reply proposes, or ``{}``; never raises, since run() must always write an overlay."""
    first_dict: dict | None = None
    parsed_any = False
    err: yaml.YAMLError | None = None
    for blob in _yaml_candidates(text):
        try:
            data = yaml.safe_load(blob) or {}
        except yaml.YAMLError as e:
            err = err or e
            continue
        parsed_any = True
        if not isinstance(data, dict):
            continue
        if set(data) == {"step1"} and isinstance(data["step1"], dict):
            data = data["step1"]
        if not isinstance(data, dict):
            continue
        if _OVERLAY_KEYS & set(data):
            return data                     # a real proposal — take this block
        if first_dict is None:
            first_dict = data               # parses, proposes nothing we read
    if first_dict is not None:
        return first_dict
    if not parsed_any and err is not None:
        # redact the FULL str(e) before [:200]: slicing first can bisect a secret past redaction
        log.warning(Event.S1_MODEL_YAML_UNPARSEABLE, detail=redact(str(err))[:200])
    return {}


# Repo-wide glob over a single bare extension: "**/*.pug" or "*.pug".
_BARE_LANG_GLOB = re.compile(r"^(?:\*\*/)?\*(\.[A-Za-z0-9_]+)$")


def _erases_language(entry: str) -> str | None:
    """Return the EXT_TO_LANG extension *entry* would erase from scope, else None."""
    m = _BARE_LANG_GLOB.match(entry)
    if m:
        ext = m.group(1).lower()
    elif re.fullmatch(r"\.[A-Za-z0-9_]+", entry):
        ext = entry.lower()
    else:
        return None
    return ext if ext in EXT_TO_LANG else None


#: A template under one of these is generated output, not app surface; bare names already excluded
_VENDOR_PATH_SEGMENTS = frozenset({
    "dist", "build", "out", "output", "target", "coverage",
    "vendor", "vendored", "third_party", "thirdparty", "external",
    "node_modules", "bower_components", "jspm_packages", "site-packages",
    ".next", ".nuxt", "_site", "__snapshots__",
})


def _is_vendor_or_build_entry(entry: str) -> bool:
    """Whether *entry* names vendored/built/minified output rather than app source."""
    # Vetoes exempt these: one bundled index.html else makes frontend/dist/** unexcludable
    low = entry.lower()
    if ".min." in low:
        return True
    parts = [p for p in re.split(r"[\\/]+", low) if p not in ("", "*", "**")]
    return any(p in _VENDOR_PATH_SEGMENTS for p in parts)


def _template_files(inventory: list[str]) -> list[str]:
    """The server-side templates in *inventory*, classified once rather than per vetoed entry."""
    return [rel for rel in inventory if is_web_template(rel)]


#: Naming convention only; content scanning is scope/walk.py _SECRET_RX, config-dedup files only
_KEY_MATERIAL_EXTS = frozenset({
    ".pem", ".key", ".ppk", ".p12", ".pfx", ".jks", ".keystore", ".p8",
    ".pkcs12", ".asc", ".gpg", ".ovpn",
})
_KEY_MATERIAL_NAME_PREFIXES = ("id_rsa", "id_dsa", "id_ecdsa", "id_ed25519")
_KEY_MATERIAL_NAMES = frozenset({
    ".htpasswd", ".git-credentials", ".npmrc", ".pypirc", ".netrc",
})


def _is_key_material(rel: str) -> bool:
    """Whether *rel* names key/credential material by filename convention."""
    name = rel.rsplit("/", 1)[-1].lower()
    if name in _KEY_MATERIAL_NAMES or name.startswith(_KEY_MATERIAL_NAME_PREFIXES):
        return True
    return Path(name).suffix in _KEY_MATERIAL_EXTS


def _key_material_files(inventory: list[str]) -> list[str]:
    """The key/credential-material files in *inventory*, classified once rather than per vetoed entry."""
    return [rel for rel in inventory if _is_key_material(rel)]


def _secret_bearing_files(inventory: list[str], repo_root: str) -> list[str]:
    """The files in *inventory* whose head (`_EXCERPT_CHARS`, so a large dump is sampled) `redact_counts` flags as carrying credential material."""
    root = Path(repo_root)
    hits: list[str] = []
    for rel in inventory:
        try:
            with (root / rel).open("r", encoding="utf-8",
                                   errors="replace") as fh:
                head = fh.read(_EXCERPT_CHARS)
        except OSError:
            continue
        _, counts = redact_counts(head)
        if counts:
            hits.append(rel)
    return hits


_CLIENT_SINK_LANGUAGES = frozenset({"javascript", "typescript"})
_CLIENT_SINK_DETECTORS = compile_detectors(
    [spec for spec in detector_corpus() if spec.rule_id == "detector-docwrite-location"])


def _client_sink_files(inventory: list[str], repo_root: str, cfg) -> list[str]:
    """The first-party JS/TS files in *inventory* where the DOM-sink detector fires.

    Reuses s5's detector-docwrite-location rule (and its proximity gate) so s1
    and s5 cannot disagree on what counts as a client-side DOM sink.
    """
    cache = FileCache(repo_root, max_kb=getattr(cfg.step1, "max_file_kb", 1024))
    hits: list[str] = []
    for rel in inventory:
        if EXT_TO_LANG.get(Path(rel).suffix.lower()) not in _CLIENT_SINK_LANGUAGES:
            continue
        if _is_vendor_or_build_entry(rel):
            continue
        lines = cache.lines(rel)
        if lines and detector_hits(rel, lines, _CLIENT_SINK_DETECTORS):
            hits.append(rel)
    return hits


def _removes_protected_files(protected: list[str], kind: str,
                             entry: str) -> list[str]:
    """Which of the `protected` files the exclusion `entry` of the given kind would remove from scope."""
    # Reproduces _walk_repo's dir/ext/glob predicates in memory so the veto cannot disagree with it
    entry_l = entry.lower()
    hits: list[str] = []
    for rel in protected:
        if kind == "dir":
            if all(part.lower() != entry_l for part in rel.split("/")[:-1]):
                continue
        elif kind == "ext":
            # endswith catches compound suffixes like '.blade.php'; Path.suffix returns '.php'
            name = rel.rsplit("/", 1)[-1].lower()
            suffix = Path(rel).suffix.lower()
            if not (suffix == entry_l or name.endswith(entry_l)):
                continue
        elif glob_hit(rel, [entry]) is None:
            continue
        hits.append(rel)
    return hits


def _norm_list(v, *, lower: bool = False) -> list[str]:
    if not v:
        return []
    if isinstance(v, str):
        v = [v]
    out: list[str] = []
    for x in v:
        if not isinstance(x, str):
            continue
        x = x.strip().strip("/\\")
        if not x:
            continue
        out.append(x.lower() if lower else x)
    seen: set[str] = set()
    uniq = []
    for x in out:
        if x not in seen:
            seen.add(x)
            uniq.append(x)
    return uniq


def vet_config_dedup(dd: dict) -> dict:
    """Return a COPY of *dd* without the model-proposed dedup widenings that could silently drop a protected file."""
    # scope.configs._dedup_configs runs on its own inventory, invisible to the containment vetoes
    if not isinstance(dd, dict):
        return dd
    out = dict(dd)
    for flag in ("promote_on_secret_hit", "promote_on_insecure_value"):
        if out.get(flag) is False:
            log.warning(Event.S1_CONFIG_DEDUP_VETOED, key=f"config_dedup.{flag}", proposed=False,
                        reason="a credential-bearing config file could be silently dropped as a near-duplicate")
            _errlog.log(_TAG, _TAG,
                        f"config_dedup veto: model-proposed {flag}=false "
                        f"refused; the flag stays enabled",
                        reason="s1_autoexclude_dedup_flag_veto",
                        recovered=True, flag=flag)
            COUNTERS.bump("s1_autoexclude_dedup_flag_veto")
            del out[flag]
    xs = out.get("exts")
    if isinstance(xs, list):
        bad = [e for e in xs if isinstance(e, str)
              and (e.lower() in _KEY_MATERIAL_EXTS or _erases_language(e))]
        if bad:
            kept = [e for e in xs if e not in bad]
            log.warning(Event.S1_CONFIG_DEDUP_VETOED, key="config_dedup.exts", exts=sorted(bad),
                        reason="key material, a scanner-known language or a server-side template is never safe to drop as a near-duplicate")
            _errlog.log(_TAG, _TAG,
                        f"config_dedup veto: model-proposed exts {bad!r} "
                        f"refused (key material, language-erasing, and "
                        f"template extensions may not be added to the "
                        f"dedup allowlist)",
                        reason="s1_autoexclude_dedup_ext_veto",
                        recovered=True, exts=bad)
            COUNTERS.bump("s1_autoexclude_dedup_ext_veto")
            if kept:
                out["exts"] = kept
            else:
                del out["exts"]
    return out


def vet_overlay(repo_root: str | Path, cfg, *, dirs: list[str],
                exts: list[str], globs: list[str],
                inventory: list[str] | None = None
                ) -> tuple[list[str], list[str], list[str]]:
    """Return the entries of a MODEL-proposed (dirs, exts, globs) triple that survive every deterministic veto."""
    # Model-only: operator overlays bypass; --resume re-vets; max_file_kb via run()'s gate
    repo_root = str(repo_root)

    vetoed = [x for x in exts + globs if _erases_language(x)]
    if vetoed:
        exts = [e for e in exts if _erases_language(e) is None]
        globs = [g for g in globs if _erases_language(g) is None]
        log.warning(Event.S1_OVERLAY_VETOED_LANGUAGE, entries=sorted(vetoed),
                    reason="would erase scannable source")
        # recovered=True: the veto KEEPS files in scope, nothing is lost.
        _errlog.log(_TAG, _TAG,
                    f"language-erasure veto: model-proposed exclusion(s) "
                    f"{vetoed!r} would erase an entire scanner-known "
                    f"language from scope; entries dropped from the overlay",
                    reason="s1_autoexclude_language_veto",
                    recovered=True, entries=vetoed)
        COUNTERS.bump("s1_autoexclude_language_veto", len(vetoed))

    # One walk, reused as run()'s scope-gate baseline and by every protected-file classification
    inv = inventory if inventory is not None else scope_after(repo_root, cfg)

    def _run_containment_veto(protected: list[str], *, noun: str,
                              label: str, reason: str, counter: str,
                              counter_files: str, errlog_files_key: str,
                              counter_vendor: str) -> None:
        nonlocal dirs, exts, globs

        def _veto(entries: list[str], kind: str) -> list[str]:
            kept: list[str] = []
            for entry in entries:
                if _is_vendor_or_build_entry(entry):
                    kept.append(entry)
                    COUNTERS.bump(counter_vendor)
                    continue
                hits = _removes_protected_files(protected, kind, entry)
                if not hits:
                    kept.append(entry)
                    continue
                log.warning(Event.S1_OVERLAY_VETOED, entry=entry, would_exclude=len(hits),
                            kind=noun, example=hits[0])
                # recovered=True: the veto KEEPS files in scope, nothing is lost.
                _errlog.log(_TAG, _TAG,
                            f"{label} veto: model-proposed {kind} exclusion "
                            f"{entry!r} would remove {len(hits)} {noun}; "
                            f"entry dropped from the overlay",
                            reason=reason, recovered=True, entry=entry,
                            **{errlog_files_key: len(hits)})
                COUNTERS.bump(counter)
                COUNTERS.bump(counter_files, len(hits))
            return kept

        dirs, exts, globs = (_veto(dirs, "dir"), _veto(exts, "ext"),
                             _veto(globs, "glob"))

    # A wider "veto any known-language file" variant was measured out: it re-included vendored JS
    if getattr(cfg.step1, "auto_exclude_protect_templates", True):
        _run_containment_veto(
            _template_files(inv),
            noun="server-side template file(s)",
            label="template-containment",
            reason="s1_autoexclude_template_veto",
            counter="s1_autoexclude_template_veto",
            counter_files="s1_autoexclude_template_files_protected",
            errlog_files_key="n_template_files",
            counter_vendor="s1_autoexclude_template_veto_vendor_exempt")

    if getattr(cfg.step1, "auto_exclude_protect_key_material", True):
        _run_containment_veto(
            _key_material_files(inv),
            noun="key-material file(s)",
            label="key-material-containment",
            reason="s1_autoexclude_key_material_veto",
            counter="s1_autoexclude_key_material_veto",
            counter_files="s1_autoexclude_key_material_files_protected",
            errlog_files_key="n_key_material_files",
            counter_vendor="s1_autoexclude_key_material_veto_vendor_exempt")

    if getattr(cfg.step1, "auto_exclude_protect_secrets", True):
        _run_containment_veto(
            _secret_bearing_files(inv, repo_root),
            noun="secret-bearing file(s)",
            label="secret-bearing-containment",
            reason="s1_autoexclude_secret_bearing_veto",
            counter="s1_autoexclude_secret_bearing_veto",
            counter_files="s1_autoexclude_secret_bearing_files_protected",
            errlog_files_key="n_secret_bearing_files",
            counter_vendor="s1_autoexclude_secret_bearing_veto_vendor_exempt")

    if getattr(cfg.step1, "auto_exclude_protect_client_sinks", True):
        _run_containment_veto(
            _client_sink_files(inv, repo_root, cfg),
            noun="first-party client file(s) with a DOM sink",
            label="client-sink-containment",
            reason="s1_autoexclude_client_sink_veto",
            counter="s1_autoexclude_client_sink_veto",
            counter_files="s1_autoexclude_client_sink_files_protected",
            errlog_files_key="n_client_sink_files",
            counter_vendor="s1_autoexclude_client_sink_veto_vendor_exempt")

    return dirs, exts, globs


def run(repo_root: str | Path, cfg, *, out_path: str | Path) -> Path:
    """Survey `repo_root`, always write a step1 overlay YAML (possibly empty) to `out_path`, and return it."""
    repo_root = str(repo_root)
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    base_dirs, base_exts, base_globs = _exclusion_sets(cfg)
    cur_max_kb = int(getattr(cfg.step1, "max_file_kb", 1024))
    cur_dedup = dict(_DEDUP_DEFAULTS)
    user_dd = getattr(cfg.step1, "config_dedup", None)
    if user_dd is not None:
        raw_dd = (user_dd if isinstance(user_dd, dict)
                  else getattr(user_dd, "_data", None) or vars(user_dd))
        # Drop None as s1_preprocess._dedup_configs does: `exts: null` else crashes list(cur_dedup)
        cur_dedup.update({k: v for k, v in raw_dd.items() if v is not None})

    survey, n_files = _survey(Path(repo_root), base_dirs, base_exts, base_globs)
    model = getattr(cfg.models, "autoexclude", None) or cfg.models.preprocess
    max_tok = int(getattr(cfg.step1, "auto_exclude_max_tokens", 8000))

    user_prompt = f"""Below is a deterministic survey of a repository. Propose
ADDITIONAL scan exclusions so the security scanner only sees production code.

Already excluded (do NOT repeat these — propose only repo-specific extras):
  dirs : {", ".join(sorted(base_dirs))}
  exts : {", ".join(sorted(base_exts))}
  globs: {", ".join(base_globs)}

Current max_file_kb = {cur_max_kb}
Current config_dedup = {{exts: {list(cur_dedup['exts'])}, min_cluster_size: {cur_dedup['min_cluster_size']}}}

{survey}

Return ONLY a fenced YAML block with these keys (omit any key you have no
change for — do NOT emit empty/null placeholders):

```yaml
exclude_dirs:   # directory NAMES (any depth), e.g. "generated", "samples"
  - ...
exclude_exts:   # file extensions WITH leading dot, e.g. ".pb.go", ".min.js"
  - ...
exclude_globs:  # repo-relative posix fnmatch, e.g. "**/*.g.dart", "tools/codegen/**"
  - ...
max_file_kb: 1024   # OPTIONAL int. Only emit if the largest-files list shows
                    # genuine source bigger than the current limit (raise it)
                    # or only data dumps above a lower threshold (lower it).
config_dedup:       # OPTIONAL. Only emit keys you want to change.
  exts: [...]       # FULL list (REPLACES current). Include defaults you want
                    # to keep plus repo-specific formats e.g. ".tfvars", ".cue".
  min_cluster_size: 3
```

Whole sub-repos that are clearly test-automation, demo, or tooling-only may
be excluded via exclude_globs (e.g. "that-repo/**"). Be conservative."""

    console.write(f"  [auto-step1] surveying {repo_root} ({n_files} files, "
                  f"prompt {len(user_prompt)} chars)")
    effort = knob(cfg, "step1.auto_exclude_effort", None) or None

    def _dispatch(*, drop_thinking: bool) -> str:
        return _deepagents.dispatch_prompt(
            user_prompt,
            model=model,
            cfg=cfg,
            cwd=repo_root,
            system_prompt=_SYSTEM,
            max_tokens=max_tok,
            tag=_TAG,
            graph_name="s1-autoexclude",
            # No response_model (fenced YAML): thinking costs no tool_choice; only a clip at a
            # budget the route could not grow can send the resend
            effort=None if drop_thinking else effort,
        )

    # Every backend passes this tag to check_response_quality(), so the override holds on any route
    with stage_floors(_TAG, min_chars=_MIN_RESPONSE_CHARS,
                      min_tokens=_MIN_RESPONSE_TOKENS):
        raw = dispatch_or_retry_unforced(
            _dispatch, "survey", stage="s1",
            effort=_deepagents.droppable_effort(model, effort, agentic=False),
            resend_refusal=refusal_resend_allowed(cfg, model))

    data = _extract_yaml(raw)
    base_dirs_l = {d.lower() for d in base_dirs}
    base_exts_l = {e.lower() for e in base_exts}

    dirs = [d for d in _norm_list(data.get("exclude_dirs"))
            if d.lower() not in base_dirs_l]
    exts = []
    for e in _norm_list(data.get("exclude_exts"), lower=True):
        if not e.startswith("."):
            e = "." + e
        if e not in base_exts_l:
            exts.append(e)
    globs = [g for g in _norm_list(data.get("exclude_globs"))
             if g not in set(base_globs)]

    # One walk, reused as the scope gate's n_before below.
    inv = scope_after(repo_root, cfg)
    dirs, exts, globs = vet_overlay(repo_root, cfg, dirs=dirs, exts=exts,
                                    globs=globs, inventory=inv)

    # Decided before the scope gate so its measurement includes the shrinkage a lowered max_file_kb causes.
    mfk = data.get("max_file_kb")
    new_max_kb = (int(mfk) if isinstance(mfk, (int, float)) and int(mfk) > 0
                  and int(mfk) != cur_max_kb else None)

    # Gate on the walk's measured effect: the vetoes miss catch-all globs and max_file_kb entirely, and _survey has no max_file_kb filter.
    n_before = len(inv)
    after = scope_after(repo_root, cfg, dirs=dirs, exts=exts, globs=globs,
                        max_file_kb=new_max_kb)
    n_after = len(after)
    # Measured under the VETTED overlay, which can differ from the model's proposal
    removed = sorted(set(inv) - set(after))
    if n_before and not n_after:
        # Drop the overlay rather than abort: same scope as --no-auto-step1.
        log.warning(Event.S1_OVERLAY_EMPTIES_SCOPE, files_before=n_before, files_after=0,
                    remedy="scanning with global step1 only")
        _errlog.log(_TAG, _TAG,
                    f"auto-exclude overlay would empty the scope "
                    f"({n_before} files -> 0); overlay discarded",
                    reason="s1_autoexclude_empty_scope",
                    files_before=n_before)
        dirs, exts, globs, new_max_kb = [], [], [], None
    elif n_before and n_after / n_before < _AGGRESSIVE_KEEP_RATIO:
        # Warn but apply: only a fully emptied scope is unambiguously wrong.
        sample = ", ".join(removed[:3])
        log.warning(Event.S1_OVERLAY_AGGRESSIVE, files_before=n_before, files_after=n_after,
                    dropped=f"{100 * (1 - n_after / n_before):.0f}%", example=sample or None,
                    remedy="re-run with --no-auto-step1 if coverage looks wrong")

    overlay: dict = {"exclude_dirs": dirs, "exclude_exts": exts,
                     "exclude_globs": globs}
    if new_max_kb is not None:
        overlay["max_file_kb"] = new_max_kb

    dd_in = data.get("config_dedup")
    if isinstance(dd_in, dict):
        dd_out: dict = {}
        for k, typ in _DEDUP_KEYS.items():
            if k not in dd_in:
                continue
            v = dd_in[k]
            if typ is list:
                xs = [("." + e.lstrip(".")).lower()
                      for e in _norm_list(v, lower=True)]
                if xs:
                    dd_out[k] = xs
            elif typ is bool and isinstance(v, bool):
                dd_out[k] = v
            elif typ is int and isinstance(v, (int, float)):
                dd_out[k] = int(v)
        # Read-site veto: refuse unsafe widenings before the proposal reaches the overlay
        dd_out = vet_config_dedup(dd_out)
        if dd_out:
            overlay["config_dedup"] = dd_out

    # Writer-site veto: re-checked before serialisation so no later setter can bypass it
    if "config_dedup" in overlay:
        overlay["config_dedup"] = vet_config_dedup(overlay["config_dedup"])
        if not overlay["config_dedup"]:
            del overlay["config_dedup"]

    out.write_text(
        "# Auto-generated by vvaharness auto-step1 — appended to global step1.\n"
        + yaml.safe_dump(overlay, sort_keys=False, default_flow_style=False),
        encoding="utf-8",
    )
    extras = []
    if "max_file_kb" in overlay:
        extras.append(f"max_file_kb={overlay['max_file_kb']}")
    if "config_dedup" in overlay:
        extras.append(f"config_dedup={sorted(overlay['config_dedup'])}")
    console.write(f"  [auto-step1] wrote {out}  "
                  f"(+{len(dirs)} dirs, +{len(exts)} exts, +{len(globs)} globs"
                  f"{', ' + ', '.join(extras) if extras else ''})")
    return out
