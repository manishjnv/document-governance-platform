# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The interactive remediation loops: :func:`run_interactive` picks the arrow-key TUI or numbered-prompt fallback, both funneling through :func:`_remediate_one`."""
from __future__ import annotations
from vvaharness.util import logs

import sys

from vvaharness.models.case import Attempt
from vvaharness.models.derive import state_of
from vvaharness.models.vocab import CaseState
from vvaharness.orchestrator.artifacts import artifact_dir
from vvaharness.orchestrator.checkpoints import save_ckpt
from vvaharness.remediation_agent import policy as _policy
from vvaharness.remediation_agent.interactive.keys import (
    DOWN,
    ENTER,
    QUIT,
    UP,
    _read_key,
)
from vvaharness.remediation_agent.interactive.render import (
    _clear_and_draw,
    parse_selection,
    render_rows,
)
from vvaharness.remediation_agent.plugin_runner import apply_plugin, checkpoint_record
from vvaharness.remediation_agent.runner import step_key_of
from vvaharness.report.redact import redact
from vvaharness.util.status import stage
from vvaharness.util import console
from vvaharness.util.events import Event

log = logs.get_logger(__name__)


def _remediate_one(target, *, report_path, rem_dir, ckpt_dir, run_id,
                   cfg, mode, verbose=False, policy_ctx=None) -> bool:
    """Run the agent for one finding, checkpoint it, and mark it done; never raises, returns False on failure so the menu keeps running."""
    step = step_key_of(target, cfg)
    label = redact(target.label)
    try:
        # Guarded here (inside the broad except below) so a planted symlinked slug dir
        # fails only this finding, not the whole interactive session.
        out_dir = artifact_dir(rem_dir, target.slug)
        # Verbose stays plain; else stage()'s TTY gate keeps spinners out of non-TTY output
        animate = False if verbose else None
        with stage(label, n=target.index, total=None, animate=animate):
            remediation = apply_plugin(target, out_dir, cfg=cfg, repo=rem_dir.parent,
                                       mode=mode, verbose=verbose,
                                       policy_ctx=policy_ctx)
            # Bind the finding identity into the checkpoint so S11 discovery's state-store
            # provenance check (vvaharness.remediation_agent.provenance.owned_cases) can
            # trust this case the same way the standalone/in-scan remediate paths do.
            record = {**checkpoint_record(target, out_dir, remediation),
                      "finding_id": target.case_id}
            save_ckpt(ckpt_dir, run_id, step, record)

        # Mirror discovery.completed_case_ids so a declined attempt shows no done mark next session
        state = state_of([Attempt(ordinal=1, remediation=remediation)])
        target.done = state in (CaseState.REMEDIATED, CaseState.VALIDATED)
        console.write(f"    → {out_dir}")
        return True
    except Exception as e:  # noqa: BLE001
        log.warning(Event.REMEDIATION_FINDING_FAILED, finding=target.index, detail=redact(str(e)))
        return False


def run_interactive(findings, *, report_path, rem_dir, ckpt_dir, run_id,
                    cfg, mode, out=None, verbose=False) -> int:
    """Interactive loop: arrow-key TUI on a real terminal, else the numbered-prompt fallback; always returns exit code 0."""
    out = out or sys.stderr
    session = 0
    # Build the policy context once (no-op unless step_remediate.enforce_policy).
    policy_ctx = _policy.build_context(cfg, rem_dir.parent)
    if policy_ctx.enabled:
        console.write("  [Remediation Agent] policy gate ENABLED "
                      "(deny-list + playbook + diff post-gate)")
    try:
        interactive_tty = sys.stdin.isatty() and out.isatty()
    except Exception:  # noqa: BLE001
        interactive_tty = False

    if interactive_tty:
        session = _loop_tty(findings, report_path=report_path, rem_dir=rem_dir,
                            ckpt_dir=ckpt_dir, run_id=run_id, cfg=cfg, mode=mode,
                            out=out, verbose=verbose, policy_ctx=policy_ctx)
    else:
        session = _loop_prompt(findings, report_path=report_path, rem_dir=rem_dir,
                               ckpt_dir=ckpt_dir, run_id=run_id, cfg=cfg, mode=mode,
                               verbose=verbose, policy_ctx=policy_ctx)

    total_done = sum(1 for f in findings if f.done)
    console.mark("ok", f"exited — {session} remediated this session "
          f"({total_done}/{len(findings)} total complete)", indent=2, lead="\n")
    return 0


def _loop_tty(findings, *, report_path, rem_dir, ckpt_dir, run_id, cfg, mode,
              out, verbose=False, policy_ctx=None) -> int:
    cursor = 0
    session = 0
    while True:
        _clear_and_draw(findings, cursor, out)
        try:
            key = _read_key()
        except RuntimeError:
            # Lost the raw TTY mid-loop — degrade to the prompt path.
            return session + _loop_prompt(
                findings, report_path=report_path, rem_dir=rem_dir,
                ckpt_dir=ckpt_dir, run_id=run_id, cfg=cfg, mode=mode,
                verbose=verbose, policy_ctx=policy_ctx)
        if key == QUIT:
            return session
        if key == UP:
            cursor = (cursor - 1) % len(findings)
        elif key == DOWN:
            cursor = (cursor + 1) % len(findings)
        elif key == ENTER:
            out.write("\033[2J\033[H")
            out.flush()
            if _remediate_one(findings[cursor], report_path=report_path,
                              rem_dir=rem_dir, ckpt_dir=ckpt_dir, run_id=run_id,
                              cfg=cfg, mode=mode, verbose=verbose,
                              policy_ctx=policy_ctx):
                session += 1


def _loop_prompt(findings, *, report_path, rem_dir, ckpt_dir, run_id, cfg,
                 mode, verbose=False, policy_ctx=None) -> int:
    session = 0
    while True:
        for row in render_rows(findings):
            console.write(row)
        try:
            raw = input("  Select issues (e.g. 1,3-5 | all | pending | q): ")
        except (EOFError, KeyboardInterrupt):
            return session
        picks = parse_selection(raw, findings)
        if picks is None:
            return session
        for i in picks:
            if _remediate_one(findings[i], report_path=report_path,
                              rem_dir=rem_dir, ckpt_dir=ckpt_dir, run_id=run_id,
                              cfg=cfg, mode=mode, verbose=verbose,
                              policy_ctx=policy_ctx):
                session += 1
