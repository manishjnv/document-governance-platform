# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The remediation/validation rollup the run manifest carries: case-state and decision counts."""

# Counts ONLY: cases live in the untrusted target, so no title/path/id/snippet reaches run_manifest

from __future__ import annotations
from vvaharness.util import logs

from collections.abc import Iterable
from pathlib import Path
from typing import Final

from vvaharness.models.case import FindingCase
from vvaharness.models.derive import state_of, verdict_state
from vvaharness.models.verdict import Verdict
from vvaharness.models.vocab import CaseState
from vvaharness.orchestrator.artifacts import (
    CASE_DIR_NAME,
    CASE_FILE_NAME,
    UnsafeArtifactDir,
    artifact_dir,
)
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

__all__ = [
    "EXIT_NOT_REMEDIATED",
    "rc_for_verdicts",
    "record",
    "reset",
    "rollup_for",
    "totals",
]

#: Nothing validated as fixed; not `1` (harness broke) / `2` (refused pre-spend)
EXIT_NOT_REMEDIATED: Final = 3

#: Cap so a hostile pre-seeded ``security-remediation/`` cannot make us read a gigabyte
_MAX_CASE_BYTES: Final = 4 * 1024 * 1024

# Cumulative across repos (cf util.counters.snapshot_cumulative): ONE manifest per batch invocation
_TOTALS: Final[dict] = {}


def rc_for_verdicts(verdicts: Iterable[Verdict | None]) -> int:
    """``EXIT_NOT_REMEDIATED`` when *verdicts* validated nothing and failed something."""
    # Deliberately narrow AND-gate (else `|| true`); MergeReadiness is operator's call; no disk read
    states = [verdict_state(v) for v in verdicts if v is not None]
    if CaseState.VALIDATED in states or CaseState.FAILED not in states:
        return 0
    return EXIT_NOT_REMEDIATED


def _inside(path: Path, root: Path) -> bool:
    """Whether *path* really resolves inside *root*."""
    try:
        return path.resolve().is_relative_to(root.resolve())
    except OSError:
        return False


def _shaped(cases: int, states: dict[str, int], decisions: dict[str, int]) -> dict:
    """The one shape both :func:`rollup_for` and :func:`totals` return, so the per-repo and invocation-wide view..."""
    return {
        "cases": cases,
        "states": dict(sorted(states.items())),
        "decisions": dict(sorted(decisions.items())),
    }


def rollup_for(repo: Path | str) -> dict:
    """Tally the case records under ``<repo>/security-remediation/``, touching no module state."""
    # ``{}`` not zeros when nothing parsed; deliberately NOT for exit codes: counts cases ON DISK
    cases = 0
    states: dict[str, int] = {}
    decisions: dict[str, int] = {}
    try:
        case_root = artifact_dir(repo, CASE_DIR_NAME)
    except UnsafeArtifactDir as exc:
        # Best-effort reader (same tree discover_cases guards): warn and skip, never raise.
        log.warning(Event.CASE_ROOT_UNSAFE, repo=str(repo), detail=str(exc))
        return {}
    if not case_root.is_dir():
        return {}
    # s11 case_loader.discover_cases glob: DISCOVERED not VALIDATED; deliberately unfiltered by age
    for path in case_root.glob(f"*/{CASE_FILE_NAME}"):
        try:
            # is_file() stats without opening: a planted device node/FIFO is skipped, not blocked on
            if not path.is_file():
                continue
            if not _inside(path, case_root):
                log.warning(Event.CASE_PATH_OUTSIDE_ROOT, path=path, case_root=case_root)
                continue
            size = path.stat().st_size
            if size > _MAX_CASE_BYTES:
                msg = f"{size} bytes exceeds the {_MAX_CASE_BYTES}-byte case limit"
                raise ValueError(msg)
            case = FindingCase.read(path)
            state = state_of(case.attempts).value
            # An unvalidated attempt contributes to `states` but to no decision.
            verdict = case.attempts[-1].verdict if case.attempts else None
            decision = verdict.decision.value if verdict is not None else None
        except Exception as exc:  # noqa: BLE001  # see the comment below
            # Catches all on purpose: no case file may fail a finished tally (e.g. derive.py drift)
            log.warning(Event.CASE_RECORD_UNREADABLE, path=path, detail=str(exc))
            continue
        cases += 1
        states[state] = states.get(state, 0) + 1
        if decision is not None:
            decisions[decision] = decisions.get(decision, 0) + 1
    if not cases:
        return {}
    return _shaped(cases, states, decisions)


def record(repo: Path | str) -> dict:
    """Compute the rollup for *repo*, fold it into the invocation-wide accumulator, and return what was computed..."""
    rollup = rollup_for(repo)
    if rollup:
        _TOTALS["cases"] = _TOTALS.get("cases", 0) + rollup["cases"]
        for key in ("states", "decisions"):
            bucket = _TOTALS.setdefault(key, {})
            for name, n in rollup[key].items():
                bucket[name] = bucket.get(name, 0) + n
    return rollup


def totals() -> dict:
    """The accumulated invocation-wide rollup, same shape as :func:`rollup_for`; ``{}`` when nothing was recorded."""
    if not _TOTALS:
        return {}
    return _shaped(_TOTALS["cases"], _TOTALS["states"], _TOTALS["decisions"])


def reset() -> None:
    """Forget the accumulated totals — for test isolation, like COUNTERS.reset_all(): the accumulator is a proce..."""
    _TOTALS.clear()
