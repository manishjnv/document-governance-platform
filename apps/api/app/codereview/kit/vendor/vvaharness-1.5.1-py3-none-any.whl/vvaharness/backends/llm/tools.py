# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Sandboxed Read/Glob/Grep for non-CLI backends (sdk.py, openai.py); skips shelling to `claude`."""

# Read-only by design (no Bash); jailed to cwd AND the inventory once s1 calls set_scope()
from __future__ import annotations

import fnmatch
import os
import re
import threading
from pathlib import Path

from vvaharness.report.redact import redact_counts

_MAX_BYTES = 200_000
_MAX_MATCHES = 200
_MAX_GLOB = 500
# Per-line ceiling for the Grep scan — a ReDoS bound, since the pattern is model-supplied.
_MAX_GREP_LINE = 50_000

# Read-surface scoping: root containment alone allows .git/config; copies s1's excludes (layering)
_ALWAYS_EXCLUDED_DIRS = frozenset({".git", ".hg", ".svn",
                                   "checkpoints", "security-scan"})

_ALWAYS_ALLOWED_PREFIXES: tuple[str, ...] = (".vvaharness/",)

_SCOPE: dict[str, frozenset[str]] = {}
_SCOPE_LOCK = threading.Lock()


def _always_allowed(rel: str) -> bool:
    """True when *rel* is harness-injected content exempt from inventory scoping."""
    return rel.startswith(_ALWAYS_ALLOWED_PREFIXES)


def set_scope(root: str | Path, files) -> None:
    """Register the scan's in-scope file inventory (repo-relative posix paths) for *root*."""
    key = str(Path(root).resolve())
    inv = frozenset(str(f).replace("\\", "/") for f in files)
    with _SCOPE_LOCK:
        _SCOPE[key] = inv


def _scope_for(root: Path) -> frozenset[str] | None:
    try:
        key = str(root.resolve())
    except OSError:
        key = str(root)
    return _SCOPE.get(key)


def _excluded_rel(rel: str, scope: frozenset[str] | None) -> bool:
    """True when the repo-relative posix path is outside the tool read surface: under an always-excluded directo..."""
    if _always_allowed(rel):
        return False
    parts = rel.split("/")
    if any(part.lower() in _ALWAYS_EXCLUDED_DIRS for part in parts[:-1]):
        return True
    return scope is not None and rel not in scope


def _excluded_target(rel: str, scope: frozenset[str] | None) -> bool:
    """_excluded_rel for an explicit Grep target, which unlike a Read target may name a directory."""
    if _always_allowed(rel):
        return False
    parts = rel.split("/")
    if any(part.lower() in _ALWAYS_EXCLUDED_DIRS for part in parts):
        return True
    if scope is None or rel in scope:
        return False
    prefix = rel + "/"
    return not any(f.startswith(prefix) for f in scope)


_SCOPE_ERROR = ("ERROR: path '{path}' is excluded from the scan scope "
                "(not in the scanned file inventory)")

#: Agentic-loop reply to a tool the session never granted (never executed)
UNGRANTED_TOOL_ERROR = "ERROR: tool '{name}' is not available in this session"

# Binary / data-URI guard: both survive the extension filter; some gateways reject data URIs
_BINARY_SNIFF_CHARS = 8192
_DATA_URI_RX = re.compile(
    r"data:([\w.+-]+/[\w.+-]+);base64,([A-Za-z0-9+/=]*)")
# Some gateways also reject the bare, case-sensitive text `data:image/` alone: a percent-encoded
# SVG payload or no payload at all. The base64 pass above already removes every form it covers.
_DATA_URI_IMAGE_RX = re.compile(r"data:image/([\w.+-]*)")


def _is_binary_text(text: str) -> bool:
    """Cheap binary sniff on the decoded head: a null byte is the conventional test; a high U+FFFD density catch..."""
    head = text[:_BINARY_SNIFF_CHARS]
    if "\x00" in head:
        return True
    return bool(head) and head.count("�") / len(head) > 0.10


def _elide_data_uris(text: str) -> str:
    # Neutralise the MARKER, not just the payload: never restore it; replacement has no \n
    text = _DATA_URI_RX.sub(
        lambda m: (f"[data-uri {m.group(1)} elided: {len(m.group(2))} chars]"
                   if m.group(2) else f"[data-uri {m.group(1)} elided]"),
        text)
    return _DATA_URI_IMAGE_RX.sub(
        lambda m: (f"[data-uri image/{m.group(1)} elided]"
                   if m.group(1) else "[data-uri image elided]"),
        text)


def sanitize_packed_text(text: str, rel: str = "") -> str:
    """Guard *text* before it is packed into a prompt: binary content becomes a visible elision marker (never mo..."""
    if _is_binary_text(text):
        return f"[binary content elided: {rel or 'file'} is not text]"
    return _elide_data_uris(text)


#: ~12K-token ceiling so one Read cannot exhaust context; shared by openai/sdk/tool_adapter
TOOL_RESULT_CAP = 48_000


def cap_tool_result(result: str) -> str:
    """Trim *result* to `TOOL_RESULT_CAP`, telling the model what was cut and how to re-read."""
    if not result or len(result) <= TOOL_RESULT_CAP:
        return result
    extra = len(result) - TOOL_RESULT_CAP
    return (result[:TOOL_RESULT_CAP]
            + f"\n\n…[truncated {extra} chars to fit context — re-read a "
              f"specific line range with Read offset/limit if you need more]")


def _jail(root: Path, p: str) -> Path | None:
    try:
        cand = (root / p).resolve() if not os.path.isabs(p) else Path(p).resolve()
    except (OSError, ValueError):
        return None
    try:
        cand.relative_to(root)
    except ValueError:
        return None
    return cand


def _read(root: Path, path: str, offset: int = 0, limit: int = 2000) -> str:
    fp = _jail(root, path)
    if fp is None:
        return f"ERROR: path '{path}' is outside the repository root"
    # Scope check BEFORE the existence check, so an excluded path is not an existence oracle.
    rel = str(fp.relative_to(root)).replace("\\", "/")
    if _excluded_rel(rel, _scope_for(root)):
        return _SCOPE_ERROR.format(path=path)
    if not fp.is_file():
        return f"ERROR: file not found: {path}"
    try:
        with open(fp, encoding="utf-8", errors="replace") as f:
            lines = sanitize_packed_text(f.read(_MAX_BYTES * 4), rel).splitlines()
    except OSError as e:
        return f"ERROR: cannot read {path}: {e}"
    start = max(0, int(offset))
    end = start + max(1, int(limit))
    out = []
    for i, line in enumerate(lines[start:end], start + 1):
        out.append(f"{i}\t{line}")
    body = "\n".join(out)
    if len(body) > _MAX_BYTES:
        body = body[:_MAX_BYTES] + "\n... [truncated]"
    if not body:
        body = "(file is empty or offset past EOF)"
    return body


def _glob(root: Path, pattern: str) -> str:
    pat = pattern.lstrip("/").lstrip("\\")
    scope = _scope_for(root)
    # Scope-check the RESOLVED target: an in-root symlink must not list an excluded file
    try:
        hits = sorted(
            rel
            for p in root.glob(pat)
            if p.is_file()
            and (fp := _jail(root, rel := str(p.relative_to(root)).replace("\\", "/")))
            is not None
            and not _excluded_rel(
                str(fp.relative_to(root)).replace("\\", "/"), scope)
        )
    except (OSError, ValueError) as e:
        return f"ERROR: invalid glob '{pattern}': {e}"
    if not hits:
        return "No files found"
    if len(hits) > _MAX_GLOB:
        return "\n".join(hits[:_MAX_GLOB]) + f"\n... ({len(hits) - _MAX_GLOB} more)"
    return "\n".join(hits)


def _grep_wanted(rel: str, glob: str | None) -> bool:
    """True when *rel*, or its basename, matches *glob* — or no glob was given."""
    if not glob:
        return True
    pat = glob.lstrip("/").lstrip("\\")
    return fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(rel.rsplit("/", 1)[-1], pat)


def _grep_skip_harness(rel: str, explicit_harness: bool) -> bool:
    """True when *rel* is harness skill content a walk that did not name it must not surface."""
    return not explicit_harness and (rel == ".vvaharness" or _always_allowed(rel))


def _grep_in_surface(root: Path, p: Path, scope: frozenset[str] | None,
                      glob: str | None, explicit_harness: bool) -> bool:
    # Resolved target, not the link path (see _glob).
    fp = _jail(root, str(p)) if p.is_file() else None
    if fp is None:
        return False
    rel = str(fp.relative_to(root)).replace("\\", "/")
    if _grep_skip_harness(rel, explicit_harness):
        return False
    return _grep_wanted(rel, glob) and not _excluded_rel(rel, scope)


def _grep_files(root: Path, path: str | None, glob: str | None,
                 scope: frozenset[str] | None) -> list[Path] | str:
    """Resolve the Grep file list for *path*/*glob*, or an ERROR string on a bad/excluded path."""
    if not path:
        # No explicit path: one recursive walk, glob (if any) filters it — never a no-op.
        return sorted(p for p in root.rglob("*")
                      if _grep_in_surface(root, p, scope, glob, False))
    target = _jail(root, path)
    if target is None:
        return f"ERROR: path '{path}' is outside the repository root"
    # Scope check BEFORE the is_file/is_dir split: no existence oracle; "." is the root, allowed
    rel = str(target.relative_to(root)).replace("\\", "/")
    if rel != "." and _excluded_target(rel, scope):
        return _SCOPE_ERROR.format(path=path)
    if not target.is_dir():
        return [target] if target.is_file() else []
    explicit_harness = rel == ".vvaharness" or _always_allowed(rel)
    return sorted(p for p in target.rglob("*")
                  if _grep_in_surface(root, p, scope, glob, explicit_harness))


def _clip_grep_line(s: str) -> str:
    # Cap the bytes both searched and emitted per line; mark when cut.
    return s if len(s) <= _MAX_GREP_LINE else s[:_MAX_GREP_LINE] + " …[line clipped]"


def _emit_grep_match(out: list[str], rel: str, i: int, lines: list[str], ctx: int) -> int:
    """Append one match (with its context window, if any) to *out*; return the lines it cost."""
    if not ctx:
        out.append(f"{rel}:{i + 1}:{_clip_grep_line(lines[i])}")
        return 1
    lo, hi = max(0, i - ctx), min(len(lines), i + ctx + 1)
    for j in range(lo, hi):
        mark = ":" if j == i else "-"
        out.append(f"{rel}:{j + 1}{mark}{_clip_grep_line(lines[j])}")
    out.append("--")
    return (hi - lo) + 1


def _grep(root: Path, pattern: str, path: str | None = None,
          glob: str | None = None, ignore_case: bool = False,
          context: int = 0) -> str:
    flags = re.IGNORECASE if ignore_case else 0
    try:
        rx = re.compile(pattern, flags)
    except re.error as e:
        return f"ERROR: invalid regex '{pattern}': {e}"

    files = _grep_files(root, path, glob, _scope_for(root))
    if isinstance(files, str):
        return files

    out: list[str] = []
    emitted = 0
    ctx = max(0, min(200, int(context)))
    for fp in files:
        try:
            text = fp.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if len(text) > _MAX_BYTES * 8:
            text = text[: _MAX_BYTES * 8]
        # Binary files yield only mojibake; a matched line must not carry a data-URI marker onward
        if _is_binary_text(text):
            continue
        text = _elide_data_uris(text)
        lines = text.splitlines()
        rel = str(fp.relative_to(root)).replace("\\", "/")

        for i, line in enumerate(lines):
            # Search only the bounded prefix so a model-supplied pattern can't blow up on a line.
            if not rx.search(line[:_MAX_GREP_LINE]):
                continue
            emitted += _emit_grep_match(out, rel, i, lines, ctx)
            if emitted >= _MAX_MATCHES:
                out.append(f"... (stopped at {_MAX_MATCHES} lines; "
                           f"narrow pattern, path or glob)")
                return "\n".join(out)
    return "\n".join(out) if out else "No matches found"


# Public surface used by backends/llm/openai.py

_SCHEMAS = {
    "Read": {
        "description": "Read a file from the repository. Returns numbered lines.",
        "parameters": {
            "type": "object",
            "properties": {
                "path":   {"type": "string",
                           "description": "Path relative to the repo root"},
                "offset": {"type": "integer",
                           "description": "0-based line to start from (default 0)"},
                "limit":  {"type": "integer",
                           "description": "Max lines to return (default 2000)"},
            },
            "required": ["path"],
        },
    },
    "Glob": {
        "description": "List files in the repository matching a glob pattern "
                       "(e.g. **/*.java).",
        "parameters": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string"},
            },
            "required": ["pattern"],
        },
    },
    "Grep": {
        "description": "Search file contents for a regex. Returns "
                       "file:line:text for each match.",
        "parameters": {
            "type": "object",
            "properties": {
                "pattern":     {"type": "string",
                                "description": "Python regex"},
                "path":        {"type": "string",
                                "description": "Restrict to this file or directory"},
                "glob":        {"type": "string",
                                "description": "Restrict to files matching this glob"},
                "ignore_case": {"type": "boolean"},
                "context":     {"type": "integer",
                                "description": "Lines of context around each match"},
            },
            "required": ["pattern"],
        },
    },
}

_EXEC = {
    "Read": lambda root, a: _read(root, a.get("path", ""),
                                  a.get("offset", 0), a.get("limit", 2000)),
    "Glob": lambda root, a: _glob(root, a.get("pattern", "")),
    "Grep": lambda root, a: _grep(root, a.get("pattern", ""),
                                  a.get("path"), a.get("glob"),
                                  bool(a.get("ignore_case", False)),
                                  a.get("context", 0)),
}


def schemas_for(allowed: list[str]) -> list[dict]:
    """Return OpenAI `tools=[...]` entries for the requested tool names."""
    out = []
    for name in allowed:
        spec = _SCHEMAS.get(name)
        if spec:
            out.append({"type": "function",
                        "function": {"name": name, **spec}})
    return out


def anthropic_schemas_for(allowed: list[str]) -> list[dict]:
    """Return Anthropic Messages-API `tools=[...]` entries for the requested tool names."""
    out = []
    for name in allowed:
        spec = _SCHEMAS.get(name)
        if spec:
            out.append({"name": name,
                        "description": spec["description"],
                        "input_schema": spec["parameters"]})
    return out


def supported(allowed: list[str]) -> tuple[list[str], list[str]]:
    ok = [t for t in allowed if t in _SCHEMAS]
    missing = [t for t in allowed if t not in _SCHEMAS]
    return ok, missing


def summarize_args(args: dict | None) -> str:
    """Return a bounded, non-sensitive summary for a local-tool invocation."""
    parts: list[str] = []
    for key in ("path", "pattern", "glob"):
        value = (args or {}).get(key)
        if value:
            text = str(value)
            parts.append(f"{key}={text[:60]}{'...' if len(text) > 60 else ''}")
    context = (args or {}).get("context")
    if context:
        parts.append(f"context={context}")
    if (args or {}).get("ignore_case"):
        parts.append("ignore_case=True")
    return ", ".join(parts) or "..."


def execute(name: str, args: dict, *, cwd: str) -> str:
    root = Path(cwd).resolve()
    fn = _EXEC.get(name)
    if fn is None:
        return f"ERROR: tool '{name}' is not available on this backend"
    try:
        result = fn(root, args or {})
    except Exception as e:
        return f"ERROR: {type(e).__name__}: {e}"
    # Read/Grep results carry file CONTENT and must not be egressed unredacted; Glob returns paths.
    if name in ("Read", "Grep") and not result.startswith("ERROR:"):
        result, _ = redact_counts(result)
    return result
