# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Fail-closed content scan of the lines an S10 patch ADDED (CWE-1427).

The path gates bound only *where* the fixer writes and ``_gates_ok`` is the
agent's own self-report, so an injected fixer staying inside the allowed paths
previously passed every gate. Only added lines are scanned — pre-existing
matches are the repo's own debt, and a fix that DELETES an ``eval`` or a
credential must not be penalised. Regex, not semgrep-shelled: S10 forbids
``Bash`` and the host must not run an analyzer chosen by model-influenced input.
"""
from __future__ import annotations

import re
from collections.abc import Iterable
from pathlib import PurePosixPath

#: (label, reason, patterns) per category; narrow on purpose — reject a backdoor, not any mention of auth
_RULES: tuple[tuple[str, str, tuple[re.Pattern[str], ...]], ...] = (
    (
        "auth_bypass",
        "introduces an authentication/authorization short-circuit",
        (
            # `if <user/token/role/admin-ish> == "<literal>"` style backdoors.
            re.compile(
                r"(?i)\b(?:user(?:name)?|login|account|email|token|api_?key|"
                r"secret|password|passwd|pwd|role|group)\b[^\n=!<>]{0,40}"
                r"==\s*['\"][^'\"\n]{2,}['\"]"
            ),
            # Magic-value escape hatches keyed on a hardcoded sentinel.
            re.compile(
                r"(?i)\b(?:backdoor|master_?key|magic_?(?:key|value|token)|"
                r"god_?mode|skip_?auth|bypass_?auth|no_?auth|auth_?bypass|"
                r"disable_?auth|allow_?all|trust_?all)\b"
            ),
            # Verification functions rewritten to unconditionally succeed.
            re.compile(
                r"(?i)\b(?:is_?(?:admin|authenticated|authorized|valid)|"
                r"check_?(?:auth|permission|access)|has_?(?:permission|access|role)|"
                r"verify|validate|authenticate|authorize)\w*\s*\([^)]*\)\s*"
                r"(?:\{\s*)?(?::\s*)?return\s+(?:True|true|1)\b"
            ),
            # TLS / certificate verification switched off.
            re.compile(
                r"(?i)(?:verify|check_?hostname|validate_?certs?|ssl_?verify|"
                r"rejectUnauthorized|CURLOPT_SSL_VERIFYPEER)\s*[=:]\s*"
                r"(?:False|false|0|None|null)\b"
            ),
            re.compile(r"(?i)\bCERT_NONE\b|\bInsecureSkipVerify\s*:\s*true\b"),
        ),
    ),
    (
        "code_execution",
        "introduces dynamic code execution",
        (
            re.compile(
                r"(?<![\w.])(?:eval|exec|compile)\s*\("
            ),
            re.compile(
                r"(?i)(?<![\w.])(?:os\.system|os\.popen|subprocess\.(?:run|call|"
                r"Popen|check_output|check_call)|commands\.getoutput|"
                r"child_process\.(?:exec|execSync|spawn|spawnSync)|"
                r"Runtime\.getRuntime\(\)\.exec|ProcessBuilder|"
                r"shell_exec|passthru|proc_open|popen|system)\s*\("
            ),
            re.compile(r"(?<![\w.])new\s+Function\s*\("),
            re.compile(r"(?i)\bpickle\.loads?\s*\(|\byaml\.load\s*\((?![^)]*Safe)"),
            re.compile(r"(?i)\b__import__\s*\(|\bimportlib\.import_module\s*\("),
            re.compile(r"(?i)\bsetTimeout\s*\(\s*['\"]"),
        ),
    ),
    (
        "network_egress",
        "introduces outbound network access",
        (
            re.compile(
                r"(?i)(?<![\w.])(?:requests\.(?:get|post|put|patch|delete|request)|"
                r"urllib\.request\.urlopen|urlopen|httpx\.(?:get|post|Client)|"
                r"http\.client\.HTTPS?Connection|aiohttp\.ClientSession|"
                r"fetch|axios(?:\.\w+)?|XMLHttpRequest|WebSocket|"
                r"socket\.(?:socket|create_connection))\s*\("
            ),
            # NO bare URL / IP:port pattern here, deliberately. A URL literal
            # in source is not egress — egress is a CALL. Matching the literal
            # would flag ordinary application code, such as an allowlist
            # validator's error message or an href in an HTML anchor. The
            # call-shaped patterns above are the real signal.
            re.compile(
                r"(?i)(?<![\w.])(?:curl|wget|nc|ncat|netcat)\s+(?:-\S+\s+)*"
                r"(?:https?://|\d{1,3}\.)"
            ),
        ),
    ),
    (
        "credential_exfiltration",
        "reads credentials or secret material into a new code path",
        (
            re.compile(
                r"(?i)(?:open|read_text|readFile(?:Sync)?|cat)\s*\(\s*"
                r"['\"][^'\"\n]*(?:/\.ssh/|/\.aws/|id_rsa|id_ed25519|"
                r"\.pem|\.env|credentials|shadow|passwd)"
            ),
            re.compile(
                r"(?i)\bos\.environ(?:\.get)?\s*[\[(]\s*['\"][^'\"\n]*"
                r"(?:SECRET|TOKEN|PASSWORD|API_?KEY|PRIVATE_?KEY|CREDENTIAL)"
            ),
            re.compile(r"(?i)\b(?:base64\.b64decode|atob)\s*\(\s*['\"][A-Za-z0-9+/=]{24,}"),
        ),
    ),
    (
        "reverse_shell",
        "introduces a reverse shell or interactive listener",
        (
            re.compile(
                r"(?i)\b(?:/bin/(?:ba)?sh|cmd\.exe|powershell)\b[^\n]{0,60}"
                r"(?:-i|-c|/c|-nop|-enc)\b"
            ),
            re.compile(r"(?i)\bpty\.spawn\s*\(|\bsocket\.dup2\b|\bdup2\s*\(\s*s\b"),
            re.compile(r"(?i)\bnc\s+-\w*l\w*\b|\bbash\s+-i\s*>&"),
        ),
    ),
)

#: Comment-only additions are skipped: an injected payload must become code to act
_COMMENT_ONLY = re.compile(
    r"""^\s*(?:\#|//|/\*|\*|<!--|--|;|%|"""         # common line-comment leaders
    r"""\"\"\"|'''|rem\s)""",
    re.IGNORECASE | re.VERBOSE,
)

#: A line whose code content is ONE string literal of prose — an operator
#: warning, a docstring row, a raised message. The construct named inside it is
#: being described, not performed: a validator that raises
#: "Remove APP_TLS_VERIFY=false (CWE-295)" is the control, not the breach.
#: Requires whitespace inside the quotes, so a real single-argument call such as
#: ``eval("payload")`` is never mistaken for prose.
_PROSE_STRING_ONLY = re.compile(
    r"""^[\s(\[{,]*             # optional call/collection punctuation
        [rfbu]{0,2}             # python string prefixes
        (?P<q>\"\"\"|'''|\"|')  # opening quote
        (?P<body>.*?)           # body
        (?P=q)                  # matching close quote
        [\s)\]},;+]*$           # optional trailing punctuation/concatenation
    """,
    re.VERBOSE | re.DOTALL,
)


def _is_prose_string(text: str) -> bool:
    """True when *text*'s whole code content is one human-sentence string.

    The space requirement is what separates prose from a real single-argument
    call: ``eval("payload")`` has no space inside the quotes and is still
    scanned, while ``raise ValueError("Remove APP_TLS_VERIFY=false")`` is a
    message describing the construct rather than performing it.
    """
    match = _PROSE_STRING_ONLY.match(text.strip())
    return bool(match) and " " in (match.group("body") or "")

_DIFF_HEADER_PREFIXES = ("+++", "---")
_HUNK = re.compile(r"^@@ ")
_DIFF_GIT = re.compile(r"^diff --git a/(?P<a>.+?) b/(?P<b>.+?)\s*$")
_PLUS_FILE = re.compile(r"^\+\+\+ (?:b/)?(?P<path>.+?)\s*$")


def added_lines_by_file(diff_text: str | None) -> dict[str, list[tuple[int, str]]]:
    """Map each file in *diff_text* to its ADDED lines as ``(lineno, text)``.

    ``lineno`` counts added lines within the file's own hunks (1-based) and is
    used only to make a finding reportable; it is not a post-image line number.
    Removed and context lines are excluded, as are diff headers.
    """
    if not diff_text:
        return {}
    out: dict[str, list[tuple[int, str]]] = {}
    current: str | None = None
    counter = 0
    for raw in diff_text.splitlines():
        m = _DIFF_GIT.match(raw)
        if m:
            current = (m.group("b") or m.group("a")).strip() or None
            counter = 0
            continue
        m = _PLUS_FILE.match(raw)
        if m:
            path = m.group("path").strip()
            current = None if path == "/dev/null" else path
            counter = 0
            continue
        if raw.startswith(_DIFF_HEADER_PREFIXES) or _HUNK.match(raw):
            continue
        if current and raw.startswith("+"):
            counter += 1
            out.setdefault(current, []).append((counter, raw[1:]))
    return out


#: Shells execute but carry no language key in frameworks._EXT_LANG.
_SHELL_EXTS = frozenset({".sh", ".bash", ".zsh", ".ksh", ".ps1", ".psm1"})

#: vvaharness' own output and scaffolding dirs, never attacker-controlled.
#: Their contents are security-detector material by design — probe.sh scripts
#: carry live attack payloads and SKILL.md docs quote them as examples — so
#: they match these rules for legitimate reasons. Matched after _fold(), which
#: strips leading "./" characters, so ".vvaharness" arrives as "vvaharness".
_HARNESS_OWNED_PREFIXES = ("vvaharness/", "security-scan/", "security-remediation/")


def _is_executable_source(path: str) -> bool:
    """True when *path* is a file whose added lines could actually run.

    These rules describe code constructs, so only code can carry them. A log,
    report, manifest or Markdown doc cannot execute, and scanning one is pure
    noise: a security skill doc quoting
    ``if username == 'admin'`` as a worked example matches auth_bypass, and a
    runtime log echoes addresses and commands verbatim. Both
    reach the diff through enforce_post's whole-tree sweep, which reports every
    dirty path in the repo whether or not the fixer touched it.
    """
    from vvaharness.remediation_agent.frameworks import language_for

    suffix = PurePosixPath(path or "").suffix.lower()
    return suffix in _SHELL_EXTS or language_for(path) != "default"


def scan_added_lines(
    diff_text: str | None, *, only_files: Iterable[str] | None = None
) -> dict[str, list[str]]:
    """Find forbidden constructs among the lines *diff_text* added.

    Returns ``{path: ["<category>: <reason> (line N: <snippet>)", …]}`` — empty
    when the patch added nothing of concern. Never raises: a scan failure must
    not take down a run, but note that an empty result is also what a clean
    patch produces, so callers treat "no findings" as pass.
    """
    try:
        added = added_lines_by_file(diff_text)
    except Exception:  # noqa: BLE001 — a best-effort scan must never break a run
        return {}
    allowed = {_fold(f) for f in only_files} if only_files is not None else None
    issues: dict[str, list[str]] = {}
    for path, lines in added.items():
        if allowed is not None and _fold(path) not in allowed:
            continue
        folded = _fold(path)
        if folded.startswith(_HARNESS_OWNED_PREFIXES):
            continue
        if not _is_executable_source(path):
            continue
        for lineno, text in lines:
            if (not text.strip() or _COMMENT_ONLY.match(text)
                    or _is_prose_string(text)):
                continue
            for label, reason, patterns in _RULES:
                if any(p.search(text) for p in patterns):
                    issues.setdefault(path, []).append(
                        f"{label}: {reason} (line {lineno}: {_snippet(text)})")
                    break  # one category per line is enough to reject it
    return issues


def undeclared_edited_files(
    diff_text: str | None, declared: Iterable[str]
) -> list[str]:
    """Files the patch changed that the dispatch never declared.

    ``FixerDispatchGuard`` validates that the dispatch's ``TARGET FILES``
    section names the primary file, but nothing checked that the fixer confined
    its edits to the files it declared. Any extra file is an edit the
    orchestrator never asked for, which is exactly the shape of an injected
    backdoor dropped into an unrelated module.
    """
    try:
        touched = added_lines_by_file(diff_text)
    except Exception:  # noqa: BLE001 — best effort, as above
        return []
    want = {_fold(d) for d in declared if d}
    return sorted(p for p in touched if _fold(p) not in want)


def _fold(path: str) -> str:
    return (path or "").replace("\\", "/").lstrip("./").casefold()


def _snippet(text: str, limit: int = 120) -> str:
    """A single-line, length-bounded excerpt safe to embed in a report."""
    flat = " ".join(text.split())
    return flat if len(flat) <= limit else flat[: limit - 1] + "…"


__all__ = ["added_lines_by_file", "scan_added_lines", "undeclared_edited_files"]
