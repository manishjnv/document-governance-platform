# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Prompt-cache policy shared by the cli/sdk/openai backends, so no two can disagree about it."""
from __future__ import annotations

from collections.abc import Mapping

from vvaharness.backends.harness.provider_routing import routes_to_anthropic
from vvaharness.report.redact import redact
from vvaharness.util import console
from vvaharness.util.tokens import TOKENS, unparsed_cache_keys

# Margin on the ESTIMATE, not the floor: the estimator under-counts; a refusal re-sends part of s4
CACHE_EST_MARGIN = 1.35

# Falsey kill-switch spellings: PyYAML parses unquoted `cache_markers: off` as the bool False
_DISABLED_SPELLINGS = ("off", "false", "no", "0", "none")


PREFIX_CACHE_BREAKPOINT = "breakpoint"
PREFIX_CACHE_IMPLICIT = "implicit"
PREFIX_CACHE_NONE = "none"


def prefix_cache_class(via: str, *, model_id: str = "",
                       provider: str | None = None) -> str:
    """The prompt-prefix caching mechanism a route's requests can use."""
    if via == "sdk":
        return PREFIX_CACHE_BREAKPOINT
    if via == "openai":
        return PREFIX_CACHE_IMPLICIT
    if via == "deepagents":
        if routes_to_anthropic(model_id, provider):
            return PREFIX_CACHE_BREAKPOINT
        return PREFIX_CACHE_IMPLICIT
    return PREFIX_CACHE_NONE


def markers_enabled(cfg: Mapping) -> bool:
    """Whether `cfg`'s `cache_markers` switch permits this route to emit cache markers/hints."""
    v = cfg.get("cache_markers", "on")
    if isinstance(v, bool):
        return v
    return str(v).strip().lower() not in _DISABLED_SPELLINGS


# `cache_creation` is the per-TTL breakdown of a total already carried — accounted for, not missed
ANTHROPIC_PARSED_CACHE_KEYS = frozenset({
    "cache_creation_input_tokens", "cache_read_input_tokens", "cache_creation",
})


def note_unparsed_cache_keys(usage: dict | None, *, via: str) -> None:
    """Flag cache accounting reported under key names the Anthropic-shaped set does not cover."""
    report_unparsed_cache_keys(usage, ANTHROPIC_PARSED_CACHE_KEYS, via=via, label=via)


def report_unparsed_cache_keys(usage: dict | None, parsed, *,
                               via: str, label: str) -> None:
    """Flag cache accounting `usage` reports under key names `parsed` does not cover."""
    # Without this a working cache reads 0/0 (util/tokens.py coerces with `or 0`); key names only
    keys = unparsed_cache_keys(usage, parsed)
    # Tolerate a TOKENS stand-in that only implements add() (test doubles patch exactly that).
    note = getattr(TOKENS, "note_cache_unparsed", None)
    if note is not None and note(keys, via=via):
        console.write(f"    [{label}] note: usage reports cache accounting under "
                      f"unparsed key(s): {redact(', '.join(keys))} — not included in "
                      f"cache_read/cache_write totals; counted in the cache_unparsed "
                      f"bucket")
