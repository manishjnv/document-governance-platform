# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""FinalReport's chunk-kind line and pipeline-diagnostics block."""
from __future__ import annotations

import logging

from vvaharness.models.scan._render import _md_cell

log = logging.getLogger(__name__)


# Display order for known chunk kinds; any other kind still renders, appended after these
_CHUNK_KIND_LABELS = [
    ("risk", "risk"), ("catchall", "catch-all"), ("specialist", "specialist"),
    ("taint", "taint"), ("threat", "threat"), ("other", "other"),
]

def _render_chunk_kind_line(report) -> str:
    m = report.metrics
    if m.chunks_by_kind:
        known = dict(_CHUNK_KIND_LABELS)
        parts = [f"{label}={m.chunks_by_kind[key]}"
                 for key, label in _CHUNK_KIND_LABELS if key in m.chunks_by_kind]
        parts += [f"{key}={v}" for key, v in m.chunks_by_kind.items()
                 if key not in known]
    else:
        # Legacy trio: populated on every report, so a payload with no chunks_by_kind still renders
        parts = [f"risk={m.chunks_risk}", f"catch-all={m.chunks_catchall}",
                 f"specialist={m.chunks_specialist}"]
    return f"- Chunks: {m.chunks_total} ({', '.join(parts)})"


#: Stages dispatch_or_retry_unforced wraps with a structured contract / with a droppable tier
_STRUCTURED_RETRY_STAGES = ("s2", "s4", "s6", "s7", "s8")
_TRUNCATED_RETRY_STAGES = ("s1", "s2", "s4", "s6", "s7", "s8", "ev_classify")


def _render_pipeline_diagnostics(report, *,
                                 unreachable_appendix: bool = True) -> list[str]:
    """The stage-counter lines, empty when no counter has anything to say."""
    # A zero counter cannot tell "never ran" from "ran clean", so only a non-default emits
    m = report.metrics
    lines: list[str] = []

    if m.s2_degraded:
        lines.append(
            "- Threat model: **degraded** — the model call failed or "
            "returned no usable threats; ranking and baseline coverage "
            "for this scan fell back to the deterministic passes only."
        )
    if m.s2_threats_raw:
        lines.append(f"- Threats identified before ranking: {m.s2_threats_raw}")
    if m.s2_threats_truncated:
        lines.append(f"- Threats truncated by the prompt cap: {m.s2_threats_truncated}")
    if m.s2_threats_promoted:
        lines.append(
            "- Threats re-promoted after truncation to keep a trust "
            f"boundary covered: {m.s2_threats_promoted}"
        )
    frontier_cuts = [(label, n) for label, n in (
        ("files", m.s2_frontier_files_excluded),
        ("entry points", m.s2_frontier_entry_points_excluded),
        ("sinks", m.s2_frontier_sinks_excluded),
        ("modules", m.s2_frontier_modules_excluded)) if n]
    if frontier_cuts:
        lines.append(
            "- **Threat-model evidence excluded by step2 caps:** "
            + ", ".join(f"{label} {n}" for label, n in frontier_cuts)
        )
    prompt_cuts = [(label, n) for label, n in (
        ("inventory files", m.s2_inventory_files_truncated),
        ("entry points", m.s2_prompt_entry_points_truncated),
        ("modules", m.s2_prompt_modules_truncated)) if n]
    if prompt_cuts:
        lines.append(
            "- **Threat-model prompt truncated by step2 caps:** "
            + ", ".join(f"{label} {n}" for label, n in prompt_cuts)
        )
    if m.s2_assets_truncated:
        lines.append(f"- Assets truncated by step2.max_assets: {m.s2_assets_truncated}")
    if m.s2_trust_boundaries_truncated:
        lines.append("- Trust boundaries truncated by step2.max_trust_boundaries: "
                     f"{m.s2_trust_boundaries_truncated}")
    if m.s2_baseline_undisposed:
        lines.append(
            "- Baseline checklist items with no threat or open question "
            f"disposing of them: {', '.join(m.s2_baseline_undisposed)}"
        )
    if m.s2_repo_kinds:
        lines.append(f"- Repository kind(s) detected: {', '.join(m.s2_repo_kinds)}")
    if m.s2_surface_files_dropped:
        lines.append(
            "- Threat-model surface paths dropped (no such in-scope file): "
            f"{m.s2_surface_files_dropped}"
        )

    if m.s3_unknown_file_ids:
        lines.append(
            f"- Chunk file references that matched no known file id: "
            f"{m.s3_unknown_file_ids}"
        )
    if m.s3_dropped_paths:
        lines.append(f"- File references dropped (no matching file found): {m.s3_dropped_paths}")
    if m.s3_relocated_paths:
        lines.append(
            f"- **File references repaired by a suffix match: "
            f"{m.s3_relocated_paths}** — the strategist named a file that "
            "did not exist as given; verify these did not resolve onto "
            "the wrong file of the same name."
        )
    if m.s3_unreachable_files:
        # The COUNT reports regardless of output.emit_unreachable_appendix; only the list is gated
        where = ("they are listed in the appendix below"
                 if unreachable_appendix and report.unreachable_files
                 else "set output.emit_unreachable_appendix: true to "
                      "list them in the report")
        lines.append(
            f"- Files named by no investigation unit: "
            f"{m.s3_unreachable_files} of {m.total_files_in_scope} "
            f"in-scope file(s) got no reviewer — {where}."
        )
    if m.s3_threats_without_unit:
        # Ids from the report, count from metrics: both read the same reconciled manifest list.
        # Cause-neutral, matching _sections_chain._ranked_threat_rows: no validated surface
        # file, or a cached manifest older than the threat model on --resume.
        ids = report.threats_without_unit or []
        listed = f" ({', '.join(_md_cell(i) for i in ids)})" if ids else ""
        lines.append(
            f"- Threats with no investigation unit minted: "
            f"{m.s3_threats_without_unit}{listed} — never reviewed."
        )

    if m.s4_findings_truncated:
        lines.append(
            f"- **Deep-dive findings discarded by the per-call cap: "
            f"{m.s4_findings_truncated}** — one or more calls produced "
            "more findings than step4.max_findings_per_run allows; only "
            "the highest-confidence findings from each call were kept."
        )

    if m.deepagents_oversize_prompts:
        lines.append(
            f"- **Calls refused as over-ceiling on the deepagents route: "
            f"{m.deepagents_oversize_prompts}** (VVAH-E004) — a prompt "
            "exceeded the route's context ceiling before dispatch, so the "
            "owning unit failed loudly instead of being silently "
            "truncated; its results are absent from this report."
        )

    if m.llm_truncated_replies:
        # Route-agnostic: every transport gets one doubled-budget retry; causes are illustrative
        lines.append(
            f"- **LLM replies cut off by the output-token budget: "
            f"{m.llm_truncated_replies}** (VVAH-E005) — each counted "
            "reply hit its completion cap, so the owning unit failed "
            "loudly instead of a truncated reply passing as success; its "
            "results are absent from this report. Whether a "
            "doubled-budget retry was possible is per call: the count "
            "means that retry also hit the cap, or there was no headroom "
            "to retry with (for example, the budget already equalled the "
            "model's output cap, or doubling it would overflow the "
            "context window). The errors log names the stage and the "
            "case for each."
        )

    if m.llm_truncated_retry_attempted:
        # Its own row: a run whose every doubled retry was rescued has no E005 row above
        lines.append(
            f"- **LLM replies resent at a doubled output-token budget (attempted / recovered): "
            f"{m.llm_truncated_retry_attempted} / {m.llm_truncated_retry_recovered}** "
            "(`llm_truncated_retry_attempted` / `llm_truncated_retry_recovered`) — each "
            "attempt is a reply cut off by its output-token budget and sent once more with "
            "the budget doubled, on any route; a recovered one came back within the doubled "
            "budget. An attempt that was not recovered is counted in the VVAH-E005 line "
            "above or failed on the resend itself (the errors log names which)."
        )

    if m.deepagents_tool_state_not_roundtripped:
        lines.append(
            f"- **Tool-call replays rejected for missing per-turn state on "
            f"the deepagents route: {m.deepagents_tool_state_not_roundtripped}** "
            "(VVAH-E006) — the endpoint rejected a replayed tool call as missing "
            "its per-call state; the owning unit failed loudly. Run the doctor "
            "probe for the affected role and see docs/errors.md."
        )

    # The counter token is verbatim so it matches the route's WARN
    if m.llm_adapter_evidence_gate_unenforced:
        lines.append(
            f"- **Verdicts reached without a required fact-tool call on "
            f"via: sdk / via: openai: "
            f"{m.llm_adapter_evidence_gate_unenforced}** "
            "(`llm_adapter_evidence_gate_unenforced`) — an agentic session "
            "produced a verdict without calling a fact tool its stage's "
            "evidence gate required. The in-loop gate that would have "
            "rejected that verdict and re-asked is deepagents-only "
            "(neither raw provider loop has the seam), so this count plus "
            "a one-time WARN is the whole enforcement: those verdicts were "
            "reached from the prompt alone. Route the stage "
            "via: deepagents if the gate must actually hold."
        )
    if m.cli_mcp_evidence_gate_unenforced:
        lines.append(
            f"- **Verdicts reached without a required fact-tool call on "
            f"via: cli: {m.cli_mcp_evidence_gate_unenforced}** "
            "(`cli_mcp_evidence_gate_unenforced`) — the same evidence-gate "
            "shortfall on the via: cli MCP-bridged tool loop: a session "
            "with graph tools and require_graph produced a verdict "
            "without calling any of the required fact tools. via: cli has "
            "no in-loop seam either, so this count plus a one-time WARN "
            "is the whole enforcement on that route. Route the stage "
            "via: deepagents if the gate must actually hold."
        )

    if m.s6_confirmed_without_vector:
        lines.append(
            f"- **Verified findings confirmed with no CVSS vector: "
            f"{m.s6_confirmed_without_vector}** "
            "(`s6_confirmed_without_vector`) — a TRUE_POSITIVE verdict, "
            "or a verifier-discovered finding kept above the confidence "
            "floor, with no `cvss_vector` (the prompt's own instruction "
            "is to leave it empty rather than invent metrics, so this is "
            "expected, not a failure). Such a finding's shipped "
            "severity comes from its own CVSS/VulContextSeverity band if "
            "one exists, else its detection-time label — never a blanket "
            "INFO floor."
        )
    if m.s6_cvss_zero_impact_on_tp:
        lines.append(
            f"- **Verified findings with a zero-impact CVSS vector withheld: "
            f"{m.s6_cvss_zero_impact_on_tp}** "
            "(`s6_cvss_zero_impact_on_tp`) — a TRUE_POSITIVE whose verifier-given "
            "vector scored 0.0 base impact; the vector and score are withheld, not "
            "shipped as 0.0, or SARIF would rank the finding last by that score. "
            "Also counted in `s6_confirmed_without_vector` above. Severity falls "
            "back to the detection-time label, as any other no-vector TRUE_POSITIVE."
        )
    if m.s6_confidence_clamped:
        lines.append(
            f"- **Verifier confidence scores rewritten by the 0-10 clamp: "
            f"{m.s6_confidence_clamped}** (`s6_confidence_clamped`) — the verifier "
            "answered off the integer 0-10 scale and each such score was saturated to "
            "0/10 or truncated (95 -> 10, 0.9 -> 0), so those recorded confidences are "
            "not the numbers it gave. Counted per clamp event on every route, so a "
            "re-asked or re-parsed submit counts again. A count near the number of "
            "verdicts means it graded on another scale and the shipped scores carry no "
            "ranking information."
        )
    if m.s6_confidence_uniform:
        lines.append(
            f"- **Every verdict at one confidence: {m.s6_confidence_uniform}** "
            "(`s6_confidence_uniform`) — all judged verdicts carried the same score, so "
            "`step6_verify.min_confidence` admitted or dropped every TRUE_POSITIVE "
            "together; the stage's `[s6-verify] WARN:` line names the score and which. "
            "Read with `s6_confidence_clamped`: nonzero points at a scale mismatch; zero "
            "means the verifier gave one score to every finding (a rubber stamp, or a "
            "uniformly strong/weak finding set — check the verdict reasons)."
        )

    # Each counter token is verbatim so it matches the run log
    rejected = sum(getattr(m, f"{s}_structured_retry_attempted") for s in _STRUCTURED_RETRY_STAGES)
    rejected_ok = sum(getattr(m, f"{s}_structured_retry_recovered")
                      for s in _STRUCTURED_RETRY_STAGES)
    clipped = sum(getattr(m, f"{s}_truncated_retry_attempted") for s in _TRUNCATED_RETRY_STAGES)
    clipped_ok = sum(getattr(m, f"{s}_truncated_retry_recovered") for s in _TRUNCATED_RETRY_STAGES)
    if rejected or clipped or m.s2_empty_retry_attempted:
        # Context only: a drop with no retry costs nothing; both routes compensate it with a
        # submit instruction, so a nonzero count here is exposure, not an unrecovered failure.
        dropped = m.sdk_tool_choice_dropped_for_thinking + m.deepagents_tool_choice_dropped
        lines.append(
            f"- **Primary model calls re-dispatched: {rejected} after a rejected structured "
            f"reply ({rejected_ok} recovered), {clipped} after a reply clipped at a budget the "
            f"route could not grow ({clipped_ok} recovered)** "
            "(`s2/s4/s6/s7/s8_structured_retry_attempted` / `_recovered`, "
            "`s1/s2/s4/s6/s7/s8/ev_classify_truncated_retry_attempted` / `_recovered`) — each "
            "is a second full model call (a whole agentic session on S2/S4/S6), sent without "
            "`effort` when one was set; on S6 the pairs also count split-retry children. The run "
            "log names each cause (prose, a cut-off, or a validator failure)."
            + (f" {m.llm_structured_retry_truncated} of the rejected finals had hit the "
               "output-token budget (`llm_structured_retry_truncated`) — reduce what the call "
               "packs, or lower `effort`, so the first call fits."
               if m.llm_structured_retry_truncated else "")
            + (f" Hollow threat model re-sampled: {m.s2_empty_retry_attempted} "
               f"({m.s2_empty_retry_recovered} recovered) (`s2_empty_retry_attempted` / "
               "`_recovered`)." if m.s2_empty_retry_attempted else "")
            + (f" {dropped} structured call(s) carried no forced `tool_choice` under thinking "
               "(`via: deepagents`, where langchain-anthropic drops it on every effort-bearing "
               "call; `via: sdk` only under manual thinking: "
               "`sdk_tool_choice_dropped_for_thinking`, `deepagents_tool_choice_dropped`)."
               if dropped else "")
        )
    repaired = (m.s2_parse_repair_attempted + m.s4_outcome_repaired_attempt
                + m.s4_batch_repaired_attempt + m.s6_outcome_repaired_attempt)
    repaired_ok = (m.s2_parse_repair_recovered + m.s4_outcome_repaired_ok
                   + m.s4_batch_repaired_ok + m.s6_outcome_repaired_ok)
    if repaired or m.llm_structured_prose_reask or m.llm_structured_submit_rejected:
        lines.append(
            f"- **Replies re-asked for their structured shape: {repaired} json-repair call(s) "
            f"({repaired_ok} repaired), {m.llm_structured_prose_reask} prose re-ask(s), "
            f"{m.llm_structured_submit_rejected} rejected submit(s)** (`s2_parse_repair_*`, "
            "`s4_outcome_repaired_*`, `s4_batch_repaired_*`, `s6_outcome_repaired_*`; "
            "`llm_structured_prose_reask`, `llm_structured_submit_rejected`) — a json-repair is "
            "one extra effort-less model call; a prose re-ask is one extra turn in the same "
            "session; a rejected submit is a tool payload that failed validation and was sent "
            "back to the model (the last one in the ladder is returned to the stage's parser "
            "instead)."
        )

    if not lines:
        return []
    return ["### Pipeline Diagnostics", "", *lines, ""]
