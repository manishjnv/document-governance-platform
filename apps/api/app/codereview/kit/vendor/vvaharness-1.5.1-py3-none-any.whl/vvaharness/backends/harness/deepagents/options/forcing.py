# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Restore the forced tool_choice that langchain drops under adaptive thinking, as via:sdk does."""
from __future__ import annotations

import warnings
from typing import Any

from langchain_anthropic import ChatAnthropic
from langchain_core.runnables import Runnable

from vvaharness.util.counters import COUNTERS

__all__ = ["ForcingChatAnthropic"]

_DROP_MESSAGE = r"tool_choice is forced but thinking is enabled"
_FORCED_TYPES = ("any", "tool")


def _forced_choice(tool_choice: Any) -> dict[str, Any] | None:
    """The API-shaped forced tool_choice *tool_choice* asks for, or None when it forces nothing."""
    if isinstance(tool_choice, dict):
        return dict(tool_choice) if tool_choice.get("type") in _FORCED_TYPES else None
    if tool_choice in _FORCED_TYPES:
        return {"type": tool_choice}
    if isinstance(tool_choice, str):
        return {"type": "tool", "name": tool_choice}
    return None


class ForcingChatAnthropic(ChatAnthropic):
    """ChatAnthropic that keeps a forced tool_choice under ADAPTIVE thinking, which the API allows."""

    #: False binds every tool_choice as auto, for ForceVerdictOnly's working calls.
    force_tool_choice: bool = True

    def bind_tools(self, tools: Any, *, tool_choice: Any = None,
                   **kwargs: Any) -> Runnable[Any, Any]:
        """Bind *tools*, then put back the forcing langchain_anthropic dropped for adaptive thinking."""
        if not self.force_tool_choice:
            return super().bind_tools(tools, tool_choice=None, **kwargs)
        # langchain_anthropic drops tool_choice for thinking type `enabled` AND `adaptive`, but
        # only manual `enabled` is restricted to auto/none -- adaptive accepts tool/any
        # (thinking.md, "Thinking with tool use"), which is what via:sdk's _forcing_blocked
        # encodes. Without this the outcome tool is merely advertised, so any S2/S4/S6 session
        # can end on prose and lose its structured output.
        forced = _forced_choice(tool_choice)
        adaptive = (self.thinking or {}).get("type") == "adaptive"
        if forced is None or not adaptive:
            return super().bind_tools(tools, tool_choice=tool_choice, **kwargs)
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message=_DROP_MESSAGE, category=UserWarning)
            bound = super().bind_tools(tools, tool_choice=tool_choice, **kwargs)
        return _reforce(bound, forced)


def _reforce(bound: Runnable[Any, Any], forced: dict[str, Any]) -> Runnable[Any, Any]:
    """Re-apply *forced* to *bound*, carrying over any disable_parallel_tool_use langchain set."""
    held = getattr(bound, "kwargs", None)
    if not isinstance(held, dict):
        return bound
    if held.get("tool_choice", {}).get("type") in _FORCED_TYPES:
        return bound
    existing = held.get("tool_choice") or {}
    if "disable_parallel_tool_use" in existing:
        forced["disable_parallel_tool_use"] = existing["disable_parallel_tool_use"]
    COUNTERS.bump("deepagents_tool_choice_reforced_under_adaptive_thinking")
    return bound.bind(tool_choice=forced)
