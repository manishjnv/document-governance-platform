# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Which on-disk finding cases this machine's S10 remediation actually produced.

``security-remediation/`` lives INSIDE the scanned repository, which is untrusted
input: a committed ``finding_case.json`` (or a committed directory that symlinks
one in) can plant a case that S11 would otherwise treat as real. The state store
(``~/.vvaharness/state``, mode 0600) lives OUTSIDE the repo, so a checkout cannot
forge a row in it. :func:`owned_cases` is the read side of that trust boundary:
every S10 ``remediate_<digest>`` checkpoint row this run wrote names the finding
id and the artifact directory it wrote, and only a case matching BOTH is treated
as this run's own.
"""

from __future__ import annotations

from pathlib import Path

from vvaharness.orchestrator import store
from vvaharness.orchestrator.checkpoints import REMEDIATE_PREFIX, load_ckpt

__all__ = ["owned_cases"]


def owned_cases(run_id: str) -> set[tuple[str, Path]]:
    """Return ``{(finding_id, artifact_dir.resolve()), ...}`` for every S10 record *run_id* holds.

    Matching on both the finding id AND the resolved artifact directory (not
    either alone) stops a planted case that reuses a real case id under a
    different slug directory, or that reuses a real slug with a different id.
    """
    owned: set[tuple[str, Path]] = set()
    for step in store.steps_with_prefix(run_id, REMEDIATE_PREFIX):
        record = load_ckpt(Path(), run_id, step)
        if not isinstance(record, dict):
            continue
        finding_id = record.get("finding_id")
        artifact_dir = record.get("artifact_dir")
        if not finding_id or not artifact_dir:
            continue
        try:
            owned.add((finding_id, Path(artifact_dir).resolve()))
        except OSError:
            continue
    return owned
