# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Deterministic gates over a proposed chain that only drop or annotate it, never promote."""
from __future__ import annotations

import itertools
import re
from functools import cache
from pathlib import Path

from vvaharness.models import VulnClass
from vvaharness.models.vocab import SEV_RANK
from vvaharness.pipeline.stages.s8 import facts as _facts
from vvaharness.report.cwe import cwe_name
from vvaharness.util.counters import COUNTERS

# Broader tells ("even if", bare "either") fire on ordinary prose; the narrow set keeps the real hedges
_HEDGE_RX = re.compile(
    r"(?i)\b(even without|future maintainer|alternatively\b)")

_HEDGE_NOTE = ("_Note: this chain's own narrative suggests its steps may be "
               "independently sufficient rather than strictly sequential — "
               "read the path as a grouping unless each step is needed._")


def location_key(ranked, step: int) -> tuple[str, int]:
    """The one-code-fact key: two findings at one (file, line_start) are one fact."""
    f = ranked[step].finding
    # Not line_end (defaults 0, s6 rewrites it); whole-range overlap flags sound chains
    return (f.file, f.line_start)


def collapse_same_location(steps: list[int], ranked) -> tuple[list[int], int]:
    """Drop hops repeating an earlier hop's location, returning (kept, dropped_count)."""
    seen: set[tuple[str, int]] = set()
    kept: list[int] = []
    for s in steps:
        loc = location_key(ranked, s)
        if loc in seen:
            continue
        seen.add(loc)
        kept.append(s)
    return kept, len(steps) - len(kept)


def resolve_citation(repo_root: str | Path, file: str, line: int) -> bool:
    """Whether *file*:*line* is a real line of a real file inside the repo."""
    if not file or line < 1:
        return False
    # resolve() raises RuntimeError on a symlink loop; unguarded it discards the whole enrichment
    try:
        root = Path(repo_root).resolve()
    except (OSError, ValueError, RuntimeError):
        return False

    def _ok(rel: str) -> bool:
        # _file_lines does containment and caches per run: one read per file, not per link
        return len(_facts._file_lines(root, rel)) >= line

    # Only these deterministic rewrites: anything else unresolved IS the fabrication signal wanted
    candidates = [file]
    stripped = file.lstrip("/\\")
    if stripped != file:
        candidates.append(stripped)
    if file.startswith(("/", "\\")):
        try:
            candidates.append(str(Path(file).resolve().relative_to(root)))
        except (OSError, ValueError, RuntimeError):
            pass
    for cand in (file, stripped):
        head, _, tail = cand.partition("/")
        if tail and head == root.name:
            candidates.append(tail)
    return any(_ok(c) for c in dict.fromkeys(candidates))


# Awkward spellings, not new evidence: "app.py:42", a pasted browser URL, or a Windows drive path
_PACKED_LINE_RX = re.compile(r":(\d+)\s*$")
_URL_PATH_RX = re.compile(r"^\w+://[^/]+(/.*)$")


def _unpacked_citation(file: str, line: int) -> tuple[str, int]:
    """One best-effort unpacking of *file*/*line*, or the input unchanged."""
    candidate = file or ""
    m = _URL_PATH_RX.match(candidate)
    if m:
        candidate = m.group(1).lstrip("/")
    if "\\" in candidate:
        candidate = re.sub(r"^[A-Za-z]:\\", "", candidate).replace("\\", "/")
    # Trust a trailing :LINE only when `line` is 0 or agrees; a digit-ending filename must not win
    pm = _PACKED_LINE_RX.search(candidate)
    if pm and (not line or line == int(pm.group(1))):
        candidate, line = candidate[:pm.start()], int(pm.group(1))
    return candidate, line


def resolved_citation(repo_root: str | Path, file: str,
                      line: int) -> tuple[bool, str, int]:
    """``(ok, file, line)`` — the citation as given, or an unpacked spelling that resolves."""
    # Stripping happens here, once, so strippers and non-strippers get the same verdict
    file = (file or "").strip()
    if resolve_citation(repo_root, file, line):
        return True, file, line
    cand_file, cand_line = _unpacked_citation(file, line)
    if (cand_file, cand_line) != (file, line) and resolve_citation(
            repo_root, cand_file, cand_line):
        return True, cand_file, cand_line
    # Text kept, line zeroed: a renderer reads a truthy line as "checked evidence"
    return False, file, 0


def link_ok(link_evidence, steps,
            repo_root: str | Path) -> tuple[bool, int, int]:
    """``(ok, resolved, hops)`` — the one canonical link-coverage predicate, rendered as "N/M"."""
    links = list(link_evidence or [])
    # steps must be the HYDRATED path (else "1/2" beside one hop); resolved uncapped so "3/2" shows
    hops = max(len(steps) - 1, 0)
    # resolved_citation, not resolve_citation: same basis the persisted link evidence ships on
    resolved = sum(1 for ln in links
                   if resolved_citation(repo_root, ln.file, ln.line)[0])
    return len(links) >= hops and resolved == len(links), resolved, hops


# Prefix-only: a whole-comment line ("# TODO: sanitize") is intention; detect/matcher.py is sibling
_COMMENT_PREFIXES = ("#", "//", "/*", "*", "<!--")


def _line_text(repo_root: str | Path, file: str, line: int) -> str | None:
    """The cited line's text, or None when it cannot be read."""
    # Only plain and leading-slash spellings, never more permissive than the citation gate
    lines = _facts._file_lines(repo_root, file.lstrip("/\\"))
    return lines[line - 1] if 1 <= line <= len(lines) else None


def cited_comment_lines(link_evidence, repo_root: str | Path) -> list[str]:
    """``["file:line", …]`` for citations whose line is wholly a comment."""
    out: list[str] = []
    for ln in (link_evidence or []):
        text = _line_text(repo_root, ln.file, ln.line)
        if text is None:
            continue
        if text.strip().startswith(_COMMENT_PREFIXES):
            out.append(f"{ln.file}:{ln.line}")
    return out


def clean_controls(values) -> list[str]:
    """Strip/dedupe a model-supplied control list, dropping blank entries."""
    # A blank blocked_by_controls entry would exempt the chain from the severity floor
    return list(dict.fromkeys(
        v.strip() for v in (values or []) if isinstance(v, str) and v.strip()))


def clean_preconditions(chain) -> list[str]:
    """The chain's stated preconditions, stripped and deduplicated."""
    # These render as **Requires:**, never blocked_by_controls: folding them reads as mitigation
    pre = clean_controls(getattr(chain, "preconditions", []))
    if pre:
        COUNTERS.bump("s8_chain_gated")
    return pre


def annotate_hedges(narrative: str) -> tuple[str, bool]:
    """``(narrative, hedged)`` — the bundle-not-sequence note appended when it hedges."""
    # Unconditional, not gated by chain_quality_checks; the verdict rides back for reuse
    if not (narrative and _HEDGE_RX.search(narrative)):
        return narrative, False
    COUNTERS.bump("s8_chain_narrative_hedged")
    return f"{narrative}\n\n{_HEDGE_NOTE}".strip(), True


# Annotate-only: control_absence (not a CWE list) flags many chains, so it notes rather than drops


def hardening_steps(steps: list[int], ranked) -> list[int]:
    """Positions in *steps* that are NON-TERMINAL stamped control absences."""
    # The terminal step is exempt: a chain whose OUTCOME is a missing control is legitimate
    return [i for i, s in enumerate(steps[:-1])
            if getattr(ranked[s].finding, "control_absence", False)]


_HARDENING_NOTE = ("Step(s) {pos} of this path describe a missing control "
                   "rather than a capability the attacker carries forward, so "
                   "the path may be a grouping of related findings rather "
                   "than a sequence.")

_LINK_COVERAGE_NOTE = ("{n} of {m} step-to-step hop(s) carry a citation this "
                       "scan could check.")

_COMMENT_CITATION_NOTE = ("Link evidence cites a line that is wholly a comment "
                          "({where}), which documents an intention rather than "
                          "the mechanism.")

_TITLE_DIVERGENCE_NOTE = ('The chain title names "{term}", which none of its '
                          "steps covers.")

# Formatted after the caller's sort: chain ordinals do not exist before it, so an early number lies
NEAR_DUPLICATE_NOTE = ("Ends at the same final step (finding #{n}) as "
                       "{others} other proposed path(s), reached from a "
                       "different entry point.")


_HEAD_MIN_CHARS = 7


def _tokens(text: str) -> list[str]:
    """Lowercase alphabetic tokens, in order."""
    return [t for t in re.split(r"[^A-Za-z]+", (text or "").lower()) if t]


def _words(text: str) -> set[str]:
    """The same tokens as a set."""
    return set(_tokens(text))


@cache
def _class_phrases() -> tuple[set[str], set[str]]:
    """``(phrases, head_nouns)`` naming a weakness, derived from VulnClass only."""
    phrases: set[str] = set()
    heads: set[str] = set()
    for member in VulnClass:
        # OTHER is the fold target for anything unrecognised, so it would flag the word "other"
        if member is VulnClass.OTHER:
            continue
        tokens = _tokens(member.value)
        if not tokens:
            continue
        if len(tokens) > 1:
            phrases.add(" ".join(tokens))
        # Short heads are ordinary English ("free", "leak", "flaw"); this ships, so a miss beats FP
        if len(tokens) == 1 or len(tokens[-1]) >= _HEAD_MIN_CHARS:
            heads.add(tokens[-1])
    return phrases, heads


def title_divergence(title: str, steps: list[int], ranked) -> str:
    """The first weakness class the *title* names that no step covers, or ''."""
    phrases, heads = _class_phrases()
    covered: set[str] = set()
    for s in steps:
        f = ranked[s].finding
        covered |= _words(getattr(f.vuln_class, "value", str(f.vuln_class)))
        covered |= _words(getattr(f, "vuln_class_label", ""))
        # VulnClass has no XSS/SSRF/traversal/authz, vuln_class_label is unset: title+CWE carry it
        covered |= _words(getattr(f, "title", ""))
        # The MITRE name spells it out ("CWE-89" -> "SQL Injection"); the token gives only "cwe"
        covered |= _words(cwe_name(getattr(f, "cwe", "")))
        covered |= _words(Path(f.file or "").name)
    title_words = _words(title)
    flat = " ".join(_tokens(title))
    for phrase in sorted(phrases):
        if " " in phrase and phrase in flat and not set(phrase.split()) & covered:
            return phrase
    for head in sorted(heads):
        if head in title_words and head not in covered:
            return head
    return ""


def quality_annotations(chain, steps: list[int], ranked,
                        repo_root: str | Path, *, links_ok: bool,
                        resolved: int, hops: int,
                        hardening: list[int]) -> list[str]:
    """The deterministic quality notes for one chain, worst-first, one per failed check."""
    # One entry per CHECK (the report counts them); inputs passed in, not recomputed; counters/site
    out: list[str] = []
    if hardening:
        COUNTERS.bump("s8_chain_hardening_step", len(hardening))
        out.append(_HARDENING_NOTE.format(
            pos=", ".join(str(p + 1) for p in hardening)))
    links = list(getattr(chain, "link_evidence", []) or [])
    if not links_ok:
        COUNTERS.bump("s8_chain_link_coverage_short")
        # Two distinct defects: wrong COUNT vs unresolvable citation; empty is a third thing
        if links:
            COUNTERS.bump("s8_chain_link_evidence_missing"
                          if len(links) != hops
                          else "s8_chain_citation_unresolved")
        out.append(_LINK_COVERAGE_NOTE.format(n=resolved, m=hops))
    comment_cites = cited_comment_lines(links, repo_root)
    if comment_cites:
        COUNTERS.bump("s8_chain_cited_line_comment", len(comment_cites))
        # Capped: an oversized evidence list must not balloon one note.
        out.append(_COMMENT_CITATION_NOTE.format(
            where=", ".join(comment_cites[:3])))
    term = title_divergence(getattr(chain, "title", ""), steps, ranked)
    if term:
        COUNTERS.bump("s8_chain_title_divergence")
        out.append(_TITLE_DIVERGENCE_NOTE.format(term=term))
    return out


# ── the severity gate ────────────────────────────────────────────────────────


def lift_allowed(links_ok: bool, hardening: list[int], hedged: bool) -> bool:
    """Whether this chain has earned a severity ABOVE what it was rated."""
    # Without this every chain inherited the strongest hop's CRITICAL; never LOWERS, only withholds
    return links_ok and not hardening and not hedged


# ── near-duplicate chains ────────────────────────────────────────────────────


def _survivor_key(chain) -> tuple:
    """Order among chains sharing one step tuple: strongest, best-evidenced, title."""
    # Content-derived, never reply position, so the survivor is order-independent
    return (SEV_RANK[chain.severity], -len(chain.link_evidence), chain.title)


def dedup_chains(chains: list) -> tuple[list, int, list[tuple[int, int]]]:
    """``(kept, merged_count, related_pairs)`` — merge identical chains, relate near ones."""
    # Equal ordered step lists only: zero false-merge risk
    best: dict[tuple, int] = {}
    for i, c in enumerate(chains):
        key = tuple(c.steps)
        first = best.get(key)
        if first is None or _survivor_key(c) < _survivor_key(chains[first]):
            best[key] = i
    kept = [chains[i] for i in sorted(best.values())]

    # Chains that share a terminal step from a different entry are related, never merged
    related: list[tuple[int, int]] = []
    for (a, ca), (b, cb) in itertools.combinations(enumerate(kept), 2):
        # The terminal step satisfies "shares a step", so no separate intersection test is needed
        if ca.steps[-1] != cb.steps[-1] or ca.steps[0] == cb.steps[0]:
            continue
        related.append((a, b))
    return kept, len(chains) - len(kept), related


# ── unpromoted link claims ───────────────────────────────────────────────────


def unpromoted_links(claims: list[tuple[int, int]], chains: list,
                     ranked) -> list[tuple[int, int]]:
    """The (owner, target) claims no shipped chain carries, by code location, owner before target."""
    # Location, not index: a chain through the target's same-file:line twin does carry the
    # claim; non-adjacent coverage counts (annotate-only, precision wins); direction matters:
    # [f1, f0] does not cover "f0 feeds f1"; a same-location pair is one code fact, not a link
    covered = {(location_key(ranked, a), location_key(ranked, b))
               for c in chains
               for i, a in enumerate(c.steps) for b in c.steps[i + 1:]}
    keyed = ((o, t, location_key(ranked, o), location_key(ranked, t)) for o, t in claims)
    return [(o, t) for o, t, lo, lt in keyed if lo != lt and (lo, lt) not in covered]
