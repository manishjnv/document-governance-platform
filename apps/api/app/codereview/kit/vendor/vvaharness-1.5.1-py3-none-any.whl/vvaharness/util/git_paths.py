# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The single answer to "is this path version-control metadata?" for every write gate."""
from __future__ import annotations

import itertools
import os
from functools import cache
from pathlib import PurePosixPath

GIT_DIR = ".git"


def is_git_metadata(path: str | os.PathLike[str]) -> bool:
    """True when any component of *path* is ``.git``, case-folded (macOS/Windows fold case)."""
    parts = PurePosixPath(os.fspath(path).replace("\\", "/")).parts
    return any(part.casefold() == GIT_DIR for part in parts)


@cache
def git_dir_spellings() -> tuple[str, ...]:
    """Every letter-case spelling of ``.git``, for matchers that cannot fold case."""
    letters = [(c.lower(), c.upper()) for c in GIT_DIR[1:]]
    return tuple("." + "".join(combo) for combo in itertools.product(*letters))
