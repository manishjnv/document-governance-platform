# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Run-level scan manifest (vvaharness).

Captures tool version, active model roles, config hash, target git SHA, and
timing for each run, written to ./run_manifest_YYYYMMDDTHHMMSSZ.json, plus the per-stage
duration/token/dollar table composed from the pipeline's process-global
recorders (util.stage_telemetry.STAGES, util.tokens.TOKENS, and — for a
--resume'd stage whose checkpoint carries a provenance envelope —
util.stage_telemetry.CACHED_PROVENANCE, so a cached stage's row names the
model/via/config it was ACTUALLY produced under instead of blending into
this run's role_models/TOKENS). The manifest is the only output that sees
the FULL run: the markdown report is rendered before s10/s11 by design, so
their spend appears here and nowhere else.
"""
from __future__ import annotations

import contextlib
import datetime as _dt
import hashlib
import json
import os
import re
import subprocess
import time
import types
from datetime import datetime
from pathlib import Path

from vvaharness.util import console

# Flags whose VALUE is a secret: case-insensitive substring; bare "key" excluded (--keep-clones)
_SECRET_FLAG_RX = re.compile(
    r"(?i)(token|password|passwd|pwd|secret|api[_-]?key|access[_-]?key"
    r"|client[_-]?secret|auth|credential|bearer|private[_-]?key)")


_RUN_MANIFEST_STEM = "run_manifest"


def _manifest_ts_from_started(started_iso: str) -> str:
    """Return the UTC timestamp token used in default run-manifest names."""
    try:
        dt = _dt.datetime.fromisoformat(started_iso.replace("Z", "+00:00"))
    except Exception:
        dt = _dt.datetime.now(_dt.UTC)
    return dt.astimezone(_dt.UTC).strftime("%Y%m%dT%H%M%SZ")


def _default_manifest_dest(started_iso: str, cwd: Path | None = None) -> Path:
    """Reserve a timestamped manifest path in cwd, so two scans racing on one timestamp never share a name."""
    root = cwd or Path.cwd()
    ts = _manifest_ts_from_started(started_iso)
    i = 0
    while True:
        suffix = "" if i == 0 else f"_{i:02d}"
        candidate = root / f"{_RUN_MANIFEST_STEM}_{ts}{suffix}.json"
        try:
            os.close(os.open(candidate, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644))
            return candidate
        except FileExistsError:
            i += 1


def _scrub_argv(argv: list[str]) -> list[str]:
    """Redact secret-bearing values from a captured argv before it persists to run_manifest.json (defense-in-dep..."""
    out: list[str] = []
    i, n = 0, len(argv)
    while i < n:
        tok = argv[i]
        if tok.startswith("-") and "=" in tok:                 # --flag=VALUE
            flag, _eq, val = tok.partition("=")
            if val and _SECRET_FLAG_RX.search(flag):
                out.append(f"{flag}=***")
                i += 1
                continue
        if (tok.startswith("-") and _SECRET_FLAG_RX.search(tok)  # --flag VALUE
                and i + 1 < n and not argv[i + 1].startswith("-")):
            out.append(tok)
            out.append("***")
            i += 2
            continue
        out.append(tok)
        i += 1
    # Shape-based second pass — catches secret-looking values regardless of flag.
    from vvaharness.report.redact import redact_tree
    return redact_tree(out)


def _metadata_failure(phase: str, error: Exception) -> None:
    try:
        from vvaharness.report.redact import redact

        console.write(f"  [manifest] {phase}: {type(error).__name__}: {redact(str(error))}")
    except Exception:
        pass


def _git_sha(args: list[str]) -> str | None:
    repo = None
    for i, a in enumerate(args):
        if a == "--repo" and i + 1 < len(args):
            repo = args[i + 1]
        elif a.startswith("--repo="):
            repo = a.split("=", 1)[1]
    if not repo:
        return None
    # --repo is data: validated here pre-orchestrator, cwd= not -C; hardening, not a live exploit
    try:
        repo_dir = Path(repo).resolve()
        if not repo_dir.is_dir():
            return None
    except (OSError, ValueError):
        return None
    try:
        out = subprocess.run(["git", "rev-parse", "HEAD"], cwd=str(repo_dir),
                             capture_output=True, text=True, timeout=10)
        if out.returncode != 0:
            _metadata_failure("git revision unavailable", RuntimeError(f"git exited {out.returncode}"))
            return None
        return out.stdout.strip() or None
    except (OSError, subprocess.SubprocessError, UnicodeError) as error:
        _metadata_failure("git revision unavailable", error)
        return None
    except Exception as error:
        _metadata_failure("unexpected git metadata failure", error)
        return None


# Mirrors config_paths' role list (incl. dead s0 callgraph); kept local to avoid the heavy import
_MODEL_ROLES = ("graph_annotate", "callgraph_creation", "autoexclude",
                "preprocess", "threatmodel", "decompose", "deepdive", "verify",
                "dedup", "chain", "remediate", "validate")
# EV omitted by design, N sub-roles recorded below; test_manifest_covers_every_top_level_model_role


# Only via:deepagents picks vendor per model; never heuristic a fixed via — a name is not a route
_FIXED_VIA_ROUTES = {"cli": "anthropic", "sdk": "anthropic", "openai": "openai"}


def _resolved_route(via: str, model_id: str, provider: str | None) -> str | None:
    """Return the vendor route this role's calls actually reach."""
    fixed = _FIXED_VIA_ROUTES.get(via)
    if fixed is not None:
        return fixed
    if via == "deepagents":
        # Import-light: registry eager-imports cli backend; _models() swallows errors → models: {}
        from vvaharness.backends.harness.provider_routing import routes_to_anthropic
        return "anthropic" if routes_to_anthropic(model_id, provider) else "openai"
    return None


#: The one via that selects its vendor and transport per model.
_DEEPAGENTS_VIA = "deepagents"

#: The fixed Chat-Completions route that hops to Responses only on a pin or a learned conflict.
_OPENAI_VIA = "openai"


def _resolved_transport_openai(model_id: str, override: bool | None) -> str:
    """`via: openai`'s one route-level hop: an explicit pin, or a learned tools conflict.

    `provider=None` on the resolver call mirrors the hop's own call shape (the openai
    route has no vendor-selecting provider; the role's recorded provider never changes it).
    A learned Chat-only failure vetoes even an explicit pin, mirroring the route's own check.
    """
    from vvaharness.backends.harness.provider_routing import (
        TRANSPORT_CHAT_COMPLETIONS,
        TRANSPORT_RESPONSES,
    )
    from vvaharness.backends.llm.models import EFFORT_REJECTIONS, TRANSPORT_MEMORY
    if model_id in TRANSPORT_MEMORY.chat_only:
        return TRANSPORT_CHAT_COMPLETIONS
    if override is True:
        return TRANSPORT_RESPONSES
    from vvaharness.backends.harness.deepagents.options.model_building import (
        resolve_use_responses_api,
    )
    if (model_id in EFFORT_REJECTIONS.tools_off
            and resolve_use_responses_api(model_id, None, override)):
        return TRANSPORT_RESPONSES
    return TRANSPORT_CHAT_COMPLETIONS


def _resolved_transport(via: str, model_id: str, provider: str | None,
                        node: object) -> str | None:
    """Return the OpenAI-branch transport this role's calls actually use.

    deepagents picks its own vendor and transport per model, so it is read
    through the same `resolve_use_responses_api` the client builds with —
    a model forced to Chat (a learned or pinned Chat-only model) reports
    that, not the stale "always Responses" default. `via: openai` is a
    fixed Chat Completions route UNLESS pinned on or a learned tools-conflict
    for this model hops it to Responses (`_resolved_transport_openai`).
    """
    override = getattr(node, "use_responses_api", None)
    if via == _OPENAI_VIA:
        return _resolved_transport_openai(model_id, override)
    if via != _DEEPAGENTS_VIA:
        return None
    from vvaharness.backends.harness.deepagents.options.model_building import (
        resolve_use_responses_api,
    )
    from vvaharness.backends.harness.provider_routing import (
        TRANSPORT_CHAT_COMPLETIONS,
        TRANSPORT_RESPONSES,
    )
    allowed = resolve_use_responses_api(model_id, provider, override)
    return (None if allowed is None
            else TRANSPORT_RESPONSES if allowed else TRANSPORT_CHAT_COMPLETIONS)


def _effective_effort(cfg: object, name: str) -> str | None:
    """The effort tier actually driving *name*'s calls, or None when it has none."""
    from vvaharness.orchestrator.config_paths import role_effort
    return role_effort(cfg, name)


def _models(cfg_path: Path) -> dict:
    phase = "could not load model roles"
    try:
        from vvaharness import config as config_mod
        cfg = config_mod.load(cfg_path)
        phase = "could not extract model roles"
        roles = {}
        for name in _MODEL_ROLES:
            r = getattr(cfg.models, name, None)
            is_validate = name == "validate"
            if is_validate and r is not None:
                r = getattr(r, "orchestrator", None)
            if r is not None:
                model_id = getattr(r, "id", str(r))
                # null provider = unpinned (manifest null-for-absent); route = the vendor reached
                provider = getattr(r, "provider", None)
                # `or "cli"` mirrors registry.resolve() coercing a falsy via (absent or null) to cli
                via = getattr(r, "via", None) or "cli"
                # Pre-normalize capture: declared_via is what the profile said, not the route
                declared_via = via
                if is_validate:
                    # Runtime's normalizer: models.validate cannot disagree with validation_panel
                    from vvaharness.validation.config.validate_role import (
                        normalize_validate_backend,
                    )
                    via, provider = normalize_validate_backend(via, provider)
                use_responses_api = getattr(r, "use_responses_api", None)
                roles[name] = {
                    "id": model_id,
                    "via": via,
                    "provider": provider,
                    "resolved_route": _resolved_route(via, model_id, provider),
                    "resolved_transport": _resolved_transport(
                        via, model_id, provider, r),
                    "use_responses_api": (
                        use_responses_api
                        if isinstance(use_responses_api, bool) else None),
                    "declared_via": declared_via,
                    "effective_effort": _effective_effort(cfg, name),
                }
        # EV roles nest, so the loop misses them; dotted names, else EV stamps have no known author
        ev = getattr(cfg.models, "exploit_verification", None)
        if ev is not None:
            from vvaharness.exploit_verification.settings import EV_MODULES, ev_effort
            for sub_name in EV_MODULES:
                node = getattr(ev, sub_name, None)
                if node is None:          # optional by design (no attacker = no loop)
                    continue
                # Same shape and `or "cli"` coercion as the loop above, so EV roles audit alike
                model_id = getattr(node, "id", str(node))
                provider = getattr(node, "provider", None)
                via = getattr(node, "via", None) or "cli"
                use_responses_api = getattr(node, "use_responses_api", None)
                roles[f"exploit_verification.{sub_name}"] = {
                    "id": model_id,
                    "via": via,
                    "provider": provider,
                    "resolved_route": _resolved_route(via, model_id, provider),
                    "resolved_transport": _resolved_transport(
                        via, model_id, provider, node),
                    "use_responses_api": (
                        use_responses_api
                        if isinstance(use_responses_api, bool) else None),
                    # == via always (only validate normalizes); shape parity, test_manifest.py
                    "declared_via": via,
                    # step6_exploit_verification.<role>.effort, via the dispatch sites' own helper
                    "effective_effort": ev_effort(cfg, sub_name),
                }
        return roles
    except Exception as e:
        _metadata_failure(phase, e)
        return {}


def _model_spec(role) -> dict | None:
    if role is None:
        return None
    spec = {"id": getattr(role, "id", str(role)),
            "via": getattr(role, "via", "cli")}
    provider = getattr(role, "provider", None)
    if provider:
        spec["provider"] = provider
    use_responses_api = getattr(role, "use_responses_api", None)
    if isinstance(use_responses_api, bool):
        spec["use_responses_api"] = use_responses_api
    return spec


_PANEL_ORCHESTRATOR = "orchestrator"
_PANEL_PERSONAS = ("security_architect", "penetration_tester",
                   "cross_repo_analyzer")


def _panel_specs(validate: object) -> dict:
    """Collect the present models.validate role specs, orchestrator first."""
    specs = {}
    orch = getattr(validate, _PANEL_ORCHESTRATOR, None)
    if orch is not None:
        specs[_PANEL_ORCHESTRATOR] = orch
    for name in _PANEL_PERSONAS:
        spec = getattr(validate, name, None)
        if spec is not None:
            specs[name] = spec
    return specs


def _panel_entry(spec: object, via: str, provider: str | None,
                  declared_via: str) -> dict:
    model_id = getattr(spec, "id", str(spec))
    return {
        "id": model_id,
        "via": via,
        "provider": provider,
        "resolved_route": _resolved_route(via, model_id, provider),
        # Pre-normalization via, so `via: openai` silently rerouted to deepagents stays visible
        "declared_via": declared_via,
    }


def _validation_panel(validate: object) -> dict:
    """Serialize models.validate with every entry on the orchestrator's route."""
    # Personas are orchestrator subagents, so persona via/provider is dead config, never read here
    if validate is None:
        return {}
    specs = _panel_specs(validate)
    orch = specs.get(_PANEL_ORCHESTRATOR)
    if orch is None:
        # No orchestrator: validation cannot run and no route is derivable.
        return {name: {"id": getattr(spec, "id", str(spec))}
                for name, spec in specs.items()}
    # Lazy import for the same reason as provider_routing in _resolved_route.
    from vvaharness.validation.config.validate_role import (
        normalize_validate_backend,
    )
    # `or "cli"`: mirror registry.resolve()'s coercion of a falsy via (_models).
    via = getattr(orch, "via", None) or "cli"
    # Pre-normalize capture (declared_via, same convention as _models())
    declared_via = via
    via, provider = normalize_validate_backend(via, getattr(orch, "provider", None))
    return {name: _panel_entry(spec, via, provider, declared_via)
            for name, spec in specs.items()}


def _pick(section, *names: str) -> dict:
    return {name: getattr(section, name, None) for name in names}


def _input_fingerprint(value, config_dir: Path) -> dict | None:
    if value is None or not str(value).strip():
        return None
    configured_path = Path(str(value))
    resolved_path = configured_path if configured_path.is_absolute() else config_dir / configured_path
    return {
        "path": str(configured_path),
        "sha256": _config_sha256(resolved_path),
    }


def _effective_scan_controls(cfg_path: Path) -> dict:
    """Return the non-secret configuration that materially changes scan output."""
    try:
        from vvaharness import config as config_mod
        cfg = config_mod.load(cfg_path)
        panel = _validation_panel(getattr(cfg.models, "validate", None))

        config_dir = Path(getattr(cfg, "_config_dir", cfg_path.parent))
        inject = getattr(cfg, "inject", None)
        remediate = getattr(cfg, "step_remediate", None)
        controls = {
            "cache": _pick(cfg, "cache_markers", "cache_route", "cache_min_block_tokens"),
            "thinking": _pick(cfg, "think_in_prompt"),
            "refusals": _pick(cfg, "refusal_retries"),
            "step0": _pick(cfg.step0, "callgraph_detection",
                           "min_graph_nodes_for_gate"),
            # mode/call_graph*/max_turns/max_budget_usd removed: dead keys of the deleted engine
            "step1": _pick(cfg.step1, "auto_exclude", "auto_exclude_max_tokens",
                           "auto_exclude_protect_templates",
                           "auto_exclude_protect_key_material",
                           "auto_exclude_protect_secrets",
                           "auto_exclude_protect_client_sinks", "max_file_kb",
                           "config_dedup"),
            "step2": _pick(cfg.step2, "max_tokens", "max_threats", "baseline",
                           "max_doc_chars", "max_manifest_chars", "max_modules",
                           "max_entry_points", "max_inventory_files", "bash",
                           "max_config_reps",
                           "max_api_artefacts",
                           "max_graph_files", "max_graph_sinks", "max_graph_edges",
                           # Declared; effective = counter evidence_gate_stood_down_degenerate_graph
                           "graph_tools", "require_graph", "require_graph_rejections",
                           "empty_retry", "deadline", "replay_timeout",
                           "resume_timeout", "replay_max_tokens", "max_model_calls"),
            # step3 has no effective controls: no model call; dead `specialists` key removed
            "step4": _pick(cfg.step4, "parallel", "max_turns",
                           "line_bucket", "max_findings_per_run", "max_tokens",
                           "cwe_tools", "cwe_tool_budget", "graph_tool_budget",
                           "planning", "inline_source", "evidence_gate",
                           "evidence_gate_refusals", "skills", "effort", "require_graph", "bash",
                           "max_model_calls", "batch_size", "split_retry", "max_extra_cwes",
                           "deadline", "replay_timeout", "resume_timeout",
                           "replay_max_tokens", "allowed_tools"),
            # getattr: line_tolerance deliberately undefaulted, falls through to step7_dedup
            "step5_prefilter": _pick(getattr(cfg, "step5_prefilter", None),
                                     "line_tolerance", "sink_reanchor",
                                     "sink_reanchor_max_move_lines"),
            "step5_detectors": _pick(getattr(cfg, "step5_detectors", None),
                                     "enabled", "max_rows"),
            "step6_verify": _pick(cfg.step6_verify, "parallel", "min_confidence",
                                    "max_budget_usd", "max_turns", "allowed_tools",
                                    "batch_size", "inline_source", "graph_tools",
                                    "graph_tool_budget", "max_model_calls",
                                    "batch_wall_clock_ceiling", "batch_deadline",
                                    "replay_timeout", "resume_timeout",
                                    "replay_max_tokens", "trait_stamps",
                                    "reframe_enabled", "max_tokens", "split_retry",
                                    # Declared only; see evidence_gate_stood_down_degenerate_graph
                                    "require_graph", "evidence_gate_refusals"),
            "step7_dedup": _pick(cfg.step7_dedup, "line_tolerance", "semantic",
                                 "max_tokens", "per_sink_keep"),
            "step8": _pick(cfg.step8, "max_tokens", "timeout",
                           "max_model_calls", "max_turns", "deadline",
                           "resume_timeout", "prompt_token_budget", "severity_lift_gate",
                           "chain_quality_checks", "chain_dedup",
                           "prompt_fact_blocks", "hop_text"),
            "step9": _pick(getattr(cfg, "step9", None),
                           "duplicate_result_guard"),
            "output": _pick(getattr(cfg, "output", None), "posture_channel",
                            "emit_unreachable_appendix"),
            # Registered cli: keys only; TLS/effort unregistered by design; restricted = read jail
            "cli": _pick(getattr(cfg, "cli", None), "mcp_tools", "restricted"),
            "step_remediate": _pick(remediate, "enabled", "enforce_policy", "top_n_findings",
                                      "max_budget_usd", "max_turns", "allowed_tools"),
            "remediation_model": _model_spec(getattr(cfg.models, "remediate", None)),
            "step_validate": _pick(cfg.step_validate, "enabled", "effort", "max_turns",
                                     "max_budget_usd", "max_findings", "timeout",
                                     "allowed_tools"),
            "validation_panel": panel,
            "input_hashes": {
                "cve_file": _input_fingerprint(getattr(inject, "cve_file", None), config_dir),
                "controls_file": _input_fingerprint(getattr(inject, "controls_file", None), config_dir),
                "cmdb_file": _input_fingerprint(getattr(inject, "cmdb_file", None), config_dir),
                "policy_file": _input_fingerprint(getattr(remediate, "policy_file", None), config_dir),
                "playbook_file": _input_fingerprint(getattr(remediate, "playbook_file", None), config_dir),
            },
        }
        return controls
    except Exception as e:
        console.write(
            f"  [manifest] could not capture effective scan controls from {cfg_path}: {e}"
        )
        return {}


def _pricing_file(cfg_path: Path) -> str | None:
    try:
        from vvaharness import config as config_mod
        cfg = config_mod.load(cfg_path)
        return getattr(getattr(cfg, "pricing", None), "file", None)
    except Exception as e:
        console.write(f"  [manifest] could not read pricing.file from {cfg_path}: {e}")
        return None


def _telemetry_fields(cfg_path: Path, models: dict) -> dict:
    """Compose the per-stage duration/token/cost fields for this run."""
    # Deferred imports + wrap: telemetry failure degrades the section, never loses the manifest
    try:
        from vvaharness.util import stage_telemetry
        from vvaharness.util.pricing import load_pricing_cached
        from vvaharness.util.tokens import TOKENS
        role_models = {role: spec["id"] for role, spec in models.items()
                       if isinstance(spec, dict) and spec.get("id")}
        # load_pricing_cached: batch runs and util/metrics.py re-resolve pricing.file; read once
        section = stage_telemetry.compose_stage_section(
            stage_telemetry.STAGES.snapshot(), TOKENS.snapshot(),
            role_models, load_pricing_cached(_pricing_file(cfg_path)),
            # A --resume'd stage reports the model/tokens it was ACTUALLY produced under
            stage_telemetry.CACHED_PROVENANCE.snapshot())
        return dict(section)
    except Exception as e:
        console.write(f"  [manifest] WARNING: per-stage telemetry unavailable: {e}")
        return {}


def _config_sha256(cfg_path: Path) -> str | None:
    if not cfg_path.exists():
        return None
    try:
        return hashlib.sha256(cfg_path.read_bytes()).hexdigest()
    except OSError as e:
        console.write(f"  [manifest] could not hash config {cfg_path}: {e}")
        return None
def _ev_collection() -> Path | None:
    """The configured EV collection path, or ``None``."""
    # EV's own resolver so manifest and run agree on "configured"; wrapped, never fatal
    try:
        from vvaharness.exploit_verification.options import collection_path
        path = collection_path()
        return Path(path) if path else None
    except Exception as e:                      # noqa: BLE001 — reporting, never fatal
        console.write(f"  [manifest] could not read EV_API_COLLECTION: {e}")
        return None


def _refresh_resolved_transport(m: dict) -> None:
    """Recompute each role's resolved_transport, so a mid-run hop is not reported stale."""
    for role in (m.get("models") or {}).values():
        node = types.SimpleNamespace(use_responses_api=role.get("use_responses_api"))
        role["resolved_transport"] = _resolved_transport(
            role["via"], role["id"], role.get("provider"), node)


class _Terminated(SystemExit):
    """A SIGTERM, converted here by `cli._dispatch`'s handler so `capture()` can record cause and stage."""


@contextlib.contextmanager
def capture(cfg_path: Path, args: list[str], out: Path | None = None):
    cfg_path = Path(cfg_path)
    from vvaharness import __version__
    ev_collection = _ev_collection()
    m: dict = {
        "tool": "vvaharness",
        "version": __version__,
        "started": datetime.now(_dt.UTC).isoformat(),
        "argv": _scrub_argv(args),
        "config_profile": str(cfg_path),
        "config_sha256": _config_sha256(cfg_path),
        # config.local.yaml silently overrides the profile, so hash it too (None when absent)
        "config_local_sha256": _config_sha256(cfg_path.with_name("config.local.yaml")),
        # From EV_API_COLLECTION, not argv; hashed (path ≠ contents); CONFIGURED, not whether EV ran
        "ev_api_collection": (str(ev_collection) if ev_collection else None),
        "ev_api_collection_sha256": (_config_sha256(ev_collection)
                                     if ev_collection else None),
        "models": _models(cfg_path),
        "effective_scan_controls": _effective_scan_controls(cfg_path),
        "target_git_sha": _git_sha(args),
        "exit_code": None,
    }
    t0 = time.time()
    try:
        yield m
    except (KeyboardInterrupt, _Terminated) as e:
        # Shell convention: SIGINT (Ctrl-C) exits 130, SIGTERM exits 143.
        if m.get("exit_code") is None:
            m["exit_code"] = 130 if isinstance(e, KeyboardInterrupt) else 143
        m["exit_cause"] = "SIGINT" if isinstance(e, KeyboardInterrupt) else "SIGTERM"
        raise
    finally:
        # Never `return` in this finally: it eats a live SystemExit; None exit_code = no write
        if m.get("exit_code") is not None:
            m["ended"] = datetime.now(_dt.UTC).isoformat()
            m["duration_sec"] = round(time.time() - t0, 1)
            try:
                _refresh_resolved_transport(m)
            except Exception:  # noqa: BLE001, S110 — best-effort, matches sibling finalize blocks
                pass
            m.update(_telemetry_fields(cfg_path, m.get("models") or {}))
            # Per-stage error counts, so the manifest shows health; best-effort, missing log = {}
            try:
                from vvaharness.util import errlog as _errlog
                errors = _errlog.counts_by_stage()
                if errors:
                    m["errors_by_stage"] = errors
            except Exception:
                pass
            # S11's rollup, omitted when S11 did not run: no validation is unknown, not clean
            try:
                from vvaharness.orchestrator import case_rollup
                rollup = case_rollup.totals()
                if rollup:
                    m["remediation"] = rollup
            except Exception:
                pass
            # Every counter verbatim: util/metrics.py's whitelist rots; notes must stay secret-free
            try:
                from vvaharness.report.redact import redact_tree
                from vvaharness.util.counters import COUNTERS as _COUNTERS
                # Cumulative, not snapshot(): a batch resets per repo, so snapshot = last repo only
                snap = _COUNTERS.snapshot_cumulative()
                if snap:
                    # Redacted like every block; a tripwire test pins masked manifest writes
                    m["counters"] = redact_tree(
                        {k: snap[k] for k in sorted(snap)})
            except Exception:
                pass
            dest = out or _default_manifest_dest(str(m.get("started") or ""))
            try:
                # default=str, and deliberately NOT a wide except: a stray Path would TypeError
                dest.write_text(json.dumps(m, indent=2, default=str),
                                encoding="utf-8")
                console.write(f"  [manifest] wrote {dest}")
            except OSError as e:
                console.write(f"  [manifest] WARNING: failed to write run manifest "
                              f"{dest}: {e}")
