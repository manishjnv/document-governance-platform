# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Repeated-identical-tool-call guard (VVAH-E009), shared by the S10 and S11 stream consumers."""

from __future__ import annotations

import contextlib
import json
from typing import TYPE_CHECKING, Final

from vvaharness.backends.harness.models import HarnessToolUse, RepeatedToolCallError

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from vvaharness.backends.harness.models import HarnessMessage

#: Identical (agent, tool, input) calls in a row before a session is aborted (VVAH-E009).
REPEAT_CALL_LIMIT: Final = 20


def _signature(msg: HarnessToolUse) -> tuple[str, str, str]:
    """(agent, tool name, canonical JSON input): two calls are identical when these match."""
    return (msg.agent or "orchestrator", msg.name,
            json.dumps(msg.input, sort_keys=True, default=str))


async def _close(source: AsyncIterator[HarnessMessage]) -> None:
    """Close *source* now rather than leaving aclose() to GC."""
    aclose = getattr(source, "aclose", None)
    if aclose is not None:
        with contextlib.suppress(Exception):
            await aclose()


async def guard_repeats(
    source: AsyncIterator[HarnessMessage], *, stage: str, route: str,
) -> AsyncIterator[HarnessMessage]:
    """Yield *source*, closing it and raising RepeatedToolCallError on a repeat loop."""
    last: tuple[str, str, str] | None = None
    streak = 0
    try:
        async for msg in source:
            if isinstance(msg, HarnessToolUse):
                signature = _signature(msg)
                streak = streak + 1 if signature == last else 1
                last = signature
                if streak >= REPEAT_CALL_LIMIT:
                    raise RepeatedToolCallError(
                        f"{signature[0]} called {msg.name} with identical input {streak} times "
                        "in a row",
                        stage=stage, route=route, tool_name=msg.name, repeats=streak,
                    )
            yield msg
    finally:
        await _close(source)
