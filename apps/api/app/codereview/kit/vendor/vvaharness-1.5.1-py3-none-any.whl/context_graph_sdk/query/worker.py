# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Manager-owned killable query-worker implementation and contract."""

from __future__ import annotations

import json
import os
import subprocess
import threading
import time
from dataclasses import dataclass
from functools import cache
from pathlib import Path
from typing import Any, Protocol, cast, runtime_checkable

from context_graph_sdk._process import ByteReader, ByteWriter, StdioChannel, spawn_stdio_worker
from context_graph_sdk.errors import (
    QueryCancelledError,
    QueryError,
    QueryProtocolError,
    QueryResourceLimitError,
    QueryTimeoutError,
    QueryValidationError,
    QueryWorkerError,
    SnapshotLifecycleError,
)
from context_graph_sdk.models import FrozenMap, freeze_properties

from .contracts import (
    QueryLimits,
    QueryWorkerRequest,
    QueryWorkerResult,
    TruncationReason,
    WorkerHealth,
    WorkerPoolLimits,
)
from .protocol import (
    decode_error,
    decode_request,
    decode_result,
    encode_error,
    encode_request,
    encode_result,
)
from .readonly import validate_readonly_cypher


@runtime_checkable
class QueryWorkerManager(Protocol):
    @property
    def limits(self) -> WorkerPoolLimits: ...

    def authorize(
        self, locator_path: str, fingerprint: str, node_count: int = 0, edge_count: int = 0
    ) -> None: ...

    def revoke(self, locator_path: str) -> None: ...

    def execute(self, request: QueryWorkerRequest) -> QueryWorkerResult: ...

    def cancel(self, request_id: str) -> bool: ...

    def health(self) -> tuple[WorkerHealth, ...]: ...

    def close(self) -> None: ...


def run_worker_loop(
    requests: ByteReader, responses: ByteWriter, maximum_request_bytes: int
) -> None:
    from context_graph_sdk.backends.arcadedb import ArcadeDBBackendFactory

    barrier_proven = False
    while True:
        try:
            # Read one byte beyond the contract so oversize requests become protocol errors.
            frame = requests.recv_bytes(maximum_request_bytes + 1)
        except EOFError:
            return
        except OSError as exc:
            responses.send_bytes(encode_error(None, "PROTOCOL_ERROR", str(exc)))
            return
        backend = None
        request_id: str | None = None
        try:
            request = decode_request(frame)
            request_id = request.request_id
            backend = ArcadeDBBackendFactory().open_project(request.snapshot)
            if not barrier_proven:
                try:
                    tuple(
                        backend.query_readonly(
                            "CREATE (:QueryWorkerWriteProbe {id:'forbidden'})",
                            freeze_properties(),
                            1,
                        )
                    )
                except Exception as exc:  # engine type is private to adapter
                    if "QueryNotIdempotentException" not in str(exc):
                        raise QueryWorkerError(
                            "engine idempotency barrier returned unexpected error"
                        ) from exc
                else:
                    raise QueryWorkerError("engine accepted mutation through readonly query path")
                barrier_proven = True

            rows: list[FrozenMap] = []
            serialized_bytes = 2
            truncated = False
            reason: TruncationReason | None = None
            for row in backend.query_readonly(
                request.cypher, request.parameters, request.limits.row_limit + 1
            ):
                row_bytes = len(
                    json.dumps(row.to_dict(), separators=(",", ":"), sort_keys=True).encode()
                )
                if len(rows) >= request.limits.row_limit:
                    truncated = True
                    reason = TruncationReason.ROWS
                    break
                if serialized_bytes + row_bytes > request.limits.byte_limit:
                    truncated = True
                    reason = TruncationReason.BYTES
                    break
                rows.append(row)
                serialized_bytes += row_bytes
            result = QueryWorkerResult(
                request.request_id,
                tuple(rows),
                serialized_bytes,
                truncated,
                reason,
            )
            response = encode_result(result)
            if len(response) > request.limits.byte_limit:
                responses.send_bytes(
                    encode_error(request_id, "RESOURCE_LIMIT", "serialized response exceeds bound")
                )
            else:
                responses.send_bytes(response)
        except QueryProtocolError as exc:
            responses.send_bytes(encode_error(request_id, "PROTOCOL_ERROR", str(exc)))
        except Exception as exc:
            responses.send_bytes(
                encode_error(request_id, "QUERY_ERROR", f"{type(exc).__name__}: {exc}")
            )
        finally:
            if backend is not None:
                backend.close()


@dataclass(frozen=True)
class _AuthorizedSnapshot:
    fingerprint: str
    node_count: int
    edge_count: int


_RECOVERY_LIMITS = QueryLimits(30.0, 1024 * 1024 * 1024, 2, 16_384)
_RSS_SAMPLE_INTERVAL_SECONDS = 0.1 if Path("/proc/self/status").exists() else 0.5


class SpawnQueryWorkerManager:
    """A max-one importable subprocess worker with hard resource enforcement."""

    def __init__(self, limits: WorkerPoolLimits | None = None) -> None:
        self._limits = limits or WorkerPoolLimits(1)
        if self._limits.max_workers != 1:
            raise ValueError("SpawnQueryWorkerManager supports exactly one query worker")
        self._connection: StdioChannel | None = None
        self._process: subprocess.Popen[bytes] | None = None
        self._authorized: dict[str, _AuthorizedSnapshot] = {}
        self._execution_lock = threading.Lock()
        self._state_lock = threading.Lock()
        self._current_request_id: str | None = None
        self._cancelled_requests: set[str] = set()
        self._closed = False

    @property
    def limits(self) -> WorkerPoolLimits:
        return self._limits

    def authorize(
        self, locator_path: str, fingerprint: str, node_count: int = 0, edge_count: int = 0
    ) -> None:
        with self._state_lock:
            self._authorized[locator_path] = _AuthorizedSnapshot(
                fingerprint, node_count, edge_count
            )

    def revoke(self, locator_path: str) -> None:
        with self._state_lock:
            self._authorized.pop(locator_path, None)

    def execute(self, request: QueryWorkerRequest) -> QueryWorkerResult:
        validate_readonly_cypher(request.cypher)
        with self._state_lock:
            authorized = request.snapshot.database_path in self._authorized
        if not authorized:
            raise QueryValidationError("snapshot locator is not authorized")
        with self._execution_lock:
            self._ensure_worker()
            with self._state_lock:
                self._current_request_id = request.request_id
            try:
                return self._exchange(request)
            finally:
                with self._state_lock:
                    self._cancelled_requests.discard(request.request_id)
                    self._current_request_id = None

    def cancel(self, request_id: str) -> bool:
        with self._state_lock:
            if self._current_request_id != request_id:
                return False
            self._cancelled_requests.add(request_id)
            process = self._process
        if process is not None:
            _terminate_process(process)
        return True

    def health(self) -> tuple[WorkerHealth, ...]:
        process = self._process
        if process is None or process.poll() is not None:
            return ()
        return (
            WorkerHealth(
                process.pid,
                _rss_bytes(process.pid) or 0,
                _thread_count(process.pid),
                _fd_count(process.pid),
            ),
        )

    def close(self) -> None:
        self._closed = True
        with self._state_lock:
            request_id = self._current_request_id
        if request_id is not None:
            self.cancel(request_id)
        with self._execution_lock:
            self._close_worker()

    def _exchange(
        self, request: QueryWorkerRequest, *, verify_on_termination: bool = True
    ) -> QueryWorkerResult:
        connection = self._connection
        process = self._process
        if connection is None or process is None:
            raise QueryWorkerError("query worker is unavailable")
        frame = encode_request(request)
        if len(frame) > self._limits.max_request_bytes:
            raise QueryProtocolError("serialized request exceeds worker pool bound")
        connection.send_bytes(frame)
        deadline = time.monotonic() + request.limits.timeout_seconds
        next_rss_sample = 0.0
        while not connection.poll(0.01):
            now = time.monotonic()
            if process.poll() is not None:
                exit_code = process.returncode
                with self._state_lock:
                    cancelled = request.request_id in self._cancelled_requests
                    self._cancelled_requests.discard(request.request_id)
                self._close_worker()
                self._verify_after_kill(request)
                if cancelled:
                    raise QueryCancelledError("query request was cancelled")
                raise QueryWorkerError(f"query worker exited unexpectedly: {exit_code}")
            with self._state_lock:
                cancellation_pending = request.request_id in self._cancelled_requests
            if cancellation_pending:
                if now < deadline:
                    continue
                self._terminate_worker()
                if verify_on_termination:
                    self._verify_after_kill(request)
                with self._state_lock:
                    self._cancelled_requests.discard(request.request_id)
                raise QueryCancelledError("query request cancellation exceeded deadline")
            if now >= next_rss_sample:
                rss = _rss_bytes(process.pid)
                next_rss_sample = now + _RSS_SAMPLE_INTERVAL_SECONDS
                if rss is None:
                    with self._state_lock:
                        cancellation_pending = request.request_id in self._cancelled_requests
                    if cancellation_pending:
                        continue
                    self._terminate_worker()
                    if verify_on_termination:
                        self._verify_after_kill(request)
                    raise QueryResourceLimitError("query worker memory could not be measured")
                if rss > request.limits.memory_bytes:
                    self._terminate_worker()
                    if verify_on_termination:
                        self._verify_after_kill(request)
                    raise QueryResourceLimitError("query worker exceeded memory limit")
            if now >= deadline:
                self._terminate_worker()
                if verify_on_termination:
                    self._verify_after_kill(request)
                raise QueryTimeoutError("query worker exceeded deadline")
        with self._state_lock:
            cancelled = request.request_id in self._cancelled_requests
            if cancelled:
                self._cancelled_requests.discard(request.request_id)
        if cancelled:
            self._close_worker()
            self._verify_after_kill(request)
            raise QueryCancelledError("query request was cancelled")
        final_rss = _rss_bytes(process.pid)
        if final_rss is None or final_rss > request.limits.memory_bytes:
            self._terminate_worker()
            if verify_on_termination:
                self._verify_after_kill(request)
            detail = "could not be measured" if final_rss is None else "exceeded memory limit"
            raise QueryResourceLimitError(f"query worker memory {detail}")
        try:
            # Keep the overflow byte so the caller receives a resource-limit error.
            frame = connection.recv_bytes(self._limits.max_response_bytes + 1)
        except (EOFError, OSError) as exc:
            self._close_worker()
            self._verify_after_kill(request)
            raise QueryWorkerError("query worker closed without a response") from exc
        error = decode_error(frame)
        if error is not None:
            _, code, message = error
            if code == "PROTOCOL_ERROR":
                raise QueryProtocolError(message)
            if code == "RESOURCE_LIMIT":
                raise QueryResourceLimitError(message)
            raise QueryError(message)
        result = decode_result(frame)
        if result.request_id != request.request_id:
            raise QueryProtocolError("worker response request_id mismatch")
        return result

    def _verify_after_kill(self, request: QueryWorkerRequest) -> None:
        if self._closed:
            return
        try:
            with self._state_lock:
                expected = self._authorized[request.snapshot.database_path]
            fingerprint_path = os.path.join(
                request.snapshot.database_path, ".context-graph-sdk-fingerprint"
            )
            with open(fingerprint_path, encoding="utf-8") as fingerprint_file:
                sidecar: object = json.load(fingerprint_file)
            if not isinstance(sidecar, dict):
                raise SnapshotLifecycleError("snapshot integrity sidecar is invalid")
            integrity = cast(dict[str, object], sidecar)
            actual_fingerprint = integrity.get("fingerprint")
            actual_nodes = integrity.get("nodeCount")
            actual_edges = integrity.get("edgeCount")
            if (
                actual_fingerprint != expected.fingerprint
                or actual_nodes != expected.node_count
                or actual_edges != expected.edge_count
            ):
                raise SnapshotLifecycleError(
                    "snapshot integrity sidecar changed after worker termination"
                )
            self._ensure_worker()
            verification = QueryWorkerRequest(
                f"verify-{request.request_id}",
                request.snapshot,
                "MATCH (n) RETURN count(n) AS nodes",
                freeze_properties(),
                _RECOVERY_LIMITS,
            )
            node_result = self._exchange(verification, verify_on_termination=False)
            edge_result = self._exchange(
                QueryWorkerRequest(
                    f"verify-edges-{request.request_id}",
                    request.snapshot,
                    "MATCH ()-[r]->() RETURN count(r) AS edges",
                    freeze_properties(),
                    _RECOVERY_LIMITS,
                ),
                verify_on_termination=False,
            )
            if (
                len(node_result.rows) != 1
                or _row_count(node_result.rows[0], "nodes") != expected.node_count
                or len(edge_result.rows) != 1
                or _row_count(edge_result.rows[0], "edges") != expected.edge_count
            ):
                self._terminate_worker()
                raise SnapshotLifecycleError(
                    "snapshot logical counts changed after worker termination"
                )
        except SnapshotLifecycleError:
            raise
        except Exception as exc:
            self._terminate_worker()
            raise SnapshotLifecycleError("snapshot recovery verification failed") from exc

    def _ensure_worker(self) -> None:
        if self._closed:
            raise QueryWorkerError("query worker manager is closed")
        if self._process is not None and self._process.poll() is None:
            return
        self._close_worker()
        process, channel = spawn_stdio_worker(
            "context_graph_sdk.query.worker_entry",
            str(self._limits.max_request_bytes),
            # The extra byte distinguishes an oversized frame from a broken channel.
            maximum_response_bytes=self._limits.max_response_bytes + 1,
        )
        self._connection = channel
        self._process = process

    def _terminate_worker(self) -> None:
        process = self._process
        if process is None:
            return
        _terminate_process(process)
        self._dispose_process()

    def _close_worker(self) -> None:
        process = self._process
        if process is None:
            return
        if self._connection is not None:
            self._connection.close_request()
        if process.poll() is None:
            try:
                process.wait(2.0)
            except subprocess.TimeoutExpired:
                process.terminate()
                try:
                    process.wait(5.0)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(2.0)
        self._dispose_process()

    def _dispose_process(self) -> None:
        if self._connection is not None:
            self._connection.close()
        self._connection = None
        self._process = None


def _terminate_process(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(5.0)
    except subprocess.TimeoutExpired:
        process.kill()
        try:
            process.wait(2.0)
        except subprocess.TimeoutExpired as exc:
            raise QueryWorkerError("query worker did not exit after kill escalation") from exc


def _row_count(row: FrozenMap, key: str) -> int:
    value = row[key]
    if not isinstance(value, int):
        raise SnapshotLifecycleError(f"snapshot {key} count is not an integer")
    return value


def _rss_bytes(pid: int | None) -> int | None:
    if pid is None:
        return None
    if os.name == "nt":
        return _windows_rss_bytes(pid)
    status = Path(f"/proc/{pid}/status")
    try:
        if status.exists():
            for line in status.read_text().splitlines():
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) * 1024
        result = subprocess.run(
            ["ps", "-o", "rss=", "-p", str(pid)],
            capture_output=True,
            text=True,
            check=False,
        )
        value = result.stdout.strip()
        return int(value) * 1024 if value.isdigit() else None
    except (OSError, ValueError, subprocess.SubprocessError):
        return None


def _thread_count(pid: int) -> int:
    if os.name == "nt":
        # Thread enumeration needs Toolhelp; zero means unavailable in best-effort health data.
        return 0
    tasks = Path(f"/proc/{pid}/task")
    try:
        if tasks.is_dir():
            return sum(1 for _ in tasks.iterdir())
        result = subprocess.run(
            ["ps", "-M", "-p", str(pid)], capture_output=True, text=True, check=False
        )
        return max(0, len(result.stdout.splitlines()) - 1)
    except (OSError, subprocess.SubprocessError):
        return 0


def _fd_count(pid: int) -> int:
    if os.name == "nt":
        # Windows has handles rather than POSIX descriptors; report the equivalent resource count.
        return _windows_handle_count(pid)
    descriptors = Path(f"/proc/{pid}/fd")
    try:
        if descriptors.is_dir():
            return sum(1 for _ in descriptors.iterdir())
        result = subprocess.run(
            ["lsof", "-p", str(pid)], capture_output=True, text=True, check=False
        )
        return max(0, len(result.stdout.splitlines()) - 1)
    except (OSError, subprocess.SubprocessError):
        return 0


@cache
def _windows_process_api() -> tuple[Any, Any, type[Any]]:
    import ctypes
    from ctypes import wintypes

    class ProcessMemoryCounters(ctypes.Structure):
        _fields_ = [
            ("cb", wintypes.DWORD),
            ("PageFaultCount", wintypes.DWORD),
            ("PeakWorkingSetSize", ctypes.c_size_t),
            ("WorkingSetSize", ctypes.c_size_t),
            ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
            ("QuotaPagedPoolUsage", ctypes.c_size_t),
            ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
            ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
            ("PagefileUsage", ctypes.c_size_t),
            ("PeakPagefileUsage", ctypes.c_size_t),
        ]

    win_dll = vars(ctypes).get("WinDLL")
    if not callable(win_dll):
        raise OSError("Windows DLL loading is unavailable")
    kernel32: Any = win_dll("kernel32", use_last_error=True)
    psapi: Any = win_dll("psapi", use_last_error=True)
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.GetProcessHandleCount.argtypes = [
        wintypes.HANDLE,
        ctypes.POINTER(wintypes.DWORD),
    ]
    kernel32.GetProcessHandleCount.restype = wintypes.BOOL
    psapi.GetProcessMemoryInfo.argtypes = [
        wintypes.HANDLE,
        ctypes.POINTER(ProcessMemoryCounters),
        wintypes.DWORD,
    ]
    psapi.GetProcessMemoryInfo.restype = wintypes.BOOL
    return kernel32, psapi, ProcessMemoryCounters


def _windows_rss_bytes(pid: int) -> int | None:
    try:
        import ctypes

        kernel32, psapi, counters_type = _windows_process_api()
        handle = kernel32.OpenProcess(0x1000, False, pid)
        if not handle:
            return None
        try:
            counters = counters_type()
            counters.cb = ctypes.sizeof(counters)
            if not psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb):
                return None
            return int(counters.WorkingSetSize)
        finally:
            kernel32.CloseHandle(handle)
    except (AttributeError, OSError, ValueError):
        return None


def _windows_handle_count(pid: int) -> int:
    try:
        import ctypes
        from ctypes import wintypes

        kernel32, _, _ = _windows_process_api()
        handle = kernel32.OpenProcess(0x1000, False, pid)
        if not handle:
            return 0
        try:
            count = wintypes.DWORD()
            if not kernel32.GetProcessHandleCount(handle, ctypes.byref(count)):
                return 0
            return int(count.value)
        finally:
            kernel32.CloseHandle(handle)
    except (AttributeError, OSError, ValueError):
        return 0
