# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Project configuration records and the manifest loading orchestrator.

Loaders are tolerant: a malformed manifest contributes nothing and never
aborts analysis. Reads are bounded and restricted to walker-discovered
relative paths inside the repository root.
"""

from __future__ import annotations

import posixpath
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass, field
from pathlib import Path

DEV_SCOPE = "dev"
TEST_SCOPE = "test"
MANIFEST_READ_BYTES = 10 * 1024 * 1024


@dataclass(frozen=True)
class DependencyRecord:
    name: str
    version: str = ""
    source: str = ""
    dev: bool = False
    scope: str = ""


@dataclass(frozen=True)
class ManifestRecord:
    name: str
    source: str
    language: str
    version: str = ""
    workspaces: tuple[str, ...] = ()


@dataclass(frozen=True)
class BuildProcessRecord:
    name: str
    source: str
    language: str
    entry_point: str


@dataclass(frozen=True)
class ResolutionSettings:
    """Import-resolution configuration parsed from root project files."""

    go_module_path: str = ""
    ts_config_base_url: str = ""
    ts_config_paths: tuple[tuple[str, tuple[str, ...]], ...] = ()
    composer_psr4: tuple[tuple[str, tuple[str, ...]], ...] = ()
    csharp_root_namespace: str = ""
    swift_targets: tuple[tuple[str, str], ...] = ()


@dataclass
class ProjectConfig:
    dependencies: list[DependencyRecord] = field(default_factory=list[DependencyRecord])
    manifests: list[ManifestRecord] = field(default_factory=list[ManifestRecord])
    build_processes: list[BuildProcessRecord] = field(default_factory=list[BuildProcessRecord])
    resolution: ResolutionSettings = field(default_factory=ResolutionSettings)
    _dependency_keys: set[tuple[str, str]] = field(default_factory=set[tuple[str, str]], repr=False)

    def add_dependency(self, dependency: DependencyRecord) -> None:
        """Record one dependency per (source, name); the first record wins.

        Loaders emit production sections before dev/peer/optional and follow
        walker file order, so first-record-wins keeps production precedence
        deterministically for every manifest family.
        """
        if not dependency.name:
            return
        key = (dependency.source, dependency.name)
        if key in self._dependency_keys:
            return
        self._dependency_keys.add(key)
        if dependency.dev and not dependency.scope:
            dependency = DependencyRecord(
                dependency.name, dependency.version, dependency.source, True, DEV_SCOPE
            )
        self.dependencies.append(dependency)

    def add_manifest(self, manifest: ManifestRecord) -> None:
        if manifest.name and manifest.source:
            self.manifests.append(manifest)

    def add_build_process(self, process: BuildProcessRecord) -> None:
        if not process.name or not process.source:
            return
        if any(
            existing.name == process.name and existing.source == process.source
            for existing in self.build_processes
        ):
            return
        self.build_processes.append(process)


class ManifestReader:
    """Bounded UTF-8 reads of normalized, walker-discovered regular files."""

    def __init__(self, root: Path, files: Sequence[str]) -> None:
        self.root = root.resolve()
        normalized_files: list[str] = []
        seen: set[str] = set()
        for relative_path in files:
            normalized = _normalize_discovered_path(relative_path)
            if normalized is None or normalized in seen:
                continue
            seen.add(normalized)
            normalized_files.append(normalized)
        self.files = tuple(normalized_files)
        self._files = frozenset(self.files)

    def by_base_name(self, *names: str) -> tuple[str, ...]:
        selected: list[str] = []
        seen: set[str] = set()
        for name in names:
            for relative in self.files:
                if posixpath.basename(relative) != name or relative in seen:
                    continue
                seen.add(relative)
                selected.append(relative)
        return tuple(selected)

    def by_extension(self, extension: str) -> tuple[str, ...]:
        return tuple(rel for rel in self.files if posixpath.splitext(rel)[1] == extension)

    def read_text(self, relative_path: str) -> str | None:
        normalized = _normalize_discovered_path(relative_path)
        if normalized is None or normalized not in self._files:
            return None
        candidate = self.root / normalized
        try:
            # The walker rejects every symlink. Recheck each component to
            # prevent a post-walk replacement from escaping this boundary.
            current = self.root
            for part in Path(normalized).parts:
                current /= part
                if current.is_symlink():
                    return None
            resolved = candidate.resolve(strict=True)
            if not resolved.is_relative_to(self.root) or not resolved.is_file():
                return None
            with resolved.open("rb") as handle:
                data = handle.read(MANIFEST_READ_BYTES + 1)
            if len(data) > MANIFEST_READ_BYTES:
                return None
            return data.decode("utf-8", errors="replace")
        except OSError:
            return None


def _normalize_discovered_path(relative_path: str) -> str | None:
    if not relative_path or "\\" in relative_path or posixpath.isabs(relative_path):
        return None
    normalized = posixpath.normpath(relative_path)
    if normalized in ("", ".", "..") or normalized.startswith("../"):
        return None
    if normalized != relative_path:
        return None
    return normalized


def workspace_display_name(root: Path, source: str) -> str:
    name = root.name
    return name if name and name not in (".", "/") else source


def workspace_member_manifest_path(manifest: ManifestRecord, workspace: str) -> str | None:
    """Map a workspace member entry to its expected member manifest path."""
    member_root = _clean_workspace_member_root(manifest.source, workspace)
    if member_root is None:
        return None
    member_file_by_language = {
        "go": "go.mod",
        "java": "pom.xml",
        "javascript": "package.json",
        "python": "pyproject.toml",
        "rust": "Cargo.toml",
    }
    if manifest.language == "csharp":
        if posixpath.splitext(member_root)[1] == ".csproj":
            return member_root
        if not member_root:
            return None
        return posixpath.normpath(
            posixpath.join(member_root, posixpath.basename(member_root) + ".csproj")
        )
    member_file = member_file_by_language.get(manifest.language)
    if member_file is None:
        return None
    return posixpath.normpath(posixpath.join(member_root, member_file))


def _clean_workspace_member_root(manifest_source: str, workspace: str) -> str | None:
    workspace = workspace.replace("\\", "/").strip()
    if not workspace or posixpath.isabs(workspace) or any(c in workspace for c in "*?["):
        return None
    manifest_dir = posixpath.dirname(manifest_source)
    cleaned = posixpath.normpath(posixpath.join(manifest_dir, workspace))
    if cleaned == ".":
        cleaned = ""
    if cleaned == ".." or cleaned.startswith("../"):
        return None
    return cleaned


def load_project_config(root: str | Path, files: Iterable[str]) -> ProjectConfig:
    from context_graph_sdk.project.manifests import ALL_LOADERS

    reader = ManifestReader(Path(root).resolve(), tuple(files))
    config = ProjectConfig()
    loaders: tuple[Callable[[ManifestReader, ProjectConfig], None], ...] = ALL_LOADERS
    for loader in loaders:
        loader(reader, config)
    return config
