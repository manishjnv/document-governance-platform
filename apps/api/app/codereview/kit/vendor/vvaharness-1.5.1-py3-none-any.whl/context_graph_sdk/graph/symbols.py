# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Symbol records to project-local graph nodes and immediately safe edges."""

from __future__ import annotations

import re

from context_graph_sdk.extractors.records import CALLABLE_LABELS, ExtractionResult, Symbol
from context_graph_sdk.models import GraphNode, LocalRelationshipType

_TEST_DIR = re.compile(
    r"(?i)(^|/)(_*test(s|ing|data|util|utils)?([_-]\w+)?_*"
    r"|[\w.-]+[_-]test(s|ing|data|util|utils)?([_-]\w+)?"
    r"|_*specs?_*|[\w.-]+[_-]specs?"
    r"|__tests__|__mocks__|__snapshots__|e2e|cypress|fixtures?|mocks?|mirage|androidtest)(/|$)"
)

_TEST_HELPER_NAMES = frozenset(
    {
        "testing.go",
        "test_helpers.go",
        "test_helper.go",
        "testutil.go",
        "testutils.go",
        "conftest.py",
        "test_helpers.rb",
        "test_helper.rb",
        "spec_helper.rb",
        "rails_helper.rb",
    }
)


def is_test_file(file_path: str) -> bool:
    lower = file_path.replace("\\", "/").lower()
    if _TEST_DIR.search(lower):
        return True
    if ".test." in lower or ".spec." in lower or ".cy." in lower:
        return True
    if lower.endswith("_test.go"):
        return True
    base = lower.rsplit("/", 1)[-1]
    if base in _TEST_HELPER_NAMES:
        return True
    if base.endswith(".go") and base.startswith("test") and base != "testing.go":
        stem = base[:-3]
        if len(stem) == 4 or (len(stem) > 4 and (stem[4].isupper() or stem[4] == "_")):
            return True
    if base.endswith(".py") and (base.startswith("test_") or base.endswith("_test.py")):
        return True
    return base.endswith("_spec.rb")


def symbol_properties(symbol: Symbol) -> dict[str, object]:
    is_test = is_test_file(symbol.file_path)
    is_exported = symbol.is_exported
    # Test functions are excluded from the public API surface even when
    # language visibility rules mark them exported.
    if is_exported and symbol.label in ("Function", "Method") and is_test:
        is_exported = False
    properties: dict[str, object] = {
        "name": symbol.name,
        "filePath": symbol.file_path,
        "startLine": symbol.start_line,
        "endLine": symbol.end_line,
        "isExported": is_exported,
        "language": symbol.language,
        "isTest": is_test,
    }
    if symbol.kind:
        properties["kind"] = symbol.kind
    if symbol.content:
        properties["content"] = symbol.content
    if symbol.doc_comment:
        properties["description"] = symbol.doc_comment
    if symbol.annotations:
        properties["annotations"] = symbol.annotations
    if symbol.signature:
        properties["signature"] = symbol.signature
    if symbol.parameter_count > 0:
        properties["parameterCount"] = symbol.parameter_count
    if symbol.return_type:
        properties["returnType"] = symbol.return_type
    return properties


def owner_relationship(symbol: Symbol) -> LocalRelationshipType:
    if symbol.label in ("Property", "Const"):
        return LocalRelationshipType.HAS_PROPERTY
    if symbol.label in CALLABLE_LABELS:
        return LocalRelationshipType.HAS_METHOD
    return LocalRelationshipType.CONTAINS


def same_file_owner(symbol: Symbol, nodes_by_name: dict[str, list[GraphNode]]) -> GraphNode | None:
    """Deterministic same-file owner lookup; owners declared in other files are not linked."""
    for candidate in nodes_by_name.get(symbol.owner_name, []):
        if candidate.properties.to_dict().get("filePath") == symbol.file_path:
            return candidate
    return None


def sorted_symbols(extraction: ExtractionResult) -> list[Symbol]:
    return sorted(
        (symbol for _, file_result in extraction.files for symbol in file_result.symbols),
        key=lambda symbol: (symbol.file_path, symbol.start_line, symbol.id),
    )
