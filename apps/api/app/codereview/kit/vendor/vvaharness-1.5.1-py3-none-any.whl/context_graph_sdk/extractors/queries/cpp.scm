; Production extraction query set for cpp
; Copyright 2026 Visa, Inc.
; Licensed under the Apache License, Version 2.0 (the "License");
; you may not use this file except in compliance with the License.
; You may obtain a copy of the License at
; http://www.apache.org/licenses/LICENSE-2.0
; Unless required by applicable law or agreed to in writing, software
; distributed under the License is distributed on an "AS IS" BASIS,
; WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
; See the License for the specific language governing permissions and
; limitations under the License.
(function_definition declarator: (function_declarator declarator: (identifier) @name)) @definition.function
(function_definition declarator: (function_declarator declarator: (qualified_identifier name: (identifier) @name))) @definition.method
(function_definition declarator: (pointer_declarator declarator: (function_declarator declarator: (identifier) @name))) @definition.function
(function_definition declarator: (pointer_declarator declarator: (function_declarator declarator: (qualified_identifier name: (identifier) @name)))) @definition.method
(function_definition declarator: (pointer_declarator declarator: (pointer_declarator declarator: (function_declarator declarator: (identifier) @name)))) @definition.function
(function_definition declarator: (reference_declarator (function_declarator declarator: (identifier) @name))) @definition.function
(function_definition declarator: (reference_declarator (function_declarator declarator: (qualified_identifier name: (identifier) @name)))) @definition.method
(function_definition declarator: (function_declarator declarator: (qualified_identifier name: (destructor_name) @name))) @definition.method
(declaration declarator: (function_declarator declarator: (identifier) @name)) @definition.function
(declaration declarator: (function_declarator declarator: (qualified_identifier name: (identifier) @name))) @definition.method
(field_declaration declarator: (function_declarator declarator: (field_identifier) @name)) @definition.method
(function_definition declarator: (function_declarator declarator: (field_identifier) @name)) @definition.method
(class_specifier name: (type_identifier) @name body: (field_declaration_list)) @definition.class
(class_specifier name: (type_identifier) @name) @definition.class
(struct_specifier name: (type_identifier) @name body: (field_declaration_list)) @definition.struct
(struct_specifier name: (type_identifier) @name) @definition.struct
(enum_specifier name: (type_identifier) @name body: (enumerator_list)) @definition.enum
(enum_specifier name: (type_identifier) @name) @definition.enum
(union_specifier name: (type_identifier) @name body: (field_declaration_list)) @definition.union
(union_specifier name: (type_identifier) @name) @definition.union
(type_definition declarator: (type_identifier) @name) @definition.typedef
(namespace_definition name: (namespace_identifier) @name) @definition.namespace
(template_declaration (class_specifier name: (type_identifier) @name)) @definition.template
(template_declaration (class_specifier name: (template_type name: (type_identifier) @name))) @definition.template
(template_declaration (function_definition declarator: (function_declarator declarator: (identifier) @name))) @definition.template
(template_declaration (function_definition declarator: (function_declarator declarator: (template_function name: (identifier) @name)))) @definition.template
(preproc_include path: (_) @import.source) @import
(call_expression function: (identifier) @call.name) @call
(call_expression function: (field_expression field: (field_identifier) @call.name)) @call
(call_expression function: (qualified_identifier name: (identifier) @call.name)) @call
(call_expression function: (template_function name: (identifier) @call.name)) @call
(new_expression type: (type_identifier) @call.name) @call
(preproc_function_def name: (identifier) @name) @definition.macro
(class_specifier name: (type_identifier) @heritage.class (base_class_clause (type_identifier) @heritage.extends)) @heritage
(class_specifier name: (type_identifier) @heritage.class (base_class_clause (access_specifier) (type_identifier) @heritage.extends)) @heritage
(field_declaration declarator: (field_identifier) @name) @definition.property
(assignment_expression left: (field_expression argument: (_) @assignment.receiver field: (field_identifier) @assignment.property) right: (_)) @assignment
(call_expression function: (qualified_identifier name: (identifier) @_fn (#match? @_fn "^(thread|async|jthread)$"))) @spawn
(call_expression arguments: (argument_list (identifier) @delegate.target)) @delegate
