# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Grammar-agnostic type-binding inference for every supported language.

Pattern-match constructs (Rust if-let, Kotlin when, C# is-patterns) are not
handled explicitly.
"""

from __future__ import annotations

import re

from tree_sitter import Node

from context_graph_sdk.extractors.analysis import (
    CLASS_NODE_TYPES,
    first_identifier_text,
    node_text,
    walk,
)
from context_graph_sdk.extractors.records import TypeBinding

_TYPE_FIELDS = ("type", "type_annotation", "return_type", "result")
_NAME_FIELDS = ("name", "declarator", "pattern", "variable", "left")

_VAR_DECL_TYPES = frozenset(
    {
        "var_spec",
        "short_var_declaration",
        "const_spec",
        "let_declaration",
        "let_statement",
        "val_declaration",
        "val_statement",
        "variable_declarator",
        "variable_declaration",
        "local_variable_declaration",
        "property_declaration",
        "pattern_binding",
        "simple_pattern_binding",
        "constant_declaration",
        "assignment",
        "const_declaration",
    }
)

_TYPE_CHILD_TYPES = frozenset(
    {
        "type_identifier",
        "predefined_type",
        "simple_type",
        "primitive_type",
        "builtin_type",
        "generic_type",
        "nullable_type",
        "user_type",
    }
)

_NEVER_TYPE_KEYWORDS = frozenset(
    {
        "extends",
        "implements",
        "with",
        "where",
        "when",
        "throw",
        "throws",
        "catch",
        "try",
        "finally",
        "switch",
        "case",
        "match",
        "select",
        "abstract",
        "virtual",
        "override",
        "async",
        "await",
        "yield",
        "package",
        "module",
        "namespace",
        "do",
        "in",
        "is",
        "not",
        "and",
        "or",
    }
)

_JSDOC_RETURN = re.compile(r"@returns?\s+\{([^}]+)\}")
_JSDOC_PARAM = re.compile(r"@param\s+\{([^}]+)\}\s+(\w+)")
_JSDOC_TYPE = re.compile(r"@type\s+\{([^}]+)\}")
_PY_TYPE_COMMENT = re.compile(r"#\s*type:\s*(\S+)")

_COMMENT_TYPES = frozenset({"comment", "line_comment", "block_comment"})

_ASSIGNMENT_TYPES = frozenset(
    {
        "assignment_expression",
        "assignment_statement",
        "assignment",
        "short_var_declaration",
        "variable_declarator",
        "let_declaration",
        "val_declaration",
        "local_variable_declaration",
    }
)


def _is_var_decl_like(lower: str) -> bool:
    if lower in _VAR_DECL_TYPES:
        return True
    if "var_" in lower or "_var" in lower:
        return True
    return (
        "declaration" in lower
        and "function" not in lower
        and "class" not in lower
        and "method" not in lower
        and "import" not in lower
        and "type_" not in lower
    )


def _is_param_like(lower: str) -> bool:
    if lower in ("parameter", "formal_parameter", "param"):
        return True
    return lower.endswith("_parameter") or lower.startswith("parameter_")


def is_type_keyword(text: str) -> bool:
    return text.lower() in _NEVER_TYPE_KEYWORDS


def is_type_name(text: str) -> bool:
    return bool(text) and text[0].isupper() and not is_type_keyword(text)


def clean_type_name(text: str) -> str:
    text = text.strip().removeprefix(":").strip()
    for opener in "<[":
        index = text.find(opener)
        if index > 0:
            text = text[:index]
    text = text.removesuffix("?").removeprefix("*").removeprefix("&")
    scope = text.rfind("::")
    if scope >= 0:
        text = text[scope + 2 :]
    dot = text.rfind(".")
    if dot >= 0:
        text = text[dot + 1 :]
    backslash = text.rfind("\\")
    if backslash >= 0:
        text = text[backslash + 1 :]
    return text.strip()


def _find_type_in_children(node: Node, source: bytes) -> str:
    for child in node.children:
        if not child.is_named:
            continue
        child_type = child.type.lower()
        if child_type in _TYPE_CHILD_TYPES:
            text = clean_type_name(node_text(child, source))
            if text:
                return text
        if "type_annotation" in child_type or child_type == "annotation":
            text = clean_type_name(node_text(child, source))
            text = text.removeprefix(":").strip()
            if text:
                return text
    return ""


def find_type_annotation(node: Node, source: bytes) -> str:
    for field in _TYPE_FIELDS:
        child = node.child_by_field_name(field)
        if child is not None:
            text = clean_type_name(node_text(child, source))
            if text and not is_type_keyword(text):
                return text
    text = _find_type_in_children(node, source)
    if text:
        return text
    for child in node.children:
        if not child.is_named:
            continue
        child_type = child.type.lower()
        if (
            "declaration" in child_type
            or "binding" in child_type
            or "pattern" in child_type
            or child_type == "type"
        ):
            text = _find_type_in_children(child, source)
            if text:
                return text
    return ""


def find_decl_name(node: Node, source: bytes) -> str:
    for field in _NAME_FIELDS:
        child = node.child_by_field_name(field)
        if child is None:
            continue
        child_type = child.type.lower()
        if "identifier" in child_type or child_type == "name":
            return node_text(child, source)
        if "declarator" in child_type:
            name_child = child.child_by_field_name("name")
            if name_child is not None:
                return node_text(name_child, source)
            return first_identifier_text(child, source)
        if "expression_list" in child_type or "pattern" in child_type:
            return first_identifier_text(child, source)
    text = first_identifier_text(node, source)
    if text:
        return text
    for child in node.children:
        if not child.is_named:
            continue
        child_type = child.type.lower()
        if "declaration" in child_type or "binding" in child_type or "pattern" in child_type:
            text = first_identifier_text(child, source)
            if text:
                return text
    return ""


def _find_owner_name(node: Node, source: bytes) -> str:
    current = node.parent
    for _ in range(20):
        if current is None:
            return ""
        current_type = current.type.lower()
        if (
            "function" in current_type
            or "method" in current_type
            or current_type in CLASS_NODE_TYPES
        ):
            name_node = current.child_by_field_name("name")
            if name_node is not None:
                return node_text(name_node, source)
            return first_identifier_text(current, source)
        current = current.parent
    return ""


def _find_assignment_target(node: Node, source: bytes) -> str:
    for field in ("left", "name", "pattern", "declarator"):
        child = node.child_by_field_name(field)
        if child is None:
            continue
        child_type = child.type.lower()
        if "identifier" in child_type:
            return node_text(child, source)
        if "declarator" in child_type or "pattern" in child_type or "expression_list" in child_type:
            return first_identifier_text(child, source)
    return first_identifier_text(node, source)


def _unwrap_single_child(node: Node) -> Node:
    if node.type.lower() in ("expression_list", "parenthesized_expression"):
        named = [child for child in node.children if child.is_named]
        if len(named) == 1:
            return named[0]
    return node


def _find_assignment_value(node: Node) -> Node | None:
    for field in ("right", "value", "initializer"):
        child = node.child_by_field_name(field)
        if child is not None:
            return _unwrap_single_child(child)
    for child in node.children:
        if child.is_named and "declarator" in child.type.lower():
            for field in ("value", "initializer", "right"):
                value = child.child_by_field_name(field)
                if value is not None:
                    return _unwrap_single_child(value)
    return None


def _constructor_type(node: Node, source: bytes) -> str:
    node_type = node.type.lower()
    if node_type in ("new_expression", "object_creation_expression"):
        for field in ("type", "constructor", "class"):
            child = node.child_by_field_name(field)
            if child is not None:
                text = node_text(child, source)
                if text and is_type_name(text):
                    return clean_type_name(text)
        for child in node.children:
            if child.type.lower() in ("type_identifier", "identifier"):
                text = node_text(child, source)
                if text and is_type_name(text):
                    return clean_type_name(text)
    if "call" in node_type:
        for field in ("function", "callee", "method"):
            child = node.child_by_field_name(field)
            if child is None:
                continue
            text = node_text(child, source)
            scope = text.find("::")
            if scope >= 0:
                text = text[:scope]
            if text and is_type_name(text):
                return clean_type_name(text)
        text = first_identifier_text(node, source)
        if text and is_type_name(text):
            return clean_type_name(text)
    if node_type == "composite_literal":
        type_node = node.child_by_field_name("type")
        if type_node is not None:
            return clean_type_name(node_text(type_node, source))
    return ""


def _comment_bindings(node: Node, source: bytes, relative_path: str) -> list[TypeBinding]:
    text = node_text(node, source)
    if not text:
        return []
    line = node.start_point.row
    bindings: list[TypeBinding] = []
    for match in _JSDOC_RETURN.finditer(text):
        bindings.append(
            TypeBinding(relative_path, "@return", clean_type_name(match.group(1)), line, "comment")
        )
    for match in _JSDOC_PARAM.finditer(text):
        bindings.append(
            TypeBinding(
                relative_path, match.group(2), clean_type_name(match.group(1)), line, "comment"
            )
        )
    for match in _JSDOC_TYPE.finditer(text):
        bindings.append(
            TypeBinding(relative_path, "@type", clean_type_name(match.group(1)), line, "comment")
        )
    for match in _PY_TYPE_COMMENT.finditer(text):
        bindings.append(
            TypeBinding(relative_path, "@type", clean_type_name(match.group(1)), line, "comment")
        )
    return bindings


def extract_type_bindings(root: Node, source: bytes, relative_path: str) -> list[TypeBinding]:
    bindings: list[TypeBinding] = []
    seen: set[tuple[str, str, int, str]] = set()

    def add(binding: TypeBinding) -> None:
        key = (binding.variable_name, binding.type_name, binding.line, binding.kind)
        if key not in seen:
            seen.add(key)
            bindings.append(binding)

    def visit(node: Node, _depth: int) -> str | None:
        lower = node.type.lower()
        if _is_var_decl_like(lower):
            type_name = find_type_annotation(node, source)
            if type_name:
                variable = find_decl_name(node, source)
                if variable:
                    add(
                        TypeBinding(
                            relative_path,
                            variable,
                            type_name,
                            node.start_point.row,
                            "declaration",
                            _find_owner_name(node, source),
                        )
                    )
        if _is_param_like(lower):
            type_name = find_type_annotation(node, source)
            if type_name:
                parameter = find_decl_name(node, source)
                if parameter and parameter not in ("self", "this", "cls"):
                    add(
                        TypeBinding(
                            relative_path,
                            parameter,
                            type_name,
                            node.start_point.row,
                            "parameter",
                            _find_owner_name(node, source),
                        )
                    )
        if lower in _ASSIGNMENT_TYPES and not find_type_annotation(node, source):
            variable = _find_assignment_target(node, source)
            value = _find_assignment_value(node) if variable else None
            if variable and value is not None:
                type_name = _constructor_type(value, source)
                if type_name:
                    add(
                        TypeBinding(
                            relative_path,
                            variable,
                            type_name,
                            node.start_point.row,
                            "constructor",
                            _find_owner_name(node, source),
                        )
                    )
        if lower in _COMMENT_TYPES:
            for binding in _comment_bindings(node, source, relative_path):
                add(binding)
        return None

    walk(root, visit)
    return _propagate_chains(bindings, root, source, relative_path)


def _propagate_chains(
    bindings: list[TypeBinding], root: Node, source: bytes, relative_path: str
) -> list[TypeBinding]:
    type_map: dict[tuple[str, str], str] = {}
    for binding in bindings:
        type_map.setdefault((binding.owner_name, binding.variable_name), binding.type_name)

    assigns: list[tuple[str, str, str, int]] = []

    def visit(node: Node, _depth: int) -> str | None:
        if node.type.lower() not in _ASSIGNMENT_TYPES:
            return None
        target = _find_assignment_target(node, source)
        if not target:
            return None
        value = _find_assignment_value(node)
        if value is None:
            return None
        if "identifier" in value.type.lower() and value.child_count == 0:
            source_name = node_text(value, source)
            if source_name and source_name != target:
                assigns.append(
                    (target, source_name, _find_owner_name(node, source), node.start_point.row)
                )
        return None

    walk(root, visit)

    for _ in range(10):
        changed = False
        for target, source_name, owner, line in assigns:
            source_type = type_map.get((owner, source_name))
            if source_type is not None and (owner, target) not in type_map:
                type_map[(owner, target)] = source_type
                bindings.append(
                    TypeBinding(relative_path, target, source_type, line, "chain", owner)
                )
                changed = True
        if not changed:
            break
    return bindings
