# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""orchestrator.config_paths — see package docstring."""
from __future__ import annotations

from pathlib import Path

from vvaharness.config import is_network_path


def _app_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _default_config() -> Path:
    cwd_cfg = Path.cwd() / "config.yaml"
    if cwd_cfg.exists():
        return cwd_cfg
    return _packaged_default()


def _packaged_default() -> Path:
    """The bundled default profile — the trusted fallback used when a config
    sourced from inside the scan target is refused."""
    return _app_root() / "config" / "profiles" / "default.yaml"


def _path_within(candidate, root) -> bool:
    """True if `candidate` resolves at or under `root` (both fully resolved).
    Used to refuse a config/.env that lives INSIDE the scanned (untrusted)
    repository, which an attacker who controls the checkout could plant."""
    try:
        Path(candidate).resolve().relative_to(Path(root).resolve())
        return True
    except (ValueError, OSError):
        return False


def _resolve_against(base: Path, p: str) -> str:
    # Refuse UNC/network input paths before they reach any loader's
    # is_file()/read — on Windows that touch leaks the user's NTLM hash over
    # SMB. Covers every injected input that funnels through here: inject.*
    # (cve/controls/cmdb), step_remediate policy/playbook (via _resolve_input),
    # and TLS ca_cert/client_cert. Check the raw value and the base-joined
    # result (a UNC base would taint an otherwise-relative path).
    if is_network_path(p):
        raise ValueError(
            f"refusing network/UNC input path {p!r} "
            f"(reading it could leak credentials over SMB)")
    pp = Path(p)
    resolved = pp if pp.is_absolute() else (base / pp)
    if is_network_path(resolved):
        raise ValueError(
            f"refusing network/UNC input path {str(resolved)!r} "
            f"(reading it could leak credentials over SMB)")
    return str(resolved)


# Every model role a profile can configure. The single definition — doctor
# (util.environment) imports it from here rather than keeping its own copy,
# which had already drifted (it omitted graph_annotate).
_MODEL_ROLES = ("graph_annotate", "callgraph_creation", "autoexclude",
                "preprocess", "threatmodel", "decompose", "deepdive", "verify",
                "dedup", "chain", "remediate", "validate")

# The S0 callgraph-annotator roles, live only under step0.callgraph_detection:
# llm. In rules mode their models are never called at runtime (taint.yaml ships
# exactly that shape), so probing/credential-checking them would fatally fail a
# config that scans fine today.
_CALLGRAPH_ROLES = frozenset({"graph_annotate", "callgraph_creation"})


def _callgraph_llm_selected(cfg) -> bool:
    """True when ``step0.callgraph_detection`` selects the LLM annotator.

    Mirrors the callgraph engine's own mode predicate
    (pipeline/stages/callgraph_engine/__init__.py): the value is stripped and
    lower-cased, and an absent, empty, or unrecognised value falls back to
    ``"rules"`` — i.e. anything that is not exactly ``llm`` means the annotator
    model is dead config and must not be preflighted.
    """
    step0 = getattr(cfg, "step0", None)
    mode = str(getattr(step0, "callgraph_detection", "rules")
               or "rules").strip().lower()
    return mode == "llm"


def _iter_model_roles(cfg):
    """Yield ``(role, model_cfg_node)`` for every configured, ACTIVE model role.

    Skips the S0 callgraph roles unless ``step0.callgraph_detection: llm``, so
    preflight/doctor only ever probe models a scan under this config could
    actually call: in rules mode those roles are dead config and probing them
    would fail a profile that scans fine.
    """
    for r in _MODEL_ROLES:
        if r in _CALLGRAPH_ROLES and not _callgraph_llm_selected(cfg):
            continue
        m = getattr(cfg.models, r, None)
        if m is None:
            continue
        # `validate` is a map of sub-roles; the whole panel runs on the orchestrator's
        # backend, so that is the only node to check. It keeps reporting under the parent
        # name because callers classify roles by it (`llm.POST_SCAN_ROLES` /
        # `preflight._post_scan_only` downgrade a post-scan credential gap to a WARN).
        if r == "validate":
            m = getattr(m, "orchestrator", None)
            if m is None:
                continue
        yield r, m
