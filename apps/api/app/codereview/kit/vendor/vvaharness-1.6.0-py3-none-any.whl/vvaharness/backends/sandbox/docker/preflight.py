# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Refuse a spec this machine cannot run, before any container exists, and return its options.

Deliberately imports no `docker`: everything here is checkable without a daemon, so the
daemon-dependent half stays in the backend and these checks stay testable on any install.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Final

from vvaharness.backends.sandbox.config import mount_origin
from vvaharness.backends.sandbox.docker.models import DockerLimits
from vvaharness.backends.sandbox.models import (
    SandboxConfigError,
    SandboxUnavailableError,
    is_over_broad,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence
    from pathlib import Path

    from vvaharness.backends.sandbox.models import Mount, SandboxSpec

#: Generous by design: the pipeline runs real thread pools and subprocesses, and a tight cap
#: surfaces as an unexplained hang rather than as "you set pids_limit too low".
_DEFAULT_PIDS: Final = 4096
#: Docker's own `--tmpfs` default is 64 MB, which a scan's temporary files outgrow.
_DEFAULT_TMPFS_SIZE: Final = "1g"

#: The knob names a profile may set under `sandbox.docker:`. Anything else is a typo, and is
#: refused as one rather than silently ignored.
OPTION_NAMES: Final[frozenset[str]] = frozenset(
    {"pids_limit", "nano_cpus", "mem_limit", "tmpfs_size"}
)


def _as_count(name: str, value: object) -> int:
    """Coerce one raw YAML value to a positive int, naming the knob on refusal.

    Raises:
        SandboxConfigError: If *value* is not an ASCII whole number greater than zero --
            Docker's own parser rejects non-ASCII digits (e.g. Arabic-Indic) that Python's
            `str.isdigit()` alone accepts.
    """
    text = str(value).strip()
    if (
        isinstance(value, bool)
        or not text.isascii()
        or not text.isdigit()
        or int(text) <= 0
    ):
        msg = f"sandbox.docker.{name} must be a whole number greater than zero, got {value!r}"
        raise SandboxConfigError(msg)
    return int(text)


def _as_size(name: str, value: object) -> str:
    """Coerce one raw YAML value to a Docker size string (`512m`, `8g`), unit required.

    Raises:
        SandboxConfigError: If *value* is not ASCII digits greater than zero followed by a
            b/k/m/g unit -- Docker's own parser rejects non-ASCII digits, and a zero-sized
            tmpfs is unbounded, not empty.
    """
    text = str(value).strip()
    digits = text[:-1]
    if (
        not digits.isascii()
        or not digits.isdigit()
        or int(digits) <= 0
        or text[-1:] not in {"b", "k", "m", "g", "B", "K", "M", "G"}
    ):
        msg = (
            f"sandbox.docker.{name} must be a Docker size string such as '512m' or '8g', "
            f"got {value!r}"
        )
        raise SandboxConfigError(msg)
    return text


def _require_known_names(raw: Mapping[str, object]) -> None:
    """Reject a misspelled knob rather than ignoring it.

    Raises:
        SandboxConfigError: If *raw* names anything outside `OPTION_NAMES`.
    """
    unknown = sorted(set(raw) - OPTION_NAMES)
    if unknown:
        msg = f"unknown sandbox.docker option(s) {unknown}; valid: {sorted(OPTION_NAMES)}"
        raise SandboxConfigError(msg)


def limits_from(raw: Mapping[str, object]) -> DockerLimits:
    """Validate and coerce the profile's raw `sandbox.docker:` mapping into typed limits.

    A `None` value is dropped rather than kept: a knob written bare in YAML parses as None,
    and a retained None reads as "set" to `dict.get(key, default)` while being falsy
    everywhere else. Absent and null must mean the same thing.
    """
    _require_known_names(raw)
    stated = {name: value for name, value in raw.items() if value is not None}
    pids = stated.get("pids_limit")
    tmpfs = stated.get("tmpfs_size")
    memory = stated.get("mem_limit")
    cpus = stated.get("nano_cpus")
    return DockerLimits(
        pids_limit=_DEFAULT_PIDS if pids is None else _as_count("pids_limit", pids),
        tmpfs_size=_DEFAULT_TMPFS_SIZE if tmpfs is None else _as_size("tmpfs_size", tmpfs),
        mem_limit=None if memory is None else _as_size("mem_limit", memory),
        nano_cpus=None if cpus is None else _as_count("nano_cpus", cpus),
    )


def _require_posix_identity() -> None:
    """Refuse a platform with no uid/gid to run the container as.

    Raises:
        SandboxUnavailableError: On a platform lacking `os.getuid` (Windows).
    """
    if not hasattr(os, "getuid"):
        msg = (
            "the docker sandbox runs the container as the invoking user's uid:gid, which this "
            "platform does not have. Use sandbox.via: none, or run on Linux/macOS."
        )
        raise SandboxUnavailableError(msg)


def _require_mount_source(mount: Mount) -> None:
    """Refuse a mount Docker will reject, or that would surface as a late failure.

    The mount list is derived, so every refusal names the setting that produced it: an `EV_*`
    file sitting directly in `$HOME` is as much a cause of a `$HOME` bind as `--scan-report` is.

    Raises:
        SandboxUnavailableError: If the source is relative, contains `..`, does not exist, or
            is too broad (`models.is_over_broad`) -- either binds far
            more of the host than the setting that named it implies.
    """
    source = mount.source
    if not source.is_absolute() or ".." in source.parts:
        msg = f"sandbox mount source must be an absolute path without '..', got {str(source)!r}"
        raise SandboxUnavailableError(msg)
    if not source.exists():
        msg = f"sandbox mount source does not exist on this host: {source}"
        raise SandboxUnavailableError(msg)
    if is_over_broad(source):
        msg = (
            f"sandbox mount source {source} is too broad to bind (the filesystem root, a "
            f"shared system or temporary directory, or your home directory or one above it); "
            f"it is what {mount_origin(mount.target)} resolves to -- scope that setting to a "
            f"narrower path"
        )
        raise SandboxUnavailableError(msg)


def _require_distinct_binds(mounts: Sequence[Mount]) -> None:
    """Refuse a bind table two mounts cannot share, naming the settings that asked for them.

    Docker's volume table is keyed by host source, so a second mount of one directory silently
    replaces the first: the forwarded argv then names a container path nothing mounted, or a
    read-only bind comes back `rw` because the duplicate carried the other mode. Two sources
    claiming one target is the same collision from the other side, and the daemon reports that
    one only as an opaque duplicate-mount-point failure.

    Raises:
        SandboxUnavailableError: If two mounts share a source but not their target and mode, or
            share a target but not their source.
    """
    by_source: dict[Path, Mount] = {}
    by_target: dict[Path, Mount] = {}
    for mount in mounts:
        first = by_source.setdefault(mount.source, mount)
        if first.target != mount.target:
            msg = (
                f"{mount_origin(first.target)} and {mount_origin(mount.target)} both resolve to "
                f"{mount.source}, and one host directory can only be bound at one place -- the "
                f"second target would not exist inside the container at all. Point one of them "
                f"at its own directory."
            )
            raise SandboxUnavailableError(msg)
        if first.writable != mount.writable:
            msg = (
                f"{mount_origin(mount.target)} binds {mount.source} at {mount.target} both "
                f"read-only and writable, and one bind has one mode -- whichever came last "
                f"would silently decide it. Make the two agree."
            )
            raise SandboxUnavailableError(msg)
        held = by_target.setdefault(mount.target, mount)
        if held.source != mount.source:
            msg = (
                f"{mount_origin(mount.target)} would be bound from two different host "
                f"directories ({held.source} and {mount.source}); Docker refuses a duplicate "
                f"mount point, and one of the two would be invisible inside the container. "
                f"Point them at one directory."
            )
            raise SandboxUnavailableError(msg)


def _require_image(image: str) -> None:
    """Refuse an empty image, which otherwise fails deep inside the Docker client.

    Raises:
        SandboxUnavailableError: If *image* is blank.
    """
    if not image.strip():
        msg = (
            "sandbox.image is not set. Build the shipped image with "
            "`docker build -f docker/sandbox/Dockerfile -t vvaharness-sandbox:local .` "
            "and name that tag in your profile."
        )
        raise SandboxUnavailableError(msg)


def check(spec: SandboxSpec) -> DockerLimits:
    """Refuse unless this machine can run *spec*, returning its validated limits.

    Refusing here rather than at first use is the point: by the time `run` fails, an image
    may already have been pulled and a container created.
    """
    _require_posix_identity()
    _require_image(spec.image)
    for mount in spec.mounts:
        _require_mount_source(mount)
    _require_distinct_binds(spec.mounts)
    return limits_from(spec.backend_options)


__all__ = ["OPTION_NAMES", "check", "limits_from"]
