# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The sandbox family's whole data contract: levels, capabilities, mounts, spec, errors.

The errors live here rather than in an `errors.py` because which failures a backend may
raise is part of the contract a caller programs against, not one backend's detail.
"""

from __future__ import annotations

import re
import tempfile
from dataclasses import dataclass, field
from enum import Flag, StrEnum, auto
from functools import lru_cache
from pathlib import Path
from typing import TYPE_CHECKING, Final
from urllib.parse import SplitResult, urlsplit

from vvaharness.validation.constants.artifacts import VALIDATE_COMMANDS

if TYPE_CHECKING:
    from collections.abc import Mapping


class SandboxLevel(StrEnum):
    """Portable statement of intent, independent of the mechanism that delivers it."""

    NONE = "none"
    READ_ONLY = "read-only"
    WORKSPACE_WRITE = "workspace-write"
    NO_NETWORK = "no-network"
    MEDIATED_NETWORK = "mediated-network"


class SandboxFs(StrEnum):
    """Filesystem axis: whether the contained run may write the target repo mount."""

    READ_ONLY = "read-only"
    WORKSPACE_WRITE = "workspace-write"


class SandboxEgress(StrEnum):
    """Network axis: how a contained run reaches anything outside its own namespace."""

    MEDIATED = "mediated"
    SCOPED = "scoped"
    OPEN = "open"
    NONE = "none"


class EgressGrant(StrEnum):
    """One destination a `scoped` run may reach beyond the model endpoints, by name.

    A closed set: each grant opens exactly one destination and admits exactly the env family
    that destination needs (`EnvFamily.grant`), so there is no raw host for a profile to widen.
    """

    INGEST = "ingest"
    EV = "ev"
    #: The Semgrep registry, for the plugin's `rulesets`; it opens nothing when there are none.
    SEMGREP = "semgrep"


#: The single `SandboxLevel` each axis pair means. The axes are what an operator states; this
#: table exists because `capability.REQUIRED` and the docker backend's network derivation are
#: still keyed by level. Egress decides the name except where it is `open`.
_LEVEL_FOR_AXES: Final[Mapping[tuple[SandboxFs, SandboxEgress], SandboxLevel]] = {
    (SandboxFs.READ_ONLY, SandboxEgress.OPEN): SandboxLevel.READ_ONLY,
    (SandboxFs.WORKSPACE_WRITE, SandboxEgress.OPEN): SandboxLevel.WORKSPACE_WRITE,
    (SandboxFs.READ_ONLY, SandboxEgress.NONE): SandboxLevel.NO_NETWORK,
    (SandboxFs.WORKSPACE_WRITE, SandboxEgress.NONE): SandboxLevel.NO_NETWORK,
    (SandboxFs.READ_ONLY, SandboxEgress.MEDIATED): SandboxLevel.MEDIATED_NETWORK,
    (SandboxFs.WORKSPACE_WRITE, SandboxEgress.MEDIATED): SandboxLevel.MEDIATED_NETWORK,
    (SandboxFs.READ_ONLY, SandboxEgress.SCOPED): SandboxLevel.MEDIATED_NETWORK,
    (SandboxFs.WORKSPACE_WRITE, SandboxEgress.SCOPED): SandboxLevel.MEDIATED_NETWORK,
}


def level_for(fs: SandboxFs, egress: SandboxEgress) -> SandboxLevel:
    """The level name *fs* and *egress* together mean, for the level-keyed surfaces."""
    return _LEVEL_FOR_AXES[fs, egress]


class Capability(Flag):
    """What a backend can actually enforce, declared per backend and checked against a level.

    A backend that cannot deliver the requested level refuses, because a sandbox believed to
    enforce something it does not is worse than no sandbox at all.
    """

    NOTHING = 0
    CONFINE_READS = auto()
    CONFINE_WRITES = auto()
    DENY_NETWORK = auto()
    MEDIATE_NETWORK = auto()
    RESTRICT_SYSCALLS = auto()
    DROP_PRIVILEGES = auto()


@dataclass(frozen=True, slots=True)
class Mount:
    """One host path bound into the container at `target`, read-only unless `writable`."""

    source: Path
    target: Path
    writable: bool


@lru_cache(maxsize=4)
def _resolved(home: Path) -> Path:
    """*home* with symlinks resolved, memoised: `is_over_broad` runs per mount, realpath syscalls.

    Keyed on the unresolved home, so a process that moves `$HOME` is never answered from a
    stale entry -- reading the variable is the cheap half.
    """
    return home.resolve()


#: Directories that hold everything of their kind on a host, so binding one exposes far more
#: than the setting that named it. Not every top-level directory: a checkout at `/app` or `/src`
#: is an ordinary CI layout and must stay mountable as the repo.
_SHARED_DIRS: Final[tuple[str, ...]] = (
    "/tmp", "/var/tmp", "/etc", "/var", "/usr", "/opt", "/srv", "/mnt", "/media", "/home",
    "/root", "/run", "/dev", "/proc", "/sys", "/boot", "/bin", "/sbin", "/lib", "/lib64",
    "/private", "/Users", "/Volumes", "/Library", "/System", "/Applications",
)


@lru_cache(maxsize=1)
def _shared_dirs() -> frozenset[Path]:
    """`_SHARED_DIRS` and the per-user temp directory, resolved: on macOS `/tmp` and `/etc`
    are `/private/tmp` and `/private/etc`, which is what a resolved mount source says."""
    return frozenset(Path(p).resolve() for p in (*_SHARED_DIRS, tempfile.gettempdir()))


def is_over_broad(source: Path) -> bool:
    """Whether *source* binds far more of the host than any one setting needs.

    That is the filesystem root, a shared system directory (`/tmp`, `/etc`, `/Users`), the
    per-user temp directory, or the invoking user's home directory or any directory above it:
    `--scan-report /tmp/r.md` would otherwise bind every file and socket in `/tmp` read-write.
    The one definition: `docker.preflight` refuses such a mount, and `config` uses the same
    answer to choose a narrower mount instead of offering one preflight would reject.
    `Path` equality already normalizes a doubled or trailing slash (`Path("/x//") ==
    Path("/x")`), so `$HOME//` is caught by the same comparison as `$HOME`. `Path.home()` is
    resolved so a symlinked home directory (e.g. `/home` -> elsewhere) still compares equal
    to an already-resolved mount source.
    """
    home = _resolved(Path.home())
    return (source == Path(source.anchor) or source == home or source in home.parents
            or source in _shared_dirs())


def _split(url: str) -> SplitResult:
    """*url* parsed, tolerating a bare `host:port` with no scheme."""
    return urlsplit(url if "://" in url else f"//{url}")


def host_of(url: str) -> str | None:
    """The hostname in *url*, tolerating a bare `host:port` with no scheme.

    The one definition: `config` derives the mediated allowlist from profile routes with it and
    `docker.egress` extends that allowlist from the environment, and the two must agree.

    An unbracketed IPv6 literal is handed back WHOLE rather than truncated: `urlsplit` would
    read `2001:db8::1` as host `2001`, which silently allowlists something else entirely, so
    `require_hostname` gets the entry as written and refuses it with the bracketed-form message.
    """
    parts = _split(url)
    if "[" not in parts.netloc and parts.netloc.count(":") > 1:
        return parts.netloc
    return parts.hostname


#: A hostname's charset, with squid's leading-dot subdomain form allowed. Each allowlisted host
#: is interpolated into an ACL line, and `host_of` PRESERVES a space -- "gw.corp .example"
#: would emit a second `dstdomain` token allowlisting every `.example`.
_HOSTNAME: Final = re.compile(r"\.?[A-Za-z0-9][A-Za-z0-9._-]*\Z")

#: The only destination ports a mediated run can reach: `docker.egress` narrows CONNECT to 443
#: and cleartext to 80. Here rather than in the Docker layer so the config path can refuse an
#: endpoint the sidecar would deny, instead of leaving it to a CONNECT failure mid-run.
MEDIATED_PORTS: Final[tuple[int, ...]] = (80, 443)

#: The one cleartext port of `MEDIATED_PORTS`, opened only for an `http://` endpoint's host.
_HTTP_PORT: Final = 80

#: Which of those ports each scheme may use, because the generated conf is scheme-aware:
#: `deny CONNECT !SSL_ports` blocks a CONNECT to :80, and cleartext is allowed on 80 alone. A
#: scheme-less `host:port` cannot be classified either way, so both ports stand for it.
_SCHEME_PORTS: Final[Mapping[str, tuple[int, ...]]] = {"https": (443,), "http": (80,)}

#: What `docker.egress` names when its own defence-in-depth charset check refuses a host: every
#: entry was already checked under the setting it came from, so reaching it means a bug here.
ALLOWLIST_SETTING: Final = "the derived egress allowlist"


def require_hostname(host: str, origin: str, *, endpoint: bool = False) -> str:
    """*host* if it is a bare hostname, since it becomes one token in an ACL line.

    The one charset gate for an allowlisted host, wherever it came from: *origin* is the setting
    or env var to name on refusal, so the operator is sent to what they actually wrote. A
    trailing dot is refused with the rest: `dstdomain` matches the token literally, so
    `gw.corp.example.` allowlists a name nothing ever requests. An *endpoint* host, read off a
    URL, may not take squid's leading-dot form either: `https://.com` names no server, and as
    `.com` it would allowlist every name under it.

    Raises:
        SandboxConfigError: If it holds anything outside a hostname's charset.
    """
    if not _HOSTNAME.match(host) or host.endswith(".") or (endpoint and host.startswith(".")):
        msg = (
            f"{origin} gives {host!r}, which is not a hostname. Each allowlisted host becomes "
            f"one token in the mediated proxy's ACL, where a space or a wildcard would match far "
            f"more than the endpoint names and a trailing dot matches nothing: name the endpoint "
            f"by one bare hostname. An IPv6 literal cannot be an ACL token at all."
        )
        raise SandboxConfigError(msg)
    return host


def require_mediated_port(url: str, origin: str) -> None:
    """Refuse an endpoint whose scheme and port pair a mediated run could not reach.

    The allowlist is derived by HOST alone, so a `:8443` gateway is allowlisted and then denied
    by the proxy's port ACL -- a refused CONNECT mid-run with nothing naming the port. Scheme by
    scheme, because the conf is: `https://host:80` and `http://host:443` each name a reachable
    port for the OTHER scheme, and each dies as the same late per-CONNECT denial.

    Raises:
        SandboxConfigError: If *url*'s port is not one this scheme can reach, or is no port.
    """
    parts = _split(url)
    try:
        port = parts.port
    except ValueError as exc:
        every = " or ".join(str(each) for each in MEDIATED_PORTS)
        msg = (
            f"{origin} gives {url!r}, whose port is not a port number. Write the endpoint as "
            f"https://<host> or http://<host>: mediated egress reaches {every}, nothing else."
        )
        raise SandboxConfigError(msg) from exc
    allowed = _SCHEME_PORTS.get(parts.scheme, MEDIATED_PORTS)
    if port is None or port in allowed:
        return
    reachable = " or ".join(str(each) for each in allowed)
    msg = (
        f"{origin} names port {port}, which a mediated run cannot reach over "
        f"{parts.scheme or 'either scheme'}: the proxy sidecar allows CONNECT to an allowlisted "
        f"host on 443 and cleartext on 80 only, so this endpoint is allowlisted by host and then "
        f"refused per-CONNECT once the scan is running. Front it on {reachable}, or set "
        f"sandbox.egress: open to accept unrestricted egress."
    )
    raise SandboxConfigError(msg)


def is_loopback(host: str) -> bool:
    """Whether *host* names the machine it is resolved on.

    Inside a container that is the container itself, so a model server on the HOST's loopback
    is never what it reaches.
    """
    named = host in {"localhost", "::1", "0.0.0.0"}  # noqa: S104 — compared, never bound
    return named or host.endswith(".localhost") or host.startswith("127.")


def loopback_message(origin: str, url: str) -> str:
    """The one wording for a loopback endpoint under mediation, refused or warned about."""
    return (
        f"{origin} gives {url!r}, which inside the container is the container itself, not this "
        f"machine: a mediated run cannot reach a server on this machine's loopback. Point it at "
        f"a host reachable by name."
    )


def is_cleartext(url: str) -> bool:
    """Whether *url* is reached over plain HTTP: an `http://` scheme, or a scheme-less `host:80`.

    Only such an endpoint opens the proxy's port 80 for its host; everything else is CONNECT on
    443 alone. A port that is not a number reads as not cleartext: `require_mediated_port`
    refuses it wherever the port is used.
    """
    parts = _split(url)
    try:
        port = parts.port
    except ValueError:
        return False
    return parts.scheme == "http" or (not parts.scheme and port == _HTTP_PORT)


class EgressMode(StrEnum):
    """How one run reaches the network, `ev-bridge` (exploit verification's) included.

    The derived plan vocabulary, not the operator's: `SandboxEgress` is what a profile states,
    and `network_for` is the one conversion between them.
    """

    MEDIATED = "mediated"
    OPEN = "open"
    NONE = "none"
    EV_BRIDGE = "ev-bridge"


@dataclass(frozen=True, slots=True)
class SandboxNetwork:
    """One run's egress decision: the mode, the hosts the proxy may reach, the forced proxy URL.

    `proxy_url` is None until the backend has a network to put the proxy on: the alias is
    network-scoped, so only the Docker layer can name it. `cleartext` is the subset of
    `allowlist` an `http://` endpoint names; only those hosts are reachable on port 80.
    `forwards` are the host loopback ports a scoped `ev` run reaches on the same port of its own
    loopback, through the sidecar rather than through the proxy. `callback` asks for the one
    path the other way, so the target can reach exploit verification's out-of-band listener.
    """

    mode: EgressMode
    allowlist: tuple[str, ...] = ()
    proxy_url: str | None = None
    cleartext: tuple[str, ...] = ()
    forwards: tuple[int, ...] = ()
    callback: bool = False


@dataclass(frozen=True, slots=True)
class SandboxSpec:
    """Everything a `Sandbox` backend needs to run one contained invocation."""

    level: SandboxLevel
    mounts: tuple[Mount, ...]
    image: str
    workdir: Path
    timeout: float | None = None
    backend_options: Mapping[str, object] = field(default_factory=dict)
    #: None means "whatever the level implies"; an exploit-verification run sets its own network.
    network: SandboxNetwork | None = None
    #: An absent image is a build instruction, not a reason to fetch one; a non-default
    #: DOCKER_HOST is a different machine, which no mount path here is valid on.
    allow_pull: bool = False
    allow_remote_daemon: bool = False
    #: The profile loads the Semgrep plugin, so preflight checks the image carries `semgrep`.
    needs_semgrep: bool = False


@dataclass(frozen=True, slots=True)
class SandboxConfig:
    """The `sandbox:` YAML block's shape, typed once so nothing downstream re-reads raw config."""

    via: str
    fs: SandboxFs
    egress: SandboxEgress
    image: str
    env_allowlist: tuple[str, ...]
    timeout_seconds: float | None
    backend_options: Mapping[str, object]
    #: Every host a mediated or scoped run may reach, DERIVED from the model routes and grants;
    #: never written by the operator.
    egress_allowlist: tuple[str, ...] = ()
    #: The `egress_allowlist` hosts an `http://` endpoint names: the only ones open on port 80.
    egress_cleartext: tuple[str, ...] = ()
    #: `sandbox.egress_grants`: what a scoped run reaches beyond the model endpoints.
    egress_grants: frozenset[EgressGrant] = frozenset()
    #: `output.ingest_url` as resolved, so the gate can say when the upload has no route.
    ingest_url: str = ""
    #: Whether the profile's `sdk.plugins` names the Semgrep plugin, which only an image built
    #: with `INSTALL_SEMGREP=1` can run.
    semgrep_plugin: bool = False
    #: That plugin's registry `rulesets`, which only the `semgrep` grant (or `open`) can fetch.
    semgrep_rulesets: tuple[str, ...] = ()
    #: That plugin's local rule files (`configs`) as WRITTEN, each mounted where the run reads it.
    semgrep_configs: tuple[str, ...] = ()
    allow_pull: bool = False
    allow_remote_daemon: bool = False
    #: The `inject:` block's path values as WRITTEN (never resolved here): the gate needs both
    #: the host path they mean and the path the contained run will resolve them to.
    inject: Mapping[str, str] = field(default_factory=dict)
    #: Whether exploit verification will run, per EV's own `options.may_run` (the profile switch
    #: AND the environment). None on a config not read from a profile: no switch was consulted,
    #: so `config.ev_requested` falls back to the environment alone.
    ev_armed: bool | None = None

    @property
    def level(self) -> str:
        """The internal level name these axes mean, for messages keyed by it."""
        return level_for(self.fs, self.egress).value


#: The plan vocabulary each operator egress value means. One table, so `EgressMode` and
#: `SandboxEgress` can never drift into two disagreeing sets of names. `scoped` is mediation
#: with more on the allowlist, so the container and the sidecar are the same.
_EGRESS_MODES: Final[Mapping[SandboxEgress, EgressMode]] = {
    SandboxEgress.MEDIATED: EgressMode.MEDIATED,
    SandboxEgress.SCOPED: EgressMode.MEDIATED,
    SandboxEgress.OPEN: EgressMode.OPEN,
    SandboxEgress.NONE: EgressMode.NONE,
}


def is_mediated(egress: SandboxEgress) -> bool:
    """Whether *egress* runs behind the allowlisting proxy: `mediated`, or `scoped`."""
    return _EGRESS_MODES[egress] is EgressMode.MEDIATED


#: The egress an internal level name implies, for a spec built without a config block.
_LEVEL_EGRESS: Final[Mapping[SandboxLevel, SandboxEgress]] = {
    SandboxLevel.NO_NETWORK: SandboxEgress.NONE,
    SandboxLevel.MEDIATED_NETWORK: SandboxEgress.MEDIATED,
}


def network_for(cfg: SandboxConfig) -> SandboxNetwork:
    """The egress decision *cfg*'s operator axis means -- THE conversion from `sandbox.egress`.

    The allowlist rides along only where it can be enforced: on an open or absent egress path
    there is no proxy to apply it, and carrying it anyway would suggest otherwise.
    """
    mode = _EGRESS_MODES[cfg.egress]
    if mode is not EgressMode.MEDIATED:
        return SandboxNetwork(mode=mode)
    return SandboxNetwork(mode=mode, allowlist=cfg.egress_allowlist,
                          cleartext=cfg.egress_cleartext)


def network_for_level(level: SandboxLevel) -> SandboxNetwork:
    """The decision *level* alone implies, for a spec carrying no network of its own.

    Fallback only -- `network_for` is the operator-facing conversion. Fail-closed: an unknown
    level's mode is whatever `_LEVEL_EGRESS` omits, i.e. the open bridge it already had.
    """
    mode = _EGRESS_MODES[_LEVEL_EGRESS.get(level, SandboxEgress.OPEN)]
    return SandboxNetwork(mode=mode)


class SandboxError(RuntimeError):
    """Base for every sandbox failure, so a caller can tell containment apart from the run."""


class SandboxUnavailableError(SandboxError):
    """The requested backend cannot be used here; the message names what is missing."""


class CapabilityError(SandboxError):
    """The requested level is not enforceable by the resolved backend."""


class SandboxConfigError(SandboxError):
    """The profile's `sandbox:` block is not usable as written."""


#: Only these subcommands run LLM calls against untrusted repo content; the rest bypass
#: sandboxing. Built from the CLI's own vocabulary so the `s11` alias cannot drift out.
#: `ev-replay` judges attacker-influenced response data, so it is contained like a scan; it
#: takes `--repo`, which is what the gate needs to mount.
SANDBOXED_COMMANDS: Final[frozenset[str]] = frozenset(
    {"scan", "remediate", "ev-replay", *VALIDATE_COMMANDS}
)

#: The sandboxed subcommands that run exploit verification. Only these are armed for it at the
#: gate: `remediate` and `validate` never verify, so they get no route to the target, no EV
#: input mounts and no `EV_*` setting, whatever the environment holds.
VERIFYING_COMMANDS: Final[frozenset[str]] = frozenset({"scan", "ev-replay"})

#: Set inside a running sandbox so a re-exec'd invocation never contains itself again. The value
#: is the per-run nonce the gate minted, never a bare "1": a stale host export must not pass.
IN_SANDBOX_ENV: Final = "VVAHARNESS_IN_SANDBOX"

#: Hidden argv flag carrying the re-exec nonce, so provenance is argv-borne rather than
#: inherited env. Defined here because `remap` cannot import `entry` (entry imports remap).
CONTAINED_FLAG: Final = "--_contained"

#: Forced into a mediated run: where the egress sidecar's Unix socket appears in the scan
#: container. Its presence is what makes the contained harness start `relay`, the run's one way
#: out of a container that has no network interface but loopback.
EGRESS_SOCKET_ENV: Final = "VVAHARNESS_EGRESS_SOCKET"

#: The loopback port that relay listens on inside the scan container; the forced proxy
#: variables name it.
EGRESS_RELAY_PORT: Final = 3128

#: The container-side port exploit verification's out-of-band listener binds; mirrors
#: `executor.oob._DEFAULT_PORT`. A scoped forward listening there would take its place.
EV_CALLBACK_PORT: Final = 9090

#: Forced into a scoped `ev` run: the comma-separated loopback ports relay also listens on, each
#: carried by its own socket beside the proxy's to the same port on the host.
EGRESS_FORWARDS_ENV: Final = "VVAHARNESS_EGRESS_FORWARDS"

#: Forced into a scoped `ev` run: the loopback port exploit verification's out-of-band listener
#: binds, which relay serves from `CALLBACK_SOCKET` -- the one connection INTO the container,
#: from the port the sidecar publishes on host loopback.
EGRESS_CALLBACK_ENV: Final = "VVAHARNESS_EGRESS_CALLBACK"

#: The socket, beside the proxy's, that relay listens on and the sidecar connects a target's
#: out-of-band callback to.
CALLBACK_SOCKET: Final = "callback.sock"


def forward_socket_name(port: int) -> str:
    """The socket, beside the proxy's, that carries forwarded loopback *port* to the sidecar."""
    return f"forward-{port}.sock"


#: The resolved HOST path of the target, forced into a contained run so run identity does not
#: collapse onto the constant `/workspace`. Advisory identity only -- never a path anyone opens.
REPO_HOST_PATH_ENV: Final = "VVAHARNESS_REPO_HOST_PATH"

#: The `sandbox.egress` the gate ran this invocation under, forced into a contained run so an
#: error there can name it (no model credential crosses `none`). Advisory text only.
SANDBOX_EGRESS_ENV: Final = "VVAHARNESS_SANDBOX_EGRESS"

#: Every harness setting travels, so a contained run behaves like the invocation that made it.
HARNESS_ENV_PREFIX: Final = "VVAHARNESS_"


#: Egress values from least to most reach: a family crosses under the egress it needs and above.
_EGRESS_REACH: Final[tuple[SandboxEgress, ...]] = (
    SandboxEgress.NONE, SandboxEgress.MEDIATED, SandboxEgress.SCOPED, SandboxEgress.OPEN,
)


@dataclass(frozen=True)
class EnvFamily:
    """One family of host variables a contained run may receive, and the least egress it needs.

    A family is a set of exact names, or a namespace prefix when the harness owns the whole
    namespace (`VVAHARNESS_`, `EV_`). A vendor namespace is named exactly, since others export
    names under it too: a launching coding agent its own `ANTHROPIC_MODEL` and the like. A family
    with a `grant` also crosses under `scoped` when that grant is given, since the grant is what
    opens the destination it is of use for.
    """

    names: frozenset[str] = frozenset()
    prefix: str | None = None
    needs: SandboxEgress = SandboxEgress.NONE
    grant: EgressGrant | None = None

    def covers(self, key: str) -> bool:
        """Whether *key* belongs to this family."""
        return key in self.names or (self.prefix is not None and key.startswith(self.prefix))


#: The model providers' variables the harness reads: keys, endpoints, proxies and TLS files (a
#: host path value is remapped or dropped like any other). A name only a model library reads
#: crosses through `sandbox.env_allowlist`.
MODEL_ENV: Final[frozenset[str]] = frozenset({
    "ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_SDK_API_KEY",
    "ANTHROPIC_BASE_URL", "ANTHROPIC_SDK_BASE_URL", "ANTHROPIC_PROXY",
    "ANTHROPIC_SDK_CA_CERT", "ANTHROPIC_SDK_CLIENT_CERT",
    "OPENAI_API_KEY", "OPENAI_BASE_URL", "OPENAI_PROXY", "OPENAI_CA_CERT",
})


#: Every host variable a contained run can receive. Anything no family covers stays on the host:
#: - every name whose value is a HOST path (`SSL_CERT_FILE`, `REQUESTS_CA_BUNDLE`,
#:   `NODE_EXTRA_CA_CERTS`, `PATH`, `HOME`, `VIRTUAL_ENV`, `PYTHONPATH`), which inside a different
#:   filesystem overrides what the image configured with a path that does not exist there;
#: - `CLAUDE_*` and `GITHUB_TOKEN`, which the run does not need: no `claude` is on the image's
#:   `PATH`, the CLI `claude-agent-sdk` bundles for `via: sdk` signs in with the API key, a
#:   launching coding agent exports its own session variables under `CLAUDE_`, and batch cloning,
#:   the one `GITHUB_TOKEN` consumer, is refused in a sandbox;
#: - `GEMINI_*` and `GOOGLE_*`: only doctor reads them, for a Gemini CLI the image lacks;
#: - tracing (`LANGSMITH_*`, `LANGCHAIN_*`), a live phone-home out of the container.
#: Each family names the least egress it is of use under: a network family stays out under
#: `none`, and one for a destination beyond the model endpoints under `mediated` too, which
#: reaches nothing else. Under `scoped` such a family crosses only with its grant.
CONTAINER_ENV: Final[tuple[EnvFamily, ...]] = (
    EnvFamily(prefix=HARNESS_ENV_PREFIX),
    EnvFamily(names=frozenset({"LANG", "LC_ALL", "TZ"})),
    EnvFamily(names=MODEL_ENV, needs=SandboxEgress.MEDIATED),
    # Exploit verification's settings and credentials; a HOST PATH value is mounted (`EV_PATH_ENV`).
    EnvFamily(prefix="EV_", needs=SandboxEgress.OPEN, grant=EgressGrant.EV),
    EnvFamily(names=frozenset({"HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY",
                               "http_proxy", "https_proxy", "no_proxy"}),
              needs=SandboxEgress.MEDIATED),
    # The harness's own credentials for network services. The model gateway's TLS client key goes
    # wherever a model does; report ingest and GitHub Enterprise are destinations of their own.
    EnvFamily(names=frozenset({"VVAHARNESS_TLS_CLIENT_KEY"}), needs=SandboxEgress.MEDIATED),
    EnvFamily(names=frozenset({"VVAHARNESS_INGEST_TOKEN"}), needs=SandboxEgress.OPEN,
              grant=EgressGrant.INGEST),
    EnvFamily(names=frozenset({"VVAHARNESS_GHE_TOKEN", "VVAHARNESS_GHE_ARCHIVED_TOKEN"}),
              needs=SandboxEgress.OPEN),
)


@dataclass(frozen=True)
class EnvPolicy:
    """Which host variables one contained run receives."""

    egress: SandboxEgress
    #: `sandbox.env_allowlist`: prefixes the operator named, which cross whatever the families say.
    allowlist: frozenset[str] = frozenset()
    #: `sandbox.egress_grants`, which only a `scoped` egress carries.
    grants: frozenset[EgressGrant] = frozenset()

    def crosses(self, key: str) -> bool:
        """Whether *key* crosses: a family covers it, and this egress meets every family's need."""
        if any(key.startswith(prefix) for prefix in self.allowlist):
            return True
        families = [family for family in CONTAINER_ENV if family.covers(key)]
        return bool(families) and all(self._meets(family) for family in families)

    def _meets(self, family: EnvFamily) -> bool:
        """Whether this egress reaches *family*'s need, or a scoped run holds its grant."""
        if _EGRESS_REACH.index(family.needs) <= _EGRESS_REACH.index(self.egress):
            return True
        return self.egress is SandboxEgress.SCOPED and family.grant in self.grants


#: EV settings whose value is a host FILE path: each earns a read-only mount at the gate and
#: its value is remapped to the container path. Ordered so the derived mount list is stable.
EV_PATH_ENV: Final[tuple[str, ...]] = (
    "EV_API_COLLECTION",
    "EV_TARGET_CA_CERT",
    "EV_TARGET_CLIENT_CERT",
    "EV_TARGET_CLIENT_KEY",
)

#: Forced into a contained run carrying the address(es) the daemon reports for this container's
#: route back to the host. `safety.check_allowed` accepts exactly these as local, provenance-
#: gated. A fixed interface shared with exploit verification -- do not rename.
EV_HOST_GATEWAY_ENV: Final = "VVAHARNESS_EV_HOST_GATEWAY"


def is_ev_bridge(network: SandboxNetwork) -> bool:
    """Whether *network* is EV's mode: default bridge, `host.docker.internal`, published port.

    Mediation cannot deliver it, because the same container runs S0-S11 inline. Compared with
    `==` so a plain string mode matches the `EgressMode` member it spells.
    """
    return network.mode == EgressMode.EV_BRIDGE


__all__ = [
    "ALLOWLIST_SETTING",
    "CALLBACK_SOCKET",
    "CONTAINED_FLAG",
    "CONTAINER_ENV",
    "EGRESS_CALLBACK_ENV",
    "EGRESS_FORWARDS_ENV",
    "EGRESS_RELAY_PORT",
    "EGRESS_SOCKET_ENV",
    "EV_CALLBACK_PORT",
    "EV_HOST_GATEWAY_ENV",
    "EV_PATH_ENV",
    "HARNESS_ENV_PREFIX",
    "IN_SANDBOX_ENV",
    "MEDIATED_PORTS",
    "MODEL_ENV",
    "REPO_HOST_PATH_ENV",
    "SANDBOXED_COMMANDS",
    "SANDBOX_EGRESS_ENV",
    "VERIFYING_COMMANDS",
    "Capability",
    "CapabilityError",
    "EgressGrant",
    "EgressMode",
    "EnvFamily",
    "EnvPolicy",
    "Mount",
    "SandboxConfig",
    "SandboxConfigError",
    "SandboxEgress",
    "SandboxError",
    "SandboxFs",
    "SandboxLevel",
    "SandboxNetwork",
    "SandboxSpec",
    "SandboxUnavailableError",
    "forward_socket_name",
    "host_of",
    "is_cleartext",
    "is_ev_bridge",
    "is_loopback",
    "is_mediated",
    "is_over_broad",
    "level_for",
    "loopback_message",
    "network_for",
    "network_for_level",
    "require_hostname",
    "require_mediated_port",
]
