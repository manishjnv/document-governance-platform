# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The files git tracks or would add under a directory."""
from __future__ import annotations

import subprocess
from pathlib import Path

from vvaharness.util.git_hardening import GIT_HOST_HARDENING, git_env_without_overrides

# Only stops a wedged git: a large repository lists in under a second
_LIST_TIMEOUT_SECONDS = 120


class GitListingError(RuntimeError):
    """Git could not list a repository's files."""


def list_git_files(directory: Path) -> list[str] | None:
    """Paths under *directory*, relative to it, that git tracks or no ignore rule matches.

    A submodule or a nested repository is listed as its folder.

    Returns:
        The paths, or None when *directory* is not in a git work tree, or git is missing and
        *directory* has no `.git`.

    Raises:
        GitListingError: If git fails or rejects the repository, or is missing for one.
    """
    env = git_env_without_overrides()
    env["LC_ALL"] = "C"  # the not-a-repository check reads an English message
    try:
        done = subprocess.run(
            ["git", "-C", str(directory), *GIT_HOST_HARDENING,
             "ls-files", "-z", "--cached", "--others", "--exclude-standard"],
            capture_output=True, timeout=_LIST_TIMEOUT_SECONDS, env=env, check=False,
        )
    except FileNotFoundError as exc:
        if (directory / ".git").exists():
            raise GitListingError("git is not installed") from exc
        return None
    except (OSError, subprocess.SubprocessError) as exc:
        raise GitListingError(f"git could not list the files ({exc})") from exc
    if done.returncode != 0:
        message = done.stderr.decode("utf-8", errors="replace").strip()
        if "not a git repository" in message:
            if (directory / ".git").exists():
                raise GitListingError("git does not recognise its .git")
            return None
        first_line = message.splitlines()[0] if message else f"exit {done.returncode}"
        raise GitListingError(f"git could not list the files ({first_line})")
    paths = done.stdout.decode("utf-8", errors="surrogateescape").split("\0")
    # A conflicted file is listed once per merge stage
    return list(dict.fromkeys(path for path in paths if path))
