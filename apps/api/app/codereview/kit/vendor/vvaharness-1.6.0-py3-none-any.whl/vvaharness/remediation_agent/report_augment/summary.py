# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""remediation_agent.report_augment.summary — the report-level ``## Remediation Summary``."""
from __future__ import annotations

from vvaharness.models import Provenance
from vvaharness.remediation_agent.report_augment.dto import REMEDIATED, CaseRecord


def _token_line(label: str, provenances: list[Provenance]) -> str:
    """One stage's summed tokens, in the S0-S8 ``Scan Metrics`` vocabulary."""
    if not provenances:
        return f"- {label} tokens (prompt / completion / total): not run\n"
    reported = [p for p in provenances if p.total_tokens is not None]
    if not reported:
        return f"- {label} tokens (prompt / completion / total): unavailable\n"
    prompt = sum(p.prompt_tokens or 0 for p in reported)
    completion = sum(p.completion_tokens or 0 for p in reported)
    total = sum(p.total_tokens or 0 for p in reported)
    unreported = len(provenances) - len(reported)
    note = f" ({unreported} of {len(provenances)} reported no usage)" if unreported else ""
    return (f"- {label} tokens (prompt / completion / total): "
            f"{prompt} / {completion} / {total}{note}\n")


def _stage_provenances(records: list[CaseRecord]) -> tuple[list[Provenance], list[Provenance]]:
    """S10 and S11 provenance of each case's latest attempt, the one the report reflects."""
    s10: list[Provenance] = []
    s11: list[Provenance] = []
    for record in records:
        if record.case is None or not record.case.attempts:
            continue
        latest = record.case.attempts[-1]
        s10.append(latest.remediation.produced_by)
        if latest.verdict is not None:
            s11.append(latest.verdict.produced_by)
    return s10, s11


def _summary_counts(records: list[CaseRecord]) -> dict[str, int]:
    """Tally report-level remediation metrics (true_positive, in_scope, remediated) from the loaded cases."""
    total = len(records)
    false_positive = sum(1 for r in records if r.false_positive)
    remediated = sum(1 for r in records if r.bucket == REMEDIATED)
    return {
        "true_positive": total - false_positive,
        "in_scope": total,
        "remediated": remediated,
    }


def _md_summary_section(records: list[CaseRecord]) -> str:
    """Render the report-level ``## Remediation Summary`` section."""
    c = _summary_counts(records)
    true_positive = c["true_positive"]
    in_scope = c["in_scope"]
    remediated = c["remediated"]
    # The label says "/true positive" -- divide by what it says, not by in_scope (which
    # includes false positives and would understate the rate the label claims to show).
    rate = f"{(remediated / true_positive * 100):.0f}%" if true_positive > 0 else "n/a"
    s10, s11 = _stage_provenances(records)
    return (
        "## Remediation Summary\n"
        f"- Total findings (true positive): {true_positive}\n"
        f"- Findings in scope for remediation: {in_scope}\n"
        f"- Remediated: {remediated}\n"
        f"- Success Rate(remediated/true positive): {rate}\n"
        + _token_line("S10", s10)
        + _token_line("S11", s11)
    )
