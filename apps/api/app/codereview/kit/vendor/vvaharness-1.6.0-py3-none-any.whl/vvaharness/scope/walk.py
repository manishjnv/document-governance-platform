# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The deterministic repo walk, its exclusion rules, and post-agent scope checks."""
from __future__ import annotations

import fnmatch
import os
import re
import stat
from collections.abc import Collection, Iterator
from pathlib import Path
from types import SimpleNamespace

from vvaharness.scope.git_listing import GitListingError, list_git_files
from vvaharness.util import console, logs
from vvaharness.util import errlog as _errlog
from vvaharness.util.git_paths import fold_name

log = logs.get_logger(__name__)

class EmptyScopeError(RuntimeError):
    """No file survived the exclusions, so nothing could be analysed (exit 2)."""


# Deterministic repo walk: s3/s4 see every source file regardless of what the agent explored
_DEFAULT_EXCLUDE_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv", "venv",
    "dist", "build", ".idea", ".vscode", "target", "vendor", ".terraform",
    ".next", ".nuxt", "coverage", ".pytest_cache", ".mypy_cache",
    # Tool caches and copied dependencies
    ".gradle", ".bloop", ".metals", ".dart_tool", ".build", ".tox", ".eggs", ".svelte-kit",
    ".turbo", "bower_components", ".bundle", "third_party", "third-party", "thirdparty",
    # Build output only beside a build file (_BUILD_OUTPUT_MARKERS)
    "bin", "obj", "out", "pods", "artifacts", "cache",
    # `target` excluded only with a build marker; "spec"/"specs" NOT here (UI component folders)
    "test", "tests", "__tests__", "__test__", "e2e", "testdata",
    "fixtures", "__fixtures__", "mocks", "__mocks__", "stubs", "__snapshots__",
    # IaC/CI dirs are KEPT in scope (only .terraform excluded); below: harness output (checkpoints: 1.0.0 only)
    "checkpoints", "security-scan", "security-remediation", ".vvaharness",
}
_DEFAULT_EXCLUDE_EXTS = {
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".svg", ".pdf", ".zip", ".gz",
    ".tar", ".7z", ".jar", ".war", ".class", ".exe", ".dll", ".so", ".dylib",
    ".bin", ".o", ".a", ".obj", ".pyc", ".pyo", ".pkl", ".lock", ".min.js", ".map",
    ".woff", ".woff2", ".ttf", ".eot", ".mp4", ".mp3", ".wav",
    ".rlib", ".wasm", ".whl", ".egg", ".apk", ".aab", ".ipa", ".nupkg", ".pdb", ".lib",
    # Recorded test output and translated strings
    ".snap", ".resx", ".po",
}
# Globs matched against the repo-relative posix path: co-located test files and root infra files
_DEFAULT_EXCLUDE_GLOBS = (
    "**/test_*.py", "**/*_test.py", "**/conftest.py",
    "**/*_test.go", "**/*.test.js", "**/*.test.ts", "**/*.test.jsx", "**/*.test.tsx",
    "**/*.spec.js", "**/*.spec.ts", "**/*.spec.jsx", "**/*.spec.tsx",
    "**/*Test.java", "**/*Tests.java", "**/*IT.java",
    "**/*Test.cs", "**/*Tests.cs", "**/*Test.kt", "**/*Tests.kt",
    "**/*Test.scala", "**/*Spec.scala", "**/*Suite.scala",
    "**/*_spec.rb", "**/*_test.rb", "**/*Test.php", "**/*Test.swift", "**/*Tests.swift",
    "**/*_test.dart", "**/*_test.cc", "**/*_test.cpp", "**/*_unittest.cc", "**/*_unittest.cpp",
    "**/*.t.sol",
    # Generated code and UI stories: findings belong in their source
    "**/*_pb2.py", "**/*_pb2_grpc.py", "**/*.pb.go", "**/*.pb.cc", "**/*.pb.h",
    "**/*.g.cs", "**/*.Designer.cs", "**/*.designer.cs", "**/*.generated.*",
    "**/*.stories.js", "**/*.stories.jsx", "**/*.stories.ts", "**/*.stories.tsx",
    # Dockerfile/Jenkinsfile/Makefile/*.tf and Helm YAML are KEPT; below is repo metadata only
    "**/.gitignore", "**/.gitattributes", "**/.gitmodules", "**/.gitkeep",
    "**/.editorconfig", "**/.dockerignore", "**/.npmignore", "**/.eslintignore",
    "**/.prettierignore", "**/.mailmap", "**/CODEOWNERS", "**/.DS_Store",
    "**/LICENSE", "**/LICENSE.*", "**/NOTICE",
)

# Build output only beside one of its ecosystem's build files; without one the folder is source
_DOTNET_PROJECTS = ("*.csproj", "*.fsproj", "*.vbproj", "*.sln")
_HARDHAT_CONFIGS = ("hardhat.config.js", "hardhat.config.ts", "hardhat.config.cjs",
                    "hardhat.config.mjs")
_BUILD_OUTPUT_MARKERS: dict[str, tuple[str, ...]] = {
    "target": ("pom.xml", "build.gradle", "build.gradle.kts", "Cargo.toml", "build.sbt",
               "project.clj"),
    "build": ("build.gradle", "build.gradle.kts", "CMakeLists.txt", "meson.build", "setup.py",
              "pyproject.toml", "package.json", "pubspec.yaml"),
    "bin": _DOTNET_PROJECTS,
    "obj": _DOTNET_PROJECTS,
    "out": ("foundry.toml",),
    "pods": ("Podfile",),
    "artifacts": _HARDHAT_CONFIGS,
    "cache": _HARDHAT_CONFIGS,
}


def _is_source_dir(parent: Path, name: str) -> bool:
    """True when *name* is a build-output folder name with none of its build files in *parent*."""
    markers = _BUILD_OUTPUT_MARKERS.get(fold_name(name))
    return markers is not None and not any(
        any(parent.glob(marker)) if "*" in marker else (parent / marker).is_file()
        for marker in markers)


def _exclusion_sets(cfg) -> tuple[set[str], set[str], list[str]]:
    """Resolve (dirs, exts, globs) once — built-in defaults + config.yaml step1.* appends."""
    excl_dirs = {fold_name(d) for d in
                 _DEFAULT_EXCLUDE_DIRS | set(getattr(cfg.step1, "exclude_dirs", None) or [])}
    excl_exts = _DEFAULT_EXCLUDE_EXTS | set(getattr(cfg.step1, "exclude_exts", None) or [])
    excl_globs = list(_DEFAULT_EXCLUDE_GLOBS) + list(
        getattr(cfg.step1, "exclude_globs", None) or [])
    return excl_dirs, excl_exts, excl_globs
def glob_hit(rel: str, globs) -> str | None:
    """Return the first glob that excludes the repo-relative posix path `rel`, else None."""
    name = rel.rsplit("/", 1)[-1]
    for g in globs:
        if fnmatch.fnmatchcase(rel, g):
            return g
        if g.startswith("**/") and fnmatch.fnmatchcase(name, g[3:]):
            return g
    return None


def _fold_slashes(p: str) -> str:
    """Posix separators with any leading './' removed."""
    p = p.replace("\\", "/")
    while p.startswith("./"):
        p = p[2:]
    return p


def _norm_rel(repo_root: str, p: str) -> str:
    """Normalize an agent-emitted path to the same repo-relative posix form that _walk_repo produces, so set-mem..."""
    if not p:
        return p
    p = _fold_slashes(p)
    rel_root = str(Path(repo_root)).replace("\\", "/").rstrip("/") + "/"
    abs_root = str(Path(repo_root).resolve()).replace("\\", "/").rstrip("/") + "/"
    pl = p.lower()
    for r in (abs_root, rel_root):
        if pl.startswith(r.lower()):
            return p[len(r):]
    # DeepAgents' vfs is repo-rooted, so "/src/app.py" arrives absolute; strip the virtual root
    return p.lstrip("/")


def resolve_inventory_path(repo_root: str, p: str, inventory: Collection[str]) -> str:
    """*p* in its inventory spelling if any deterministic reading of it is in *inventory*, else its _norm_rel form."""
    if not p:
        return p
    folded = _fold_slashes(p)
    if not inventory:
        # Nothing to resolve against: strip only the virtual root (no inventory path carries one);
        # a root-prefix strip could rewrite a correct path into a wrong one
        return folded.lstrip("/")
    # Raw first: a correct spelling must never lose to a prefix strip (repo dir named like a
    # package dir); the first hit wins, since the string alone cannot tell two readings apart.
    for cand in (folded, folded.lstrip("/"), folded.removeprefix(Path(repo_root).name + "/")):
        if cand in inventory:
            return cand
    return _norm_rel(repo_root, folded)


def _resolve_scope_path(path: str, repo_root: str, keep: set[str],
                        top_dirs: list[str]) -> tuple[str | None, bool]:
    """Resolve an agent-emitted path to its in-scope inventory form."""
    rel = resolve_inventory_path(repo_root, path, keep)
    if rel in keep:
        return rel, False
    matches = [f"{td}/{rel}" for td in top_dirs if f"{td}/{rel}" in keep]
    if len(matches) == 1:
        return matches[0], False
    return None, len(matches) > 1


def scope_after(repo_root: str, cfg, *, dirs=(), exts=(), globs=(),
                max_file_kb: int | None = None) -> list[str]:
    """In-scope inventory _walk_repo yields with these extra step1 exclusions."""
    # A guard on a proposed overlay must measure the walk that actually runs. _survey() is not it — it has no max_file_kb filter.
    base_dirs, base_exts, base_globs = _exclusion_sets(cfg)
    shadow = SimpleNamespace(step1=SimpleNamespace(
        exclude_dirs=sorted(base_dirs | {d.lower() for d in dirs}),
        exclude_exts=sorted(base_exts | set(exts)),
        exclude_globs=list(base_globs) + list(globs),
        max_file_kb=(max_file_kb if max_file_kb is not None
                     else getattr(cfg.step1, "max_file_kb", 1024)),
        follow_symlinks=False,
    ))
    return _walk_repo(repo_root, shadow)[0]


def _candidate_files(top: Path, root: Path, excl_dirs: set[str]) -> Iterator[Path]:
    """Paths under *top*, from git in a repository and from the disk elsewhere."""
    where = top.relative_to(root).as_posix() if top != root else "the scan root"
    try:
        listed = list_git_files(top)
    except GitListingError as exc:
        console.write(f"  [s1] NOTE: {exc} ({where}); walking it from disk, so its "
                      ".gitignore rules are not applied")
        # Recovered: no file is lost, only the ignore rules
        _errlog.log("s1", where, exc, reason="git_list_failed", note="walked from disk instead",
                    recovered=True)
        listed = None
    if listed == []:
        console.write(f"  [s1] NOTE: git lists no file in {where} (an enclosing repository "
                      "ignores it); walking it from disk")
        listed = None
    if listed is None:
        yield from _disk_files(top, root, excl_dirs)
        return
    folders: _FolderSpelling = {}
    ignores_case = _ignores_case(top)
    for entry in listed:
        path = (_disk_spelling(top, entry.rstrip("/"), folders) if ignores_case
                else top / entry.rstrip("/"))
        if path.is_dir() and not _is_link(path):
            # A submodule or nested repository: git lists the folder, not its files
            if (path / ".git").exists():
                yield from _candidate_files(path, root, excl_dirs)
            else:
                yield from _disk_files(path, root, excl_dirs)
        else:
            yield path


def _ignores_case(directory: Path) -> bool:
    """True when *directory*'s filesystem ignores case (macOS and Windows by default)."""
    spelled = str(directory.resolve())
    swapped = spelled.swapcase()
    return swapped != spelled and os.path.exists(swapped)


_FolderSpelling = dict[str, tuple[Path, frozenset[str], dict[str, str]]]


def _disk_spelling(top: Path, entry: str, folders: _FolderSpelling) -> Path:
    """*entry* under *top* as spelled on disk, which the rest of the scan uses.

    On a case-insensitive filesystem git's spelling of a folder can differ from the disk's.
    """
    folder, _, name = entry.rpartition("/")
    path, exact, folded = _spelled_folder(top, folder, folders)
    return path / (name if name in exact else folded.get(name.casefold(), name))


def _spelled_folder(top: Path, folder: str,
                    folders: _FolderSpelling) -> tuple[Path, frozenset[str], dict[str, str]]:
    """The disk path and names of git folder *folder*, cached in *folders*."""
    cached = folders.get(folder)
    if cached is None:
        path = _disk_spelling(top, folder, folders) if folder else top
        try:
            names = os.listdir(path)
        except OSError:
            names = []
        cached = (path, frozenset(names), {name.casefold(): name for name in names})
        folders[folder] = cached
    return cached


def _disk_files(top: Path, root: Path, excl_dirs: set[str]) -> Iterator[Path]:
    """Paths under *top* on disk; a nested repository outside an excluded folder goes to its git.

    Excluded folders are still walked so their files are counted as excluded.
    """
    in_excluded: set[Path] = set()
    for dirpath, dirnames, filenames in os.walk(top):
        current = Path(dirpath)
        excluded = current in in_excluded
        if not excluded and current != top and (current / ".git").exists():
            dirnames[:] = []
            yield from _candidate_files(current, root, excl_dirs)
            continue
        in_excluded.update(
            current / name for name in dirnames
            if excluded or (fold_name(name) in excl_dirs and not _is_source_dir(current, name)))
        for name in filenames:
            yield current / name


# Windows symlink and junction tags; other reparse points (cloud placeholders) are real entries
_LINK_REPARSE_TAGS = frozenset({
    getattr(stat, "IO_REPARSE_TAG_SYMLINK", 0xA000000C),
    getattr(stat, "IO_REPARSE_TAG_MOUNT_POINT", 0xA0000003),
})


def _is_link(path: Path) -> bool:
    """True when *path* is a symlink or a Windows junction (is_symlink() misses junctions)."""
    try:
        status = path.lstat()
    except OSError:
        return False
    return stat.S_ISLNK(status.st_mode) or getattr(status, "st_reparse_tag", 0) in _LINK_REPARSE_TAGS


def _folder_inside(folder: Path, root_resolved: Path, cache: dict[Path, bool]) -> bool:
    """True when *folder* resolves inside the root; only a linked folder is resolved."""
    inside = cache.get(folder)
    if inside is None:
        if folder.parent == folder or not _folder_inside(folder.parent, root_resolved, cache):
            inside = False
        elif _is_link(folder):
            try:
                inside = folder.resolve().is_relative_to(root_resolved)
            except OSError:
                inside = False
        else:
            inside = True
        cache[folder] = inside
    return inside


def _walk_repo(repo_root: str, cfg) -> tuple[list[str], dict]:
    root = Path(repo_root)
    root_resolved = root.resolve()
    excl_dirs, excl_exts, excl_globs = _exclusion_sets(cfg)
    max_kb = getattr(cfg.step1, "max_file_kb", 1024)
    # Off-root symlinks are dropped UNCONDITIONALLY (host-file exfil); follow_symlinks only warns
    follow_symlinks = bool(getattr(cfg.step1, "follow_symlinks", False))
    if follow_symlinks:
        console.write("  [s1] NOTE: step1.follow_symlinks is set, but symlinks whose "
                      "target resolves outside the repo are still dropped (host-file "
                      "disclosure guard); only in-tree symlinks are followed.")

    out: list[str] = []
    skipped_dirs: dict[str, int] = {}
    skipped_exts: dict[str, int] = {}
    skipped_globs: dict[str, int] = {}
    skipped_size: list[tuple[str, int]] = []
    skipped_symlinks: dict[str, int] = {}
    skipped_symlink_targets: dict[str, int] = {}

    # Cached per folder: _rule_hit runs once per file
    source_dirs: dict[tuple[str, str], bool] = {}

    def _source_dir(parent_rel: str, name: str) -> bool:
        key = (parent_rel, fold_name(name))
        if key not in source_dirs:
            source_dirs[key] = _is_source_dir(root / parent_rel, name)
        return source_dirs[key]

    def _rule_hit(r: str) -> tuple[dict[str, int], str] | None:
        """(bucket, key) of the first dir/ext/glob rule excluding path *r*."""
        parts = r.split("/")
        hit_idx = next(
            (i for i, part in enumerate(parts[:-1])
             if fold_name(part) in excl_dirs and not _source_dir("/".join(parts[:i]), part)),
            None)
        if hit_idx is not None:
            return skipped_dirs, "/".join(parts[:hit_idx + 1])
        name = parts[-1].lower()
        hit_ext = next((e for e in excl_exts
                        if Path(name).suffix == e or name.endswith(e)), None)
        if hit_ext:
            return skipped_exts, hit_ext
        hit_glob = glob_hit(r, excl_globs)
        if hit_glob:
            return skipped_globs, hit_glob
        return None

    folders_inside: dict[Path, bool] = {root: True}
    for p in _candidate_files(root, root, excl_dirs):
        if not p.is_file():
            continue
        rel = str(p.relative_to(root)).replace("\\", "/")
        # A crafted git index can name a file through a symlinked folder
        if not _folder_inside(p.parent, root_resolved, folders_inside):
            skipped_symlinks[rel] = skipped_symlinks.get(rel, 0) + 1
            continue
        # UNCONDITIONAL: no config re-opens an escaping symlink
        tgt_rel = None
        if p.is_symlink():
            try:
                tgt = p.resolve(strict=False)
                escapes = not tgt.is_relative_to(root_resolved)
                if not escapes:
                    tgt_rel = tgt.relative_to(root_resolved).as_posix()
            except OSError as _sym_err:
                escapes = True
                _errlog.log("s1", rel, _sym_err, reason="symlink_resolve_failed",
                            note="treated as escaping — file excluded from scope")
            if escapes:
                skipped_symlinks[rel] = skipped_symlinks.get(rel, 0) + 1
                continue
        hit = _rule_hit(rel)
        if hit:
            bucket, key = hit
            bucket[key] = bucket.get(key, 0) + 1
            continue
        # An in-root link is judged by its target too, or a.txt -> key.pem smuggles it into scope
        if tgt_rel is not None and _rule_hit(tgt_rel):
            skipped_symlink_targets[rel] = skipped_symlink_targets.get(rel, 0) + 1
            continue
        try:
            sz = p.stat().st_size
            if sz > max_kb * 1024:
                skipped_size.append((rel, sz))
                continue
        except OSError as _stat_err:
            _errlog.log("s1", rel, _stat_err, reason="stat_failed",
                        note="file excluded from scan scope")
            continue
        out.append(rel)

    excluded = {
        "dirs": skipped_dirs,
        "exts": skipped_exts,
        "globs": skipped_globs,
        "oversize": len(skipped_size),
        "oversize_files": sorted(skipped_size, key=lambda kv: -kv[1]),
        "symlinks": skipped_symlinks,
        "symlink_targets": skipped_symlink_targets,
    }
    return sorted(out), excluded


# Collapses many per-env config copies to one per shape-cluster; only if the secret regex clears

_DEDUP_DEFAULTS = {
    "enabled": True,
    "exts": (".yml", ".yaml", ".json", ".toml", ".ini",
             ".properties", ".conf", ".cfg", ".env"),
    "min_cluster_size": 3,
    "keep_per_top_dir": True,
    "promote_on_secret_hit": True,
    "promote_on_insecure_value": True,
    "max_file_kb": 512,
}

# Layer-2 net: real credential material must never be dropped; lookahead skips templated refs
_SECRET_RX = re.compile(
    r"(?i)(?:password|passwd|pwd|secret|api[_-]?key|apikey|access[_-]?key|"
    r"auth[_-]?token|private[_-]?key|client[_-]?secret|credential)s?"
    r"[ \t]*[:=][ \t]*['\"]?"
    r"(?!CRYPT:|ENC\(|\{\{|\$\{|<%=|<%|vault:|secret:|file:|/)"
    r"(?![\w.-]+[ \t]*:)"
    r"[^\s'\",}{]{8,}"
    r"|-----BEGIN [A-Z ]*PRIVATE KEY-----"
    r"|\bAKIA[0-9A-Z]{16}\b"
    r"|\bxox[baprs]-[0-9A-Za-z-]{10,}\b"
    r"|\bgh[pousr]_[0-9A-Za-z]{36,}\b"
    r"|\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"
)

# Insecure *values*, not secrets: they make a variant worth scanning despite a safe-sibling shape
_INSECURE_RX = re.compile(
    r"(?i)\b(?:verify|verif(?:y|ication)[_-]?ssl|ssl[_-]?verify|"
    r"validate[_-]?cert\w*|tls[_-]?verify|check[_-]?hostname|"
    r"reject[_-]?unauthori[sz]ed)\b\s*[:=]\s*['\"]?(?:false|0|no|none|off)\b"
    r"|\binsecure\w*\s*[:=]\s*['\"]?(?:true|1|yes)\b"
    r"|\bInsecureSkipVerify\s*[:=]\s*true\b"
    r"|\b(?:auth|authentication|authn|security)\s*[:=]\s*['\"]?(?:none|disabled|off|false)\b"
    r"|\bdebug\s*[:=]\s*['\"]?(?:true|1|yes)\b"
    r"|\ballow[_-]?anonymous\s*[:=]\s*['\"]?(?:true|1|yes)\b"
)
