# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The CLI's one containment decision: run here, or run the whole invocation inside a sandbox."""

from __future__ import annotations

import os
import re
import secrets
import signal
import subprocess
import sys
import threading
import time
from contextlib import contextmanager, suppress
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Final

from vvaharness.backends.sandbox.config import (
    GIT_HOST_HARDENING,
    REPO_TARGET,
    STATE_TARGET,
    env_policy,
    host_git_env,
    host_paths_note,
    load_sandbox_config,
    refuse_batch,
    refuse_split_overlay,
    requested,
    resolve,
)
from vvaharness.backends.sandbox.models import (
    CONTAINED_FLAG,
    IN_SANDBOX_ENV,
    REPO_HOST_PATH_ENV,
    SANDBOX_EGRESS_ENV,
    SANDBOXED_COMMANDS,
    VERIFYING_COMMANDS,
    SandboxConfig,
    SandboxConfigError,
    SandboxError,
    SandboxUnavailableError,
)
from vvaharness.backends.sandbox.remap import filter_env, forwarded_argv, path_flags
from vvaharness.validation.constants.artifacts import VALIDATE_COMMANDS

if TYPE_CHECKING:
    from collections.abc import Iterator, Mapping, Sequence

    from vvaharness.backends.sandbox.models import SandboxSpec

#: Runs one invocation uncontained without editing a profile. Consumed here so it never
#: reaches the inner argument parser.
NO_SANDBOX_FLAG: Final = "--no-sandbox"

#: The help flags, and the subcommands that answer one by printing help and exiting before any
#: config load or stage runs: containment is skipped only where nothing would run inside the
#: container.
_HELP_FLAGS: Final = frozenset({"-h", "--help"})
_HELP_COMMANDS: Final = frozenset({"scan", "ev-replay", "remediate", *VALIDATE_COMMANDS})

#: The env var naming the state directory, forced to its in-container target: the host value is
#: a host path, and leaving it unset sends the contained run to `$HOME/.vvaharness/state`, which
#: is inside the container and disappears with it -- silently breaking checkpoints and --resume.
_STATE_DIR_ENV: Final = "VVAHARNESS_STATE_DIR"

#: The shape `secrets.token_hex(16)` mints. Only the FORM is checkable here -- presence is the
#: provenance signal and there is no stored value to compare against.
_NONCE_RX: Final = re.compile(r"\A[0-9a-f]{32}\Z")

#: Baked root-owned into the sandbox image (docker/sandbox/Dockerfile), on a read-only root
#: filesystem the contained run cannot write; on a host only root can create it. The same file
#: `exploit_verification.safety` requires, mirrored as a literal to keep EV off this import path.
_CONTAINED_MARKER: Final = Path("/etc/vvaharness/contained")

#: How a contained run is stopped from outside other than Ctrl-C: `kill`, `timeout`, a CI cancel,
#: a closed terminal. Their default action ends this process before `teardown` can run.
_TERMINATING: Final = tuple(getattr(signal, name) for name in ("SIGTERM", "SIGHUP")
                            if hasattr(signal, name))

#: What a `.git` the contained run created at a target that had none is renamed to: out of
#: git's way, kept for the operator to inspect.
_QUARANTINE_PREFIX: Final = ".git.vvaharness-quarantine-"


def _default_config() -> Path:
    """The profile `cli._config_path_from` would resolve, imported lazily.

    Importing `vvaharness.orchestrator.config_paths` executes the orchestrator package, which
    pulls the pipeline and the LLM backends (~2300 modules); the gate runs for every command.
    """
    from vvaharness.orchestrator.config_paths import (  # noqa: PLC0415 — lazy: see docstring
        _default_config as resolve_default,
    )

    return resolve_default()


def strip_flag(argv: list[str]) -> tuple[list[str], bool]:
    """Split *argv* into the remaining arguments and whether containment was declined."""
    remaining = [arg for arg in argv if arg != NO_SANDBOX_FLAG]
    return remaining, len(remaining) != len(argv)


def strip_contained_flag(argv: list[str]) -> tuple[list[str], str | None]:
    """Split *argv* into the remaining arguments and the re-exec nonce it carried.

    The nonce is `""` for the flag without a value and `None` when the flag is absent, so "was it
    there" stays distinguishable from "what did it say".
    """
    remaining: list[str] = []
    nonce: str | None = None
    want_value = False
    for arg in argv:
        if want_value:
            nonce, want_value = arg, False
            continue
        if arg == CONTAINED_FLAG:
            nonce, want_value = "", True
            continue
        if arg.startswith(f"{CONTAINED_FLAG}="):
            nonce = arg.split("=", 1)[1]
            continue
        remaining.append(arg)
    return remaining, nonce


def record_provenance(nonce: str | None) -> None:
    """Make the env marker say exactly what the argv nonce says, for child processes only.

    Stage code checks the marker's presence, so an ambient host value must be cleared when the
    gate did not re-exec this process.

    Raises:
        SandboxConfigError: If the flag was present carrying something the gate never mints
            (empty, wrong length, non-hex). Accepting it would make a hand-written bare
            `--_contained` an undocumented `--no-sandbox`: the caller skips the gate on
            presence alone. Also if a well-formed one arrives outside the sandbox image:
            only the nonce's form is checkable, so the image's marker file is what proves
            this process is the gate's re-exec rather than a host run acting contained.
    """
    if nonce is None:
        os.environ.pop(IN_SANDBOX_ENV, None)
        return
    if not _NONCE_RX.match(nonce):
        os.environ.pop(IN_SANDBOX_ENV, None)
        msg = (f"{CONTAINED_FLAG} carries a malformed nonce ({nonce!r}): the containment gate "
               f"mints 32 lowercase hex characters and nothing else may pass this flag.")
        raise SandboxConfigError(msg)
    if os.name != "posix" or not _CONTAINED_MARKER.is_file():
        os.environ.pop(IN_SANDBOX_ENV, None)
        msg = (f"{CONTAINED_FLAG} is only valid inside the sandbox image, which carries "
               f"{_CONTAINED_MARKER}; on the host it would make this run act contained "
               f"without being so. Remove the flag; a custom sandbox.image must carry the file.")
        raise SandboxConfigError(msg)
    os.environ[IN_SANDBOX_ENV] = nonce


def containment_eligible(stripped: list[str], declined: bool) -> bool:
    """Whether *stripped* is even a candidate for containment.

    True only for a sandboxed subcommand that was not opted out with `--no-sandbox` and does not
    already carry the gate's `--_contained` nonce. Provenance is argv-only: a stale host
    `VVAHARNESS_IN_SANDBOX` must never disable the boundary. A request for help to a command
    that only prints it (`_HELP_COMMANDS`) is not contained: a container, and the run lock,
    would serve nothing.
    """
    options = stripped[1:stripped.index("--")] if "--" in stripped else stripped[1:]
    asks_help = (bool(stripped) and stripped[0] in _HELP_COMMANDS
                 and bool(_HELP_FLAGS & set(options)))
    return (bool(stripped) and stripped[0] in SANDBOXED_COMMANDS
            and not declined and strip_contained_flag(stripped)[1] is None
            and not asks_help)


def _effective_config(flag_paths: Mapping[str, Path],
                      vetted: Path | str | None = None) -> Path:
    """The profile the gate decided from: the path it already trust-gated when it passed one.

    Re-deriving it here would read cwd a second time, ungated — inside a container cwd IS the
    target. The fallback mirrors `cli._config_path_from` for callers that vet nothing.
    """
    if vetted is not None:
        return Path(vetted).resolve()
    given = flag_paths.get("--config")
    return (given if given is not None else _default_config()).resolve()


@contextmanager
def _unwinding_on_termination() -> Iterator[None]:
    """Turn SIGTERM and SIGHUP into `SystemExit(128 + signum)` for the duration of the block.

    Left at their default they end the process on the spot: `_contain`'s teardown never runs,
    and the container keeps running the scan unwatched. Only a signal still at its default is
    taken, so an embedding caller's own handler is left alone, and only on the main thread, the
    one Python runs handlers on.
    """
    if threading.current_thread() is not threading.main_thread():
        yield
        return
    taken = [signum for signum in _TERMINATING if signal.getsignal(signum) is signal.SIG_DFL]

    def _unwind(signum: int, _frame: object) -> None:
        # A second signal must not cut short the teardown the first one started.
        for each in taken:
            signal.signal(each, signal.SIG_IGN)
        raise SystemExit(128 + signum)

    for signum in taken:
        signal.signal(signum, _unwind)
    try:
        yield
    finally:
        for signum in taken:
            signal.signal(signum, signal.SIG_DFL)


#: The entries a bare git repository is made of: when git reports the root as a bare repo
#: (`_root_is_bare_repo`), these are what the quarantine moves aside. `branches`/`hooks`/`info`
#: are not load-bearing for the detection, but are swept too so no half of a repo is left.
_BARE_MARKERS: Final = ("HEAD", "objects", "refs", "config", "packed-refs",
                        "branches", "hooks", "info")


@dataclass(frozen=True)
class _GitWatch:
    """What the gate records before a writable run so it can quarantine planted git metadata after.

    A target with no `.git` of its own, such as a folder inside a larger checkout, gets no
    read-only one mounted, so a writable run could plant git metadata -- a `.git`, or a bare
    layout at the root -- whose hook, `core.fsmonitor` or driver would run on this machine the
    next time git runs there.
    """

    planted_git: Path | None            #: `<root>/.git` to quarantine if the run creates it
    root: Path                          #: the target root, watched for a planted bare layout
    bare_before: bool                   #: whether host git already saw the root as a bare repo


def _watch_git(spec: SandboxSpec, repo: Path) -> _GitWatch:
    """Record the target's git state before a writable run; an empty watch for a read-only one."""
    root = repo.resolve()
    if not any(m.target == REPO_TARGET and m.writable for m in spec.mounts):
        return _GitWatch(None, root, False)
    meta = root / ".git"
    planted = meta if not (meta.is_symlink() or meta.exists()) else None
    return _GitWatch(planted, root, _root_is_bare_repo(root))


def _root_is_bare_repo(root: Path) -> bool:
    """Whether host git, run at *root*, would treat the root itself as a bare repository.

    The oracle for a planted bare layout: git's own answer, not a guess at which marker files
    make one. `GIT_CEILING_DIRECTORIES` stops git climbing above the root to a real parent repo,
    and `safe.bareRepository=all` makes it willing to use a bare layout, as a host without the
    image's pin is. `GIT_HOST_HARDENING` and the scrubbed env (`host_git_env`) keep the target's
    own `core.fsmonitor`/hook from running on this host as git reads the layout. Best effort:
    anything unreadable is "not a repo", never a crash.
    """
    try:
        done = subprocess.run(  # noqa: S603 — fixed argv
            ["git", "-C", str(root), *GIT_HOST_HARDENING,  # noqa: S607
             "-c", "safe.bareRepository=all", "rev-parse", "--absolute-git-dir"],
            capture_output=True, timeout=30,
            env=host_git_env(root),
        )
    except (OSError, subprocess.SubprocessError):
        return False
    if done.returncode != 0:
        return False
    found = done.stdout.decode("utf-8", "replace").strip()
    return bool(found) and Path(found).resolve() == root


def _move_aside(target: Path, aside: Path, what: str) -> bool:
    """Rename *target* into *aside*; True on success. Says what it was and where it went."""
    try:
        aside.parent.mkdir(parents=True, exist_ok=True)
        target.rename(aside)  # a symlink is renamed itself, never what it points at
    except OSError as exc:
        print(f"  WARN: sandbox: the contained run created {target}, {what}, and it could not "
              f"be moved aside ({exc}). Delete it before you run git there.", file=sys.stderr)
        return False
    print(f"  WARN: sandbox: the contained run created {target}, {what}. It was moved to "
          f"{aside}; inspect it, then delete it.", file=sys.stderr)
    return True


def _quarantine_planted_git(watch: _GitWatch) -> bool:
    """Move aside git metadata the contained run created where there was none; True if all clean.

    Two shapes, handled independently so a run that plants both is fully cleaned: a `.git`
    directory or link at the target root, and a bare layout written directly at the root. The
    bare case is decided by whether host git now treats the root as a bare repository when it
    did not before the run (`_root_is_bare_repo`), not by which marker names are new, so a
    layout the run completes from files the target already shipped is still caught.
    """
    stamp = time.strftime("%Y%m%dT%H%M%S")
    clean = True
    meta = watch.planted_git
    if meta is not None and (meta.is_symlink() or meta.exists()):
        clean &= _move_aside(meta, meta.with_name(f"{_QUARANTINE_PREFIX}{stamp}"),
                             "a .git that git run there would use, with any hook or driver named")
    if not watch.bare_before and _root_is_bare_repo(watch.root):
        # A distinct name from the planted-.git quarantine above, so a run that plants both does
        # not nest the bare markers inside the moved .git.
        aside = watch.root / f"{_QUARANTINE_PREFIX}{stamp}-bare"
        present = [name for name in _BARE_MARKERS
                   if (watch.root / name).exists() or (watch.root / name).is_symlink()]
        for name in present:
            clean &= _move_aside(watch.root / name, aside / name,
                                 "part of a bare git repository git run there would use, with "
                                 "any hook or driver it names")
    return clean


@contextmanager
def _dropping_unused_state(repo: Path) -> Iterator[None]:
    """Remove the target's contained state subtree again if the gate refuses before any run.

    `spec_from` creates the subtree before its mount checks, so a refused run would leave an
    empty one behind, and later uncontained commands would report contained state that never
    existed. Only a subtree this call created, and only while still empty (`rmdir`), is removed.
    """
    from vvaharness.orchestrator import store  # noqa: PLC0415 — lazy: see _default_config
    from vvaharness.orchestrator.checkpoints import run_id_for  # noqa: PLC0415

    location = store.contained_state_location(run_id_for(repo))
    fresh = not os.path.lexists(location)
    try:
        yield
    except SandboxError:
        if fresh and location.is_dir() and not location.is_symlink():
            with suppress(OSError):  # no longer empty or not removable: `vvaharness gc` reaps it
                location.rmdir()
        raise


def _contain(
    cfg: SandboxConfig, argv: list[str], repo: Path, log_flags: Sequence[str] = (),
    config_path: Path | str | None = None,
) -> int:
    """Run *argv* inside the configured sandbox and return its exit code."""
    flag_paths = dict(path_flags(argv))
    # Judged on the path the host loaded the profile from, before `_effective_config` resolves it
    refuse_split_overlay(Path(config_path) if config_path is not None
                         else flag_paths.get("--config"))
    config_path = _effective_config(flag_paths, config_path)
    # Mount the profile even when argv never named it: the contained run is given it explicitly.
    flag_paths["--config"] = config_path
    with _dropping_unused_state(repo):
        sandbox, spec = resolve(cfg, repo, flag_paths, command=argv[0])
        sandbox.preflight(spec)
    git_watch = _watch_git(spec, repo)
    nonce = secrets.token_hex(16)
    with _unwinding_on_termination():
        try:
            env = filter_env(
                os.environ,
                env_policy(cfg),
                {
                    _STATE_DIR_ENV: str(STATE_TARGET),
                    REPO_HOST_PATH_ENV: str(repo.resolve()),
                    IN_SANDBOX_ENV: nonce,
                    SANDBOX_EGRESS_ENV: cfg.egress.value,
                },
                spec.mounts,
            )
            if argv[0] not in VERIFYING_COMMANDS:  # never verifies: no EV setting or secret
                env = {key: value for key, value in env.items() if not key.startswith("EV_")}
            forwarded = forwarded_argv(
                argv, spec.mounts, config_path=config_path, nonce=nonce, log_flags=log_flags,
            )
            code = sandbox.run(forwarded, env, spec.timeout)
        finally:
            try:
                sandbox.teardown()
            finally:
                # Once the container is gone, so nothing can put it back. Planted git metadata
                # that could not be moved aside is live on the host, so an otherwise-clean run
                # fails rather than reporting success over a WARN the operator may miss.
                quarantined_clean = _quarantine_planted_git(git_watch)
    if not quarantined_clean and code == 0:
        code = 2
    # After the run, whatever its exit code: the paths it printed are the container's.
    print(host_paths_note(spec.mounts, argv[0]), file=sys.stderr)
    return code


def maybe_contain(
    argv: list[str], config: object, repo: Path | None, log_flags: Sequence[str] = (),
    *, config_path: Path | str | None = None,
) -> int | None:
    """Run *argv* inside a sandbox and return its exit code, or `None` to run uncontained.

    Returns `None` when this is not a sandboxed subcommand, containment was declined with
    `--no-sandbox`, this process is already the contained one, or no profile asked for it.
    *log_flags* are the `--log-level`/`--log-file` tokens the CLI consumed before the gate ran;
    they are appended to the contained argv so the inner run logs the same way. *config_path* is
    the path *config* was loaded from once the caller's trust gate vetted it; it is mounted and
    forwarded instead of being resolved a second time.

    Raises:
        SandboxUnavailableError: If a profile asks for containment but no `--repo` was given.
            Refusing is the point: a run that silently escapes the sandbox it was configured
            to have is the one outcome this must never produce.
        SandboxError: If another command against the same target holds its run lock.
    """
    remaining, declined = strip_flag(argv)
    if not containment_eligible(remaining, declined):
        return None
    cfg = load_sandbox_config(config)
    if not requested(cfg):
        return None
    # Before the --repo check: `--repo-file` alone would otherwise get the generic refusal
    refuse_batch(dict(path_flags(remaining)))
    if repo is None:
        msg = (
            "this profile requests a sandbox, which needs a target directory to mount, but "
            "no --repo was given. Pass --repo, or run with --no-sandbox."
        )
        raise SandboxUnavailableError(msg)
    return _contain_locked(cfg, remaining, repo, log_flags, config_path)


def _contain_locked(
    cfg: SandboxConfig, argv: list[str], repo: Path, log_flags: Sequence[str],
    config_path: Path | str | None,
) -> int:
    """`_contain` *argv* while holding its target's run lock here, on the host.

    Every contained command, not only `scan`: each reads and writes the target's contained
    state subtree, which `gc` removes only when this lock is free, and two contained commands
    against one target would share it. Docker Desktop does not carry file locks across the
    state mount, so a lock taken inside the container is invisible here; the contained scan
    skips its own.

    Raises:
        SandboxError: If another command against the same target holds the lock.
    """
    from vvaharness.orchestrator import store  # noqa: PLC0415 — lazy: see _default_config
    from vvaharness.orchestrator.checkpoints import run_id_for  # noqa: PLC0415

    run_id = run_id_for(repo)
    with store.run_lock(run_id) as acquired:
        if not acquired:
            if argv[0] == "scan":
                msg = (f"scan already in progress for this repo (run_id {run_id[:12]}…); "
                       f"retry or use --resume when it completes")
            else:
                msg = (f"another vvaharness command is using this repo's state (run_id "
                       f"{run_id[:12]}…), so a contained {argv[0]} cannot run beside it; "
                       f"retry when it completes")
            raise SandboxError(msg)
        return _contain(cfg, argv, repo, log_flags, config_path)


__all__ = [
    "CONTAINED_FLAG",
    "NO_SANDBOX_FLAG",
    "containment_eligible",
    "maybe_contain",
    "record_provenance",
    "strip_contained_flag",
    "strip_flag",
]
