# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""The non-scan subcommand handlers: doctor, estimate, gc, validate, remediate, ev-replay."""
from __future__ import annotations
from vvaharness.util import logs

from pathlib import Path

from vvaharness.cli._paths import (
    _config_path_from,
    _config_path_from_explicit,
    _load_and_configure,
    _repo_from,
)
from vvaharness.util import console
from vvaharness.util.events import Event

log = logs.get_logger(__name__)

_ICON = {"ok": "✓", "warn": "⚠", "fail": "✗"}


def _doctor(rest: list[str]) -> int:
    """Read-only diagnostic: static readiness checks, a live backend probe, and opt-in --cache-probe."""
    if "--help" in rest or "-h" in rest:
        # Without this, asking for help RUNS the diagnostic against live backends.
        print(
            "usage: vvaharness doctor [--config PATH] [--cache-probe]\n"
            "\n"
            "Check credentials and live backend connectivity (read-only).\n"
            "Exits non-zero on any blocking issue or probe failure.\n"
            "\n"
            "  --config PATH   config to check (same resolution as `scan`)\n"
            "  --cache-probe   additionally run a prompt-cache diagnostic against\n"
            "                  each configured model route. Spends real tokens;\n"
            "                  prints an estimate first. Never runs during a scan.\n"
        )
        return 0

    from vvaharness.orchestrator import probe_backends
    from vvaharness.util import environment as env
    cfg_path = _config_path_from(rest)
    if not Path(cfg_path).exists():
        console.write(f"doctor: config not found: {cfg_path}")
        return 2
    cfg = _load_and_configure(cfg_path, "doctor")
    if cfg is None:
        return 2

    checks = env.run_checks(cfg_path)
    for c in checks:
        print(f"  {_ICON.get(c.status, '?')} {c.name:<30} {c.detail}")
    n_ok, n_warn, n_blocking = env.summarize(checks)
    print("  " + "─" * 60)
    print(f"  {n_ok} ok · {n_warn} warning(s) · {n_blocking} blocking issue(s)")

    if n_blocking:
        print("  [probe] skipped — fix the blocking item(s) above first")
        return 1
    rc = 0 if probe_backends(cfg) else 1
    # tls_check() cannot see an OS-store CA a via:cli Node child trusts, so reconcile its WARN
    tls = next((c for c in checks if c.name == "TLS / CA cert"), None)
    if rc == 0 and tls is not None and tls.status != env.OK:
        print("  Note: the TLS/CA warning above didn't block anything — the "
              "live probe just reached the configured endpoint successfully "
              "using this run's actual credentials/trust path.")
    if "--cache-probe" in rest:
        if rc != 0:
            console.write("  [cache-probe] skipped — fix the backend probe failure(s) "
                          "above first")
            return rc
        from vvaharness.orchestrator.preflight import run_cache_probe
        rc = 0 if run_cache_probe(cfg) else 1
    return rc

def _estimate(rest: list[str]) -> int:
    from stat import S_ISDIR

    from vvaharness import config as config_mod
    from vvaharness.orchestrator import trusted_config
    from vvaharness.scope import _walk_repo

    if "--help" in rest or "-h" in rest:
        print("usage: vvaharness estimate --repo <path> [--config PATH]\n"
              "Offline S1 scope preview and heuristic S1-S9 token budget.")
        return 0
    repo = _repo_from(rest)
    if not repo:
        console.write("usage: vvaharness estimate --repo <path> [--config PATH]")
        return 2
    root = Path(repo)
    try:
        directory = S_ISDIR(root.stat().st_mode)
    except FileNotFoundError as error:
        if getattr(error, "winerror", None) == 206:
            console.write("estimate: invalid repository path: path is too long")
            return 2
        console.write(f"not a repository directory: {repo}")
        return 1
    except (OSError, ValueError) as error:
        console.write(f"estimate: invalid repository path: {error}")
        return 2
    if not directory:
        console.write(f"not a repository directory: {repo}")
        return 1
    cfg_path, explicit = _config_path_from_explicit(rest)
    try:
        cfg_path = trusted_config(cfg_path, root, explicit=explicit)
        cfg = config_mod.load(cfg_path)
        inventory, _excluded = _walk_repo(str(root), cfg)
    except (OSError, ValueError, config_mod.ConfigPolicyError) as error:
        console.write(f"estimate: {error}")
        return 2
    files = bytes_ = 0
    for relative in inventory:
        try:
            bytes_ += (root / relative).stat().st_size
            files += 1
        except OSError:
            pass
    approx_tokens = bytes_ // 4
    print(f"scope estimate for {repo}")
    print(f"  in-scope files   : {files:,}")
    print(f"  bytes            : {bytes_:,}")
    print(f"  ~source tokens   : {approx_tokens:,} (bytes/4, not pipeline usage)")
    lower = 250_000 + 5 * approx_tokens if files else 0
    upper = 1_000_000 + 20 * approx_tokens if files else 0
    print(f"  S1-S9 input budget: {lower:,}-{upper:,} tokens (heuristic)")
    print("  assumes 250k-1M fixed prompt/tool overhead plus 5-20x source tokens.")
    print("  Not a measured forecast or spend cap; agent turns, findings, retries")
    print("  and cache billing can put actual usage outside this range. S10/S11")
    print("  and exploit verification are extra. No model calls were made.")
    print("  Scope is before config dedup and optional auto-exclusions; use")
    print("  --stop-after s3 for the final inventory. Cost depends on model pricing.")
    return 0

def _gc(rest: list[str]) -> int:
    """Delete old run records from the SQLite state DB and their code-graph workspaces, keeping reports under security-scan/ untouched."""
    import argparse
    import contextlib

    from vvaharness.orchestrator.checkpoints import prune_checkpoints, run_id_for
    ap = argparse.ArgumentParser(prog="vvaharness gc")
    ap.add_argument("--keep-runs", type=int, default=100,
                    help="retain the N most-recent run_ids (default: 100)")
    ap.add_argument("--max-age-days", type=int, default=5,
                    help="delete runs older than D days (default: 5)")
    ap.add_argument("--run", metavar="PATH",
                    help="fully evict the run for this repo PATH (its run_id is "
                         "derived from the path) instead of age/count pruning")
    ap.add_argument("--dry-run", action="store_true",
                    help="show what would be deleted; touch nothing")
    a = ap.parse_args(rest)
    from vvaharness.orchestrator import store

    if a.run:
        rid = run_id_for(a.run)
        if a.dry_run:
            try:
                exists = store.run_exists(rid)
            except store.StoreError as error:
                log.error(Event.STORE_UNUSABLE, detail=str(error))
                return 2
            if exists:
                print(f"  [dry-run] gc: would evict run {rid} for {a.run}")
            else:
                print(f"  [dry-run] gc: no run recorded for {a.run} (run_id {rid}); nothing to do")
            if store.contained_state_location(rid).is_dir():
                print(f"  [dry-run] gc: would remove the contained-run state for {a.run}")
            return 0
        # Held across all three, as the age prune does: a scan or contained command against
        # this target is using the rows, artifacts and contained state being deleted. With no
        # state root nothing holds it, and taking it would create the root gc must not.
        lock = (store.run_lock(rid) if store.state_root().exists()
                else contextlib.nullcontext(True))
        try:
            with lock as acquired:
                if not acquired:
                    console.mark("fail", f"gc: a command is using {a.run} (run_id {rid[:12]}…); "
                                         f"nothing was removed, retry when it completes")
                    return 2
                # Purge the relocated artifact trees FIRST so the eviction message can report
                # how many were removed (the real count, before delete_run drops the rows they
                # key off).
                removed = store.purge_run_artifacts(rid)
                ok = store.delete_run(rid)
                contained = store.purge_contained_state(rid)
        except store.StoreError as e:
            log.error(Event.STORE_UNUSABLE, detail=str(e))
            return 2
        except OSError as e:
            # An unusable locks/ dir (bad perms, a planted non-directory) reached run_lock as a
            # bare OSError; report it like a StoreError rather than a traceback, exit 2.
            log.error(Event.STORE_UNUSABLE, detail=str(e))
            return 2
        if ok:
            print(f"  gc: evicted {a.run} (run_id {rid}) — "
                  f"{removed} artifact dir(s)")
        else:
            print(f"  gc: no run found for {a.run} (run_id {rid})")
        if contained:
            print(f"  gc: removed the contained-run state for {a.run}")
        return 0

    try:
        r = prune_checkpoints(keep_runs=a.keep_runs,
                              max_age_days=a.max_age_days,
                              dry_run=a.dry_run)
        contained, _ = store.prune_contained_states(a.max_age_days, dry_run=a.dry_run)
    except store.StoreError as e:
        log.error(Event.STORE_UNUSABLE, detail=str(e))
        return 2
    tag = "[dry-run] " if a.dry_run else ""
    if not store.db_location().exists():
        print(f"  gc: no state database at {r['root']}; nothing to do")
    else:
        print(f"  gc: {r['root']}")
    print(f"  {tag}kept {r['kept']} run(s), "
          f"{'would delete' if a.dry_run else 'deleted'} {len(r['deleted'])}")
    for rid in r["deleted"]:
        print(f"    - {rid if store.is_run_id(rid) else repr(rid)}")
    if contained:
        print(f"  {tag}{'would delete' if a.dry_run else 'deleted'} {len(contained)} "
              f"contained-run state dir(s) older than {a.max_age_days} day(s)")
    return 0

def _validate(rest: list[str]) -> int:
    """Run the s11 agentic validation agent (invocable as `validate` or `s11`)."""
    from vvaharness.validation.cli import main as validate_main
    return validate_main(rest)

def _remediate(rest: list[str]) -> int:
    """Drive remediation from a prior scan's findings, using the configured `models.remediate` role."""
    if "--help" in rest or "-h" in rest:
        # Without this, asking for help runs the real remediation engine instead —
        # live model spend and, in the default fix mode, an edit to the target's source.
        print(
            "usage: vvaharness remediate --repo <path> [--config PATH]\n"
            "                            [--mode fix|report-only] [--top N|all|*]\n"
            "                            [-i|--interactive] [--resume] [-v|--verbose]\n"
            "\n"
            "Apply or propose fixes for a prior scan's findings (step 10), reading\n"
            "<repo>/security-scan/ and writing case DTOs to <repo>/security-remediation/.\n"
            "\n"
            "  --repo <path>            target repo whose security-scan/ findings are\n"
            "                           remediated. Required.\n"
            "  --config <file>          config profile path; else ./config.yaml, else the\n"
            "                           packaged default.yaml.\n"
            "  --mode fix|report-only   fix (default) applies minimal diffs; report-only\n"
            "                           proposes fixes only and edits nothing.\n"
            "  --top <N|all|*>          remediate only the N highest-CVSS findings;\n"
            "                           all/* does every finding.\n"
            "  -i, --interactive        pick which findings to remediate from a menu.\n"
            "  --resume                 skip findings already remediated in a prior run.\n"
            "  -v, --verbose            print the prompt + raw LLM response per finding.\n"
        )
        return 0
    from vvaharness import config as config_mod
    from vvaharness.orchestrator import trusted_config
    from vvaharness.remediation_agent import remediate
    repo = _repo_from(rest)
    if not repo:
        console.write("usage: vvaharness remediate --repo <path>")
        return 2
    cfg_path, explicit = _config_path_from_explicit(rest)
    try:
        cfg_path = trusted_config(cfg_path, repo, explicit=explicit)
    except config_mod.ConfigPolicyError as e:
        console.write(f"remediate: {e}")
        return 2
    if not Path(cfg_path).exists():
        console.write(f"remediate: config not found: {cfg_path}")
        return 2
    cfg = _load_and_configure(cfg_path, "remediate")
    if cfg is None:
        return 2
    from vvaharness.orchestrator import store
    try:
        return remediate(repo, rest, cfg)
    except store.StateIntegrityError as e:
        # A value read back from the state DB that this code could not have written (a planted
        # instance id): name the refusal at the CLI boundary and exit non-zero, not a traceback.
        console.write(f"remediate: {e}")
        return 1
    except store.StoreError:
        # A refused/symlinked state dir or an unusable state root: let cli.main surface it as
        # exit 2, like every other structural state-store fault.
        raise
    except Exception as e:  # noqa: BLE001
        # A state path a contained scan can write may simply vanish under us (a path race);
        # report that at the CLI boundary, not as a traceback.
        console.write(f"remediate: {e}")
        return 1

def _ev_replay(rest: list[str]) -> int:
    """Re-check previously exploit-verified findings against a REDEPLOYED target."""
    if "--help" in rest or "-h" in rest:
        # Without this, asking for help sends the stored requests to the target.
        print("usage: vvaharness ev-replay --repo <path> [--config PATH]\n"
              "Re-send the requests exploit verification stored for this repo to the redeployed\n"
              "target (EV_TARGET_URL) and report which findings still reproduce.")
        return 0
    from vvaharness import config as config_mod
    from vvaharness.exploit_verification.replay.run import replay_run
    from vvaharness.orchestrator import trusted_config
    repo = _repo_from(rest)
    if not repo:
        console.write("usage: vvaharness ev-replay --repo <path>")
        return 2
    cfg_path, explicit = _config_path_from_explicit(rest)
    try:
        cfg_path = trusted_config(cfg_path, repo, explicit=explicit)
    except config_mod.ConfigPolicyError as e:
        console.write(f"ev-replay: {e}")
        return 2
    cfg = _load_and_configure(cfg_path, "ev-replay")
    if cfg is None:
        return 2
    from vvaharness.orchestrator import store
    try:
        return replay_run(repo, rest, cfg)
    except store.StateIntegrityError as e:
        # A value read back from the state DB that this code could not have written (a planted
        # instance id): name the refusal at the CLI boundary and exit non-zero, not a traceback.
        console.write(f"ev-replay: {e}")
        return 1
    except store.StoreError:
        # A refused/symlinked state dir or an unusable state root: let cli.main surface it as
        # exit 2, like every other structural state-store fault.
        raise
    except Exception as e:  # noqa: BLE001
        # A state path a contained scan can write may simply vanish under us (a path race);
        # report that at the CLI boundary, not as a traceback.
        console.write(f"ev-replay: {e}")
        return 1
