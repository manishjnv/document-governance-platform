# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Whole-invocation sandbox family: contain `scan`/`remediate`/`validate` in one container.

The family's public surface: import from `vvaharness.backends.sandbox` rather than reaching
into a submodule, so a later reshuffle inside the family cannot break `cli.py`.
"""

from vvaharness.backends.sandbox.capability import assert_supports
from vvaharness.backends.sandbox.entry import (
    CONTAINED_FLAG,
    NO_SANDBOX_FLAG,
    containment_eligible,
    maybe_contain,
    record_provenance,
    strip_contained_flag,
)
from vvaharness.backends.sandbox.entry import (
    strip_flag as strip_sandbox_flag,
)
from vvaharness.backends.sandbox.models import (
    SANDBOXED_COMMANDS,
    Capability,
    CapabilityError,
    Mount,
    SandboxConfig,
    SandboxConfigError,
    SandboxError,
    SandboxLevel,
    SandboxSpec,
    SandboxUnavailableError,
)
from vvaharness.backends.sandbox.protocol import Sandbox
from vvaharness.backends.sandbox.registry import get_sandbox, register_sandbox

__all__ = [
    "CONTAINED_FLAG",
    "NO_SANDBOX_FLAG",
    "SANDBOXED_COMMANDS",
    "Capability",
    "CapabilityError",
    "Mount",
    "Sandbox",
    "SandboxConfig",
    "SandboxConfigError",
    "SandboxError",
    "SandboxLevel",
    "SandboxSpec",
    "SandboxUnavailableError",
    "assert_supports",
    "containment_eligible",
    "get_sandbox",
    "maybe_contain",
    "record_provenance",
    "register_sandbox",
    "strip_contained_flag",
    "strip_sandbox_flag",
]
