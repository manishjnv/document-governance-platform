# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Read `sandbox:` into a typed config, and derive the spec one invocation needs.

The operator states intent -- a backend and a level -- and the harness supplies the rest: it
already knows the target, where state lives, and which paths the invocation named.
"""

from __future__ import annotations

import os
import posixpath
import re
import subprocess
import sys
import unicodedata
from dataclasses import dataclass, replace
from enum import StrEnum
from pathlib import Path, PurePosixPath
from types import MappingProxyType
from typing import TYPE_CHECKING, Final, NamedTuple, TypeVar
from urllib.parse import urlsplit

from vvaharness.backends.sandbox.capability import assert_supports
from vvaharness.backends.sandbox.models import (
    EGRESS_RELAY_PORT,
    EV_CALLBACK_PORT,
    EV_PATH_ENV,
    VERIFYING_COMMANDS,
    EgressGrant,
    EgressMode,
    EnvPolicy,
    Mount,
    SandboxConfig,
    SandboxConfigError,
    SandboxEgress,
    SandboxFs,
    SandboxLevel,
    SandboxNetwork,
    SandboxSpec,
    SandboxUnavailableError,
    host_of,
    is_cleartext,
    is_ev_bridge,
    is_loopback,
    is_mediated,
    is_over_broad,
    level_for,
    loopback_message,
    network_for,
    require_hostname,
    require_mediated_port,
)
from vvaharness.backends.sandbox.registry import get_sandbox
from vvaharness.backends.sandbox.remap import remap_path
from vvaharness.util.git_hardening import GIT_HOST_HARDENING, git_env_without_overrides

if TYPE_CHECKING:
    from collections.abc import Iterator, Mapping, Sequence

    from vvaharness.backends.sandbox.protocol import Sandbox

#: Where the target repo appears inside the container.
REPO_TARGET: Final = Path("/workspace")
#: Checkpoints and the run store must outlive the container or `--resume` stops working.
STATE_TARGET: Final = Path("/vvaharness-state")
#: The target itself: its mount and the `.git` laid over it, the two that may sit anywhere,
#: inside the state directory included (`_mount_conflict`).
_TARGET_MOUNTS: Final = frozenset({REPO_TARGET, REPO_TARGET / ".git"})
#: The container's working directory, deliberately NOT the repo mount: with cwd inside the
#: target, a planted top-level `vvaharness/` or `yaml.py` becomes `sys.path[0]`. Must match the
#: final `WORKDIR` in docker/sandbox/Dockerfile, which is where the harness is installed.
CONTAINER_WORKDIR: Final = Path("/opt/vvaharness")
#: Where EV's host inputs appear in the container: one directory per setting, so two settings
#: naming files with the same basename cannot collide.
EV_INPUTS_TARGET: Final = Path("/vvaharness-ev")
#: Container paths an `inject:` mount is never allowed to land on or above. Its target is
#: DERIVED (from where the contained run resolves the value), so it can point anywhere,
#: including at the image that runs the harness. `/tmp` and `/home` are the backend's tmpfs.
_RESERVED_TARGETS: Final[tuple[Path, ...]] = tuple(
    Path(name)
    for name in (
        "/bin", "/boot", "/dev", "/etc", "/home", "/lib", "/lib64", "/opt", "/proc", "/root",
        "/run", "/sbin", "/srv", "/sys", "/usr", "/var",
        "/tmp",  # noqa: S108 — an in-container path, not a host temp path
    )
)

#: Keys a `sandbox:` block may set. A change that adds a knob adds its name here; anything
#: else is a typo, and is refused as one rather than silently ignored.
SANDBOX_KEYS: Final[frozenset[str]] = frozenset({
    "via", "fs", "egress", "image", "env_allowlist", "timeout_seconds", "docker",
    "egress_grants", "allow_pull", "allow_remote_daemon",
})

class _Provider(NamedTuple):
    """One model provider's default endpoint host, and every setting that names another."""

    #: The `provider_routing.Provider` value a role routed to this provider resolves to.
    name: str
    default: str
    #: The config blocks `provider_routing.credential_env_overrides` reads a `base_url` off.
    routes: tuple[str, ...]
    env: tuple[str, ...]


#: Where the report upload's endpoint is read from, and named when it is refused.
_INGEST_SETTING: Final = "output.ingest_url"

#: The one host the `semgrep` grant opens: where the plugin's registry `rulesets` are fetched
#: from. Its metrics host is never needed, since the plugin always runs with `--metrics=off`.
SEMGREP_REGISTRY_HOST: Final = "semgrep.dev"

#: A provider's default host is allowlisted under mediated egress only when a model role routes
#: to that provider and neither its routes nor its environment name an endpoint: a run that names
#: a gateway, or uses no model of that provider, never calls the default, so allowing it anyway is
#: one more host a hostile target could send data to.
_PROVIDERS: Final[tuple[_Provider, ...]] = (
    _Provider("anthropic", "api.anthropic.com", ("sdk", "cli"),
              ("ANTHROPIC_SDK_BASE_URL", "ANTHROPIC_BASE_URL")),
    _Provider("openai", "api.openai.com", ("openai",), ("OPENAI_BASE_URL",)),
)

#: The `via:` routes whose provider is fixed; `deepagents` resolves per model (`_providers_in_use`).
_VIA_PROVIDER: Final[Mapping[str, str]] = MappingProxyType(
    {"cli": "anthropic", "sdk": "anthropic", "openai": "openai"}
)

#: Axis defaults for a block that names neither: the repo is writable (S10 fix mode needs it)
#: and egress is the Docker default bridge, which is what every level below mediated does today.
DEFAULT_FS: Final = SandboxFs.WORKSPACE_WRITE
DEFAULT_EGRESS: Final = SandboxEgress.OPEN

#: An absent `sandbox:` block: nothing asked for containment, so no other knob matters.
UNCONTAINED: Final = SandboxConfig(
    via="none",
    fs=DEFAULT_FS,
    egress=DEFAULT_EGRESS,
    image="",
    env_allowlist=(),
    timeout_seconds=None,
    backend_options=MappingProxyType({}),
)

_Member = TypeVar("_Member", bound=StrEnum)


@dataclass(frozen=True, slots=True)
class MountRule:
    """How one path-valued CLI flag becomes a mount.

    `mount_parent` mounts the value's containing directory instead of the value itself, for two
    reasons: a file the run *rewrites* gets a new inode, which a single-file bind cannot follow;
    and a profile resolves its own relative overrides against its directory.
    """

    target: Path
    writable: bool
    mount_parent: bool


#: Every path-valued flag `remap.REMAPPED_FLAGS` names, and the mount it earns. `--repo` and the
#: state directory are not here: they are unconditional. The repo's writability follows `fs`;
#: the state mount is always writable.
FLAG_RULES: Final[Mapping[str, MountRule]] = {
    # A profile's relative `policy_file`/`playbook_file` overrides resolve against its own
    # directory (`config._config_dir`), so the directory travels, not just the file.
    "--config": MountRule(Path("/vvaharness-config"), writable=False, mount_parent=True),
    "--step1-config": MountRule(Path("/vvaharness-overlay"), writable=False, mount_parent=True),
    "--workspace": MountRule(Path("/vvaharness-workspace"), writable=True, mount_parent=False),
    "--scan-report": MountRule(Path("/vvaharness-report"), writable=True, mount_parent=True),
    "--semgrep-report": MountRule(Path("/vvaharness-semgrep"), writable=False, mount_parent=True),
}


#: The setting behind each fixed mount target. `EV_INPUTS_TARGET`'s children are derived from
#: the setting name itself, and an `inject:` target is a host path, so neither is listed.
_MOUNT_ORIGINS: Final[Mapping[Path, str]] = {
    REPO_TARGET: "--repo",
    REPO_TARGET / ".git": "--repo",
    STATE_TARGET: "VVAHARNESS_STATE_DIR",
    **{rule.target: flag for flag, rule in FLAG_RULES.items()},
}


def mount_origin(target: Path) -> str:
    """Which setting asked for the mount at *target*, so a refusal can name its own cause.

    The mount list is derived rather than written, so nothing else tells an operator which of
    `--repo`, a path flag, an `EV_*` setting or `inject:` produced a given host directory.
    """
    if target.parent == EV_INPUTS_TARGET:
        return target.name.upper()
    return _MOUNT_ORIGINS.get(target, "an inject: input")


def host_paths_note(mounts: Sequence[Mount], command: str) -> str:
    """Where each container path a contained run printed is on this machine.

    The run reports its own paths -- `/workspace/...`, `/vvaharness-state/...` -- which mean
    nothing here, and a scan's resume hint names them too. A mount inside another one (the
    repo's `.git`) is covered by its parent's line.
    """
    shown = [m for m in mounts if not any(o.target in m.target.parents for o in mounts)]
    width = max((len(str(m.target)) for m in shown), default=0)
    lines = ["  NOTE: sandbox: the paths above are the container's; on this machine they are:"]
    lines += [f"    {str(m.target):<{width}}  {m.source}" for m in shown]
    if command == "scan":
        lines.append("  To resume, re-run the same command here with --resume, not the container's "
                     "resume hint.")
    return "\n".join(lines)


def _raw_block(config: object) -> Mapping[str, object] | None:
    """The raw `sandbox:` mapping off the dynamic `Config` object, or None when absent.

    `Config` is a `__getattr__`-based YAML wrapper with no declared attributes, so this is the
    one place in the family allowed to `getattr` it; everything else takes `SandboxConfig`.

    Raises:
        SandboxConfigError: If `sandbox:` is present but is not a mapping of settings, an empty
            value included: YAML reads a key whose settings are all commented out as null.
    """
    absent = object()
    block = getattr(config, "sandbox", absent)
    if block is absent:
        return None
    if block is None:
        msg = ("sandbox: is present but empty; give it its settings, or delete the whole "
               "block to run uncontained")
        raise SandboxConfigError(msg)
    raw = getattr(block, "_data", block)
    if not isinstance(raw, dict):
        msg = f"sandbox: must be a mapping of settings, got {raw!r}"
        raise SandboxConfigError(msg)
    return raw


def _require_known_keys(raw: Mapping[str, object]) -> None:
    """Refuse a misspelled key rather than defaulting past it.

    Raises:
        SandboxConfigError: If *raw* names anything outside `SANDBOX_KEYS`.
    """
    unknown = sorted(set(raw) - SANDBOX_KEYS)
    if unknown:
        msg = f"unknown sandbox key(s) {unknown}; valid: {sorted(SANDBOX_KEYS)}"
        raise SandboxConfigError(msg)


def _member(key: str, value: object, enum: type[_Member]) -> _Member:
    """One enum-valued knob, refusing an unknown name rather than defaulting past it.

    Raises:
        SandboxConfigError: If *value* is not one of *enum*'s values.
    """
    try:
        return enum(value)
    except ValueError:
        valid = sorted(member.value for member in enum)
        msg = f"unknown sandbox.{key} {value!r}; valid: {valid}"
        raise SandboxConfigError(msg) from None


def _via(raw: Mapping[str, object]) -> str:
    """The backend name, which a present block must state explicitly.

    Raises:
        SandboxConfigError: If `via` is missing, blank, or not a string.
    """
    value = raw.get("via")
    if not isinstance(value, str) or not value.strip():
        msg = (
            f"sandbox.via must name a backend ('docker', or 'none' to opt out), got {value!r}. "
            "Delete the sandbox: block entirely to run uncontained."
        )
        raise SandboxConfigError(msg)
    return value.strip()


def _axes(raw: Mapping[str, object]) -> tuple[SandboxFs, SandboxEgress]:
    """The filesystem and network axes, from `fs` and `egress`.

    Raises:
        SandboxConfigError: If either name is unknown.
    """
    return (
        _member("fs", raw.get("fs", DEFAULT_FS.value), SandboxFs),
        _member("egress", raw.get("egress", DEFAULT_EGRESS.value), SandboxEgress),
    )


def _text(raw: Mapping[str, object], key: str) -> str:
    """One optional string knob, empty when unset and refused when it is not a string.

    Raises:
        SandboxConfigError: If the value is present and not a string.
    """
    value = raw.get(key)
    if value is None:
        return ""
    if not isinstance(value, str):
        msg = f"sandbox.{key} must be a string, got {value!r}"
        raise SandboxConfigError(msg)
    return value


def _str_list(raw: Mapping[str, object], key: str, expected: str) -> tuple[str, ...]:
    """One list-of-strings knob, refusing a bare string and refusing a blank entry.

    A bare string is refused rather than iterated: `env_allowlist: "EV_"` would otherwise
    become the per-character prefix set {'E', 'V', '_'} and carry most of the host env across.
    A blank entry is worse still: `""` is a prefix of every name, so one stray `- ` list item
    would cross the whole host environment.

    Raises:
        SandboxConfigError: If the value is not a list of strings, or any entry is blank.
    """
    value = raw.get(key)
    if value is None:
        return ()
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        msg = f"sandbox.{key} must be a list of {expected}, got {value!r}"
        raise SandboxConfigError(msg)
    if not all(item.strip() for item in value):
        msg = (
            f"sandbox.{key} entries must each name something; a blank entry matches "
            f"everything. Got {value!r}"
        )
        raise SandboxConfigError(msg)
    return tuple(value)


def _env_allowlist(raw: Mapping[str, object]) -> tuple[str, ...]:
    """The extra env-name prefixes, which must be written as a list of non-empty strings."""
    return _str_list(raw, "env_allowlist", "env-name prefixes (e.g. ['EV_'])")


def _grants(raw: Mapping[str, object], egress: SandboxEgress) -> frozenset[EgressGrant]:
    """`sandbox.egress_grants`, which only `scoped` takes and `scoped` cannot do without.

    Raises:
        SandboxConfigError: If a grant is unknown, grants are given under another egress, or a
            scoped egress gives none.
    """
    names = _str_list(raw, "egress_grants", "grant names (e.g. ['ingest'])")
    if names and egress is not SandboxEgress.SCOPED:
        msg = (
            f"sandbox.egress_grants applies to egress: scoped only, but sandbox.egress is "
            f"{egress.value!r}: set sandbox.egress: scoped, or remove sandbox.egress_grants"
        )
        raise SandboxConfigError(msg)
    grants = frozenset(_member("egress_grants", name, EgressGrant) for name in names)
    if egress is SandboxEgress.SCOPED and not grants:
        valid = sorted(grant.value for grant in EgressGrant)
        msg = (
            f"sandbox.egress: scoped needs at least one entry in sandbox.egress_grants "
            f"(valid: {valid}); with none it reaches the model endpoints alone, which is "
            f"sandbox.egress: mediated"
        )
        raise SandboxConfigError(msg)
    return grants


def _ingest_url(config: object) -> str:
    """`output.ingest_url` as resolved, empty when unset."""
    url = getattr(getattr(config, "output", None), "ingest_url", None)
    return str(url).strip() if url else ""


def _semgrep_entry(config: object) -> object | None:
    """The profile's `sdk.plugins` entry for the Semgrep plugin (`sdk.loading` reads it so)."""
    entries = getattr(getattr(config, "sdk", None), "plugins", None) or ()
    if not isinstance(entries, (list, tuple)):
        return None
    for entry in entries:
        name = entry.get("name") if isinstance(entry, dict) else getattr(entry, "name", None)
        if name == "semgrep":
            return entry
    return None


def _semgrep_plugin(config: object) -> bool:
    """Whether the profile's `sdk.plugins` names the Semgrep plugin."""
    return _semgrep_entry(config) is not None


def _semgrep_values(config: object, key: str) -> tuple[str, ...]:
    """The Semgrep plugin entry's *key* list (`rulesets`/`configs`) as written, blanks dropped.

    Tolerant like `_inject_paths`: a malformed list is the plugin's to refuse when it loads.
    """
    entry = _semgrep_entry(config)
    raw = entry.get(key) if isinstance(entry, dict) else getattr(entry, key, None)
    if not isinstance(raw, (list, tuple)):
        return ()
    return tuple(value.strip() for value in raw if isinstance(value, str) and value.strip())


def _endpoint_host(endpoint: str, origin: str) -> tuple[str, bool]:
    """The host a mediated run reaches *endpoint* by, and whether it is cleartext.

    Checked at LOAD time: the allowlist is derived by host, so an endpoint on a port the
    sidecar's ACL does not admit would be allowlisted and then refused as a CONNECT with nothing
    naming the port. A loopback endpoint is refused first, since no port fixes it. The charset
    gate runs here too so the refusal names *origin*, the setting the operator wrote.

    Raises:
        SandboxConfigError: If the endpoint is loopback, its port is unreachable, or its host
            is not a hostname.
    """
    host = host_of(endpoint) or ""
    if is_loopback(host):
        raise SandboxConfigError(loopback_message(origin, endpoint))
    # Before the port: an unbracketed IPv6 literal would otherwise read as a malformed port.
    require_hostname(host, origin, endpoint=True)
    require_mediated_port(endpoint, origin)
    return host, is_cleartext(endpoint)


def _route_host(config: object, block: str, *, mediated: bool) -> tuple[str, bool] | None:
    """The host this route's `base_url` names, and whether it is cleartext; refused if unreachable.

    Checked only under mediation (`_endpoint_host`).

    Raises:
        SandboxConfigError: If the endpoint is loopback, its port is unreachable, or its host
            is not a hostname.
    """
    url = getattr(getattr(config, block, None), "base_url", None)
    endpoint = str(url) if url else ""
    host = host_of(endpoint) if endpoint else None
    if host is None or not mediated:
        return None if host is None else (host, False)
    return _endpoint_host(endpoint, f"{block}.base_url")


def _model_nodes(tree: object) -> Iterator[Mapping[str, object]]:
    """Every model node (a mapping with an `id`) under the profile's raw `models:` tree."""
    if not isinstance(tree, dict):
        return
    if "id" in tree:
        yield tree
        return
    for value in tree.values():
        yield from _model_nodes(value)


def _node_providers(node: Mapping[str, object]) -> set[str]:
    """The providers one model node may call, resolved as the router does.

    `deepagents` resolves per model (`provider_routing.routes_to_anthropic`). A node naming no
    `via:` is read both ways -- `cli`, the default, or the route of the role it sits under -- and
    a route this does not know counts as every provider, so no role is left without its endpoint.
    """
    from vvaharness.backends.harness.provider_routing import (  # noqa: PLC0415 — lazy: see `_within`
        routes_to_anthropic,
    )

    via = node.get("via")
    by_model = ("anthropic" if routes_to_anthropic(str(node.get("id") or ""), node.get("provider"))
                else "openai")
    if via is None:
        return {"anthropic", by_model}
    if via == "deepagents":
        return {by_model}
    return {_VIA_PROVIDER[via]} if via in _VIA_PROVIDER else {p.name for p in _PROVIDERS}


def _providers_in_use(config: object) -> frozenset[str] | None:
    """The providers the profile's model roles may call; None if it names no model at all."""
    models = getattr(getattr(config, "models", None), "_data", None)
    used = {name for node in _model_nodes(models) for name in _node_providers(node)}
    return frozenset(used) or None


def _provider_routes(
    config: object, provider: _Provider, env: Mapping[str, str], *, mediated: bool,
    in_use: frozenset[str] | None,
) -> list[tuple[str, bool]]:
    """*provider*'s route hosts with their cleartext flag, else its default host.

    The default stands only when a role uses that provider (*in_use*, None when unknown) and
    nothing -- no route, no environment variable -- names that provider's endpoint.
    """
    routes = [_route_host(config, block, mediated=mediated) for block in provider.routes]
    named = [route for route in routes if route]
    if named or any((env.get(name) or "").strip() for name in provider.env):
        return named
    if in_use is not None and provider.name not in in_use:
        return []
    return [(provider.default, False)]


def _egress_allowlist(
    config: object,
    egress: SandboxEgress,
    grants: frozenset[EgressGrant],
    env: Mapping[str, str] | None = None,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Every host a mediated run may CONNECT to, and the subset an `http://` endpoint names.

    Derived from the same `base_url` fields `provider_routing.credential_env_overrides` reads,
    so a gateway-routed profile keeps working through the sidecar. A provider's default host
    joins only when a role uses that provider and nothing names its endpoint (`_PROVIDERS`);
    the environment's endpoints themselves are added at run time, by
    `docker.egress.with_env_hosts`. Under
    `scoped`, each grant adds the one destination it names, and nothing else can add a host.

    Raises:
        SandboxConfigError: If -- under mediated or scoped egress -- a route or a granted
            destination names an endpoint the sidecar could not reach.
    """
    env = os.environ if env is None else env
    mediated = is_mediated(egress)
    named: list[tuple[str, bool]] = []
    in_use = _providers_in_use(config)
    for provider in _PROVIDERS:
        named += _provider_routes(config, provider, env, mediated=mediated, in_use=in_use)
    ingest = _ingest_url(config)
    if EgressGrant.INGEST in grants and ingest:
        named.append(_endpoint_host(ingest, _INGEST_SETTING))
    if EgressGrant.SEMGREP in grants and _semgrep_values(config, "rulesets"):
        named.append((SEMGREP_REGISTRY_HOST, False))
    hosts = {host for host, _ in named}
    cleartext = {host for host, plain in named if plain}
    return tuple(sorted(hosts)), tuple(sorted(cleartext))


def _warn_ungranted_ingest(cfg: SandboxConfig) -> None:
    """Say up front that the report upload has no route, rather than leave it to fail at S9.

    A warning, not a refusal: the upload is optional and already non-fatal. Its token does not
    cross without a route (`models.CONTAINER_ENV`), so the contained run skips it cleanly.
    """
    routed = cfg.egress is SandboxEgress.OPEN or EgressGrant.INGEST in cfg.egress_grants
    if not cfg.ingest_url or routed:
        return
    _warn(
        f"{_INGEST_SETTING} is set, but sandbox.egress: {cfg.egress.value} gives the report "
        f"upload no route, so it is skipped. Set sandbox.egress: scoped with egress_grants: "
        f"[ingest] to upload from a contained run."
    )


def _warn_semgrep_unrouted(cfg: SandboxConfig) -> None:
    """Say up front when the Semgrep plugin's registry rulesets have no route, or a grant no use.

    A warning, not a refusal: a scan already continues without Semgrep evidence when its rules
    cannot be fetched. Whether the image carries `semgrep` at all is the backend's to say, since
    only it reads the image (`docker.backend`).
    """
    granted = EgressGrant.SEMGREP in cfg.egress_grants
    if granted and not (cfg.semgrep_plugin and cfg.semgrep_rulesets):
        _warn(
            "sandbox.egress_grants names semgrep, but the profile loads no Semgrep plugin with "
            "registry rulesets, so the grant opens nothing; remove it."
        )
    if not cfg.semgrep_rulesets or cfg.egress is SandboxEgress.OPEN or granted:
        return
    # `scoped` CAN reach the registry, with the grant: name what is missing, not the egress.
    scoped = cfg.egress is SandboxEgress.SCOPED
    stated = "scoped without the semgrep grant" if scoped else cfg.egress.value
    remedy = ("Add semgrep to sandbox.egress_grants" if scoped
              else "Set sandbox.egress: scoped with egress_grants: [semgrep]")
    _warn(
        f"the Semgrep plugin's registry rulesets ({', '.join(cfg.semgrep_rulesets)}) are "
        f"fetched from {SEMGREP_REGISTRY_HOST}, which sandbox.egress: {stated} cannot reach, "
        f"so this run has no evidence from them. {remedy}, or list local rule files in the "
        f"plugin's configs."
    )


def _warn_loopback_endpoints(cfg: SandboxConfig, env: Mapping[str, str] | None = None) -> None:
    """Say which provider endpoint variables name this machine's loopback under mediation.

    A warning where a route is a refusal: `ANTHROPIC_BASE_URL` goes unused whenever
    `sdk.base_url` names a gateway, so a variable nothing reads must not refuse a run that works.
    """
    if not is_mediated(cfg.egress):
        return
    env = os.environ if env is None else env
    for name in (name for provider in _PROVIDERS for name in provider.env):
        value = (env.get(name) or "").strip()
        host = host_of(value) if value else None
        if host and is_loopback(host):
            _warn(f"{loopback_message(name, value)} A model call that uses it will fail.")


def _flag(raw: Mapping[str, object], key: str) -> bool:
    """One boolean escape hatch, which must be written as a YAML boolean.

    Refusing `"false"` is deliberate: a string is truthy, so coercing it would turn a typo
    into the permissive answer on exactly the knobs that exist to withhold permission.

    Raises:
        SandboxConfigError: If the value is present and not a boolean.
    """
    value = raw.get(key)
    if value is None:
        return False
    if not isinstance(value, bool):
        msg = f"sandbox.{key} must be true or false, got {value!r}"
        raise SandboxConfigError(msg)
    return value


def _timeout(raw: Mapping[str, object]) -> float | None:
    """The `timeout_seconds` knob as a float, or None when unset.

    Raises:
        SandboxConfigError: If the value is present but not a number of seconds.
    """
    value = raw.get("timeout_seconds")
    if value is None:
        return None
    try:
        return float(str(value).strip())
    except ValueError as exc:
        msg = f"sandbox.timeout_seconds must be a number of seconds, got {value!r}"
        raise SandboxConfigError(msg) from exc


def _backend_options(raw: Mapping[str, object]) -> Mapping[str, object]:
    """The `sandbox.docker:` sub-block as a raw mapping; the knob NAMES are preflight's to check.

    `docker/preflight.OPTION_NAMES` is the single source for which knobs exist, and
    `limits_from` already refuses an unknown one before any container is created, so this
    validates the sub-block's shape only.

    Raises:
        SandboxConfigError: If the sub-block is present but is not a mapping.
    """
    block = raw.get("docker")
    if block is None:
        return MappingProxyType({})
    if not isinstance(block, dict):
        msg = f"sandbox.docker must be a mapping of knobs, got {block!r}"
        raise SandboxConfigError(msg)
    return dict(block)


def _inject_paths(config: object) -> Mapping[str, str]:
    """The `inject:` block's path values as written, for the mounts that make them travel.

    Read off the dynamic `Config` here (like `_egress_allowlist`) because `spec_from` only ever
    sees `SandboxConfig`. Deliberately tolerant: a malformed `inject:` block is the injectors'
    to complain about, and refusing it here would fail every sandboxed command over a block
    containment does not depend on.
    """
    block = getattr(config, "inject", None)
    if block is None:
        return MappingProxyType({})
    raw = getattr(block, "_data", block)
    if not isinstance(raw, dict):
        return MappingProxyType({})
    return MappingProxyType({
        key: value.strip()
        for key, value in raw.items()
        if isinstance(value, str) and value.strip()
    })


def _ev_may_run(config: object, env: Mapping[str, str] | None = None) -> bool:
    """Whether exploit verification will run, by EV's own predicate -- the profile switch first.

    Imported lazily: `cli.py` reaches this module on every invocation, and exploit
    verification's package is not on the path of a run that never verifies.
    """
    from vvaharness.exploit_verification.options import (  # noqa: PLC0415 — lazy: keeps EV's package off every invocation's import path
        may_run,
    )

    return may_run(config, dict(env if env is not None else os.environ))


def load_sandbox_config(config: object) -> SandboxConfig:
    """Read the `sandbox:` block into a typed value, once, refusing a malformed one.

    An absent block means no containment. A block that is present but unreadable as written is
    a refusal, never a silent fall back to an uncontained run.

    Raises:
        SandboxConfigError: If the block is present and any key is unknown or ill-typed.
    """
    raw = _raw_block(config)
    if raw is None:
        return UNCONTAINED
    _require_known_keys(raw)
    fs, egress = _axes(raw)
    grants = _grants(raw, egress)
    allowlist, cleartext = _egress_allowlist(config, egress, grants)
    return SandboxConfig(
        via=_via(raw),
        fs=fs,
        egress=egress,
        image=_text(raw, "image"),
        env_allowlist=_env_allowlist(raw),
        timeout_seconds=_timeout(raw),
        backend_options=_backend_options(raw),
        egress_allowlist=allowlist,
        egress_cleartext=cleartext,
        egress_grants=grants,
        ingest_url=_ingest_url(config),
        semgrep_plugin=_semgrep_plugin(config),
        semgrep_rulesets=_semgrep_values(config, "rulesets"),
        semgrep_configs=_semgrep_values(config, "configs"),
        allow_pull=_flag(raw, "allow_pull"),
        allow_remote_daemon=_flag(raw, "allow_remote_daemon"),
        inject=_inject_paths(config),
        ev_armed=_ev_may_run(config),
    )


def requested(cfg: SandboxConfig) -> bool:
    """Whether *cfg* opts into containment at all."""
    return cfg.via != "none"


def env_policy(cfg: SandboxConfig) -> EnvPolicy:
    """Which host variables a run under *cfg* receives (`models.CONTAINER_ENV`)."""
    return EnvPolicy(egress=cfg.egress, allowlist=frozenset(cfg.env_allowlist),
                     grants=cfg.egress_grants)


def level_of(cfg: SandboxConfig) -> SandboxLevel:
    """The single level name *cfg*'s axes mean, for the level-keyed surfaces."""
    return level_for(cfg.fs, cfg.egress)


def _covered(source: Path, needs_write: bool, mounts: list[Mount]) -> bool:
    """Whether *source* already sits inside a mount that grants the access it needs.

    Writability is part of coverage: a read-only mount over a path the run must write is not
    coverage, it is a `Read-only file system` failure later, inside the container.
    """
    return any(
        (source == m.source or m.source in source.parents) and (m.writable or not needs_write)
        for m in mounts
    )


def _as_written(path: Path) -> Path:
    """*path* made absolute with `..` collapsed, but NO symlink resolved."""
    return Path(os.path.abspath(path))  # noqa: PTH100 — Path.resolve() would follow symlinks


def _within(candidate: Path, root: Path) -> bool:
    """`config_paths._path_within`: whether *candidate* resolves at or under *root*.

    Imported lazily: `config_paths` executes the orchestrator package, which pulls the pipeline
    and the LLM backends, and the containment gate reaches this module for every command.
    """
    from vvaharness.orchestrator.config_paths import (  # noqa: PLC0415 — lazy: see docstring
        _path_within,
    )

    return _path_within(candidate, root)


def _reaches_repo(given: Path, repo: Path) -> bool:
    """Whether *given*'s own path passes through *repo*, in whatever spelling each was written.

    Every ancestor is resolved rather than string-matched: a lexical prefix test misses the
    ordinary macOS case, where `/tmp`, `/var` and `$TMPDIR` are symlinks, so `--repo /tmp/clone`
    and a value relative to cwd share no prefix at all.
    """
    written = _as_written(given)
    return any(_within(step, repo) for step in (written, *written.parents))


def _refuse_mount_escape(flag: str, given: Path, source: Path, repo: Path) -> None:
    """Refuse a flag value that goes through the repo but mounts a directory outside it.

    The attacker authors the checkout, and the documented `--scan-report`/`--workspace` defaults
    live inside it, so a planted symlink there turns a normal-looking value into a bind of any
    host directory -- read-WRITE for those two flags. Judged on the mount SOURCE, which is the
    value's parent for the `mount_parent` flags: naming the repo root itself would otherwise
    bind the repo's parent. An operator path that never touches the target keeps working.

    Raises:
        SandboxUnavailableError: If the value reaches *repo* but *source* lands outside it.
    """
    if not _reaches_repo(given, repo) or _within(source, repo):
        return
    msg = (
        f"{flag} names {given}, which goes through the target repo, but the directory that "
        f"would be mounted is {source}, outside it -- nothing in the scanned repo may choose "
        f"which host directory is bound. Point {flag} at a path outside the target, or remove "
        f"the symlink it goes through."
    )
    raise SandboxUnavailableError(msg)


def _overlay_of(inner: Mount, outer: Mount) -> bool:
    """Whether *inner* is bound exactly where *outer* would show it, so it hides that view.

    The read-only `.git` over a writable repo: the files have one container path, not two.
    """
    try:
        return inner.target == outer.target / inner.source.relative_to(outer.source)
    except ValueError:
        return False


def _mount_conflict(
    candidate: Mount, mounts: Sequence[Mount], *, repo: Path, state_root: Path
) -> str | None:
    """Why *candidate* cannot join *mounts*, or None when it can. The one overlap rule.

    Every leg asks it -- repo, path flags, `inject:`, EV inputs -- and keeps its own policy for
    a refusal. Directories are compared by identity (`_within`), never by spelling: on a
    case-insensitive or normalising filesystem `Repo` and `REPO` are one directory, which a
    string comparison would let a second spelling bind again in another mode.

    - Nothing but the state mount may hold the state root: it carries every target's findings
      and the database host commands trust. Only the target may sit inside it.
    - Nothing but the target may contain the target: the mount would show every checkout and
      file beside it.
    - A writable and a read-only mount may not overlap, in either direction, except a read-only
      overlay at the matching container path (`.git`): otherwise the read-only files are
      writable through a second path.
    """
    return (_placement_conflict(candidate, repo=repo, state_root=state_root)
            or _mode_conflict(candidate, mounts))


def _placement_conflict(candidate: Mount, *, repo: Path, state_root: Path) -> str | None:
    """`_mount_conflict`'s target and state-root rules, which need no other mount."""
    source = candidate.source
    is_state = candidate.target == STATE_TARGET
    other = candidate.target not in _TARGET_MOUNTS and not is_state
    reason = None
    if other and _within(repo, source):
        reason = (f"{source} contains the target; mounting it would show the container every "
                  f"other checkout and file beside the target, their .env files included. "
                  f"Move it to a directory that does not contain the target.")
    elif not is_state and _within(state_root, source):
        reason = (f"{source} contains the state directory {state_root}; mounting it would show "
                  f"the container every target's findings and the database host commands "
                  f"trust.")
    elif other and _within(source, state_root):
        reason = (f"{source} is inside the state directory {state_root}, whose contents host "
                  f"commands trust. Keep it outside the state directory.")
    return reason


def _require_no_conflict(
    origin: str, candidate: Mount, mounts: Sequence[Mount], *, repo: Path, state_root: Path
) -> None:
    """Refuse *candidate*, led by *origin* (the setting and its value), on a `_mount_conflict`.

    Raises:
        SandboxUnavailableError: If *candidate* cannot join *mounts*.
    """
    conflict = _mount_conflict(candidate, mounts, repo=repo, state_root=state_root)
    if conflict is not None:
        msg = f"{origin}: {conflict}"
        raise SandboxUnavailableError(msg)


def _mode_conflict(candidate: Mount, mounts: Sequence[Mount]) -> str | None:
    """`_mount_conflict`'s rule that a writable and a read-only mount never overlap."""
    for mount in mounts:
        if mount.writable == candidate.writable:
            continue
        rw, ro = (candidate, mount) if candidate.writable else (mount, candidate)
        if _within(rw.source, ro.source):
            return (f"{rw.source}, writable at {rw.target}, is inside {ro.source}, which this "
                    f"run mounts read-only at {ro.target}; a writable bind there would hand back "
                    f"exactly the access that mount withholds.")
        if _within(ro.source, rw.source) and not _overlay_of(ro, rw):
            return (f"{rw.source}, writable at {rw.target}, contains {ro.source}, which this "
                    f"run mounts read-only at {ro.target}; a writable bind of it would make "
                    f"those files writable through a second path.")
    return None


def _flag_mounts(
    flag_paths: Mapping[str, Path], repo: Path, mounts: list[Mount], state_root: Path
) -> list[Mount]:
    """One mount per path-valued flag present, skipping anything already mounted.

    A report written under a writable repo is the common case, and it needs no second mount:
    `remap` resolves it through the repo's own mount. The value is fully resolved because that
    is the path the daemon will bind -- so preflight's breadth rule judges the real directory.
    Values arrive AS THE OPERATOR WROTE THEM for every flag but `--config`, which `entry._contain`
    hands over already resolved: `_refuse_mount_escape` cannot tell a pre-resolved value from one
    that never went near the repo, so that leg is instead gated upstream by
    `config_paths.trusted_config_path`, which anchors on every UNFOLLOWED directory the path is
    written through. Each mount is then held to `_mount_conflict` against every mount before it,
    the flags' own included.

    Raises:
        SandboxUnavailableError: If a value escapes the repo through it, or its mount conflicts.
    """
    extra: list[Mount] = []
    for flag, rule in FLAG_RULES.items():
        given = flag_paths.get(flag)
        if given is None:
            continue
        resolved = given.resolve()
        source = resolved.parent if rule.mount_parent else resolved
        _refuse_mount_escape(flag, given, source, repo)
        if _covered(source, rule.writable, [*mounts, *extra]):
            continue
        mount = Mount(source=source, target=rule.target, writable=rule.writable)
        _require_no_conflict(f"{flag} names {given}", mount, [*mounts, *extra],
                             repo=repo, state_root=state_root)
        extra.append(mount)
    return extra


def ev_requested(cfg: SandboxConfig, env: Mapping[str, str] | None = None) -> bool:
    """Whether exploit verification will run this invocation -- the ONE armed predicate.

    `cfg.ev_armed` is `options.may_run`'s answer, which doctor's readiness checks ask too, so
    the gate cannot refuse a run for a stage `step6_exploit_verification.enabled: false` had
    already switched off. None means no profile was consulted (a hand-built config), and then
    the environment alone decides, as it did before the switch was read here.
    """
    if cfg.ev_armed is not None:
        return cfg.ev_armed
    return _ev_may_run(None, env)


def _ev_mounts(mounts: list[Mount], repo: Path, state_root: Path) -> list[Mount]:
    """One read-only mount per EV host input the environment names, skipping what is covered.

    The value's PARENT is mounted, not the file: EV reads sibling files for a client
    cert/key pair, and a single-file bind cannot follow a rewritten inode. A collection the
    target ships is a normal input, so a value inside *repo* is allowed -- but not one that
    goes through it and resolves elsewhere: a symlink planted there would choose the mount.

    Raises:
        SandboxUnavailableError: If a named EV input does not exist on this host -- a
            requested input that cannot travel must fail loudly, not vanish in the container
            -- reaches *repo* but resolves outside it, or its directory conflicts with
            another mount (`_mount_conflict`), such as one that contains the target.
    """
    extra: list[Mount] = []
    for name in EV_PATH_ENV:
        value = (os.environ.get(name) or "").strip()
        if not value:
            continue
        given = Path(value).expanduser()  # `~` and a relative path mean what host EV reads
        source = given.resolve()
        if not source.exists():
            msg = (
                f"{name} names {value!r}, which does not exist on this host, so a contained "
                f"run cannot mount it. Correct the path, or unset it."
            )
            raise SandboxUnavailableError(msg)
        parent = source.parent
        _refuse_mount_escape(name, given, parent, repo)
        if _covered(parent, False, [*mounts, *extra]):
            continue
        mount = Mount(source=parent, target=EV_INPUTS_TARGET / name.lower(), writable=False)
        _require_no_conflict(f"{name} names {value!r}", mount, [*mounts, *extra],
                             repo=repo, state_root=state_root)
        extra.append(mount)
    return extra


@dataclass(frozen=True, slots=True)
class _InjectInput:
    """One `inject:` value: the host file it names, and where the contained run will look."""

    key: str
    source: Path
    expected: Path
    #: The value as written, made absolute: what `_reaches_repo` judges, before any link.
    given: Path


def _warn(message: str) -> None:
    """Say on stderr that this contained run carries less than the same host run would."""
    print(f"  WARN: sandbox: {message}", file=sys.stderr)


def _note_no_egress(cfg: SandboxConfig) -> None:
    """Say up front what `egress: none` leaves a run able to do, before a stage fails on it."""
    read_only = (", and the repository is mounted read-only although sandbox.fs is "
                 "workspace-write, since nothing that writes it can run"
                 if cfg.fs is SandboxFs.WORKSPACE_WRITE else "")
    print(f"  NOTE: sandbox: egress: none reaches no model, so only stages that need none can "
          f"complete (S0, and S1 without its auto-exclude survey; a scan needs --skip-preflight "
          f"to reach them). No credential that needs a network is passed in{read_only}.",
          file=sys.stderr)


def _warn_open_egress(cfg: SandboxConfig) -> None:
    """Say up front what `egress: open` lets a hostile target reach, since nothing else does.

    A warning on every such run, because `open` is now an explicit choice: the shipped profile
    uses `mediated`, which reaches the model endpoints alone.
    """
    if cfg.egress is not SandboxEgress.OPEN:
        return
    _warn(
        "egress: open gives this run unrestricted network access: the internet, services on "
        "this machine (host.docker.internal), other containers on Docker's default bridge "
        "and, on a cloud VM, the instance metadata service. Use sandbox.egress: mediated, or "
        "scoped with the grants the run needs, unless the egress sidecar cannot reach your "
        "model endpoint."
    )


def _inject_source(base: Path, value: str) -> Path:
    """*value* as an absolute host path without `..`, keeping the name as written.

    Only the parent chain is symlink-resolved: resolving the last component would mount a
    symlink's real directory, under which the name the container opens does not exist.
    """
    given = Path(value)
    candidate = given if given.is_absolute() else base / given
    return candidate.parent.resolve() / candidate.name


def _inject_expected(container_dir: str, value: str) -> Path:
    """Where the contained run resolves *value*: against the config dir it was given.

    `orchestrator._resolve_against` joins without normalizing, so the `..` segments a packaged
    profile uses are collapsed by the kernel at open() time -- clamped at the root, which is
    exactly what `normpath` computes here.
    """
    given = Path(value)
    joined = given if given.is_absolute() else Path(container_dir) / given
    return Path(os.path.normpath(joined))


def _lands(item: _InjectInput, mounts: list[Mount]) -> bool:
    """Whether *mounts* already put this input's host file exactly where the run will look.

    Coverage is checked first because `remap_path` returns an unmounted path unchanged, which
    an absolute inject value would otherwise read as "already there".
    """
    return (
        _covered(item.source, False, mounts)
        and remap_path(str(item.source), tuple(mounts)) == str(item.expected)
    )


def _shadows(target: Path, other: Path) -> bool:
    """Whether a bind at *target* would swallow *other*: the same path, or a directory above it.

    One-directional on purpose. A target BELOW a reserved path (`/home/you/feeds`, which is
    where an absolute inject value on Linux usually lives) shadows nothing the image needs;
    a target at or above one replaces the container's own directory.
    """
    return target == other or target in other.parents


def _inject_refusal(
    item: _InjectInput, mounts: list[Mount], *, repo: Path, state_root: Path
) -> str | None:
    """Why mounting *item*'s directory where the run will look is not allowed, or None.

    Breadth is preflight's rule (`is_over_broad`), reused rather than restated so the gate never
    offers a mount preflight would reject. The target rule is the mirror image: the image's own
    filesystem is what runs the harness, so a bind that lands on (or above) any of it, or on a
    path another mount owns, breaks the run instead of enriching it. A value that goes through
    the target but resolves outside it is refused as a path flag's is (`_refuse_mount_escape`):
    a symlink planted in the target would choose the host directory bound. The rest is
    `_mount_conflict`.
    """
    source, target = item.source.parent, item.expected.parent
    owners = (*_RESERVED_TARGETS, CONTAINER_WORKDIR, *(m.target for m in mounts))
    if is_over_broad(source):
        reason = (f"{source} is too broad to bind: the filesystem root, a shared system or "
                  f"temporary directory, or the invoking user's home directory or one above it")
    elif any(_shadows(target, owner) for owner in owners):
        reason = f"{target} is, or is above, a path the container itself owns"
    elif _reaches_repo(item.given, repo) and not _within(source, repo):
        reason = (f"it goes through the target but resolves outside it, to {source}, and "
                  f"nothing in the scanned repo may choose which host directory is bound")
    else:
        conflict = _mount_conflict(Mount(source=source, target=target, writable=False), mounts,
                                   repo=repo, state_root=state_root)
        reason = conflict.rstrip(".") if conflict else None
    return reason


def _inject_travel_mounts(
    inputs: list[_InjectInput], mounts: list[Mount], *, repo: Path, state_root: Path
) -> list[Mount]:
    """One read-only mount per input, skipping any an earlier mount already lands.

    Per-input only: a two-sided common ancestor would save a mount now and then, at the price of
    deriving a broader host mount than any single input needs.
    """
    extra: list[Mount] = []
    for item in inputs:
        if _lands(item, [*mounts, *extra]):
            continue
        refusal = _inject_refusal(item, [*mounts, *extra], repo=repo, state_root=state_root)
        if refusal is not None:
            _warn(
                f"inject.{item.key} names {item.source}, which cannot be mounted "
                f"({refusal}); this run has no {item.key} context. Move the file under a "
                f"narrower directory, or set sandbox.via: none."
            )
            continue
        extra.append(
            Mount(source=item.source.parent, target=item.expected.parent, writable=False)
        )
    return extra


def _inject_inputs(
    cfg: SandboxConfig, base: Path, container_dir: str, mounts: list[Mount]
) -> list[_InjectInput]:
    """The inject inputs still needing a mount, having named any the host does not have."""
    inputs: list[_InjectInput] = []
    missing: list[str] = []
    for key, value in cfg.inject.items():
        source = _inject_source(base, value)
        if not source.exists():
            missing.append(f"inject.{key}={value}")
            continue
        given = Path(value)
        item = _InjectInput(
            key=key, source=source, expected=_inject_expected(container_dir, value),
            given=given if given.is_absolute() else base / given,
        )
        if not _lands(item, mounts):
            inputs.append(item)
    if missing:
        # A NOTE, not `_warn`: the contained run carries no less than a host run would here, and
        # the shipped profiles name optional inputs most machines do not have
        print("  NOTE: sandbox: inject input(s) absent on this host, so nothing is injected for "
              f"them, as on a host run: {', '.join(missing)}", file=sys.stderr)
    return inputs


def _inject_mounts(
    cfg: SandboxConfig, flag_paths: Mapping[str, Path], mounts: list[Mount], *,
    repo: Path, state_root: Path,
) -> list[Mount]:
    """Read-only mounts so the profile's `inject:` inputs reach the container.

    The inputs are optional enrichment, so one that cannot travel degrades the run instead of
    failing it -- but never silently: a contained run that injects less CVE/controls/CMDB
    context than the same host run would says so on stderr.
    """
    config = flag_paths.get("--config")
    if not cfg.inject or config is None:
        return []
    base = config.resolve().parent
    # The container's config dir, through the mount `--config` already earned: relative inject
    # values resolve against it there, exactly as they resolve against `base` here.
    container_dir = remap_path(str(base), tuple(mounts))
    return _inject_travel_mounts(_inject_inputs(cfg, base, container_dir, mounts), mounts,
                                 repo=repo, state_root=state_root)


def _semgrep_config_mounts(
    cfg: SandboxConfig, mounts: list[Mount], *, repo: Path, state_root: Path
) -> list[Mount]:
    """Read-only mounts so the Semgrep plugin's local rule files reach the container.

    The plugin reads each `configs` value as a path in the container and fails the scan on one
    it cannot open, so each value is mounted at the path as written. Unlike an `inject:` input,
    a rule file that cannot travel refuses the run: it would fail the scan once it was paid for.
    A relative or `~` value names a different file in the container, so it is refused too.

    Raises:
        SandboxUnavailableError: If a value is not absolute, is not a file on this host, or its
            directory cannot be mounted where the run reads it (`_inject_refusal`).
    """
    extra: list[Mount] = []
    for value in cfg.semgrep_configs:
        given = Path(value)
        reason = None
        if not given.is_absolute():
            reason = "it is not an absolute path, which is the only kind the container resolves"
        elif not given.is_file():
            reason = "it is not a file on this host"
        if reason is None:
            item = _InjectInput(key="semgrep configs", source=given.resolve(), expected=given,
                                given=given)
            if _lands(item, [*mounts, *extra]):
                continue
            reason = _inject_refusal(item, [*mounts, *extra], repo=repo, state_root=state_root)
            if reason is None:
                extra.append(Mount(source=item.source.parent, target=given.parent,
                                   writable=False))
                continue
        msg = (f"the Semgrep plugin's configs names {value}, which cannot reach the contained "
               f"run ({reason}). Give each rule file as an absolute path in a directory of its "
               f"own, or set sandbox.via: none.")
        raise SandboxUnavailableError(msg)
    return extra


def _ev_disarm_hint(env: Mapping[str, str] | None = None) -> str:
    """How to disarm verification on THIS run, since either the switch or the collection arms it.

    Telling an operator to unset `EV_API_COLLECTION` when nothing exported it sends them looking
    for a variable that is not there.
    """
    from vvaharness.exploit_verification.options import (  # noqa: PLC0415 — lazy: see `_ev_may_run`
        collection_path,
    )

    if collection_path(dict(env if env is not None else os.environ)) is None:
        return (
            "set step6_exploit_verification.enabled to auto or false (no collection is "
            "exported, so enabled: true is what arms verification here)"
        )
    return "unset EV_API_COLLECTION"


def _ev_network(
    network: SandboxNetwork, cfg: SandboxConfig, *, replay: bool = False
) -> SandboxNetwork:
    """The EV network, or a refusal when the egress axis contradicts a verifying run.

    S6 runs inline in the same container as S0-S11, so one container cannot be both mediated
    and on the host bridge: `open` becomes the EV bridge, and `scoped` with the `ev` grant stays
    mediated, forwards the target's ports and takes its callback instead. The refusal names the
    operator's egress value, since `scoped` and `mediated` share one network mode. *replay*
    marks `ev-replay`, which nothing disarms, so its refusal offers no disarm hint.

    Raises:
        SandboxConfigError: If egress is `none`, `mediated` or `scoped` without the `ev` grant
            -- none of them reaches a target on the host -- or a forward is refused.
    """
    if is_ev_bridge(network):
        return network
    if cfg.egress is SandboxEgress.SCOPED and EgressGrant.EV in cfg.egress_grants:
        return replace(network, forwards=_ev_forwards(os.environ), callback=True)
    if network.mode != EgressMode.OPEN:
        stated = cfg.egress.value
        remedy = "sandbox.egress: open, or scoped with egress_grants: [ev],"
        if replay:
            msg = (
                f"ev-replay sends exploit traffic to the target, so it needs a route to it, but "
                f"sandbox.egress is {stated!r}: run it with a profile whose {remedy} gives one."
            )
        else:
            msg = (
                f"exploit verification needs a route to its target, but sandbox.egress is "
                f"{stated!r}: set {remedy} for EV runs, or {_ev_disarm_hint()} to keep this "
                f"profile's egress policy."
            )
        raise SandboxConfigError(msg)
    return replace(network, mode=EgressMode.EV_BRIDGE)


#: The exploit-verification settings naming a URL it sends requests to: the target, and the
#: login and token endpoints of an auth server that may listen on a port of its own.
_EV_URL_ENV: Final[tuple[str, ...]] = ("EV_TARGET_URL", "EV_AUTH_LOGIN_URL", "EV_AUTH_TOKEN_URL")

#: The scheme's port where a URL names none.
_DEFAULT_PORTS: Final[Mapping[str, int]] = {"http": 80, "https": 443}

#: The first port an unprivileged process may listen on, which the in-container relay is.
_FIRST_UNPRIVILEGED_PORT: Final = 1024


def _ev_forwards(env: Mapping[str, str]) -> tuple[int, ...]:
    """The loopback ports a scoped `ev` run forwards: those its EV URLs name on this machine.

    A URL off loopback earns none: exploit verification refuses it anyway, and a forward is the
    run's way to this machine, never anywhere else.

    Raises:
        SandboxConfigError: If a port is not a number, is privileged (the relay cannot listen
            there), or is the proxy relay's or the out-of-band listener's own.
    """
    ports: set[int] = set()
    for name in _EV_URL_ENV:
        url = (env.get(name) or "").strip()
        parts = urlsplit(url)
        if not url or not is_loopback(host_of(url) or ""):
            continue
        try:
            port = parts.port or _DEFAULT_PORTS.get(parts.scheme, 80)
        except ValueError as exc:
            msg = f"{name} gives {url!r}, whose port is not a port number"
            raise SandboxConfigError(msg) from exc
        if port < _FIRST_UNPRIVILEGED_PORT or port in (EGRESS_RELAY_PORT, EV_CALLBACK_PORT):
            msg = (
                f"{name} names port {port}, which a scoped run cannot forward: the relay in the "
                f"container listens unprivileged, on {_FIRST_UNPRIVILEGED_PORT} and up, "
                f"{EGRESS_RELAY_PORT} is the model proxy's and {EV_CALLBACK_PORT} the "
                f"out-of-band listener's. Run the target on another port, or set "
                f"sandbox.egress: open."
            )
            raise SandboxConfigError(msg)
        ports.add(port)
    return tuple(sorted(ports))


def refuse_batch(flag_paths: Mapping[str, Path]) -> None:
    """Refuse `--repo-file`, whose entries may name host directories nothing has mounted.

    Raises:
        SandboxUnavailableError: If `--repo-file` was given.
    """
    if "--repo-file" not in flag_paths:
        return
    msg = (
        "--repo-file cannot be combined with a sandbox: its entries may name local "
        "directories, and only paths known before the run starts can be mounted. Scan each "
        "repo with its own contained --repo invocation, or set sandbox.via: none."
    )
    raise SandboxUnavailableError(msg)


def _refuse_repo_holding_state(repo_mount: Mount, repo: Path, state_root: Path) -> None:
    """Refuse a target that holds the state root, which its mount would show in full.

    At either fs setting: read-only, the always-writable state mount would widen the repo;
    writable, the repo mount itself would carry every target's state and the host database.

    Raises:
        SandboxUnavailableError: If `VVAHARNESS_STATE_DIR` is the target or inside it.
    """
    conflict = _mount_conflict(repo_mount, [], repo=repo, state_root=state_root)
    if conflict is not None:
        msg = (f"--repo names {repo}: {conflict} Set VVAHARNESS_STATE_DIR to a directory "
               f"outside the target.")
        raise SandboxUnavailableError(msg)


#: The target's own git config keys that name a command git runs on file content, and the
#: includes that could hide one. The image pins the hook and fsmonitor commands for every git the
#: harness spawns; a driver is named per attribute pattern (`diff.external` for every diff), so
#: no fixed pin can reach it.
_GIT_DRIVER_KEY: Final = re.compile(
    r"(?:filter\..+\.(?:clean|smudge|process)|diff\..+\.(?:textconv|command)|diff\.external"
    r"|merge\..+\.driver|include\.path|includeif\..+\.path)"
)

def host_git_env(root: Path) -> dict[str, str]:
    """Environment for a host git run on untrusted *root*: ambient ``GIT_*`` dropped, ceiling set.

    ``GIT_CEILING_DIRECTORIES`` keeps git from climbing above *root* to a real parent repo when
    *root* has none. Host-side preflight runs need it: the image's pins reach only in-container git.
    """
    env = git_env_without_overrides()
    env["GIT_CEILING_DIRECTORIES"] = str(root.parent)
    return env


def _git_config_keys(path: Path) -> set[str]:
    """Every key set in the git config file *path*, as git itself parses it.

    Raises:
        SandboxUnavailableError: If git is missing here or cannot parse the file.
    """
    try:
        listed = subprocess.run(  # noqa: S603 — fixed argv; the file is parsed, never run
            ["git", "config", "--file", str(path), "--null", "--list"],  # noqa: S607
            capture_output=True, check=True, timeout=30,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        msg = (f"sandbox: could not read {path} to check that it names no git driver ({exc}). "
               f"Install git on this machine, or repair that file.")
        raise SandboxUnavailableError(msg) from exc
    # `--null` ends each entry with NUL and puts a newline between the key and its value
    return {entry.split("\n", 1)[0] for entry in listed.stdout.decode("utf-8", "replace")
            .split("\0") if entry}


def _refuse_git_drivers(repo: Path) -> None:
    """Refuse a target whose own git config names a filter, diff or merge driver.

    Git runs such a driver on the target's files during `diff`, `status`, `add` and `checkout`,
    inside the container with the model credentials and the run's network reach, and a read-only
    `.git` mount does not stop it. A clone never carries this file, so only a checkout whose
    `.git` came from elsewhere is refused. `git config --file` parses it and never runs anything.

    The config git reads can hide behind an indirection -- a `gitdir:`/symlinked `.git`, a
    `commondir`, a submodule's own config -- so each is refused or followed rather than trusted
    to be absent. A bare layout at a `.git`-less root is barred by the image's
    `safe.bareRepository=explicit` pin, so it reaches no config here either.

    Raises:
        SandboxUnavailableError: If such a key is set, the `.git` uses an indirection that could
            place the config outside this check, or the config cannot be read.
    """
    for gitdir in _git_config_dirs(repo.resolve()):
        _refuse_driver_in(gitdir / "config")
        _refuse_driver_in(gitdir / "config.worktree")


def _git_config_dirs(root: Path) -> list[Path]:
    """Every git directory whose config git would read for a scan of *root*.

    The target's own and each gitlink submodule's, in and under the target.

    Not an `rglob` for any file named `config`, which would also match a ref or reflog named
    `config` and refuse a legitimate repo; the real git dirs are enumerated and only their
    `config` / `config.worktree` are read. A `gitdir:` pointer that stays inside the target --
    a normal `git worktree` or submodule checkout -- is followed, not refused; where that lands
    on a linked worktree's dir, its `commondir` is followed too so the shared main config (where
    a driver would actually live) is read.

    Raises:
        SandboxUnavailableError: via `_resolve_git_dir`, if a `.git` is a symlink or a pointer
            that could place a config this check cannot see onto the writable mount.
    """
    dirs: list[Path] = []
    top = _resolve_git_dir(root / ".git", root)
    for found in (top, _commondir_of(top, root)):
        if found is not None and found not in dirs:
            dirs.append(found)
    for candidate in _submodule_git_dirs(root, top):
        if candidate.is_dir() and candidate not in dirs:
            dirs.append(candidate)
    return dirs


def _commondir_of(gitdir: Path | None, root: Path) -> Path | None:
    """The shared git dir a linked worktree's `commondir` in *gitdir* names, when inside *root*.

    A `git worktree`'s own dir holds only its per-worktree config; a filter/diff/merge driver
    that would run on the worktree lives in the main repo's config, which `commondir` points to.
    Read that too when it stays inside the target; a commondir leaving the target is not on the
    mount, so in-container git never reaches it. Best effort: an unreadable pointer is skipped.

    Raises:
        SandboxUnavailableError: via `_refuse_if_root`, if the commondir resolves to *root* itself;
            via `_refuse_unseen_pointer`, if in-container git would resolve it elsewhere.
    """
    link = None if gitdir is None else gitdir / "commondir"
    if link is None or not link.is_file():
        return None
    try:
        rel = link.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        rel = ""
    if not rel:
        return None
    pointed = Path(rel)
    _refuse_unseen_pointer(pointed, link, root)
    target = (pointed if pointed.is_absolute() else link.parent / pointed).resolve()
    inside = _within(target, root) and target.is_dir()
    if inside:
        _refuse_if_root(target, link, root)
    return target if inside else None


def _submodule_git_dirs(root: Path, top: Path | None) -> list[Path]:
    """Candidate git dirs for each in-target gitlink: its own `.git`, and `.git/modules/<p>`."""
    out: list[Path] = []
    for sub in _gitlink_paths(root):
        sub_root = (root / sub).resolve()
        if not _within(sub_root, root):
            continue  # a gitlink pointing out of the target is not carried by the mount
        own = _resolve_git_dir(sub_root / ".git", root)
        if own is not None:
            out.append(own)
        if top is not None:
            out.append(top / "modules" / sub)  # where git keeps the submodule's real dir
    return out


def _resolve_git_dir(meta: Path, root: Path) -> Path | None:
    """The real git directory `<dir>/.git` (*meta*) denotes, or None when there is none to read.

    Raises:
        SandboxUnavailableError: If *meta* is a symlink, or a `.git` directory holding a
            `commondir` -- each could hide the config git reads from this check. A `gitdir:`
            pointer is followed when it stays inside the target, and ignored when it leaves it
            (the mount does not carry it, so in-container git finds nothing there).
    """
    if meta.is_symlink():
        raise SandboxUnavailableError(_GIT_INDIRECTION_MSG.format(meta=meta, why="a symlink"))
    if not meta.exists():
        return None
    if not meta.is_dir():
        return _follow_gitdir_pointer(meta, root)
    if (meta / "commondir").is_file():
        raise SandboxUnavailableError(
            _GIT_INDIRECTION_MSG.format(meta=meta / "commondir", why="a `commondir` pointer"))
    return meta


def _follow_gitdir_pointer(meta: Path, root: Path) -> Path | None:
    """Resolve a ``gitdir: <path>`` pointer file to its git dir inside *root*, else None.

    Raises:
        SandboxUnavailableError: via `_refuse_if_root`, if the pointer resolves to *root* itself;
            via `_refuse_unseen_pointer`, if in-container git would resolve it elsewhere.
    """
    try:
        text = meta.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return None
    first = text.splitlines()[0] if text else ""
    if not first.startswith("gitdir:"):
        return None
    pointed = Path(first[len("gitdir:"):].strip())
    _refuse_unseen_pointer(pointed, meta, root)
    target = (pointed if pointed.is_absolute() else meta.parent / pointed).resolve()
    inside = _within(target, root) and target.is_dir()
    if inside:
        _refuse_if_root(target, meta, root)
    return target if inside else None


def _refuse_unseen_pointer(pointed: Path, link: Path, root: Path) -> None:
    """Refuse a `gitdir:`/`commondir` pointer that in-container git would read differently.

    These checks resolve *pointed* on this host, but git in the container resolves it against
    the container's mounts. A path under one (`/workspace/gd`) is absent or unrelated here, so
    the host would ignore the directory git actually reads. A symlink in the target can make a
    relative pointer land on such a path too.

    Raises:
        SandboxUnavailableError: If *pointed* names a container mount, or reaches the git dir
            through a symlink inside *root*.
    """
    if _names_container_mount(pointed):
        raise SandboxUnavailableError(_GIT_INDIRECTION_MSG.format(
            meta=link, why=f"a pointer to {pointed}, a path the container mounts"))
    if _pointer_through_symlink(link.parent, pointed, root):
        raise SandboxUnavailableError(_GIT_INDIRECTION_MSG.format(
            meta=link, why=f"a pointer to {pointed}, which goes through a symlink in the target"))


def _names_container_mount(pointed: Path) -> bool:
    """Whether absolute *pointed*, read as Linux git reads it, lands under a container mount."""
    if not pointed.is_absolute():
        return False
    # normpath folds `..` but keeps a leading `//`, which Linux treats as `/`
    norm = PurePosixPath("/" + posixpath.normpath(pointed.as_posix()).lstrip("/"))
    top = norm.parts[1] if len(norm.parts) > 1 else ""
    return top == REPO_TARGET.name or top.startswith("vvaharness-")


def _pointer_through_symlink(base: Path, pointed: Path, root: Path) -> bool:
    """Whether reaching *pointed* from *base* passes a symlink that sits inside *root*."""
    full = pointed if pointed.is_absolute() else base / pointed
    step = Path(full.anchor)
    for part in full.parts[1:]:
        step = step / part
        if step.is_symlink() and _within(step.parent, root):
            return True
    return False


def _gitlink_paths(root: Path) -> list[str]:
    """Relative paths of the gitlink (submodule) entries in *root*'s index; [] if none/unreadable.

    `ls-files` reads the index and applies no filter, so it runs no driver; `GIT_HOST_HARDENING`
    and the scrubbed env (`host_git_env`) stop a `core.fsmonitor` or hook in the target's own
    config from running on this host as git reads that index (the index refresh `ls-files` does
    would otherwise invoke `core.fsmonitor`).
    """
    try:
        done = subprocess.run(  # noqa: S603 — fixed argv; lists the index, runs nothing
            ["git", "-C", str(root), *GIT_HOST_HARDENING, "ls-files", "-s", "-z"],  # noqa: S607
            capture_output=True, timeout=30,
            env=host_git_env(root),
        )
    except (OSError, subprocess.SubprocessError):
        return []
    if done.returncode != 0:
        return []
    # "<mode> <sha> <stage>\t<path>" per entry; a gitlink (submodule) is mode 160000
    entries = done.stdout.decode("utf-8", "replace").split("\0")
    return [e.split("\t", 1)[1] for e in entries if e.startswith("160000 ") and "\t" in e]


def _refuse_driver_in(path: Path) -> None:
    """Refuse the git config file *path* if it names a driver, or is a symlink out of sight."""
    if path.is_symlink():
        raise SandboxUnavailableError(_GIT_INDIRECTION_MSG.format(meta=path, why="a symlink"))
    if not path.is_file():
        return
    named = sorted(key for key in _git_config_keys(path) if _GIT_DRIVER_KEY.fullmatch(key))
    if named:
        msg = (
            f"{path} sets {', '.join(named)}: git would run those commands on the target's "
            f"files inside the container, with the run's model credentials and network reach. "
            f"Remove them from that file, or scan a fresh clone."
        )
        raise SandboxUnavailableError(msg)


#: A `.git` indirection that could place the config git reads outside `_refuse_git_drivers`'
#: reach: refused rather than followed, since each can land on the writable repo mount.
_GIT_INDIRECTION_MSG: Final = (
    "{meta} is {why}, so git could read a config this check does not see, and run a driver it "
    "names on the target's files inside the container. Scan a fresh clone, whose .git is a plain "
    "directory."
)

#: A `.git` pointer or `commondir` that resolves to the worktree root: the git dir would be the
#: writable repo, so a hook or driver planted there runs on the host and it cannot be mounted
#: read-only without disabling remediation. Uncontainable -- refused, not followed.
_GIT_ROOT_AS_GITDIR_MSG: Final = (
    "{meta} resolves the git directory to the repository root, which stays writable for "
    "remediation; a hook or driver written there would then run on the host and cannot be mounted "
    "read-only. Scan a fresh clone, whose .git is a plain directory."
)


def _refuse_if_root(resolved: Path, meta: Path, root: Path) -> None:
    """Refuse a git dir that resolves to *root* itself.

    Compared by identity (`samefile`), not by text: on a case-insensitive or Unicode-normalising
    volume a differently spelled path (`../WORK` for a `work` root) is the same directory, which a
    text match would miss -- and then crash in `relative_to` at the mount layer rather than refuse
    cleanly. Mirrors how the mount checks compare. Best effort: a path that cannot be stat'd is
    not treated as the root.

    Raises:
        SandboxUnavailableError: If *resolved* is the repository root -- the writable worktree
            cannot double as a read-only git dir, so a hook or driver planted there would run on
            the host and this layout cannot be contained.
    """
    try:
        same = resolved.samefile(root)
    except OSError:
        same = False
    if same:
        raise SandboxUnavailableError(_GIT_ROOT_AS_GITDIR_MSG.format(meta=meta))


def refuse_split_overlay(config: Path | None) -> None:
    """Refuse a linked `--config` whose overlay is not the one the contained run would load.

    The host reads `config.local.yaml` beside the profile path as given; the container reads
    it beside the file that path resolves to, since only that directory is mounted. Through a
    symlink into another directory the two runs would apply different overlays, which can route
    the models, endpoints and tool permissions differently. *config* must be the path as the
    host loaded it, before anything resolves it (`entry._contain`).

    Raises:
        SandboxUnavailableError: If the two directories differ and either holds an overlay.
    """
    from vvaharness.config.constants import (  # noqa: PLC0415 — lazy: see `_within`
        LOCAL_OVERLAY_NAME,
    )

    if config is None:
        return
    given, resolved = Path(config).absolute().parent, Path(config).resolve().parent
    if given.resolve() == resolved:
        return
    overlays = [d / LOCAL_OVERLAY_NAME for d in (given, resolved)]
    if not any(o.exists() or o.is_symlink() for o in overlays):
        return
    msg = (
        f"--config {config} is a link into {resolved}, so this run would apply {overlays[0]} "
        f"while the contained run applies {overlays[1]}. Pass the profile's real path, "
        f"{Path(config).resolve()}."
    )
    raise SandboxUnavailableError(msg)


def _spelled_by_filesystem(path: Path) -> str | None:
    """*path* as the filesystem itself spells it, where the platform can say (macOS), else None."""
    try:
        import fcntl  # noqa: PLC0415 — POSIX only; `F_GETPATH` is macOS's

        # O_NONBLOCK so a FIFO planted as --repo cannot block the open forever while the run
        # lock is held; the target is a directory anyway, which the flag does not affect.
        fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
    except (ImportError, OSError):
        return None
    try:
        return os.fsdecode(fcntl.fcntl(fd, fcntl.F_GETPATH, bytes(1024)).split(b"\0", 1)[0])
    except (AttributeError, OSError):  # no `F_GETPATH` on this platform
        return None
    finally:
        os.close(fd)


def _refuse_case_variant(repo: Path) -> None:
    """Refuse a `--repo` that spells the target other than the filesystem does.

    A case-insensitive volume, the macOS default, answers to any case of a name, but the run id
    hashes the path as given: two spellings of one target get two run locks, which no longer
    exclude each other, and two state subtrees.

    Raises:
        SandboxUnavailableError: If the spelling differs from the directory's own only in case
            or Unicode normalization.
    """
    given = str(repo.resolve())
    actual = _spelled_by_filesystem(repo.resolve())

    def fold(text: str) -> str:
        return unicodedata.normalize("NFC", text).casefold()

    if actual is None or actual == given or fold(actual) != fold(given):
        return
    msg = (
        f"--repo {repo} names {actual}, spelled differently: on this case-insensitive volume "
        f"each spelling would get its own run lock and state. Pass --repo {actual}."
    )
    raise SandboxUnavailableError(msg)


def _refuse_inputs(repo: Path, flag_paths: Mapping[str, Path]) -> None:
    """The refusals that read only what the invocation names, before anything is created."""
    refuse_batch(flag_paths)
    _refuse_case_variant(repo)
    _refuse_git_drivers(repo)


def _git_metadata_mount(repo_mount: Mount) -> list[Mount]:
    """`.git` and every real git dir it resolves to, read-only over a writable repo: a hook,
    driver or config written there runs on the host at the operator's next git command.

    Remediation edits worktree files, never a git dir. A symlinked `.git` gets no mount: following
    it would let the target choose which host directory is bound. A `gitdir:` pointer, a linked
    worktree or a submodule names a dir that itself sits on the writable repo mount, so the
    pointer file alone being read-only is not enough: each in-target git dir `_refuse_git_drivers`
    already enumerated is bound read-only too.
    """
    if not repo_mount.writable:
        return []
    root = repo_mount.source
    meta = root / ".git"
    mounts: list[Mount] = []
    if meta.exists() and not meta.is_symlink():
        mounts.append(Mount(source=meta, target=REPO_TARGET / ".git", writable=False))
    mounts.extend(_resolved_git_dir_mounts(root, mounts))
    return mounts


def _resolved_git_dir_mounts(root: Path, existing: Sequence[Mount]) -> list[Mount]:
    """Read-only mounts for the in-target real git dirs a `.git` resolves to.

    Skips any already covered by *existing* -- the `.git` path itself (a plain `.git` directory
    resolves to that same mount), or a dir nested under one already bound read-only.
    """
    bound = {m.target for m in existing}
    out: list[Mount] = []
    for gitdir in _git_config_dirs(root):
        if not _within(gitdir, root):
            continue  # a dir outside the target is not on the writable mount; nothing to protect
        target = REPO_TARGET / gitdir.relative_to(root)
        if target == REPO_TARGET:
            # The git dir resolved to the repo root; a read-only mount here would collide with the
            # writable repo mount. `_refuse_if_root` refuses this upstream, so reaching here is a
            # bug -- fail closed rather than emit a duplicate /workspace mount.
            raise SandboxUnavailableError(_GIT_ROOT_AS_GITDIR_MSG.format(meta=gitdir))
        if any(target == t or target.is_relative_to(t) for t in bound):
            continue
        out.append(Mount(source=gitdir, target=target, writable=False))
        bound.add(target)
    return out


def spec_from(
    cfg: SandboxConfig, repo: Path, flag_paths: Mapping[str, Path], *, command: str = "scan"
) -> SandboxSpec:
    """Derive the spec for a contained run of *repo* under *cfg*, for subcommand *command*.

    Only a `VERIFYING_COMMANDS` subcommand is armed for exploit verification. `ev-replay`
    exists only to resend exploit requests: it verifies whatever the profile switch and
    `EV_API_COLLECTION` say, since it reads neither.
    """
    replay = command == "ev-replay"
    _refuse_inputs(repo, flag_paths)
    no_egress = cfg.egress is SandboxEgress.NONE
    if no_egress:
        _note_no_egress(cfg)
    _warn_loopback_endpoints(cfg)
    _warn_ungranted_ingest(cfg)
    if command == "scan":
        _warn_semgrep_unrouted(cfg)
    _warn_open_egress(cfg)
    repo_mount = Mount(
        source=repo.resolve(),
        target=REPO_TARGET,
        # Every stage that writes the repository needs a model, which `egress: none` cannot reach:
        # writable there, the mount would serve only a hostile target changing its own tree.
        writable=cfg.fs is SandboxFs.WORKSPACE_WRITE and not no_egress,
    )
    # Only this target's subtree, never the whole state root: given the root, a hostile target
    # reads every other target's findings and plants rows a later host command adopts.
    from vvaharness.orchestrator import store  # noqa: PLC0415 — lazy: see `_within`
    from vvaharness.orchestrator.checkpoints import run_id_for  # noqa: PLC0415

    run_id = run_id_for(repo)
    # Checked before the subtree is created, so a refused run leaves nothing inside the repo.
    state_root = store.state_root()
    _refuse_repo_holding_state(repo_mount, repo, state_root)
    try:
        state = store.contained_state_dir(run_id).resolve()
    except store.StoreError as exc:  # a symlinked or non-directory state root: refuse, cleanly
        raise SandboxUnavailableError(str(exc)) from exc
    mounts = [repo_mount, Mount(source=state, target=STATE_TARGET, writable=True)]
    mounts.extend(_git_metadata_mount(repo_mount))
    mounts.extend(_flag_mounts(flag_paths, repo, mounts, state_root))
    # After the flag mounts: the inject targets are derived from where `--config` landed.
    mounts.extend(_inject_mounts(cfg, flag_paths, mounts, repo=repo, state_root=state_root))
    # Only a scan loads the Semgrep plugin, so only a scan needs its rule files or its binary.
    semgrep = cfg.semgrep_plugin and command == "scan"
    if semgrep:
        mounts.extend(_semgrep_config_mounts(cfg, mounts, repo=repo, state_root=state_root))
    # EV's inputs and its host-reachable network are only required by a run that verifies: a
    # stale EV_* path in the environment must not refuse every other contained run.
    armed = replay or (command in VERIFYING_COMMANDS and ev_requested(cfg))
    if armed:
        mounts.extend(_ev_mounts(mounts, repo, state_root))
    network = network_for(cfg)
    if armed:
        network = _ev_network(network, cfg, replay=replay)
    return SandboxSpec(
        level=level_of(cfg),
        mounts=tuple(mounts),
        image=cfg.image,
        workdir=CONTAINER_WORKDIR,
        timeout=cfg.timeout_seconds,
        backend_options=cfg.backend_options,
        network=network,
        allow_pull=cfg.allow_pull,
        allow_remote_daemon=cfg.allow_remote_daemon,
        needs_semgrep=semgrep,
    )


def resolve(
    cfg: SandboxConfig, repo: Path, flag_paths: Mapping[str, Path], *, command: str = "scan"
) -> tuple[Sandbox, SandboxSpec]:
    """Return the backend and spec, having checked the pair is actually enforceable.

    *command* is the subcommand being contained (`spec_from`).

    The capability check happens here rather than at first use, so a profile asking for
    something its backend cannot deliver fails before any container exists.

    Raises:
        SandboxUnavailableError: If `cfg.via` names no registered backend.
    """
    spec = spec_from(cfg, repo, flag_paths, command=command)
    try:
        sandbox = get_sandbox(cfg.via)
    except ValueError as exc:
        raise SandboxUnavailableError(str(exc)) from exc
    assert_supports(cfg.via, spec.level, sandbox.capabilities)
    return sandbox, spec


__all__ = [
    "CONTAINER_WORKDIR",
    "DEFAULT_EGRESS",
    "DEFAULT_FS",
    "EV_INPUTS_TARGET",
    "FLAG_RULES",
    "REPO_TARGET",
    "SANDBOX_KEYS",
    "STATE_TARGET",
    "UNCONTAINED",
    "MountRule",
    "env_policy",
    "ev_requested",
    "host_paths_note",
    "level_of",
    "load_sandbox_config",
    "mount_origin",
    "refuse_batch",
    "refuse_split_overlay",
    "requested",
    "resolve",
    "spec_from",
]
