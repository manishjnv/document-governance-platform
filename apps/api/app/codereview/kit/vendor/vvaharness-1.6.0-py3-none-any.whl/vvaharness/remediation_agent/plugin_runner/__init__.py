# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""remediation_agent.plugin_runner — run the remediation method for one finding."""
from __future__ import annotations

import asyncio
import json
import os
import threading
from collections.abc import Coroutine
from pathlib import Path
from typing import Any, TypeVar

from vvaharness.backends.harness import (
    HarnessAssistantText,
    HarnessResult,
    HarnessToolResult,
    HarnessToolUse,
    StreamingOptions,
    SubagentDefinition,
    ToolPolicy,
    get_harness,
)
from vvaharness.backends.harness.deepagents.limits import RECURSION_HEADROOM
from vvaharness.backends.harness.deepagents.model_call_budget import ModelCallBudget
from vvaharness.backends.harness.provider_routing import credential_env_overrides
from vvaharness.backends.harness.repeat_guard import guard_repeats
from vvaharness.backends.llm.cli import post_scan_read_deny_rules, stream_trace
from vvaharness.backends.llm.deepagents import markers_on, raise_if_refused
from vvaharness.backends.llm.models import (
    ModelRefusal,
    call_timeout_error,
    model_refusal_from,
)
from vvaharness.backends.llm.registry import agentic, use_responses_api_of
from vvaharness.backends.llm.registry import resolve as resolve_model
from vvaharness.remediation_agent.models import FixerResult, RemediationVerdict
from vvaharness.remediation_agent.plugin_runner.handoff import FixerDispatchGuard
from vvaharness.remediation_agent.plugin_runner.helpers import (  # noqa: F401
    _build_user,
    _coerce_verdict,
    _tools,
)
from vvaharness.remediation_agent.plugin_runner.run import (
    ENGINE_ID,
    Amended,
    EngineRequest,
    GuardedCall,
    apply_plugin,
    call_with_guards,
    checkpoint_record,
    engine_model,
    harness_amend,
)
from vvaharness.remediation_agent.plugin_runner.trace import dump as _dump
from vvaharness.remediation_agent.plugin_runner.trace import dump_policy as _dump_policy
from vvaharness.remediation_agent.policy import describe_escapes, escaping_symlinks
from vvaharness.remediation_agent.prompts import (
    FIXER_SYSTEM,
    ORCHESTRATOR_SYSTEM,
    SYSTEM,
)
from vvaharness.remediation_agent.target import RemediationTarget
from vvaharness.util import console
from vvaharness.util.json_extract import extract_json
from vvaharness.util.tokens import TOKENS
from vvaharness.util.warn_once import warn_once

__all__ = [
    "ENGINE_ID", "Amended", "EngineRequest", "GuardedCall",
    "apply_plugin", "call_with_guards", "checkpoint_record", "engine_model",
    "harness_amend",
]

_T = TypeVar("_T")

def _run_sync(awaitable: Coroutine[Any, Any, _T]) -> _T:
    """Run a coroutine from synchronous code, including inside a live loop."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(awaitable)

    result: list[_T] = []
    error: list[BaseException] = []

    def worker() -> None:
        try:
            result.append(asyncio.run(awaitable))
        except BaseException as exc:  # propagate the original harness failure
            error.append(exc)

    thread = threading.Thread(target=worker, name="vvaharness-remediation", daemon=True)
    thread.start()
    thread.join()
    if error:
        raise error[0]
    return result[0]


def _timeout_of(sr: Any) -> int:
    """`step_remediate.timeout`, defaulting to one hour when unset or falsy."""
    return int(getattr(sr, "timeout", 3600) or 3600)


def _max_model_calls_of(sr: Any) -> int:
    """`step_remediate.max_model_calls`; <= 0 leaves the session and its fixer unmetered."""
    return int(getattr(sr, "max_model_calls", 0) or 0)


def _remediate_call_budget(sr: Any) -> ModelCallBudget | None:
    """The fix session's model-call cap, or None when `step_remediate.max_model_calls` <= 0."""
    limit = _max_model_calls_of(sr)
    if limit <= 0:
        return None
    return ModelCallBudget(
        limit=limit,
        outcome_tools=frozenset({RemediationVerdict.__name__}),
        counter="s10_model_call_budget_final_turn",
        stage="s10",
    )


def _debug_log(event: str, detail: str = "") -> None:
    """Append a debug line to VVAHARNESS_DEBUG_LOG (no-op when unset)."""
    path = os.environ.get("VVAHARNESS_DEBUG_LOG")
    if not path:
        return
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(f"{event}: {detail}\n")


def _terminal_stats(terminal: HarnessResult) -> tuple[int, int, str]:
    """Return (message count, tool-call count, trailing-message shape) for diagnostics."""
    messages = (getattr(terminal, "state", None) or {}).get("messages", [])
    tool_calls = sum(len(getattr(m, "tool_calls", None) or []) for m in messages)
    last = messages[-1] if messages else None
    pending = bool(getattr(last, "tool_calls", None)) and type(last).__name__ == "AIMessage"
    shape = "pending_tool_call(loop_truncated)" if pending else type(last).__name__ if last else "empty"
    return len(messages), tool_calls, shape


def _debug_terminal(terminal: HarnessResult) -> None:
    """Dump why a terminal lacks structured output (tool-call trail + state)."""
    if not os.environ.get("VVAHARNESS_DEBUG_LOG"):
        return
    n_msgs, n_calls, shape = _terminal_stats(terminal)
    _debug_log("TERMINAL.structured_is_none", str(terminal.structured is None))
    _debug_log("TERMINAL.structured", repr(terminal.structured)[:600])
    _debug_log("TERMINAL.result_text", repr(terminal.result_text)[:600])
    _debug_log("TERMINAL.stats", f"messages={n_msgs} tool_calls={n_calls} last={shape}")
    for msg in (getattr(terminal, "state", None) or {}).get("messages", [])[-8:]:
        tool_calls = getattr(msg, "tool_calls", None) or []
        _debug_log(
            f"STATE_MSG.{type(msg).__name__}",
            f"tool_calls={[c.get('name') for c in tool_calls]} "
            f"content={str(getattr(msg, 'content', ''))[:200]}",
        )


def _report_recursion_limit(terminal: HarnessResult, options: StreamingOptions) -> None:
    """Surface a swallowed recursion-limit truncation with actionable advice."""
    n_msgs, n_calls, shape = _terminal_stats(terminal)
    limit = (options.max_turns or 50) + RECURSION_HEADROOM
    msg = (
        f"  [deepagents] {options.model} HIT THE LANGGRAPH RECURSION LIMIT "
        f"(recursion_limit={limit} = step_remediate.max_turns({options.max_turns}) + "
        f"{RECURSION_HEADROOM}). The tool loop was truncated mid-flight after {n_calls} tool "
        f"call(s) / {n_msgs} message(s) (last={shape}), so the agent never reached a final turn "
        f"and produced NO structured verdict. ACTION: set step_remediate.max_model_calls "
        f"(e.g. 20) to force a final verdict turn well before this limit; raising max_turns "
        f"only raises the limit and lengthens the loop."
    )
    console.write(msg)
    _debug_log("RECURSION_LIMIT_HIT", f"limit={limit} tool_calls={n_calls} messages={n_msgs} last={shape}")


def _verdict_extraction_prompt() -> str:
    schema = json.dumps(RemediationVerdict.model_json_schema(), separators=(",", ":"))
    return (
        "You completed remediation work above but did not emit a structured verdict. "
        "Based solely on the work you did, return ONLY a JSON object — no prose, no "
        f"markdown fences — matching exactly this JSON Schema:\n{schema}"
    )


def _extract_verdict_from_history(
    terminal: HarnessResult, options: StreamingOptions
) -> dict | None:
    """Ask the same model to emit its verdict as raw JSON from its own work log."""
    from langchain_core.messages import HumanMessage

    from vvaharness.backends.harness.deepagents.options import build_model_cached
    messages = (getattr(terminal, "state", None) or {}).get("messages", [])
    if not messages:
        return None
    model = build_model_cached(
        options.model,
        options.env,
        options.model_provider,
        use_responses_api=options.use_responses_api,
    )
    try:
        response = model.invoke([*messages, HumanMessage(content=_verdict_extraction_prompt())])
        data = extract_json(getattr(response, "content", "") or "")
        if isinstance(data, dict):
            return data
        _debug_log("EXTRACTION_NOT_A_DICT", repr(data)[:200])
        return None
    except Exception as exc:
        _debug_log("EXTRACTION_FAILED", f"{type(exc).__name__}: {exc}")
        return None


def _attempt_extraction(terminal: HarnessResult, options: StreamingOptions) -> Any:
    """Try post-hoc verdict extraction; print diagnostics; return result or None."""
    n_tool_calls = sum(
        len(getattr(m, "tool_calls", None) or [])
        for m in (getattr(terminal, "state", None) or {}).get("messages", [])
    )
    console.write(
        f"  [deepagents] {options.model} made {n_tool_calls} tool call(s) but did not "
        f"emit a structured verdict — attempting post-hoc extraction from message history"
    )
    extracted = _extract_verdict_from_history(terminal, options)
    if extracted is not None:
        _debug_log("EXTRACTION_RESULT", repr(extracted)[:400])
        return extracted
    console.write(
        f"  [deepagents] post-hoc extraction failed for {options.model} — "
        f"recording as Needs Review. Check endpoint tool-call-parser config."
    )
    return terminal.result_text or ""


async def _consume_deepagents(prompt: str, options: StreamingOptions,
                              *, verbose: bool) -> Any:
    """Consume one DeepAgents stream and return its structured terminal value."""
    from vvaharness.backends.harness import HarnessProcessError
    terminal: HarnessResult | None = None
    recursion_error: BaseException | None = None
    refusal: ModelRefusal | None = None
    try:
        stream = guard_repeats(get_harness("deepagents").run_streaming(prompt, options),
                               stage="s10", route="deepagents")
        async for message in stream:
            if isinstance(message, HarnessResult):
                terminal = message
            elif isinstance(message, HarnessAssistantText):
                _debug_log("ASSISTANT_TEXT", message.text[:200])
                if verbose:
                    _dump("ASSISTANT", message.text)
            elif isinstance(message, HarnessToolUse):
                _debug_log("TOOL_USE", f"{message.name} {str(message.input)[:200]}")
                if verbose:
                    _dump(f"TOOL → {message.name}", str(message.input))
            elif isinstance(message, HarnessToolResult):
                # The result text, so a loop on one repeated answer can be triaged from the log
                _debug_log("TOOL_RESULT", str(message.content)[:200])
                if verbose:
                    _dump("TOOL RESULT", str(message.content))
    except Exception as exc:
        # A mid-stream provider block is never salvaged into extraction. Recursion: typed flag
        # primary, string match a belt; `terminal is None` on purpose so it propagates.
        refusal = model_refusal_from(exc, route="deepagents", stage="s10")
        recursion = isinstance(exc, HarnessProcessError) and (
            getattr(exc, "recursion_limited", False) or "GraphRecursionError" in str(exc))
        if refusal is None and not (recursion and terminal is not None):
            raise
        recursion_error = exc
    if refusal is not None:
        # Outside the except, unchained, as deepagents._call_classified does
        raise refusal
    if terminal is None:
        raise RuntimeError("DeepAgents remediation ended without a terminal result")
    _debug_terminal(terminal)
    # Before extraction, which would re-send the refused conversation to the same model
    raise_if_refused(terminal, tag="s10")
    if terminal.is_error and recursion_error is None:
        raise RuntimeError(
            f"DeepAgents remediation failed: {terminal.subtype or 'unknown error'}")
    if terminal.structured is not None:
        return terminal.structured
    if recursion_error is not None:
        _report_recursion_limit(terminal, options)
    result = _attempt_extraction(terminal, options)
    if result is not None or recursion_error is None:
        return result
    raise recursion_error  # extraction failed and it was a recursion crash


async def _consume_deepagents_bounded(prompt: str, options: StreamingOptions,
                                      *, verbose: bool, timeout: int) -> Any:
    """Bound one DeepAgents remediation session by a wall clock; raises VVAH-E008 on expiry."""
    # This coroutine runs inside _run_sync's own fresh asyncio.run() loop, so the cancellation
    # asyncio.timeout delivers on expiry reaches the in-flight LangGraph stream directly.
    deadline = asyncio.timeout(timeout)
    try:
        async with deadline:
            return await _consume_deepagents(prompt, options, verbose=verbose)
    except TimeoutError as exc:
        # .expired() tells OUR deadline apart from a TimeoutError raised inside the session
        if not deadline.expired():
            raise
        raise call_timeout_error(
            stage="s10", route="deepagents", budget_s=timeout, effort=None,
            cause_text=f"deepagents remediation session exceeded {timeout:g}s") from exc


def _virtualize_deepagents_prompt(user: str) -> str:
    """Present the repo using DeepAgents' virtual filesystem namespace so tools don't look for the host path inside the virtual root."""
    lines = user.splitlines()
    if lines and lines[0].startswith("REPOSITORY ROOT:"):
        lines[0] = "REPOSITORY ROOT: / (DeepAgents virtual workspace root)"
    return "\n".join(lines)


def _invoke_deepagents(user: str, *, model_id: str, repo: Path, mode: str,
                       sr: Any, cfg: Any, verbose: bool,
                       provider: str | None = None,
                       use_responses_api: bool | None = None,
                       primary_file: str = "") -> Any:
    tools = tuple(t for t in _tools(cfg) if t != "Bash")
    fix_mode = mode == "fix"
    env = {
        **os.environ,
        **credential_env_overrides(
            model_id, provider,
            sdk_cfg=getattr(cfg, "sdk", None),
            openai_cfg=getattr(cfg, "openai", None),
        ),
    }
    # Orchestrator reads redacted, fixer unredacted: "Edit" makes get_subagent_specs skip redaction
    agents: dict[str, SubagentDefinition] = {}
    if fix_mode:
        fixer_tools = tuple(dict.fromkeys((*tools, "Edit")))
        agents = {
            "fixer": SubagentDefinition(
                name="fixer",
                description="Applies the security fix to the target file(s).",
                prompt=FIXER_SYSTEM,
                tools=fixer_tools,
                response_model=FixerResult,
                # The parent's cap, shared by the session's dispatches: a looping fixer reports too
                max_model_calls=_max_model_calls_of(sr),
            ),
        }
    options = StreamingOptions(
        model=model_id,
        model_provider=provider,
        use_responses_api=use_responses_api,
        cwd=repo,
        env=env,
        max_turns=getattr(sr, "max_turns", 40),
        max_budget_usd=getattr(sr, "max_budget_usd", 10.0),
        system_prompt=ORCHESTRATOR_SYSTEM if fix_mode else SYSTEM,
        tool_policy=ToolPolicy(
            allowed_tools=tools,
            disallowed_tools=("Bash",),
        ),
        response_model=RemediationVerdict,
        # Force the verdict tool only to end the session, not on every turn (see the field).
        force_verdict_only=True,
        allow_writes=fix_mode,
        writable_paths=(str(repo.resolve()),) if fix_mode else (),
        graph_name="remediation",
        agents=agents,
        parent_middleware=tuple(m for m in (
            FixerDispatchGuard(finding_context=user, primary_file=primary_file)
            if fix_mode else None,
            _remediate_call_budget(sr),
        ) if m is not None),
        cache_markers=markers_on(getattr(cfg, "sdk", None)),
    )
    return _run_sync(_consume_deepagents_bounded(
        user, options, verbose=verbose, timeout=_timeout_of(sr)))


#: One-time notice per process for the degradation via:cli cannot close (see below).
_WARNED_CLI_REDACTION: set[str] = set()
#: One-time notice per process for a repo whose symlinks force report-only.
_WARNED_SYMLINK_ESCAPE: set[str] = set()


def _invoke_cli(user: str, *, cfg, repo: Path, mode: str, sr: Any,
                verbose: bool, tag: str) -> Any:
    """S10 on `via: cli`, with the confinement the deepagents branch gets natively."""
    # Permission-engine scoping, NOT a path jail: symlinks escape, keep run.py's git-status proof
    fix_mode = mode == "fix"
    tools = [t for t in _tools(cfg) if t != "Bash"]
    if fix_mode:
        # Same two writers the deepagents fixer gets, and only in fix mode.
        tools = list(dict.fromkeys([*tools, "Edit", "Write"]))
        warn_once(
            _WARNED_CLI_REDACTION, "cli-fix-redaction",
            "  [remediate] NOTE: via:cli runs the fix in ONE context that reads "
            "unredacted source. The orchestrator-reads-redacted / fixer-edits-"
            "unredacted split (and its dispatch guard) is via:deepagents-only — the "
            "CLI exposes no seam to rewrite a tool result the model already has. "
            "Route models.remediate via: deepagents where that separation is "
            "required; everything leaving this machine is still redacted.")
    return agentic(
        user,
        model=cfg.models.remediate,
        system_prompt=SYSTEM,
        allowed_tools=tools,
        cwd=str(repo),
        max_budget_usd=getattr(sr, "max_budget_usd", 10.0),
        max_turns=getattr(sr, "max_turns", 40),
        # --max-turns is never forwarded: max_turns is the backend's turn watchdog, this timeout
        # the outer bound
        timeout=_timeout_of(sr),
        tag=tag,
        stream_cb=(stream_trace if verbose else None),
        json_schema=RemediationVerdict.model_json_schema(),
        disallowed_tools=["Bash", *post_scan_read_deny_rules()],
        # acceptEdits only where edits are wanted; report mode ships no writer at all.
        permission_mode="acceptEdits" if fix_mode else "default",
        permission_prompts="none",
    )


def _symlink_safe_mode(repo: Path, mode: str) -> str:
    """Return *mode*, downgraded to report-only when *repo* has escaping symlinks.

    A symlink inside the repository that resolves outside it turns any write
    through it into a host write that no post-hoc control can see: the link
    object itself never changes, so ``git status`` and ``changed_files_whole_tree``
    report nothing and ``revert_files`` has no baseline to restore. The hazard
    is therefore unrecoverable once a write has happened, which makes refusing
    the writer the only effective control (CWE-59).
    """
    if mode != "fix":
        return mode
    escapes = escaping_symlinks(repo)
    if not escapes:
        return mode
    warn_once(
        _WARNED_SYMLINK_ESCAPE, "fix-symlink-escape",
        "  [remediate] REFUSING fix mode: the repository contains "
        f"{len(escapes)} symlink(s) resolving outside the checkout "
        f"({describe_escapes(escapes)}). A write through such a link lands on the host "
        "and is invisible to the post-gate's git-status proof, so it could be "
        "neither detected nor reverted. Running report-only instead — remove "
        "the link(s) or scan a clean copy to enable fix mode.")
    return "report"


def _invoke(target: RemediationTarget, cfg, repo: Path, mode: str,
            verbose: bool = False, *, pre=None, ctx=None) -> Any:
    """Single model call through the configured backend, isolated so tests can monkeypatch one seam."""
    sr = getattr(cfg, "step_remediate", None)
    user = _build_user(target, repo, mode, pre=pre, ctx=ctx)
    model_id, via, _ = resolve_model(cfg.models.remediate)
    provider = getattr(cfg.models.remediate, "provider", None)
    mode = _symlink_safe_mode(repo, mode)
    if via == "deepagents":
        user = _virtualize_deepagents_prompt(user)
    if verbose:
        _dump(f"PROMPT → finding {target.index} ({mode})", user)
    with TOKENS.phase("remediation-agent-remediate"):
        if via == "deepagents":
            raw = _invoke_deepagents(
                user, model_id=model_id, repo=repo, mode=mode,
                sr=sr, cfg=cfg, verbose=verbose, provider=provider,
                use_responses_api=use_responses_api_of(cfg.models.remediate),
                primary_file=target.file)
        elif via == "cli":
            raw = _invoke_cli(
                user, cfg=cfg, repo=repo, mode=mode, sr=sr, verbose=verbose,
                tag=f"Remediation Agent remediate #{target.index}")
        else:
            # sdk/openai has no permission_mode fallback: the tools list is the only gate.
            fix_mode = mode == "fix"
            tools = [t for t in _tools(cfg) if t not in ("Edit", "Write")]
            if fix_mode:
                tools = list(dict.fromkeys([*tools, "Edit", "Write"]))
            raw = agentic(
                user,
                model=cfg.models.remediate,
                system_prompt=SYSTEM,
                allowed_tools=tools,
                cwd=str(repo),
                max_budget_usd=getattr(sr, "max_budget_usd", 10.0),
                max_turns=getattr(sr, "max_turns", 40),
                timeout=_timeout_of(sr),
                tag=f"Remediation Agent remediate #{target.index}",
                stream_cb=(stream_trace if verbose else None),
                post_scan=True,
            )
    if verbose:
        body = raw.model_dump_json() if isinstance(raw, RemediationVerdict) else str(raw)
        _dump(f"FINAL VERDICT ← finding {target.index}", body)
    return raw
