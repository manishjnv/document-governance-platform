# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Reaching the daemon, and turning its failures into messages that name the fix."""

from __future__ import annotations

import contextlib
import os
import shutil
import socket
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Final
from urllib.parse import urlsplit

import docker
from docker.constants import IS_WINDOWS_PLATFORM
from docker.context import ContextAPI
from docker.errors import APIError, DockerException, ImageNotFound
from docker.utils import parse_host
from requests.exceptions import ReadTimeout, RequestException

from vvaharness.backends.sandbox.docker import egress, evnet, policy
from vvaharness.backends.sandbox.models import SandboxUnavailableError

if TYPE_CHECKING:
    from collections.abc import Mapping

    from docker.models.images import Image

    from vvaharness.backends.sandbox.docker.models import RunPlan

#: A registry behind an authenticating proxy answers a pull with this, while the daemon itself
#: stays perfectly reachable -- so "docker is up" is not evidence the sandbox can run.
_PROXY_AUTH_STATUS = 407

#: The env var docker-py honours FIRST; with it unset, `from_env` resolves the Docker CLI
#: context instead, so locality is judged on `_effective_daemon_host`, never on this alone.
_DAEMON_HOST_ENV: Final = "DOCKER_HOST"

#: `DOCKER_HOST` schemes that can only be this machine (empty = a bare socket path; `http+unix`
#: is how docker-py's `parse_host` writes `unix://`).
_LOCAL_SCHEMES: Final[frozenset[str]] = frozenset({"", "unix", "http+unix", "npipe", "fd"})

#: Hostnames that are still this machine over a TCP or SSH transport.
_LOCAL_HOSTS: Final[frozenset[str]] = frozenset({"", "localhost", "127.0.0.1", "::1"})

#: The sidecar has one job and starts in well under a second; a longer wait means it is broken.
_READY_TIMEOUT_SECONDS: Final = 20.0
_READY_POLL_SECONDS: Final = 0.2

#: The proxy image's own entrypoint is bypassed: `policy.derive_sidecar` supplies the script
#: that runs socat and squid, so the container's whole argument set is derived in one place.
_PROXY_ENTRYPOINT: Final[tuple[str, ...]] = ("sh",)

#: What squid itself logs once it has ACCEPTED its config and opened the listener (`-d 1` puts
#: these on stderr). Two spellings because the wording changed across squid majors.
_READY_MARKERS: Final[tuple[str, ...]] = (
    "Accepting HTTP Socket connections",
    "Accepting HTTP connections",
)

#: What socat logs once the shared socket exists: without it the scan container has no way out.
_BRIDGE_READY_MARKER: Final = "listening on"

#: The socket volume lives in memory: it holds one socket, and nothing in it may outlast the run.
#: World-writable and sticky, because the sidecar's fixed uid creates the socket in it and no
#: volume root is owned by that uid.
_SOCKET_VOLUME_OPTS: Final[Mapping[str, str]] = {
    "type": "tmpfs", "device": "tmpfs", "o": "size=1m,mode=1777",
}


#: Docker Desktop only bind-mounts paths inside its File Sharing allowlist, and a path outside
#: it fails when the container starts rather than when the mount is declared. There is no API
#: to read that list, so the hint goes on the failure instead of into a preflight check.
_MACOS_SHARING_HINT = (
    "On macOS, Docker Desktop only shares paths on its File Sharing list: check "
    "Settings -> Resources -> File sharing includes the repo, the state directory, and any "
    "path passed via --config/--workspace/--scan-report."
)


def local_daemon(host: str | None) -> bool:
    """Whether *host* -- a `DOCKER_HOST` or context endpoint, None when unset -- is this machine."""
    if not host:
        return True
    # Read as docker-py reads it, so the two cannot disagree: a scheme-less `10.0.0.5:2375` has
    # no URL scheme, yet docker-py connects to it over TCP. A value it refuses (a bare socket
    # path among them, or a port that is not a number) connects nowhere at all, so it is judged
    # as written.
    with contextlib.suppress(DockerException, ValueError):
        host = parse_host(host, IS_WINDOWS_PLATFORM)
    parts = urlsplit(host)
    # Judge by hostname, which is where docker-py's TCP/HTTP(S) transport connects, so a userinfo
    # prefix (`user@`, legitimate for an `ssh://user@host` endpoint) neither redirects the
    # connection nor changes the verdict: `ssh://me@localhost` is local, `tcp://x@10.0.0.5` is
    # not. One exception: a backslash in the authority is where urlsplit and urllib3 (the
    # transport's own parser) disagree -- urlsplit reads `tcp://10.0.0.5\@127.0.0.1:2375` as host
    # `127.0.0.1` (local) while urllib3 connects to `10.0.0.5`. Refuse that mismatch as non-local
    # rather than trust the local-looking half; a real endpoint carries no backslash.
    if "\\" in parts.netloc:
        return False
    return parts.scheme in _LOCAL_SCHEMES or (parts.hostname or "") in _LOCAL_HOSTS


def _effective_daemon_host() -> str | None:
    """The daemon endpoint `from_env` will use: `DOCKER_HOST`, else the current CLI context.

    docker-py 7.2's `from_env(use_context=True)` resolves `DOCKER_CONTEXT` / `config.json`'s
    `currentContext` when `DOCKER_HOST` is unset, so the env var alone under-reports: asking
    docker-py's own resolver is what keeps this gate and the connection talking about one daemon.
    """
    host = os.environ.get(_DAEMON_HOST_ENV)
    if host:
        return host
    try:
        # docker-py's own resolver, so this gate cannot disagree with `from_env` about the host.
        resolved = ContextAPI.kwargs_from_context().get("base_url")
    except Exception:
        # Absent or malformed context files: keep the local-socket answer the env var alone
        # would have given, i.e. fall back to today's behaviour rather than refusing anything new.
        return None
    return resolved


def _require_local_daemon(*, allow_remote: bool) -> None:
    """Refuse a daemon on another machine unless the operator said it is the same one.

    Every mount in the plan is a path on THIS host, and the boundary's whole premise is that
    the container sees only what was mounted; against a remote daemon those paths either do not
    exist or, worse, name something else entirely on that machine.

    Raises:
        SandboxUnavailableError: If `DOCKER_HOST` or the current CLI context names a non-local
            daemon.
    """
    host = _effective_daemon_host()
    if allow_remote or local_daemon(host):
        return
    msg = (
        f"DOCKER_HOST/DOCKER_CONTEXT selects a daemon on another machine: {host!r}. The "
        "sandbox's mounts are paths on this one -- they would resolve against the remote "
        "host's filesystem or not at all. Unset DOCKER_HOST and `docker context use default` "
        "for the local daemon, or set sandbox.allow_remote_daemon: true if that daemon shares "
        "this filesystem."
    )
    raise SandboxUnavailableError(msg)


def connect(*, allow_remote: bool = False) -> docker.DockerClient:
    """Connect to the local Docker daemon, or raise a clear, actionable error.

    Raises:
        SandboxUnavailableError: If the daemon is not local, or none answers.
    """
    _require_local_daemon(allow_remote=allow_remote)
    client: docker.DockerClient | None = None
    try:
        client = docker.from_env()
        client.ping()
    # Not just DockerException: `from_env` resolves the CLI context, and docker-py raises a bare
    # `Exception` for a corrupt context store -- which must be a refusal, not a traceback.
    except Exception as exc:
        close(client)  # a client whose ping failed still holds a requests session
        msg = (
            f"the docker sandbox needs a reachable Docker daemon, and none answered: {exc}. "
            f"Start Docker (macOS: open -a Docker) or set sandbox.via: none to run uncontained."
        )
        raise SandboxUnavailableError(msg) from exc
    return client


def warn_weak_isolation(client: docker.DockerClient) -> None:
    """Say on stderr when this daemon or invoker confines the container less than documented.

    A warning, not a refusal: a kernel without seccomp exists, and root invokers (CI,
    Docker-in-Docker) are common. The hardening options the backend passes leave syscall
    filtering to the daemon's default profile, so an unconfined daemon voids it silently.
    """
    if hasattr(os, "getuid") and os.getuid() == 0:
        print("  WARN: sandbox: running as root, so the container runs as uid 0 and can read "
              "root-owned files in its mounts; run vvaharness as an unprivileged user.",
              file=sys.stderr)
    try:
        options = client.info().get("SecurityOptions") or []
    # Advisory only: a daemon that cannot describe itself still runs the scan it was asked to.
    except Exception:  # noqa: BLE001
        return
    seccomp = [option for option in options if "name=seccomp" in option]
    if not seccomp or any("profile=unconfined" in option for option in seccomp):
        print("  WARN: sandbox: the Docker daemon applies no seccomp profile, so the "
              "container's system calls are not filtered; run the daemon with its default "
              "profile.", file=sys.stderr)


def _pull(client: docker.DockerClient, image: str) -> Image:
    """Pull *image*, distinguishing a proxy's auth demand from a genuinely missing tag.

    Raises:
        SandboxUnavailableError: If the pull fails, naming the likely cause.
    """
    try:
        client.images.pull(image)
        return client.images.get(image)
    except APIError as exc:
        hint = (
            "the registry demanded proxy authentication (407)"
            if exc.status_code == _PROXY_AUTH_STATUS
            else f"the pull failed: {exc}"
        )
        msg = (
            f"sandbox image {image!r} is not present locally and {hint}. Build it instead: "
            f"docker build -f docker/sandbox/Dockerfile -t {image} ."
        )
        raise SandboxUnavailableError(msg) from exc


def _absent_image_msg(image: str) -> str:
    """Why an absent sandbox image is a refusal rather than a pull."""
    return (
        f"sandbox image {image!r} is not present locally, and it is never pulled implicitly: "
        f"whatever a registry answers with under that tag would then run this scan. Build it: "
        f"docker build -f docker/sandbox/Dockerfile -t {image} . -- or set "
        f"sandbox.allow_pull: true to accept a pulled image."
    )


def _pinned(resolved: Image, image: str) -> str:
    """The immutable id *image* resolved to, which is what the container is created from.

    Raises:
        SandboxUnavailableError: If the daemon reports no id. Returning the tag instead would
            silently restore the double resolution the pin exists to remove.
    """
    image_id = str(resolved.id or "")
    if not image_id:
        msg = (
            f"the docker daemon reported no image id for {image!r}, so the image that passed "
            f"preflight cannot be pinned for the run and a tag moved in between would decide "
            f"what runs. Re-tag or rebuild the image, or name it by digest in sandbox.image."
        )
        raise SandboxUnavailableError(msg)
    return image_id


def require_image(client: docker.DockerClient, image: str, *, allow_pull: bool = False) -> str:
    """Ensure *image* exists locally and return the IMMUTABLE id it resolves to.

    The id, not the tag, is what the container is then created from: a tag is mutable, and
    re-resolving it at create time can yield a different image than the one checked here. The
    default is no pull, which is also what `doctor` gets: a readiness check must report a
    missing image, never acquire one as a side effect.

    Raises:
        SandboxUnavailableError: If the image is absent, or cannot be checked or pulled.
    """
    try:
        resolved = client.images.get(image)
    except ImageNotFound as exc:
        if not allow_pull:
            raise SandboxUnavailableError(_absent_image_msg(image)) from exc
        resolved = _pull(client, image)
    except DockerException as exc:
        msg = f"docker sandbox could not check for image {image!r}: {exc}"
        raise SandboxUnavailableError(msg) from exc
    return _pinned(resolved, image)


#: Stamped by docker/sandbox/Dockerfile: "1" when the image was built with INSTALL_SEMGREP=1.
SEMGREP_IMAGE_LABEL: Final = "org.vvaharness.semgrep"


def warn_missing_semgrep(client: docker.DockerClient, image_id: str) -> None:
    """Say on stderr, before the run, when the image *image_id* was built without `semgrep`.

    A warning, not a refusal: a scan already continues without Semgrep evidence when `semgrep`
    is missing. Read off the image's label, so no container has to start to find out.
    """
    try:
        labels = client.images.get(image_id).labels or {}
    # Advisory only: an image that cannot describe itself still runs the scan it was asked to.
    except Exception:  # noqa: BLE001
        return
    if labels.get(SEMGREP_IMAGE_LABEL) == "1":
        return
    print("  WARN: sandbox: the profile loads the Semgrep plugin, but the sandbox image was "
          "built without semgrep, so this run has no Semgrep evidence and continues without "
          "it. Rebuild the image with --build-arg INSTALL_SEMGREP=1 (docker/sandbox/Dockerfile).",
          file=sys.stderr)


def require_local_image(client: docker.DockerClient, image: str) -> str:
    """The sidecar image's id, requiring it locally and NEVER pulling -- not even `allow_pull`.

    This is the sidecar's image: it sees every model request in cleartext CONNECT form, so an
    unpinned registry answer standing in for it is not a trade an operator knob may make, and
    the id is what the sidecar is then created from for the same reason as the scan image.

    Raises:
        SandboxUnavailableError: If the image is absent or cannot be checked.
    """
    try:
        resolved = client.images.get(image)
    except ImageNotFound as exc:
        msg = (
            f"the mediated-network sidecar image {image!r} is not present locally, and it is "
            f"never pulled implicitly. Build it from the repository root: "
            f"docker build -t {image} - < docker/sandbox/egress.Dockerfile"
        )
        raise SandboxUnavailableError(msg) from exc
    except DockerException as exc:
        msg = f"docker sandbox could not check for sidecar image {image!r}: {exc}"
        raise SandboxUnavailableError(msg) from exc
    return _pinned(resolved, image)


@dataclass(slots=True)
class Egress:
    """The daemon-side halves of a mediated run, so teardown can release both.

    `Any`, like `RunPlan.container_kwargs`: docker-py's model classes carry no stubs here, and
    these are opaque handles whose only use is the daemon call that releases them.
    """

    volume: Any = None
    proxy: Any = None


def _listening(container: Any, bridges: int = 1) -> bool:
    """Whether the sidecar's output says squid accepted its config and *bridges* socats listen."""
    with contextlib.suppress(DockerException, ReadTimeout):
        out = container.logs(stdout=True, stderr=True)
        text = out.decode("utf-8", "replace") if isinstance(out, bytes) else str(out)
        return (text.count(_BRIDGE_READY_MARKER) >= bridges
                and any(marker in text for marker in _READY_MARKERS))
    return False


def _await_ready(container: Any, timeout: float | None = None, bridges: int = 1) -> None:
    """Poll *container* until squid and every socat bridge report a listening socket.

    Daemon status `running` is not readiness: squid may still be parsing the generated config,
    or have refused it, and a scan started then races its own first model call.

    Raises:
        SandboxUnavailableError: If it exits, or never reports the listener.
    """
    deadline = time.monotonic() + (_READY_TIMEOUT_SECONDS if timeout is None else timeout)
    while time.monotonic() < deadline:
        container.reload()
        if _listening(container, bridges):
            return
        if getattr(container, "status", "") in ("exited", "dead"):
            break
        time.sleep(_READY_POLL_SECONDS)
    msg = (
        "the mediated-network egress proxy never reported a listening socket; the scan would "
        "have run with no reachable model endpoint. Check `docker logs` for the sidecar "
        "container -- a config squid refuses is reported there, and `socat: not found` means "
        f"the image predates the socket bridge: rebuild it with docker build -t "
        f"{egress.PROXY_IMAGE} - < docker/sandbox/egress.Dockerfile"
    )
    raise SandboxUnavailableError(msg)


def start_egress(
    client: docker.DockerClient, plan: RunPlan, *, volume_name: str, proxy_name: str,
    bridges: int = 1,
) -> Egress:
    """Create the socket volume and the proxy sidecar, and wait for the proxy to listen.

    The volume is the only thing the sidecar and the scan container share: no network joins
    them, so the scan container keeps loopback alone. The sidecar sits on the default bridge,
    its outside leg. Its whole argument set comes from *plan* (`policy.derive_sidecar`), which
    already mounts this volume, so the sidecar's hardening cannot drift from the scan
    container's. *bridges* is how many sockets it serves: the proxy's, and one per forward.

    Raises:
        SandboxUnavailableError: If either half cannot be created or the proxy never listens.
    """
    acquired = Egress()
    try:
        acquired.volume = client.volumes.create(
            volume_name, driver="local", driver_opts=dict(_SOCKET_VOLUME_OPTS),
            labels=dict(plan.labels),
        )
        acquired.proxy = client.containers.create(
            plan.image,
            name=proxy_name,
            entrypoint=list(_PROXY_ENTRYPOINT),
            **plan.container_kwargs(),
        )
        acquired.proxy.start()
        _await_ready(acquired.proxy, bridges=bridges)
    # ReadTimeout is requests', not docker-py's, and any of these calls can raise it: uncaught
    # it escapes as a bare traceback AND leaks the volume and the sidecar.
    except (DockerException, ReadTimeout) as exc:
        stop_egress(acquired)
        msg = f"the docker sandbox could not start its mediated-network egress proxy: {exc}"
        raise SandboxUnavailableError(msg) from exc
    except SandboxUnavailableError:
        # `_await_ready` already named the failure; release what was acquired and re-raise.
        stop_egress(acquired)
        raise
    except BaseException:
        # Ctrl-C or SIGTERM mid bring-up: the caller never receives *acquired*, so its
        # teardown cannot release the half-made sidecar and volume; this is the last chance.
        stop_egress(acquired)
        raise
    return acquired


#: What socat logs as it takes a connection on its listening port, the callback's included.
_ACCEPT_MARKER: Final = "accepting connection"


def check_callback(acquired: Egress, host_port: int, timeout: float = 5.0) -> None:
    """Prove the published callback port reaches the sidecar, before the scan relies on it.

    The host leg only: the listener it ends at starts with exploit verification, long after
    this, and its own self-test covers the container side. A connection accepted on the host
    is not enough -- Docker Desktop's port forwarder accepts before it reaches anything -- so
    the proof is socat in the sidecar logging the connection.

    Raises:
        SandboxUnavailableError: If the sidecar never sees the connection.
    """
    seen = _accepted(acquired.proxy)
    with contextlib.suppress(OSError), socket.create_connection(
        (evnet.HOST_LOOPBACK, host_port), timeout=timeout
    ):
        pass
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if _accepted(acquired.proxy) > seen:
            return
        time.sleep(_READY_POLL_SECONDS)
    msg = (
        f"exploit verification's callback port {evnet.HOST_LOOPBACK}:{host_port} never reached "
        f"the egress sidecar, so a target could not confirm a blind finding. Check `docker logs` "
        f"for the sidecar and that nothing else intercepts host loopback ports, or run "
        f"exploit verification under sandbox.egress: open."
    )
    raise SandboxUnavailableError(msg)


def _accepted(container: Any) -> int:
    """How many connections the sidecar's socat processes have logged taking so far."""
    with contextlib.suppress(DockerException, ReadTimeout):
        out = container.logs(stdout=True, stderr=True)
        text = out.decode("utf-8", "replace") if isinstance(out, bytes) else str(out)
        return text.count(_ACCEPT_MARKER)
    return 0


def stop_egress(acquired: Egress | None) -> None:
    """Remove the sidecar and its socket volume, in that order; a partial acquisition is expected.

    The volume goes last because Docker refuses to remove one a container still mounts; the
    scan container is already gone by the time `teardown` reaches this.
    """
    if acquired is None:
        return
    # Any requests error, a daemon gone mid-run included, not only a read timeout: one escaping
    # here would skip the rest of the caller's teardown.
    if acquired.proxy is not None:
        with contextlib.suppress(DockerException, RequestException):
            acquired.proxy.remove(force=True)
    if acquired.volume is not None:
        with contextlib.suppress(DockerException, RequestException):
            acquired.volume.remove()


def _owner_dead(labels: Mapping[str, str], host: str) -> bool:
    """Whether *labels* name an owner process on THIS machine that no longer exists.

    Every unclear case reads as alive, so a sweep can leave something behind but never remove
    a run that is still being watched: another machine's owner, an unreadable or non-positive
    pid (`kill(0)` and `kill(-1)` address process groups), a process this user may not signal
    (someone else's, alive), and Windows, where `os.kill` terminates rather than probes.
    """
    pid = labels.get(policy.OWNER_PID_LABEL, "")
    # `isdigit` refuses a sign, so a negative pid never reaches `kill`; zero is refused by name.
    if os.name == "nt" or labels.get(policy.OWNER_HOST_LABEL) != host or not pid.isdigit() or (
        int(pid) == 0
    ):
        return False
    try:
        os.kill(int(pid), 0)
    except ProcessLookupError:
        return True
    except OSError:
        pass  # PermissionError: a live process another user owns
    return False


def _conf_dirs(container: Any) -> list[Path]:
    """The generated-config directories bound into a sidecar, and nothing else.

    Only a directory with the egress prefix directly inside this machine's temp directory.
    """
    tmp = Path(tempfile.gettempdir()).resolve()
    binds = (container.attrs.get("HostConfig") or {}).get("Binds") or []
    sources = (Path(bind.split(":", 1)[0]) for bind in binds)
    return [source for source in sources
            if source.name.startswith(egress.CONF_DIR_PREFIX) and source.resolve().parent == tmp]


def _remove_orphan(container: Any) -> None:
    """Force-remove *container*, then the config directories it had bound, and say so."""
    dirs = _conf_dirs(container)
    with contextlib.suppress(DockerException, ReadTimeout):
        container.remove(force=True)
        print(f"  NOTE: sandbox: removed container {container.name}, left running by a contained "
              f"run whose process ended without cleanup "
              f"(pid {container.labels.get(policy.OWNER_PID_LABEL)}).", file=sys.stderr)
        for path in dirs:
            shutil.rmtree(path, ignore_errors=True)


def sweep_orphans(client: docker.DockerClient) -> None:
    """Remove the containers, socket volumes and config dirs of a run whose owner died.

    Teardown runs on every exit Python sees, SIGTERM included, but not on SIGKILL or a crash:
    then the scan container goes on running the scan unwatched, and the sidecar and its volume
    stay up for good. Containers first, since a volume a container mounts cannot be removed.
    Best effort, item by item: what the daemon cannot list or remove now is found again by the
    next contained run.
    """
    host = socket.gethostname()
    owned = {"label": f"{policy.OWNER_HOST_LABEL}={host}"}
    with contextlib.suppress(DockerException, ReadTimeout):
        for container in client.containers.list(all=True, filters=owned):
            if _owner_dead(container.labels, host):
                _remove_orphan(container)
    with contextlib.suppress(DockerException, ReadTimeout):
        for volume in client.volumes.list(filters=owned):
            if _owner_dead(volume.attrs.get("Labels") or {}, host):
                with contextlib.suppress(DockerException, ReadTimeout):
                    volume.remove()


def close(client: docker.DockerClient | None) -> None:
    """Release the daemon connection; docker-py leaks its requests session otherwise."""
    if client is None:
        return
    with contextlib.suppress(DockerException):
        client.close()


def run_failure(exc: DockerException) -> str:
    """The message for a failed container run, with the macOS mount hint where it applies."""
    base = f"the docker sandbox failed to run the contained invocation: {exc}"
    return f"{base}. {_MACOS_SHARING_HINT}" if sys.platform == "darwin" else base


__all__ = [
    "Egress",
    "close",
    "connect",
    "local_daemon",
    "require_image",
    "require_local_image",
    "run_failure",
    "start_egress",
    "stop_egress",
    "sweep_orphans",
    "warn_weak_isolation",
]
