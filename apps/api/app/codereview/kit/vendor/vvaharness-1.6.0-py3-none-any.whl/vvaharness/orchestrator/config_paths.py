# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""orchestrator.config_paths — see package docstring."""
from __future__ import annotations
from vvaharness.util import logs

import os
import sys
from collections.abc import Sequence
from pathlib import Path

from vvaharness.config import ConfigPolicyError, is_network_path
from vvaharness.config.constants import ALLOW_CWD_CONFIG_ENV, LOCAL_OVERLAY_NAME

# Safe at module scope: `exploit_verification/__init__` is empty, `settings` stdlib-only: no cycle
from vvaharness.exploit_verification.settings import EV_MODULES as _EV_MODULES
from vvaharness.util.events import Event
from vvaharness.util.gitindex import tracked

log = logs.get_logger(__name__)

Boundary = str | os.PathLike[str] | Sequence[str | os.PathLike[str]] | None


def _app_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _default_config(*, quiet: bool = False) -> Path:
    cwd = Path.cwd()
    cwd_cfg = cwd / "config.yaml"
    if not cwd_cfg.exists():
        return _packaged_default()
    if os.environ.get(ALLOW_CWD_CONFIG_ENV):
        return cwd_cfg
    hit = tracked(cwd, ("config.yaml", LOCAL_OVERLAY_NAME))
    if hit is False:
        return cwd_cfg
    if not quiet:
        log.warning(Event.CONFIG_TRACKED if hit else Event.CONFIG_INDEX_UNREADABLE, path=cwd_cfg)
    return _packaged_default()


def _packaged_default() -> Path:
    """The bundled default profile — the trusted fallback used when a config sourced from inside the scan target..."""
    return _app_root() / "config" / "profiles" / "default.yaml"


def _ancestor_ids(candidate: str | os.PathLike[str]) -> set[tuple[int, int]]:
    """Device and inode of `candidate` and every ancestor, lexical and resolved; a zero inode carries no identity."""
    lexical = Path(os.path.abspath(candidate))
    try:
        resolved = lexical.resolve()
    except (OSError, RuntimeError, ValueError):
        resolved = lexical
    ids: set[tuple[int, int]] = set()
    for p in {lexical, *lexical.parents, resolved, *resolved.parents}:
        try:
            st = p.stat()
        except (OSError, ValueError):
            continue
        if st.st_ino:
            ids.add((st.st_dev, st.st_ino))
    return ids


def _boundary_paths(boundary: Boundary) -> tuple[str | os.PathLike[str], ...]:
    """*boundary* as a tuple of paths: one path, a collection of paths, or None (no target)."""
    return (boundary,) if isinstance(boundary, (str, os.PathLike)) else tuple(boundary or ())


def _containing_boundary(candidate: str | os.PathLike[str], boundary: Boundary) -> Path | None:
    """The first boundary that holds `candidate`, by resolved path and then by inode identity, else None."""
    paths = _boundary_paths(boundary)
    try:
        cand = Path(candidate).resolve()
    except (OSError, RuntimeError, ValueError):
        return None
    ids: set[tuple[int, int]] | None = None
    for b in map(Path, paths):
        try:
            base = b.resolve()
        except (OSError, RuntimeError, ValueError):
            continue
        if cand.is_relative_to(base):
            return b
        # resolve() does not case-normalise (APFS/NTFS): `--repo /x/REPO` must still contain /x/Repo/.env
        try:
            st = base.stat()
        except (OSError, ValueError):
            continue
        if not st.st_ino:
            continue
        if ids is None:
            ids = _ancestor_ids(candidate)
        if (st.st_dev, st.st_ino) in ids:
            return b
    return None


def _path_within(candidate, root: Boundary) -> bool:
    """True if `candidate` resolves at or under `root` (one path or several); see `_containing_boundary`."""
    return _containing_boundary(candidate, root) is not None


def _through_target_symlink(written: Path, boundary: Boundary) -> bool:
    """True if reaching *written* follows a symlink that sits inside *boundary*.

    `<repo>/dirlink/p.yaml` with `dirlink -> outside/` reads a file outside the target, but the
    target chose which. Climbing out with `..` (`<repo>/../ops/p.yaml`) follows nothing it planted.
    """
    step = Path(written.anchor)
    for part in written.parts[1:]:
        step = step / part
        if os.path.islink(step) and _path_within(step.parent, boundary):
            return True
    return False


def _refuse_config(candidate: str | Path, label: str, where: str, *,
                   quiet: bool = False) -> str:
    """Report the refusal and return the trusted fallback every caller degrades to."""
    if not quiet:
        print(f"  WARN: {label}: ignoring config {where} "
              f"({candidate}) — attacker-influenced; using the packaged "
              f"default. Set VVAHARNESS_ALLOW_CWD_CONFIG=1 in the process environment "
              f"to override.",
              file=sys.stderr)
    return str(_packaged_default())


def trusted_config(config: str, boundary: Boundary, *,
                   explicit: bool, quiet: bool = False, label: str = "config") -> str:
    """Refuse an attacker-influenceable ``--config``, over two anchors, failing closed.

    The scan target (``--repo``) is untrusted, so a config it can author must not steer the run.
    This is the single gate every entry point shares (scan/remediate/validate/ev-replay/doctor
    and the containment decision). *boundary* is one target or a collection of them (a
    ``--repo-file`` batch); the checks below apply to each:

    * **Inside the target** — a config resolving at/under *boundary*, OR whose own directory
      (where its NAME sits, so a symlink planted in a hostile tree still anchors where it was
      dropped) sits inside it, OR whose path follows a symlink inside it. When the operator
      TYPED ``--config`` (*explicit*) this is a hard refusal (``ConfigPolicyError`` → exit 2): a
      named config that still points into the target is a mistake worth stopping on. An auto-discovered one degrades to the packaged default
      with a warning.
    * **Above the target** — a config whose directory CONTAINS the target: one hostile clone
      holding both the config and the code delivers that with no flag at all, so an
      auto-discovered one is refused (fallback to default). An explicit one is kept with a
      warning, since operator intent is the only thing that separates the two.

    ``VVAHARNESS_ALLOW_CWD_CONFIG`` is the operator's HOST-side escape hatch; the containment
    gate strips it from the env that crosses into a contained run, so it cannot re-open target
    trust there. *quiet* suppresses the message only, never a refusal (a second reader of an
    already-reported decision, e.g. manifest capture).
    """
    targets = tuple(map(Path, _boundary_paths(boundary)))
    if not targets or os.environ.get(ALLOW_CWD_CONFIG_ENV):
        return str(config)
    # Where the config's NAME sits (final component NOT followed) and where its content lives.
    written = Path(config).expanduser().absolute()
    link_dir = written.parent
    real_dir = Path(config).resolve().parent
    matched = (_containing_boundary(config, targets) or _containing_boundary(link_dir, targets)
               or next((t for t in targets if _through_target_symlink(written, t)), None))
    if matched is not None:
        if explicit:
            raise ConfigPolicyError(
                f"--config {config} resolves inside the scan target ({matched}), or is "
                f"reached through it — attacker-influenced; refusing. Point --config outside "
                f"the target, or set VVAHARNESS_ALLOW_CWD_CONFIG=1 in the process "
                f"environment to override.")
        if not quiet:
            log.warning(Event.CONFIG_INSIDE_TARGET, path=config, target=matched,
                        override="VVAHARNESS_ALLOW_CWD_CONFIG=1")
        return str(_packaged_default())
    above = next((t for t in targets
                  if _path_within(t, link_dir) or _path_within(t, real_dir)), None)
    if above is None:
        return str(config)
    if not explicit:
        return _refuse_config(config, label,
                              "whose directory holds the scan target", quiet=quiet)
    if not quiet:
        print(f"  WARN: {label}: --config {config} sits above the scan target "
              f"({above}); whatever can write that directory steers this run.",
              file=sys.stderr)
    return str(config)


def trusted_config_path(candidate: str | Path, repo: str | Path | None, *,
                        label: str = "config", explicit: bool = False,
                        quiet: bool = False) -> str:
    """Alias of :func:`trusted_config` under the containment gate's parameter names.

    Kept so the sandbox gate and the subcommands share one implementation; see
    :func:`trusted_config` for the policy.
    """
    return trusted_config(candidate, repo, explicit=explicit, quiet=quiet, label=label)


def _resolve_against(base: Path, p: str) -> str:
    # Refuse UNC before any is_file()/read: on Windows that leaks NTLM over SMB; raw AND joined path
    if is_network_path(p):
        raise ValueError(
            f"refusing network/UNC input path {p!r} "
            f"(reading it could leak credentials over SMB)")
    pp = Path(p)
    resolved = pp if pp.is_absolute() else (base / pp)
    if is_network_path(resolved):
        raise ValueError(
            f"refusing network/UNC input path {str(resolved)!r} "
            f"(reading it could leak credentials over SMB)")
    return str(resolved)


# The single definition: doctor (util.environment) imports it; its old copy had drifted
_MODEL_ROLES = ("graph_annotate", "callgraph_creation", "autoexclude",
                "preprocess", "threatmodel", "decompose", "deepdive", "verify",
                "dedup", "chain", "remediate", "validate", "exploit_verification")

# Legacy S0 roles, probed only under step0.callgraph_detection: llm; a rules-mode cred check breaks
_CALLGRAPH_ROLES = frozenset({"graph_annotate", "callgraph_creation"})


def _callgraph_llm_selected(cfg) -> bool:
    """True when ``step0.callgraph_detection`` selects the LLM annotator."""
    # Anything but exactly ``llm`` makes the annotator model dead config: do not preflight it
    step0 = getattr(cfg, "step0", None)
    mode = str(getattr(step0, "callgraph_detection", "rules")
               or "rules").strip().lower()
    return mode == "llm"


#: Roles whose config is a MAP of sub-roles; ``validate``: orchestrator only, EV: every sub-role
_SUB_ROLES: dict[str, tuple[str, ...]] = {
    "validate": ("orchestrator",),
    "exploit_verification": _EV_MODULES,
}

#: Derived from the map above so the two cannot drift. Callers that must exclude EV filter on these.
EV_MODEL_ROLES: tuple[str, ...] = tuple(
    f"exploit_verification.{s}" for s in _SUB_ROLES["exploit_verification"])

def _iter_model_roles(cfg):
    """Yield ``(role, model_cfg_node)`` for every configured, ACTIVE model role.

    Skips the S0 callgraph roles unless ``step0.callgraph_detection: llm``, so
    preflight/doctor only ever probe models a scan under this config could
    actually call: in rules mode those roles are dead config and probing them
    would fail a profile that scans fine.
    """
    # A config with no `models:` block has no roles -- `Config.__getattr__` raises for it, and
    # doctor must report that as a config problem, not traceback out of this loop.
    models = getattr(cfg, "models", None)
    if models is None:
        return
    for r in _MODEL_ROLES:
        if r in _CALLGRAPH_ROLES and not _callgraph_llm_selected(cfg):
            continue
        m = getattr(models, r, None)
        if m is None:
            continue
        subs = _SUB_ROLES.get(r)
        if subs is None:
            yield r, m
            continue
        for sub in subs:
            node = getattr(m, sub, None)
            # Absent sub-roles are optional by design; demanding a credential would fail the scan
            if node is None:
                continue
            # `validate` reports under its own name: `llm.POST_SCAN_ROLES` matches no sub-role name
            yield (r if len(subs) == 1 else f"{r}.{sub}"), node


#: Step roles with a configured effort tier; mirrors manifest._ROLE_EFFORT_STEP.
ROLE_EFFORT_KEY: dict[str, tuple[str, str]] = {
    "autoexclude": ("step1", "auto_exclude_effort"),
    "threatmodel": ("step2", "effort"),
    "deepdive": ("step4", "effort"),
    "verify": ("step6_verify", "effort"),
    "dedup": ("step7_dedup", "effort"),
    "chain": ("step8", "effort"),
    "validate": ("step_validate", "effort"),
}


def role_effort(cfg: object, role: str) -> str | None:
    """The effort tier driving *role*'s calls, or None when *role* has none."""
    # EV sub-roles are dotted ("exploit_verification.<sub>"); their tier lives under its own key
    if role.startswith("exploit_verification."):
        from vvaharness.exploit_verification.settings import ev_effort
        return ev_effort(cfg, role.split(".", 1)[1])
    from vvaharness.util.config import knob
    if role == "preprocess":
        # Shares autoexclude's model, and its effort, only when models.autoexclude is unset
        # (s1_autoexclude.py:562); decompose and remediate have no effort key at all.
        if getattr(getattr(cfg, "models", None), "autoexclude", None) is not None:
            return None
        return knob(cfg, "step1.auto_exclude_effort", None) or None
    knob_path = ROLE_EFFORT_KEY.get(role)
    if knob_path is None:
        return None
    return knob(cfg, ".".join(knob_path), None) or None


def highest_effort(tiers) -> str | None:
    """The highest tier in *tiers*, ordered by EFFORT_TIME_FACTOR's REQUEST order; None/unknown ignored."""
    # Lazy: config_paths loads at import time (util/environment.py:40); backends.llm drags in
    # the whole backends.harness package, which this module must not pull in at import time.
    from vvaharness.backends.llm.models import EFFORT_TIME_FACTOR, ClockKind
    order = list(EFFORT_TIME_FACTOR[ClockKind.REQUEST])
    best_rank = -1
    best: str | None = None
    for tier in tiers:
        if tier is None:
            continue
        try:
            rank = order.index(tier)
        except ValueError:
            continue
        if rank > best_rank:
            best_rank = rank
            best = str(tier)
    return best
