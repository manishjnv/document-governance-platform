# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deterministic ContextPackage field producers over the built graph."""
from __future__ import annotations

from dataclasses import replace

from vvaharness.codegraph.handle import GraphHandle
from vvaharness.context_graph_sdk import FrozenMap, QueryLimits
from vvaharness.context_graph_sdk.query.contracts import MAX_QUERY_BYTES
from vvaharness.util import logs

log = logs.get_logger(__name__)

_COMMUNITY_FILES_QUERY = """
MATCH (fn)-[:MEMBER_OF]->(c:Community)
MATCH (file:File)-[:DEFINES]->(fn)
RETURN DISTINCT c.name AS community, file.filePath AS path
ORDER BY community, path
SKIP $skip LIMIT $limit
"""
#: Rows per page; a single query at the SDK's 1,000-row default would truncate a large graph's map
_COMMUNITY_FILES_PAGE_ROWS = 10_000

_LANGUAGE_COUNTS_QUERY = """
MATCH (f:File)
WHERE f.language IS NOT NULL AND f.language <> ''
RETURN f.language AS language, count(*) AS n
ORDER BY n DESC
"""

_COUNT_QUERIES = {
    "files": "MATCH (f:File) RETURN count(f) AS n",
    "functions": "MATCH (fn:Function) RETURN count(fn) AS n",
    "communities": "MATCH (c:Community) RETURN count(c) AS n",
}


def _community_files_page(handle: GraphHandle, limits: QueryLimits,
                          skip: int) -> tuple[FrozenMap, ...]:
    """One page of (community, path) rows; a page cut short by a query bound raises."""
    params = {"skip": skip, "limit": _COMMUNITY_FILES_PAGE_ROWS}
    result = handle.graph.cypher(_COMMUNITY_FILES_QUERY, params, limits)
    # A page over the byte bound usually surfaces as the SDK's QueryResourceLimitError instead:
    # the worker checks the encoded response against the same 16 MiB cap before this flag
    if result.truncated:
        raise RuntimeError(f"community/file page exceeded the {result.truncation_reason} "
                           "query bound; scope the scan with --repo <subdir>")
    return result.rows


def communities_as_modules(handle: GraphHandle) -> dict[str, list[str]]:
    """Community name -> its member functions' file paths (graph-relative, deduped)."""
    limits = replace(handle.workspace.default_query_limits,
                     row_limit=_COMMUNITY_FILES_PAGE_ROWS, byte_limit=MAX_QUERY_BYTES)
    modules: dict[str, list[str]] = {}
    # No page cap: the walk ends at the graph's last pair, so its size never fails the scan
    skip = 0
    while True:
        rows = _community_files_page(handle, limits, skip)
        for row in rows:
            values = row.to_dict()
            name, path = values.get("community"), values.get("path")
            if isinstance(name, str) and isinstance(path, str):
                modules.setdefault(name, []).append(path)
        if len(rows) < _COMMUNITY_FILES_PAGE_ROWS:
            return modules
        skip += _COMMUNITY_FILES_PAGE_ROWS


def primary_language(handle: GraphHandle) -> str | None:
    """The most common non-empty ``File.language`` value, or ``None`` on an empty graph."""
    rows = handle.graph.cypher(_LANGUAGE_COUNTS_QUERY).rows
    if not rows:
        return None
    language = rows[0].to_dict().get("language")
    return language if isinstance(language, str) else None


def _int_count(handle: GraphHandle, query: str) -> int:
    rows = handle.graph.cypher(query).rows
    if not rows:
        return 0
    n = rows[0].to_dict().get("n")
    return n if isinstance(n, int) else 0


def system_context_notes(handle: GraphHandle) -> str:
    """One-line, deterministic summary of the graph's shape — the v1.5 ``system_context`` trick."""
    counts = {key: _int_count(handle, query) for key, query in _COUNT_QUERIES.items()}
    languages = [
        lang for r in handle.graph.cypher(_LANGUAGE_COUNTS_QUERY).rows
        if isinstance(lang := r.to_dict().get("language"), str)
    ]
    lang_str = ", ".join(languages[:5]) or "unknown"
    return (f"{counts['files']} files ({lang_str}), "
            f"{counts['functions']} functions, "
            f"{counts['communities']} communities.")
