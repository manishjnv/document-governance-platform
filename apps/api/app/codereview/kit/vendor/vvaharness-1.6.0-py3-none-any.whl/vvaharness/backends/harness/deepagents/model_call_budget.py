# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Middleware that caps model calls per session and forces the verdict on the last one."""

from __future__ import annotations

import threading
from collections.abc import Awaitable, Callable

from langchain.agents.middleware.types import AgentMiddleware, ModelRequest, ModelResponse
from langchain_core.messages import HumanMessage

from vvaharness.backends.harness.deepagents.evidence_gate import EvidenceGate
from vvaharness.backends.harness.models import ModelCallBudgetExhaustedError
from vvaharness.util.counters import COUNTERS


def _final_turn_notice(limit: int) -> HumanMessage:
    """The turn appended when the budget leaves room for the verdict and nothing else."""
    return HumanMessage(content=(
        f"FINAL TURN. You have used your {limit} model calls for this unit, and every tool "
        "except the outcome report has been withdrawn — no further Read, Grep, execute or "
        "graph call will run.\n\n"
        "Report the outcome object NOW from the evidence you already hold. Findings you have "
        "confirmed are kept; do not discard them because you wanted one more lookup. If a "
        "question stayed open, say so in the rationale and set the verdict accordingly — "
        "`inconclusive` is honest, silence is not."
    ))


def _evidence_turn_notice(pending: frozenset[str]) -> HumanMessage:
    """The turn appended when the budget defers its final turn for the evidence gate."""
    return HumanMessage(content=(
        "ONE CALL BEFORE YOUR FINAL TURN. Your model-call budget is spent, but your verdict "
        "still needs call-graph evidence and you have not called any of "
        + ", ".join(sorted(pending))
        + ". Every other tool has been withdrawn. Call one of them now on the file or function "
        "your verdict depends on most; the next call is your final turn, which keeps only the "
        "outcome report."
    ))


class ModelCallBudget(AgentMiddleware):
    """Cap model calls per session, reserving the last one for the verdict.

    With an *evidence_gate* whose required tools are still uncalled, the call that would be the
    final turn becomes an evidence turn instead -- only those tools and the outcome stay bound --
    and the final turn follows it, so the gate can still be satisfied: one extra call, once.
    """
    # KNOWN RESIDUAL: CapOutputTokens' doubled retry is one uncounted call; only S4 raises VVAH-E007
    # The gate sits inside this budget, so its re-asks go uncounted too (max_rejections at most)

    def __init__(self, *, limit: int, outcome_tools: frozenset[str],
                 counter: str = "model_call_budget_final_turn",
                 raise_when_exhausted: bool = False, stage: str = "",
                 evidence_gate: EvidenceGate | None = None,
                 evidence_counter: str = "model_call_budget_evidence_turn") -> None:
        """Allow *limit* model calls, keeping only *outcome_tools* bound on the last."""
        super().__init__()
        self._limit = max(1, int(limit))
        self._outcome = outcome_tools
        self._counter = counter
        self._calls = 0
        self._lock = threading.Lock()
        self._raise_when_exhausted = raise_when_exhausted
        self._stage = stage
        self._final_turn_issued = False
        self._gate = evidence_gate
        self._evidence_counter = evidence_counter
        self._evidence_turn_issued = False

    @property
    def name(self) -> str:
        """Per-instance name; langchain asserts middleware names are unique per agent."""
        return f"{self.__class__.__name__}[{self._counter}]"

    def _claim(self) -> bool:
        """Count this call, returning whether it is the last permitted one."""
        with self._lock:
            self._calls += 1
            return self._calls >= self._limit

    def grant_resume_turn(self) -> None:
        """Make a deadline resume's next call the forced final turn again, instead of VVAH-E007."""
        with self._lock:
            if not self._final_turn_issued:
                return
            self._final_turn_issued = False
            self._calls = self._limit - 1

    def _final(self, request: ModelRequest) -> ModelRequest:
        """*request* with every tool but the outcome withdrawn, plus the notice."""
        kept = [t for t in (request.tools or []) if getattr(t, "name", None) in self._outcome]
        COUNTERS.bump(self._counter)
        return request.override(tools=kept,
                                messages=[*request.messages, _final_turn_notice(self._limit)])

    def _evidence_turn(self, request: ModelRequest) -> ModelRequest | None:
        """*request* narrowed to the gate's pending tools plus the outcome, once; else None."""
        pending = self._gate.pending_tools() if self._gate is not None else frozenset()
        keep = pending | self._outcome
        kept = [t for t in (request.tools or []) if getattr(t, "name", None) in keep]
        if self._evidence_turn_issued or not any(
                getattr(t, "name", None) in pending for t in kept):
            return None
        self._evidence_turn_issued = True
        COUNTERS.bump(self._evidence_counter)
        return request.override(tools=kept,
                                messages=[*request.messages, _evidence_turn_notice(pending)])

    def _spend(self, request: ModelRequest) -> ModelRequest:
        """Count one call; *request* as the evidence or final turn when it is the last."""
        self._check_exhausted()
        if not self._claim():
            return request
        evidence = self._evidence_turn(request)
        if evidence is not None:
            return evidence
        self._final_turn_issued = True
        return self._final(request)

    def _check_exhausted(self) -> None:
        """Raise VVAH-E007 once the forced final turn still didn't end the session."""
        # A caller that never opted in falls through as a no-op.
        if self._raise_when_exhausted and self._final_turn_issued:
            raise ModelCallBudgetExhaustedError(
                "the forced final turn (every tool but the outcome withdrawn) "
                "still did not end the session on the outcome tool",
                stage=self._stage, limit=self._limit)

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        """Spend one call from the budget, demanding the verdict once it is the last."""
        return handler(self._spend(request))

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelResponse:
        """Async counterpart of :meth:`wrap_model_call`."""
        return await handler(self._spend(request))
