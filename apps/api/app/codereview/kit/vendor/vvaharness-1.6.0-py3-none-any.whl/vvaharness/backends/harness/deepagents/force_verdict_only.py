# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Middleware that forces the structured-output tool only for the call that ends a session."""

from __future__ import annotations

import threading
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, cast

from langchain.agents.middleware.types import (
    AgentMiddleware,
    ExtendedModelResponse,
    ModelCallResult,
    ModelRequest,
    ModelResponse,
)
from langchain.agents.structured_output import ToolStrategy
from langchain_core.messages import AIMessage, HumanMessage

from vvaharness.backends.harness.deepagents.tool_choice_rejection import (
    UNSUPPORTED_MODELS,
    is_tool_choice_unsupported_rejection,
    learn_tool_choice_unsupported,
)
from vvaharness.util.counters import COUNTERS

if TYPE_CHECKING:
    # Typing only: importing options.* here would cycle through options/streaming.py.
    from vvaharness.backends.harness.deepagents.options.forcing import ForcingChatAnthropic

#: Bumped once per session end the middleware turned into a forced outcome call.
FORCED_VERDICT_COUNTER = "deepagents_verdict_forced_after_auto"

#: Bumped when a rejecter exhausted every re-ask below and still never called the outcome tool.
DECLINED_AFTER_REASKS_COUNTER = "deepagents_verdict_declined_after_reasks"

#: Hard cap on re-asking a rejecter's outcome call after it ends on prose. A rejecter can
#: never be forced at the API level (it 400s), so this is the only lever to raise its
#: completion rate -- kept a small fixed constant, not a loop that runs until it complies, so
#: a model that keeps declining still ends the session instead of recreating an
#: unbounded tool-calling loop. Each attempt withdraws every regular tool, so
#: there is nothing left to loop on even at the cap.
_MAX_OUTCOME_REASKS = 2


def _report_now(tool_names: list[str], *, final: bool = False) -> HumanMessage:
    """The turn appended when the model stopped working without reporting its outcome."""
    names = " or ".join(f"`{n}`" for n in tool_names) or "the outcome tool"
    last_chance = " This is the last chance to do so." if final else ""
    return HumanMessage(content=(
        f"You have finished working. Report your outcome NOW by calling {names} with the "
        f"conclusion you just reached. Every other tool has been withdrawn.{last_chance}"
    ))


def _forcing(request: ModelRequest) -> ForcingChatAnthropic:
    """*request*'s model, which ``ForceVerdictOnly._applies`` checked is a ForcingChatAnthropic."""
    return cast("ForcingChatAnthropic", request.model)


def _reply(result: ModelCallResult) -> AIMessage | None:
    """The AI message a ``wrap_model_call`` handler's result ends on, if any."""
    if isinstance(result, ExtendedModelResponse):
        result = result.model_response
    messages = result.result if isinstance(result, ModelResponse) else [result]
    last = messages[-1] if messages else None
    return last if isinstance(last, AIMessage) else None


class ForceVerdictOnly(AgentMiddleware):
    """Leave tool_choice on auto while the session works; force the outcome tool only to end it.

    A model that rejects the forcing with a 400 is learned and its outcome call re-issued on
    auto in the same session, with only the outcome tool offered, instead of the client
    re-running the whole session.

    *unforceable_only* limits it to models in the rejecter set, the only ones that can end a
    session on prose without it; every other model's calls pass through untouched.
    """
    # The forced outcome call is one extra model call an outer ModelCallBudget does not count

    def __init__(self, *, unforceable_only: bool = False) -> None:
        """Start with no auto-binding model copies; one is made per model on first use."""
        super().__init__()
        self._unforceable_only = unforceable_only
        self._auto: dict[int, ForcingChatAnthropic] = {}
        self._lock = threading.Lock()

    def _auto_model(self, model: ForcingChatAnthropic) -> ForcingChatAnthropic:
        """*model*, copied once to bind tool_choice as auto."""
        with self._lock:
            copy = self._auto.get(id(model))
            if copy is None:
                copy = self._auto[id(model)] = model.model_copy(update={"force_tool_choice": False})
            return copy

    def _applies(self, request: ModelRequest) -> bool:
        """Whether *request* forces an outcome on a model that can bind auto."""
        # Duck-typed on ForcingChatAnthropic.force_tool_choice, for the import cycle above
        return (isinstance(request.response_format, ToolStrategy)
                and getattr(request.model, "force_tool_choice", None) is True
                and (not self._unforceable_only
                     or _forcing(request).model in UNSUPPORTED_MODELS))

    def _unforced(self, request: ModelRequest) -> ModelRequest:
        """*request* on the auto-binding copy of its model."""
        return request.override(model=self._auto_model(_forcing(request)))

    def _learn_rejection(self, request: ModelRequest, exc: Exception) -> bool:
        """Learn *request*'s model when *exc* is its forced-tool_choice 400; True to re-issue."""
        if not is_tool_choice_unsupported_rejection(exc):
            return False
        learn_tool_choice_unsupported(_forcing(request).model)
        return True

    @staticmethod
    def _forced(request: ModelRequest, reply: AIMessage, *, final: bool = False) -> ModelRequest:
        """*request* re-issued after *reply* with only the outcome tool, which langchain forces."""
        strategy = request.response_format
        names = [spec.name for spec in strategy.schema_specs] if isinstance(
            strategy, ToolStrategy) else []
        COUNTERS.bump(FORCED_VERDICT_COUNTER)
        return request.override(
            tools=[],
            messages=[*request.messages, reply, _report_now(names, final=final)])

    def _auto_outcome(
        self, request: ModelRequest, handler: Callable[[ModelRequest], ModelCallResult],
    ) -> ModelCallResult:
        """The outcome-only *request* on auto, re-asked up to `_MAX_OUTCOME_REASKS` times."""
        unforced = self._unforced(request)
        result = handler(unforced)
        reply = _reply(result)
        attempt = 0
        while reply is not None and not reply.tool_calls and attempt < _MAX_OUTCOME_REASKS:
            unforced = self._forced(unforced, reply, final=attempt == _MAX_OUTCOME_REASKS - 1)
            result = handler(unforced)
            reply = _reply(result)
            attempt += 1
        if reply is not None and not reply.tool_calls:
            COUNTERS.bump(DECLINED_AFTER_REASKS_COUNTER)
        return result

    async def _aauto_outcome(
        self, request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelCallResult]],
    ) -> ModelCallResult:
        """Async counterpart of :meth:`_auto_outcome`."""
        unforced = self._unforced(request)
        result = await handler(unforced)
        reply = _reply(result)
        attempt = 0
        while reply is not None and not reply.tool_calls and attempt < _MAX_OUTCOME_REASKS:
            unforced = self._forced(unforced, reply, final=attempt == _MAX_OUTCOME_REASKS - 1)
            result = await handler(unforced)
            reply = _reply(result)
            attempt += 1
        if reply is not None and not reply.tool_calls:
            COUNTERS.bump(DECLINED_AFTER_REASKS_COUNTER)
        return result

    def _force(
        self, request: ModelRequest, handler: Callable[[ModelRequest], ModelCallResult],
    ) -> ModelCallResult:
        """Run the outcome-only *request* forced, or on auto for a model that rejects forcing."""
        if _forcing(request).model in UNSUPPORTED_MODELS:
            return self._auto_outcome(request, handler)
        try:
            return handler(request)
        except Exception as exc:
            if not self._learn_rejection(request, exc):
                raise
        return self._auto_outcome(request, handler)

    async def _aforce(
        self, request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelCallResult]],
    ) -> ModelCallResult:
        """Async counterpart of :meth:`_force`."""
        if _forcing(request).model in UNSUPPORTED_MODELS:
            return await self._aauto_outcome(request, handler)
        try:
            return await handler(request)
        except Exception as exc:
            if not self._learn_rejection(request, exc):
                raise
        return await self._aauto_outcome(request, handler)

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelCallResult],
    ) -> ModelCallResult:
        """Run the call on auto; if it ends the session without an outcome, force one."""
        if not self._applies(request):
            return handler(request)
        # No regular tools: already outcome-only (ModelCallBudget's final turn), forced as it is
        if request.tools:
            result = handler(self._unforced(request))
            reply = _reply(result)
            if reply is None or reply.tool_calls:
                return result
            request = self._forced(request, reply)
        return self._force(request, handler)

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelCallResult]],
    ) -> ModelCallResult:
        """Async counterpart of :meth:`wrap_model_call`."""
        if not self._applies(request):
            return await handler(request)
        if request.tools:
            result = await handler(self._unforced(request))
            reply = _reply(result)
            if reply is None or reply.tool_calls:
                return result
            request = self._forced(request, reply)
        return await self._aforce(request, handler)
