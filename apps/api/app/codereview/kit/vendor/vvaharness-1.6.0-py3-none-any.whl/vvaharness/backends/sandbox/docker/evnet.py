# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""What exploit verification needs from the daemon: the host's address, and a published port.

Both must be known before the container is created -- its environment and port map are fixed
there -- so neither can be read off the running container.
"""

from __future__ import annotations

import contextlib
import socket
from typing import TYPE_CHECKING, Final

from vvaharness.backends.sandbox.docker.models import EVNetwork
from vvaharness.backends.sandbox.models import (
    EV_CALLBACK_PORT,
    EV_HOST_GATEWAY_ENV,
    SandboxUnavailableError,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    import docker

#: The name Docker resolves to the host: automatic on Docker Desktop, via the alias below on
#: Linux Engine. Documented on Linux, macOS and Windows alike, which host networking is not.
HOST_GATEWAY_NAME: Final = "host.docker.internal"
#: Docker's own alias for "the host this container's gateway points back to" (Docker >= 20.10).
HOST_GATEWAY_ALIAS: Final = "host-gateway"

#: The container-side port the OOB listener binds (`models.EV_CALLBACK_PORT`).
CONTAINER_OOB_PORT: Final = EV_CALLBACK_PORT
#: The listener must answer on the published interface, not only the container's loopback.
OOB_BIND_ALL: Final = "0.0.0.0"  # noqa: S104 — in-container bind, published to host loopback only
#: The published port is bound on host loopback only, so nothing off-box reaches the callback.
HOST_LOOPBACK: Final = "127.0.0.1"

#: Enough tries to ride out a machine churning through loopback ports, few enough that a host
#: with no free port left refuses instead of spinning.
_PORT_ATTEMPTS: Final = 8

#: Asked of a throwaway container, because the address `host.docker.internal` resolves to is
#: NOT the bridge network's IPAM gateway on Docker Desktop, and `safety.check_allowed` accepts
#: the forced ADDRESS -- so a guessed one fails closed with a confusing refusal.
#: `ahosts`, not `hosts`: Docker Desktop writes both an IPv4 and an (unroutable-to-host) IPv6
#: record for the gateway name; `ahosts` filters to the families the container can actually use
#: and returns the reachable IPv4 first, so `text.split()[0]` picks a gateway that connects.
_PROBE: Final[tuple[str, ...]] = ("getent", "ahosts", HOST_GATEWAY_NAME)


def _bindable(port: int) -> bool:
    """Whether *port* is still free now that the socket that picked it has been released."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind((HOST_LOOPBACK, port))
    except OSError:
        return False
    return True


def reserve_host_port(attempts: int = _PORT_ATTEMPTS) -> int:
    """An unused host-loopback port to publish the OOB listener on.

    Bound and released rather than left to Docker's own ephemeral choice: `EV_OOB_URL` must
    name the published port in the container's environment, which is fixed at create time.
    Two concurrent contained runs therefore never advertise the same port. The port is free
    again between here and `containers.create`, so it is re-checked and the race retried --
    losing it surfaces at create time as an opaque failure that names no port at all.

    Raises:
        SandboxUnavailableError: If every attempt lost the port to something else.
    """
    for _ in range(attempts):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind((HOST_LOOPBACK, 0))
            port = int(sock.getsockname()[1])
        if _bindable(port):
            return port
    msg = (
        f"exploit verification needs a free port on {HOST_LOOPBACK} to publish its callback "
        f"listener on, and {attempts} reserved ports were each taken by another process before "
        f"the container could be created. Re-run, or unset EV_API_COLLECTION to run SAST-only."
    )
    raise SandboxUnavailableError(msg)


def _probed_gateway(client: docker.DockerClient, image: str,
                    labels: Mapping[str, str] | None = None) -> str:
    """The address the real container will see for `host.docker.internal`, or `""`.

    `entrypoint=""` because the sandbox image's ENTRYPOINT is `python3 -m vvaharness`. It only
    reads /etc/hosts, so it runs as unprivileged as the scan container: the image bakes no
    `USER`, and without these it would run as root with every default capability. *labels* are
    the run's owner labels, so a probe that leaks (the host killed before `remove=True` fires)
    is found by `sweep_orphans` like any other container this run started.
    """
    from docker.errors import DockerException  # noqa: PLC0415 — lazy: optional extra

    with contextlib.suppress(DockerException, ValueError, IndexError):
        out = client.containers.run(
            image,
            list(_PROBE),
            entrypoint="",
            network_mode="bridge",
            extra_hosts={HOST_GATEWAY_NAME: HOST_GATEWAY_ALIAS},
            user="65534:65534",
            cap_drop=["ALL"],
            security_opt=["no-new-privileges:true"],
            read_only=True,
            remove=True,
            labels=dict(labels or {}),
        )
        text = out.decode("utf-8", "replace") if isinstance(out, bytes) else str(out)
        return text.split()[0]
    return ""


def _ipam_gateway(client: docker.DockerClient) -> str:
    """The default bridge network's declared gateway, or `""`. The fallback, never the only try."""
    from docker.errors import DockerException  # noqa: PLC0415 — lazy: optional extra

    with contextlib.suppress(DockerException, KeyError, TypeError):
        for config in client.networks.get("bridge").attrs["IPAM"]["Config"] or ():
            gateway = str(config.get("Gateway") or "")
            if gateway:
                return gateway
    return ""


def plan(client: docker.DockerClient, image: str,
         labels: Mapping[str, str] | None = None) -> EVNetwork:
    """Everything an `ev-bridge` run needs from the daemon, queried before any container exists.

    Both addresses are forwarded (comma-separated, most authoritative first) because the two
    sources disagree on Docker Desktop and `safety.host_gateways` accepts a pair. *labels* are
    the run's owner labels, carried onto the gateway probe so a leaked one is sweepable.

    Raises:
        SandboxUnavailableError: If the daemon reports no route back to this machine, which
            makes a contained EV run unable to reach a host-run target.
    """
    found = [addr for addr in (_probed_gateway(client, image, labels), _ipam_gateway(client))
             if addr]
    if not found:
        msg = (
            "exploit verification needs the address this machine is reachable at from inside a "
            "container, and the docker daemon reported none. Check `docker network inspect "
            "bridge`, or unset EV_API_COLLECTION to run SAST-only."
        )
        raise SandboxUnavailableError(msg)
    return EVNetwork(
        gateway=",".join(dict.fromkeys(found)),
        container_port=CONTAINER_OOB_PORT,
        host_port=reserve_host_port(),
        host_ip=HOST_LOOPBACK,
    )


def forced_env(ev: EVNetwork | None) -> dict[str, str]:
    """The EV settings that must describe the CONTAINER, applied after the caller's env.

    Empty for a non-EV run. `EV_TARGET_URL` is deliberately absent: exploit verification
    rewrites a loopback target in-container (`options._contained_target`) from the same forced
    gateway, so the two cannot disagree. The EV input paths are remapped with every other
    host-path value, under any egress (`remap.filter_env`).
    """
    if ev is None:
        return {}
    return {
        EV_HOST_GATEWAY_ENV: ev.gateway,
        "EV_OOB_BIND": OOB_BIND_ALL,
        "EV_OOB_PORT": str(ev.container_port),
        "EV_OOB_URL": f"http://{ev.host_ip}:{ev.host_port}",
    }


__all__ = [
    "CONTAINER_OOB_PORT",
    "HOST_GATEWAY_ALIAS",
    "HOST_GATEWAY_NAME",
    "HOST_LOOPBACK",
    "OOB_BIND_ALL",
    "forced_env",
    "plan",
    "reserve_host_port",
]
