# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The scan container's half of mediated egress: loopback TCP in, the sidecar's socket out.

Under `egress: mediated` the scan container has no network interface but loopback, so no
address is reachable from it at all -- a Docker network's gateway, which on Linux Docker Engine
is the host itself, included. Its one way out is a Unix socket on a volume it shares with the
egress sidecar. Model clients speak `HTTP(S)_PROXY` over TCP, so this relay listens on the
loopback port the forced proxy variables name and copies each connection to that socket byte
for byte; the sidecar hands it to squid, which still makes every allow and deny decision.

A scoped `ev` run also listens on each forwarded port, the exploit-verification target's, and
copies it to that port's own socket, which the sidecar connects to the same port on the host:
exploit verification keeps dialling a loopback address, as it does on the host. It also serves
the one path the other way, the target's out-of-band callback, from a socket the sidecar
connects to into exploit verification's loopback listener.
"""

from __future__ import annotations

import contextlib
import os
import socket
import threading
from typing import TYPE_CHECKING, Final

from vvaharness.backends.sandbox.models import (
    CALLBACK_SOCKET,
    EGRESS_CALLBACK_ENV,
    EGRESS_FORWARDS_ENV,
    EGRESS_RELAY_PORT,
    EGRESS_SOCKET_ENV,
    SandboxUnavailableError,
    forward_socket_name,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

#: One read's worth; the relay copies, it never parses, so the size only bounds a buffer.
_CHUNK: Final = 65536


def _pipe(source: socket.socket, sink: socket.socket) -> None:
    """Copy *source* to *sink* until *source* ends, then say so by half-closing *sink*."""
    with contextlib.suppress(OSError):
        while chunk := source.recv(_CHUNK):
            sink.sendall(chunk)
    with contextlib.suppress(OSError):
        sink.shutdown(socket.SHUT_WR)


#: Where a bridged connection goes: a socket path toward the sidecar, or, for the callback, a
#: loopback `(host, port)` inside the container.
_Target = str | tuple[str, int]


def _dial(target: _Target) -> socket.socket:
    """A socket connected to *target*.

    Raises:
        OSError: If nothing accepts the connection there.
    """
    if not isinstance(target, str):
        return socket.create_connection(target)
    upstream = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        upstream.connect(target)
    except OSError:
        upstream.close()
        raise
    return upstream


def _bridge(client: socket.socket, target: _Target) -> None:
    """Carry one client connection to *target*, in both directions.

    An unreachable target closes the client's connection unanswered, which the client reports
    as a failed proxy connection -- the same failure a stopped proxy gives.
    """
    with client:
        try:
            upstream = _dial(target)
        except OSError:
            return
        with upstream:
            back = threading.Thread(target=_pipe, args=(upstream, client), daemon=True)
            back.start()
            _pipe(client, upstream)
            back.join()


def _serve(server: socket.socket, target: _Target) -> None:
    """Accept connections for the life of the process, each bridged on its own thread."""
    while True:
        try:
            client, _ = server.accept()
        except OSError:
            return
        threading.Thread(target=_bridge, args=(client, target), daemon=True).start()


def start(env: Mapping[str, str] | None = None) -> None:
    """Start the relay when the gate forced a socket path into this run, else do nothing.

    Called only once the run's provenance is established, so a host run never listens. Bound
    to loopback alone: there is no other interface in the container, and on a host it would be
    the wrong process to accept anyone's traffic.

    Raises:
        SandboxUnavailableError: If a relay port is already taken, which would leave the run
            with no way to reach its model or its exploit-verification target.
    """
    env = os.environ if env is None else env
    path = env.get(EGRESS_SOCKET_ENV)
    if not path:
        return
    _listen(EGRESS_RELAY_PORT, path, "its model")
    sockets = os.path.dirname(path)
    for port in filter(None, (env.get(EGRESS_FORWARDS_ENV) or "").split(",")):
        forward = os.path.join(sockets, forward_socket_name(int(port)))
        _listen(int(port), forward, "its exploit-verification target")
    callback = env.get(EGRESS_CALLBACK_ENV)
    if callback:
        _accept_callbacks(os.path.join(sockets, CALLBACK_SOCKET), int(callback))


def _accept_callbacks(path: str, port: int) -> None:
    """Relay the socket at *path*, where the sidecar delivers callbacks, to loopback *port*.

    The one connection into the container: the target's out-of-band callback, which the
    sidecar takes on a port it publishes on host loopback. World-writable because the sidecar
    connects as its own uid, never the invoking user's.

    Raises:
        SandboxUnavailableError: If the socket cannot be created.
    """
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        server.bind(path)
        os.chmod(path, 0o666)  # noqa: S103 — a socket in a per-run volume; see the docstring
        server.listen()
    except OSError as exc:
        server.close()
        msg = (f"the mediated egress relay could not listen on {path}, so the target could not "
               f"reach exploit verification's callback listener: {exc}")
        raise SandboxUnavailableError(msg) from exc
    threading.Thread(
        target=_serve, args=(server, ("127.0.0.1", port)), daemon=True, name="egress-callback"
    ).start()


def _listen(port: int, path: str, purpose: str) -> None:
    """Relay loopback *port* to the socket at *path*, on a thread of its own.

    Raises:
        SandboxUnavailableError: If *port* is already taken.
    """
    try:
        server = socket.create_server(("127.0.0.1", port))
    except OSError as exc:
        msg = (f"the mediated egress relay could not listen on 127.0.0.1:{port}, so this run "
               f"could not reach {purpose}: {exc}")
        raise SandboxUnavailableError(msg) from exc
    threading.Thread(
        target=_serve, args=(server, path), daemon=True, name=f"egress-relay-{port}"
    ).start()


__all__ = ["start"]
