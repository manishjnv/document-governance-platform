# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Fail-closed content scan of the lines an S10 patch ADDED (CWE-1427).

The path gates bound only *where* the fixer writes and ``_gates_ok`` is the
agent's own self-report, so an injected fixer staying inside the allowed paths
previously passed every gate. Only added lines are scanned — pre-existing
matches are the repo's own debt, and a fix that DELETES an ``eval`` or a
credential must not be penalised. Regex, not semgrep-shelled: S10 forbids
``Bash`` and the host must not run an analyzer chosen by model-influenced input.
"""
from __future__ import annotations

import re
from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import PurePosixPath

#: A subprocess-style call — matched on its own, separately from the
#: always-shell constructs below, so ``_is_safe_argv_subprocess_call`` can
#: exempt the argv-list form. Besides ``subprocess.*`` it covers the same
#: functions reached through an alias (``sp.run``) or a ``from subprocess
#: import``: ``Popen``/``check_output``/``check_call`` under any receiver, and
#: ``run``/``call`` when the first argument is a list, a tuple or on the next line.
_SUBPROCESS_ARGV_CALL = re.compile(
    r"(?<![\w.])(?<!def )(?:subprocess\.(?:run|call|Popen|check_output|check_call)\s*\("
    r"|(?:[A-Za-z_]\w*\.)*(?:Popen|check_output|check_call)\s*\("
    r"|(?:[A-Za-z_]\w*\.)*(?:run|call)\s*\((?=\s*(?:[\[(#]|$)))"
)

#: ``from subprocess import`` names that run nothing: exceptions and constants.
_INERT_SUBPROCESS_NAMES = (r"(?:CalledProcessError|TimeoutExpired|SubprocessError|"
                           r"CompletedProcess|PIPE|DEVNULL|STDOUT)")

_SAFE_SUBPROCESS_KWARGS = frozenset({
    "shell", "check", "capture_output", "text", "timeout", "cwd", "input",
    "stdin", "stdout", "stderr", "encoding", "errors", "universal_newlines",
    "close_fds", "bufsize",
})

#: Programs that turn an argv list back into code execution, egress or an exec
#: of another program. Matched on the lowercased basename minus ``.exe``, for
#: argv[0] and for every later literal element, so a wrapper running one of
#: them (``nice sh``, ``find -exec sh``) is caught through the program it runs.
_UNSAFE_ARGV0 = re.compile(
    r"^(?:"
    # Shells and interpreters.
    r"(?:ba|da|z|k|c|tc|fi|a)?sh|busybox|cmd|command|powershell|pwsh|"
    r"python[\d.]*w?|py|pypy[\d.]*|perl[\d.]*|ruby|irb|node(?:js)?|deno|bun|"
    r"php[\d.]*|lua[\d.]*|tclsh|wish|osascript|java|jshell|rscript|[gmn]?awk|sed|"
    # Exec wrappers.
    r"xargs|env|sudo|su|doas|nohup|timeout|exec|eval|nice|ionice|setsid|stdbuf|"
    r"time|watch|strace|ltrace|gdb|chroot|unshare|nsenter|flock|script|expect|"
    r"taskset|chrt|setpriv|runuser|systemd-run|parallel|"
    # Programs that run a command named in their own arguments.
    r"find|tar|zip|sqlite3|mysql|psql|make|"
    # Package managers and runners that fetch and run code.
    r"pip[\d.]*|pipx|uvx?|npm|npx|pnpm|yarn|bunx|cargo|go|gem|docker|podman|"
    # Network clients. DNS lookup tools (dig, nslookup, host) are deliberately
    # NOT here: the canonical command-injection fix for a vulnerable DNS
    # lookup is itself a DNS lookup of a caller-supplied name
    # (``["nslookup", "--", address]``), so banning the data path would also
    # ban its own replacement. Exfiltration via a DNS query name is an
    # accepted residual risk of that trade-off, pinned by
    # test_dns_lookup_tools_are_accepted_by_design.
    r"openssl|curl|wget|nc|ncat|netcat|socat|telnet|ssh|scp|sftp|rsync|ftp|tftp"
    r")$"
)

#: Options that make a program run a command named in its own arguments.
_EXEC_OPTION = re.compile(
    r"(?i)^-{1,2}(?:exec(?:dir)?|ok(?:dir)?|checkpoint-action|to-command|"
    r"use-compress-program|rsh-command|info-script|new-volume-script|"
    r"upload-pack|receive-pack|config-env)\b|"
    r"\bcore\.(?:\w*command|pager|editor|fsmonitor|hookspath)\b"
)

#: git global options that load config or run git from somewhere else.
_GIT_UNSAFE_GLOBAL = re.compile(r"^(?:-c|-C|--(?:exec-path|git-dir|work-tree|namespace|config-env))(?:=|$)")

#: git subcommands that reach the network, change config or run a command.
_GIT_UNSAFE_SUBCOMMAND = frozenset({
    "push", "pull", "fetch", "clone", "remote", "submodule", "ls-remote",
    "archive", "send-email", "request-pull", "daemon", "instaweb",
    "upload-pack", "receive-pack", "upload-archive", "http-backend",
    "http-fetch", "http-push", "config", "bisect", "rebase", "filter-branch",
    "difftool", "mergetool", "credential", "svn", "p4", "cvsimport",
    "cvsserver", "shell", "hook",
})

#: git options that write a file or run a configured program.
_GIT_UNSAFE_OPTION = re.compile(r"^--(?:output|ext-diff|textconv)\b")

#: Secret material an argv call must not read, whatever the program.
_SECRET_PATH = re.compile(
    r"(?i)/\.ssh/|/\.aws/|~/\.ssh|~/\.aws|id_rsa|id_ed25519|\.pem\b|\.env\b|"
    r"credentials|/etc/shadow|/etc/passwd"
)

#: A plain string literal: no f-prefix, no escapes, no implicit concatenation.
_PLAIN_STRING = re.compile(r"""^[rRbBuU]{0,2}(['"])([^'"\\\n]*)\1$""")


def _skip_string(text: str, i: int) -> int:
    """Index just past the string literal opening at *text[i]*, or ``len(text)``."""
    quote = text[i]
    i += 1
    while i < len(text):
        if text[i] == "\\":
            i += 2
            continue
        if text[i] == quote:
            return i + 1
        i += 1
    return len(text)


def _strip_comments(text: str) -> str:
    """*text* with every ``#`` comment removed, leaving string literals intact.

    Without this a ``)`` inside a comment would end a multi-line call early and hide
    a ``shell=True`` on the line after it.
    """
    out: list[str] = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch in "'\"":
            end = _skip_string(text, i)
            out.append(text[i:end])
            i = end
            continue
        if ch == "#":
            newline = text.find("\n", i)
            i = len(text) if newline < 0 else newline
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def _call_args(text: str, open_paren: int) -> str | None:
    """The argument text of the call whose ``(`` is at *open_paren*; None if unclosed."""
    depth = 0
    i = open_paren
    while i < len(text):
        ch = text[i]
        if ch in "'\"":
            i = _skip_string(text, i)
            continue
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
            if depth == 0:
                return text[open_paren + 1:i]
        i += 1
    return None


def _split_top_level(text: str) -> list[str]:
    """*text* split on commas outside any bracket or string."""
    parts: list[str] = []
    depth = 0
    start = 0
    i = 0
    while i < len(text):
        ch = text[i]
        if ch in "'\"":
            i = _skip_string(text, i)
            continue
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
        elif ch == "," and depth == 0:
            parts.append(text[start:i])
            start = i + 1
        i += 1
    parts.append(text[start:])
    return [p.strip() for p in parts if p.strip()]


def _is_safe_argv_args(args: str) -> bool:
    """True when one call's *args* are an argv list running a benign literal program."""
    if "**" in args or _SECRET_PATH.search(args):
        return False
    parts = _split_top_level(args)
    if not parts or parts[0][:1] not in "[(" or parts[0][-1:] not in "])":
        return False
    for kw in parts[1:]:
        name, eq, value = kw.partition("=")
        name = name.strip()
        if not eq or not name.isidentifier() or name not in _SAFE_SUBPROCESS_KWARGS:
            return False
        if name == "shell" and value.strip() != "False":
            return False
    argv = _split_top_level(parts[0][1:-1])
    literals = [_PLAIN_STRING.match(a) for a in argv]
    if not literals or literals[0] is None:
        return False
    program = _program_name(literals[0].group(2))
    if not program or _UNSAFE_ARGV0.match(program):
        return False
    rest = [lit.group(2) for lit in literals[1:] if lit is not None]
    if any(_runs_a_program(value) for value in rest):
        return False
    return program != "git" or _is_safe_git(literals[1:])


def _program_name(path: str) -> str:
    """The lowercased basename of *path* without ``.exe``."""
    return re.split(r"[/\\]", path)[-1].lower().removesuffix(".exe")


def _runs_a_program(value: str) -> bool:
    """True when argv element *value* is an exec option or names an unsafe program.

    Split on ``=``, ``:``, ``,`` and whitespace, so ``exec=sh`` and
    ``core.sshCommand=sh -c id`` are seen through to the ``sh`` they run.
    """
    if _EXEC_OPTION.search(value):
        return True
    return any(_UNSAFE_ARGV0.match(_program_name(piece))
               for piece in re.split(r"[=:,\s]+", value) if piece)


def _is_safe_git(args: list[re.Match[str] | None]) -> bool:
    """True when a git argv (after ``git``) names its subcommand and runs nothing else.

    The subcommand must be a literal, no global option may load config or
    move git elsewhere (``-c``, ``-C``, ``--exec-path``), and neither the
    subcommand nor any option may reach the network, change config or run a
    command.
    """
    subcommand_seen = False
    for lit in args:
        if lit is None:
            if not subcommand_seen:
                return False
            continue
        value = lit.group(2)
        if not subcommand_seen:
            if _GIT_UNSAFE_GLOBAL.match(value):
                return False
            if not value.startswith("-"):
                if value in _GIT_UNSAFE_SUBCOMMAND:
                    return False
                subcommand_seen = True
        elif _GIT_UNSAFE_OPTION.match(value):
            return False
    return subcommand_seen or any(
        lit is not None and lit.group(2) == "--version" for lit in args)


def _is_safe_argv_subprocess_call(text: str, continuation: str = "") -> bool:
    """True when EVERY subprocess call starting on *text* is a benign argv-list call.

    This is CWE-78's own textbook remediation — replacing
    ``os.popen("cmd " + arg)`` with ``subprocess.run(["cmd", "--", arg],
    shell=False)`` — so flagging it as the same "dynamic code execution" as the
    sink it fixes makes command-injection findings unfixable. The exemption is
    fail-closed: argv[0] must be a plain string literal naming a program that
    is not on ``_UNSAFE_ARGV0``; no later element may name one or be an exec
    option; git may not reach the network, change config or run a command;
    ``shell`` may only be the literal ``False``; only known-benign keywords,
    no ``**``, no secret paths. A call may span lines only through
    *continuation* — the added
    lines directly after *text* — and is judged on its whole span, so a
    ``shell=True`` on a later line voids it; a call still open at the end of
    the added block is never exempt.
    """
    calls = list(_SUBPROCESS_ARGV_CALL.finditer(text))
    if not calls:
        return False
    for call in calls:
        span = _strip_comments(text[call.start():] + "\n" + continuation)
        head = _SUBPROCESS_ARGV_CALL.match(span)
        args = _call_args(span, head.end() - 1) if head else None
        if args is None or not _is_safe_argv_args(args):
            return False
    return True


#: ``shell=True`` on its own line, e.g. added into a multi-line call whose opening
#: line is unchanged context and so never reaches the subprocess pattern.
_SHELL_TRUE_KW = re.compile(r"(?<![\w.])shell\s*=\s*(?:True|1)\b")

#: A secret read from the environment. ``\benviron`` also matches an aliased
#: module (``_os.environ``) and ``getenv`` covers ``os.getenv``.
_ENV_SECRET_READ = re.compile(
    r"(?i)(?:\benviron(?:\.get)?\s*[\[(]|\bgetenv\s*\()\s*['\"][^'\"\n]*"
    r"(?:SECRET|TOKEN|PASSWORD|API_?KEY|PRIVATE_?KEY|CREDENTIAL)"
)

#: Never netted against removed lines: argv subprocess calls have their own
#: fail-closed exemption, and netting them would let a fixer rewrite an
#: existing call into a shell.
_NEVER_NETTED = frozenset({_SUBPROCESS_ARGV_CALL, _SHELL_TRUE_KW})

#: (label, reason, patterns) per category; narrow on purpose — reject a backdoor, not any mention of auth
_RULES: tuple[tuple[str, str, tuple[re.Pattern[str], ...]], ...] = (
    (
        "auth_bypass",
        "introduces an authentication/authorization short-circuit",
        (
            # `if <user/token/role/admin-ish> == "<literal>"` style backdoors.
            re.compile(
                r"(?i)\b(?:user(?:name)?|login|account|email|token|api_?key|"
                r"secret|password|passwd|pwd|role|group)\b[^\n=!<>]{0,40}"
                r"==\s*['\"][^'\"\n]{2,}['\"]"
            ),
            # Magic-value escape hatches keyed on a hardcoded sentinel.
            re.compile(
                r"(?i)\b(?:backdoor|master_?key|magic_?(?:key|value|token)|"
                r"god_?mode|skip_?auth|bypass_?auth|no_?auth|auth_?bypass|"
                r"disable_?auth|allow_?all|trust_?all)\b"
            ),
            # Verification functions rewritten to unconditionally succeed.
            re.compile(
                r"(?i)\b(?:is_?(?:admin|authenticated|authorized|valid)|"
                r"check_?(?:auth|permission|access)|has_?(?:permission|access|role)|"
                r"verify|validate|authenticate|authorize)\w*\s*\([^)]*\)\s*"
                r"(?:\{\s*)?(?::\s*)?return\s+(?:True|true|1)\b"
            ),
            # TLS / certificate verification switched off.
            re.compile(
                r"(?i)(?:verify|check_?hostname|validate_?certs?|ssl_?verify|"
                r"rejectUnauthorized|CURLOPT_SSL_VERIFYPEER)\s*[=:]\s*"
                r"(?:False|false|0|None|null)\b"
            ),
            re.compile(r"(?i)\bCERT_NONE\b|\bInsecureSkipVerify\s*:\s*true\b"),
        ),
    ),
    (
        "code_execution",
        "introduces dynamic code execution",
        (
            re.compile(
                r"(?<![\w.])(?:eval|exec|compile)\s*\("
            ),
            _SUBPROCESS_ARGV_CALL,
            _SHELL_TRUE_KW,
            re.compile(
                r"(?<![\w.])(?:subprocess\.(?:getoutput|getstatusoutput)|"
                r"asyncio\.create_subprocess_(?:shell|exec)|"
                r"os\.(?:exec[lv]p?e?|spawn[lv]p?e?|posix_spawnp?))\s*\("
            ),
            re.compile(
                r"(?i)(?<![\w.])(?:os\.system|os\.popen|commands\.getoutput|"
                r"child_process\.(?:exec|execSync|spawn|spawnSync)|"
                r"Runtime\.getRuntime\(\)\.exec|ProcessBuilder|"
                r"shell_exec|passthru|proc_open|popen|system)\s*\("
            ),
            # A process-spawning function imported under another name, which the
            # call patterns above would not recognise at its call site.
            re.compile(
                r"(?<![\w.])(?:import\b[^\n#]*\bsubprocess\s+as\b|"
                rf"from\s+subprocess\s+import\b(?!\s*\(?\s*{_INERT_SUBPROCESS_NAMES}"
                rf"(?:\s*,\s*{_INERT_SUBPROCESS_NAMES})*\s*,?\s*\)?\s*(?:#|$))|"
                r"from\s+os\s+import\b[^\n#]*\b(?:system|popen|exec\w*|spawn\w*|posix_spawnp?)\b)"
            ),
            # ctypes calls libc directly: CDLL(None).system(cmd).
            re.compile(r"(?<![\w.])(?:ctypes|cdll|windll|CDLL)\b"),
            re.compile(r"(?<![\w.])new\s+Function\s*\("),
            re.compile(r"(?i)\bpickle\.loads?\s*\(|\byaml\.load\s*\((?![^)]*Safe)"),
            re.compile(r"(?i)\b__import__\s*\(|\bimportlib\.import_module\s*\("),
            re.compile(r"(?i)\bsetTimeout\s*\(\s*['\"]"),
        ),
    ),
    (
        "network_egress",
        "introduces outbound network access",
        (
            re.compile(
                r"(?i)(?<![\w.])(?:requests\.(?:get|post|put|patch|delete|request)|"
                r"urllib\.request\.urlopen|urlopen|httpx\.(?:get|post|Client)|"
                r"http\.client\.HTTPS?Connection|aiohttp\.ClientSession|"
                r"fetch|axios(?:\.\w+)?|XMLHttpRequest|WebSocket|"
                r"socket\.(?:socket|create_connection))\s*\("
            ),
            # NO bare URL / IP:port pattern here, deliberately. A URL literal
            # in source is not egress — egress is a CALL. Matching the literal
            # would flag ordinary application code, such as an allowlist
            # validator's error message or an href in an HTML anchor. The
            # call-shaped patterns above are the real signal.
            re.compile(
                r"(?i)(?<![\w.])(?:curl|wget|nc|ncat|netcat)\s+(?:-\S+\s+)*"
                r"(?:https?://|\d{1,3}\.)"
            ),
        ),
    ),
    (
        "credential_exfiltration",
        "reads credentials or secret material into a new code path",
        (
            re.compile(
                r"(?i)(?:open|read_text|readFile(?:Sync)?|cat)\s*\(\s*"
                r"['\"][^'\"\n]*(?:/\.ssh/|/\.aws/|id_rsa|id_ed25519|"
                r"\.pem|\.env|credentials|shadow|passwd)"
            ),
            # The same paths reached through a path helper, e.g.
            # open(os.path.expanduser("~/.aws/credentials")).
            re.compile(
                r"(?i)\b(?:expanduser|Path\.home|homedir)\s*\(\s*(?:\)\s*/\s*)?"
                r"['\"][^'\"\n]*(?:\.ssh|\.aws|id_rsa|id_ed25519|\.pem|\.env|credentials)"
            ),
            _ENV_SECRET_READ,
            re.compile(r"(?i)\b(?:base64\.b64decode|atob)\s*\(\s*['\"][A-Za-z0-9+/=]{24,}"),
        ),
    ),
    (
        "reverse_shell",
        "introduces a reverse shell or interactive listener",
        (
            re.compile(
                # (?<![\w/]), not \b: \b needs a word character before "/",
                # so it never matched a quoted "/bin/sh".
                r"(?i)(?<![\w/])(?:/bin/(?:ba)?sh|cmd\.exe|powershell)\b[^\n]{0,60}"
                r"(?:-i|-c|/c|-nop|-enc)\b"
            ),
            re.compile(r"(?i)\bpty\.spawn\s*\(|\bsocket\.dup2\b|\bdup2\s*\(\s*s\b"),
            re.compile(r"(?i)\bnc\s+-\w*l\w*\b|\bbash\s+-i\s*>&"),
        ),
    ),
)

#: Comment-only additions are skipped: an injected payload must become code to act
_COMMENT_ONLY = re.compile(
    r"""^\s*(?:\#|//|/\*|\*|<!--|--|;|%|"""         # common line-comment leaders
    r"""\"\"\"|'''|rem\s)""",
    re.IGNORECASE | re.VERBOSE,
)

#: A line whose code content is ONE string literal of prose — an operator
#: warning, a docstring row, a raised message. The construct named inside it is
#: being described, not performed: a validator that raises
#: "Remove APP_TLS_VERIFY=false (CWE-295)" is the control, not the breach.
#: Requires whitespace inside the quotes, so a real single-argument call such as
#: ``eval("payload")`` is never mistaken for prose.
_PROSE_STRING_ONLY = re.compile(
    r"""^[\s(\[{,]*             # optional call/collection punctuation
        [rfbu]{0,2}             # python string prefixes
        (?P<q>\"\"\"|'''|\"|')  # opening quote
        (?P<body>.*?)           # body
        (?P=q)                  # matching close quote
        [\s)\]},;+]*$           # optional trailing punctuation/concatenation
    """,
    re.VERBOSE | re.DOTALL,
)


def _is_prose_string(text: str) -> bool:
    """True when *text*'s whole code content is one human-sentence string.

    The space requirement is what separates prose from a real single-argument
    call: ``eval("payload")`` has no space inside the quotes and is still
    scanned, while ``raise ValueError("Remove APP_TLS_VERIFY=false")`` is a
    message describing the construct rather than performing it.
    """
    match = _PROSE_STRING_ONLY.match(text.strip())
    return bool(match) and " " in (match.group("body") or "")

_DIFF_HEADER_PREFIXES = ("+++", "---")
_HUNK = re.compile(r"^@@ -(?P<start>\d+)(?:,(?P<count>\d+))?")
_DIFF_GIT = re.compile(r"^diff --git a/(?P<a>.+?) b/(?P<b>.+?)\s*$")
_PLUS_FILE = re.compile(r"^\+\+\+ (?:b/)?(?P<path>.+?)\s*$")


@dataclass
class _Hunk:
    """One hunk's removed and added lines, with its pre-image line range."""

    old_start: int = 0
    old_count: int = 0
    removed: list[str] = field(default_factory=list)
    #: ``(lineno, text, run)``; equal *run* means adjacent in the post-image.
    added: list[tuple[int, str, int]] = field(default_factory=list)

    def overlaps(self, start: int, end: int) -> bool:
        """True when pre-image lines *start*..*end* fall inside this hunk."""
        return self.old_start > 0 and start <= self.old_start + max(self.old_count, 1) - 1 \
            and end >= self.old_start


def _hunks_by_file(diff_text: str | None) -> dict[str, list[_Hunk]]:
    """Each file's hunks; ``lineno`` counts added lines within the file (1-based)."""
    if not diff_text:
        return {}
    out: dict[str, list[_Hunk]] = {}
    current: str | None = None
    hunk: _Hunk | None = None
    counter = run = 0
    for raw in diff_text.splitlines():
        m = _DIFF_GIT.match(raw)
        if m:
            current, hunk, counter = (m.group("b") or m.group("a")).strip() or None, None, 0
            continue
        m = _PLUS_FILE.match(raw)
        if m:
            path = m.group("path").strip()
            current, hunk, counter = (None if path == "/dev/null" else path), None, 0
            continue
        if raw.startswith(_DIFF_HEADER_PREFIXES):
            continue
        m = _HUNK.match(raw)
        if m:
            hunk = None
            if current:
                hunk = _Hunk(int(m.group("start")), int(m.group("count") or 1))
                out.setdefault(current, []).append(hunk)
            run += 1
            continue
        if not current:
            continue
        if hunk is None:  # +/- lines with no hunk header: never sink-scoped
            hunk = _Hunk()
            out.setdefault(current, []).append(hunk)
        if raw.startswith("+"):
            counter += 1
            hunk.added.append((counter, raw[1:], run))
        elif raw.startswith("-"):
            hunk.removed.append(raw[1:])
        else:  # a context line ends the post-image run of added lines
            run += 1
    return out


def added_lines_by_file(diff_text: str | None) -> dict[str, list[tuple[int, str]]]:
    """Map each file in *diff_text* to its ADDED lines as ``(lineno, text)``.

    ``lineno`` counts added lines within the file's own hunks (1-based) and is
    used only to make a finding reportable; it is not a post-image line number.
    Removed and context lines are excluded, as are diff headers.
    """
    return {path: [(n, text) for h in hunks for n, text, _run in h.added]
            for path, hunks in _hunks_by_file(diff_text).items()
            if any(h.added for h in hunks)}


#: Shells execute but carry no language key in frameworks._EXT_LANG.
_SHELL_EXTS = frozenset({".sh", ".bash", ".zsh", ".ksh", ".ps1", ".psm1"})

#: vvaharness' own output and scaffolding dirs, never attacker-controlled.
#: Their contents are security-detector material by design — probe.sh scripts
#: carry live attack payloads and SKILL.md docs quote them as examples — so
#: they match these rules for legitimate reasons. Matched after _fold(), which
#: strips leading "./" characters, so ".vvaharness" arrives as "vvaharness".
_HARNESS_OWNED_PREFIXES = ("vvaharness/", "security-scan/", "security-remediation/")


def _is_executable_source(path: str) -> bool:
    """True when *path* is a file whose added lines could actually run.

    These rules describe code constructs, so only code can carry them. A log,
    report, manifest or Markdown doc cannot execute, and scanning one is pure
    noise: a security skill doc quoting
    ``if username == 'admin'`` as a worked example matches auth_bypass, and a
    runtime log echoes addresses and commands verbatim. Both
    reach the diff through enforce_post's whole-tree sweep, which reports every
    dirty path in the repo whether or not the fixer touched it.
    """
    from vvaharness.remediation_agent.frameworks import language_for

    suffix = PurePosixPath(path or "").suffix.lower()
    return suffix in _SHELL_EXTS or language_for(path) != "default"


#: ``target = …`` / ``target: T = …``; the assigned name, for replacement netting.
_ASSIGN_TARGET = re.compile(
    r"^\s*(?P<t>[A-Za-z_][\w.]*(?:\[[^\]\n]*\])*)\s*(?::[^=\n]+)?=(?!=)")


def _assign_target(text: str) -> str | None:
    m = _ASSIGN_TARGET.match(text)
    return m.group("t").replace('"', "'").replace(" ", "") if m else None


def _scannable(text: str) -> bool:
    return bool(text.strip()) and not _COMMENT_ONLY.match(text) and not _is_prose_string(text)


@dataclass
class _Netting:
    """What a sink-scoped hunk removed, which its added lines may replace one for one.

    Pre-existing matches are the repo's own debt, and a fix that rewrites the
    reported sink in place — an ``eval`` constrained to an AST-checked
    expression, a hard-coded secret moved to the environment — does not
    INTRODUCE the construct. Netting only ever applies inside a hunk that
    overlaps the finding's own lines, so a fixer cannot rewrite some unrelated
    sink elsewhere, and never to ``_NEVER_NETTED``.
    """

    patterns: Counter[re.Pattern[str]] = field(default_factory=Counter)
    targets: Counter[str] = field(default_factory=Counter)

    @classmethod
    def of(cls, hunk: _Hunk) -> _Netting:
        net = cls()
        for text in hunk.removed:
            if not _scannable(text):
                continue
            net.patterns.update(p for _l, _r, patterns in _RULES for p in patterns
                                if p not in _NEVER_NETTED and p.search(text))
            if (target := _assign_target(text)) is not None:
                net.targets[target] += 1
        return net

    def take(self, pattern: re.Pattern[str], text: str) -> bool:
        """Consume a removed match that *text*'s *pattern* hit replaces; False if none."""
        if self.patterns[pattern] > 0:
            self.patterns[pattern] -= 1
            return True
        target = _assign_target(text) if pattern is _ENV_SECRET_READ else None
        if target is not None and self.targets[target] > 0:
            self.targets[target] -= 1
            return True
        return False


def scan_added_lines(
    diff_text: str | None, *, only_files: Iterable[str] | None = None,
    sink: tuple[str, int, int] | None = None,
) -> dict[str, list[str]]:
    """Find forbidden constructs among the lines *diff_text* added.

    *sink* is the remediated finding's ``(file, line_start, line_end)``. A hit
    in a hunk overlapping it may net against what that hunk removed (see
    ``_Netting``); without it nothing is netted.

    Returns ``{path: ["<category>: <reason> (line N: <snippet>)", …]}`` — empty
    when the patch added nothing of concern. Never raises: a scan failure must
    not take down a run, but note that an empty result is also what a clean
    patch produces, so callers treat "no findings" as pass.
    """
    try:
        hunks_by_file = _hunks_by_file(diff_text)
    except Exception:  # noqa: BLE001 — a best-effort scan must never break a run
        return {}
    allowed = {_fold(f) for f in only_files} if only_files is not None else None
    issues: dict[str, list[str]] = {}
    for path, hunks in hunks_by_file.items():
        if allowed is not None and _fold(path) not in allowed:
            continue
        folded = _fold(path)
        if folded.startswith(_HARNESS_OWNED_PREFIXES):
            continue
        if not _is_executable_source(path):
            continue
        for hunk in hunks:
            scoped = sink is not None and _fold(sink[0]) == folded and hunk.overlaps(
                sink[1], max(sink[1], sink[2]))
            netting = _Netting.of(hunk) if scoped else _Netting()
            for i, (lineno, text, run) in enumerate(hunk.added):
                if not _scannable(text):
                    continue
                continuation = "\n".join(t for _n, t, r in hunk.added[i + 1:] if r == run)
                problem = _line_problem(text, continuation, netting)
                if problem is not None:
                    label, reason = problem
                    issues.setdefault(path, []).append(
                        f"{label}: {reason} (line {lineno}: {_snippet(text)})")
    return issues


def _line_problem(text: str, continuation: str, netting: _Netting) -> tuple[str, str] | None:
    """The first rule *text* breaks that no exemption or netting covers."""
    safe_argv = _is_safe_argv_subprocess_call(text, continuation)
    for label, reason, patterns in _RULES:
        for p in patterns:
            if not p.search(text):
                continue
            if p is _SUBPROCESS_ARGV_CALL and safe_argv:
                continue
            if p not in _NEVER_NETTED and netting.take(p, text):
                continue
            return label, reason  # one category per line is enough to reject it
    return None


def undeclared_edited_files(
    diff_text: str | None, declared: Iterable[str]
) -> list[str]:
    """Files the patch changed that the dispatch never declared.

    ``FixerDispatchGuard`` validates that the dispatch's ``TARGET FILES``
    section names the primary file, but nothing checked that the fixer confined
    its edits to the files it declared. Any extra file is an edit the
    orchestrator never asked for, which is exactly the shape of an injected
    backdoor dropped into an unrelated module.
    """
    try:
        touched = added_lines_by_file(diff_text)
    except Exception:  # noqa: BLE001 — best effort, as above
        return []
    want = {_fold(d) for d in declared if d}
    return sorted(p for p in touched if _fold(p) not in want)


def _fold(path: str) -> str:
    return (path or "").replace("\\", "/").lstrip("./").casefold()


def _snippet(text: str, limit: int = 120) -> str:
    """A single-line, length-bounded excerpt safe to embed in a report."""
    flat = " ".join(text.split())
    return flat if len(flat) <= limit else flat[: limit - 1] + "…"


__all__ = ["added_lines_by_file", "scan_added_lines", "undeclared_edited_files"]
