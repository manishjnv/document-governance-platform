# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Filesystem permissioning, backend selection, and skill-source resolution."""

from __future__ import annotations

import contextlib
from functools import lru_cache
from pathlib import Path, PurePosixPath

from deepagents.backends import FilesystemBackend
from deepagents.backends import filesystem as _deepagents_filesystem
from deepagents.backends.composite import CompositeBackend
from deepagents.backends.filesystem import _raise_if_symlink_loop
from deepagents.backends.local_shell import LocalShellBackend
from deepagents.backends.protocol import (
    BackendProtocol,
    DeleteResult,
    EditResult,
    FileInfo,
    FileUploadResponse,
    GlobResult,
    GrepResult,
    LsResult,
    ReadResult,
    WriteResult,
)
from deepagents.middleware.filesystem import FilesystemPermission

# Scan-scope registry is SHARED with sdk/openai, never re-derived: one s1 registration binds all
from vvaharness.backends.harness.deepagents.models import (
    GIT_INTERNALS_DENY,
    READ_ONLY_PERMISSIONS,
)
from vvaharness.backends.harness.models import OneShotOptions, StreamingOptions
from vvaharness.backends.llm import tools as _scan_scope
from vvaharness.util.counters import COUNTERS
from vvaharness.util.git_paths import first_folded_part, is_git_metadata

#: Refusal for a path that escapes the backend's root; only the model's own path is echoed.
_JAIL_ERROR = "ERROR: path '{path}' is outside the scan root; use a repo-relative path"


def _filesystem_permissions(
    options: OneShotOptions | StreamingOptions,
) -> list[FilesystemPermission]:
    """Deny all writes for a read-only session; permit them when the caller opts in."""
    if options.allow_writes:
        # DeepAgents' filesystem middleware is rooted at cwd; refuse a broader writable_paths scope.
        root = options.cwd.resolve()
        for raw in options.writable_paths:
            candidate = Path(raw).resolve()
            if candidate != root and root not in candidate.parents:
                raise ValueError(f"writable path escapes harness cwd: {raw}")
        return GIT_INTERNALS_DENY
    return READ_ONLY_PERMISSIONS


@lru_cache(maxsize=8)
def _in_scope_dirs(scope: frozenset[str]) -> frozenset[str]:
    """Every ancestor directory (repo-relative posix) of an in-scope file."""
    # ls shows only dirs holding in-scope files: an excluded file's NAME must not leak
    dirs: set[str] = set()
    for rel in scope:
        parts = rel.split("/")[:-1]
        for depth in range(1, len(parts) + 1):
            dirs.add("/".join(parts[:depth]))
    return frozenset(dirs)


#: Refusal a detection session's backend returns for any write-class operation.
_WRITE_REFUSED = "write operations are disabled on detection sessions: {path}"


class _NoWriteBackend(FilesystemBackend):
    """A ``FilesystemBackend`` whose write surface fails closed, touching no disk."""
    # Middleware writes (eviction/offload) bypass permissions into the scanned repo; failing = no-op

    def write(self, file_path: str, content: str) -> WriteResult:  # noqa: ARG002
        return WriteResult(error=_WRITE_REFUSED.format(path=file_path))

    def edit(
        self,
        file_path: str,
        old_string: str,  # noqa: ARG002
        new_string: str,  # noqa: ARG002
        replace_all: bool = False,  # noqa: ARG002 — upstream signature
    ) -> EditResult:
        return EditResult(error=_WRITE_REFUSED.format(path=file_path))

    def delete(self, file_path: str) -> DeleteResult:
        return DeleteResult(error=_WRITE_REFUSED.format(path=file_path))

    def upload_files(
        self, files: list[tuple[str, bytes]]
    ) -> list[FileUploadResponse]:
        return [
            FileUploadResponse(path=path, error=_WRITE_REFUSED.format(path=path))
            for path, _content in files
        ]


class _PathJail:
    """Shared crash-proof ``_resolve_path`` jail (OSError subtype, not a raised exception); carries no read-reach narrowing of its own."""

    def _locate(self, key: str) -> Path | None:
        """Resolve *key* inside the jail, or None when the jail refuses it; never counts."""
        if not self.virtual_mode:
            return super()._resolve_path(key)
        vpath = key if key.startswith("/") else f"/{key}"
        # Tilde checked on the ORIGINAL key: vpath is always "/"-prefixed by now, so
        # vpath.startswith("~") can never fire.
        refused = ".." in PurePosixPath(vpath).parts or key.startswith("~")
        full = None if refused else (self.cwd / vpath.lstrip("/")).resolve()
        if full is None or not full.is_relative_to(self.cwd):
            return None
        _raise_if_symlink_loop(full)
        return full

    def _resolve_path(self, key: str) -> Path:
        full = self._locate(key)
        if full is None:
            COUNTERS.bump("deepagents_path_jail_refused")
            raise PermissionError(_JAIL_ERROR.format(path=key))
        return full


class _ReadSurfaceFilter(_PathJail, FilesystemBackend):
    """Read-surface narrowing for ``read``/``grep``/``glob``/``ls``.

    Subclasses set the deny set (``_excluded_dirs``) and the inventory (``_scope``), and may
    count a refusal (``_note_refused``) or a filtered result (``_note_filtered``).
    """

    _excluded_dirs: frozenset[str] = _scan_scope._ALWAYS_EXCLUDED_DIRS

    def _scope(self) -> frozenset[str] | None:
        return None

    def _note_refused(self, n: int) -> None:  # noqa: ARG002 - base no-op, overridden below
        return None

    def _note_filtered(self, n: int) -> None:  # noqa: ARG002 - base no-op, overridden below
        return None

    def _excluded_error(self, path: str, rel: str) -> str:  # noqa: ARG002 - overridden below
        return _scan_scope._SCOPE_ERROR.format(path=path)

    def _rel_of(self, file_path: str) -> str | None:
        """Repo-relative posix path for *file_path*, or None when it cannot resolve."""
        # Resolution failures return None: the scope check must never REPLACE the jail's refusals.
        # Uncounted: the real call that follows repeats the refusal and counts it once.
        try:
            full = self._locate(file_path)
            return None if full is None else full.relative_to(self.cwd).as_posix()
        except (ValueError, OSError, RuntimeError):
            return None

    def read(self, file_path: str, offset: int = 0, limit: int = 2000) -> ReadResult:
        rel = self._rel_of(file_path)
        # Scope check BEFORE super()'s existence check, so it is never an existence oracle
        if (rel is not None and rel != "."
                and _scan_scope._excluded_rel(rel, self._scope(), dirs=self._excluded_dirs)):
            self._note_refused(1)
            return ReadResult(error=self._excluded_error(file_path, rel))
        return super().read(file_path, offset, limit)

    def grep(
        self,
        pattern: str,
        path: str | None = None,
        glob: str | None = None,
        *,
        max_count: int | None = None,
        context_lines: int = 0,
    ) -> GrepResult:
        scope = self._scope()
        if path is not None:
            # Only a named excluded FILE is refused; dirs fall through or every subtree is refused
            rel = self._rel_of(path)
            if (
                rel is not None
                and rel != "."
                and (self.cwd / rel).is_file()
                and _scan_scope._excluded_rel(rel, scope, dirs=self._excluded_dirs)
            ):
                self._note_refused(1)
                return GrepResult(error=self._excluded_error(path, rel), matches=[])
        result = super().grep(
            pattern, path, glob, max_count=max_count, context_lines=context_lines
        )
        if result.matches:
            # Match paths are virtual ("/rel/posix") on this always-virtual backend.
            kept = [
                m
                for m in result.matches
                if not _scan_scope._excluded_rel(
                    m["path"].lstrip("/"), scope, dirs=self._excluded_dirs)
            ]
            self._note_filtered(len(result.matches) - len(kept))
            result.matches = kept
        return result

    def glob(self, pattern: str, path: str | None = None) -> GlobResult:
        result = super().glob(pattern, path)
        if result.matches:
            scope = self._scope()
            kept = [
                m
                for m in result.matches
                if not _scan_scope._excluded_rel(
                    m["path"].lstrip("/"), scope, dirs=self._excluded_dirs)
            ]
            self._note_filtered(len(result.matches) - len(kept))
            result.matches = kept
        return result

    def _entry_excluded(self, entry: FileInfo, scope: frozenset[str] | None) -> bool:
        rel = entry["path"].strip("/")
        if not entry.get("is_dir"):
            return bool(rel) and _scan_scope._excluded_rel(rel, scope, dirs=self._excluded_dirs)
        return _dir_excluded(rel, scope, dirs=self._excluded_dirs)

    def ls(self, path: str) -> LsResult:
        result = super().ls(path)
        if result.entries:
            scope = self._scope()
            kept = [e for e in result.entries if not self._entry_excluded(e, scope)]
            self._note_filtered(len(result.entries) - len(kept))
            result.entries = kept
        return result


class _ScopedReadBackend(_ReadSurfaceFilter, _NoWriteBackend):
    """A ``FilesystemBackend`` whose READ surface is confined to the scan scope."""
    # Root jail NOT enough (.git/config, security-scan/); choke point scopes all reads, pre-s1 too

    def _scope(self) -> frozenset[str] | None:
        """The registered inventory for this root, or None when s1 has not run."""
        return _scan_scope._scope_for(self.cwd)


def _dir_excluded(
    rel: str, scope: frozenset[str] | None, *,
    dirs: frozenset[str] = _scan_scope._ALWAYS_EXCLUDED_DIRS,
) -> bool:
    """Whether ``ls`` should hide directory *rel* under the registered inventory *scope*."""
    if _scan_scope._under_excluded_dir(rel.split("/"), dirs=dirs):
        return True
    # .vvaharness/skills post-dates s1's walk; without this exemption every scan loads zero skills
    if _scan_scope._always_allowed(rel + "/"):
        return False
    return bool(rel) and scope is not None and rel not in _in_scope_dirs(scope)


class _ShellScopedReadBackend(_ScopedReadBackend, LocalShellBackend):
    """Inventory-scoped file operations plus ``execute``, when a stage sets ``allow_shell``."""


def _shell_composite(cwd: str) -> CompositeBackend:
    """A composite whose default AND sole route are one executing, scoped backend."""
    # execute ignores routing; a non-empty routes map is the ONLY way past the NotImplementedError
    shell = _ShellScopedReadBackend(root_dir=cwd, virtual_mode=True, inherit_env=False)
    return CompositeBackend(default=shell, routes={"/": shell})


def _scoped_backend(options: StreamingOptions) -> BackendProtocol:
    """The inventory-scoped read backend, wrapped for ``execute`` when ``allow_shell`` is set."""
    if getattr(options, "allow_shell", False):
        return _shell_composite(options.cwd)
    return _ScopedReadBackend(root_dir=options.cwd, virtual_mode=True)


#: Refusal for a write into repository metadata, whatever the permission globs allowed.
_GIT_WRITE_REFUSED = "writes into version-control metadata (.git) are refused: {path}"

#: Matches the sdk route's own text (agent_sdk._refused_key_value), not the inventory-scope
#: wording: S10/S11 have no file inventory, so "not in the scanned file inventory" is false here.
_POST_SCAN_READ_REFUSED = ("path {path!r} falls under the internal {hit!r} directory, which "
                          "is never readable in a remediation/validation session.")


class _StockReadBackend(_ReadSurfaceFilter, FilesystemBackend):
    """The S10/S11 backend: full source reach and write access, minus post-scan deny-set reads.

    Refuses version-control metadata and harness output, because neither stage's intent reads
    those paths. A traversal or symlink loop returns ``error=...`` instead of killing the session:
    a deliberate, scoped exception to staying frozen on S10/S11.
    """

    _excluded_dirs = _scan_scope._POST_SCAN_EXCLUDED_DIRS

    def _note_refused(self, n: int) -> None:
        _scan_scope.note_post_scan_refusal("deepagents_post_scan_read_refused", "post-scan", n)

    def _note_filtered(self, n: int) -> None:
        _scan_scope.note_post_scan_filter(
            "deepagents_post_scan_entries_filtered", "post-scan", n)

    def _excluded_error(self, path: str, rel: str) -> str:
        hit = first_folded_part(rel.split("/"), self._excluded_dirs)
        return _POST_SCAN_READ_REFUSED.format(path=path, hit=hit)

    def _write_refusal(self, file_path: str) -> str | None:
        """Why a write to *file_path* is refused: the name as given, or where it resolves."""
        if is_git_metadata(file_path):
            return _GIT_WRITE_REFUSED.format(path=file_path)
        rel = self._rel_of(file_path)
        if rel is None or not _scan_scope._excluded_target(rel, None, dirs=self._excluded_dirs):
            return None
        self._note_refused(1)
        return self._excluded_error(file_path, rel)

    def _crlf_if_uniform(self, file_path: str) -> bool:
        """Whether *file_path* is uniformly CRLF already, with no bare LF."""
        try:
            full = self._locate(file_path)
            if full is None or not full.is_file():
                return False
            raw = full.read_bytes()
        except OSError:
            return False
        return b"\r\n" in raw and b"\n" not in raw.replace(b"\r\n", b"")

    def _restore_crlf(self, file_path: str) -> None:
        """Turn every bare LF *file_path* was just written with back into CRLF.

        `FilesystemBackend.write`/`.edit` read with universal newlines (CRLF -> LF
        in memory) and write back with ``newline=""`` (no translation), so a CRLF
        file comes back all-LF even when the fixer changed one line — the whole
        file then reads as changed. Called only when the pre-write file was
        uniformly CRLF; a no-op once the content already has CRLF pairs (the
        fixer wrote its own, or there was nothing to restore).
        """
        full = self._locate(file_path)
        if full is None:
            return
        try:
            data = full.read_bytes()
            if b"\r\n" in data:
                return
            fixed = data.replace(b"\n", b"\r\n")
            if fixed != data:
                full.write_bytes(fixed)
                COUNTERS.bump("deepagents_crlf_restored")
        except OSError:
            return

    # The async variants delegate to these via asyncio.to_thread, so this covers both.
    def write(self, file_path: str, content: str) -> WriteResult:
        if (refusal := self._write_refusal(file_path)) is not None:
            return WriteResult(error=refusal)
        was_crlf = self._crlf_if_uniform(file_path)
        result = super().write(file_path, content)
        if was_crlf and result.error is None:
            self._restore_crlf(file_path)
        return result

    def edit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> EditResult:
        if (refusal := self._write_refusal(file_path)) is not None:
            return EditResult(error=refusal)
        was_crlf = self._crlf_if_uniform(file_path)
        result = super().edit(file_path, old_string, new_string, replace_all)
        if was_crlf and result.error is None:
            self._restore_crlf(file_path)
        return result

    def delete(self, file_path: str) -> DeleteResult:
        if (refusal := self._write_refusal(file_path)) is not None:
            return DeleteResult(error=refusal)
        return super().delete(file_path)

    def upload_files(
        self, files: list[tuple[str, bytes]]
    ) -> list[FileUploadResponse]:
        refusals = [self._write_refusal(p) for p, _c in files]
        allowed = [file for file, refusal in zip(files, refusals, strict=True) if refusal is None]
        results = iter(super().upload_files(allowed) if allowed else [])
        return [
            next(results) if refusal is None else FileUploadResponse(path=p, error=refusal)
            for (p, _c), refusal in zip(files, refusals, strict=True)
        ]


def _session_backend(
    options: OneShotOptions | StreamingOptions,
) -> BackendProtocol | None:
    """Use a real, repo-confined filesystem; read-only sessions still need native reads."""
    # Always disk-backed: native read_file/grep/glob are the only read path; StateBackend is empty.
    _filesystem_permissions(options)
    # Opt-in per site, keyed off the SAME permitted_tool_calls as the gate, so the two cannot drift
    if getattr(options, "permitted_tool_calls", None) is not None:
        return _scoped_backend(options)
    # One-shot = detection parser: fail closed, since a tool-less turn cannot recover an eviction
    if isinstance(options, OneShotOptions):
        return _NoWriteBackend(root_dir=options.cwd, virtual_mode=True)
    # S10/S11 streaming: full source reach and writes; the post-scan deny set is refused
    # (see _StockReadBackend).
    return _StockReadBackend(root_dir=options.cwd, virtual_mode=True)


@contextlib.contextmanager
def patched_read_timeouts(seconds: float | None):
    """Temporarily raise deepagents' hardcoded 5s glob / 15s grep timeout (module-global, not safe to nest with a different value); ``None`` is a no-op."""
    if seconds is None:
        yield
        return
    mod = _deepagents_filesystem
    grep_timeout = int(seconds)
    async_grep_timeout = 2 * grep_timeout + 5
    python_search_defaults = mod.FilesystemBackend._python_search.__kwdefaults__
    originals = (
        mod._DEFAULT_GLOB_TIMEOUT,
        mod.DEFAULT_GREP_TIMEOUT,
        mod.ASYNC_GREP_TIMEOUT,
        python_search_defaults["timeout"],
    )
    try:
        mod._DEFAULT_GLOB_TIMEOUT = seconds
        mod.DEFAULT_GREP_TIMEOUT = grep_timeout
        mod.ASYNC_GREP_TIMEOUT = async_grep_timeout
        python_search_defaults["timeout"] = grep_timeout
        yield
    finally:
        (
            mod._DEFAULT_GLOB_TIMEOUT,
            mod.DEFAULT_GREP_TIMEOUT,
            mod.ASYNC_GREP_TIMEOUT,
            python_search_defaults["timeout"],
        ) = originals


def _skill_sources(skill_root: Path | None, cwd: Path) -> list[str]:
    """Return *skill_root* as a virtual-path skill source, re-rooted under the session cwd."""
    if skill_root is None or not skill_root.is_dir():
        return []
    root, base = skill_root.resolve(), cwd.resolve()
    if not root.is_relative_to(base):
        msg = f"skill_root {root} must live under the session cwd {base}"
        raise ValueError(msg)
    relative = root.relative_to(base).as_posix()
    return [f"/{relative}" if relative != "." else "/"]
