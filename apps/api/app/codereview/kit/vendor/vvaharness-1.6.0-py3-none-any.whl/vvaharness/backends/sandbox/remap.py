# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Argv path-remapping and env-allowlisting for a contained re-exec."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Final

from vvaharness.backends.sandbox.models import CONTAINED_FLAG, EV_PATH_ENV

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence
    from collections.abc import Set as AbstractSet

    from vvaharness.backends.sandbox.models import EnvPolicy, Mount

#: Every flag across scan/remediate/validate whose value is a host filesystem path. A flag is
#: only remappable if something mounts it, so this set and `config.FLAG_RULES` move together.
REMAPPED_FLAGS: Final[frozenset[str]] = frozenset({
    "--repo", "--config", "--repo-file", "--workspace", "--step1-config", "--scan-report",
    "--semgrep-report",
})

#: Names refused outright. ALLOW_CWD_CONFIG is a host-operator escape hatch about the HOST's
#: cwd, which means nothing in a container: the contained run uses the profile the gate passed
#: and mounted, never one a lookup discovers -- in a target it would be the target's own planted
#: config. The IMAGE_* pair must come from the image's own baked ENV: a host
#: value crossing as `-e` would override it and spoof the manifest's stale-image record.
_NEVER_CROSS: Final[frozenset[str]] = frozenset({
    "VVAHARNESS_ALLOW_CWD_CONFIG", "VVAHARNESS_IMAGE_VERSION", "VVAHARNESS_IMAGE_GIT_SHA",
    # The EV gateway is daemon-derived per run (docker/evnet.forced_env); an ambient host
    # value must never widen safety.check_allowed's envelope inside the container.
    "VVAHARNESS_EV_HOST_GATEWAY",
})

#: Tracing namespaces that cross only when `sandbox.env_allowlist` names one of them: they are a
#: live phone-home out of the container. Checked by name, so an allowlist entry that is merely a
#: prefix of them (`LANG`) does not let them through.
_TELEMETRY_PREFIXES: Final[frozenset[str]] = frozenset({"LANGSMITH_", "LANGCHAIN_"})

#: langchain-core raises "Tracing using LangChainTracerV1 is no longer supported" at callback
#: setup when either of these is set and v2 tracing is not (callbacks/manager.py:2492-2506).
_V1_TRACING: Final[frozenset[str]] = frozenset({"LANGCHAIN_TRACING", "LANGCHAIN_HANDLER"})

#: The v2 gates langsmith consults, each enabling only on the exact string "true"
#: (langsmith.utils.get_env_var: TRACING_V2 then TRACING, LANGSMITH_ before LANGCHAIN_).
_V2_TRACING_GATES: Final[tuple[str, ...]] = (
    "LANGSMITH_TRACING_V2", "LANGCHAIN_TRACING_V2", "LANGSMITH_TRACING", "LANGCHAIN_TRACING",
)

#: The one log flag whose value is a host path. It earns no mount (`REMAPPED_FLAGS` does not
#: name it), so it is forwarded only when some other mount already carries it.
_LOG_FILE_FLAG: Final = "--log-file"


def remap_path(path: str, mounts: tuple[Mount, ...]) -> str:
    """Rewrite *path* to its in-container target, using the longest matching mount source."""
    resolved = Path(path).resolve()
    best: Mount | None = None
    for mount in mounts:
        if resolved != mount.source and mount.source not in resolved.parents:
            continue
        if best is None or len(str(mount.source)) > len(str(best.source)):
            best = mount
    if best is None:
        return path
    relative = resolved.relative_to(best.source)
    return str(best.target / relative) if relative != Path() else str(best.target)


def _remap_joined_token(token: str, mounts: tuple[Mount, ...]) -> tuple[str, bool]:
    """Rewrite one token; report whether the token *after* it should be remapped too."""
    if token in REMAPPED_FLAGS:
        return token, True
    flag, sep, value = token.partition("=")
    if sep and flag in REMAPPED_FLAGS:
        return f"{flag}={remap_path(value, mounts)}", False
    return token, False


def remap_argv(argv: list[str], mounts: tuple[Mount, ...]) -> list[str]:
    """Rewrite every `REMAPPED_FLAGS` value in *argv*, split and `=`-joined forms alike."""
    out: list[str] = []
    remap_next = False
    for token in argv:
        if remap_next:
            out.append(remap_path(token, mounts))
            remap_next = False
            continue
        rewritten, remap_next = _remap_joined_token(token, mounts)
        out.append(rewritten)
    return out


def scan_flags(argv: Sequence[str], names: AbstractSet[str]) -> dict[str, str]:
    """The value each flag in *names* carries in *argv*, `--f v` and `--f=v` alike, last wins.

    The one argv value-reader: `path_flags` and the manifest's forwarded-config record both
    build on it, so the mount/forward decision and the audit record read one argv one way.
    A trailing flag with no value contributes nothing, matching argparse's refusal of it.
    *names* is a set, not any Collection: `in` on a bare `str` is substring containment, so
    `scan_flags(argv, "--config")` would answer for every flag whose name it contains.
    """
    found: dict[str, str] = {}
    pending: str | None = None
    for token in argv:
        if pending is not None:
            found[pending] = token
            pending = None
            continue
        flag, sep, value = token.partition("=")
        if sep and flag in names:
            found[flag] = value
        elif token in names:
            pending = token
    return found


def path_flags(argv: list[str]) -> dict[str, Path]:
    """The host path each `REMAPPED_FLAGS` entry in *argv* names, so each can be mounted.

    Read back out of argv rather than threaded down from the parsers: argv is the one place
    every value is guaranteed to be, and `Config` does not retain the path it was loaded from.
    """
    return {flag: Path(value) for flag, value in scan_flags(argv, REMAPPED_FLAGS).items()}


def _crossable(value: str, mounts: tuple[Mount, ...]) -> str | None:
    """*value* as the container should see it, or None when nothing mounts the host path it names.

    Prefix allowlisting alone lets a host-path-valued var cross as a path that does not exist in
    the container, overriding what the image configured. A value that is not an existing
    absolute host path is not a path at all -- it crosses untouched.
    """
    try:
        candidate = Path(value)
        if not candidate.is_absolute() or not candidate.exists():
            return value
    except (OSError, ValueError):
        return value
    mapped = remap_path(value, mounts)
    return mapped if mapped != value else None


def _ev_host_path(key: str, value: str) -> str:
    """An EV input path (`EV_PATH_ENV`) as host EV reads it, `~` and a relative path included."""
    if key not in EV_PATH_ENV or not value.strip():
        return value
    return str(Path(value.strip()).expanduser().absolute())


def _telemetry_refused(key: str, allow_prefixes: frozenset[str]) -> bool:
    """Whether *key* is a tracing var whose namespace no operator allowlisted."""
    blocking = {p for p in _TELEMETRY_PREFIXES if key.startswith(p)}
    return bool(blocking) and not (blocking & allow_prefixes)


def _drop_stray_v1_tracing(kept: dict[str, str]) -> None:
    """Remove a v1 tracing var that would raise at callback setup, in place."""
    if any(kept.get(gate) == "true" for gate in _V2_TRACING_GATES):
        return
    for name in _V1_TRACING:
        kept.pop(name, None)


def filter_env(
    env: Mapping[str, str],
    policy: EnvPolicy,
    forced: Mapping[str, str],
    mounts: tuple[Mount, ...],
) -> dict[str, str]:
    """Keep only the *env* entries *policy* lets cross whose values mean something in the container.

    Four rules beyond the policy: `_NEVER_CROSS` names are refused outright, a tracing namespace
    crosses only when allowlisted by name, a host-path value is remapped through *mounts* or
    dropped, and a stray v1 tracing var is sanitized. *forced* -- the state dir, the host repo
    path, the containment nonce -- is applied last, so no host value can win over it and it is
    never value-filtered.
    """
    kept: dict[str, str] = {}
    for key, value in env.items():
        if key in _NEVER_CROSS or _telemetry_refused(key, policy.allowlist):
            continue
        if not policy.crosses(key):
            continue
        crossable = _crossable(_ev_host_path(key, value), mounts)
        if crossable is not None:
            kept[key] = crossable
    _drop_stray_v1_tracing(kept)
    kept.update(forced)
    return kept


def _forwarded_log_flags(log_flags: Sequence[str], mounts: tuple[Mount, ...]) -> list[str]:
    """The captured log flags as the container can honour them, in flag/value pairs.

    An unmounted `--log-file` would write the log inside the container, where it dies with it;
    dropping it leaves the relayed stderr as the run's log.
    """
    out: list[str] = []
    pending: str | None = None
    for token in log_flags:
        if pending is None:
            pending = token
            continue
        if pending != _LOG_FILE_FLAG:
            out += [pending, token]
        elif (mapped := remap_path(token, mounts)) != token:
            out += [pending, mapped]
        pending = None
    return out


def forwarded_argv(
    argv: list[str],
    mounts: tuple[Mount, ...],
    *,
    config_path: Path,
    nonce: str,
    log_flags: Sequence[str] = (),
) -> list[str]:
    """The contained argv: *argv* remapped, plus the flags the gate must state explicitly.

    Order is pinned: subcommand, the provenance nonce, the original arguments, then
    `--config <remapped>` and the log flags. In-container cwd is never the gate's, so an
    implicit `--config` would resolve to the image's packaged default instead of the profile
    that asked for containment; the log flags were consumed host-side before
    the gate saw them, so they are re-stated here.
    """
    out = remap_argv(argv, mounts)
    # `containment_eligible` guarantees argv[0] is the subcommand, so index 1 is after it.
    out[1:1] = [CONTAINED_FLAG, nonce]
    if "--config" not in path_flags(argv):
        out += ["--config", remap_path(str(config_path), mounts)]
    return out + _forwarded_log_flags(log_flags, mounts)


__all__ = [
    "REMAPPED_FLAGS",
    "filter_env",
    "forwarded_argv",
    "path_flags",
    "remap_argv",
    "remap_path",
    "scan_flags",
]
