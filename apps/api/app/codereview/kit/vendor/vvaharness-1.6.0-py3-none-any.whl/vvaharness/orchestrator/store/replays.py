# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Exploit-verification replay bundles and probe logs, per run."""
from __future__ import annotations
from vvaharness.util import logs

import sqlite3

from vvaharness.orchestrator.store._db import (
    _REPLAY_MAX_BYTES,
    _current_instance,
    _touch_run,
    _validated_instance_id,
    connect,
)
from vvaharness.util.events import Event

log = logs.get_logger(__name__)


def save_replays(run_id: str, items: list[tuple[str, bytes]], *,
                 instance_id: str | None = None) -> int:
    """Replace this instance's exploit-verification replay bundles with ``items``."""
    # Replaces the whole set: call ONLY when EV ran, else a SAST rescan clears it; JSON not pickle
    inst = instance_id or _current_instance()
    con = connect()
    written = 0
    try:
        with con:
            _touch_run(con, run_id)
            con.execute("DELETE FROM ev_replays WHERE run_id = ? AND instance_id = ?",
                        (run_id, inst))
            for key, blob in items:
                if len(blob) > _REPLAY_MAX_BYTES:
                    log.warning(Event.REPLAY_TOO_LARGE, key=key[:12], size=len(blob),
                                cap=_REPLAY_MAX_BYTES)
                    continue
                con.execute(
                    "INSERT OR REPLACE INTO ev_replays"
                    "(run_id, instance_id, finding_key, payload, size) "
                    "VALUES (?, ?, ?, ?, ?)", (run_id, inst, key, blob, len(blob)))
                written += 1
    finally:
        con.close()
    return written


def prune_replays(run_id: str, keep_keys, *, instance_id: str | None = None) -> int:
    """Drop this instance's replay bundles whose ``finding_key`` is not in ``keep_keys``."""
    # save_replays runs end of S6, BEFORE S7 dedup; call only post-dedup, so empty keep_keys clears
    keep = set(keep_keys or ())
    stale: list[str] = []
    inst = instance_id or _current_instance()
    con = connect()
    try:
        with con:
            rows = con.execute("SELECT finding_key FROM ev_replays "
                               "WHERE run_id = ? AND instance_id = ?",
                               (run_id, inst)).fetchall()
            stale = [r[0] for r in rows if r[0] not in keep]
            for key in stale:
                con.execute("DELETE FROM ev_replays WHERE run_id = ? AND instance_id = ? "
                            "AND finding_key = ?", (run_id, inst, key))
    finally:
        con.close()
    return len(stale)


def _latest_instance_with(con: sqlite3.Connection, table: str, run_id: str) -> str | None:
    """Newest instance of *run_id* with rows in *table* (a module-local literal, never caller input)."""
    row = con.execute(f"SELECT instance_id FROM {table} WHERE run_id = ? "
                      "ORDER BY created_at DESC, rowid DESC LIMIT 1",
                      (run_id,)).fetchone()
    if row is None:
        return None
    return _validated_instance_id(row[0], source=f"the {table} table")


def latest_replay_instance(run_id: str) -> str | None:
    """The instance an unqualified :func:`load_replays` would read, or ``None`` if the run holds no bundles."""
    # ev-replay writes its report to that instance's dir: resolve once so bundles and dir match
    con = connect()
    try:
        return _latest_instance_with(con, "ev_replays", run_id)
    finally:
        con.close()


def load_replays(run_id: str, instance_id: str | None = None) -> list[tuple[str, bytes]]:
    """Return one instance's replay bundles as ``[(finding_key, payload_bytes), …]``, oldest first (stable order for..."""
    # ev-replay has no instance of its own: unqualified reads the newest instance with bundles, never a mix
    con = connect()
    try:
        inst = instance_id or _latest_instance_with(con, "ev_replays", run_id)
        if inst is None:
            return []
        rows = con.execute(
            "SELECT finding_key, payload, size FROM ev_replays "
            "WHERE run_id = ? AND instance_id = ? ORDER BY created_at, finding_key",
            (run_id, inst)).fetchall()
    finally:
        con.close()
    out: list[tuple[str, bytes]] = []
    for key, payload, _size in rows:
        # The payload's own length, not the stored `size`, which a direct INSERT sets independently
        if len(payload or b"") > _REPLAY_MAX_BYTES:
            log.warning(Event.REPLAY_STORED_TOO_LARGE, key=key[:12], cap=_REPLAY_MAX_BYTES)
            continue
        out.append((key, payload))
    return out


def delete_replays(run_id: str) -> int:
    """Drop this run's replay bundles. Returns rows deleted."""
    # Run-wide on purpose: operator eviction of a target's bundles, not one scan's
    con = connect()
    try:
        with con:
            cur = con.execute("DELETE FROM ev_replays WHERE run_id = ?", (run_id,))
            return cur.rowcount or 0
    finally:
        con.close()


#: ``ev_probes`` columns in insert order; omitted -> NULL, extra -> ignored (caller is not trusted)
_EV_PROBE_COLS = (
    "finding_key", "finding_title", "file", "line_start", "line_end", "cwe", "vuln_class",
    "ev_class", "ev_subtype", "ev_verdict", "endpoint_method", "endpoint_path",
    "payload_label", "injection_point", "req_method", "req_url", "req_query", "req_body",
    "authed", "auth_applied", "resp_status", "resp_ms", "resp_snippet")


def save_ev_probes(run_id: str, rows: list[dict], *,
                   instance_id: str | None = None) -> int:
    """Replace this instance's exploit-verification probe log with ``rows``."""
    # Replaces the set: call ONLY when EV ran; router._probe_rows redacts, auth_applied has no token
    cols = ", ".join(_EV_PROBE_COLS)
    ph = ", ".join("?" for _ in _EV_PROBE_COLS)
    inst = instance_id or _current_instance()
    con = connect()
    written = 0
    try:
        with con:
            _touch_run(con, run_id)
            con.execute("DELETE FROM ev_probes WHERE run_id = ? AND instance_id = ?",
                        (run_id, inst))
            for r in rows:
                con.execute(
                    f"INSERT INTO ev_probes(run_id, instance_id, {cols}) "
                    f"VALUES (?, ?, {ph})",
                    (run_id, inst, *(r.get(c) for c in _EV_PROBE_COLS)))
                written += 1
    finally:
        con.close()
    return written


def load_ev_probes(run_id: str, instance_id: str | None = None) -> list[dict]:
    """One instance's stored probes for ``run_id`` as column dicts, in insertion order."""
    # Unqualified (the standalone probe readers) resolves to the newest instance with rows
    con = connect()
    try:
        inst = instance_id or _latest_instance_with(con, "ev_probes", run_id)
        if inst is None:
            return []
        con.row_factory = sqlite3.Row
        cur = con.execute(
            f"SELECT id, run_id, instance_id, {', '.join(_EV_PROBE_COLS)}, created_at "
            f"FROM ev_probes WHERE run_id = ? AND instance_id = ? ORDER BY id",
            (run_id, inst))
        return [dict(row) for row in cur.fetchall()]
    finally:
        con.close()
