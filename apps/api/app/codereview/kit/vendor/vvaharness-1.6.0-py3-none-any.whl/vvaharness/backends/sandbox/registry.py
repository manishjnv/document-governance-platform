# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Sandbox registry: maps `via` strings to lazy `Sandbox` factory callables.

Each factory imports its own client library inside the function body, so selecting `none`
never imports `docker`.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from vvaharness.backends.sandbox.models import Capability, SandboxUnavailableError

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping, Sequence

    from vvaharness.backends.sandbox.models import SandboxSpec
    from vvaharness.backends.sandbox.protocol import Sandbox


class _NoSandbox:
    """The `via: none` default: no containment, and `run` is never reached."""

    @property
    def capabilities(self) -> Capability:
        """Nothing, which is why every level above `none` refuses on this backend."""
        return Capability.NOTHING

    def preflight(self, spec: SandboxSpec) -> None:
        """Nothing to verify; this backend never runs anything."""

    def run(self, argv: Sequence[str], env: Mapping[str, str], timeout: float | None) -> int:
        """Never called: `entry.maybe_contain` returns `None` before reaching a real backend.

        Raises:
            RuntimeError: Always.
        """
        msg = "NoSandbox.run() should never be called; sandboxing was not requested"
        raise RuntimeError(msg)

    def teardown(self) -> None:
        """Nothing to release."""


def _make_docker() -> Sandbox:
    """Build the Docker backend, translating a missing optional extra into a clear refusal.

    Raises:
        SandboxUnavailableError: If the `docker` distribution is not installed.
    """
    try:
        from vvaharness.backends.sandbox.docker.backend import (  # noqa: PLC0415 — lazy: docker is optional
            DockerSandbox,
        )
    except ImportError as exc:
        msg = "the docker sandbox backend needs the 'docker' package: pip install '.[sandbox]'"
        raise SandboxUnavailableError(msg) from exc

    return DockerSandbox()


_BACKENDS: dict[str, Callable[[], Sandbox]] = {
    "none": _NoSandbox,
    "docker": _make_docker,
}


def get_sandbox(via: str | None) -> Sandbox:
    """Return a fresh `Sandbox` instance for the given *via* selector.

    Raises:
        ValueError: If *via* is not a registered backend key.
    """
    key = via or "none"
    factory = _BACKENDS.get(key)
    if factory is None:
        valid = ", ".join(f'"{k}"' for k in _BACKENDS)
        raise ValueError(f"unknown sandbox backend {key!r}; valid values are: {valid}")
    return factory()


def register_sandbox(via: str, factory: Callable[[], Sandbox]) -> None:
    """Add a third-party `Sandbox` backend under *via*.

    Raises:
        ValueError: If *via* collides with a built-in backend name.
    """
    if via in _BACKENDS:
        msg = f"{via!r} is already a built-in sandbox backend"
        raise ValueError(msg)
    _BACKENDS[via] = factory


__all__ = ["get_sandbox", "register_sandbox"]
