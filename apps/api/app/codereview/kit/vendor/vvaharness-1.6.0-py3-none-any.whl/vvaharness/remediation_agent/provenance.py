# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Which on-disk finding cases this machine's S10 remediation actually produced.

``security-remediation/`` lives INSIDE the scanned repository, which is untrusted
input: a committed ``finding_case.json`` (or a committed directory that symlinks
one in) can plant a case that S11 would otherwise treat as real. The state store
(``~/.vvaharness/state``, mode 0600) lives OUTSIDE the repo, so a checkout cannot
forge a row in it. :func:`owned_cases` is the read side of that trust boundary:
every S10 ``remediate_<digest>`` checkpoint row this run wrote names the finding
id and the artifact directory it wrote, and only a case matching BOTH is treated
as this run's own.
"""

from __future__ import annotations

from pathlib import Path

from vvaharness.orchestrator import store
from vvaharness.orchestrator.checkpoints import (
    REMEDIATE_PREFIX,
    contained_repo_path,
    load_ckpt,
)

__all__ = ["owned_cases"]

#: Mirrors backends.sandbox.config.REPO_TARGET as a literal, not an import: the sandbox package
#: must stay off every validate run's import path.
_CONTAINED_REPO = Path("/workspace")


def owned_cases(run_id: str, repo: Path | str | None = None) -> set[tuple[str, Path]]:
    """Return ``{(finding_id, artifact_dir.resolve()), ...}`` for every S10 record *run_id* holds.

    Matching on both the finding id AND the resolved artifact directory (not
    either alone) stops a planted case that reuses a real case id under a
    different slug directory, or that reuses a real slug with a different id.

    With *repo*, a directory recorded under the other side's name for the repository (the
    container's mount, or the host path from inside one) is re-rooted onto *repo*, so a host
    run and a contained run of the same target recognise each other's cases. Only the root
    changes; the slug directory must still match exactly.
    """
    roots = _repo_roots(repo) if repo is not None else ()
    owned: set[tuple[str, Path]] = set()
    for step in store.steps_with_prefix(run_id, REMEDIATE_PREFIX):
        record = load_ckpt(Path(), run_id, step)
        if not isinstance(record, dict):
            continue
        finding_id = record.get("finding_id")
        artifact_dir = record.get("artifact_dir")
        if not finding_id or not artifact_dir:
            continue
        try:
            owned.add((finding_id, _rebased(Path(artifact_dir).resolve(), roots)))
        except OSError:
            continue
    return owned


def _repo_roots(repo: Path | str) -> tuple[Path, ...]:
    """*repo* resolved, then every name the same repository has on either side of the mount."""
    here = Path(repo).resolve()
    return (here, Path(contained_repo_path(repo)).resolve(), _CONTAINED_REPO)


def _rebased(path: Path, roots: tuple[Path, ...]) -> Path:
    """*path* moved from whichever of *roots* it sits under onto ``roots[0]``; else unchanged."""
    for root in roots:
        if path.is_relative_to(root):
            return (roots[0] / path.relative_to(root)).resolve()
    return path
