# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Transactional project-local trusted plugin runner."""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass

from vvaharness.context_graph_sdk.errors import ModelValidationError, PluginError
from vvaharness.context_graph_sdk.models import (
    AnalysisVersion,
    FrozenMap,
    GraphEdge,
    GraphMutation,
    GraphNode,
    GraphSnapshot,
    freeze_properties,
)
from vvaharness.context_graph_sdk.pipeline import PluginContext, PluginDiagnostic, SourceReader

from .base import PluginMetadata, PluginPhase
from .context import BufferedPluginReporter, CancellationToken, PluginLogRecord
from .registry import PluginRegistry

DEFAULT_LOCAL_PLUGIN_TIMEOUT_SECONDS = 300.0


@dataclass(frozen=True)
class LocalPluginLimits:
    max_nodes_per_plugin: int = 10_000
    max_edges_per_plugin: int = 20_000
    max_removals_per_plugin: int = 20_000
    max_total_work: int = 50_000

    def __post_init__(self) -> None:
        if (
            min(
                self.max_nodes_per_plugin,
                self.max_edges_per_plugin,
                self.max_removals_per_plugin,
                self.max_total_work,
            )
            <= 0
        ):
            raise ModelValidationError("local plugin limits must be positive")


@dataclass(frozen=True)
class LocalPluginResult:
    snapshot: GraphSnapshot
    executed: tuple[PluginMetadata, ...]
    logs: tuple[PluginLogRecord, ...]
    diagnostics: tuple[PluginDiagnostic, ...]


class LocalPluginRunner:
    def __init__(self, limits: LocalPluginLimits | None = None) -> None:
        self._limits = limits or LocalPluginLimits()

    def run(
        self,
        snapshot: GraphSnapshot,
        registry: PluginRegistry,
        *,
        source_reader: SourceReader,
        cancellation: CancellationToken,
        deadline_monotonic: float,
        configuration: FrozenMap,
        derive: Callable[[GraphSnapshot], GraphSnapshot] | None = None,
    ) -> LocalPluginResult:
        current = snapshot
        reporter = BufferedPluginReporter()
        executed: list[PluginMetadata] = []
        total_work = 0
        context_label = (
            f"project={snapshot.project.project_id.value},snapshot={snapshot.snapshot_id.value}"
        )
        for phase in (PluginPhase.PRE_DERIVATION, PluginPhase.POST_DERIVATION):
            for plugin in registry.for_phase(phase):
                metadata = plugin.metadata
                self._check_lifecycle(metadata, cancellation, deadline_monotonic, context_label)
                context = PluginContext(
                    snapshot.project,
                    current,
                    source_reader,
                    reporter,
                    cancellation,
                    configuration,
                    deadline_monotonic,
                )
                try:
                    mutation = _require_mutation(plugin.enrich(context))
                    work = self._validate_bounds(mutation)
                    mutation = _stamp_provenance(mutation, metadata)
                    if total_work + work > self._limits.max_total_work:
                        raise ModelValidationError("aggregate local plugin work exceeds bound")
                    candidate = _apply_mutation(current, mutation)
                    self._check_lifecycle(metadata, cancellation, deadline_monotonic, context_label)
                    candidate = _record_component(candidate, metadata)
                except PluginError as exc:
                    # Preserve runner-created lifecycle errors; recontextualize
                    # plugin-created errors so registry metadata stays authoritative.
                    if (
                        exc.plugin_name == metadata.name
                        and exc.phase == metadata.phase.value
                        and exc.context == context_label
                    ):
                        raise
                    raise PluginError(
                        metadata.name,
                        metadata.phase.value,
                        str(exc),
                        context=context_label,
                    ) from exc
                except Exception as exc:
                    raise PluginError(
                        metadata.name,
                        metadata.phase.value,
                        str(exc),
                        context=context_label,
                    ) from exc
                current = candidate
                total_work += work
                executed.append(metadata)
            if phase == PluginPhase.PRE_DERIVATION and derive is not None:
                derivation_started = time.monotonic()
                derived = derive(current)
                # The deadline bounds plugin work; derivation is engine work that grows
                # with the graph
                deadline_monotonic += time.monotonic() - derivation_started
                if (
                    derived.project != snapshot.project
                    or derived.snapshot_id != snapshot.snapshot_id
                ):
                    raise ModelValidationError(
                        "derived graph changed the candidate project or snapshot identity"
                    )
                current = derived
        return LocalPluginResult(current, tuple(executed), reporter.logs, reporter.diagnostics)

    def _validate_bounds(self, mutation: GraphMutation) -> int:
        removals = len(mutation.removed_node_ids) + len(mutation.removed_edge_ids)
        if len(mutation.nodes) > self._limits.max_nodes_per_plugin:
            raise ModelValidationError("plugin node emission exceeds bound")
        if len(mutation.edges) > self._limits.max_edges_per_plugin:
            raise ModelValidationError("plugin edge emission exceeds bound")
        if removals > self._limits.max_removals_per_plugin:
            raise ModelValidationError("plugin removal emission exceeds bound")
        return len(mutation.nodes) + len(mutation.edges) + removals

    @staticmethod
    def _check_lifecycle(
        metadata: PluginMetadata,
        cancellation: CancellationToken,
        deadline_monotonic: float,
        context: str,
    ) -> None:
        if cancellation.is_cancelled:
            raise PluginError(
                metadata.name,
                metadata.phase.value,
                "plugin execution cancelled",
                context=context,
            )
        if time.monotonic() >= deadline_monotonic:
            raise PluginError(
                metadata.name,
                metadata.phase.value,
                "plugin execution deadline exceeded",
                context=context,
            )


def _require_mutation(value: object) -> GraphMutation:
    if not isinstance(value, GraphMutation):
        raise ModelValidationError("plugin must return GraphMutation")
    return value


def _stamp_provenance(mutation: GraphMutation, metadata: PluginMetadata) -> GraphMutation:
    expected = {"pluginName": metadata.name, "pluginVersion": metadata.version}

    def properties_with_provenance(properties: FrozenMap) -> FrozenMap:
        values = properties.to_dict()
        for key, value in expected.items():
            if key in values and values[key] != value:
                raise ModelValidationError(f"plugin cannot override reserved {key} provenance")
            values[key] = value
        return freeze_properties(values)

    nodes = tuple(
        GraphNode(
            node.project_id,
            node.local_id,
            node.labels,
            properties_with_provenance(node.properties),
        )
        for node in mutation.nodes
    )
    edges = tuple(
        GraphEdge(
            edge.project_id,
            edge.source_id,
            edge.relationship_type,
            edge.target_id,
            edge.discriminator,
            properties_with_provenance(edge.properties),
        )
        for edge in mutation.edges
    )
    return GraphMutation(
        mutation.project_id,
        nodes,
        edges,
        mutation.removed_node_ids,
        mutation.removed_edge_ids,
    )


def _record_component(snapshot: GraphSnapshot, metadata: PluginMetadata) -> GraphSnapshot:
    name = f"plugin:{metadata.phase.value}:{metadata.name}"
    components = dict(snapshot.analysis_version.components)
    existing_version = components.get(name)
    if existing_version is not None and existing_version != metadata.version:
        raise ModelValidationError("plugin component version conflicts with analysis metadata")
    components[name] = metadata.version
    analysis_version = AnalysisVersion(
        snapshot.analysis_version.sdk_version,
        tuple(components.items()),
    )
    return GraphSnapshot(
        snapshot.project,
        snapshot.snapshot_id,
        analysis_version,
        snapshot.nodes,
        snapshot.edges,
    )


def _apply_mutation(snapshot: GraphSnapshot, mutation: GraphMutation) -> GraphSnapshot:
    if mutation.project_id != snapshot.project.project_id:
        raise ModelValidationError("plugin mutation targets another project")
    nodes: dict[str, GraphNode] = {node.id: node for node in snapshot.nodes}
    edges: dict[str, GraphEdge] = {edge.id: edge for edge in snapshot.edges}
    missing_nodes = set(mutation.removed_node_ids).difference(nodes)
    removed_edge_ids = set(mutation.removed_edge_ids)
    missing_edges = removed_edge_ids.difference(edges)
    if missing_nodes or missing_edges:
        raise ModelValidationError("plugin mutation removes unknown graph identities")
    remaining_edges = {
        edge_id: edge for edge_id, edge in edges.items() if edge_id not in removed_edge_ids
    }
    remaining_endpoints = {
        endpoint
        for edge in remaining_edges.values()
        for endpoint in (edge.source_id, edge.target_id)
    }
    for node_id in mutation.removed_node_ids:
        if node_id in remaining_endpoints:
            raise ModelValidationError(
                "plugin must explicitly remove edges incident to removed nodes"
            )
        del nodes[node_id]
    for edge_id in mutation.removed_edge_ids:
        edges.pop(edge_id)
    for node in mutation.nodes:
        if node.id in nodes:
            raise ModelValidationError("plugin adds an existing node identity")
        nodes[node.id] = node
    for edge in mutation.edges:
        if edge.id in edges:
            raise ModelValidationError("plugin adds an existing edge identity")
        if edge.source_id not in nodes or edge.target_id not in nodes:
            raise ModelValidationError("plugin edge endpoints must exist in the candidate graph")
        edges[edge.id] = edge
    return GraphSnapshot(
        snapshot.project,
        snapshot.snapshot_id,
        snapshot.analysis_version,
        tuple(nodes.values()),
        tuple(edges.values()),
    )
