# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Derive the whole `containers.run` argument set from a spec, rather than hand-authoring it.

The harness already computed the mounts, resolved the image and knows the level, so the plan
is derived; the operator's validated limits are the only thing merged on top.
"""

from __future__ import annotations

import os
import socket
from typing import TYPE_CHECKING, Final

from vvaharness.backends.sandbox.docker import egress, evnet
from vvaharness.backends.sandbox.docker.models import DockerLimits, EVNetwork, RunPlan
from vvaharness.backends.sandbox.models import (
    EgressMode,
    SandboxNetwork,
    SandboxSpec,
    network_for_level,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from vvaharness.backends.sandbox.models import Mount, SandboxLevel

#: Writable scratch the run cannot function without once the rootfs is read-only: Python needs
#: a temp dir, and tooling writes under HOME. Both are tmpfs, so nothing they hold can persist
#: or reach the host, and their pages are charged to this container's memory cgroup.
CONTAINER_HOME: Final = "/home/vvaharness"
_SCRATCH_TARGETS: Final[tuple[str, ...]] = ("/tmp", CONTAINER_HOME)  # noqa: S108 — in-container tmpfs, not a host temp path

#: Every capability Docker grants by default is dropped: the run reads files and makes HTTPS
#: calls, and `CAP_DAC_OVERRIDE` alone would make the mounted repo's permission bits advisory.
_CAP_DROP: Final[tuple[str, ...]] = ("ALL",)

#: Closes the setuid path permanently, which is what makes the dropped capabilities durable.
_SECURITY_OPT: Final[tuple[str, ...]] = ("no-new-privileges:true",)

#: Marks containers this harness started, so a leaked one is findable with `docker ps -f`.
_LABEL_KEY: Final = "com.visa.vvaharness.sandbox"

#: Which process on which machine started a container or network, so a later run can tell one
#: whose owner died without tearing it down (SIGKILL, a crash) from one still being watched.
OWNER_PID_LABEL: Final = f"{_LABEL_KEY}.owner-pid"
OWNER_HOST_LABEL: Final = f"{_LABEL_KEY}.owner-host"

#: The only two modes that get Docker's default bridge. Membership rather than an inequality is
#: the fail-closed half: a mode this table does not name -- `mediated`, `none`, or one added
#: later -- gets no network at all, never the open bridge.
_BRIDGE_MODES: Final[frozenset[EgressMode]] = frozenset(
    {EgressMode.OPEN, EgressMode.EV_BRIDGE}
)

#: squid's own writable paths, so the sidecar's rootfs can stay read-only like the scan's. On
#: tmpfs, so nothing it parses from the network can persist or reach the host.
_SIDECAR_SCRATCH: Final[tuple[str, ...]] = (
    "/tmp",  # noqa: S108 — in-container tmpfs, not a host temp path
    "/var/run",
    "/var/log/squid",
    "/var/spool/squid",
)

#: Stated rather than relied on: the sidecar runs as a FIXED uid the proxy image never
#: provisioned these directories for, and a tmpfs root's default mode is not part of Docker's
#: documented contract. Sticky, and nothing else shares the namespace.
_SIDECAR_SCRATCH_MODE: Final = "mode=1777"

#: The sidecar forwards CONNECT and caches nothing, so it needs neither the scan's process
#: budget nor its scratch size; the operator's `sandbox.docker:` knobs are for the scan.
_SIDECAR_LIMITS: Final = DockerLimits(pids_limit=256, tmpfs_size="64m")

#: `nobody:nogroup`, which the Debian/Ubuntu-based proxy image already has an account for.
#: FIXED, never the invoker's: its mounts are a world-readable read-only conf dir and a
#: world-writable socket volume, so it has no ownership reason to track the host user, and a
#: root invoker (Linux CI, Docker-in-Docker) would otherwise leave the one process parsing
#: attacker-influenced CONNECT traffic as uid 0 -- with `cap_drop: ALL` leaving squid unable to
#: drop that itself.
_SIDECAR_USER: Final = "65534:65534"


def _volumes(mounts: Sequence[Mount]) -> dict[str, dict[str, str]]:
    """The bind-mount table: each host source at its target, `rw` only where permitted."""
    return {
        str(mount.source): {
            "bind": str(mount.target),
            "mode": "rw" if mount.writable else "ro",
        }
        for mount in mounts
    }


def _tmpfs(limits: DockerLimits) -> dict[str, str]:
    """The scratch mounts, sized explicitly because Docker's own default is 64 MB.

    `noexec,nosuid,nodev` are Docker's defaults too, stated so that a runtime with other
    defaults cannot let a file the target drops in /tmp or HOME be executed.
    """
    return dict.fromkeys(_SCRATCH_TARGETS, f"size={limits.tmpfs_size},noexec,nosuid,nodev")


def _network_mode(network: SandboxNetwork) -> str:
    """`none` leaves the container's network namespace holding only loopback.

    Derived from the egress mode alone -- the canonical axis -- so no caller can hand this a
    level and a network that disagree. `mediated` is `none` too: its way out is the sidecar's
    socket on a shared volume, never a network, so there is no gateway for it to reach.
    `ev-bridge` IS the default bridge: EV's reach comes from `extra_hosts` and a published port,
    not from a different network driver.
    """
    return "bridge" if network.mode in _BRIDGE_MODES else "none"


def _extra_hosts(ev: EVNetwork | None) -> dict[str, str]:
    """`host.docker.internal` -> the host, on every platform.

    Passed even on Docker Desktop, where the name already resolves: an explicit /etc/hosts
    entry is consulted before any resolver, so the address the run sees is the one the gate
    forced into `VVAHARNESS_EV_HOST_GATEWAY`.
    """
    return {} if ev is None else {evnet.HOST_GATEWAY_NAME: evnet.HOST_GATEWAY_ALIAS}


def _ports(ev: EVNetwork | None) -> dict[str, tuple[str, int]]:
    """Publish the in-container OOB listener on the reserved HOST-LOOPBACK port.

    Loopback, never `0.0.0.0`: the callback is for a target on this machine, and a published
    listener on every interface would expose the harness's own OOB endpoint to the network.
    """
    if ev is None:
        return {}
    return {f"{ev.container_port}/tcp": (ev.host_ip, ev.host_port)}


def _identity() -> str:
    """The invoking host user's uid:gid, so bind-mounted output comes back correctly owned."""
    return f"{os.getuid()}:{os.getgid()}"


def owner_labels(level: SandboxLevel) -> dict[str, str]:
    """The run's labels, carried by every container, volume and network it starts.

    The sidecar, its network and the gateway probe all inherit them, so one owner covers all and
    `sweep_orphans` finds any that leaks.
    """
    return {
        _LABEL_KEY: level.value,
        OWNER_PID_LABEL: str(os.getpid()),
        OWNER_HOST_LABEL: socket.gethostname(),
    }


_labels = owner_labels  # internal name kept for the derive/derive_sidecar call sites below


def derive(spec: SandboxSpec, limits: DockerLimits, *, ev: EVNetwork | None = None) -> RunPlan:
    """Build the run plan for *spec*, with *limits* the only operator-supplied part.

    `read_only` is unconditional: the rootfs is never a legitimate write target at any level.
    The level decides the repo *mount's* mode instead, which is why a read-only rootfs and a
    remediation run that edits source are not in tension. `ev` is present only for an
    `ev-bridge` run; with it `None` the plan is exactly the non-EV plan.
    """
    network = spec.network or network_for_level(spec.level)
    return RunPlan(
        image=spec.image,
        command=(),
        environment={"HOME": CONTAINER_HOME},
        volumes=_volumes(spec.mounts),
        tmpfs=_tmpfs(limits),
        user=_identity(),
        working_dir=str(spec.workdir),
        network_mode=_network_mode(network),
        network=network,
        read_only=True,
        cap_drop=_CAP_DROP,
        security_opt=_SECURITY_OPT,
        limits=limits,
        labels=_labels(spec.level),
        timeout=spec.timeout,
        mounts=spec.mounts,
        extra_hosts=_extra_hosts(ev),
        ports=_ports(ev),
        ev=ev,
    )


def derive_sidecar(
    *, conf_dir: str, socket_volume: str, labels: Mapping[str, str],
    image: str = egress.PROXY_IMAGE, forwards: tuple[int, ...] = (),
    callback_port: int | None = None,
) -> RunPlan:
    """The mediated-egress sidecar's plan, hardened through the same `container_kwargs`.

    squid is the one process here parsing attacker-influenced CONNECT traffic, so it gets the
    scan container's treatment rather than a hand-written weaker set: read-only rootfs, every
    capability dropped, no-new-privileges, a real PID 1, a bounded process count and a uid that
    is never 0 -- which is also why it needs no SETUID/SETGID back. *image* is the id preflight
    resolved the proxy tag to, so the tag cannot move between that check and this create.
    *socket_volume* is the named volume it shares with the scan container, its only inbound path.
    *forwards* are a scoped `ev` run's ports, which socat connects to on this machine by
    `host.docker.internal`, mapped to Docker's host gateway on every platform. *callback_port*
    is the host-loopback port the sidecar publishes for that run's out-of-band callback:
    loopback, never `0.0.0.0`, so nothing off this machine reaches it.

    socat and squid run under one shell (`egress.sidecar_command`); `-N` keeps squid in the
    foreground and `-d 1` puts its startup messages on stderr, where `client._await_ready` reads
    its readiness off, beside socat's.
    """
    network = SandboxNetwork(mode=EgressMode.OPEN)
    return RunPlan(
        image=image,
        command=egress.sidecar_command(forwards, callback=callback_port is not None),
        environment={},
        volumes={
            conf_dir: {"bind": egress.CONF_TARGET, "mode": "ro"},
            socket_volume: {"bind": egress.SOCKET_TARGET, "mode": "rw"},
        },
        tmpfs=dict.fromkeys(
            _SIDECAR_SCRATCH, f"size={_SIDECAR_LIMITS.tmpfs_size},{_SIDECAR_SCRATCH_MODE}"
        ),
        user=_SIDECAR_USER,
        # Not the scan's workdir: this is the proxy image's filesystem, which has no such path.
        working_dir="/",
        network_mode=_network_mode(network),
        network=network,
        read_only=True,
        cap_drop=_CAP_DROP,
        security_opt=_SECURITY_OPT,
        limits=_SIDECAR_LIMITS,
        labels=labels,
        timeout=None,
        extra_hosts=(
            {evnet.HOST_GATEWAY_NAME: evnet.HOST_GATEWAY_ALIAS} if forwards else {}
        ),
        ports=(
            {} if callback_port is None
            else {f"{egress.CALLBACK_PORT}/tcp": (evnet.HOST_LOOPBACK, callback_port)}
        ),
    )


__all__ = ["CONTAINER_HOME", "OWNER_HOST_LABEL", "OWNER_PID_LABEL", "derive", "derive_sidecar",
           "owner_labels"]
