# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from __future__ import annotations
from vvaharness.util import logs

"""orchestrator.batch — see package docstring."""
import csv
import fnmatch
import hashlib
import itertools
import json
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
from collections.abc import Iterable, Iterator
from pathlib import Path

from vvaharness.backends.harness.models import AuthenticationError, ProxyError
from vvaharness.backends.llm import cli

# The single audited Markdown neutraliser — a hardening fix there must never leave this path behind.
from vvaharness.models import _md_cell
from vvaharness.orchestrator import store as _store
from vvaharness.orchestrator.case_rollup import EXIT_NOT_REMEDIATED
from vvaharness.orchestrator.cleanup import (
    _is_link,
    _preserve_set,
    _purge_clone,
    _rmtree_rw,
)
from vvaharness.orchestrator.cmdb import _load_app_profile
from vvaharness.orchestrator.scan import ScanOutcome, scan_repo
from vvaharness.report.redact import reset_known_values as _reset_redact_known_values
from vvaharness.util import console
from vvaharness.util import errlog as _errlog
from vvaharness.util.counters import COUNTERS
from vvaharness.util.events import Event
from vvaharness.util.response_quality import reset_counters as _reset_quality_counters
from vvaharness.util.stage_telemetry import CACHED_PROVENANCE, STAGES
from vvaharness.util.tokens import TOKENS
from vvaharness.util.warn_once import reset_warn_once_registries as _reset_warn_once

log = logs.get_logger(__name__)


def _module_name_from(ref: str) -> str:
    tail = ref.rstrip("/").split("/")[-1]
    if tail.lower().endswith(".git"):
        tail = tail[:-4]
    return tail or "repo"


def _clone_dir_name(name: str) -> str:
    """The workspace directory name for a clone of `name`: path-hostile characters become ``_``."""
    return "".join(c if c.isalnum() or c in "._-" else "_" for c in name)


def _app_dir_name(app_id: str) -> str:
    """The workspace directory name for an application group; app ids come from the operator or the CMDB, so the name is sanitised and "../x" and "." cannot escape the workspace."""
    return _clone_dir_name(str(app_id)).strip(".") or "app"


def _require_plain_dir(path: Path, what: str) -> None:
    """Refuse a *path* that exists as a link or as anything but a directory.

    A batch workspace can be shared, so the entry named after an application or a repository can
    be planted by someone else. A link there would send staging, the scan and the purge to
    wherever it points, outside the workspace.
    """
    if os.path.lexists(path) and (_is_link(path) or not path.is_dir()):
        raise RuntimeError(
            f"refusing {what} {path}: it is a link or not a directory, so staging, the scan "
            f"and the cleanup would act on what it points at instead of the workspace. "
            f"Remove it, or use a workspace only this account can write to.")


def _replace_planted_link(dest: Path) -> None:
    """Remove a link standing at a clone/copy destination so it is never reused or cloned through."""
    if _is_link(dest):
        console.write(f"  [batch] {dest} is a link — removing the link (not its target)")
        _rmtree_rw(dest)
        if _is_link(dest):
            raise RuntimeError(f"could not remove the link at {dest}; refusing to stage through it")


def _is_url(ref: str) -> bool:
    return ref.startswith(("http://", "https://", "git@", "ssh://"))


# Scheme allow-list only: a ".git" suffix must not make `ext::<cmd> x.git` a clone URL.
def _is_remote(ref: str) -> bool:
    return _is_url(ref)


# Overrides every protocol.* config, so git refuses ext::/fd::/file:// even on a host that enabled them.
_GIT_ALLOW_PROTOCOL = "http:https:ssh"


# Strip `scheme://user:token@host` userinfo down to `scheme://***@host` so an inline credential in a repo URL never reaches stderr, an error string, or the batch summary.
_URL_USERINFO_RX = re.compile(r"(\w[\w+.\-]*://)[^/@\s]+@")


def _scrub_url_secrets(s: str) -> str:
    if not s:
        return s
    return _URL_USERINFO_RX.sub(r"\1***@", s)


def _clone_url_for(repo_name: str, base: str) -> str:
    """RepoName is the full repo slug — '{base}/{repo_name}.git'."""
    return f"{base.rstrip('/')}/{repo_name}.git"


# A staged repo is bound to the repo it was created from via a marker kept in the operator-private state dir, so a writer who controls only the (shared) workspace cannot forge reuse of a stale/foreign/pre-seeded dir.
def _state_root() -> Path:
    return _store.state_root()


def _ref_id(ref: str) -> str:
    """Stable, token-free id for a repo ref — the original csv URL / local path, not the token-bearing clone URL."""
    return hashlib.sha256(str(ref).encode("utf-8")).hexdigest()[:32]


def _stage_marker_path(dest: Path) -> Path:
    key = hashlib.sha256(str(Path(dest).resolve()).encode("utf-8")).hexdigest()[:32]
    return _state_root() / "stage-markers" / f"{key}.json"


def _write_stage_marker(dest: Path, ref: str, kind: str) -> None:
    """Record that `dest` was staged from `ref`. Best-effort — a marker-write failure just means the next run re-stages."""
    mp = _stage_marker_path(dest)
    try:
        # Via store so the dir isn't umask-default: a marker a foreign writer can read is forgeable
        _store.ensure_state_dir("stage-markers")
        mp.write_text(json.dumps({"v": 1, "kind": kind, "ref_id": _ref_id(ref)}),
                      encoding="utf-8")
    except OSError as e:
        log.warning(Event.BATCH_MARKER_WRITE_FAILED, path=dest, detail=str(e))


def _stage_dir_bound(dest: Path, ref: str) -> bool:
    """True iff `dest` carries a state-dir marker proving it was staged from `ref` by a prior run; missing/mismatched/corrupt means the caller must re-stage."""
    try:
        data = json.loads(_stage_marker_path(dest).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    return isinstance(data, dict) and data.get("ref_id") == _ref_id(ref)


def _assign_slugs(repos: list[dict]) -> list[str]:
    """Map each repo in an app group to a UNIQUE staging slug, so two repo names with the same tail don't collide and silently reuse one dir."""
    slugs: list[str] = []
    used: set[str] = set()
    for r in repos:
        base = _module_name_from(r["repo_name"])
        slug = base
        salt = r["repo_name"]
        while slug in used:
            slug = f"{base}-{hashlib.sha1(salt.encode('utf-8')).hexdigest()[:8]}"
            salt = slug + r["repo_name"]
        used.add(slug)
        slugs.append(slug)
    return slugs


# Bounds the decode/parse so an oversized or pathological manifest fails fast instead of OOM-killing the batch runner; caps are deliberately generous.
_MANIFEST_MAX_BYTES = 64 * 1024 * 1024      # 64 MiB on disk
_MANIFEST_MAX_ROWS = 200_000                # data rows / physical lines


def _check_manifest_size(list_file: Path) -> None:
    """Reject a manifest larger than the byte cap before it is decoded into memory; raises ValueError (caught by run_batch -> exit 2)."""
    try:
        size = list_file.stat().st_size
    except OSError as e:
        raise ValueError(f"{list_file}: cannot stat manifest: {e}")
    if size > _MANIFEST_MAX_BYTES:
        raise ValueError(
            f"{list_file}: manifest is {size} bytes, over the "
            f"{_MANIFEST_MAX_BYTES // (1024 * 1024)} MiB cap — split the batch "
            f"into smaller manifests")


BATCH_WORKSPACE_DEFAULT = "./batch-workspace"


def _csv_columns(header: list[str]) -> tuple[dict[str, int], int | None, int | None, int | None]:
    """Header index map plus the AppID, RepoName and Path column indexes (case-insensitive aliases)."""
    hdr = {str(h).strip().lower(): i for i, h in enumerate(header) if h}

    def col(*names: str) -> int | None:
        for n in names:
            if n in hdr:
                return hdr[n]
        return None
    return (hdr,
            col("appid", "application_id", "app_id", "applicationid"),
            col("reponame", "repository_name", "repo_name", "repo"),
            col("path", "url", "repo_url", "ref"))


def _txt_records(fh: Iterable[str], list_file: Path) -> Iterator[tuple[int, list[str]]]:
    """Yield ``(lineno, fields)`` for each non-blank, non-comment line of a .txt batch sheet; raises past the line cap."""
    for lineno, raw in enumerate(fh, 1):
        if lineno > _MANIFEST_MAX_ROWS:
            raise ValueError(
                f"{list_file}: over {_MANIFEST_MAX_ROWS} lines — "
                f"split the batch into smaller manifests")
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        yield lineno, [p.strip() for p in line.split(",")]


def _cell(row: list[str], i: int | None) -> str:
    return "" if i is None or i >= len(row) else str(row[i]).strip()


def manifest_rows(list_file: Path) -> tuple[tuple[str, str, str], ...]:
    """Every ``(app_id, repo_name, ref)`` a batch sheet holds, read tolerantly: never raises, and keeps the rows read before any error."""
    rows: list[tuple[str, str, str]] = []
    try:
        if not list_file.is_file():
            return ()
        _check_manifest_size(list_file)
        if list_file.suffix.lower() == ".csv":
            with open(list_file, newline="", encoding="utf-8-sig", errors="surrogateescape") as fh:
                reader = csv.reader(fh)
                header = next(reader, None)
                if header is not None:
                    _, i_app, i_repo, i_path = _csv_columns(header)
                    for row in itertools.islice(reader, _MANIFEST_MAX_ROWS):
                        rows.append((_cell(row, i_app), _cell(row, i_repo), _cell(row, i_path)))
        else:
            with open(list_file, encoding="utf-8", errors="surrogateescape") as fh:
                rows.extend((p[0], p[1], p[2]) for _, p in _txt_records(fh, list_file) if len(p) == 3)
    except (OSError, ValueError, csv.Error):
        pass  # fewer boundaries only; run_batch re-reads the sheet and reports the error
    return tuple(rows)


def scan_boundaries(repo: str | None, repo_file: str | None, workspace: str | None) -> tuple[str, ...]:
    """The directories a scan command reads at start: the `--repo` path, or a batch's local entries and the existing workspace directories its rows stage into."""
    if repo is not None:
        return (repo,)
    if repo_file is None:
        return ()
    rows = manifest_rows(Path(repo_file))
    ws = Path(workspace if workspace is not None else BATCH_WORKSPACE_DEFAULT)
    names: list[str] = []
    for app_id, repo_name, ref in rows:
        if app_id:
            names.append(_app_dir_name(app_id))
        if repo_name and (not ref or _is_remote(ref)) and _clone_dir_name(repo_name).strip("."):
            names.append(_clone_dir_name(repo_name))
    local = (ref for _, _, ref in rows if ref and not _is_url(ref))
    staged = (str(ws / n) for n in dict.fromkeys(names) if os.path.isdir(ws / n))
    return tuple(dict.fromkeys((*local, *staged)))


def _parse_repo_csv(list_file: Path, git_base_url: str | None) -> list[dict]:
    """Parse a .csv batch sheet with an AppID/RepoName[/Path] header (case-insensitive aliases accepted)."""
    _check_manifest_size(list_file)
    # Stream the reader rather than list(csv.reader(fh)) so a manifest is never fully materialized into memory before validation.
    with open(list_file, newline="", encoding="utf-8-sig") as fh:
        rows = csv.reader(fh)
        try:
            header = next(rows)
        except StopIteration:
            raise ValueError(f"{list_file}: empty file")

        hdr, i_app, i_repo, i_path = _csv_columns(header)
        if i_app is None or i_repo is None:
            raise ValueError(
                f"{list_file}: header must contain AppID and RepoName columns "
                f"(found: {list(hdr.keys())})")
        if i_path is None and not git_base_url:
            raise ValueError(
                f"{list_file}: no Path column and batch.git_base_url is not set — "
                f"cannot derive clone URLs")

        entries: list[dict] = []
        errors: list[str] = []
        seen: set[str] = set()
        for lineno, row in enumerate(rows, 2):
            if lineno - 1 > _MANIFEST_MAX_ROWS:
                raise ValueError(
                    f"{list_file}: over {_MANIFEST_MAX_ROWS} data rows — "
                    f"split the batch into smaller manifests")
            app_id, repo_name, ref = (_cell(row, i) for i in (i_app, i_repo, i_path))
            if not app_id and not repo_name:
                continue
            if not app_id or not repo_name:
                errors.append(f"row {lineno}: AppID and RepoName are both required")
                continue
            if not ref:
                # A blank Path cell can only be resolved when git_base_url is set; otherwise this is a validation error caught up-front, not an opaque AttributeError mid-derive.
                if not git_base_url:
                    errors.append(
                        f"row {lineno}: Path is blank and batch.git_base_url is "
                        f"not set — cannot derive a clone URL")
                    continue
                ref = _clone_url_for(repo_name, git_base_url)
            if ref.lstrip().startswith("-"):
                # A leading "-" would be consumed by `git clone` as an option rather than a URL operand. Reject up front.
                errors.append(f"row {lineno}: path '{ref}' may not start with '-'")
                continue
            if not _is_remote(ref) and not Path(ref).is_dir():
                errors.append(f"row {lineno}: path '{ref}' is neither a git URL "
                              f"nor an existing local directory")
                continue
            if ref in seen:
                errors.append(f"row {lineno}: duplicate path '{ref}'")
                continue
            seen.add(ref)
            entries.append({"application_id": app_id,
                            "repo_name": repo_name,
                            "ref": ref})

    if errors:
        raise ValueError(f"{list_file}: {len(errors)} validation error(s):\n  - "
                         + "\n  - ".join(errors))
    if not entries:
        raise ValueError(f"{list_file}: no repo entries found")
    return entries


def _parse_repo_file(list_file: Path) -> list[dict]:
    """Parse the batch input file: each non-blank, non-comment line is ``application_id,repository_name,path``, validated up-front so a bad line fails before any scan starts."""
    _check_manifest_size(list_file)
    entries: list[dict] = []
    errors: list[str] = []
    seen: set[str] = set()

    # Stream lines rather than read_text().splitlines() so a manifest is never fully materialized into memory.
    with open(list_file, encoding="utf-8") as fh:
        for lineno, parts in _txt_records(fh, list_file):
            if len(parts) != 3:
                errors.append(f"line {lineno}: expected 3 comma-separated fields "
                              f"(application_id,repository_name,path) — got {len(parts)}")
                continue

            app_id, repo_name, ref = parts
            if not app_id:
                errors.append(f"line {lineno}: application_id is empty")
            if not repo_name:
                errors.append(f"line {lineno}: repository_name is empty")
            if not ref:
                errors.append(f"line {lineno}: path is empty")
            if not (app_id and repo_name and ref):
                continue

            if ref.lstrip().startswith("-"):
                # A leading "-" would be consumed by `git clone` as an option rather than a URL operand. Reject up front.
                errors.append(f"line {lineno}: path '{ref}' may not start with '-'")
                continue
            if not _is_remote(ref) and not Path(ref).is_dir():
                errors.append(f"line {lineno}: path '{ref}' is neither a git URL "
                              f"nor an existing local directory")
                continue

            if ref in seen:
                errors.append(f"line {lineno}: duplicate path '{ref}'")
                continue
            seen.add(ref)

            entries.append({"application_id": app_id,
                            "repo_name": repo_name,
                            "ref": ref})

    if errors:
        msg = f"{list_file}: {len(errors)} validation error(s):\n  - " \
              + "\n  - ".join(errors)
        raise ValueError(msg)
    if not entries:
        raise ValueError(f"{list_file}: no repo entries found")
    return entries


def _with_token(url: str, token: str | None) -> str:
    if not token or not url.startswith(("http://", "https://")) or "@" in url.split("//", 1)[1]:
        return url
    scheme, rest = url.split("://", 1)
    return f"{scheme}://x-access-token:{token}@{rest}"


def _acquire_repo(ref: str, workspace: Path, git_token: str | None,
                  dest_name: str | None = None) -> Path:
    """Return a local directory for `ref`, cloning into `workspace` if remote."""
    if not _is_remote(ref):
        p = Path(ref)
        if not p.is_dir():
            raise RuntimeError(f"local path does not exist: {ref}")
        return p

    workspace.mkdir(parents=True, exist_ok=True)
    safe = _clone_dir_name(dest_name or _module_name_from(ref))
    # "." and ".." survive the per-char allowlist and would escape the workspace, after which _purge_clone deletes the PARENT. Refuse.
    if safe in (".", "..") or not safe.strip("."):
        raise RuntimeError(
            f"refusing unsafe clone dest name {safe!r} derived from "
            f"{(dest_name or ref)!r}: '.'/'..' would escape the workspace")
    dest = workspace / safe
    _replace_planted_link(dest)
    if dest.exists():
        has_content = any(p for p in dest.iterdir() if p.name != ".git")
        # Reuse ONLY a dir that is both non-empty AND bound (by a state-dir marker) to THIS ref — never a stale/foreign/pre-seeded dir.
        if has_content and _stage_dir_bound(dest, ref):
            console.write(f"  [batch] reusing verified checkout {dest}")
            return dest
        reason = ("empty" if not has_content else
                  "unverified (no matching stage marker — stale, foreign, or "
                  "pre-seeded)")
        console.write(f"  [batch] {reason} dir at {dest} — removing and re-cloning")
        _rmtree_rw(dest)
        if dest.exists():
            console.write(f"  [batch] could not remove {dest}; reusing as-is")
            return dest
    clone_url = _with_token(ref, git_token)
    console.write(f"  [batch] git clone {_scrub_url_secrets(ref)} -> {dest}")
    env = {**os.environ, "GIT_TERMINAL_PROMPT": "0",
           "GIT_ALLOW_PROTOCOL": _GIT_ALLOW_PROTOCOL}
    # Bound the clone so a network stall / unresponsive remote cannot hang the whole batch; GIT_TERMINAL_PROMPT=0 only suppresses interactive auth, not stalls.
    try:
        r = subprocess.run(["git", "-c", "core.longpaths=true",
                            "clone", "--depth", "1", "--", clone_url, str(dest)],
                           capture_output=True, text=True, env=env,
                           timeout=600)
    except subprocess.TimeoutExpired:
        raise RuntimeError(
            f"git clone timed out after 600s: {ref} (network stall or "
            f"unresponsive remote)")
    if r.returncode != 0:
        err = (r.stderr.strip() or r.stdout.strip())
        if git_token:
            err = err.replace(git_token, "***")
        # Mask any inline userinfo credential the remote echoed back before the RuntimeError reaches stderr / errlog / the batch summary.
        err = _scrub_url_secrets(err)
        raise RuntimeError(f"git clone failed: {err}")
    _write_stage_marker(dest, ref, "remote")
    return dest


def _outcome_status(outcome: ScanOutcome) -> dict[str, object]:
    """Fold one repo's scan outcome into the summary row's status fields; a stage that exited non-zero is DEGRADED, while a run that finished and validated nothing it remediated is NOT_REMEDIATED."""
    if outcome.exit_code == 0:
        status, error = "OK", ""
    elif outcome.exit_code == EXIT_NOT_REMEDIATED:
        # An outcome claim, not a health claim: every stage ran, so do not report it as a failure
        status = "NOT_REMEDIATED"
        error = "the scan completed but nothing it remediated validated as fixed"
    else:
        status = "DEGRADED"
        error = f"a scan stage exited {outcome.exit_code}; see the per-repo log"
    return {
        "status": status,
        "findings": outcome.finding_count,
        "report": str(outcome.report_path) if outcome.report_path else "",
        "error": error,
    }


def _split_non_ok(results: list[dict]) -> tuple[list[dict], list[dict]]:
    """Partition the non-OK rows into ``(unremediated, failures)``."""
    # One fold for all three call sites; deny-list on purpose: an unknown status lands in *failures*
    unremediated = [r for r in results if r["status"] == "NOT_REMEDIATED"]
    failures = [r for r in results if r["status"] not in ("OK", "NOT_REMEDIATED")]
    return unremediated, failures


def run_batch(list_file: Path, args, cfg) -> int:
    batch_cfg = getattr(cfg, "batch", None)
    git_token = getattr(batch_cfg, "git_token", None) or None
    git_base = getattr(batch_cfg, "git_base_url", None) or None
    try:
        if list_file.suffix.lower() == ".csv":
            entries = _parse_repo_csv(list_file, git_base)
        else:
            entries = _parse_repo_file(list_file)
    except ValueError as e:
        log.error(Event.BATCH_ROW_INVALID, detail=str(e))
        return 2

    # Filtered out here, before cloning/scanning, via case-insensitive fnmatch globs against RepoName (e.g. "*automation*", "*-karate*").
    skip_pats = [p.lower() for p in
                 (getattr(batch_cfg, "skip_repo_patterns", None) or [])]
    if skip_pats:
        kept: list[dict] = []
        for e in entries:
            name = e["repo_name"]
            hit = next((p for p in skip_pats
                        if fnmatch.fnmatch(name.lower(), p)), None)
            if hit:
                console.write(f"  [batch] skipping '{name}' (app {e['application_id']}) "
                              f"— matches batch.skip_repo_patterns: {hit}")
            else:
                kept.append(e)
        if len(kept) != len(entries):
            console.write(f"  [batch] {len(entries)} rows → {len(kept)} after "
                          f"skip_repo_patterns ({len(entries) - len(kept)} dropped)")
        entries = kept
        if not entries:
            log.error(Event.BATCH_ALL_ROWS_SKIPPED, path=list_file)
            return 2

    workspace = Path(args.workspace)

    if getattr(args, "group_by_app", False):
        return _run_batch_grouped(entries, workspace, git_token, args, cfg,
                                  list_file)

    results: list[dict] = []
    batch_t0 = time.time()

    for i, entry in enumerate(entries, 1):
        ref = entry["ref"]
        repo_name = entry["repo_name"]
        app_id = entry["application_id"]
        console.write(f"\n{'='*72}\n[batch {i}/{len(entries)}] {repo_name}  "
                      f"app_id={app_id}  ({_scrub_url_secrets(ref)})\n{'='*72}")
        TOKENS.reset()
        STAGES.reset()
        COUNTERS.reset()
        CACHED_PROVENANCE.reset()  # repo N>1 must not inherit repo 1's cached-stage provenance
        _reset_quality_counters()
        # Without this repo N>1 loses every warn-once, incl. deepagents' "no token usage recorded"
        _reset_warn_once()
        # Same reason: the value-carry registry is process-global; repo N-1's secrets would leak
        _reset_redact_known_values()
        cli.reset_abort()  # don't let a prior repo's guardrail abort poison this one
        t0 = time.time()
        cloned: Path | None = None
        try:
            local = _acquire_repo(ref, workspace, git_token,
                                  dest_name=repo_name)
            if _is_remote(ref):
                cloned = local
            if args.stop_after == "clone":
                results.append({
                    "ref": ref, "module": repo_name, "app_id": app_id,
                    "status": "OK", "findings": 0, "report": str(local),
                    "elapsed": time.time() - t0, "error": "",
                })
                continue
            outcome = scan_repo(local, repo_name, app_id, args, cfg,
                                path_prefix=repo_name)
            results.append({
                "ref": ref, "module": repo_name, "app_id": app_id,
                **_outcome_status(outcome),
                "elapsed": time.time() - t0,
            })
        except KeyboardInterrupt:
            results.append({"ref": ref, "module": repo_name, "app_id": app_id,
                            "status": "ABORTED", "findings": 0, "report": "",
                            "elapsed": time.time() - t0,
                            "error": "interrupted by user"})
            raise
        except (AuthenticationError, ProxyError, _store.StoreError):
            # VVAH-E001 / VVAH-E002 / a refused state store are environment-wide — every remaining repo would fail identically.
            raise
        except Exception as e:
            # Ordinary failures are repo-scoped: record them and keep the batch moving.
            traceback.print_exc(file=sys.stderr)
            _errlog.log("batch", repo_name, e, app_id=app_id, ref=ref)
            results.append({"ref": ref, "module": repo_name, "app_id": app_id,
                            "status": "FAILED", "findings": 0, "report": "",
                            "elapsed": time.time() - t0, "error": str(e)[:500]})
        finally:
            if cloned and not args.keep_clones and args.stop_after != "clone":
                _purge_clone(cloned, _preserve_set(cfg))

    summary_path = workspace / "batch_summary.md"
    workspace.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(_render_batch_summary(results, list_file,
                                                  time.time() - batch_t0),
                            encoding="utf-8")
    console.write(f"\n[batch] summary written to {summary_path}")

    unremediated, failed = _split_non_ok(results)
    if not (unremediated or failed):
        console.write(f"\n[batch] all {len(results)} repos OK")
        return 0
    if unremediated:
        console.write(f"\n[batch] {len(unremediated)}/{len(results)} repos validated "
                      f"nothing they remediated:")
        for r in unremediated:
            console.write(f"  - {r['module']} ({_scrub_url_secrets(r['ref'])})")
    if failed:
        console.write(f"\n[batch] {len(failed)}/{len(results)} repos FAILED:")
        for r in failed:
            console.write(f"  - {r['module']} ({_scrub_url_secrets(r['ref'])}): "
                          f"{_scrub_url_secrets(r['error'])}")
        # Health outranks outcome, the same precedence the single-repo path applies.
        return 1
    return EXIT_NOT_REMEDIATED


def _stage_repo(ref: str, app_dir: Path, slug: str, git_token: str | None) -> None:
    """Place repo `ref` at app_dir/slug — clone if remote, copytree if local."""
    if _is_remote(ref):
        _acquire_repo(ref, app_dir, git_token, dest_name=slug)
        return
    src = Path(ref)
    if not src.is_dir():
        raise RuntimeError(f"local path does not exist: {ref}")
    dest = app_dir / slug
    _replace_planted_link(dest)
    if dest.exists():
        # Reuse ONLY a copy bound (by a state-dir marker) to THIS ref — never a stale/foreign/pre-seeded dir that happens to sit at the same path.
        if _stage_dir_bound(dest, ref):
            console.write(f"  [batch] reusing verified local copy {dest}")
            return
        console.write(f"  [batch] unverified local copy at {dest} (stale, foreign, or "
                      f"pre-seeded) — replacing")
        _rmtree_rw(dest)
        if dest.exists():
            console.write(f"  [batch] could not remove {dest}; reusing as-is")
            return
    app_dir.mkdir(parents=True, exist_ok=True)
    console.write(f"  [batch] copytree {src} -> {dest}")
    # SECURITY: default shutil DEREFERENCES, copying `key -> ~/.ssh/id_ed25519` in; cf scope/walk.py
    shutil.copytree(src, dest, symlinks=True,
                    ignore=shutil.ignore_patterns(".git"))
    _write_stage_marker(dest, ref, "local")


def _app_module_name(app_id: str, repos: list[dict]) -> str:
    profile, _ = _load_app_profile(app_id)
    if profile and profile.name:
        safe = "".join(c if c.isalnum() or c in "._-" else "_" for c in profile.name)
        return safe or f"app_{app_id}"
    if len(repos) == 1:
        return _module_name_from(repos[0]["repo_name"])
    return f"app_{app_id}"


def _run_batch_grouped(entries: list[dict], workspace: Path,
                       git_token: str | None, args, cfg,
                       list_file: Path) -> int:
    from collections import defaultdict
    groups: dict[str, list[dict]] = defaultdict(list)
    for e in entries:
        groups[e["application_id"]].append(e)

    results: list[dict] = []
    batch_t0 = time.time()

    for n, (app_id, repos) in enumerate(sorted(groups.items()), 1):
        app_dir = workspace / _app_dir_name(app_id)
        slugs = _assign_slugs(repos)
        console.write(f"\n{'='*72}\n[batch {n}/{len(groups)}] app_id={app_id}  "
                      f"({len(repos)} repos → {app_dir})\n  repos: {', '.join(slugs)}\n"
                      f"{'='*72}")
        TOKENS.reset()
        STAGES.reset()
        COUNTERS.reset()
        CACHED_PROVENANCE.reset()  # same per-repo reset as the other loop above
        _reset_quality_counters()
        _reset_warn_once()
        _reset_redact_known_values()  # same reason: no cross-app-group secret leakage
        cli.reset_abort()  # don't let a prior app's guardrail abort poison this one
        t0 = time.time()
        try:
            _require_plain_dir(app_dir, "application directory")
            staged: list[str] = []
            for r, slug in zip(repos, slugs):
                try:
                    _stage_repo(r["ref"], app_dir, slug, git_token)
                    staged.append(slug)
                except _store.StoreError:
                    raise  # the state store is shared, so this is no per-repo clone failure
                except Exception as ce:
                    log.warning(Event.BATCH_REPO_SKIPPED, repo=slug, detail=str(ce))
                    _errlog.log("batch.clone", slug, ce, app_id=app_id)
            if not staged:
                raise RuntimeError(
                    f"all {len(repos)} repo(s) failed to stage for app {app_id}")
            if len(staged) < len(repos):
                console.write(f"  [batch] staged {len(staged)}/{len(repos)} repos for "
                              f"app {app_id}; continuing scan")
            module = _app_module_name(app_id, repos)
            if args.stop_after == "clone":
                results.append({
                    "ref": f"{len(repos)} repos", "module": module,
                    "app_id": app_id, "status": "OK", "findings": 0,
                    "report": str(app_dir), "elapsed": time.time() - t0,
                    "error": "",
                })
                continue
            outcome = scan_repo(app_dir, module, app_id, args, cfg)
            results.append({
                "ref": f"{len(repos)} repos", "module": module, "app_id": app_id,
                **_outcome_status(outcome),
                "elapsed": time.time() - t0,
            })
        except KeyboardInterrupt:
            results.append({"ref": f"{len(repos)} repos", "module": str(app_id),
                            "app_id": app_id, "status": "ABORTED", "findings": 0,
                            "report": "", "elapsed": time.time() - t0,
                            "error": "interrupted by user"})
            raise
        except (AuthenticationError, ProxyError, _store.StoreError):
            # VVAH-E001 / VVAH-E002 / a refused state store are environment-wide — every remaining app would fail identically.
            raise
        except Exception as e:
            traceback.print_exc(file=sys.stderr)
            _errlog.log("batch", f"app_{app_id}", e, app_id=app_id)
            results.append({"ref": f"{len(repos)} repos", "module": str(app_id),
                            "app_id": app_id, "status": "FAILED", "findings": 0,
                            "report": "", "elapsed": time.time() - t0,
                            "error": str(e)[:500]})
        finally:
            if not args.keep_clones and args.stop_after != "clone":
                _purge_clone(app_dir, _preserve_set(cfg))

    summary_path = workspace / "batch_summary.md"
    workspace.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(_render_batch_summary(results, list_file,
                                                  time.time() - batch_t0),
                            encoding="utf-8")
    console.write(f"\n[batch] summary written to {summary_path}")

    unremediated, failed = _split_non_ok(results)
    if not (unremediated or failed):
        console.write(f"\n[batch] all {len(results)} apps OK")
        return 0
    if unremediated:
        console.write(f"\n[batch] {len(unremediated)}/{len(results)} apps validated "
                      f"nothing they remediated:")
        for r in unremediated:
            console.write(f"  - app_id={r['app_id']}")
    if failed:
        console.write(f"\n[batch] {len(failed)}/{len(results)} apps FAILED:")
        for r in failed:
            console.write(f"  - app_id={r['app_id']}: {_scrub_url_secrets(r['error'])}")
        return 1
    return EXIT_NOT_REMEDIATED


def _render_batch_summary(results: list[dict], list_file: Path, elapsed: float) -> str:
    ok = sum(1 for r in results if r["status"] == "OK")
    # Same three-way split the exit code uses, else this report contradicts it on unremediated
    unremediated, failed = _split_non_ok(results)
    counts = f"{ok} OK"
    if unremediated:
        counts += f", {len(unremediated)} not remediated"
    counts += f", {len(failed)} failed"
    out = [
        "# Agentic SAST batch summary",
        "",
        f"- Input list: `{list_file}`",
        f"- Repos: {len(results)} ({counts})",
        f"- Total elapsed: {elapsed:.0f}s",
        "",
        "| # | App ID | Repo | Status | Findings | Elapsed (s) | Report | Source |",
        "|--:|---|---|---|--:|--:|---|---|",
    ]
    for i, r in enumerate(results, 1):
        # _md_cell scrubs+neutralises operator fields; backtick -> U+02CB, as escapes are inert here
        rep = (f"`{_md_cell(r['report']).replace(chr(96), chr(0x2CB))}`"
               if r["report"] else "")
        src = _md_cell(_scrub_url_secrets(r["ref"]))
        out.append(f"| {i} | {_md_cell(r['app_id'])} | {_md_cell(r['module'])} | "
                   f"{_md_cell(r['status'])} | {r['findings']} | {r['elapsed']:.0f} | "
                   f"{rep} | {src} |")
    # Its own section, not under Failures: the table has no error column, so prose is the only place
    if unremediated:
        out.extend(["", "## Not remediated", "",
                    "These scans ran to completion. Nothing they remediated validated as "
                    "fixed.", ""])
        for r in unremediated:
            out.extend([f"### {_md_cell(r['module'])} (app {_md_cell(r['app_id'])})",
                        f"- Source: `"
                        f"{_md_cell(_scrub_url_secrets(r['ref'])).replace(chr(96), chr(0x2CB))}`",
                        ""])
    if failed:
        out.extend(["", "## Failures", ""])
        for r in failed:
            out.extend([f"### {_md_cell(r['module'])} (app {_md_cell(r['app_id'])})",
                        f"- Source: `"
                        f"{_md_cell(_scrub_url_secrets(r['ref'])).replace(chr(96), chr(0x2CB))}`",
                        f"- Error: {_md_cell(_scrub_url_secrets(r['error']))}", ""])
    return "\n".join(out) + "\n"
