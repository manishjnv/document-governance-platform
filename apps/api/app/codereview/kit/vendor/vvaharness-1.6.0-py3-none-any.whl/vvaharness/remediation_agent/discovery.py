# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Locates the scan report and selects findings for the ``remediate`` command."""

from __future__ import annotations

import os
import stat
import sys
from dataclasses import dataclass
from pathlib import Path

from vvaharness.models import FinalReport
from vvaharness.models.case import FindingCase
from vvaharness.models.vocab import CaseState
from vvaharness.orchestrator.artifacts import UnsafeArtifactDir, artifact_dir, contained
from vvaharness.orchestrator.checkpoints import (
    REPO_IDENTITY_STEP,
    adopt_run_instance,
    contained_repo_path,
    load_ckpt,
    run_id_for,
)
from vvaharness.orchestrator.findings_json import (
    findings_json_path,
    read_findings_json,
)
from vvaharness.remediation_agent.report_parser import (
    REMEDIATION_DIR_NAME,
    SCAN_DIR_NAME,
    find_scan_dir,
    latest_report,
    parse_findings,
)
from vvaharness.remediation_agent.report_parser.locate import mtime_or_missing
from vvaharness.remediation_agent.select import (
    drop_non_main_channel,
    select_top_logged,
)
from vvaharness.remediation_agent.target import RemediationTarget
from vvaharness.util import console

__all__ = ["Findings", "Layout", "completed_case_ids", "cvss_score_of",
           "load_findings", "locate_report", "prepare_layout",
           "verify_report_trust"]

CHECKPOINTS_DIR_NAME = "checkpoints"


def _mtime(path: Path) -> float | None:
    """The artifact's mtime, or None (no cutoff) when it cannot be read."""
    try:
        return path.stat().st_mtime
    except OSError:
        return None


def _state_report(repo_path: Path) -> Path | None:
    """Newest ``*_report.md`` among this repo's state artifacts instances, or None.

    Instances are tried newest-first and an instance with no report falls through to
    the next: a ``--stop-after s8`` run (or a crash) leaves one behind.
    """
    from vvaharness.orchestrator import store
    # The artifacts tree is container-writable and a report found here steers a HOST-side
    # remediate, so every level is checked, not just the leaf: a minted instance name, and
    # nothing reached through a symlink or resolving outside the state root.
    state_root = store.state_root()
    root = store.state_artifacts_root(run_id_for(repo_path))
    if root.is_symlink() or not store.within_state_root(root):
        print(f"  [Remediation Agent] ignoring {root}: it is a symlink, or resolves "
              f"outside the state root {state_root}", file=sys.stderr)
        return None
    if not root.is_dir():
        return None
    instances, ignored = [], 0
    try:
        for d in root.iterdir():
            if (store.is_known_instance_id(d.name) and not d.is_symlink() and d.is_dir()
                    and store.within_state_root(d)):
                instances.append(d)
            elif d.is_dir() or d.is_symlink():
                ignored += 1
    except OSError:
        return None
    if ignored:
        print(f"  [Remediation Agent] ignoring {ignored} entry/entries under {root} that "
              f"vvaharness could not have written", file=sys.stderr)
    # Tolerant key: a concurrent `vvaharness gc` can rmtree these dirs mid-sort.
    instances.sort(key=mtime_or_missing, reverse=True)
    for instance in instances:
        report = latest_report(instance)
        if report is None:
            continue
        # The chosen path is re-checked, not just the dir it came from: the instance dir is
        # container-writable, so it can become a link after the check above. This vets the
        # path only — the read itself (load_findings) re-opens it O_NOFOLLOW, because the
        # swap can also happen after this check.
        if report.is_symlink() or not store.within_state_root(report):
            print(f"  [Remediation Agent] ignoring {report}: a scan report must be a "
                  f"real file that resolves under the state root", file=sys.stderr)
            continue
        return report
    return None


def locate_report(repo_path: Path) -> tuple[Path | None, int]:
    """Find the newest scan report for *repo_path*, returning ``(None, exit_code)`` with the error already printed on failure.

    Repo-local ``<repo>/security-scan/`` first (legacy layout, and where a manual copy
    still wins), then the run's state artifacts dir, where a contained scan writes. A
    repo-local ``security-scan`` that is unsafe to follow is refused, not skipped.
    """
    try:
        scan_dir = find_scan_dir(repo_path)
    except UnsafeArtifactDir as e:
        console.mark("fail", f"refusing to read scan report: {e}", indent=2)
        return None, 1
    report = latest_report(scan_dir) if scan_dir is not None else None
    if report is None:
        # A contained run writes its report under the state artifacts tree, not the repo.
        report = _state_report(repo_path)
        if report is not None:
            console.write(f"  [Remediation Agent] no report under {repo_path}/"
                          f"{SCAN_DIR_NAME} — using the scan's state artifacts dir")
    if report is None:
        # Contained, repo_path is the mount; the hint must name the path to type on the host
        shown = contained_repo_path(repo_path)
        console.mark("fail", f"no scan report (*_report.md) found under {shown}/"
              f"{SCAN_DIR_NAME} or in this repo's state artifacts dir — run "
              f"`vvaharness scan --repo {shown}` first.", indent=2)
        return None, 1
    return report, 0


def cvss_score_of(target: RemediationTarget) -> float | None:
    """Numeric CVSS base score accessor for ``--top N`` selection, or ``None`` when the report carried only a vector / bare severity band."""
    return target.finding.cvss_score


@dataclass(frozen=True)
class Findings:
    """What a report yielded: the findings this run will work on (``selected``), and every one it had (``discovered``, still needed for checkpoint pruning)."""

    selected: list[RemediationTarget]
    discovered: list[RemediationTarget]


def completed_case_ids(repo_path: Path, *,
                       since: float | None = None) -> set[str]:
    """Case ids under ``<repo>/security-remediation/`` whose fix currently stands (remediated/validated)."""
    done: set[str] = set()
    for case_path in sorted(
            (repo_path / REMEDIATION_DIR_NAME).glob("*/finding_case.json")):
        try:
            if since is not None and case_path.stat().st_mtime < since:
                continue
            case = FindingCase.model_validate_json(
                case_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if case.state in (CaseState.REMEDIATED, CaseState.VALIDATED):
            done.add(case.case_id)
    done.discard("")
    return done


def _targets_from_typed(report: FinalReport,
                        done: set[str]) -> list[RemediationTarget]:
    """Adapter: the typed report's findings as remediation targets."""
    # Ordinals precede the posture drop, matching to_markdown ### N.; posture leaves discovered too
    targets = []
    for i, rf in enumerate(report.findings, 1):
        f = rf.finding
        f.severity = rf.severity
        t = RemediationTarget(finding=f, index=i)
        t.done = t.case_id in done
        targets.append(t)
    return drop_non_main_channel(targets, log_prefix="[Remediation Agent]")


def _read_vetted_report(report: Path) -> str:
    """Read *report* through an ``O_NOFOLLOW`` fd, refusing anything but a regular file.

    ``locate_report`` vetted this path, but the instance dir holding it is
    container-writable: a plain ``read_text`` here re-resolves the name and would hand an
    arbitrary operator-readable host file to the remediation model if the report was
    swapped for a link in between. The fd is stat'ed and read, so name and bytes match.
    """
    from vvaharness.orchestrator import store
    try:
        fd = os.open(report, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    except OSError as e:
        raise store.StateIntegrityError(
            f"refusing to read scan report {report}: {e}. A scan report must be a real "
            f"file that is still there when it is read.") from e
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise store.StateIntegrityError(
                f"refusing to read scan report {report}: it is not a regular file "
                f"(a symlink, directory or device).")
        handle = os.fdopen(fd, "r", encoding="utf-8")
    except BaseException:
        os.close(fd)        # nothing has taken ownership of the fd yet
        raise
    with handle:
        return handle.read()


def _findings_dir(report: Path | None) -> Path | None:
    """Where the ``findings.json`` paired with *report* lives; None means the repo-local default."""
    # Contained, the scan wrote findings.json beside the report it relocated to the state tree
    return report.parent if report is not None and contained() else None


def load_findings(repo_path: Path, report: Path, top: int | None) -> Findings:
    """Targets for *repo_path*, narrowed to the N highest-CVSS when ``top`` is set."""
    # Invalid findings.json raises InvalidFindingsJSON, no silent MD fallback; mtime gates done
    out_dir = _findings_dir(report)
    typed = read_findings_json(repo_path, out_dir=out_dir)
    done = completed_case_ids(
        repo_path,
        since=_mtime(findings_json_path(repo_path, out_dir=out_dir) if typed is not None
                     else report))
    if typed is not None:
        console.write("  [Remediation Agent] source: findings.json (typed scan result)")
        discovered = _targets_from_typed(typed, done)
    else:
        console.write("  [Remediation Agent] source: legacy Markdown parse "
                      "(this checkout has no findings.json — older scan)")
        # The report may come from the container-writable state tree, so it is read
        # through an O_NOFOLLOW fd rather than re-resolved by name with read_text.
        discovered = parse_findings(_read_vetted_report(report))
        for t in discovered:
            t.done = t.done or t.case_id in done
    selected = select_top_logged(discovered, top, score_of=cvss_score_of,
                                 log_prefix="[Remediation Agent]")
    return Findings(selected=selected, discovered=discovered)


def verify_report_trust(repo_path: Path, mode: str, *,
                        report: Path | None = None) -> str | None:
    """Refuse fix mode on a ``findings.json`` this host did not just produce for *repo_path* at its current HEAD; returns an error string or ``None`` to proceed.

    Standalone ``remediate`` reads ``findings.json`` from inside the target it is
    about to edit, so a repository that commits its own report supplies every
    finding field AND the edit target. The in-scan path refuses when HEAD moved
    since the report (``orchestrator.scan._remediate_preflight``), but that check
    alone is not enough here: it trusts the report's own ``git_sha``, and that
    field is exactly as attacker-controlled as the rest of a planted file — a
    clone whose HEAD the attacker predicts (or a report regenerated post-clone)
    forges a match for free. So this additionally requires a ``REPO_IDENTITY_STEP``
    checkpoint row for THIS resolved path in the local state store that itself
    records the current HEAD — proof this host actually ran
    ``vvaharness scan`` here, not merely that a file claims to agree with it.

    Only fix mode is gated: report-only never touches source, so a crafted
    report cannot do more than a crafted scan report already could. Pass the *report*
    ``locate_report`` chose, so this checks the same ``findings.json`` that
    ``load_findings`` then reads.
    """
    if mode != "fix":
        return None
    # may raise InvalidFindingsJSON; let it propagate
    typed = read_findings_json(repo_path, out_dir=_findings_dir(report))
    if typed is None:
        return None  # legacy Markdown-only report carries no git_sha to check

    from vvaharness.orchestrator.scan import _head_sha  # local: scan.py is heavy, cf. _remediate_preflight

    cur = _head_sha(repo_path)
    shown = contained_repo_path(repo_path)  # the host path, also when contained
    if not typed.git_sha or not cur or typed.git_sha != cur:
        return (f"findings.json git_sha ({typed.git_sha or 'missing'}) does not match "
                f"this checkout's HEAD ({cur or 'unknown'}) — re-run "
                f"`vvaharness scan --repo {shown}` here, or pass --mode report-only")

    run_id = run_id_for(repo_path)
    # The scan saved the row under its own instance; an unadopted process reads `legacy`
    adopt_run_instance(run_id)
    recorded_head = load_ckpt(repo_path, run_id, REPO_IDENTITY_STEP)
    if recorded_head != cur:
        return (f"no scan of {shown} at HEAD {cur[:8]} is recorded in this host's "
                f"state store — run `vvaharness scan --repo {shown}` here first, or "
                f"pass --mode report-only")
    return None


@dataclass(frozen=True)
class Layout:
    """Resolved per-repo output + checkpoint locations for one remediation run."""
    rem_dir: Path
    ckpt_dir: Path
    run_id: str


def prepare_layout(repo_path: Path) -> Layout:
    """Resolve (and create) the per-repo remediation output dir; ``ckpt_dir`` is a layout field only, because checkpoints live in the state store.

    Raises ``UnsafeArtifactDir`` (via ``artifact_dir``) rather than following a
    committed symlink that would redirect remediation artefacts outside the repo.
    """
    rem_dir = artifact_dir(repo_path, REMEDIATION_DIR_NAME)
    rem_dir.mkdir(exist_ok=True)
    run_id = run_id_for(repo_path)
    # Standalone `remediate` mints no instance, so without this it reads and prunes the
    # `legacy` bucket and cannot see the rows an in-scan S10 wrote.
    adopt_run_instance(run_id)
    return Layout(
        rem_dir=rem_dir,
        ckpt_dir=repo_path / CHECKPOINTS_DIR_NAME,
        run_id=run_id,
    )
