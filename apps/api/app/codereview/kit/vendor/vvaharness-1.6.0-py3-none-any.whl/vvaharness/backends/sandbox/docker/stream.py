# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Relay the container's output to this process's own streams, keeping stderr separate.

The split is not cosmetic: the harness parses NDJSON on stdout, so stderr merged into it
corrupts the parse. Pumping happens on a thread so the caller can still bound the run with a
wait deadline -- following the log stream on the calling thread would block past any timeout.
"""

from __future__ import annotations

import codecs
import sys
import threading
from collections.abc import Iterable, Iterator
from contextlib import contextmanager
from typing import TYPE_CHECKING

from vvaharness.util.console import _CONTROL_RX

if TYPE_CHECKING:
    from docker.models.containers import Container

#: A moment for the last frames to arrive after the container exits. Short: the run is over, and
#: this only decides whether its final lines print before the harness moves on.
_DRAIN_GRACE_SECONDS = 2.0


def _decoders() -> dict[bool, codecs.IncrementalDecoder]:
    """One decoder per stream, keyed by `err`, for one relay: a multi-byte character split across
    two frames still decodes whole, and nothing half-decoded leaks into another run."""
    return {err: codecs.getincrementaldecoder("utf-8")("replace") for err in (False, True)}


def _scrub(text: bytes, decoder: codecs.IncrementalDecoder) -> bytes:
    """*text* with control characters replaced, as `util.console` does for the harness's own."""
    return _CONTROL_RX.sub(" ", decoder.decode(text)).encode("utf-8")


def _emit(text: bytes, *, err: bool, decoder: codecs.IncrementalDecoder) -> None:
    """Write *text* to this process's stderr or stdout, unbuffered, scrubbed.

    The target influences these bytes, so both streams are scrubbed: an escape sequence relayed
    raw retitles the window, garbles the screen or, where the terminal honours OSC 52, sets the
    clipboard, and piped output is often shown in a terminal later. Newline and tab survive, and
    valid JSON holds no other control character, so a machine reader of stdout loses nothing.
    A line with no control character passes unchanged, so this does not neutralise a CI
    runner's in-band commands, such as GitHub's `::` workflow commands.
    """
    stream = sys.stderr if err else sys.stdout
    text = _scrub(text, decoder)
    target = getattr(stream, "buffer", None)
    if target is None:  # a replaced text-only stream, such as a notebook's
        stream.write(text.decode("utf-8", "replace"))
        stream.flush()
        return
    target.write(text)
    target.flush()


def _as_bytes(part: object) -> bytes:
    """Coerce one frame half to bytes; docker-py may hand back str when not demultiplexing."""
    if isinstance(part, bytes):
        return part
    return str(part).encode() if part else b""


def _write(chunk: object, decoders: dict[bool, codecs.IncrementalDecoder]) -> None:
    """Route one output frame to the stream it came from.

    A demultiplexed frame is a `(stdout, stderr)` pair with one side set. Anything else means
    demultiplexing was not honoured, and stdout is the safe destination: misrouting stderr into
    stdout corrupts the NDJSON the harness parses, so the tolerant case belongs on this side.
    """
    if isinstance(chunk, tuple):
        out, err = chunk
        _emit(_as_bytes(out), err=False, decoder=decoders[False])
        _emit(_as_bytes(err), err=True, decoder=decoders[True])
        return
    _emit(_as_bytes(chunk), err=False, decoder=decoders[False])


def _relay(frames: Iterable[object]) -> None:
    """Drain an attached container's demultiplexed output until the stream ends.

    A dead or removed container just ends the stream -- the exit code the caller awaits is the
    authoritative outcome.
    """
    decoders = _decoders()
    try:
        for chunk in frames:
            _write(chunk, decoders)
    # Deliberately everything: this runs on a side thread whose only job is relaying output, so
    # any failure here must be swallowed rather than allowed to mask the run's real outcome.
    except Exception:
        return


def _attach(container: Container) -> Iterable[object]:
    """Open *container*'s output stream; an attach the daemon refuses relays nothing.

    `attach`, not `logs`: only attach takes `demux` (verified against docker-py 7.2.0, where
    `logs` has no such parameter). docker-py sends the attach request here, eagerly, and only
    the reading is deferred to the stream it returns.
    """
    try:
        return container.attach(stream=True, logs=True, demux=True)
    # Same reasoning as `_relay`: relaying output must never decide the run's outcome.
    except Exception:
        return ()


@contextmanager
def pumping(container: Container) -> Iterator[None]:
    """Relay *container*'s output on a daemon thread for the duration of the block.

    The stream is opened HERE, before the block runs, so a caller starts the container inside
    the block: Docker refuses an attach to a container that has already exited, so a thread
    that attached only after `start` lost every line of a run that ended within its first
    moment -- a bad flag or an import error then showed nothing but the exit code.

    The thread is not joined on exit: `wait` has already returned by then, and a log stream
    that has not closed must never hold up teardown.
    """
    thread = threading.Thread(target=_relay, args=(_attach(container),), daemon=True)
    thread.start()
    try:
        yield
    finally:
        thread.join(timeout=_DRAIN_GRACE_SECONDS)


__all__ = ["pumping"]
