# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""orchestrator.store — single-file SQLite state store under ``$VVAHARNESS_STATE_DIR`` holding per-run checkpoint blobs, callgraph snapshots, and run metadata."""
from __future__ import annotations

from vvaharness.orchestrator.store._db import (
    _O_NOFOLLOW,
    _PERM_WARNED,
    _POSIX,
    _REPLAY_MAX_BYTES,
    _SCHEMA_VERSION,
    _SYMLINK_ERRNOS,
    LEGACY_INSTANCE_ID,
    InstanceStatus,
    StateIntegrityError,
    StoreError,
    _create_db_file_safe,
    _tighten_mode,
    begin_instance,
    check_run_id,
    connect,
    contained_state_dir,
    contained_state_location,
    db_location,
    db_path,
    delete_run,
    delete_run_graphs,
    delete_steps,
    ensure_state_dir,
    finish_instance,
    is_known_instance_id,
    is_run_id,
    latest_instance_with_step,
    new_instance_id,
    prune_contained_states,
    purge_contained_state,
    purge_run_artifacts,
    register_instance,
    register_run,
    reset_run,
    run_exists,
    run_lock,
    state_artifacts_dir,
    state_artifacts_root,
    state_root,
    steps_with_prefix,
    within_state_root,
)
from vvaharness.orchestrator.store._schema import _DDL, _DDL_V2, _DDL_V3

# This process's scan instance. Lives on the PACKAGE (not _db) so the suite's
# `monkeypatch.setattr(store, "_CURRENT_INSTANCE", None)` reset is seen by the accessors
# below — and so _db/replays default-resolve through the same one source of truth.
_CURRENT_INSTANCE: str | None = None


def current_instance_id() -> str:
    """This process's instance, or the legacy sentinel when nobody began one."""
    return _CURRENT_INSTANCE or LEGACY_INSTANCE_ID


def set_current_instance(instance_id: str | None) -> None:
    """Pin the instance every unqualified read/write in this process uses."""
    global _CURRENT_INSTANCE  # process-wide scan identity — intentional module state
    _CURRENT_INSTANCE = instance_id
from vvaharness.orchestrator.store.callgraph import load_callgraph, save_callgraph
from vvaharness.orchestrator.store.replays import (
    delete_replays,
    latest_replay_instance,
    load_ev_probes,
    load_replays,
    prune_replays,
    save_ev_probes,
    save_replays,
)

__all__ = [
    "_DDL",
    "_DDL_V2",
    "_DDL_V3",
    "_O_NOFOLLOW",
    "_PERM_WARNED",
    "_POSIX",
    "_REPLAY_MAX_BYTES",
    "_SCHEMA_VERSION",
    "_SYMLINK_ERRNOS",
    "LEGACY_INSTANCE_ID",
    "InstanceStatus",
    "StateIntegrityError",
    "StoreError",
    "_create_db_file_safe",
    "_tighten_mode",
    "begin_instance",
    "check_run_id",
    "connect",
    "contained_state_dir",
    "contained_state_location",
    "current_instance_id",
    "db_location",
    "db_path",
    "delete_replays",
    "delete_run",
    "delete_run_graphs",
    "delete_steps",
    "ensure_state_dir",
    "finish_instance",
    "is_known_instance_id",
    "is_run_id",
    "latest_instance_with_step",
    "latest_replay_instance",
    "load_callgraph",
    "load_ev_probes",
    "load_replays",
    "new_instance_id",
    "prune_contained_states",
    "prune_replays",
    "purge_contained_state",
    "purge_run_artifacts",
    "register_instance",
    "register_run",
    "reset_run",
    "run_exists",
    "run_lock",
    "save_callgraph",
    "save_ev_probes",
    "save_replays",
    "set_current_instance",
    "state_artifacts_dir",
    "state_artifacts_root",
    "state_root",
    "steps_with_prefix",
    "within_state_root",
]
