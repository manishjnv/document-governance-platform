# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Everything the mediated-network sidecar decides, with no daemon in reach.

CONNECT-forwarding, not TLS-terminating: the crossing env deliberately drops `SSL_CERT_FILE`
and httpx ignores the OS trust store, so a terminating proxy would need a CA baked into the
image. Tunnelling keeps TLS end-to-end and still gives a domain allowlist.

No network joins the two containers. The scan container has loopback alone; the sidecar sits on
the default bridge, its outside leg. They share one per-run volume holding a Unix socket: in the
scan container `relay` turns the proxy port on loopback into that socket, and in the sidecar
socat turns it back into squid's port on the sidecar's own loopback. With no interface there is
no gateway to reach either, so what the scan container can reach is squid's allowlist and
nothing else, on every platform -- except, for a scoped `ev` run, the exploit-verification
target's own ports on this machine, each through a socket of its own that socat connects there.
That run also takes the target's out-of-band callback the other way: on a port the sidecar
publishes on host loopback, into a socket the scan container listens on.
"""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING, Final

from vvaharness.backends.sandbox.docker.evnet import (
    CONTAINER_OOB_PORT,
    HOST_GATEWAY_NAME,
    HOST_LOOPBACK,
)
from vvaharness.backends.sandbox.models import (
    ALLOWLIST_SETTING,
    CALLBACK_SOCKET,
    EGRESS_CALLBACK_ENV,
    EGRESS_FORWARDS_ENV,
    EGRESS_RELAY_PORT,
    EGRESS_SOCKET_ENV,
    MEDIATED_PORTS,
    EgressMode,
    SandboxNetwork,
    forward_socket_name,
    host_of,
    is_cleartext,
    is_loopback,
    require_hostname,
    require_mediated_port,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

#: Squid's default, bound to the sidecar's own loopback: only socat reaches it, never another
#: container on the default bridge, and it is never published.
PROXY_PORT: Final = 3128
#: The name squid gives itself in its replies, in place of the sidecar's container id.
PROXY_HOSTNAME: Final = "vvaharness-egress"
#: Where the shared socket volume is mounted, in the scan container and the sidecar alike.
SOCKET_TARGET: Final = "/vvaharness-egress-socket"
SOCKET_PATH: Final = f"{SOCKET_TARGET}/proxy.sock"
#: The port the callback listens on, in the sidecar (published) and in the scan container (the
#: out-of-band listener, behind the relay) alike: the EV bridge's own container-side port.
CALLBACK_PORT: Final = CONTAINER_OOB_PORT
#: Built locally and tagged by the operator: an unpinned pull of a proxy image is the same
#: supply-chain hole as an unpinned sandbox image, so this is never pulled.
PROXY_IMAGE: Final = "vvaharness-egress:local"
#: Where the generated proxy config is bound, read-only, inside the sidecar.
CONF_TARGET: Final = "/vvaharness-egress"
CONF_NAME: Final = "squid.conf"
#: The host temp directory holding one run's generated config, by name prefix, so a dead
#: owner's directory can be recognised and removed along with its sidecar.
CONF_DIR_PREFIX: Final = "vvaharness-egress-"

#: EV localhost traffic must never be funnelled to the proxy.
_LOOPBACK: Final = "localhost,127.0.0.1,::1"

#: Cleartext is only ever an `http://` gateway base_url, i.e. port 80; 443 is CONNECT-only.
_HTTP_PORT: Final = 80

#: Env names whose value is a model endpoint URL this run legitimately needs to reach. Model
#: endpoints only: a tracing endpoint carried across by `env_allowlist` is not one, so it stays
#: unreachable rather than becoming a destination no grant names.
_ENDPOINT_ENV: Final[frozenset[str]] = frozenset({
    "ANTHROPIC_BASE_URL", "ANTHROPIC_SDK_BASE_URL", "OPENAI_BASE_URL",
})


def mediated(network: SandboxNetwork) -> bool:
    """Whether *network* needs the sidecar at all."""
    return network.mode is EgressMode.MEDIATED


def names(token: str) -> tuple[str, str]:
    """The per-run socket volume and sidecar container names; *token* keeps runs apart."""
    return (f"vvaharness-egress-socket-{token}", f"vvaharness-egress-{token}")


def bound(network: SandboxNetwork) -> SandboxNetwork:
    """The same decision with the proxy URL filled in: the relay on the container's loopback."""
    if not mediated(network):
        return network
    return replace(network, proxy_url=f"http://127.0.0.1:{EGRESS_RELAY_PORT}")


def sidecar_command(forwards: tuple[int, ...] = (), *, callback: bool = False) -> tuple[str, ...]:
    """The sidecar's `sh -c` script: socat bridging each shared socket, then squid.

    One bridge to squid, and one per forwarded port to that port on this machine, by the name
    `policy.derive_sidecar` maps to Docker's host gateway: the target is fixed here, so the scan
    container chooses no destination of its own. With *callback*, one bridge the other way: the
    port `policy.derive_sidecar` publishes on host loopback, into the scan container's callback
    socket.
    `mode=666` because the scan container connects as the invoking host user, never the
    sidecar's own uid. `-d -d` makes socat log the `listening on` line readiness waits for. No
    `exec`: the shell stays the parent of every process, so squid is never handed socat's
    children, and the container ends when squid does.
    """
    bridges = [f"socat -d -d UNIX-LISTEN:{SOCKET_PATH},fork,mode=666 TCP:127.0.0.1:{PROXY_PORT}"]
    bridges += [
        f"socat -d -d UNIX-LISTEN:{SOCKET_TARGET}/{forward_socket_name(port)},fork,mode=666 "
        f"TCP:{HOST_GATEWAY_NAME}:{int(port)}"
        for port in forwards
    ]
    if callback:
        bridges.append(f"socat -d -d TCP-LISTEN:{CALLBACK_PORT},fork,reuseaddr "
                       f"UNIX-CONNECT:{SOCKET_TARGET}/{CALLBACK_SOCKET}")
    starts = "".join(f"{bridge} & " for bridge in bridges)
    return ("-c", f"{starts}squid -N -d 1 -f {CONF_TARGET}/{CONF_NAME}")


def with_env_hosts(network: SandboxNetwork, env: Mapping[str, str]) -> SandboxNetwork:
    """Extend the allowlist with the hosts *env*'s endpoint variables actually name.

    The profile's routes are already in `allowlist`; this catches an endpoint that reached the
    run through the environment instead, which would otherwise fail to resolve at all. A
    loopback endpoint is skipped: it names the container itself (the gate has warned), and
    allowlisting one such as `127.0.0.2` would point the sidecar at its OWN loopback; `::1`
    could not be an ACL token anyway. An `http://` endpoint's host also joins `cleartext`, the
    only hosts port 80 opens for.
    Sorted iteration so which of two malformed variables is reported does not vary per run.

    Raises:
        SandboxConfigError: If an endpoint variable's host is not a bare hostname, or names a
            port mediation cannot reach -- named by the variable it came from rather than by the
            profile setting it did not come from.
    """
    if not mediated(network):
        return network
    hosts = set(network.allowlist)
    cleartext = set(network.cleartext)
    for name in sorted(_ENDPOINT_ENV):
        raw = (env.get(name) or "").strip()
        host = host_of(raw) if raw else None
        if host and not is_loopback(host):
            require_mediated_port(raw, name)
            hosts.add(require_hostname(host, name, endpoint=True))
            if is_cleartext(raw):
                cleartext.add(host)
    return replace(network, allowlist=tuple(sorted(hosts)), cleartext=tuple(sorted(cleartext)))


def proxy_env(network: SandboxNetwork) -> Mapping[str, str]:
    """The proxy variables to force into the container, in both casings plus the SDK hooks.

    Both casings because urllib prefers the lowercase name and drops the uppercase one when
    `REQUEST_METHOD` is set (CVE-2016-1000110). `ANTHROPIC_PROXY`/`OPENAI_PROXY` are the
    first-class hooks the SDK routes read, so an injected transport cannot shadow the proxy.
    No `ALL_PROXY`: the sidecar speaks HTTP CONNECT only. The socket path rides along, since it
    is what starts the relay the proxy URL names, and so do any forwarded ports.
    """
    if not mediated(network) or not network.proxy_url:
        return {}
    url = network.proxy_url
    forced = {
        "HTTP_PROXY": url, "http_proxy": url,
        "HTTPS_PROXY": url, "https_proxy": url,
        "NO_PROXY": _LOOPBACK, "no_proxy": _LOOPBACK,
        "ANTHROPIC_PROXY": url, "OPENAI_PROXY": url,
        EGRESS_SOCKET_ENV: SOCKET_PATH,
    }
    if network.forwards:
        forced[EGRESS_FORWARDS_ENV] = ",".join(str(port) for port in network.forwards)
    return forced


def callback_env(host_port: int) -> Mapping[str, str]:
    """What points exploit verification's out-of-band listener at the sidecar's published port.

    The listener binds loopback (`EV_OOB_BIND`), where the relay delivers callbacks, on
    `CALLBACK_PORT`; it advertises the host-loopback port the sidecar publishes, which is what
    the target dials. Forced after the caller's env, so a host `EV_OOB_*` cannot redirect it.
    """
    return {
        EGRESS_CALLBACK_ENV: str(CALLBACK_PORT),
        "EV_OOB_URL": f"http://{HOST_LOOPBACK}:{host_port}",
        "EV_OOB_PORT": str(CALLBACK_PORT),
        "EV_OOB_BIND": "127.0.0.1",
    }


def squid_conf(network: SandboxNetwork) -> str:
    """The generated sidecar config: CONNECT on 443, and HTTP on 80 for a cleartext host only.

    A cleartext host is one an `http://` endpoint names. Anything else is denied -- another
    port, another method on 443, another host, cleartext to a host only reached over HTTPS, a
    non-HTTP scheme on 80 (`ftp://`) -- and an empty allowlist yields a proxy that refuses every
    request rather than one that forwards everything: the failure has to be a refused CONNECT,
    not open egress.

    The trailing settings keep the sidecar from describing itself or the run upstream: no
    version or container hostname in its replies or its `Via` (which HTTP requires, so it stays),
    no `X-Forwarded-For` carrying the scan container's address. It caches nothing and starts no
    ICMP pinger, which it has no capability for; its own messages reach stderr through `-d 1`,
    where readiness is read.

    Raises:
        SandboxConfigError: If an allowlist entry is not a bare hostname.
    """
    lines = [
        f"http_port 127.0.0.1:{PROXY_PORT}",
        "acl CONNECT method CONNECT",
        "acl SSL_ports port 443",
        f"acl HTTP_ports port {_HTTP_PORT}",
        "acl HTTP_proto proto HTTP",
        *[f"acl Safe_ports port {port}" for port in MEDIATED_PORTS],
        # `-n`: without it squid reverse-resolves an IP-literal destination and matches the
        # PTR name, which whoever owns the address controls -- a PTR of `api.anthropic.com`
        # would open a tunnel to any host. A literal IP entry still matches literally.
        *[
            f"acl vvaharness_allowed dstdomain -n {require_hostname(host, ALLOWLIST_SETTING)}"
            for host in network.allowlist
        ],
        *[
            f"acl vvaharness_cleartext dstdomain -n {require_hostname(host, ALLOWLIST_SETTING)}"
            for host in network.cleartext
        ],
        # Before any allow, and both needed: without them an allowlisted host is reachable on
        # any port (22, 3306) and a CONNECT tunnel to it carries cleartext HTTP.
        "http_access deny !Safe_ports",
        "http_access deny CONNECT !SSL_ports",
    ]
    if network.allowlist:
        lines.append("http_access allow CONNECT SSL_ports vvaharness_allowed")
    if network.cleartext:
        lines.append("http_access allow HTTP_ports HTTP_proto vvaharness_cleartext")
    lines += [
        "http_access deny all",
        "cache deny all",
        "cache_mem 0 MB",
        "pid_filename none",
        "access_log stdio:/dev/stdout",
        "cache_log /dev/null",
        "pinger_enable off",
        "httpd_suppress_version_string on",
        f"visible_hostname {PROXY_HOSTNAME}",
        "forwarded_for delete",
        "",
    ]
    return "\n".join(lines)


__all__ = [
    "ALLOWLIST_SETTING",
    "CALLBACK_PORT",
    "CONF_DIR_PREFIX",
    "CONF_NAME",
    "CONF_TARGET",
    "PROXY_HOSTNAME",
    "PROXY_IMAGE",
    "PROXY_PORT",
    "SOCKET_PATH",
    "SOCKET_TARGET",
    "bound",
    "callback_env",
    "mediated",
    "names",
    "proxy_env",
    "sidecar_command",
    "squid_conf",
    "with_env_hosts",
]
