# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The typed scan result on disk, beside the rendered Markdown one, so a later process reads it instead of re-parsing Markdown and losing fields."""

from __future__ import annotations

import errno
import json
import os
import stat
from pathlib import Path

from pydantic import ValidationError

from vvaharness.models import FinalReport
from vvaharness.orchestrator.artifacts import (
    FINDINGS_JSON_NAME,
    SCAN_DIR_NAME,
    artifact_dir,
)
from vvaharness.orchestrator.store import _O_NOFOLLOW, _SYMLINK_ERRNOS, StateIntegrityError
from vvaharness.report.redact import redact_tree

#: 0 where absent (Windows, which the README lists as supported), so the flag is a no-op there
#: rather than an `AttributeError` that would crash `remediate` on open.
_O_NONBLOCK = getattr(os, "O_NONBLOCK", 0)

__all__ = ["InvalidFindingsJSON", "findings_json_path", "read_findings_json",
           "write_findings_json"]


class InvalidFindingsJSON(ValueError):
    """A findings.json exists but does not validate as a FinalReport."""
    # Distinct from absence on purpose: a corrupt contract file must not fall back to the Markdown


def findings_json_path(repo: Path | str, *,
                       out_dir: Path | str | None = None) -> Path:
    """Where the typed result lives: *out_dir* when the caller relocated scan output (the run's state artifacts dir), else ``<repo>/security-scan/``."""
    if out_dir is not None:
        return Path(out_dir) / FINDINGS_JSON_NAME
    return Path(repo) / SCAN_DIR_NAME / FINDINGS_JSON_NAME


def write_findings_json(report: FinalReport, repo: Path | str, *,
                        out_dir: Path | str | None = None) -> Path:
    """Persist *report* as JSON in *out_dir* (else under ``<repo>/security-scan/``) and return the path, atomically so a reader in another process never sees a half-written document."""
    # Uncontained: resolve through artifact_dir so a planted <repo>/security-scan symlink or
    # regular file is refused (UnsafeArtifactDir), not silently followed. Contained: out_dir is the
    # state artifacts dir, already vetted and owner-only by the store.
    if out_dir is None:
        path = artifact_dir(repo, SCAN_DIR_NAME) / FINDINGS_JSON_NAME
    else:
        path = findings_json_path(repo, out_dir=out_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(redact_tree(report.model_dump(mode="json")), indent=2) + "\n"
    tmp = path.with_suffix(f"{path.suffix}.tmp")
    with os.fdopen(_open_new_tmp(tmp), "w", encoding="utf-8") as fh:
        fh.write(payload)
    tmp.replace(path)
    return path


def _open_new_tmp(tmp: Path) -> int:
    """A write fd at *tmp*, refusing to follow anything already planted at that fixed name.

    The artifacts directory is writable by the contained scan, so a symlink dropped at this
    predictable name would redirect the host-side write to wherever it points.

    Raises:
        StateIntegrityError: If *tmp* exists as anything but a regular file, cannot be cleared,
            or reappears between the cleanup and the create.
    """
    try:
        mode: int | None = os.lstat(tmp).st_mode
    except OSError:
        mode = None
    if mode is not None and not stat.S_ISREG(mode):
        raise StateIntegrityError(
            f"refusing to write {tmp}: it is not a regular file, so the scan result would not "
            f"land where it belongs. The scan output directory has "
            f"been written to by something other than vvaharness; inspect it before re-running.")
    if mode is not None:
        try:
            tmp.unlink(missing_ok=True)   # a regular leftover from a crashed run
        except OSError as e:
            # A leftover the scan cannot clear is the same refusal, not a bare OSError: the
            # write cannot proceed and the operator needs the path named.
            raise StateIntegrityError(
                f"refusing to write {tmp}: a leftover file there could not be removed ({e}). "
                f"Inspect the scan output directory before re-running.") from e
    try:
        # 0o666: the mode `write_text` left here, so the umask still decides -- this fix
        # closes the symlink hole without also changing who can read the result.
        return os.open(tmp, os.O_CREAT | os.O_EXCL | os.O_WRONLY | _O_NOFOLLOW, 0o666)
    except OSError as e:
        if e.errno in {errno.EEXIST, *_SYMLINK_ERRNOS}:
            raise StateIntegrityError(
                f"refusing to write {tmp}: {e}. Something re-created that path while the "
                f"scan result was being written; inspect the scan output directory.") from e
        raise  # ENOSPC/EACCES/EROFS etc. -- an environment fault, not an attack


def read_findings_json(repo: Path | str, *,
                       out_dir: Path | str | None = None) -> FinalReport | None:
    """Load the typed result for *repo*, from *out_dir* when the scan relocated its output."""
    # ``None`` when absent (older build); raises when present but invalid — never partially trusted
    path = findings_json_path(repo, out_dir=out_dir)
    data = _read_regular(path)
    if data is None:
        return None
    return _validated(path, data)


def _read_regular(path: Path) -> bytes | None:
    """*path*'s bytes through an ``O_NOFOLLOW`` fd that must be a regular file; None when absent.

    The directory holding this is writable by a contained scan and the name is fixed, so a plain
    ``read_text`` would follow a symlink swapped in at it. Read like the report beside it
    (``discovery._read_vetted_report``): name and bytes match. Bytes, not text, so bad UTF-8
    becomes a `ValidationError` the caller turns into `InvalidFindingsJSON`, not a raw
    `UnicodeDecodeError`. ``O_NONBLOCK`` so a FIFO planted at the name does not block the open;
    the regular-file check then refuses it. The flag is a no-op on the regular file it must be,
    and `_O_NONBLOCK` is 0 on Windows, where the constant is absent.

    Raises:
        StateIntegrityError: If the path exists as anything but a regular file.
    """
    try:
        fd = os.open(path, os.O_RDONLY | _O_NONBLOCK | _O_NOFOLLOW)
    except OSError as exc:
        if exc.errno == errno.ENOENT:
            return None  # absent is "older build"
        if exc.errno in _SYMLINK_ERRNOS:
            raise StateIntegrityError(
                f"refusing to read {path}: it is a symlink, not a regular scan result.") from exc
        raise
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise StateIntegrityError(
                f"refusing to read {path}: it is not a regular file.")
        handle = os.fdopen(fd, "rb")
    except BaseException:
        os.close(fd)        # nothing has taken ownership of the fd yet
        raise
    with handle:            # from here the handle owns the fd and closes it exactly once
        return handle.read()


def _validated(path: Path, data: bytes) -> FinalReport:
    try:
        return FinalReport.model_validate_json(data)
    except (ValidationError, ValueError) as exc:
        raise InvalidFindingsJSON(
            f"{path} is not a readable scan result: {exc}") from exc
