# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Claude Agent SDK backend for the Remediation Agent's fix mode (`via: sdk`); sdk.py is read-only."""

from __future__ import annotations

import asyncio
import contextlib
import os
import re
import time
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, NamedTuple, cast

from vvaharness.backends.llm import tools as _llm_tools
from vvaharness.backends.llm.cli import (
    _NO_REFUSAL_RESEND_ENV,
    _POST_SCAN_EXTRA_READ_DENY_RULES,
    _READ_DENY_RULES,
)
from vvaharness.backends.llm.models import (
    DEFAULT_READ_TOOLS,
    TIMEOUT_STOP_GRACE_SECONDS,
    ClockKind,
    call_timeout_error,
    effort_scaled_seconds,
    note_budget_use,
)
from vvaharness.report.redact import redact_counts
from vvaharness.util import console
from vvaharness.util.git_paths import first_folded_part, fold_name, is_git_metadata
from vvaharness.util.tokens import TOKENS, TokenUsage

if TYPE_CHECKING:
    from claude_agent_sdk import ResultMessage

# Reads are confined to cwd and the post-scan deny set; file-mutation tools are gated to cwd.
_WRITE_TOOLS = frozenset({"Edit", "Write", "MultiEdit", "NotebookEdit"})
# Read-only inspection tools: path-checked by the gate, output filtered and redaction-hooked.
READ_TOOLS = frozenset({"Read", "Glob", "Grep", "LS", "NotebookRead"})
# Masked by the PostToolUse hook so on-disk secrets/PII aren't egressed unredacted.
_REDACT_TOOLS = READ_TOOLS | frozenset({"Bash"})


def pre_tool_deny(reason: str) -> dict:
    """The PreToolUse hook result that denies a call with *reason*."""
    return {"hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "deny",
        "permissionDecisionReason": reason,
    }}


def gate_error_reason(exc: Exception) -> str:
    """The denial text for a gate that raised: it must fail closed, not open."""
    return (f"the security gate could not evaluate this call "
            f"({type(exc).__name__}) and denies it as a precaution.")


_CLI_TRIMMED_EDGES = re.compile(r"^[\s\ufeff]+|[\s\ufeff]+$")
_CLI_HOME_PREFIXES = ("~/", "~\\")


def _resolve_within_root(
    root: Path, raw: object, *, follow_final_link: bool = False,
) -> Path | None:
    """Resolve *raw* to a real path confined to *root*, or None if unresolvable/escaping.

    A symlinked final component is refused unless *follow_final_link* is set (reads): writes
    must not be redirected through a link, but a read follows it and judges the target.
    The path is judged as the CLI opens it: edge whitespace is trimmed, and ``~`` and ``~/...``
    (home-relative) are refused because the CLI expands them to the home directory, which this
    check would resolve inside *root*.
    """
    if not isinstance(raw, str):
        return None
    text = _CLI_TRIMMED_EDGES.sub("", raw)
    if not text or text == "~" or text.startswith(_CLI_HOME_PREFIXES):
        return None
    try:
        candidate = Path(text) if os.path.isabs(text) else (root / text)
        if not follow_final_link and candidate.is_symlink():
            return None
        target = candidate.resolve()
        target.relative_to(root)
    except (OSError, RuntimeError, ValueError):
        return None
    return target


def _within_root(root: Path, raw: object) -> bool:
    """Return True iff *raw* resolves to a non-symlinked path inside (or equal to) *root*."""
    return _resolve_within_root(root, raw) is not None


def _read_arg_keys(tool_name: str) -> tuple[str, ...]:
    """Path-shaped argument keys *tool_name* might carry."""
    keys = ("file_path", "path", "notebook_path")
    if tool_name == "Glob":
        return (*keys, "pattern")
    if tool_name == "Grep":
        # `glob` is path-shaped (a `!` pattern only excludes, see `_grep_glob_patterns`);
        # `pattern` stays out (content regex)
        return (*keys, "glob")
    return keys


class _ReadJudge(NamedTuple):
    """`_read_refusal`'s path-decision strategy: who decides, what to say, and the one exemption."""

    judge: Callable[[str, tuple[str, ...]], str | None]
    session: str
    outside_ok: Callable[[str, object], bool] | None
    follow_links: bool = False


def _refused_key_value(tool_name: str, key: str, raw: object, root: Path,
                       how: _ReadJudge) -> str | None:
    """`_read_refusal`'s per-argument decision: why *raw* (at *key*) is refused, or None."""
    resolved = _resolve_within_root(root, raw, follow_final_link=how.follow_links)
    if resolved is None:
        if how.outside_ok is not None and how.outside_ok(key, raw):
            return None
        return (f"{tool_name} target {raw!r} is outside the repository root, "
                f"unresolvable, or a symlink — reads are confined to {root}")
    hit = how.judge(key, resolved.relative_to(root).parts)
    return None if hit is None else (
        f"{tool_name} target {raw!r} falls under the internal {hit!r} "
        f"directory, which is never readable in {how.session}.")


def _grep_glob_patterns(raw: str) -> list[str]:
    """The positive patterns of a Grep `glob`: split like the CLI, and a `!` pattern only excludes."""
    words = ([word] if "{" in word and "}" in word else word.split(",") for word in raw.split())
    return [p for group in words for p in group if p and not p.startswith("!")]


def _read_arg_values(tool_name: str, key: str, raw: object) -> list[object]:
    """The values of one path-shaped argument that the gate judges."""
    if tool_name == "Grep" and key == "glob" and isinstance(raw, str):
        return list(_grep_glob_patterns(raw))
    return [raw]


def _read_refusal(tool_name: str, tool_input: dict, root: Path, how: _ReadJudge) -> str | None:
    """Why a read tool's path arguments are refused, or None; keys and texts are the bridge's."""
    given = [(key, tool_input[key]) for key in _read_arg_keys(tool_name) if tool_input.get(key)]
    for key, raw in given:
        for value in _read_arg_values(tool_name, key, raw):
            reason = _refused_key_value(tool_name, key, value, root, how)
            if reason is not None:
                return reason
    # Read's path must FAIL CLOSED: "no decision" auto-approves a pathless, unconfined Read
    if tool_name == "Read" and not given:
        return (f"{tool_name} requires a file path argument, and none was found in "
                f"this call — denied as a precaution rather than defaulting to an "
                f"unconfined read.")
    return None


def _post_scan_hit(key: str, parts: tuple[str, ...]) -> str | None:
    """`_read_refusal` judge for the post-scan deny set; a Grep `path` may name a directory."""
    rel = "/".join(parts)
    check = _llm_tools._excluded_target if key == "path" else _llm_tools._excluded_rel
    if not rel or not check(rel, None, dirs=_llm_tools._POST_SCAN_EXCLUDED_DIRS):
        return None
    return first_folded_part(parts, _llm_tools._POST_SCAN_EXCLUDED_DIRS)


#: The CLI's per-session directory for a large tool result it tells the model to re-read.
_CLI_TOOL_RESULTS_DIRNAME = "tool-results"


def _in_own_tool_results(input_data: dict, raw: object) -> bool:
    """True for an absolute path inside this session's own CLI tool-results directory."""
    if not isinstance(raw, str) or not Path(raw).is_absolute():
        return False
    transcript_path = input_data.get("transcript_path")
    session_id = input_data.get("session_id")
    if (not isinstance(transcript_path, str) or not transcript_path
            or not isinstance(session_id, str) or not session_id
            or Path(session_id).name != session_id):
        return False
    spill_root = (Path(transcript_path).parent / session_id
                  / _CLI_TOOL_RESULTS_DIRNAME).resolve()
    return _resolve_within_root(spill_root, raw) is not None


def post_scan_read_refusal(input_data: dict, root: Path, *, session: str) -> str | None:
    """Why S10/S11 refuses this read, or None; the session's own saved tool output is exempt."""
    data = input_data or {}

    def _outside_ok(key: str, raw: object) -> bool:
        return (data.get("tool_name") == "Read" and key == "file_path"
                and _in_own_tool_results(data, raw))

    how = _ReadJudge(_post_scan_hit, session, _outside_ok, follow_links=True)
    return _read_refusal(data.get("tool_name") or "", data.get("tool_input") or {}, root, how)


def post_scan_read_verdict(input_data: dict, root: Path, *, session: str,
                           counter: str, label: str) -> dict:
    """The PreToolUse result for a read: ``{}`` to allow, else a denial counted under *counter*."""
    try:
        reason = post_scan_read_refusal(input_data, root, session=session)
    except Exception as exc:  # a gate must fail closed, not open
        reason = gate_error_reason(exc)
    if reason is None:
        return {}
    _llm_tools.note_post_scan_refusal(counter, label)
    return pre_tool_deny(reason)


def _sdk_env() -> dict[str, str]:
    """Inherit the ambient environment, forwarding the SDK-specific key as the standard ANTHROPIC_API_KEY when o..."""
    env = dict(os.environ)
    if not env.get("ANTHROPIC_API_KEY"):
        fallback = (env.get("ANTHROPIC_AUTH_TOKEN")
                    or env.get("ANTHROPIC_SDK_API_KEY"))
        if fallback:
            env["ANTHROPIC_API_KEY"] = fallback
    sdk_base = env.get("ANTHROPIC_SDK_BASE_URL")
    if sdk_base and not env.get("ANTHROPIC_BASE_URL"):
        env["ANTHROPIC_BASE_URL"] = sdk_base
    # Same no-resend env as the CLI route; set last so an ambient "0" cannot win.
    return {**env, **_NO_REFUSAL_RESEND_ENV}


#: Path keys redacted with ``carry=False``; NOT redact's `_NO_CARRY_KEYS` (``file`` holds content)
_TOOL_PATH_KEYS = frozenset({"filePath", "file_path", "filenames", "path"})


def _redact_tool_output(payload: object, *, carry: bool = True) -> object:
    """Mask secret/PII in *payload* (str/list/dict) via redact_counts(); unknown shapes pass."""
    if isinstance(payload, str):
        masked, _ = redact_counts(payload, carry=carry)
        return masked
    if isinstance(payload, list):
        return [_redact_tool_output(item, carry=carry) for item in payload]
    if isinstance(payload, dict):
        return {k: _redact_tool_output(v, carry=carry and k not in _TOOL_PATH_KEYS)
                for k, v in payload.items()}
    return payload


def _rel_under_root(entry: str, root: Path) -> str | None:
    """*entry* made root-relative, or None when absolute and outside *root*.

    An outside-root absolute entry is kept, not an exclusion candidate.
    """
    path = Path(entry)
    if not path.is_absolute():
        return entry
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return None


def _filtered_filenames(filenames: list, root: Path) -> tuple[list, int]:
    """Drop a `filenames` entry under the post-scan deny set; non-str entries pass through."""
    kept = []
    dropped = 0
    for entry in filenames:
        rel = _rel_under_root(entry, root) if isinstance(entry, str) else None
        if rel is not None and _llm_tools._excluded_rel(
                rel, None, dirs=_llm_tools._POST_SCAN_EXCLUDED_DIRS):
            dropped += 1
            continue
        kept.append(entry)
    return kept, dropped


def _filtered_content(content: str, root: Path) -> tuple[str, int]:
    """Drop a Grep `content` line whose path segment is a denied, existing directory.

    The check runs on segments before the trailing match, not the whole line: a match TEXT that
    merely contains ``/.git/`` is not a path.
    """
    prefix = f"{root}/".replace("\\", "/")
    kept: list[str] = []
    dropped = 0
    for line in content.split("\n"):
        norm = line[len(prefix):] if line.startswith(prefix) else line
        segments = norm.replace("\\", "/").split("/")
        hit = any(
            fold_name(seg) in _llm_tools._POST_SCAN_EXCLUDED_DIRS
            and (root / "/".join(segments[:i + 1])).is_dir()
            for i, seg in enumerate(segments[:-1])
        )
        if hit:
            dropped += 1
            continue
        kept.append(line)
    return "\n".join(kept), dropped


#: The numeric fields of a Grep/Glob response, grouped by what they count; `_all_denied` zeroes
#: every one, so a field the filters learn to recompute belongs in a group.
_FILE_COUNT_KEYS = ("numFiles", "totalFiles")
_LINE_COUNT_KEYS = ("numLines", "totalLines")
_MATCH_COUNT_KEYS = ("totalMatches", "numMatches")


def _set_present_keys(out: dict, keys: tuple[str, ...], value: int) -> None:
    """Set every one of *keys* already present in *out* to *value*; never add a key."""
    for key in keys:
        if key in out:
            out[key] = value


def _apply_filename_filter(out: dict, tool_name: str, root: Path) -> int:
    """Filter `out["filenames"]` in place; return the number of entries dropped."""
    filenames = out.get("filenames")
    if not isinstance(filenames, list):
        return 0
    kept, dropped = _filtered_filenames(filenames, root)
    out["filenames"] = kept
    if tool_name == "Glob" or out.get("mode") == "files_with_matches":
        _set_present_keys(out, _FILE_COUNT_KEYS, len(kept))
    if tool_name == "Glob" and isinstance(out.get("totalMatches"), int):
        out["totalMatches"] -= dropped
    return dropped


def _apply_count_mode_totals(out: dict, kept_lines: list[str]) -> None:
    """Set a Grep `count`-mode response's `numFiles`/`numMatches` from the lines that remain.

    `numMatches` is the sum of the kept ``...:N`` lines, so it is 0 when every line was dropped;
    it is left alone only when a kept line has no count to sum.
    """
    tails = [ln.rsplit(":", 1)[-1] for ln in kept_lines]
    if "numFiles" in out:
        out["numFiles"] = len(kept_lines)
    if "numMatches" in out and all(t.isdigit() for t in tails):
        out["numMatches"] = sum(int(t) for t in tails)


def _apply_content_filter(out: dict, root: Path) -> int:
    """Filter `out["content"]` in place; return the number of lines dropped."""
    content = out.get("content")
    if not isinstance(content, str):
        return 0
    new_content, dropped = _filtered_content(content, root)
    out["content"] = new_content
    kept_lines = [ln for ln in new_content.split("\n") if ln]
    _set_present_keys(out, _LINE_COUNT_KEYS, len(kept_lines))
    if out.get("mode") == "count":
        _apply_count_mode_totals(out, kept_lines)
    return dropped


def _drop_post_scan_entries(tool_name: str, response: object, root: Path) -> tuple[object, int]:
    """Remove post-scan deny-set entries from a built-in Grep/Glob response; never changes shape."""
    if tool_name not in ("Grep", "Glob") or not isinstance(response, dict):
        return response, 0
    out = dict(response)
    dropped = _apply_filename_filter(out, tool_name, root) + _apply_content_filter(out, root)
    return out, dropped


def _all_denied(tool_name: str, response: object) -> object:
    """A fail-closed stand-in for *response* when the result filter itself could not run.

    The keys the filters keep for a Grep/Glob dict, every entry and count emptied; the gate's
    own "denies it as a precaution" wording for any other response shape.
    """
    if tool_name not in ("Grep", "Glob") or not isinstance(response, dict):
        return (f"{tool_name} output could not be checked for version-control metadata or "
                f"harness output, and is withheld as a precaution.")
    out = dict(response)
    for key, empty in (("filenames", []), ("content", "")):
        if key in out:
            out[key] = empty
    _set_present_keys(out, (*_FILE_COUNT_KEYS, *_LINE_COUNT_KEYS, *_MATCH_COUNT_KEYS), 0)
    return out


def _filtered_masked(
    result_filter: Callable[[str, object], tuple[object, int]] | None,
    tool_name: str, response: object,
) -> tuple[object, int]:
    """*response* filtered by *result_filter*, then redacted; the count is what was dropped.

    A *result_filter* that fails fails closed: `_all_denied`'s stand-in, never the original.
    """
    if result_filter is None:
        return _redact_tool_output(response), 0
    try:
        filtered, dropped = result_filter(tool_name, response)
        return _redact_tool_output(filtered), dropped
    except Exception:
        return _all_denied(tool_name, response), 1


def _build_redaction_hooks(
    result_filter: Callable[[str, object], tuple[object, int]] | None = None,
):
    """Build a PostToolUse hook masking Read/Grep/Bash; best-effort, None if HookMatcher missing.

    *result_filter*, when given, is ``(tool_name, response) -> (filtered_response, dropped)``,
    applied before masking; a non-zero *dropped* is counted under its own post-scan counter,
    apart from refused reads: a result filter drops hundreds of entries per run.
    """
    try:
        from claude_agent_sdk import HookMatcher  # type: ignore  # noqa: PLC0415 — optional SDK
    except Exception:
        return None

    async def _post_tool_use(input_data, tool_use_id, context):  # noqa: ANN001, ARG001
        try:
            tool_name = (input_data or {}).get("tool_name")
            if tool_name not in _REDACT_TOOLS:
                return {}
            response = (input_data or {}).get("tool_response")
            if response is None:
                return {}
            masked, dropped = _filtered_masked(result_filter, tool_name, response)
            _llm_tools.note_post_scan_filter(
                "agent_sdk_post_scan_entries_filtered", "remediate", dropped)
            if masked == response:
                return {}
            # `updatedToolOutput` is the only key the CLI honours; the old name leaked cleartext.
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PostToolUse",
                    "updatedToolOutput": masked,
                }
            }
        except Exception:
            return {}

    try:
        return {"PostToolUse": [HookMatcher(hooks=[_post_tool_use])]}  # type: ignore[list-item]
    except Exception:
        return None


def _build_options(*, model: str, system_prompt: str | None,
                   allowed_tools: list[str], cwd: str,
                   max_budget_usd: float | None, max_turns: int | None):
    """Compose ClaudeAgentOptions with a cwd-confined write gate; lazy import keeps SDK optional."""
    try:
        from claude_agent_sdk import (  # noqa: PLC0415 — lazy: SDK stays optional
            ClaudeAgentOptions,
            HookMatcher,
        )
    except ImportError as e:
        raise RuntimeError(
            "This Claude Agent SDK build has no PreToolUse hook support "
            "(HookMatcher), which is what enforces the cwd-confined write "
            "gate on `via: sdk` (see _pre_tool_use_gate's docstring) — "
            "reinstall vvaharness to pull in a newer SDK release."
        ) from e

    root = Path(cwd).resolve()

    async def _pre_tool_use_gate(input_data, tool_use_id, context):  # noqa: ANN001, ARG001
        """PreToolUse hook enforcing the write-confinement + deny-by-default gate."""
        # Must stay PreToolUse, never can_use_tool (a bare allow entry bypasses it); fail-closed
        try:
            tool_name = (input_data or {}).get("tool_name") or ""
            tool_input = (input_data or {}).get("tool_input") or {}

            # File-mutation tools: allow only when the target stays inside the repo.
            if tool_name in _WRITE_TOOLS:
                raw = key_used = None
                for key in ("file_path", "path", "notebook_path"):
                    val = tool_input.get(key)
                    if val:
                        raw, key_used = val, key
                        break
                resolved = _resolve_within_root(root, raw)
                if resolved is None:
                    return pre_tool_deny(f"{tool_name} target {raw!r} is outside the "
                                         f"repository root, unresolvable, or a symlink — "
                                         f"edits are confined to {root}")
                if is_git_metadata(resolved.relative_to(root)):
                    return pre_tool_deny(f"{tool_name} target {raw!r} is version-control "
                                         f"metadata (.git), which remediation never edits.")
                # Hand the SDK the resolved path, not the raw name, so an alias can't redirect it.
                safe_input = dict(tool_input)
                safe_input[key_used] = str(resolved)
                return {"hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "allow",
                    "updatedInput": safe_input,
                }}
            # Read-only tools: confined to the repo and the post-scan deny set; the bare
            # allow entry covers the rest.
            if tool_name in READ_TOOLS:
                return post_scan_read_verdict(
                    input_data, root, session="a remediation session",
                    counter="agent_sdk_post_scan_read_refused", label="remediate")
            # DENY-BY-DEFAULT, esp. Bash: host-shell RCE + credential exfil; re-adding it can't run.
            return pre_tool_deny(f"{tool_name} is not permitted in remediation fix mode — "
                                 f"only Read/Glob/Grep and cwd-confined Edit/Write are "
                                 f"allowed (Bash and other tools are denied by default).")
        except Exception as exc:
            return pre_tool_deny(gate_error_reason(exc))

    redaction_hooks = _build_redaction_hooks(
        result_filter=lambda name, resp: _drop_post_scan_entries(name, resp, root)) or {}
    hooks = {**redaction_hooks, "PreToolUse": [HookMatcher(hooks=[_pre_tool_use_gate])]}

    opts = ClaudeAgentOptions(
        model=model,
        cwd=str(root),
        env=_sdk_env(),
        # The PreToolUse hook above is the live gate; permission_mode/allowed_tools set availability
        permission_mode="default",
        # "user" only: a scanned repo's own .claude/settings.json can never re-grant Bash or
        # register a host hook into this Edit/Write-capable session (mirrors the via:cli
        # route's --setting-sources user).
        setting_sources=["user"],
        # Without this, a target repo's own .mcp.json server would be spawned into this
        # session (mirrors cli_mcp.py's strict_mcp_config=True).
        strict_mcp_config=True,
        allowed_tools=list(allowed_tools),
        # A second layer: the CLI applies these rules to Grep and Glob results before the
        # hooks see them.
        disallowed_tools=[*_READ_DENY_RULES, *_POST_SCAN_EXTRA_READ_DENY_RULES],
        hooks=hooks,
        # Own pipe: an inherited stderr comes back non-blocking and breaks a merged 2>&1 stdout
        stderr=console.write,
        # Finding text/code snippets reach this prompt; verbatim keeps them from being
        # parsed as an @path expansion or a slash command.
        verbatim_prompts=True,
    )

    if system_prompt is not None:
        opts.system_prompt = system_prompt
    if max_turns is not None:
        opts.max_turns = int(max_turns)
    if max_budget_usd is not None:
        opts.max_budget_usd = float(max_budget_usd)
    return opts


class DrainResult(NamedTuple):
    """One drain pass's outcome: the terminal ResultMessage, if any, and whether it timed out."""

    result: ResultMessage | None
    timed_out: bool


async def _drain(client, on_message) -> ResultMessage | None:  # noqa: ANN001
    """One fresh pass over `client.receive_response()`, returning the terminal ResultMessage."""
    from claude_agent_sdk import ResultMessage  # noqa: PLC0415 — lazy: SDK stays optional

    async for message in client.receive_response():
        on_message(message)
        if isinstance(message, ResultMessage):
            return message
    return None


async def drain_until_result(client, *, on_message, timeout: float | None,
                             grace: float = TIMEOUT_STOP_GRACE_SECONDS) -> DrainResult:
    """Drain *client* to its terminal result, bounded by `timeout`; interrupt-then-regrace on expiry."""
    if timeout is None or timeout <= 0:
        return DrainResult(await _drain(client, on_message), False)
    # .expired() tells OUR deadline apart from a TimeoutError raised inside the drain itself
    deadline = asyncio.timeout(timeout)
    try:
        async with deadline:
            return DrainResult(await _drain(client, on_message), False)
    except TimeoutError:
        if not deadline.expired():
            raise
    with contextlib.suppress(Exception):
        await client.interrupt()
    # The cancelled `async for` above finalized its generator; receive_response() opens a new one
    # (claude_agent_sdk.client.ClaudeSDKClient), so this second _drain is a fresh call, not a resume.
    regrace = asyncio.timeout(grace)
    try:
        async with regrace:
            return DrainResult(await _drain(client, on_message), True)
    except TimeoutError:
        if not regrace.expired():
            raise
        return DrainResult(None, True)


async def _run(*, user_prompt: str, opts, timeout: float | None = None,
               tag: str | None = None, effort: str | None = None) -> str:  # noqa: ANN001
    """Stream one agentic session to completion and return the final text."""
    from claude_agent_sdk import (  # noqa: PLC0415 — lazy: SDK stays optional
        AssistantMessage,
        ClaudeSDKClient,
        TextBlock,
    )

    text_parts: list[str] = []

    def _on_message(message) -> None:  # noqa: ANN001
        if isinstance(message, AssistantMessage):
            for block in message.content:
                if isinstance(block, TextBlock):
                    text_parts.append(block.text)

    # Session clock, scaled the same way every other route scales its own agentic() timeout.
    budget = effort_scaled_seconds(timeout, effort, kind=ClockKind.SESSION)
    # The caller owns no scope around this call: the client's __aexit__ (close()) must run with
    # no cancellation in flight, or the SDK skips its own terminate/kill escalation (subprocess_cli.py).
    _start = time.monotonic()
    async with ClaudeSDKClient(options=opts) as client:
        await client.query(user_prompt)
        drained = await drain_until_result(client, on_message=_on_message, timeout=budget,
                                           grace=TIMEOUT_STOP_GRACE_SECONDS)

    result = drained.result
    if result is not None and result.usage:
        TOKENS.add(cast("TokenUsage", result.usage))
    if drained.timed_out:
        raise call_timeout_error(
            stage=tag or "", route="agent-sdk", budget_s=budget, effort=effort,
            cause_text=f"agent-sdk session exceeded {budget:g}s")
    note_budget_use(time.monotonic() - _start, budget, effort)
    result_text = result.result if result is not None else None
    return (result_text or "".join(text_parts)).strip()


def agentic(
    user_prompt: str,
    *,
    model: str,
    system_prompt: str | None = None,
    allowed_tools: list[str] | None = None,
    cwd: str,
    max_budget_usd: float | None = None,
    permission_mode: str = "auto",   # accepted for parity; gate handles policy
    max_turns: int | None = None,
    tag: str | None = None,
    timeout: float | None = None,
    effort: str | None = None,
) -> str:
    """Run an agentic loop with native Edit/Write/Bash via the Agent SDK; writes cwd-confined."""
    try:
        import claude_agent_sdk  # noqa: F401, PLC0415 — availability probe
    except ImportError as e:
        raise RuntimeError(
            "An agentic role is configured `via: sdk` and requests file-editing "
            "tools (Edit/Write/Bash), which require the Claude Agent SDK. "
            "Reinstall vvaharness to pull it in (pip install .), or "
            "set this role to `via: cli`."
        ) from e
    # `None` = unspecified (read-only default), `[]` = none wanted; same as backends.llm.sdk.agentic
    allowed = list(DEFAULT_READ_TOOLS) if allowed_tools is None else list(allowed_tools)
    tag_sfx = f" [{tag}]" if tag else ""
    console.write(f"    [agent-sdk] agentic -> {model}{tag_sfx} (tools={allowed}, "
                  f"max_turns={max_turns}, cwd={cwd}, timeout={timeout})")

    opts = _build_options(
        model=model, system_prompt=system_prompt, allowed_tools=allowed,
        cwd=cwd, max_budget_usd=max_budget_usd, max_turns=max_turns,
    )
    return asyncio.run(_run(user_prompt=user_prompt, opts=opts, timeout=timeout,
                            tag=tag, effort=effort))
