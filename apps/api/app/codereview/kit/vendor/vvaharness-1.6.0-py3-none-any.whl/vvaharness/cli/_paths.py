# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Config/repo path resolution and the trust gate shared by every subcommand."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import TYPE_CHECKING, NoReturn

from vvaharness.util import console

if TYPE_CHECKING:
    from vvaharness.config import Config


def _load_and_configure(cfg_path: str, label: str) -> Config | None:
    """load() plus backend configuration; a policy refusal is reported and returns None."""
    from vvaharness import config as config_mod
    from vvaharness.orchestrator import configure_backends
    try:
        cfg = config_mod.load(cfg_path)
    except config_mod.ConfigPolicyError as e:
        console.write(f"{label}: {e}")
        return None
    configure_backends(cfg, Path(cfg_path).resolve().parent)
    return cfg

def _config_path_from_explicit(rest: list[str], *, quiet: bool = False) -> tuple[str, bool]:
    """Resolve the effective --config path (or =-joined form) and whether it was explicitly given, else the packaged default and ``False``."""
    from vvaharness.orchestrator import _default_config
    found: str | None = None
    for i, a in enumerate(rest):
        # Last occurrence wins, matching argparse's behaviour on a repeated flag.
        if a == "--config" and i + 1 < len(rest):
            found = rest[i + 1]
        elif a.startswith("--config="):
            found = a.split("=", 1)[1]
    if found is not None:
        return found, True
    return str(_default_config(quiet=quiet)), False

def _config_path_from(rest: list[str]) -> str:
    """Resolve the effective --config path (or =-joined form), else the packaged default."""
    return _config_path_from_explicit(rest)[0]

class _TargetArgs(argparse.ArgumentParser):
    """An argparse parser for the trust gate: it must never print usage or exit."""

    def error(self, message: str) -> NoReturn:
        raise ValueError(message)


def _target_namespace(rest: list[str], *flags: str) -> argparse.Namespace | None:
    """Parse only the named string flags out of *rest* the way the command parser would; None when argparse rejects the argv."""
    ap = _TargetArgs(add_help=False)
    for flag in flags:
        ap.add_argument(flag)
    try:
        return ap.parse_known_args(rest)[0]
    except ValueError:
        return None


def _trust_boundaries(rest: list[str]) -> tuple[str, ...]:
    """Every path the command in *rest* scans, from raw argv: the paths the trust gate keeps config and ``.env`` files out of."""
    if not rest:
        return ()
    from vvaharness.cli import VALIDATE_COMMANDS, _with_command
    argv = _with_command(rest)
    cmd, tail = argv[0], list(argv[1:])
    if "--" in tail:
        tail.remove("--")  # the command parser drops the first bare "--" before dispatch
    literal = _repo_from(tail)
    found = [] if literal is None else [literal]
    if cmd == "scan":
        ns = _target_namespace(tail, "--repo", "--repo-file", "--workspace")
        if ns is not None:
            if ns.repo is not None:
                found.append(ns.repo)
            if ns.repo_file is not None:
                from vvaharness.orchestrator.batch import scan_boundaries
                found.extend(scan_boundaries(None, ns.repo_file, ns.workspace))
    elif cmd in VALIDATE_COMMANDS:
        ns = _target_namespace(tail, "--repo")
        if ns is not None and ns.repo is not None:
            found.append(ns.repo)
    return tuple(dict.fromkeys(found))

def _check_python() -> str | None:
    """Return an error string if the interpreter is older than the package's Requires-Python floor, else None."""
    try:
        from importlib.metadata import metadata
        req = metadata("vvaharness").get("Requires-Python") or ""
    except Exception:
        return None
    import re
    m = re.search(r">=\s*(\d+)\.(\d+)", req)
    if not m:
        return None
    floor = (int(m.group(1)), int(m.group(2)))
    if sys.version_info[:2] < floor:
        cur = ".".join(str(v) for v in sys.version_info[:3])
        return (f"vvaharness requires Python >= {floor[0]}.{floor[1]}; this "
                f"interpreter is {cur}. Please use a newer Python.")
    return None

def _repo_from(rest: list[str]) -> str | None:
    """Extract the --repo target (split or =-joined form) from raw args, else None."""
    found: str | None = None
    for i, a in enumerate(rest):
        # Last occurrence wins, as argparse and the containment gate read it: a first-wins read
        # would judge .env and --config against a decoy target the run never scans.
        if a == "--repo" and i + 1 < len(rest):
            found = rest[i + 1]
        elif a.startswith("--repo="):
            found = a.split("=", 1)[1]
    return found
