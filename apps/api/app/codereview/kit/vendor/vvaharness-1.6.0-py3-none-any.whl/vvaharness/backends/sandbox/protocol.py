# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The whole-invocation sandbox contract every backend (built-in or third-party) implements."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from vvaharness.backends.sandbox.models import Capability, SandboxSpec


class Sandbox(Protocol):
    """Declare what you enforce, fail loud before work starts, run once, always tear down."""

    @property
    def capabilities(self) -> Capability:
        """What this backend actually enforces, not what it is asked for.

        Checked against the requested level before anything runs, so a backend that cannot
        deliver refuses instead of silently under-containing the run.
        """
        ...

    def preflight(self, spec: SandboxSpec) -> None:
        """Raise if *spec* cannot actually be satisfied; never fail partway through `run`."""
        ...

    def run(self, argv: Sequence[str], env: Mapping[str, str], timeout: float | None) -> int:
        """Run *argv* to completion inside the sandbox and return its exit code."""
        ...

    def teardown(self) -> None:
        """Release whatever `run` allocated. Called unconditionally, even after a failure."""
        ...


__all__ = ["Sandbox"]
