# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""The state DB itself: where it lives, how it is opened and hardened, and run rows."""
from __future__ import annotations

import errno
import os
import re
import secrets
import shutil
import sqlite3
import stat
import sys
import time
from collections.abc import Collection
from contextlib import contextmanager, suppress
from enum import StrEnum
from functools import partial
from pathlib import Path
from typing import Final

from vvaharness.orchestrator.store._schema import (
    _DDL,
    _DDL_V2,
    _DDL_V3,
    _DDL_V4_CHECKPOINTS,
    _DDL_V4_EV_PROBES,
    _DDL_V4_EV_PROBES_INDEX,
    _DDL_V4_EV_REPLAYS,
    _DDL_V4_RUN_INSTANCES,
)
from vvaharness.util.warn_once import warn_once

# Guarded at IMPORT, not at use: fcntl does not exist on Windows.
try:
    import fcntl
except ImportError:
    fcntl = None

_SCHEMA_VERSION = 4

#: Stamped on rows the v4 rebuild copies, and used by every caller that never begins an instance
LEGACY_INSTANCE_ID: Final[str] = "legacy"

#: What new_instance_id mints (token_hex(16)); every id that reaches a host path is matched against it
_INSTANCE_ID_RE: Final = re.compile(r"\A[0-9a-f]{32}\Z")

#: What checkpoints.run_id_for mints (32-char sha256 prefix); vets runs.run_id read back from the DB
_RUN_ID_RE: Final = re.compile(r"[0-9a-f]{32}")


def _current_instance() -> str:
    """This process's instance id. The authoritative global lives on the ``store`` package
    (so the suite's ``monkeypatch.setattr(store, "_CURRENT_INSTANCE", ...)`` reset is honoured);
    imported lazily to avoid a package<->submodule import cycle at load time."""
    from vvaharness.orchestrator import store
    return store.current_instance_id()

# Bundles are small (bodies capped at 512 bytes); enforced here AND by a CHECK, so direct INSERT too
_REPLAY_MAX_BYTES = 1024 * 1024

# Confidentiality: payloads embed scanned SOURCE, sqlite3 creates at umask 0644; pin 0600 + sidecars
_DB_FILE_MODE = 0o600
_STATE_DIR_MODE = 0o700
_SIDECAR_SUFFIXES = ("-wal", "-shm", "-journal")
# Windows has no meaningful chmod/POSIX mode bits: every hardening step below is gated on this.
_POSIX = os.name == "posix"
_PERM_WARNED: set[str] = set()
# Absent on Windows, where the flock path returns before any open() anyway.
_O_NOFOLLOW: Final = getattr(os, "O_NOFOLLOW", 0)
# What O_NOFOLLOW reports on a symlink (ELOOP Linux, EMLINK macOS/BSD); ENOTDIR = planted file
_SYMLINK_ERRNOS: Final = frozenset({errno.ELOOP, errno.EMLINK, errno.ENOTDIR})


def _warn_once(key: str, message: str) -> None:
    """Permission problems degrade to a single stderr warning per path per process — a confidentiality hardening..."""
    warn_once(_PERM_WARNED, key, f"  [store] WARN: {message}")


def _tighten_mode(path: Path, mode: int) -> None:
    """Best-effort chmod of *path* down to *mode* when it is looser."""
    # Never raises; never loosens an already-tighter mode; non-POSIX is skipped entirely
    # lstat, and a symlink is left alone: chmod follows it, and a planted link must not be followed
    if not _POSIX:
        return
    try:
        st = os.lstat(path)
    except OSError:
        return  # absent (e.g. no sidecar yet) — nothing to tighten
    if stat.S_ISLNK(st.st_mode):
        _warn_once(str(path),
                   f"not tightening permissions on {path}: it is a symlink. "
                   f"Nothing under the state root should be one — inspect it")
        return
    current = stat.S_IMODE(st.st_mode)
    if not (current & ~mode):
        return  # already at least as tight as the target
    try:
        os.chmod(path, mode)
    except OSError as e:
        _warn_once(str(path),
                   f"could not tighten permissions on {path} (mode "
                   f"{current:o}; it holds scanned-source snippets): {e}")


class StoreError(RuntimeError):
    """A state-store precondition we refuse to silently work around: a symlinked state directory or DB path, or a state root that exists but is not a directory."""


class StateIntegrityError(StoreError):
    """A value read back from the state tree is not one this code could have written."""
    # The state dir is container-writable at every sandbox.fs level: what comes out is untrusted


class InstanceStatus(StrEnum):
    """Lifecycle of one scan invocation in ``run_instances``."""

    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


def is_known_instance_id(instance_id: str) -> bool:
    """True when *instance_id* is one this code could have written: a ``token_hex(16)`` or the legacy sentinel."""
    # The one accept-list; readers of the artifacts tree (remediation_agent.discovery) share it
    return bool(instance_id == LEGACY_INSTANCE_ID
                or _INSTANCE_ID_RE.match(instance_id or ""))


def _validated_instance_id(instance_id: str, *, source: str) -> str:
    """Return *instance_id* if this code could have minted it, else refuse the run."""
    # An id read back from the DB becomes a HOST path component (state_artifacts_dir)
    if is_known_instance_id(instance_id):
        return instance_id
    raise StateIntegrityError(
        f"refusing instance id {instance_id!r} from {source}: expected 32 hex "
        f"characters or {LEGACY_INSTANCE_ID!r}. The state store has been written "
        f"to by something other than vvaharness; inspect or evict it "
        f"(`vvaharness gc`) before re-running.")


def state_root() -> Path:
    """Where scan state lives, resolved and nothing more."""
    # Deliberately NO I/O: scan.py resolves this pre-safety-check, so --stop-after must not mkdir ~
    return Path(os.environ.get("VVAHARNESS_STATE_DIR")
                or Path.home() / ".vvaharness" / "state")


def ensure_state_dir(*parts: str) -> Path:
    """Return ``state_root()/ *parts``, creating each level owner-only."""
    # Only place state-root dirs are made; tighten EVERY level (parents=True leaves umask default)
    root = state_root()
    if _POSIX:
        # lstat BEFORE anything follows it: is_dir() would follow, letting a planted link redirect
        try:
            lst = root.lstat()
        except OSError:
            lst = None
        if lst is not None and stat.S_ISLNK(lst.st_mode):
            raise StoreError(
                f"refusing to use state directory {root}: it is a symlink")
    if root.is_dir():
        # NOT one decision: VVAHARNESS_STATE_DIR -> warn only (operator chose it); default -> repair
        if _POSIX:
            try:
                mode = stat.S_IMODE(root.stat().st_mode)
            except OSError:
                mode = 0
            if mode & 0o077:
                if os.environ.get("VVAHARNESS_STATE_DIR"):
                    _warn_once(
                        str(root),
                        f"state directory {root} is group/other-accessible "
                        f"(mode {mode:o}) and holds scanned-source snippets — "
                        "consider `chmod 700` if it is not shared on purpose")
                else:
                    _tighten_mode(root, _STATE_DIR_MODE)
                    _warn_once(
                        str(root),
                        f"tightened {root} from mode {mode:o} to 700 — it holds "
                        "scanned-source snippets. Set VVAHARNESS_STATE_DIR to a "
                        "path you manage if you need to share this state")
    else:
        try:
            root.mkdir(parents=True, exist_ok=True)
        except FileExistsError as e:
            # exist_ok forgives only an existing *directory*; a plain file is refused cleanly
            raise StoreError(
                f"refusing to use state directory {root}: it exists and is not "
                "a directory") from e
        # A directory this process created is owner-only by construction.
        _tighten_mode(root, _STATE_DIR_MODE)
    path = root
    for part in parts:
        _check_component(part)
        path = path / part
        _mkdir_no_symlink(path)
        _tighten_mode(path, _STATE_DIR_MODE)
    # Every level created beneath the root is pinned; the resolved leaf must still land inside it
    if parts and not _resolved_within(path, root):
        raise StateIntegrityError(
            f"refusing state directory {path}: it resolves outside the state root "
            f"{root}")
    return path


def _resolved_within(path: Path, root: Path) -> bool:
    """True when *path* resolves inside *root*; a resolve() that cannot complete (a loop) is not inside."""
    try:
        return path.resolve().is_relative_to(root.resolve())
    except OSError:
        return False


def within_state_root(path: Path) -> bool:
    """True when *path* resolves inside the state root."""
    # Seam for host-side readers of the container-writable artifacts tree (remediation discovery)
    return _resolved_within(path, state_root())


def _check_component(part: str) -> None:
    """Refuse a path component that could leave the state root."""
    # Path("/a") / "/etc" is /etc and mkdir resolves "..": ids read from the DB are checked first
    if (not part or part in (".", "..") or os.path.isabs(part)
            or "/" in part or "\\" in part):
        raise StateIntegrityError(
            f"refusing unsafe state-directory component {part!r}")


def check_run_id(run_id: str) -> None:
    """Refuse a ``runs.run_id`` this code could not have minted (32 hex characters, what run_id_for mints)."""
    # Public seam for callers vetting a batch BEFORE acting on any
    if is_run_id(run_id):
        return
    raise StateIntegrityError(
        f"refusing run id {run_id!r} from the runs table: expected 32 hex characters "
        f"(what run_id_for mints), because a run id becomes a delete path under the "
        f"artifacts tree and a lock path. Nothing has been deleted. The state store has "
        f"been written to by something other than vvaharness; inspect it and then remove "
        f"the state directory ({state_root()}) — it is rebuilt on the next run, at the "
        f"cost of losing resumable state — before re-running.")


def _mkdir_no_symlink(path: Path) -> None:
    """Create one level under the state root, refusing a symlink or non-directory."""
    # mkdir(exist_ok=True) accepts a symlink-to-dir and _tighten_mode would chmod through it
    try:
        path.mkdir()
    except FileExistsError:
        pass
    if path.is_symlink():
        raise StateIntegrityError(
            f"refusing state directory {path}: it is a symlink, and everything "
            f"beneath the state root must be a real directory")
    if not path.is_dir():
        raise StateIntegrityError(
            f"refusing state directory {path}: it exists and is not a directory")


#: Shared by both resolvers below so the filename exists once.
_DB_NAME = "vvaharness.db"


def db_location() -> Path:
    """The DB path, creating NOTHING -- the read-only counterpart of `db_path`."""
    # Asking whether state exists must not create the state directory; `gc` needs exactly this
    return state_root() / _DB_NAME


def run_exists(run_id: str) -> bool:
    """Look up a run without creating, migrating or changing store permissions."""
    path = db_location()
    try:
        for candidate in (state_root(), path):
            if candidate.is_symlink():
                raise StoreError(f"refusing to inspect state path {candidate}: it is a symlink")
        try:
            path.stat()
        except FileNotFoundError:
            return False
        con = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
        try:
            return con.execute("SELECT 1 FROM runs WHERE run_id = ?", (run_id,)).fetchone() is not None
        finally:
            con.close()
    except (OSError, sqlite3.Error) as error:
        raise StoreError(f"could not inspect state database at {path}: {error}") from error


def db_path() -> Path:
    """Resolve the state DB path the same way scan.py resolves the legacy ``checkpoints/`` root, so ``--resume`` and the in-target safety check see the same location."""
    return ensure_state_dir() / _DB_NAME


_ARTIFACTS_DIR_NAME = "artifacts"


def state_artifacts_dir(run_id: str, instance_id: str) -> Path:
    """Return ``<state_root>/artifacts/<run_id>/<instance_id>/``, created owner-only."""
    # Contained runs' output: the repo mount may be read-only; the instance separates concurrent scans
    return ensure_state_dir(_ARTIFACTS_DIR_NAME, run_id,
                            _validated_instance_id(instance_id,
                                                   source="an artifacts path"))


def state_artifacts_root(run_id: str) -> Path:
    """Return ``<state_root>/artifacts/<run_id>/`` without creating it — report discovery only reads."""
    # Validated like every joined component: an absolute run_id would discard the base entirely
    _check_component(run_id)
    return state_root() / _ARTIFACTS_DIR_NAME / run_id


def _create_db_file_safe(path: Path) -> None:
    """Create the DB file owner-only, refusing a symlink planted at *path*."""
    # Pre-create 0600 before sqlite3's 0644; O_EXCL|O_NOFOLLOW (sqlite3 lacks both), lstat if extant
    try:
        os.close(os.open(path, os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_RDWR,
                         _DB_FILE_MODE))
        return  # freshly created by us, so not a symlink
    except OSError as err:
        open_err = err  # already exists, or is a symlink; either way, checked below
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        # Report the create's own cause (e.g. EACCES on a read-only dir), not lstat's ENOENT.
        raise FileNotFoundError(
            f"could not create state DB at {path}: {open_err.strerror}") from open_err
    if stat.S_ISLNK(st.st_mode):
        raise StoreError(f"refusing to open state DB at {path}: it is a symlink")
    if not stat.S_ISREG(st.st_mode):
        # sqlite3.connect would open a device or FIFO planted in the container-writable state dir
        raise StateIntegrityError(
            f"refusing to open state DB at {path}: it is not a regular file. The state "
            f"store has been written to by something other than vvaharness; inspect or "
            f"evict it before re-running.")


def connect() -> sqlite3.Connection:
    """Open the state DB, ensure the schema exists, and return a connection — cheap enough to call per operation since sqlite3 connections are thread-affine."""
    path = db_path()
    if _POSIX:
        _create_db_file_safe(path)
    con = sqlite3.connect(path)
    # Per-connection pragmas — must be set on every handle.
    con.execute("PRAGMA foreign_keys = ON")
    con.execute("PRAGMA busy_timeout = 30000")
    con.execute("PRAGMA synchronous  = NORMAL")
    # The schema defines no trigger or view, so one here was planted -- a container that shared
    # this root could -- and SQLite would run its body inside this process's own writes. Matched
    # as what IS allowed: SQLite also loads a trigger whose `type` is written `TRIGGER`, or
    # `trigger` followed by a NUL, and neither equals 'trigger' in SQL.
    if con.execute("SELECT 1 FROM sqlite_master WHERE type NOT IN ('table', 'index')").fetchone():
        con.close()
        raise StateIntegrityError(
            f"refusing to use state DB at {path}: it defines a trigger or view, which "
            f"vvaharness never creates. The state store has been written to by something "
            f"other than vvaharness; inspect it and then remove the state directory "
            f"({state_root()}) — it is rebuilt on the next run, at the cost of losing "
            f"resumable state — before re-running.")
    # Skipped entirely once user_version matches, so the hot path is three pragmas + one read.
    have = con.execute("PRAGMA user_version").fetchone()[0]
    if have != _SCHEMA_VERSION:
        _migrate(con, have)
    # Tighten a 0644 DB from an older release plus WAL/SHM/journal sidecars (same payload bytes)
    for p in (path, *(path.with_name(path.name + s)
                      for s in _SIDECAR_SUFFIXES)):
        _tighten_mode(p, _DB_FILE_MODE)
    return con


def _migrate(con: sqlite3.Connection, have: int) -> None:
    # v0 gets all of _DDL; an existing DB runs migrations cumulatively, so v1 gets both V2 and V3
    if have == 0:
        con.executescript(_DDL)
    else:
        if have < 2:
            con.executescript(_DDL_V2)
        if have < 3:
            con.executescript(_DDL_V3)
        if have < 4:
            _migrate_v4(con)
    con.execute(f"PRAGMA user_version = {_SCHEMA_VERSION}")
    con.commit()


def _has_column(con: sqlite3.Connection, table: str, column: str) -> bool:
    """True when *table* exists and already carries *column* — makes v4 re-entrant."""
    return any(r[1] == column for r in con.execute(f"PRAGMA table_info({table})"))


def _rebuild_v4(con: sqlite3.Connection, table: str, ddl: str) -> None:
    """Instance-key one table by REBUILD, re-enterably (*table* is a module literal)."""
    # executescript is not atomic: resume an interrupted rebuild instead of failing on CREATE forever
    if _has_column(con, table, "instance_id"):
        return
    scratch = f"{table}_v4"
    if not _has_column(con, table, "run_id") and _has_column(con, scratch, "run_id"):
        con.execute(f"ALTER TABLE {scratch} RENAME TO {table}")
        return
    con.executescript(ddl)


def _migrate_v4(con: sqlite3.Connection) -> None:
    """Instance-key checkpoints/ev_replays/ev_probes, skipping any table already done."""
    # FK off for the rebuild (SQLite's documented procedure): a DROP of a child table must not cascade
    con.execute("PRAGMA foreign_keys = OFF")
    try:
        con.executescript(_DDL_V4_RUN_INSTANCES)
        _rebuild_v4(con, "checkpoints", _DDL_V4_CHECKPOINTS)
        _rebuild_v4(con, "ev_replays", _DDL_V4_EV_REPLAYS)
        if not _has_column(con, "ev_probes", "instance_id"):
            con.executescript(_DDL_V4_EV_PROBES)
        con.executescript(_DDL_V4_EV_PROBES_INDEX)
    finally:
        con.execute("PRAGMA foreign_keys = ON")


def register_run(run_id: str, *, repo_root: str,
                 repo_name: str | None = None,
                 app_id: str | None = None) -> None:
    """Upsert the per-run metadata row, called once at the top of ``scan_repo()`` so ``gc`` can rank runs by recency."""
    con = connect()
    with con:
        con.execute(
            "INSERT INTO runs(run_id, repo_root, repo_name, app_id) "
            "VALUES (?, ?, ?, ?) "
            "ON CONFLICT(run_id) DO UPDATE SET "
            "  repo_root = excluded.repo_root, "
            "  repo_name = excluded.repo_name, "
            "  app_id    = excluded.app_id, "
            "  updated_at = datetime('now')",
            (run_id, repo_root, repo_name, app_id),
        )
    con.close()


@contextmanager
def run_lock(run_id: str):
    """Advisory per-run_id lock in ``<state_dir>/locks/<run_id>.lock``; yields True if acquired, False if held."""
    # Non-blocking flock: the caller refuses, never waits; the OS drops it on crash; no fcntl -> True
    if fcntl is None:
        yield True
        return
    # O_NOFOLLOW protects only the final component, so the name goes through the component guard
    _check_component(f"{run_id}.lock")
    lock_path = ensure_state_dir("locks") / f"{run_id}.lock"
    try:
        fd = os.open(lock_path, os.O_CREAT | os.O_RDWR | _O_NOFOLLOW, _DB_FILE_MODE)
    except OSError as e:
        if e.errno in _SYMLINK_ERRNOS:
            raise StateIntegrityError(
                f"refusing to lock {lock_path}: {e}. A lock file must be a regular "
                f"file under the state root, never a symlink.") from e
        raise  # ENOSPC/EACCES/EROFS etc. — an environment fault, not an attack
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        os.close(fd)
        yield False
        return
    try:
        yield True
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def new_instance_id() -> str:
    """A fresh per-invocation instance id (128 bits — never collides across a server's scans)."""
    return secrets.token_hex(16)


def register_instance(run_id: str, instance_id: str, *,
                      status: InstanceStatus = InstanceStatus.RUNNING) -> None:
    """Upsert the ``run_instances`` row for one invocation of one target."""
    con = connect()
    with con:
        con.execute("INSERT OR IGNORE INTO runs(run_id, repo_root) VALUES (?, '')",
                    (run_id,))
        con.execute(
            "INSERT INTO run_instances(run_id, instance_id, status) VALUES (?, ?, ?) "
            "ON CONFLICT(run_id, instance_id) DO UPDATE SET "
            "  status = excluded.status, finished_at = NULL",
            (run_id, instance_id, str(status)))
    con.close()


def finish_instance(run_id: str, instance_id: str | None = None, *,
                    status: InstanceStatus = InstanceStatus.COMPLETED) -> None:
    """Record an instance's completion (and when), for gc and reporting; --resume picks by recency, not status."""
    con = connect()
    with con:
        con.execute(
            "UPDATE run_instances SET status = ?, finished_at = datetime('now') "
            "WHERE run_id = ? AND instance_id = ?",
            (str(status), run_id, instance_id or _current_instance()))
    con.close()


def latest_instance_with_step(run_id: str, step: str | None = None) -> str | None:
    """The instance ``--resume`` should continue: the newest one holding *step* (any step when None), or None."""
    # Recency decides; a running row means the previous invocation CRASHED (run_lock serialises a
    # run_id). LEFT join so legacy rows (no run_instances row) stay reachable and a pre-v4 DB resumes.
    where_step = "AND c.step = ? " if step is not None else ""
    sql = ("SELECT c.instance_id FROM checkpoints c "
           "LEFT JOIN run_instances i "
           "  ON i.run_id = c.run_id AND i.instance_id = c.instance_id "
           "WHERE c.run_id = ? " + where_step +
           # i.rowid outranks status: started_at has 1-second resolution
           "ORDER BY COALESCE(i.started_at, c.created_at) DESC, "
           "         i.rowid DESC, "
           "         COALESCE(i.status = ?, 0) DESC, "
           "         c.created_at DESC, c.instance_id DESC "
           "LIMIT 1")
    args = ((run_id, step, str(InstanceStatus.COMPLETED)) if step is not None
            else (run_id, str(InstanceStatus.COMPLETED)))
    con = connect()
    try:
        row = con.execute(sql, args).fetchone()
    finally:
        con.close()
    if row is None:
        return None
    return _validated_instance_id(row[0], source="the checkpoints table")


def begin_instance(run_id: str, *, resume: bool = False) -> str:
    """Mint (fresh scan) or adopt (--resume) this process's instance and pin it."""
    # Fresh: new id, so concurrent scans of one path never share checkpoints or cached S6 verdicts
    inst = (latest_instance_with_step(run_id) if resume else None) or new_instance_id()
    register_instance(run_id, inst)
    from vvaharness.orchestrator import store as _pkg
    _pkg.set_current_instance(inst)
    return inst


def _touch_run(con: sqlite3.Connection, run_id: str) -> None:
    """Ensure the parent ``runs`` row exists (FK + cascade depend on it) and mark it used now, for ``gc``."""
    con.execute("INSERT OR IGNORE INTO runs(run_id, repo_root) VALUES (?, '')",
                (run_id,))
    con.execute("UPDATE runs SET updated_at = datetime('now') WHERE run_id = ?",
                (run_id,))


def reset_run(run_id: str, *, instance_id: str | None = None,
              other_instances: bool = False) -> int:
    """Delete checkpoint rows for one run (fixed s1..s9 steps and dynamic remediate_/validate_ steps), call..."""
    # ev_replays DELIBERATELY NOT cleared: must outlive a rescan; delete_run reaps via FK cascade
    # Default: only this instance's rows; other_instances=True purges every OTHER (a fresh scan)
    inst = instance_id or _current_instance()
    con = connect()
    try:
        with con:
            cleared = 0
            cur = con.execute(
                "DELETE FROM checkpoints WHERE run_id = ? AND instance_id "
                + ("!= ?" if other_instances else "= ?"), (run_id, inst))
            cleared += cur.rowcount or 0
            # Callgraph tables are not instance-keyed; stays run-scoped.
            cur = con.execute("DELETE FROM callgraph_snapshots WHERE run_id = ?", (run_id,))
            cleared += cur.rowcount or 0
            return cleared
    finally:
        con.close()


def steps_with_prefix(run_id: str, prefix: str, *,
                      instance_id: str | None = None) -> list[str]:
    """Return this instance's checkpoint step keys starting with *prefix*, sorted — the dynamic keys hash engine identity and a case id, so no caller can reconstruct one to look it up directly."""
    inst = instance_id or _current_instance()
    con = connect()
    try:
        rows = con.execute("SELECT step FROM checkpoints "
                           "WHERE run_id = ? AND instance_id = ?",
                           (run_id, inst)).fetchall()
        return sorted(r[0] for r in rows if r[0].startswith(prefix))
    finally:
        con.close()


def delete_steps(run_id: str, prefix: str, keep: Collection[str], *,
                 instance_id: str | None = None) -> list[str]:
    """Delete this instance's checkpoint rows whose step starts with *prefix* and is not in *keep* — the complement of :func:`reset_run` for the standalone remediate/validate commands. Returns the deleted keys, sorted."""
    inst = instance_id or _current_instance()
    con = connect()
    try:
        with con:
            rows = con.execute("SELECT step FROM checkpoints "
                               "WHERE run_id = ? AND instance_id = ?",
                               (run_id, inst)).fetchall()
            victims = sorted(r[0] for r in rows
                             if r[0].startswith(prefix) and r[0] not in keep)
            con.executemany("DELETE FROM checkpoints "
                            "WHERE run_id = ? AND instance_id = ? AND step = ?",
                            [(run_id, inst, v) for v in victims])
        return victims
    finally:
        con.close()


def is_run_id(value: object) -> bool:
    """True for a string of the shape ``run_id_for`` mints."""
    return isinstance(value, str) and _RUN_ID_RE.fullmatch(value) is not None


def delete_run_graphs(run_id: str) -> bool:
    """Remove the run's code-graph workspaces under ``graphs/<run_id>``; absent is fine. An id without the minted shape is left alone and returns False."""
    if not is_run_id(run_id):
        return False
    shutil.rmtree(state_root() / "graphs" / run_id, ignore_errors=True)
    return True


def purge_run_artifacts(run_id: str) -> int:
    """Remove one run's relocated artifacts from the state tree; returns instance directories removed."""
    # run_id comes from the container-writable runs table: validated BEFORE it is joined
    _check_component(run_id)
    target = state_root() / _ARTIFACTS_DIR_NAME / run_id
    try:
        removed = 0 if target.is_symlink() else sum(1 for p in target.iterdir() if p.is_dir())
    except OSError:
        removed = 0
    return removed if _rmtree_within_root(target) else 0


def _rmtree_within_root(target: Path) -> bool:
    """Delete *target* if it is a real directory inside the state root; True if it is gone."""
    root = state_root()
    if not target.exists() and not target.is_symlink():
        return False
    # A symlinked leaf or intermediate level would redirect the rmtree off the state tree
    if target.is_symlink() or not _resolved_within(target, root):
        _warn_once(str(target),
                   f"not deleting {target}: it is a symlink or resolves outside the "
                   f"state root {root}. Remove it by hand after checking what it "
                   f"points at")
        if target.is_symlink():
            target.unlink()          # drop the planted link, never its target
        return False
    failure: OSError | None = None
    for _ in range(_RMTREE_PASSES):
        failed: list[tuple[str, OSError]] = []
        shutil.rmtree(target, **{_RMTREE_ERROR_HOOK: partial(_record_failure, failed)})
        if not failed:
            return not os.path.lexists(target)
        failure = failed[0][1]
        if any(exc.errno == errno.EMFILE for _, exc in failed):
            _raise_fd_limit()
        for path, _exc in failed:
            _owner_dir_access(path)
    _warn_once(str(target),
               f"could not fully delete {target} — some entries remain, and they can "
               f"quote scanned source: {failure}")
    return False


#: Passes `_rmtree_within_root` makes over a subtree: a contained run owns its files, so it can
#: take its own directories away from their owner, and each pass gives back the ones the last
#: one could not enter. A chain locked deeper than this is left behind with a warning rather
#: than retried without bound.
_RMTREE_PASSES: Final = 32

#: `shutil.rmtree`'s error hook: `onexc` from 3.12, where `onerror` is deprecated.
_RMTREE_ERROR_HOOK: Final = "onexc" if sys.version_info >= (3, 12) else "onerror"


def _record_failure(sink: list[tuple[str, OSError]], _func: object, path: str,
                    exc: object) -> None:
    """`shutil.rmtree`'s hook: note what could not be removed, for the next pass to retry."""
    error = exc[1] if isinstance(exc, tuple) else exc  # `onerror` passes exc_info
    sink.append((path, error if isinstance(error, OSError) else OSError(str(error))))


def _owner_dir_access(path: str) -> None:
    """Give *path*, and the directory holding it, back to their owner, where each is a directory.

    `lstat` decides, so a link is never followed to a mode change outside the subtree.
    """
    for candidate in (path, os.path.dirname(path)):
        with suppress(OSError):
            if stat.S_ISDIR(os.lstat(candidate).st_mode):
                os.chmod(candidate, stat.S_IRWXU)


def _raise_fd_limit() -> None:
    """Raise this process's soft open-file limit toward its hard one, for a deep subtree.

    `shutil.rmtree` holds one descriptor per directory level, so a deep enough chain runs out
    of them (macOS's default soft limit is 256). Best effort: some systems cap below the hard
    limit, so smaller targets are tried in turn.
    """
    try:
        import resource  # POSIX only
    except ImportError:
        return
    soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    unlimited = resource.RLIM_INFINITY
    for wanted in (hard, 65536, 10240):
        if wanted == unlimited or wanted <= soft or (hard != unlimited and wanted > hard):
            continue
        with suppress(ValueError, OSError):
            resource.setrlimit(resource.RLIMIT_NOFILE, (wanted, hard))
            return


#: Each contained target's whole state root (`sandbox.config.spec_from` mounts it): a container
#: reads and writes only its own target's state, never another target's, nor the host's.
_CONTAINED_DIR_NAME: Final = "contained"


def contained_state_location(run_id: str) -> Path:
    """Where *run_id*'s contained state lives, creating NOTHING."""
    _check_component(run_id)
    return state_root() / _CONTAINED_DIR_NAME / run_id


def contained_state_dir(run_id: str) -> Path:
    """Create and return *run_id*'s contained state subtree, every level owner-only."""
    return ensure_state_dir(_CONTAINED_DIR_NAME, run_id)


def purge_contained_state(run_id: str) -> bool:
    """Remove *run_id*'s contained state subtree; True if one was removed."""
    # Container-authored, so it is deleted unopened: nothing in it is read
    return _rmtree_within_root(contained_state_location(run_id))


def prune_contained_states(max_age_days: int, *,
                           dry_run: bool = False) -> tuple[list[str], list[str]]:
    """Delete contained subtrees unwritten for *max_age_days*; returns ``(deleted, skipped)``.

    Age is the newest mtime of the subtree, its DB and the DB's WAL, read without opening the
    DB (`_contained_age_mtime`). A subtree whose target's run lock is held -- a contained scan in
    progress takes it on the host -- is skipped, and one written again by the time the lock is
    taken is kept. ``dry_run`` reports the victims as deleted and touches nothing.
    """
    base = state_root() / _CONTAINED_DIR_NAME
    if base.is_symlink() or not base.is_dir():
        return [], []
    cutoff = time.time() - max_age_days * 86400
    victims = sorted(
        entry.name for entry in base.iterdir()
        if _RUN_ID_RE.fullmatch(entry.name) and not entry.is_symlink() and entry.is_dir()
        and _contained_age_mtime(entry) < cutoff
    )
    if dry_run:
        return victims, []
    deleted: list[str] = []
    skipped: list[str] = []
    for run_id in victims:
        with run_lock(run_id) as acquired:
            if not acquired:
                skipped.append(run_id)
            elif (_contained_age_mtime(base / run_id) < cutoff
                  and purge_contained_state(run_id)):
                deleted.append(run_id)
    return deleted, skipped


#: How far ahead of this clock an mtime may be and still count. The contained run sets its own
#: subtree's times, and one dated far ahead would keep the subtree from ever ageing out; within
#: this slack, clock skew between the host and a network state directory reads as "now".
_FUTURE_MTIME_SLACK_SECONDS: Final = 86400


def _contained_age_mtime(entry: Path) -> float:
    """The mtime a contained subtree's age is judged by, a far-future one not believed."""
    now = time.time()
    newest = max(_mtime(entry / name) for name in ("", _DB_NAME, f"{_DB_NAME}-wal"))
    return 0.0 if newest > now + _FUTURE_MTIME_SLACK_SECONDS else min(newest, now)


def _mtime(path: Path) -> float:
    """*path*'s own mtime, not following a link; 0 when it is absent."""
    try:
        return path.lstat().st_mtime
    except OSError:
        return 0.0


def delete_run(run_id: str) -> bool:
    """Fully evict a single run: delete its ``runs`` row (dropping ``checkpoints`` and ``ev_replays`` via ON DEL..."""
    # Same guard as `prune_checkpoints`: `connect()` would create the DB just to report no such run
    if not db_location().exists():
        return False
    con = connect()
    try:
        with con:
            cur = con.execute("DELETE FROM runs WHERE run_id = ?", (run_id,))
            deleted = cur.rowcount or 0
        if deleted:
            # incremental_vacuum frees one page per fetched row: unfetched, it frees one page
            con.execute("PRAGMA incremental_vacuum").fetchall()
            con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        delete_run_graphs(run_id)
        purge_run_artifacts(run_id)
        return deleted > 0
    finally:
        con.close()
