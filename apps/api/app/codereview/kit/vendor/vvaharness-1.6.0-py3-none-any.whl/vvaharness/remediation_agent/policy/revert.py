# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Roll back forbidden-path edits on disk, confined to the repo and restored from snapshot or the git index."""
from __future__ import annotations

import os
import re
import stat
import subprocess
from pathlib import Path, PurePosixPath

from vvaharness.remediation_agent.artifacts.diff import _norm_path, _safe_repo_path
from vvaharness.util import logs
from vvaharness.util.git_hardening import GitHardeningError, host_git
from vvaharness.util.git_paths import is_git_metadata

log = logs.get_logger(__name__)


# `git ls-files -s -z`: "<mode> <object> <stage>\t<path>" per entry
_INDEX_ENTRY = re.compile(r"(\d{6}) ([0-9a-f]{40,64}) (\d)\t(.+)", re.DOTALL)
_REGULAR_MODES = {"100644": False, "100755": True}  # mode -> executable


def _is_git_worktree(repo: Path) -> bool:
    # Every git run here is on a target whose own config could name a program: see `host_git`
    try:
        git = host_git(repo)
        r = subprocess.run(
            [*git.argv, "rev-parse", "--is-inside-work-tree"],
            capture_output=True, text=True, timeout=15, env=git.env)
        return r.returncode == 0 and r.stdout.strip() == "true"
    except (OSError, subprocess.SubprocessError, GitHardeningError):
        return False


def _index_entry(repo: Path, rel: str) -> tuple[str, str] | None:
    """``(mode, object id)`` of *rel*'s merged entry in the index, or ``None`` when it has none."""
    try:
        git = host_git(repo)
        r = subprocess.run(
            # --literal-pathspecs: a name such as `a[1].py` or `*.py` names one file, not a glob
            [*git.argv, "--literal-pathspecs", "ls-files", "-s", "-z", "--", rel],
            capture_output=True, timeout=15, env=git.env)
    except (OSError, subprocess.SubprocessError, GitHardeningError):
        return None
    if r.returncode != 0:
        return None
    wanted = PurePosixPath(rel)
    for record in r.stdout.decode("utf-8", "surrogateescape").split("\0"):
        match = _INDEX_ENTRY.fullmatch(record)
        # stage 0 only (an unmerged path has no single index content), and exactly this path
        if match and match.group(3) == "0" and PurePosixPath(match.group(4)) == wanted:
            return match.group(1), match.group(2)
    return None


def _is_tracked(repo: Path, rel: str) -> bool:
    return _index_entry(repo, rel) is not None


def _restore_from_index(repo: Path, rel: str) -> bool:
    """Put *rel* back to the content the index holds, byte for byte; True when it was restored.

    ``git checkout -- rel`` would do this too, but it runs the target's post-checkout hook, a
    smudge filter and ``core.fsmonitor``, none of which a rollback may run. This reads the
    object with ``cat-file`` (no filter, no textconv) and writes it with Python. The index, not
    HEAD, is the source: content staged before the run is kept. A symlink or submodule entry
    is left alone.
    """
    entry = _index_entry(repo, rel)
    if entry is None:
        return False
    mode, oid = entry
    if mode not in _REGULAR_MODES:
        log.warning("not restoring %s: the index holds it as mode %s, not a regular file",
                    rel, mode)
        return False
    try:
        git = host_git(repo)
        blob = subprocess.run([*git.argv, "cat-file", "blob", oid],
                              capture_output=True, timeout=30, env=git.env)
    except (OSError, subprocess.SubprocessError, GitHardeningError):
        return False
    if blob.returncode != 0:
        return False
    p = repo / rel
    if p.is_symlink():
        p.unlink()  # a link the run planted: replace it, never write through it
    elif p.is_dir():
        log.warning("not restoring %s: a directory stands where the file was", rel)
        return False
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(blob.stdout)
    if os.name != "nt":
        # an edit may have flipped the executable bit; the index's mode is the truth
        bits = stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
        current = p.stat().st_mode
        p.chmod(current | bits if _REGULAR_MODES[mode] else current & ~bits)
    return True


def revert_files(repo: Path, files: list[str],
                 before_snapshot: dict[str, str | None] | None = None) -> list[str]:
    """Roll back *files* (repo-relative) to their pre-edit state. Best-effort and never raises."""
    # Order: pre-edit snapshot, then the index's content (tracked) / delete (untracked), else leave alone
    repo = Path(repo)
    snap = before_snapshot or {}
    is_git = _is_git_worktree(repo)
    reverted: list[str] = []
    for raw in files or []:
        rel = _norm_path(raw)
        if not rel:
            continue
        # Fail closed on abs/../symlink escapes (CWE-22): LLM refs would unlink host files
        if _safe_repo_path(repo, raw) is None:
            log.warning("refusing to revert out-of-repo path %r (escapes %s)",
                        raw, repo)
            continue
        # Repository metadata is never deleted or rewritten, whatever the baseline or verdict says
        if is_git_metadata(rel):
            log.warning("refusing to revert .git-owned path %r", rel)
            continue
        p = repo / rel
        try:
            if rel in snap:
                old = snap[rel]
                if old is None:
                    if p.exists():
                        p.unlink()
                else:
                    p.write_text(old, encoding="utf-8")
                reverted.append(rel)
                continue
            if is_git:
                if _is_tracked(repo, rel):
                    if not _restore_from_index(repo, rel):
                        continue
                elif p.exists():
                    # untracked (agent-created) → remove
                    p.unlink()
                reverted.append(rel)
        except Exception as e:                         # noqa: BLE001
            log.warning("failed to revert %s: %s", rel, e)
    return reverted
