# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The `Sandbox` protocol implemented against a real Docker daemon."""

from __future__ import annotations

import contextlib
import secrets
import shutil
import tempfile
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING

from docker.errors import DockerException
from requests.exceptions import ConnectionError as DaemonConnectionError
from requests.exceptions import ReadTimeout, RequestException
from urllib3.exceptions import ReadTimeoutError

from vvaharness.backends.sandbox.docker import client as daemon
from vvaharness.backends.sandbox.docker import egress, evnet, policy, preflight, stream
from vvaharness.backends.sandbox.models import (
    EGRESS_CALLBACK_ENV,
    EGRESS_FORWARDS_ENV,
    EGRESS_SOCKET_ENV,
    EV_HOST_GATEWAY_ENV,
    Capability,
    SandboxError,
    SandboxUnavailableError,
    is_ev_bridge,
    network_for_level,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    import docker
    from docker.models.containers import Container

    from vvaharness.backends.sandbox.docker.models import RunPlan
    from vvaharness.backends.sandbox.models import SandboxNetwork, SandboxSpec

#: What this backend can actually enforce. `MEDIATE_NETWORK` is claimable because
#: `mediated-network` runs the container with no network at all, its one way out a socket to a
#: CONNECT-proxy sidecar whose allowlist is generated per run (egress.py) -- Docker alone still
#: has no L7 control.
#: `RESTRICT_SYSCALLS` is Docker's default seccomp profile, which no knob here overrides.
_CAPABILITIES = (
    Capability.CONFINE_READS
    | Capability.CONFINE_WRITES
    | Capability.DENY_NETWORK
    | Capability.MEDIATE_NETWORK
    | Capability.RESTRICT_SYSCALLS
    | Capability.DROP_PRIVILEGES
)


def _run_error(
    exc: ReadTimeout | DaemonConnectionError | DockerException,
    *, waiting: bool, deadline: float | None,
) -> SandboxError:
    """The refusal for *exc*, raised creating, starting or waiting on the contained run."""
    # docker-py signals an expired wait with a read timeout. Before the wait, the timeout is
    # docker-py's own per-request one, and naming the sandbox's would blame a knob unused.
    if _read_timed_out(exc) and waiting and deadline is not None:
        msg = (f"the contained invocation exceeded its {deadline}s sandbox timeout "
               f"(sandbox.timeout_seconds) and was killed")
    elif isinstance(exc, ReadTimeout):
        msg = "the Docker daemon stopped answering while the contained run was starting"
    # Also requests': the daemon went away mid-run (quit, restarted).
    elif isinstance(exc, DaemonConnectionError):
        msg = f"lost the connection to the Docker daemon during the contained run: {exc}"
    else:
        msg = daemon.run_failure(exc)
    return SandboxError(msg)


def _read_timed_out(exc: BaseException) -> bool:
    """Whether *exc* is an expired read, in either form requests raises it.

    A read that times out while the response streams (docker-py's wait, over the unix socket)
    comes back as requests' ConnectionError wrapping urllib3's ReadTimeoutError, not ReadTimeout.
    """
    if isinstance(exc, ReadTimeout):
        return True
    return isinstance(exc, DaemonConnectionError) and any(
        isinstance(arg, ReadTimeoutError) for arg in exc.args)


class DockerSandbox:
    """Runs one whole vvaharness invocation inside a single Docker container."""

    def __init__(self) -> None:
        """Start with nothing acquired; `preflight` connects and `run` creates the container."""
        self._client: docker.DockerClient | None = None
        self._plan: RunPlan | None = None
        self._container: Container | None = None
        self._egress: daemon.Egress | None = None
        self._callback_port: int | None = None
        self._conf_dir: str | None = None
        self._proxy_image: str | None = None

    @property
    def capabilities(self) -> Capability:
        """What this backend enforces, checked against the requested level before any work."""
        return _CAPABILITIES

    def preflight(self, spec: SandboxSpec) -> None:
        """Validate *spec*, connect to Docker, ensure the images are present, derive the plan.

        Raises:
            SandboxUnavailableError: If the spec, this machine, or the daemon cannot satisfy it.
        """
        limits = preflight.check(spec)
        network = spec.network or network_for_level(spec.level)
        # Held from the moment it connects, so a refusal below still releases it: the gate
        # calls `teardown` only around `run`, never after a failed preflight.
        self._client = client = daemon.connect(allow_remote=spec.allow_remote_daemon)
        try:
            daemon.warn_weak_isolation(client)
            daemon.sweep_orphans(client)
            # Pinned to the id the tag resolved to HERE, and everything downstream -- the
            # gateway probe and the create call -- uses that: re-resolving a mutable tag could
            # run a different image than the one this preflight checked.
            resolved = daemon.require_image(client, spec.image, allow_pull=spec.allow_pull)
            if spec.needs_semgrep:
                daemon.warn_missing_semgrep(client, resolved)
            pinned = replace(spec, image=resolved)
            if egress.mediated(network):
                self._proxy_image = daemon.require_local_image(client, egress.PROXY_IMAGE)
            # The image must already be present: the gateway probe runs it, labelled so a
            # leaked probe is swept like the scan container.
            ev = (evnet.plan(client, pinned.image, policy.owner_labels(spec.level))
                  if is_ev_bridge(network) else None)
            self._plan = policy.derive(pinned, limits, ev=ev)
        except BaseException:
            self.teardown()
            raise

    def run(self, argv: Sequence[str], env: Mapping[str, str], timeout: float | None) -> int:
        """Create the container, stream its output live, and return its exit code.

        Raises:
            SandboxError: If the container cannot be created, times out, or cannot be waited on.
        """
        client, plan = self._resolve()
        network = egress.with_env_hosts(egress.bound(plan.network), env)
        socket_volume = self._start_egress(client, plan, network)
        kwargs = plan.container_kwargs()
        kwargs["command"] = list(argv)
        if socket_volume is not None:
            kwargs["volumes"][socket_volume] = {"bind": egress.SOCKET_TARGET, "mode": "rw"}
        # The plan's own env describes the container (HOME on a tmpfs); the caller's carries the
        # credentials and the remapped state directory. The forced proxy env goes LAST: the
        # HTTP(S)_PROXY/NO_PROXY names cross the boundary with a network (CONTAINER_ENV), so
        # a host-side value would otherwise win over mediation. The socket path, the forwarded
        # ports, the callback and the EV gateway are dropped from what crossed first:
        # `VVAHARNESS_` crosses wholesale, so a host-set socket or port would start a relay
        # outside mediation, and a host-set gateway would pick the address
        # `safety.check_allowed` treats as local.
        contained = {**plan.environment, **env}
        for forced in (EGRESS_SOCKET_ENV, EGRESS_FORWARDS_ENV, EGRESS_CALLBACK_ENV):
            contained.pop(forced, None)
        contained.update(egress.proxy_env(network))
        if self._callback_port is not None:
            contained.update(egress.callback_env(self._callback_port))
        contained.pop(EV_HOST_GATEWAY_ENV, None)
        contained.update(evnet.forced_env(plan.ev))
        kwargs["environment"] = contained
        deadline = plan.timeout if timeout is None else timeout
        waiting = False
        try:
            container = client.containers.create(plan.image, **kwargs)
            # Assigned before start, so a container that fails to start is still removable.
            self._container = container
            # Started INSIDE the relay: the output stream must exist before the run can end.
            with stream.pumping(container):
                container.start()
                waiting = True
                result = container.wait(timeout=deadline)
        # requests' errors are NOT DockerExceptions -- left uncaught they escape as a bare
        # traceback. The container may still be running; `teardown`'s force-remove stops it.
        except (ReadTimeout, DaemonConnectionError, DockerException) as exc:
            raise _run_error(exc, waiting=waiting, deadline=deadline) from exc
        return int(result["StatusCode"])

    def _start_egress(
        self, client: docker.DockerClient, plan: RunPlan, network: SandboxNetwork
    ) -> str | None:
        """Bring up the sidecar for a mediated run and return the socket volume to mount, else None.

        Raises:
            SandboxUnavailableError: If the sidecar image was never resolved by `preflight`;
                creating it from the mutable tag here would resolve the tag a second time.
        """
        if not egress.mediated(network):
            return None
        if self._proxy_image is None:
            msg = (
                "mediated egress reached run() with no preflighted sidecar image; the proxy "
                "image is resolved once, by preflight(), so the tag cannot move before create"
            )
            raise SandboxUnavailableError(msg)
        self._conf_dir = tempfile.mkdtemp(prefix=egress.CONF_DIR_PREFIX)
        conf = Path(self._conf_dir) / egress.CONF_NAME
        conf.write_text(egress.squid_conf(network), encoding="utf-8")
        # World-readable: a bind mount's apparent owner inside the container is platform-
        # dependent, and the file holds nothing but this run's allowlisted hostnames.
        conf.chmod(0o644)
        Path(self._conf_dir).chmod(0o755)
        volume_name, proxy_name = egress.names(secrets.token_hex(4))
        # Reserved before create: the published port and `EV_OOB_URL` are both fixed there.
        self._callback_port = evnet.reserve_host_port() if network.callback else None
        self._egress = daemon.start_egress(
            client,
            policy.derive_sidecar(
                conf_dir=self._conf_dir, socket_volume=volume_name, labels=plan.labels,
                image=self._proxy_image, forwards=network.forwards,
                callback_port=self._callback_port,
            ),
            volume_name=volume_name,
            proxy_name=proxy_name,
            bridges=1 + len(network.forwards) + int(network.callback),
        )
        if self._callback_port is not None:
            daemon.check_callback(self._egress, self._callback_port)
        return volume_name

    def teardown(self) -> None:
        """Release all this run acquired: container, sidecar, socket volume, daemon client."""
        try:
            # requests' errors too (a read timeout, a daemon gone): either one escaping here
            # would skip the sidecar and the conf dir below.
            if self._container is not None:
                with contextlib.suppress(DockerException, RequestException):
                    self._container.remove(force=True)
            daemon.stop_egress(self._egress)
            if self._conf_dir is not None:
                shutil.rmtree(self._conf_dir, ignore_errors=True)
        finally:
            daemon.close(self._client)
            self._container = None
            self._egress = None
            self._callback_port = None
            self._conf_dir = None
            self._proxy_image = None
            self._client = None

    def _resolve(self) -> tuple[docker.DockerClient, RunPlan]:
        """Return the client and plan that `preflight` established.

        Raises:
            SandboxUnavailableError: If `run` was reached without a successful `preflight`.
        """
        if self._client is None or self._plan is None:
            msg = "docker sandbox run() called before a successful preflight()"
            raise SandboxUnavailableError(msg)
        return self._client, self._plan


__all__ = ["DockerSandbox"]
