# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


from __future__ import annotations
from vvaharness.util import logs

"""orchestrator.cleanup — see package docstring."""
import os
import stat
from pathlib import Path

from vvaharness.orchestrator.artifacts import CASE_DIR_NAME, SCAN_DIR_NAME
from vvaharness.util.events import Event

log = logs.get_logger(__name__)


# Directory-descriptor operations let the purge open the clone root once, refusing a link, and
# then work only relative to that descriptor, so a link swapped in afterwards cannot redirect it.
_FD_SAFE = (
    os.name != "nt"
    and hasattr(os, "O_NOFOLLOW") and hasattr(os, "O_DIRECTORY")
    and {os.open, os.stat, os.unlink, os.rmdir} <= os.supports_dir_fd
    and os.stat in os.supports_follow_symlinks
    and os.listdir in os.supports_fd
)
_OPEN_DIR = (os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0))


def _is_link(path: Path | str) -> bool:
    """True for a symlink or a Windows junction/reparse point, judged without following it."""
    try:
        st = os.lstat(path)
    except OSError:
        return False
    if stat.S_ISLNK(st.st_mode):
        return True
    return bool(getattr(st, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0))


def _unlink_link(path: Path) -> None:
    """Remove the link itself, never what it points at (a Windows junction needs rmdir)."""
    try:
        os.unlink(path)
    except OSError:
        os.rmdir(path)


def _rm_at(dir_fd: int, name: str) -> None:
    """Remove *name* inside the directory *dir_fd*; a link is unlinked, never followed or chmod-ed."""
    st = os.stat(name, dir_fd=dir_fd, follow_symlinks=False)
    if not stat.S_ISDIR(st.st_mode):
        os.unlink(name, dir_fd=dir_fd)  # a file, or a link: the entry itself
        return
    fd = os.open(name, _OPEN_DIR, dir_fd=dir_fd)
    failed = False
    try:
        if not os.path.samestat(st, os.fstat(fd)):
            raise OSError(f"{name} was replaced while it was being removed")
        if stat.S_IMODE(st.st_mode) & 0o700 != 0o700:
            # a read-only directory inside the clone: add owner access, keep every other bit
            os.fchmod(fd, stat.S_IMODE(st.st_mode) | 0o700)
        for child in os.listdir(fd):
            try:
                _rm_at(fd, child)
            except OSError:
                failed = True  # keep going: the caller reports whatever survives
    finally:
        os.close(fd)
    if failed:
        raise OSError(f"could not remove everything under {name}")
    os.rmdir(name, dir_fd=dir_fd)


def _retry_writable(op, path: Path) -> None:
    """Run *op*; on a read-only refusal add the write bit to *path*'s own mode and retry once."""
    try:
        op()
    except PermissionError:
        os.chmod(path, stat.S_IMODE(os.lstat(path).st_mode) | stat.S_IWRITE)
        op()


def _rm_path(path: Path) -> None:
    """Path-based removal for a platform without directory descriptors (Windows).

    Windows has no symlink-swap hazard that descriptors would close here, but the link checks
    still apply: a link is unlinked itself and its target is never listed or chmod-ed.
    """
    if _is_link(path):
        _unlink_link(path)
        return
    if path.is_dir():
        failed = False
        for child in path.iterdir():
            try:
                _rm_path(child)
            except OSError:
                failed = True
        if failed:
            raise OSError(f"could not remove everything under {path}")
        _retry_writable(path.rmdir, path)
    else:
        _retry_writable(path.unlink, path)  # RO .git/objects/* files are left behind otherwise


def _rmtree_rw(path: Path) -> None:
    """Remove *path* and what is under it, best effort; a link is removed itself, never followed.

    Clears the read-only bit where Windows needs it (RO `.git/objects/*` files otherwise leave the
    tree behind). A survivor is not raised: the caller checks for it.
    """
    try:
        if _is_link(path):
            _unlink_link(path)
        elif _FD_SAFE:
            parent = os.open(path.parent, _OPEN_DIR & ~getattr(os, "O_NOFOLLOW", 0))
            try:
                _rm_at(parent, path.name)
            finally:
                os.close(parent)
        else:
            _rm_path(path)
    except OSError:
        pass


# A profile that doesn't set output.preserve_on_cleanup falls back to this tuple; anything absent from it is deleted outright by the batch clone purge — a case file not listed here is data loss, not a stale artefact.
_CLONE_KEEP_DEFAULT = (SCAN_DIR_NAME, CASE_DIR_NAME)


def _preserve_set(cfg) -> set[str]:
    vals = getattr(getattr(cfg, "output", None), "preserve_on_cleanup", None)
    return set(vals) if vals else set(_CLONE_KEEP_DEFAULT)


def _purge_clone(root: Path, keep: set[str]) -> None:
    """Delete the cloned source under `root` but preserve the named artifact folders (security-scan/ and security-remediation/ by default).

    `root` must be a plain directory. A link, or anything else, at that path is refused and left
    alone: following it would empty or chmod whatever it points at, outside the workspace.
    """
    if not os.path.lexists(root):
        return
    if _is_link(root) or not root.is_dir():
        log.warning(Event.PURGE_REFUSED, root=root)
        return
    if _FD_SAFE:
        try:
            fd = os.open(root, _OPEN_DIR)  # O_NOFOLLOW: a link swapped in since the check fails here
        except OSError:
            log.warning(Event.PURGE_REFUSED, root=root)
            return
        try:
            for name in os.listdir(fd):
                if name not in keep:
                    try:
                        _rm_at(fd, name)
                    except OSError:
                        pass  # reported as a survivor below
            leftover = [n for n in os.listdir(fd) if n not in keep]
        finally:
            os.close(fd)
    else:
        for child in root.iterdir():
            if child.name not in keep:
                try:
                    _rm_path(child)
                except OSError:
                    pass
        leftover = [c.name for c in root.iterdir() if c.name not in keep]

    # A failed delete would otherwise leave a secret-bearing clone on disk with no signal; surface any survivor so the operator knows.
    if leftover:
        log.warning(Event.PURGE_LEFTOVER, root=root, count=len(leftover), items=sorted(leftover))
