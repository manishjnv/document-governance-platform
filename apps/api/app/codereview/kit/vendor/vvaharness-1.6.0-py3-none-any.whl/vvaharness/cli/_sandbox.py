# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""The CLI's containment gate: re-exec an invocation inside a sandbox when the profile asks."""
# Kept out of cli/__init__ so --version/--help never import the sandbox package; see main()
from __future__ import annotations

import sys
from collections.abc import Sequence
from pathlib import Path

#: The logging tokens a contained re-exec must carry, so the inner run logs the same way.
_LOG_FLAGS = ("--log-level", "--log-file")


def log_flag_args(args: list[str]) -> list[str]:
    """The ``--log-level``/``--log-file`` tokens in *args*, split form, for a contained re-exec."""
    # _configure_logging strips these before the gate sees argv, so capture the values first
    found: dict[str, str] = {}
    for i, arg in enumerate(args):
        for flag in _LOG_FLAGS:
            if arg == flag and i + 1 < len(args):   # last occurrence wins, like _configure_logging
                found[flag] = args[i + 1]
            elif arg.startswith(f"{flag}="):
                found[flag] = arg.split("=", 1)[1]
    return [token for flag in _LOG_FLAGS if flag in found for token in (flag, found[flag])]


def _repo_from(rest: list[str]) -> str | None:
    """The --repo target in raw args, last occurrence wins — read through the gate's own reader."""
    # First-occurrence-wins would let a decoy --repo steer the mount while argparse read the last
    from vvaharness.backends.sandbox.remap import scan_flags
    return scan_flags(rest, {"--repo"}).get("--repo")


def maybe_contain(args: list[str], log_flags: Sequence[str] = ()) -> tuple[list[str], int | None]:
    """Run *args* inside a sandbox if ``sandbox:`` is configured; see `_gate`."""
    stripped, code = _gate(args, log_flags)
    if code is None:
        _note_contained_state(stripped)
    return stripped, code


def _note_contained_state(stripped: list[str]) -> None:
    """Say so when a host follow-up's target has state that only a contained command can see.

    A contained run keeps its target's state in its own subtree, which a host `--resume`,
    `remediate`, `validate` or `ev-replay` never reads; without this line it just finds nothing.
    """
    import os

    from vvaharness.backends.sandbox.models import IN_SANDBOX_ENV, SANDBOXED_COMMANDS

    if os.environ.get(IN_SANDBOX_ENV) or not stripped or stripped[0] not in SANDBOXED_COMMANDS:
        return
    if stripped[0] == "scan" and "--resume" not in stripped:
        return
    repo = _repo_from(stripped)
    if not repo:
        return
    from vvaharness.orchestrator import store
    from vvaharness.orchestrator.checkpoints import run_id_for

    if store.contained_state_location(run_id_for(repo)).is_dir():
        print(f"NOTE: {repo} also has state from a contained run, which only a command run "
              f"with the same sandbox profile can see.", file=sys.stderr)


def _gate(args: list[str], log_flags: Sequence[str]) -> tuple[list[str], int | None]:
    """Run *args* inside a sandbox if ``sandbox:`` is configured.

    Returns the arguments with ``--no-sandbox`` consumed (it must never reach the inner parser)
    and either the contained run's exit code or ``None`` to carry on here. A missing config falls
    through to an uncontained run: there is no profile to ask for containment. A policy-refused
    or unloadable one fails closed: whether it requests containment is unknowable, and a second
    load of the same file in the inner command must not be what decides that the run escapes
    the sandbox. A profile that DOES ask for containment and cannot get it fails too. *log_flags*
    are the logging tokens ``_configure_logging`` already consumed, forwarded into the container.
    """
    import yaml

    from vvaharness import config as config_mod
    from vvaharness.backends.sandbox import (
        SandboxError,
        containment_eligible,
        record_provenance,
        strip_contained_flag,
        strip_sandbox_flag,
    )
    from vvaharness.backends.sandbox import maybe_contain as _gate_contain

    stripped, declined = strip_sandbox_flag(args)
    # The nonce proves this process IS the re-exec; consumed here (no inner parser declares it) and
    # it replaces the ambient env marker as the re-entry signal. A malformed one is an error:
    # "" from a bare flag would otherwise skip the gate.
    stripped, nonce = strip_contained_flag(stripped)
    try:
        record_provenance(nonce)
        if nonce is not None:
            # A mediated run's one way out, opened before anything can call a model; only once
            # provenance holds, so a host run never listens.
            from vvaharness.backends.sandbox import relay

            relay.start()
    except SandboxError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return stripped, 2
    if nonce is not None:
        return stripped, None
    # Deciding eligibility here too skips the config load for never-contained commands, so doctor
    # can still diagnose a policy-refused config instead of dying before it runs.
    if not containment_eligible(stripped, declined):
        return stripped, None
    # Lazy: config_paths executes the orchestrator package, which must stay out of this module's
    # import graph — --version and --help would pay for it otherwise.
    from vvaharness.cli._paths import _config_path_from_explicit
    from vvaharness.orchestrator.config_paths import trusted_config_path

    repo = _repo_from(stripped)
    cfg_path, explicit = _config_path_from_explicit(stripped)
    # The gate is a config reader like any other: the profile picks the image, mounts and env,
    # so it goes through the same trust gate as the subcommands' own. An explicit --config inside
    # the target is a hard refusal (ConfigPolicyError) -> surface it as a clean exit 2 here, before
    # any subcommand parser runs, rather than letting it escape as an uncaught raise.
    # Quiet here: a run that stays uncontained gets the same WARN from the subcommand's own check,
    # so it is printed below only for a run the gate contains, whose inner check cannot see it.
    asked = cfg_path
    try:
        cfg_path = trusted_config_path(asked, repo, label="containment gate", explicit=explicit,
                                       quiet=True)
    except config_mod.ConfigPolicyError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return stripped, 2
    if not Path(cfg_path).exists():
        return stripped, None
    try:
        cfg = config_mod.load(cfg_path)
    except config_mod.ConfigPolicyError as exc:   # subclasses ValueError, so this clause is first
        print(f"ERROR: {exc}", file=sys.stderr)
        return stripped, 2
    except (OSError, ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: config unreadable ({exc}); not running a sandboxed command whose "
              f"containment cannot be decided", file=sys.stderr)
        return stripped, 2
    if _will_contain(cfg):
        trusted_config_path(asked, repo, label="containment gate", explicit=explicit)
    from vvaharness.orchestrator import store

    try:
        return stripped, _gate_contain(stripped, cfg, Path(repo) if repo else None,
                                       log_flags=log_flags, config_path=Path(cfg_path))
    # The host takes the target's run lock under the state dir before any container starts: a
    # symlinked or unwritable one is an operator fix, as on the uncontained path, not a crash.
    except (SandboxError, store.StoreError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return stripped, 2


def _will_contain(cfg: object) -> bool:
    """Whether *cfg*'s `sandbox:` block asks for containment; False when it cannot be read.

    An unreadable block is reported (and refused) by the gate itself, right after.
    """
    from vvaharness.backends.sandbox import SandboxError
    from vvaharness.backends.sandbox.config import load_sandbox_config, requested

    try:
        return requested(load_sandbox_config(cfg))
    except SandboxError:
        return False


__all__ = ["log_flag_args", "maybe_contain"]
