# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""Selection and loading of a trusted .env from cwd or home."""
from __future__ import annotations
from vvaharness.util import logs

import os
import stat
from pathlib import Path
from typing import TYPE_CHECKING
from vvaharness.util import console
from vvaharness.util.events import Event

if TYPE_CHECKING:
    from vvaharness.orchestrator.config_paths import Boundary

log = logs.get_logger(__name__)


def _dotenv_path_is_trusted(path: Path) -> bool:
    """Reject unsafe POSIX ownership/modes; exact-location checks protect other OSes."""
    try:
        entries = (path.parent.stat(), path.stat())
    except OSError:
        return False
    get_euid = getattr(os, "geteuid", None)
    if get_euid is None:
        return True
    effective_uid = get_euid()
    for entry in entries:
        if entry.st_uid != effective_uid:
            return False
        if entry.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
            return False
    return True

def _dotenv_selection(
    boundary: Boundary = (), *, warn: bool = False,
) -> tuple[Path | None, str | None, tuple[Path, ...]]:
    """Return the selected dotenv path, its source, and rejected candidates."""
    roots: list[tuple[str, Path]] = []
    for source, get_root in (("cwd", Path.cwd), ("home", Path.home)):
        try:
            roots.append((source, get_root().resolve()))
        except (OSError, RuntimeError):
            continue

    home_root = next((root for source, root in roots if source == "home"), None)
    rejected: list[Path] = []
    seen_roots: set[Path] = set()
    for source, root in roots:
        if root in seen_roots:
            continue
        seen_roots.add(root)
        candidate = root / ".env"
        if not candidate.is_file():
            continue
        try:
            path = candidate.resolve(strict=True)
        except OSError:
            continue
        if path.parent != root or not _dotenv_path_is_trusted(path):
            rejected.append(candidate)
            if warn:
                log.warning(Event.DOTENV_UNTRUSTED, path=candidate,
                            override="VVAHARNESS_ALLOW_CWD_CONFIG=1")
            continue
        from vvaharness.config.constants import ALLOW_CWD_CONFIG_ENV
        allow = os.environ.get(ALLOW_CWD_CONFIG_ENV)
        if boundary and not allow:
            from vvaharness.orchestrator.config_paths import _containing_boundary
            matched = _containing_boundary(path, boundary)
            if matched is not None:
                rejected.append(candidate)
                if warn:
                    log.warning(Event.DOTENV_INSIDE_TARGET, path=path, target=matched)
                continue
        if source == "cwd" and root != home_root and not allow:
            from vvaharness.util.gitindex import tracked
            hit = tracked(root, (".env",))
            if hit is not False:
                rejected.append(candidate)
                if warn:
                    log.warning(Event.DOTENV_TRACKED if hit else Event.DOTENV_INDEX_UNREADABLE,
                                path=path)
                continue
        return path, source, tuple(rejected)
    return None, None, tuple(rejected)

def _dotenv_path(boundary: Boundary = (), *, warn: bool = False) -> Path | None:
    """Return the first trusted cwd/home ``.env`` accepted for this invocation."""
    return _dotenv_selection(boundary, warn=warn)[0]

def _load_dotenv(boundary: Boundary = ()) -> None:
    """Load a trusted .env from exactly cwd or home, never an arbitrary ancestor."""
    try:
        from dotenv import load_dotenv
    except ImportError:
        return

    path = _dotenv_path(boundary, warn=True)
    if path is None:
        return
    from vvaharness.config.constants import ALLOW_CWD_CONFIG_ENV, NO_LOCAL_CONFIG_ENV
    shell_only = frozenset({ALLOW_CWD_CONFIG_ENV, NO_LOCAL_CONFIG_ENV})
    held = shell_only.intersection(os.environ)
    try:
        load_dotenv(path, override=False)
    finally:
        dropped = sorted(shell_only.intersection(os.environ) - held)
        for key in dropped:
            del os.environ[key]
    console.write(f"  [env] loaded {path}")
    if dropped:
        log.warning(Event.DOTENV_SWITCH_IGNORED, path=path, keys=",".join(dropped))
