# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""What each level requires, checked against what a backend declares it can enforce.

This table is the honesty contract: a backend that cannot enforce the requested level
refuses rather than running under-contained.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Final

from vvaharness.backends.sandbox.models import (
    Capability,
    CapabilityError,
    SandboxLevel,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

#: The capabilities a level is not meaningful without. A level whose requirements a backend
#: does not declare is refused at resolve time, before any container exists.
REQUIRED: Final[Mapping[SandboxLevel, Capability]] = {
    SandboxLevel.NONE: Capability.NOTHING,
    SandboxLevel.READ_ONLY: Capability.CONFINE_READS | Capability.CONFINE_WRITES,
    SandboxLevel.WORKSPACE_WRITE: Capability.CONFINE_READS | Capability.CONFINE_WRITES,
    SandboxLevel.NO_NETWORK: (
        Capability.CONFINE_READS | Capability.CONFINE_WRITES | Capability.DENY_NETWORK
    ),
    SandboxLevel.MEDIATED_NETWORK: (
        Capability.CONFINE_READS | Capability.CONFINE_WRITES | Capability.MEDIATE_NETWORK
    ),
}


def missing(level: SandboxLevel, capabilities: Capability) -> Capability:
    """Return the capabilities *level* requires that *capabilities* does not provide."""
    return REQUIRED[level] & ~capabilities


def _names(gap: Capability) -> str:
    """Render *gap*'s member names for an error message, lowercased and sorted."""
    return ", ".join(
        sorted(flag.name.lower() for flag in Capability if flag.name and flag & gap)
    )


def assert_supports(via: str, level: SandboxLevel, capabilities: Capability) -> None:
    """Raise `CapabilityError` unless *via* can enforce *level*.

    Raises:
        CapabilityError: If *capabilities* lacks anything `REQUIRED[level]` names.
    """
    gap = missing(level, capabilities)
    if gap is Capability.NOTHING:
        return
    msg = (
        f"sandbox via={via!r} cannot enforce level={level.value!r}: missing {_names(gap)}. "
        f"Choose a backend that can, or lower the level."
    )
    raise CapabilityError(msg)


__all__ = ["REQUIRED", "assert_supports", "missing"]
