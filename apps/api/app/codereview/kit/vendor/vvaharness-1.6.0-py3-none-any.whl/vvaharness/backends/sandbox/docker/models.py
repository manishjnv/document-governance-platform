# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""The Docker backend's own typed shapes: its validated knobs, and one run's decided arguments.

These are Docker's vocabulary, so they live with the backend rather than in the family's
portable contract.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Mapping

    from vvaharness.backends.sandbox.models import Mount, SandboxNetwork


@dataclass(frozen=True, slots=True)
class DockerLimits:
    """The `sandbox.docker:` resource knobs, after validation.

    `mem_limit`/`nano_cpus` default to unset: capping them needs knowledge of the machine, and
    a wrong guess OOM-kills a legitimate scan. `tmpfs_size` already bounds in-memory writes.
    """

    pids_limit: int
    tmpfs_size: str
    mem_limit: str | None = None
    nano_cpus: int | None = None


@dataclass(frozen=True, slots=True)
class EVNetwork:
    """One contained EV run's decided network facts, all known BEFORE the container starts.

    They must be: a container's environment and port map are fixed at create time, so the
    published host port is reserved and the gateway queried first.
    """

    gateway: str
    container_port: int
    host_port: int
    host_ip: str


@dataclass(frozen=True, slots=True)
class RunPlan:
    """The complete, already-decided argument set for one `containers.run` call.

    Derived by `policy.derive` so the backend holds no policy of its own. `timeout` rides
    along because it bounds the same run without being a `containers.run` argument.
    """

    image: str
    command: tuple[str, ...]
    environment: Mapping[str, str]
    volumes: Mapping[str, Mapping[str, str]]
    tmpfs: Mapping[str, str]
    user: str
    working_dir: str
    network_mode: str
    network: SandboxNetwork
    read_only: bool
    cap_drop: tuple[str, ...]
    security_opt: tuple[str, ...]
    limits: DockerLimits
    labels: Mapping[str, str]
    timeout: float | None
    #: The spec's mounts, kept so the EV path settings can be remapped with `remap.remap_path`
    #: rather than a second path-rewriting rule.
    mounts: tuple[Mount, ...] = ()
    extra_hosts: Mapping[str, str] = field(default_factory=dict)
    #: `{"9090/tcp": ("127.0.0.1", 54321)}` -- an empty map publishes nothing.
    ports: Mapping[str, tuple[str, int]] = field(default_factory=dict)
    ev: EVNetwork | None = None

    def container_kwargs(self) -> dict[str, Any]:
        """The keyword arguments to hand `containers.create`; `timeout` is deliberately excluded.

        `Any` values, not `object`: these are splatted into docker-py's own heavily-overloaded
        signature, which an `object` value satisfies for no parameter at all.
        """
        kwargs: dict[str, Any] = {
            "command": list(self.command),
            "detach": True,
            "environment": dict(self.environment),
            "volumes": {source: dict(opts) for source, opts in self.volumes.items()},
            "tmpfs": dict(self.tmpfs),
            "user": self.user,
            "working_dir": self.working_dir,
            "network_mode": self.network_mode,
            "read_only": self.read_only,
            "cap_drop": list(self.cap_drop),
            "security_opt": list(self.security_opt),
            "pids_limit": self.limits.pids_limit,
            "init": True,
            "labels": dict(self.labels),
        }
        if self.limits.mem_limit is not None:
            kwargs["mem_limit"] = self.limits.mem_limit
        if self.limits.nano_cpus is not None:
            kwargs["nano_cpus"] = self.limits.nano_cpus
        # Omitted when empty: docker-py sends `ExtraHosts: []`/`PortBindings: {}` happily, but
        # an absent key keeps a non-EV run's create call byte-identical to today's.
        kwargs.update({
            name: dict(value)
            for name, value in (("extra_hosts", self.extra_hosts), ("ports", self.ports))
            if value
        })
        return kwargs


__all__ = ["DockerLimits", "EVNetwork", "RunPlan"]
