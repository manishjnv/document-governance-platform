# Copyright 2026 Visa, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""vvaharness — agentic SAST pipeline."""
# Must stay the first statement: `python -m vvaharness[.<sub>]` puts the cwd on sys.path, so a
# scan target's own `json.py` would load ahead of the real one — including via the imports below.
import os as _os
import sys as _sys

# Runs even under `-P`/PYTHONSAFEPATH: those stop the interpreter ADDING cwd, but not a
# PYTHONPATH entry naming it, so skipping here made `-P` the one form that stayed hijackable.
# Compared by realpath, not by spelling: `/tmp/x` and `/private/tmp/x` are the same directory on
# macOS, and `<cwd>//`, `<cwd>/.` and `sub/..` all name it too.
_cwd_entries = {"", "."}
try:
    _real_cwd = _os.path.realpath(_os.getcwd())
    _cwd_entries.add(_real_cwd)
except OSError:  # cwd unreadable/deleted: nothing of ours to drop
    _real_cwd = None
_sys.path[:] = [
    _entry for _entry in _sys.path
    if _entry not in _cwd_entries
    and (_real_cwd is None or _os.path.realpath(_entry) != _real_cwd)
]
del _cwd_entries, _real_cwd

del _os, _sys

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

try:
    # Single source of truth: pyproject `version`, so the CLI banner can't drift from it.
    __version__ = _pkg_version("vvaharness")
except PackageNotFoundError:  # running from a source tree that isn't pip-installed
    __version__ = "1.6.0"


def __getattr__(name: str):
    """Expose the embeddable surface (e.g. ``remediate``) lazily, without importing backends."""
    if name in ("remediate", "validate"):
        from vvaharness import api
        return getattr(api, name)
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)
